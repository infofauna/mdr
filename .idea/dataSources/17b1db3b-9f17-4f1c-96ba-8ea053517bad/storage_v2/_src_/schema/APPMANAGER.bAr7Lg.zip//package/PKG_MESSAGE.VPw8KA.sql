create PACKAGE            pkg_message
AS
   /******************************************************************************
      NAME:       PKG_MESSAGE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        18.07.2013      burrif       1. Created this package.

   ******************************************************************************/
   TYPE t_messagetable IS TABLE OF MESSAGE.msg_message%TYPE
      INDEX BY PLS_INTEGER;


   cst_severity_level_error     CONSTANT CHAR (1) := 'E';
   cst_severity_level_info      CONSTANT CHAR (1) := 'I';
   cst_severity_level_warning   CONSTANT CHAR (1) := 'W';
   cst_severity_level_fatal     CONSTANT CHAR (1) := 'F';


   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_removeplaceholder (p_message       IN VARCHAR2,
                                 p_placeholder   IN VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION f_convertseveritylevel2status (
      p_exception IN MESSAGE.msg_errornumber%TYPE)
      RETURN NUMBER;

   FUNCTION f_get_severity_level_error
      RETURN CHAR;


   FUNCTION f_get_severity_level_info
      RETURN CHAR;


   FUNCTION f_get_severity_level_warning
      RETURN CHAR;


   FUNCTION f_get_severity_level_fatal
      RETURN CHAR;

   FUNCTION f_substituteparameter (p_message IN MESSAGE.msg_message%TYPE)
      RETURN MESSAGE.msg_message%TYPE;

   PROCEDURE p_clearapplication_id;

   FUNCTION f_getapplication_id
      RETURN admin_application.apl_id%TYPE;

   PROCEDURE p_setapplication_id (
      p_apl_code IN admin_application.apl_code%TYPE);

   PROCEDURE p_setapplication_id (p_apl_id IN admin_application.apl_id%TYPE);

   PROCEDURE p_clearmessageparameter;

   FUNCTION f_returnparameterlist
      RETURN pkg_message.t_messagetable;

   PROCEDURE p_getmessage (
      p_msg_errornumber   IN     MESSAGE.msg_errornumber%TYPE,
      p_lan_id            IN     MESSAGE.msg_lan_id%TYPE,
      p_severity             OUT MESSAGE.msg_severity%TYPE,
      p_message              OUT MESSAGE.msg_message%TYPE,
      p_returnstatus         OUT NUMBER);

   PROCEDURE p_getmessage (
      p_msg_errornumber   IN     MESSAGE.msg_errornumber%TYPE,
      p_lan_id            IN     MESSAGE.msg_lan_id%TYPE,
      p_parameter1        IN     VARCHAR2,
      p_severity             OUT MESSAGE.msg_severity%TYPE,
      p_message              OUT MESSAGE.msg_message%TYPE,
      p_returnstatus         OUT NUMBER);



   PROCEDURE p_getmessage (
      p_msg_errornumber   IN     MESSAGE.msg_errornumber%TYPE,
      p_lan_id            IN     MESSAGE.msg_lan_id%TYPE,
      p_parameter1        IN     VARCHAR2,
      p_parameter2        IN     VARCHAR2,
      p_severity             OUT MESSAGE.msg_severity%TYPE,
      p_message              OUT MESSAGE.msg_message%TYPE,
      p_returnstatus         OUT NUMBER);

   PROCEDURE p_getmessage (
      p_msg_errornumber   IN     MESSAGE.msg_errornumber%TYPE,
      p_lan_id            IN     MESSAGE.msg_lan_id%TYPE,
      p_parameter1        IN     VARCHAR2,
      p_parameter2        IN     VARCHAR2,
      p_parameter3        IN     VARCHAR2,
      p_severity             OUT MESSAGE.msg_severity%TYPE,
      p_message              OUT MESSAGE.msg_message%TYPE,
      p_returnstatus         OUT NUMBER);

   PROCEDURE p_getmessage (
      p_msg_errornumber   IN     MESSAGE.msg_errornumber%TYPE,
      p_lan_id            IN     MESSAGE.msg_lan_id%TYPE,
      p_parameter1        IN     VARCHAR2,
      p_parameter2        IN     VARCHAR2,
      p_parameter3        IN     VARCHAR2,
      p_parameter4        IN     VARCHAR2,
      p_severity             OUT MESSAGE.msg_severity%TYPE,
      p_message              OUT MESSAGE.msg_message%TYPE,
      p_returnstatus         OUT NUMBER);

   FUNCTION f_returnmessageseverity (
      p_msg_errornumber IN MESSAGE.msg_errornumber%TYPE)
      RETURN MESSAGE.msg_severity%TYPE;

   FUNCTION f_getmessagetext (
      p_msg_errornumber   IN MESSAGE.msg_errornumber%TYPE,
      p_lan_id            IN MESSAGE.msg_lan_id%TYPE)
      RETURN MESSAGE.msg_message%TYPE;

   PROCEDURE p_setparameter (p_value IN VARCHAR2, p_indice IN NUMBER);

   PROCEDURE p_tr_bif_message (p_newrec IN OUT MESSAGE%ROWTYPE);

   PROCEDURE p_tr_buf_message (p_oldrec   IN     MESSAGE%ROWTYPE,
                               p_newrec   IN OUT MESSAGE%ROWTYPE);


   FUNCTION f_returnmessagetext (
      p_msg_errornumber   IN MESSAGE.msg_errornumber%TYPE,
      p_lan_id            IN MESSAGE.msg_lan_id%TYPE)
      RETURN MESSAGE.msg_message%TYPE;
END pkg_message;
/

