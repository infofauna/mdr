create PACKAGE            pkg_job
AS
   /******************************************************************************
      NAME:       PKG_JOB
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.08.2015      burrif       1. Created this package.
   ******************************************************************************/

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_definecomputestats;
   PROCEDURE p_computecurrentschemastats;
END pkg_job;
/

