create PACKAGE            pkg_exception
AS
   /******************************************************************************
      NAME:       PKG_EXCEPTION
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        18.07.2013      burrif       1. Created this package.
      2.0        12.12.2016      burrif       2. Ajout des message MIDATSOURCE
      2.1        27.07.2017      burrif       3. Version 2 MIDAT
      2.2        11.07.2018      burrif       4. Nouveau droit d'accès
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_putexception2cache;


   exc_credentialstatusinvalid               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_credentialstatusinvalid, -20001);
   cst_credentialstatusinvalid      CONSTANT NUMBER := -20001;

   exc_tokenexpired                          EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_tokenexpired, -20002);
   cst_tokenexpired                 CONSTANT NUMBER := -20002;

   exc_crf_limitminandmaxreq                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_crf_limitminandmaxreq, -20003);
   cst_crf_limitminandmaxreq        CONSTANT NUMBER := -20003;

   exc_crf_limitmissmatch                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_crf_limitmissmatch, -20004);
   cst_crf_limitmissmatch           CONSTANT NUMBER := -20004;

   exc_crf_limitoverlay                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_crf_limitoverlay, -20005);
   cst_crf_limitoverlay             CONSTANT NUMBER := -20005;

   exc_fieldrequired                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_fieldrequired, -20006);
   cst_fieldrequired                CONSTANT NUMBER := -20006;


   exc_recordnotfound                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_recordnotfound, -20007);
   cst_recordnotfound               CONSTANT NUMBER := -20007;

   exc_noaccesstoapplication                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_noaccesstoapplication, -20008);
   cst_noaccesstoapplication        CONSTANT NUMBER := -20008;

   exc_invalidlancode                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_invalidlancode, -20009);
   cst_invalidlancode               CONSTANT NUMBER := -20009;

   exc_authoryearinvalid                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_authoryearinvalid, -20010);
   cst_authoryearinvalid            CONSTANT NUMBER := -20010;

   exc_authoryearyearinvalid                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_authoryearyearinvalid, -20011);
   cst_authoryearyearinvalid        CONSTANT NUMBER := -20011;

   exc_sheetnotfound                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_sheetnotfound, -20012);
   cst_sheetnotfound                CONSTANT NUMBER := -20012;

   exc_excelfieldrequired                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_excelfieldrequired, -20013);
   cst_excelfieldrequired           CONSTANT NUMBER := -20013;

   exc_exceldateinvalid                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_exceldateinvalid, -20014);
   cst_exceldateinvalid             CONSTANT NUMBER := -20014;

   exc_elevationinvalid                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_elevationinvalid, -20015);
   cst_elevationinvalid             CONSTANT NUMBER := -20015;

   exc_numvalueinvalid                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_numvalueinvalid, -20016);
   cst_numvalueinvalid              CONSTANT NUMBER := -20016;

   exc_decimalvalueinvalid                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_decimalvalueinvalid, -20017);
   cst_decimalvalueinvalid          CONSTANT NUMBER := -20017;

   exc_xcoordoutofrange                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_xcoordoutofrange, -20018);
   cst_xcoordoutofrange             CONSTANT NUMBER := -20018;

   exc_ycoordoutofrange                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_ycoordoutofrange, -20019);
   cst_ycoordoutofrange             CONSTANT NUMBER := -20019;

   exc_stationnotmatch                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_stationnotmatch, -20020);
   cst_stationnotmatch              CONSTANT NUMBER := -20020;


   exc_distanceininfolimit                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_distanceininfolimit, -20021);
   cst_distanceininfolimit          CONSTANT NUMBER := -20021;

   exc_distancewarninglimit                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_distancewarninglimit, -20022);
   cst_distancewarninglimit         CONSTANT NUMBER := -20022;

   exc_distanceoutofrange                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_distanceoutofrange, -20023);
   cst_distanceoutofrange           CONSTANT NUMBER := -20023;

   exc_newstationfound                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_newstationfound, -20024);
   cst_newstationfound              CONSTANT NUMBER := -20024;

   exc_stationintolerancproximity            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_stationintolerancproximity, -20025);
   cst_stationintolerancproximity   CONSTANT NUMBER := -20025;

   exc_info                                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_info, -20026);
   cst_info                         CONSTANT NUMBER := -20026;

   exc_zcoordoutofrange                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_zcoordoutofrange, -20027);
   cst_zcoordoutofrange             CONSTANT NUMBER := -20027;

   exc_numberoutofrange                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_numberoutofrange, -20028);
   cst_numberoutofrange             CONSTANT NUMBER := -20028;

   exc_integeronly                           EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_integeronly, -20029);
   cst_integeronly                  CONSTANT NUMBER := -20029;

   exc_localityundefinlanid                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_localityundefinlanid, -20030);
   cst_localityundefinlanid         CONSTANT NUMBER := -20030;

   exc_watercourseundefinlanid               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_watercourseundefinlanid, -20031);
   cst_watercourseundefinlanid      CONSTANT NUMBER := -20031;

   exc_protocanotbesave                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_protocanotbesave, -20032);
   cst_protocanotbesave             CONSTANT NUMBER := -20032;

   exc_warningvalidate                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_warningvalidate, -20033);
   cst_warningvalidate              CONSTANT NUMBER := -20033;

   exc_unabletosaveform                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_unabletosaveform, -20034);
   cst_unabletosaveform             CONSTANT NUMBER := -20034;

   exc_processdonewithouterror               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_processdonewithouterror, -20035);
   cst_processdonewithouterror      CONSTANT NUMBER := -20035;

   exc_protocolallreadyexist                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_protocolallreadyexist, -20036);
   cst_protocolallreadyexist        CONSTANT NUMBER := -20036;

   exc_protoheaderfieldnotmatch              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_protoheaderfieldnotmatch, -20037);
   cst_protoheaderfieldnotmatch     CONSTANT NUMBER := -20037;

   exc_excelobsdateignored                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_excelobsdateignored, -20038);
   cst_excelobsdateignored          CONSTANT NUMBER := -20038;

   exc_datatypeexcelinvalid                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_datatypeexcelinvalid, -20039);
   cst_datatypeexcelinvalid         CONSTANT NUMBER := -20039;


   exc_recouvrementoutofrange                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_recouvrementoutofrange, -20040);
   cst_recouvrementoutofrange       CONSTANT NUMBER := -20040;

   exc_unexpectederroritem                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_unexpectederroritem, -20041);
   cst_unexpectederroritem          CONSTANT NUMBER := -20041;

   exc_substratoutofrange                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_substratoutofrange, -20042);
   cst_substratoutofrange           CONSTANT NUMBER := -20042;

   exc_averagewidthoutofrange                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_averagewidthoutofrange, -20043);
   cst_averagewidthoutofrange       CONSTANT NUMBER := -20043;

   exc_strartprocess                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_strartprocess, -20044);
   cst_strartprocess                CONSTANT NUMBER := -20044;

   exc_endprocess                            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_endprocess, -20045);
   cst_endprocess                   CONSTANT NUMBER := -20045;

   exc_groundmappinginvalid                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_groundmappinginvalid, -20046);
   cst_groundmappinginvalid         CONSTANT NUMBER := -20046;


   exc_morevalueingroup                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_morevalueingroup, -20047);
   cst_morevalueingroup             CONSTANT NUMBER := -20047;

   exc_isnotnullgroup                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_isnotnullgroup, -20048);
   cst_isnotnullgroup               CONSTANT NUMBER := -20048;


   exc_invaliddatatype                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_invaliddatatype, -20049);
   cst_invaliddatatype              CONSTANT NUMBER := -20049;

   exc_laboratoryprotocolrequired            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_laboratoryprotocolrequired, -20050);
   cst_laboratoryprotocolrequired   CONSTANT NUMBER := -20050;

   exc_systdesignationambigous               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_systdesignationambigous, -20051);
   cst_systdesignationambigous      CONSTANT NUMBER := -20051;

   exc_duplicateheaderfield                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_duplicateheaderfield, -20052);
   cst_duplicateheaderfield         CONSTANT NUMBER := -20052;

   exc_requiredfieldmissing                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_requiredfieldmissing, -20053);
   cst_requiredfieldmissing         CONSTANT NUMBER := -20053;

   exc_requiredgrpfieldmissing               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_requiredgrpfieldmissing, -20054);
   cst_requiredgrpfieldmissing      CONSTANT NUMBER := -20054;

   exc_unknownheaderfield                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_unknownheaderfield, -20055);
   cst_unknownheaderfield           CONSTANT NUMBER := -20055;

   exc_massfieldrequired                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_massfieldrequired, -20056);
   cst_massfieldrequired            CONSTANT NUMBER := -20056;

   exc_excludereqfieldnotfilled              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_excludereqfieldnotfilled, -20057);
   cst_excludereqfieldnotfilled     CONSTANT NUMBER := -20057;

   exc_massgroupfieldrequired                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_massgroupfieldrequired, -20058);
   cst_massgroupfieldrequired       CONSTANT NUMBER := -20058;

   exc_samesamplehasmorevalue                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_samesamplehasmorevalue, -20059);
   cst_samesamplehasmorevalue       CONSTANT NUMBER := -20059;

   exc_displayrequiredfield                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_displayrequiredfield, -20060);
   cst_displayrequiredfield         CONSTANT NUMBER := -20060;

   exc_collectdateinvalide                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_collectdateinvalide, -20061);
   cst_collectdateinvalide          CONSTANT NUMBER := -20061;

   exc_systemprecrefinvalid                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_systemprecrefinvalid, -20062);
   cst_systemprecrefinvalid         CONSTANT NUMBER := -20062;

   exc_codeprecinvalid                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_codeprecinvalid, -20063);
   cst_codeprecinvalid              CONSTANT NUMBER := -20063;

   exc_massfielddatarequired                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_massfielddatarequired, -20064);
   cst_massfielddatarequired        CONSTANT NUMBER := -20064;

   exc_massfieldlinkrequired                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_massfieldlinkrequired, -20065);
   cst_massfieldlinkrequired        CONSTANT NUMBER := -20065;

   exc_massnumvalueinvalid                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_massnumvalueinvalid, -20066);
   cst_massnumvalueinvalid          CONSTANT NUMBER := -20066;

   exc_systentrynotfound                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_systentrynotfound, -20067);
   cst_systentrynotfound            CONSTANT NUMBER := -20067;

   exc_systentrynotmatchall                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_systentrynotmatchall, -20068);
   cst_systentrynotmatchall         CONSTANT NUMBER := -20068;

   exc_positivevaluerequired                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_positivevaluerequired, -20069);
   cst_positivevaluerequired        CONSTANT NUMBER := -20069;

   exc_midatindiceinvalid                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatindiceinvalid, -20070);
   cst_midatindiceinvalid           CONSTANT NUMBER := -20070;

   exc_midatabsoluteflagerror                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatabsoluteflagerror, -20071);
   cst_midatabsoluteflagerror       CONSTANT NUMBER := -20071;


   exc_midatuseexistingstation               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatuseexistingstation, -20072);
   cst_midatuseexistingstation      CONSTANT NUMBER := -20072;

   exc_midatstartloadingexcel                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatstartloadingexcel, -20073);
   cst_midatstartloadingexcel       CONSTANT NUMBER := -20073;

   exc_midatendloadingexcel                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatendloadingexcel, -20074);
   cst_midatendloadingexcel         CONSTANT NUMBER := -20074;

   exc_midatstartidentifymassfld             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatstartidentifymassfld, -20075);
   cst_midatstartidentifymassfld    CONSTANT NUMBER := -20075;

   exc_midatendidentifymassfld               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatendidentifymassfld, -20076);
   cst_midatendidentifymassfld      CONSTANT NUMBER := -20076;

   exc_unrecoverableerror                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_unrecoverableerror, -20077);
   cst_unrecoverableerror           CONSTANT NUMBER := -20077;

   exc_midatstartexceldataload               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatstartexceldataload, -20078);
   cst_midatstartexceldataload      CONSTANT NUMBER := -20078;

   exc_midatendexceldataload                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatendexceldataload, -20079);
   cst_midatendexceldataload        CONSTANT NUMBER := -20079;


   exc_midatstartcheckrequiredfld            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatstartcheckrequiredfld, -20080);
   cst_midatstartcheckrequiredfld   CONSTANT NUMBER := -20080;

   exc_midatendcheckrequiredfld              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatendcheckrequiredfld, -20081);
   cst_midatendcheckrequiredfld     CONSTANT NUMBER := -20081;


   exc_midatstartbuildheader                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatstartbuildheader, -20082);
   cst_midatstartbuildheader        CONSTANT NUMBER := -20082;


   exc_midatendbuildheader                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatendbuildheader, -20083);
   cst_midatendbuildheader          CONSTANT NUMBER := -20083;

   exc_midatstartvalidatedetail              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatstartvalidatedetail, -20084);
   cst_midatstartvalidatedetail     CONSTANT NUMBER := -20084;

   exc_midatendvalidatedetail                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatendvalidatedetail, -20085);
   cst_midatendvalidatedetail       CONSTANT NUMBER := -20085;

   exc_midatmassinfomapping                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatmassinfomapping, -20086);
   cst_midatmassinfomapping         CONSTANT NUMBER := -20086;


   exc_startmasscompleteheader               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_startmasscompleteheader, -20087);
   cst_startmasscompleteheader      CONSTANT NUMBER := -20087;

   exc_endmasscompleteheader                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_endmasscompleteheader, -20088);
   cst_endmasscompleteheader        CONSTANT NUMBER := -20088;

   exc_subformvaluenotmatch                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_subformvaluenotmatch, -20089);
   cst_subformvaluenotmatch         CONSTANT NUMBER := -20089;

   exc_subformvaluenotinlanid                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_subformvaluenotinlanid, -20090);
   cst_subformvaluenotinlanid       CONSTANT NUMBER := -20090;

   exc_autocoordinatedefined                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_autocoordinatedefined, -20091);
   cst_autocoordinatedefined        CONSTANT NUMBER := -20091;

   exc_validprocessallreadydone              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_validprocessallreadydone, -20092);
   cst_validprocessallreadydone     CONSTANT NUMBER := -20092;

   exc_stationnotmatchcoordinates            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_stationnotmatchcoordinates, -20093);
   cst_stationnotmatchcoordinates   CONSTANT NUMBER := -20093;

   exc_sameoidoutofdistance                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_sameoidoutofdistance, -20094);
   cst_sameoidoutofdistance         CONSTANT NUMBER := -20094;

   exc_saveallreadydone                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_saveallreadydone, -20095);
   cst_saveallreadydone             CONSTANT NUMBER := -20095;

   exc_fieldnotfilled                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_fieldnotfilled, -20096);
   cst_fieldnotfilled               CONSTANT NUMBER := -20096;

   exc_speciesvalueignored                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_speciesvalueignored, -20097);
   cst_speciesvalueignored          CONSTANT NUMBER := -20097;

   exc_parenthesisvalueremoved               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_parenthesisvalueremoved, -20098);
   cst_parenthesisvalueremoved      CONSTANT NUMBER := -20098;

   exc_startinvalidstationdepende            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_startinvalidstationdepende, -20099);
   cst_startinvalidstationdepende   CONSTANT NUMBER := -20099;

   exc_endinvalidstationdepende              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_endinvalidstationdepende, -20100);
   cst_endinvalidstationdepende     CONSTANT NUMBER := -20100;

   exc_massstatistics                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_massstatistics, -20101);
   cst_massstatistics               CONSTANT NUMBER := -20101;

   exc_massdataheaderallreadyexis            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_massdataheaderallreadyexis, -20102);
   cst_massdataheaderallreadyexis   CONSTANT NUMBER := -20102;

   exc_massmappingnotexist                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_massmappingnotexist, -20103);
   cst_massmappingnotexist          CONSTANT NUMBER := -20103;

   exc_startbuildimportstation               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_startbuildimportstation, -20104);
   cst_startbuildimportstation      CONSTANT NUMBER := -20104;

   exc_endbuildimportstation                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_endbuildimportstation, -20105);
   cst_endbuildimportstation        CONSTANT NUMBER := -20105;

   exc_readandvalidateheader                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_readandvalidateheader, -20106);
   cst_readandvalidateheader        CONSTANT NUMBER := -20106;


   exc_loaddata                              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_loaddata, -20107);
   cst_loaddata                     CONSTANT NUMBER := -20107;

   exc_checkrequiredfield                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_checkrequiredfield, -20108);
   cst_checkrequiredfield           CONSTANT NUMBER := -20108;

   exc_buildheader                           EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_buildheader, -20109);
   cst_buildheader                  CONSTANT NUMBER := -20109;

   exc_validateheader                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_validateheader, -20110);
   cst_validateheader               CONSTANT NUMBER := -20110;

   exc_validatedetail                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_validatedetail, -20111);
   cst_validatedetail               CONSTANT NUMBER := -20111;

   exc_buildandvalidatestation               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_buildandvalidatestation, -20112);
   cst_buildandvalidatestation      CONSTANT NUMBER := -20112;

   exc_loadingdone                           EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_loadingdone, -20113);
   cst_loadingdone                  CONSTANT NUMBER := -20113;

   exc_checkrequiredgrpfield                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_checkrequiredgrpfield, -20114);
   cst_checkrequiredgrpfield        CONSTANT NUMBER := -20114;

   exc_consolidateheader                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_consolidateheader, -20115);
   cst_consolidateheader            CONSTANT NUMBER := -20115;



   exc_mkithesaurusentrycheck                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkithesaurusentrycheck, -20116);
   cst_mkithesaurusentrycheck       CONSTANT NUMBER := -20116;

   exc_mkithesaurusentryfound                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkithesaurusentryfound, -20117);
   cst_mkithesaurusentryfound       CONSTANT NUMBER := -20117;

   exc_mkithesaurusentrynotfound             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkithesaurusentrynotfound, -20118);
   cst_mkithesaurusentrynotfound    CONSTANT NUMBER := -20118;

   exc_taxonibchnotfound                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxonibchnotfound, -20119);
   cst_taxonibchnotfound            CONSTANT NUMBER := -20119;

   exc_taxonibchchecked                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxonibchchecked, -20120);
   cst_taxonibchchecked             CONSTANT NUMBER := -20120;

   exc_taxonibchsettingmissing               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxonibchsettingmissing, -20121);
   cst_taxonibchsettingmissing      CONSTANT NUMBER := -20121;

   exc_taxonibchlaboused                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxonibchlaboused, -20122);
   cst_taxonibchlaboused            CONSTANT NUMBER := -20122;

   exc_unabletosavemass                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_unabletosavemass, -20123);
   cst_unabletosavemass             CONSTANT NUMBER := -20123;

   exc_ibchtaxaignored                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_ibchtaxaignored, -20124);
   cst_ibchtaxaignored              CONSTANT NUMBER := -20124;


   exc_mkiusedvalues                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiusedvalues, -20125);
   cst_mkiusedvalues                CONSTANT NUMBER := -20125;

   exc_mkiicannotbecomputed                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiicannotbecomputed, -20126);
   cst_mkiicannotbecomputed         CONSTANT NUMBER := -20126;

   exc_stadiumfieldmissing                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_stadiumfieldmissing, -20127);
   cst_stadiumfieldmissing          CONSTANT NUMBER := -20127;

   exc_stadiumunidentifieldwarnin            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_stadiumunidentifieldwarnin, -20128);
   cst_stadiumunidentifieldwarnin   CONSTANT NUMBER := -20128;

   exc_stadiumunidentifielderror             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_stadiumunidentifielderror, -20129);
   cst_stadiumunidentifielderror    CONSTANT NUMBER := -20129;

   exc_indicevaluemissmatch                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_indicevaluemissmatch, -20130);
   cst_indicevaluemissmatch         CONSTANT NUMBER := -20130;

   exc_midatwindowtampon                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatwindowtampon, -20131);
   cst_midatwindowtampon            CONSTANT NUMBER := -20131;

   exc_midatwindowouter                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatwindowouter, -20132);
   cst_midatwindowouter             CONSTANT NUMBER := -20132;

   exc_spearindexcannotbecomputed            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_spearindexcannotbecomputed, -20133);
   cst_spearindexcannotbecomputed   CONSTANT NUMBER := -20133;

   exc_displayindexcategory                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_displayindexcategory, -20134);
   cst_displayindexcategory         CONSTANT NUMBER := -20134;

   exc_taxanotusedforcomputespear            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxanotusedforcomputespear, -20135);
   cst_taxanotusedforcomputespear   CONSTANT NUMBER := -20135;



   exc_taxonhasnotspearindice                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxonhasnotspearindice, -20136);
   cst_taxonhasnotspearindice       CONSTANT NUMBER := -20136;

   exc_mkiasselushirudinaeturbifi            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiasselushirudinaeturbifi, -20137);
   cst_mkiasselushirudinaeturbifi   CONSTANT NUMBER := -20137;

   exc_mkigammarushydropsyche                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkigammarushydropsyche, -20138);
   cst_mkigammarushydropsyche       CONSTANT NUMBER := -20138;

   exc_mkiephemeropterawithoutbae            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiephemeropterawithoutbae, -20139);
   cst_mkiephemeropterawithoutbae   CONSTANT NUMBER := -20139;

   exc_mkiplecopteratrichoptera              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiplecopteratrichoptera, -20140);
   cst_mkiplecopteratrichoptera     CONSTANT NUMBER := -20140;

   exc_mkiplecoptera                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiplecoptera, -20141);
   cst_mkiplecoptera                CONSTANT NUMBER := -20141;

   exc_mkiresume                             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiresume, -20142);
   cst_mkiresume                    CONSTANT NUMBER := -20142;

   exc_mkiusecase                            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiusecase, -20143);
   cst_mkiusecase                   CONSTANT NUMBER := -20143;


   exc_makroindexibchmapping                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_makroindexibchmapping, -20144);
   cst_makroindexibchmapping        CONSTANT NUMBER := -20144;

   exc_computedmassindice                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_computedmassindice, -20145);
   cst_computedmassindice           CONSTANT NUMBER := -20145;

   exc_displayprocessheaderinfo              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_displayprocessheaderinfo, -20146);
   cst_displayprocessheaderinfo     CONSTANT NUMBER := -20146;

   exc_mkihasonlyinsecta                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkihasonlyinsecta, -20147);
   cst_mkihasonlyinsecta            CONSTANT NUMBER := -20147;

   exc_elevationnotmatchprovided             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_elevationnotmatchprovided, -20148);
   cst_elevationnotmatchprovided    CONSTANT NUMBER := -20148;


   exc_autocompleteelevation                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_autocompleteelevation, -20149);
   cst_autocompleteelevation        CONSTANT NUMBER := -20149;

   exc_elevationformnotmatchprovi            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_elevationformnotmatchprovi, -20150);
   cst_elevationformnotmatchprovi   CONSTANT NUMBER := -20150;


   exc_midatnotaxonindicator                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_midatnotaxonindicator, -20151);
   cst_midatnotaxonindicator        CONSTANT NUMBER := -20151;

   exc_protocolwillbereplace                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_protocolwillbereplace, -20152);
   cst_protocolwillbereplace        CONSTANT NUMBER := -20152;

   exc_computeindice                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_computeindice, -20153);
   cst_computeindice                CONSTANT NUMBER := -20153;
   exc_strengtheningleftbankinco             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_strengtheningleftbankinco, -20154);
   cst_strengtheningleftbankinco    CONSTANT NUMBER := -20154;

   exc_strengtheningrightbankinco            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_strengtheningrightbankinco, -20155);
   cst_strengtheningrightbankinco   CONSTANT NUMBER := -20155;


   exc_permleftothernulreqprec               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_permleftothernulreqprec, -20156);
   cst_permleftothernulreqprec      CONSTANT NUMBER := -20156;


   exc_permrightothernulreqprec              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_permrightothernulreqprec, -20157);
   cst_permrightothernulreqprec     CONSTANT NUMBER := -20157;

   exc_invalidcombination                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_invalidcombination, -20158);
   cst_invalidcombination           CONSTANT NUMBER := -20158;

   exc_mkiunabletocompute                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiunabletocompute, -20159);
   cst_mkiunabletocompute           CONSTANT NUMBER := -20159;


   exc_taxonibchcolumnexist                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxonibchcolumnexist, -20160);
   cst_taxonibchcolumnexist         CONSTANT NUMBER := -20160;

   exc_taxonibchcolumnnotexist               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxonibchcolumnnotexist, -20161);
   cst_taxonibchcolumnnotexist      CONSTANT NUMBER := -20161;

   exc_computeoneindice                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_computeoneindice, -20162);
   cst_computeoneindice             CONSTANT NUMBER := -20162;


   exc_matamenagementnotauth                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_matamenagementnotauth, -20163);
   cst_matamenagementnotauth        CONSTANT NUMBER := -20163;


   exc_matamenagementreq                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_matamenagementreq, -20164);
   cst_matamenagementreq            CONSTANT NUMBER := -20164;

   exc_noreqcause                            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_noreqcause, -20165);
   cst_noreqcause                   CONSTANT NUMBER := -20165;

   exc_missingcause                          EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_missingcause, -20166);
   cst_missingcause                 CONSTANT NUMBER := -20166;

   exc_indexcalculationnotrestric            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_indexcalculationnotrestric, -20167);
   cst_indexcalculationnotrestric   CONSTANT NUMBER := -20167;

   exc_indexcalculationrectricted            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_indexcalculationrectricted, -20168);
   cst_indexcalculationrectricted   CONSTANT NUMBER := -20168;

   exc_noprivilegetoinsertstation            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_noprivilegetoinsertstation, -20169);
   cst_noprivilegetoinsertstation   CONSTANT NUMBER := -20169;

   exc_cantonlistright                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_cantonlistright, -20170);
   cst_cantonlistright              CONSTANT NUMBER := -20170;

   exc_mkirecordsinsectaentry                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkirecordsinsectaentry, -20171);
   cst_mkirecordsinsectaentry       CONSTANT NUMBER := -20171;

   exc_mkirecordsnoinsectaentry              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkirecordsnoinsectaentry, -20172);
   cst_mkirecordsnoinsectaentry     CONSTANT NUMBER := -20172;


   exc_mkientryratioexclude                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkientryratioexclude, -20173);
   cst_mkientryratioexclude         CONSTANT NUMBER := -20173;

   exc_mkientryrationotfound                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkientryrationotfound, -20174);
   cst_mkientryrationotfound        CONSTANT NUMBER := -20174;

   exc_mkinormalizedvalue                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkinormalizedvalue, -20175);
   cst_mkinormalizedvalue           CONSTANT NUMBER := -20175;

   exc_indicevaluematch                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_indicevaluematch, -20176);
   cst_indicevaluematch             CONSTANT NUMBER := -20176;

   exc_mkidisplaydetail                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkidisplaydetail, -20177);
   cst_mkidisplaydetail             CONSTANT NUMBER := -20177;

   exc_mkiunitdetail                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiunitdetail, -20178);
   cst_mkiunitdetail                CONSTANT NUMBER := -20178;

   exc_mkiunitdetailspecies                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiunitdetailspecies, -20179);
   cst_mkiunitdetailspecies         CONSTANT NUMBER := -20179;

   exc_mkiunitdetailgenus                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiunitdetailgenus, -20180);
   cst_mkiunitdetailgenus           CONSTANT NUMBER := -20180;

   exc_mkiunitdetailfamily                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiunitdetailfamily, -20181);
   cst_mkiunitdetailfamily          CONSTANT NUMBER := -20181;

   exc_mkiunitdetailtaxonsup                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiunitdetailtaxonsup, -20182);
   cst_mkiunitdetailtaxonsup        CONSTANT NUMBER := -20182;

   exc_mkispinferedby                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkispinferedby, -20183);
   cst_mkispinferedby               CONSTANT NUMBER := -20183;

   exc_mkitrichounable2detscabbar            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkitrichounable2detscabbar, -20184);
   cst_mkitrichounable2detscabbar   CONSTANT NUMBER := -20184;

   exc_mkifamillyscabbarnotdefine            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkifamillyscabbarnotdefine, -20185);
   cst_mkifamillyscabbarnotdefine   CONSTANT NUMBER := -20185;

   exc_mkigroupinhierarcyinsecta             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkigroupinhierarcyinsecta, -20186);
   cst_mkigroupinhierarcyinsecta    CONSTANT NUMBER := -20186;

   exc_mkisubtotalinsecta                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkisubtotalinsecta, -20187);
   cst_mkisubtotalinsecta           CONSTANT NUMBER := -20187;

   exc_mkifreq1useclass                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkifreq1useclass, -20188);
   cst_mkifreq1useclass             CONSTANT NUMBER := -20188;

   exc_mkiclassoutofrange                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiclassoutofrange, -20189);
   cst_mkiclassoutofrange           CONSTANT NUMBER := -20189;

   exc_mkiincompatibilityindex               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkiincompatibilityindex, -20190);
   cst_mkiincompatibilityindex      CONSTANT NUMBER := -20190;

   exc_mkitrichopwhitoutscabbard             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkitrichopwhitoutscabbard, -20191);
   cst_mkitrichopwhitoutscabbard    CONSTANT NUMBER := -20191;


   exc_mkigrouphierachynoinsecta             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkigrouphierachynoinsecta, -20192);
   cst_mkigrouphierachynoinsecta    CONSTANT NUMBER := -20192;

   exc_mkitricopteracount                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkitricopteracount, -20193);
   cst_mkitricopteracount           CONSTANT NUMBER := -20193;

   exc_mkitaxonignored                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mkitaxonignored, -20194);
   cst_mkitaxonignored              CONSTANT NUMBER := -20194;

   exc_massendresume                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_massendresume, -20195);
   cst_massendresume                CONSTANT NUMBER := -20195;

   exc_datalanguagemissmatch                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_datalanguagemissmatch, -20196);
   cst_datalanguagemissmatch        CONSTANT NUMBER := -20196;

   exc_massheaderinvalidated                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_massheaderinvalidated, -20197);
   cst_massheaderinvalidated        CONSTANT NUMBER := -20197;

   exc_infovalidatemassdetail                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infovalidatemassdetail, -20198);
   cst_infovalidatemassdetail       CONSTANT NUMBER := -20198;

   exc_infovalidatemassdetailend             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infovalidatemassdetailend, -20199);
   cst_infovalidatemassdetailend    CONSTANT NUMBER := -20199;

   exc_startcheckuniqbycoord                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_startcheckuniqbycoord, -20200);
   cst_startcheckuniqbycoord        CONSTANT NUMBER := -20200;

   exc_endcheckuniqbycoord                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_endcheckuniqbycoord, -20201);
   cst_endcheckuniqbycoord          CONSTANT NUMBER := -20201;

   exc_endcheckuniqbycoorderror              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_endcheckuniqbycoorderror, -20202);
   cst_endcheckuniqbycoorderror     CONSTANT NUMBER := -20202;

   exc_resumevalidheader                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_resumevalidheader, -20203);
   cst_resumevalidheader            CONSTANT NUMBER := -20203;

   exc_resumeinvalidheader                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_resumeinvalidheader, -20204);
   cst_resumeinvalidheader          CONSTANT NUMBER := -20204;

   exc_indexuncalculated                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_indexuncalculated, -20205);
   cst_indexuncalculated            CONSTANT NUMBER := -20205;

   exc_taxondefinedinprotocollabo            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxondefinedinprotocollabo, -20206);
   cst_taxondefinedinprotocollabo   CONSTANT NUMBER := -20206;

   exc_massendresumenotok                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_massendresumenotok, -20207);
   cst_massendresumenotok           CONSTANT NUMBER := -20207;

   exc_taxonlevelmissmatch                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxonlevelmissmatch, -20208);
   cst_taxonlevelmissmatch          CONSTANT NUMBER := -20208;

   exc_moreversion                           EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_moreversion, -20209);
   cst_moreversion                  CONSTANT NUMBER := -20209;

   exc_isnotnullgroupwarning                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_isnotnullgroupwarning, -20210);
   cst_isnotnullgroupwarning        CONSTANT NUMBER := -20210;

   exc_leftpermrenforunset                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_leftpermrenforunset, -20211);
   cst_leftpermrenforunset          CONSTANT NUMBER := -20211;

   exc_rightpermrenforunset                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_rightpermrenforunset, -20212);
   cst_rightpermrenforunset         CONSTANT NUMBER := -20212;

   exc_causeunsetted                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_causeunsetted, -20213);
   cst_causeunsetted                CONSTANT NUMBER := -20213;

   exc_remarkmissing                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_remarkmissing, -20214);
   cst_remarkmissing                CONSTANT NUMBER := -20214;

   exc_remarkcheckboxmissing                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_remarkcheckboxmissing, -20215);
   cst_remarkcheckboxmissing        CONSTANT NUMBER := -20215;

   exc_checkboxsetandtextnotset              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_checkboxsetandtextnotset, -20216);
   cst_checkboxsetandtextnotset     CONSTANT NUMBER := -20216;

   exc_checkboxnotsetandtextset              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_checkboxnotsetandtextset, -20217);
   cst_checkboxnotsetandtextset     CONSTANT NUMBER := -20217;

   exc_morevalueingroupwarning               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_morevalueingroupwarning, -20218);
   cst_morevalueingroupwarning      CONSTANT NUMBER := -20218;

   exc_amennotsetandmatset                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_amennotsetandmatset, -20219);
   cst_amennotsetandmatset          CONSTANT NUMBER := -20219;

   exc_onlyonerigthmatamenauth               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_onlyonerigthmatamenauth, -20220);
   cst_onlyonerigthmatamenauth      CONSTANT NUMBER := -20220;

   exc_onlyoneleftmatamenauth                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_onlyoneleftmatamenauth, -20221);
   cst_onlyoneleftmatamenauth       CONSTANT NUMBER := -20221;

   exc_unabletopoelevationquery              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_unabletopoelevationquery, -20222);
   cst_unabletopoelevationquery     CONSTANT NUMBER := -20222;

   exc_stationelevationinvalid               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_stationelevationinvalid, -20223);
   cst_stationelevationinvalid      CONSTANT NUMBER := -20223;


   exc_unableidentifywtcbyswissto            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_unableidentifywtcbyswissto, -20224);
   cst_unableidentifywtcbyswissto   CONSTANT NUMBER := -20224;

   exc_gewissnrmissing                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_gewissnrmissing, -20225);
   cst_gewissnrmissing              CONSTANT NUMBER := -20225;

   exc_wtcoutofradius                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_wtcoutofradius, -20226);
   cst_wtcoutofradius               CONSTANT NUMBER := -20226;

   exc_autocompletegewissnr                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_autocompletegewissnr, -20227);
   cst_autocompletegewissnr         CONSTANT NUMBER := -20227;

   exc_buildstationinfo                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_buildstationinfo, -20228);
   cst_buildstationinfo             CONSTANT NUMBER := -20228;

   exc_improvedatastation                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_improvedatastation, -20229);
   cst_improvedatastation           CONSTANT NUMBER := -20229;

   exc_samestationhasmorelocality            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_samestationhasmorelocality, -20230);
   cst_samestationhasmorelocality   CONSTANT NUMBER := -20230;

   exc_samestationhasmorewtc                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_samestationhasmorewtc, -20231);
   cst_samestationhasmorewtc        CONSTANT NUMBER := -20231;

   exc_toponamematch                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_toponamematch, -20232);
   cst_toponamematch                CONSTANT NUMBER := -20232;

   exc_elevservicetopounreachable            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_elevservicetopounreachable, -20233);
   cst_elevservicetopounreachable   CONSTANT NUMBER := -20233;

   exc_closestbetweenstationoid              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_closestbetweenstationoid, -20234);
   cst_closestbetweenstationoid     CONSTANT NUMBER := -20234;

   exc_startcheckstationconsisten            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_startcheckstationconsisten, -20235);
   cst_startcheckstationconsisten   CONSTANT NUMBER := -20235;

   exc_endcheckstationconsistency            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_endcheckstationconsistency, -20236);
   cst_endcheckstationconsistency   CONSTANT NUMBER := -20236;

   exc_stationmatching                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_stationmatching, -20237);
   cst_stationmatching              CONSTANT NUMBER := -20237;


   exc_infostationaggregate                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infostationaggregate, -20238);
   cst_infostationaggregate         CONSTANT NUMBER := -20238;

   exc_infostationnearoidnotdsame            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infostationnearoidnotdsame, -20239);
   cst_infostationnearoidnotdsame   CONSTANT NUMBER := -20239;

   exc_infostationsameoidcoorderr            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infostationsameoidcoorderr, -20240);
   cst_infostationsameoidcoorderr   CONSTANT NUMBER := -20240;

   exc_infostationnearnotsame                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infostationnearnotsame, -20241);
   cst_infostationnearnotsame       CONSTANT NUMBER := -20241;

   exc_infostationfusion                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infostationfusion, -20242);
   cst_infostationfusion            CONSTANT NUMBER := -20242;

   exc_infostationnearoidnotoid              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infostationnearoidnotoid, -20243);
   cst_infostationnearoidnotoid     CONSTANT NUMBER := -20243;

   exc_infostationoidwithsavedoid            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infostationoidwithsavedoid, -20244);
   cst_infostationoidwithsavedoid   CONSTANT NUMBER := -20244;

   exc_stationsameoidnotsamecoord            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_stationsameoidnotsamecoord, -20245);
   cst_stationsameoidnotsamecoord   CONSTANT NUMBER := -20245;

   exc_headerinvalidatedbystation            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_headerinvalidatedbystation, -20246);
   cst_headerinvalidatedbystation   CONSTANT NUMBER := -20246;

   exc_matamenfondmussbefilled               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_matamenfondmussbefilled, -20247);
   cst_matamenfondmussbefilled      CONSTANT NUMBER := -20247;

   exc_dechetaucundisableremark              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_dechetaucundisableremark, -20248);
   cst_dechetaucundisableremark     CONSTANT NUMBER := -20248;

   exc_systematiquestat                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_systematiquestat, -20249);
   cst_systematiquestat             CONSTANT NUMBER := -20249;

   exc_nomanyvaluesauthorized                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_nomanyvaluesauthorized, -20250);
   cst_nomanyvaluesauthorized       CONSTANT NUMBER := -20250;

   exc_nomanyvaluesnormally                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_nomanyvaluesnormally, -20251);
   cst_nomanyvaluesnormally         CONSTANT NUMBER := -20251;

   exc_atleastvaluerequired                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_atleastvaluerequired, -20252);
   cst_atleastvaluerequired         CONSTANT NUMBER := -20252;

   exc_atleastvalueexpected                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_atleastvalueexpected, -20253);
   cst_atleastvalueexpected         CONSTANT NUMBER := -20253;

   exc_neitherconflict                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_neitherconflict, -20254);
   cst_neitherconflict              CONSTANT NUMBER := -20254;

   exc_datatypeerror                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_datatypeerror, -20255);
   cst_datatypeerror                CONSTANT NUMBER := -20255;


   exc_fieldheaderrequired                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_fieldheaderrequired, -20256);
   cst_fieldheaderrequired          CONSTANT NUMBER := -20256;


   exc_fieldheadertypeerror                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_fieldheadertypeerror, -20257);
   cst_fieldheadertypeerror         CONSTANT NUMBER := -20257;

   exc_listoiddistance                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_listoiddistance, -20258);
   cst_listoiddistance              CONSTANT NUMBER := -20258;

   exc_fielddetailrequired                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_fielddetailrequired, -20259);
   cst_fielddetailrequired          CONSTANT NUMBER := -20259;

   exc_unabletofindlistofvaluestr            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_unabletofindlistofvaluestr, -20260);
   cst_unabletofindlistofvaluestr   CONSTANT NUMBER := -20260;

   exc_unableidenttaxon                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_unableidenttaxon, -20261);
   cst_unableidenttaxon             CONSTANT NUMBER := -20261;

   exc_ambigoustaxon                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_ambigoustaxon, -20262);
   cst_ambigoustaxon                CONSTANT NUMBER := -20262;


   exc_taxonidentified                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxonidentified, -20263);
   cst_taxonidentified              CONSTANT NUMBER := -20263;

   exc_field1fillreqiffield2fill             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_field1fillreqiffield2fill, -20264);
   cst_field1fillreqiffield2fill    CONSTANT NUMBER := -20264;

   exc_parentprottypenotfound                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_parentprottypenotfound, -20265);
   cst_parentprottypenotfound       CONSTANT NUMBER := -20265;

   exc_insidandoiddoesnotexist               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_insidandoiddoesnotexist, -20266);
   cst_insidandoiddoesnotexist      CONSTANT NUMBER := -20266;

   exc_parentprotidentified                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_parentprotidentified, -20267);
   cst_parentprotidentified         CONSTANT NUMBER := -20267;

   exc_linkfieldandoidfieldnotsam            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_linkfieldandoidfieldnotsam, -20268);
   cst_linkfieldandoidfieldnotsam   CONSTANT NUMBER := -20268;

   exc_parentprotbyinsnotfound               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_parentprotbyinsnotfound, -20269);
   cst_parentprotbyinsnotfound      CONSTANT NUMBER := -20269;

   exc_faunafieldrequired                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_faunafieldrequired, -20270);
   cst_faunafieldrequired           CONSTANT NUMBER := -20270;

   exc_faunadatatypefieldinvalid             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_faunadatatypefieldinvalid, -20271);
   cst_faunadatatypefieldinvalid    CONSTANT NUMBER := -20271;

   exc_unablefaunafindlstofvalue             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_unablefaunafindlstofvalue, -20272);
   cst_unablefaunafindlstofvalue    CONSTANT NUMBER := -20272;

   exc_faunataxonnotfound                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_faunataxonnotfound, -20273);
   cst_faunataxonnotfound           CONSTANT NUMBER := -20273;

   exc_faunataxonambigous                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_faunataxonambigous, -20274);
   cst_faunataxonambigous           CONSTANT NUMBER := -20274;

   exc_infoloadedfaunaformerror              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infoloadedfaunaformerror, -20275);
   cst_infoloadedfaunaformerror     CONSTANT NUMBER := -20275;

   exc_taxaentrymissmatch                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxaentrymissmatch, -20276);
   cst_taxaentrymissmatch           CONSTANT NUMBER := -20276;

   exc_infostructparent                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infostructparent, -20277);
   cst_infostructparent             CONSTANT NUMBER := -20277;

   exc_stationproximitylist                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_stationproximitylist, -20278);
   cst_stationproximitylist         CONSTANT NUMBER := -20278;

   exc_stationproximitydetail                EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_stationproximitydetail, -20279);
   cst_stationproximitydetail       CONSTANT NUMBER := -20279;

   exc_mdsstationproximityfound              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_mdsstationproximityfound, -20280);
   cst_mdsstationproximityfound     CONSTANT NUMBER := -20280;

   exc_coordoutofswissboundary               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_coordoutofswissboundary, -20281);
   cst_coordoutofswissboundary      CONSTANT NUMBER := -20281;

   exc_infocanton                            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infocanton, -20282);
   cst_infocanton                   CONSTANT NUMBER := -20282;

   exc_remarkcodenotfound                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_remarkcodenotfound, -20283);
   cst_remarkcodenotfound           CONSTANT NUMBER := -20283;

   exc_oidlinknotautolink                    EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_oidlinknotautolink, -20284);
   cst_oidlinknotautolink           CONSTANT NUMBER := -20284;

   exc_oidlinknotfound                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_oidlinknotfound, -20285);
   cst_oidlinknotfound              CONSTANT NUMBER := -20285;

   exc_oidlinkoutoftolerance                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_oidlinkoutoftolerance, -20286);
   cst_oidlinkoutoftolerance        CONSTANT NUMBER := -20286;

   exc_oidlinkallreadylinked                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_oidlinkallreadylinked, -20287);
   cst_oidlinkallreadylinked        CONSTANT NUMBER := -20287;

   exc_projectnotfound                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_projectnotfound, -20288);
   cst_projectnotfound              CONSTANT NUMBER := -20288;

   exc_oidlinkismaster                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_oidlinkismaster, -20289);
   cst_oidlinkismaster              CONSTANT NUMBER := -20289;

   exc_oidlinkhasanotherlink                 EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_oidlinkhasanotherlink, -20290);
   cst_oidlinkhasanotherlink        CONSTANT NUMBER := -20290;

   exc_oidmustbedefinewithoidlink            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_oidmustbedefinewithoidlink, -20291);
   cst_oidmustbedefinewithoidlink   CONSTANT NUMBER := -20291;

   exc_oidlinkrefmoreoid                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_oidlinkrefmoreoid, -20292);
   cst_oidlinkrefmoreoid            CONSTANT NUMBER := -20292;

   exc_infomorelink                          EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infomorelink, -20293);
   cst_infomorelink                 CONSTANT NUMBER := -20293;

   exc_indexcalculationnone                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_indexcalculationnone, -20294);
   cst_indexcalculationnone         CONSTANT NUMBER := -20294;

   exc_norightforloadcolumn                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_norightforloadcolumn, -20295);
   cst_norightforloadcolumn         CONSTANT NUMBER := -20295;

   exc_sampleassociatedtocanton              EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_sampleassociatedtocanton, -20296);
   cst_sampleassociatedtocanton     CONSTANT NUMBER := -20296;

   exc_cantonoutoftoleranceradius            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_cantonoutoftoleranceradius, -20297);
   cst_cantonoutoftoleranceradius   CONSTANT NUMBER := -20297;

   exc_projetnamedefinedotherins             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_projetnamedefinedotherins, -20298);
   cst_projetnamedefinedotherins    CONSTANT NUMBER := -20298;

   exc_sourcetarie                           EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_sourcetarie, -20299);
   cst_sourcetarie                  CONSTANT NUMBER := -20299;

   exc_sourcedetruite                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_sourcedetruite, -20300);
   cst_sourcedetruite               CONSTANT NUMBER := -20300;

   exc_outofswitzerland                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_outofswitzerland, -20301);
   cst_outofswitzerland             CONSTANT NUMBER := -20301;

   exc_outofgroupright                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_outofgroupright, -20302);
   cst_outofgroupright              CONSTANT NUMBER := -20302;

   exc_compaccessinfo                        EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_compaccessinfo, -20303);
   cst_compaccessinfo               CONSTANT NUMBER := -20303;

   exc_infoibchdata                          EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_infoibchdata, -20304);
   cst_infoibchdata                 CONSTANT NUMBER := -20304;

   exc_requiredcolvalue                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_requiredcolvalue, -20305);
   cst_requiredcolvalue             CONSTANT NUMBER := -20305;


   exc_systematiqueerror                     EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_systematiqueerror, -20306);
   cst_systematiqueerror            CONSTANT NUMBER := -20306;

   exc_taxoninfo                             EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxoninfo, -20307);
   cst_taxoninfo                    CONSTANT NUMBER := -20307;

   exc_taxonnotfound                         EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxonnotfound, -20308);
   cst_taxonnotfound                CONSTANT NUMBER := -20308;

   exc_taxonnotinhierarchy                   EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_taxonnotinhierarchy, -20309);
   cst_taxonnotinhierarchy          CONSTANT NUMBER := -20309;

   exc_valtaxonibchrequired                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_valtaxonibchrequired, -20310);
   cst_valtaxonibchrequired         CONSTANT NUMBER := -20310;

   exc_valtaxonibchnotfound                  EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_valtaxonibchnotfound, -20311);
   cst_valtaxonibchnotfound         CONSTANT NUMBER := -20311;


   exc_valtaxonibchnotinhierarchy            EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_valtaxonibchnotinhierarchy, -20312);
   cst_valtaxonibchnotinhierarchy   CONSTANT NUMBER := -20312;

   exc_valtaxonibchinhierarchy               EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_valtaxonibchinhierarchy, -20313);
   cst_valtaxonibchinhierarchy      CONSTANT NUMBER := -20313;

   exc_unexpectederror                       EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_unexpectederror, -20997);
   cst_unexpectederror              CONSTANT NUMBER := -20997;



   exc_msguntrapped                          EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_msguntrapped, -20998);
   cst_msguntrapped                 CONSTANT NUMBER := -20998;

   exc_undefinedmessage                      EXCEPTION;
   PRAGMA EXCEPTION_INIT (exc_undefinedmessage, -20999);
   cst_undefinedmessage             CONSTANT NUMBER := -20999;
END pkg_exception;
/

