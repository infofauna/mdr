create PACKAGE            pkg_admin_group
AS
   /******************************************************************************
      NAME:       PKG_ADMIN_GROUP
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
        1.0        24.02.2015   burrif       1. Created this package.
        1.1        31.07.2018   burrif       2. intégration ARMA
   ******************************************************************************/


   /*
  SELECT ' cst_admin_group_'||cvl_code||' CONSTANT admin_group.agr_name%type:='''||cvl_code||''';'
    FROM codevalue
         INNER JOIN codereference ON crf_id = cvl_crf_id
         INNER JOIN codedesignation ON cdn_cvl_id = cvl_id
   WHERE crf_code = 'CANTON' AND cdn_lan_id=1;
   */
   TYPE t_listgroup IS TABLE OF admin_group.agr_name%TYPE;

   cst_admin_group_zg       CONSTANT admin_group.agr_name%TYPE := 'ZG';
   cst_admin_group_fr       CONSTANT admin_group.agr_name%TYPE := 'FR';
   cst_admin_group_so       CONSTANT admin_group.agr_name%TYPE := 'SO';
   cst_admin_group_bs       CONSTANT admin_group.agr_name%TYPE := 'BS';
   cst_admin_group_bl       CONSTANT admin_group.agr_name%TYPE := 'BL';
   cst_admin_group_sh       CONSTANT admin_group.agr_name%TYPE := 'SH';
   cst_admin_group_ai       CONSTANT admin_group.agr_name%TYPE := 'AI';
   cst_admin_group_ar       CONSTANT admin_group.agr_name%TYPE := 'AR';
   cst_admin_group_sg       CONSTANT admin_group.agr_name%TYPE := 'SG';
   cst_admin_group_gr       CONSTANT admin_group.agr_name%TYPE := 'GR';
   cst_admin_group_ag       CONSTANT admin_group.agr_name%TYPE := 'AG';
   cst_admin_group_tg       CONSTANT admin_group.agr_name%TYPE := 'TG';
   cst_admin_group_ti       CONSTANT admin_group.agr_name%TYPE := 'TI';
   cst_admin_group_vd       CONSTANT admin_group.agr_name%TYPE := 'VD';
   cst_admin_group_vs       CONSTANT admin_group.agr_name%TYPE := 'VS';
   cst_admin_group_ne       CONSTANT admin_group.agr_name%TYPE := 'NE';
   cst_admin_group_ge       CONSTANT admin_group.agr_name%TYPE := 'GE';
   cst_admin_group_ju       CONSTANT admin_group.agr_name%TYPE := 'JU';
   cst_admin_group_zh       CONSTANT admin_group.agr_name%TYPE := 'ZH';
   cst_admin_group_be       CONSTANT admin_group.agr_name%TYPE := 'BE';
   cst_admin_group_lu       CONSTANT admin_group.agr_name%TYPE := 'LU';
   cst_admin_group_ur       CONSTANT admin_group.agr_name%TYPE := 'UR';
   cst_admin_group_sz       CONSTANT admin_group.agr_name%TYPE := 'SZ';
   cst_admin_group_ow       CONSTANT admin_group.agr_name%TYPE := 'OW';
   cst_admin_group_nw       CONSTANT admin_group.agr_name%TYPE := 'NW';
   cst_admin_group_gl       CONSTANT admin_group.agr_name%TYPE := 'GL';
   cst_admin_group_public   CONSTANT admin_group.agr_name%TYPE := 'PUBLIC';


   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecord (p_agr_id IN admin_group.agr_id%TYPE)
      RETURN admin_group%ROWTYPE;


   FUNCTION f_getrecordbyname (p_agr_name IN admin_group.agr_name%TYPE)
      RETURN admin_group%ROWTYPE;

   PROCEDURE p_insert (
      p_name          IN     admin_group.agr_name%TYPE,
      p_description   IN     admin_group.agr_description%TYPE,
      p_apl_id        IN     admin_group.agr_apl_id%TYPE,
      p_id               OUT admin_group.agr_id%TYPE);

   FUNCTION f_returnlistgroup (p_usr_id IN admin_user_group.agp_usr_id%TYPE)
      RETURN t_listgroup;

   FUNCTION f_returnalllistgroup (p_publicinclude IN BOOLEAN)
      RETURN t_listgroup;
END pkg_admin_group;
/

