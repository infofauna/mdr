create PACKAGE            pkg_migr_admin_user_role_group
AS
   /******************************************************************************
      NAME:       PKG_MIGR_ADMIN_USER_ROLE_GROUP
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.07.2018      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;


   PROCEDURE p_updateapplicationrole; -- A executer en premier

   PROCEDURE p_main;    -- Permet de construire la table ADMIN_USER_ROLE_GROUP
END pkg_migr_admin_user_role_group;
/

