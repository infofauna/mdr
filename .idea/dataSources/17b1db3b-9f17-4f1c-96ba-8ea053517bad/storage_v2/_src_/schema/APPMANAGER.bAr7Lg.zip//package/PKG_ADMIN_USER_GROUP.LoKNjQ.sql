create PACKAGE            pkg_admin_user_group
AS
   /******************************************************************************
      NAME:       pkg_admin_user_group
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
        1.0        24.02.2015      burrif       1. Created this package.
        1.1        31.07.2018      burrif       2. Ajout des fonctionalité de simplification (liste de groupe)
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_buildlistgroup (p_usr_id IN admin_user_group.agp_usr_id%TYPE)
      RETURN pkg_admin_group.t_listgroup;

   FUNCTION f_getrecord (p_agp_id IN admin_user_group.agp_id%TYPE)
      RETURN admin_user_group%ROWTYPE;

   FUNCTION f_getrecordbyname (p_agr_name IN admin_group.agr_name%TYPE)
      RETURN admin_group%ROWTYPE;

   PROCEDURE p_insert (p_usr_id   IN     admin_user_group.agp_usr_id%TYPE,
                       p_agr_id   IN     admin_user_group.agp_agr_id%TYPE,
                       p_id          OUT admin_user_group.agp_id%TYPE);
END pkg_admin_user_group;
/

