create PACKAGE            pkg_admin_user
AS
   /******************************************************************************
      NAME:       PKG_ADMIN_USER
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.07.2013      burrif       1. Created this package.
   ******************************************************************************/
   FUNCTION f_getversion
      RETURN VARCHAR2;


   PROCEDURE p_insert (
      p_lan_id             IN     admin_user.usr_lan_id%TYPE,
      p_per_id             IN     admin_user.usr_per_id%TYPE,
      p_pin_id             IN     admin_user.usr_pin_id%TYPE,
      p_user_login         IN     admin_user.usr_user_login%TYPE,
      p_is_ldap_login      IN     admin_user.usr_is_ldap_login%TYPE,
      p_password           IN     admin_user.usr_password%TYPE,
      p_ipaddress          IN     admin_user.usr_ipaddress%TYPE,
      p_ssocounter         IN     admin_user.usr_ssocounter%TYPE,
      p_token              IN     admin_user.usr_token%TYPE,
      p_token_timestamp    IN     admin_user.usr_token_timestamp%TYPE,
      p_token_expiration   IN     admin_user.usr_token_expiration%TYPE,
      p_designation        IN     admin_user.usr_designation%TYPE,
      p_id                    OUT admin_user.usr_id%TYPE);

   FUNCTION f_getrecordbyusername (
      p_usr_user_login   IN admin_user.usr_user_login%TYPE)
      RETURN admin_user%ROWTYPE;

   FUNCTION f_getrecord (p_usr_id IN admin_user.usr_id%TYPE)
      RETURN admin_user%ROWTYPE;

   PROCEDURE p_delete (p_usr_id IN admin_user.usr_id%TYPE);

   PROCEDURE p_checklogin;

   FUNCTION f_cancelemail (p_usr_id   IN admin_user.usr_id%TYPE,
                           p_email    IN admin_user.usr_user_login%TYPE)
      RETURN admin_user.usr_user_login%TYPE;

   PROCEDURE p_tr_bif_admin_user (p_newrec IN OUT admin_user%ROWTYPE);

   PROCEDURE p_tr_buf_admin_user (p_oldrec   IN     admin_user%ROWTYPE,
                                  p_newrec   IN OUT admin_user%ROWTYPE);

   PROCEDURE p_login (p_username       IN     admin_user.usr_user_login%TYPE,
                      p_password       IN     VARCHAR2, -- Password en clair pour validation via LDAP
                      p_passwordhash   IN     VARCHAR2, -- Password crypté pour validation des comptes locaux
                      p_lan_code       IN     language.lan_code%TYPE,
                      p_ipaddress      IN     VARCHAR2,
                      p_apl_id         IN     NUMBER,
                      p_token          IN     VARCHAR2,
                      p_user_id           OUT admin_user.usr_id%TYPE,
                      p_returnstatus      OUT NUMBER);
END pkg_admin_user;
/

