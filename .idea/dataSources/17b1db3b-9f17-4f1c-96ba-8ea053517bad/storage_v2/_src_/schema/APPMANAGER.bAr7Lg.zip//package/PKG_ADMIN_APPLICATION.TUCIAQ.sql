create PACKAGE            pkg_admin_application
AS
    /******************************************************************************
       NAME:       PKG_ADMIN_APPLICATION
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        19.07.2013      burrif       1. Created this package.
    ******************************************************************************/


    cst_application_midat          CONSTANT admin_application.apl_code%TYPE
                                                := 'MIDAT' ;
    cst_application_infofauna      CONSTANT admin_application.apl_code%TYPE
                                                := 'INFOFAUNA' ;
    cst_application_mds            CONSTANT admin_application.apl_code%TYPE
                                                := 'MDS' ;
    cst_application_systematique   CONSTANT admin_application.apl_code%TYPE
                                                := 'SYSTEMATIQUE' ;

    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_getapplmidat
        RETURN VARCHAR2;

    FUNCTION f_getapplmds
        RETURN VARCHAR2;

    FUNCTION f_getapplinfofauna
        RETURN VARCHAR2;

    FUNCTION f_getapplsystematique
        RETURN VARCHAR2;

    FUNCTION f_getrecordfromcode (
        p_apl_code   IN admin_application.apl_code%TYPE)
        RETURN admin_application%ROWTYPE;

    FUNCTION f_getrecord (p_apl_id IN admin_application.apl_id%TYPE)
        RETURN admin_application%ROWTYPE;

    PROCEDURE p_insert (
        p_code          IN     admin_application.apl_code%TYPE,
        p_description   IN     admin_application.apl_description%TYPE,
        p_id               OUT admin_application.apl_id%TYPE);

    PROCEDURE p_tr_bif_admin_application (
        p_newrec   IN OUT admin_application%ROWTYPE);

    PROCEDURE p_tr_buf_admin_application (
        p_oldrec   IN     admin_application%ROWTYPE,
        p_newrec   IN OUT admin_application%ROWTYPE);
END pkg_admin_application;
/

