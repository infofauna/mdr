create PACKAGE            pkg_admin_user_role
AS
   /******************************************************************************
      NAME:       PKG_ADMIN_USER_ROLE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.07.2013      burrif       1. Created this package.
      1.1        16.10.2017      burrif       2. Test d'un rôle
      1.2        30.07.2018      burrif       3. Role par application
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;



   FUNCTION f_getrecord (p_aur_id IN admin_user_role.aur_id%TYPE)
      RETURN admin_user_role%ROWTYPE;

   PROCEDURE p_tr_bif_admin_user_role (
      p_newrec   IN OUT admin_user_role%ROWTYPE);

   PROCEDURE p_tr_buf_admin_user_role (
      p_oldrec   IN     admin_user_role%ROWTYPE,
      p_newrec   IN OUT admin_user_role%ROWTYPE);

   PROCEDURE p_insert (p_usr_id   IN     admin_user_role.aur_usr_id%TYPE,
                       p_apr_id   IN     admin_user_role.aur_apr_id%TYPE,
                       p_id          OUT admin_user_role.aur_id%TYPE);

   FUNCTION f_userhasrole (p_usr_id   IN admin_user.usr_id%TYPE,
                           p_role     IN admin_role.apr_name%TYPE)
      RETURN VARCHAR2;

   FUNCTION f_userhasrole (
      p_usr_id            IN admin_user.usr_id%TYPE,
      p_role              IN admin_role.apr_name%TYPE,
      p_applicationcode   IN admin_application.apl_code%TYPE)
      RETURN VARCHAR2;

   FUNCTION f_userhasroleid (p_usr_id   IN admin_user.usr_id%TYPE,
                             p_apr_id   IN admin_role.apr_id%TYPE)
      RETURN VARCHAR2;
END pkg_admin_user_role;
/

