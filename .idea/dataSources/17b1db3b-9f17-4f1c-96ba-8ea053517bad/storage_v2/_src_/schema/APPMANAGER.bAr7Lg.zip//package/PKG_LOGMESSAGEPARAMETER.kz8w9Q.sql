create PACKAGE            pkg_logmessageparameter
AS
   /******************************************************************************
      NAME:       PKG_LOGMESSAGEPARAMETER
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.07.2013      burrif       1. Created this package.
   ******************************************************************************/

   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecord (p_lmp_id IN logmessageparameter.lmp_id%TYPE)
      RETURN logmessageparameter%ROWTYPE;

   PROCEDURE p_tr_bif_logmessageparameter (
      p_newrec IN OUT logmessageparameter%ROWTYPE);

   PROCEDURE p_tr_buf_logmessageparameter (
      p_oldrec   IN     logmessageparameter%ROWTYPE,
      p_newrec   IN OUT logmessageparameter%ROWTYPE);

   PROCEDURE p_write (
      p_lmh_id                  IN logmessageparameter.lmp_lmh_id%TYPE,
      p_lmp_parametersequence   IN logmessageparameter.lmp_parametersequence%TYPE,
      p_lmp_value               IN logmessageparameter.lmp_parametervalue%TYPE);

   FUNCTION f_loadparameter (p_lmh_id IN logmessageparameter.lmp_lmh_id%TYPE)
      RETURN pkg_message.t_messagetable;
END pkg_logmessageparameter;
/

