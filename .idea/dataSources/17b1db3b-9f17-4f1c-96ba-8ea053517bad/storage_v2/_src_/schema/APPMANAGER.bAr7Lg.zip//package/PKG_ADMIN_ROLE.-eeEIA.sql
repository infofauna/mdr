create PACKAGE            pkg_admin_role
AS
    /******************************************************************************
       NAME:       PKG_ADMIN_ROLE
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        19.07.2013      burrif       1. Created this package.
       1.1        09.07.2018      burrif       2. Modification perttant de gérer les droit depuis la table ADMIN_USER_ROLE_GROUP
       1.2        30.01.2020      burrif       3. Ajout de fonction retrournant les rôles
    ******************************************************************************/



    cst_usergroupflag_na           CONSTANT admin_role.apr_usergroupflag%TYPE
                                                := 'N/A' ;   -- Not applicable
    cst_usergroupflag_ugd          CONSTANT admin_role.apr_usergroupflag%TYPE
                                                := 'UGD' ; -- User Group Defined



    TYPE t_listrole IS TABLE OF admin_role.apr_name%TYPE;

    cst_admin_role_manager         CONSTANT admin_role.apr_name%TYPE := 'MANAGER';
    cst_admin_role_contributor     CONSTANT admin_role.apr_name%TYPE
                                                := 'CONTRIBUTOR' ;
    cst_admin_role_nationalread    CONSTANT admin_role.apr_name%TYPE
                                                := 'NATIONAL_USER' ;
    cst_admin_role_nationalwrite   CONSTANT admin_role.apr_name%TYPE
                                                := 'NATIONAL_CONTRIBUTOR' ;
    cst_admin_role_user            CONSTANT admin_role.apr_name%TYPE
                                                := 'USER' ;
    cst_admin_role_noexport        CONSTANT admin_role.apr_name%TYPE
                                                := 'NOEXPORT' ;
    cst_admin_role_noexportmds     CONSTANT admin_role.apr_name%TYPE
                                                := 'NOEXPORTMDS' ;
    cst_admin_role_export          CONSTANT admin_role.apr_name%TYPE
                                                := 'EXPORT' ;

    cst_admin_role_arma            CONSTANT admin_role.apr_name%TYPE
                                                := 'ARMA' ;

    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_getrolemanager
        RETURN admin_role.apr_name%TYPE;

    FUNCTION f_getrolecontributor
        RETURN admin_role.apr_name%TYPE;

    FUNCTION f_getrolemationalread
        RETURN admin_role.apr_name%TYPE;

    FUNCTION f_getrolemationalcontributor
        RETURN admin_role.apr_name%TYPE;

    FUNCTION f_getroleuser
        RETURN admin_role.apr_name%TYPE;

    FUNCTION f_getrolenoexport
        RETURN admin_role.apr_name%TYPE;

    FUNCTION f_getroleexportmds
        RETURN admin_role.apr_name%TYPE;

    FUNCTION f_getroleexport
        RETURN admin_role.apr_name%TYPE;

    FUNCTION f_getrolearma
        RETURN admin_role.apr_name%TYPE;



    FUNCTION f_getrecordbyname (
        p_role_name          IN admin_role.apr_name%TYPE,
        p_application_code   IN admin_application.apl_code%TYPE)
        RETURN admin_role%ROWTYPE;

    FUNCTION f_returnlistrole (p_usr_id IN admin_user_group.agp_usr_id%TYPE)
        RETURN t_listrole;

    FUNCTION f_getrecordbyname (p_name IN admin_role.apr_name%TYPE)
        RETURN admin_role%ROWTYPE;

    PROCEDURE p_insert (
        p_apl_id        IN     admin_role.apr_apl_id%TYPE,
        p_name          IN     admin_role.apr_name%TYPE,
        p_description   IN     admin_role.apr_description%TYPE,
        p_id               OUT admin_role.apr_id%TYPE);


    PROCEDURE p_insert (
        p_apl_id          IN     admin_role.apr_apl_id%TYPE,
        p_name            IN     admin_role.apr_name%TYPE,
        p_description     IN     admin_role.apr_description%TYPE,
        p_usergroupflag   IN     admin_role.apr_usergroupflag%TYPE,
        p_id                 OUT admin_role.apr_id%TYPE);


    FUNCTION f_getrecord (p_apr_id IN admin_role.apr_id%TYPE)
        RETURN admin_role%ROWTYPE;

    PROCEDURE p_tr_bif_admin_role (p_newrec IN OUT admin_role%ROWTYPE);

    PROCEDURE p_tr_buf_admin_role (p_oldrec   IN     admin_role%ROWTYPE,
                                   p_newrec   IN OUT admin_role%ROWTYPE);
END pkg_admin_role;
/

