create PACKAGE            pkg_admin_user_role_group
AS
    /******************************************************************************
       NAME:       PKG_ADMIN_USER_ROLE_GROUP
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        05.07.2018      burrif       1. Created this package.
    ******************************************************************************/



    cst_rightgroup_none    CONSTANT VARCHAR2 (5) := 'NONE';
    cst_rightgroup_read    CONSTANT VARCHAR2 (5) := 'READ';
    cst_rightgroup_write   CONSTANT VARCHAR2 (5) := 'WRITE';

    TYPE t_listrole IS TABLE OF admin_role.apr_name%TYPE;

    TYPE t_listgroup IS TABLE OF admin_group.agr_name%TYPE;

    PROCEDURE p_testhasrole;

    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_hasrole (p_usr_id        IN admin_user_role_group.arg_usr_id%TYPE,
                        p_role          IN admin_role.apr_name%TYPE,
                        p_application   IN admin_application.apl_code%TYPE)
        RETURN BOOLEAN;

    FUNCTION f_hasonewritable (
        p_usr_id        IN admin_user_role_group.arg_usr_id%TYPE,
        p_role          IN admin_role.apr_name%TYPE,
        p_application   IN admin_application.apl_code%TYPE)
        RETURN BOOLEAN;

    FUNCTION f_returnrightofgroup (
        p_usr_id        IN admin_user_role_group.arg_usr_id%TYPE,
        p_role          IN admin_role.apr_name%TYPE,
        p_application   IN admin_application.apl_code%TYPE,
        p_group         IN admin_group.agr_name%TYPE)
        RETURN VARCHAR2;

    PROCEDURE p_write (
        p_usr_id     IN admin_user_role_group.arg_usr_id%TYPE,
        p_apr_id     IN admin_user_role_group.arg_apr_id%TYPE,
        p_agr_id     IN admin_user_role_group.arg_agr_id%TYPE,
        p_writable   IN admin_user_role_group.arg_writetable%TYPE);

    PROCEDURE p_updatestatus (
        p_arg_id       IN admin_user_role_group.arg_id%TYPE,
        p_writetable   IN admin_user_role_group.arg_writetable%TYPE);

    FUNCTION f_getrecord (p_arg_id IN admin_user_role_group.arg_id%TYPE)
        RETURN admin_user_role_group%ROWTYPE;

    FUNCTION f_getrecordbyallkey (
        p_usr_id   IN admin_user_role_group.arg_usr_id%TYPE,
        p_apr_id   IN admin_user_role_group.arg_apr_id%TYPE,
        p_agr_id   IN admin_user_role_group.arg_agr_id%TYPE)
        RETURN admin_user_role_group%ROWTYPE;

    FUNCTION f_returnlistgroup (
        p_usr_id        IN admin_user_group.agp_usr_id%TYPE,
        p_application   IN admin_application.apl_code%TYPE,
        p_writetable    IN BOOLEAN)
        RETURN t_listgroup;

    FUNCTION f_returnlistrole (
        p_usr_id             IN admin_user_group.agp_usr_id%TYPE,
        p_application_code   IN admin_application.apl_code%TYPE)
        RETURN t_listrole;

    PROCEDURE p_testlistrole;

    PROCEDURE p_testlistgroup;
END pkg_admin_user_role_group;
/

