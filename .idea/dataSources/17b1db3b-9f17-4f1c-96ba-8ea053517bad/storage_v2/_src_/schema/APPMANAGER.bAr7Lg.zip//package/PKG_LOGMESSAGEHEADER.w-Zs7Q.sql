create PACKAGE            pkg_logmessageheader
AS
   /******************************************************************************

      NAME:       PKG_LOGMESSAGEHEADER

      PURPOSE:



      REVISIONS:

      Ver        Date        Author           Description

      ---------  ----------  ---------------  ------------------------------------

      1.0        25.07.2013      burrif       1. Created this package.

   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;



   FUNCTION f_getrecord (p_lmh_id IN logmessageheader.lmh_id%TYPE)
      RETURN logmessageheader%ROWTYPE;



   PROCEDURE p_tr_bif_logmessageheader (
      p_newrec IN OUT logmessageheader%ROWTYPE);



   PROCEDURE p_tr_buf_logmessageheader (
      p_oldrec   IN     logmessageheader%ROWTYPE,
      p_newrec   IN OUT logmessageheader%ROWTYPE);



   PROCEDURE p_processexception (
      p_sqlcode   IN     NUMBER,
      p_sqlerrm     IN     logmessageheader.lmh_errm%TYPE,
      p_lmh_id       OUT logmessageheader.lmh_id%TYPE);

   PROCEDURE p_getlogmessage (
      p_messagekey     IN     logmessageheader.lmh_errm%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_severity          OUT MESSAGE.msg_severity%TYPE,
      p_message           OUT MESSAGE.msg_message%TYPE,
      p_returnstatus      OUT NUMBER);
      
    PROCEDURE p_getlogmessage (
      p_messagekey     IN     logmessageheader.lmh_errm%TYPE,
      p_apl_id         IN     admin_application.apl_id%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_severity          OUT MESSAGE.msg_severity%TYPE,
      p_message           OUT MESSAGE.msg_message%TYPE,
      p_returnstatus      OUT NUMBER);  
         
END pkg_logmessageheader;
/

