create trigger TR_BUF_SAMPLEDOCUMENT
    before update
    on SAMPLEDOCUMENT
    for each row
DECLARE
BEGIN
 
   :new.SPT_moddate := SYSDATE;
   :new.SPT_moduser := USER;
END tr_buf_SAMPLEDOCUMENT;

/

