create PACKAGE BODY       pkg_manageindice
AS
   /******************************************************************************
      NAME:       PKG_MANAGEINDICE
      PURPOSE: Ce package est destiné à être utilisé comme outil autonome de gestion des indices
                      par exemple pour refaire un calcul

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        21.04.2016      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, avril  2016';

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-------------------------------------------------------------------------------------*/
   PROCEDURE p_updatemkidata (
      p_sph_id                  IN sampleheader.sph_id%TYPE,
      p_makroindexvalue         IN sampleheader.sph_makroindexvalue%TYPE,
      p_cvl_id_mkicase          IN sampleheader.sph_cvl_id_mkicase%TYPE,
      p_mkirangecount           IN sampleheader.sph_mkirangecount%TYPE,
      p_mkiinsectacount         IN sampleheader.sph_mkiinsectacount%TYPE,
      p_mkinonisectacount       IN sampleheader.sph_mkinonisectacount%TYPE,
      p_mkiplecopteracount      IN sampleheader.sph_mkiplecopteracount%TYPE,
      p_mkitricopteracount      IN sampleheader.sph_mkitricopteracount%TYPE,
      p_mkiephemeropteracount   IN sampleheader.sph_mkiephemeropteracount%TYPE,
      p_mkibaetidaecount        IN sampleheader.sph_mkibaetidaecount%TYPE,
      p_mkigammaruscount        IN sampleheader.sph_mkigammaruscount%TYPE,
      p_mkihydropsychecount     IN sampleheader.sph_mkihydropsychecount%TYPE,
      p_mkiaselluscount         IN sampleheader.sph_mkiaselluscount%TYPE,
      p_mkihirudinaecount       IN sampleheader.sph_mkihirudinaecount%TYPE,
      p_mkitubificidaecount     IN sampleheader.sph_mkitubificidaecount%TYPE,
      p_mkierrornumber          IN sampleheader.sph_mkierrornumber%TYPE)
   /*------------------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      DBMS_OUTPUT.put_line ('UPDATED');

      UPDATE sampleheader
         SET sph_makroindexvalue = p_makroindexvalue,
             sph_cvl_id_mkicase = p_cvl_id_mkicase,
             sph_mkirangecount = p_mkirangecount,
             sph_mkiinsectacount = p_mkiinsectacount,
             sph_mkinonisectacount = p_mkinonisectacount,
             sph_mkiplecopteracount = p_mkiplecopteracount,
             sph_mkitricopteracount = p_mkitricopteracount,
             sph_mkiephemeropteracount = p_mkiephemeropteracount,
             sph_mkibaetidaecount = p_mkibaetidaecount,
             sph_mkigammaruscount = p_mkigammaruscount,
             sph_mkihydropsychecount = p_mkihydropsychecount,
             sph_mkiaselluscount = p_mkiaselluscount,
             sph_mkihirudinaecount = p_mkihirudinaecount,
             sph_mkitubificidaecount = p_mkitubificidaecount,
             sph_mkierrornumber = p_mkierrornumber
       WHERE sph_id = p_sph_id;
   END;

   /*---------------------------------------------------------------------------------*/
   PROCEDURE p_updateibchdata (
      p_sph_id           IN sampleheader.sph_id%TYPE,
      p_indexvalueibch   IN sampleheader.sph_indexvalueibch%TYPE,
      p_ibchgivalue      IN sampleheader.sph_ibchgivalue%TYPE,
      p_ibchvtvalue      IN sampleheader.sph_ibchvtvalue%TYPE)
   /*-----------------------------------------------------------------------------------------*/
   IS
   BEGIN
      DBMS_OUTPUT.put_line ('UPDATED');

      UPDATE sampleheader
         SET sph_indexvalueibch = p_indexvalueibch,
             sph_ibchgivalue = p_ibchgivalue,
             sph_ibchvtvalue = p_ibchvtvalue
       WHERE sph_id = p_sph_id;
   END;

   /*---------------------------------------------------------------------------------*/
   PROCEDURE p_updatespeardata (
      p_sph_id            IN sampleheader.sph_id%TYPE,
      p_spearindexvalue   IN sampleheader.sph_spearindexvalue%TYPE)
   /*-----------------------------------------------------------------------------------------*/
   IS
   BEGIN
      DBMS_OUTPUT.put_line ('UPDATED');

      UPDATE sampleheader
         SET sph_spearindexvalue = p_spearindexvalue
       WHERE sph_id = p_sph_id;
   END;


   /*--------------------------------------------------------------*/
   PROCEDURE p_calculatespear (
      p_recsampleheader   IN     sampleheader%ROWTYPE,
      p_spearvalue           OUT sampleheader.sph_spearindexvalue%TYPE)
   /*--------------------------------------------------------------*/
   IS
      l_status                  NUMBER;

      CURSOR l_sampleprotocollabo (
         p_sph_id   IN sampleprotocollabo.spl_sph_id%TYPE)
      IS
         SELECT *
           FROM sampleprotocollabo
          WHERE spl_sph_id = p_sph_id;

      l_recsampleprotocollabo   l_sampleprotocollabo%ROWTYPE;
      l_absolutenumberflag      codevalue.cvl_code%TYPE;
   BEGIN
      pkg_spear.p_spearinit;

      OPEN l_sampleprotocollabo (p_recsampleheader.sph_id);

      LOOP
         FETCH l_sampleprotocollabo INTO l_recsampleprotocollabo;

         EXIT WHEN l_sampleprotocollabo%NOTFOUND;



         pkg_spear.p_spearadddata (l_recsampleprotocollabo.spl_syv_id,
                                   l_recsampleprotocollabo.spl_frequency,
                                   l_status); --pkg_constante.cst_returnstatusnotok -> pas dans la liste
      END LOOP;

      CLOSE l_sampleprotocollabo;

    

      IF p_recsampleheader.sph_absolutenumberflag = pkg_constante.cst_yes
      THEN
         l_absolutenumberflag := pkg_ibch.cst_abondanceflag_absolu;
      ELSE
         l_absolutenumberflag := pkg_ibch.cst_abondanceflag_class;
      END IF;

      p_spearvalue :=
         pkg_spear.f_computespearfrommemory (l_absolutenumberflag);
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_calculateibch (
      p_recsampleheader   IN     sampleheader%ROWTYPE,
      p_ibchvalue            OUT sampleheader.sph_indexvalueibch%TYPE)
   /*--------------------------------------------------------------*/
   IS
      l_status                     NUMBER;

      CURSOR l_sampleprotocollabo (
         p_sph_id   IN sampleprotocollabo.spl_sph_id%TYPE)
      IS
         SELECT *
           FROM sampleprotocollabo
          WHERE spl_sph_id = p_sph_id;

      l_recsampleprotocollabo      l_sampleprotocollabo%ROWTYPE;
      l_absolutenumberflag         codevalue.cvl_code%TYPE;
      l_recprotocolversion         protocolversion%ROWTYPE;
      l_reccodevalueprotocoltype   codevalue%ROWTYPE;
   BEGIN
      l_recprotocolversion :=
         pkg_protocolversion.f_getrecord (p_recsampleheader.sph_ptv_id);
      l_reccodevalueprotocoltype :=
         pkg_codevalue.f_getrecord (
            l_recprotocolversion.ptv_cvl_id_protocoltype);


      pkg_ibch.p_ibchinit;
      pkg_ibch.p_initlistibchvaluemass;

      OPEN l_sampleprotocollabo (p_recsampleheader.sph_id);

      LOOP
         FETCH l_sampleprotocollabo INTO l_recsampleprotocollabo;

         EXIT WHEN l_sampleprotocollabo%NOTFOUND;

         IF l_reccodevalueprotocoltype.cvl_code =
               pkg_codevalue.cst_protocoltype_laboratory
         THEN
            pkg_ibch.p_ibchadddata (l_recsampleprotocollabo.spl_ptl_id,
                                    l_recsampleprotocollabo.spl_frequency);
         ELSIF l_reccodevalueprotocoltype.cvl_code =
                  pkg_codevalue.cst_protocoltype_mass
         THEN
            pkg_ibch.p_addlistibchvaluemass (
               l_recsampleprotocollabo.spl_syv_id,
               l_recsampleprotocollabo.spl_frequency);
         END IF;
      END LOOP;

      CLOSE l_sampleprotocollabo;

      IF p_recsampleheader.sph_absolutenumberflag = pkg_constante.cst_yes
      THEN
         l_absolutenumberflag := pkg_ibch.cst_abondanceflag_absolu;
      ELSE
         l_absolutenumberflag := pkg_ibch.cst_abondanceflag_class;
      END IF;

     

      IF l_reccodevalueprotocoltype.cvl_code =
            pkg_codevalue.cst_protocoltype_mass
      THEN
         pkg_ibch.p_convertmass2ibch (
            l_recprotocolversion.ptv_id);
      END IF;

      p_ibchvalue := pkg_ibch.f_computeibchfrommemory (l_absolutenumberflag);
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_calculatemakroindex (
      p_recsampleheader   IN     sampleheader%ROWTYPE,
      p_mkivalue             OUT sampleheader.sph_makroindexvalue%TYPE)
   /*--------------------------------------------------------------*/
   IS
      CURSOR l_sampleprotocollabo (
         p_sph_id   IN sampleprotocollabo.spl_sph_id%TYPE)
      IS
         SELECT *
           FROM sampleprotocollabo
          WHERE spl_sph_id = p_sph_id;

      l_recsampleprotocollabo   l_sampleprotocollabo%ROWTYPE;
   BEGIN
      pkg_makroindex.p_mkiinit;

      OPEN l_sampleprotocollabo (p_recsampleheader.sph_id);

      LOOP
         FETCH l_sampleprotocollabo INTO l_recsampleprotocollabo;

         EXIT WHEN l_sampleprotocollabo%NOTFOUND;
         pkg_makroindex.p_mkiadddata (NULL,              -- NULL -> Pas de log
                                      l_recsampleprotocollabo.spl_syv_id);
      END LOOP;

      CLOSE l_sampleprotocollabo;

      p_mkivalue := pkg_makroindex.f_computemakroindex;
   END;



   /*---------------------------------------------------------------*/
   PROCEDURE p_calculateindicefromsph (
      p_recsampleheader   IN sampleheader%ROWTYPE)
   /*--------------------------------------------------------------*/
   IS
      -- Permet de recalculer les indices associées à un header
      l_listmkireference           pkg_makroindex.t_listmkireference;
      l_recprotocolversion         protocolversion%ROWTYPE;
      l_reccodevalueprotocoltype   codevalue%ROWTYPE;
      l_spearindexcalculation      BOOLEAN;
      l_makroindexcalculation      BOOLEAN;
      l_ibchindexcalculation       BOOLEAN;
      l_spearvalue                 sampleheader.sph_spearindexvalue%TYPE;
      l_ibchvalue                  sampleheader.sph_indexvalueibch%TYPE;
      l_makroindex                 sampleheader.sph_makroindexvalue%TYPE;
      l_reccodevaluemkicase        codevalue%ROWTYPE;
   BEGIN
      l_spearindexcalculation := FALSE;
      l_makroindexcalculation := FALSE;
      l_ibchindexcalculation := FALSE;
      l_recprotocolversion :=
         pkg_protocolversion.f_getrecord (p_recsampleheader.sph_ptv_id);
      l_reccodevalueprotocoltype :=
         pkg_codevalue.f_getrecord (
            l_recprotocolversion.ptv_cvl_id_protocoltype);

      IF l_reccodevalueprotocoltype.cvl_code =
            pkg_codevalue.cst_protocoltype_laboratory
      THEN
         l_spearindexcalculation := TRUE;
         l_ibchindexcalculation := TRUE;
      ELSIF l_reccodevalueprotocoltype.cvl_code =
               pkg_codevalue.cst_protocoltype_mass
      THEN
         pkg_importmassdataheader.p_returnindexcalculation (
            p_recsampleheader.sph_imh_id,
            l_spearindexcalculation,
            l_makroindexcalculation,
            l_ibchindexcalculation);
      ELSE
         raise_application_error (
            -20000,
               'Type de protocole= '
            || l_reccodevalueprotocoltype.cvl_code
            || ' invalide');
      END IF;

      IF l_spearindexcalculation
      THEN
         p_calculatespear (p_recsampleheader, l_spearvalue);

         IF NVL ( (p_recsampleheader.sph_spearindexvalue), -1) !=
               NVL (l_spearvalue, -1)
         THEN
            DBMS_OUTPUT.put_line (
                  'Old spear value='
               || NVL (TO_CHAR (p_recsampleheader.sph_spearindexvalue),
                       'null')
               || ' New spear value='
               || NVL (TO_CHAR (l_spearvalue), 'null'));
         END IF;
      END IF;

      IF l_ibchindexcalculation
      THEN
         p_calculateibch (p_recsampleheader, l_ibchvalue);

         IF NVL ( (p_recsampleheader.sph_indexvalueibch), -1) !=
               NVL (l_ibchvalue, -1)
         THEN
            DBMS_OUTPUT.put_line (
                  'Old ibch value='
               || NVL (TO_CHAR (p_recsampleheader.sph_indexvalueibch),
                       'null')
               || ' New ibch value='
               || NVL (TO_CHAR (l_ibchvalue), 'null'));
         END IF;
      END IF;

      IF l_makroindexcalculation
      THEN
         p_calculatemakroindex (p_recsampleheader, l_makroindex);

         IF NVL ( (p_recsampleheader.sph_makroindexvalue), -1) !=
               NVL (l_makroindex, -1)
         THEN
            DBMS_OUTPUT.put_line (
                  'Old mki value='
               || NVL (TO_CHAR (p_recsampleheader.sph_makroindexvalue),
                       'null')
               || ' New mki value='
               || NVL (TO_CHAR (l_makroindex), 'null'));
         END IF;
      END IF;
   END;

   /*-----------------------------------------------------------------------------------*/

   PROCEDURE p_testrebuild
   /*-----------------------------------------------------------------------------------*/
   IS
      CURSOR l_sampleheader
      IS
         SELECT * FROM sampleheader;

      l_recsampleheader   l_sampleheader%ROWTYPE;
      l_status            NUMBER;
   BEGIN
      OPEN l_sampleheader;

      LOOP
         FETCH l_sampleheader INTO l_recsampleheader;

         EXIT WHEN l_sampleheader%NOTFOUND;
         p_calculateindicefromsph (l_recsampleheader);
      END LOOP;

      CLOSE l_sampleheader;
   END;

   /*-----------------------------------------------------------------------------------*/
   PROCEDURE p_check
   /*-----------------------------------------------------------------------------------*/
   IS
      CURSOR l_sampleheader
      IS
         SELECT *
           FROM sampleheader;
       --   WHERE ROWNUM < 5;

      l_recsampleheader   l_sampleheader%ROWTYPE;
      l_status            NUMBER;
   BEGIN
      OPEN l_sampleheader;

      LOOP
         FETCH l_sampleheader INTO l_recsampleheader;

         EXIT WHEN l_sampleheader%NOTFOUND;
         DBMS_OUTPUT.put_line ('sph_id=' || l_recsampleheader.sph_id);
         p_calculateindicefromsph (l_recsampleheader);
      END LOOP;

      CLOSE l_sampleheader;
   END;
END pkg_manageindice;
/

