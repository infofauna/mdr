create trigger TR_BIF_IMPORTMASSSTATION
    before insert
    on IMPORTMASSSTATION
    for each row
DECLARE
BEGIN
   IF :new.ims_id IS NULL
   THEN
      :new.ims_id := seq_importmassstation.NEXTVAL;
   END IF;

   :new.ims_credate := SYSDATE;
   :new.ims_creuser := USER;
END tr_bif_importmassstation;

/

