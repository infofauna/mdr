create PACKAGE       pkg_neozoaire
AS
    /******************************************************************************
      NAME:       PKG_NEOZOAIRE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
   ******************************************************************************/

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2020';


    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_getrecord (p_id IN neozoaire.neo_id%TYPE)
        RETURN neozoaire%ROWTYPE;

    FUNCTION f_getrecordbydesignation (
        p_designation   IN neozoaire.neo_designation%TYPE)
        RETURN neozoaire%ROWTYPE;

    PROCEDURE p_insert (
        p_code          IN     neozoaire.neo_code%TYPE,
        p_order         IN     neozoaire.neo_order%TYPE,
        p_syv_id        IN     neozoaire.neo_syv_id%TYPE,
        p_designation   IN     neozoaire.neo_designation%TYPE,
        p_id               OUT neozoaire.neo_id%TYPE);

    PROCEDURE p_updatesyv_id (p_id       IN neozoaire.neo_id%TYPE,
                              p_syv_id   IN neozoaire.neo_syv_id%TYPE);
END;
/

