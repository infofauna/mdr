create trigger TR_BIF_TRICOPTERASCABBARD
    before insert
    on TRICOPTERASCABBARD
    for each row
DECLARE
BEGIN
   IF :new.TSD_id IS NULL
   THEN
      :new.TSD_id := seq_TRICOPTERASCABBARD.NEXTVAL;
   END IF;

   :new.TSD_credate := SYSDATE;
   :new.TSD_creuser := USER;
END tr_bif_TRICOPTERASCABBARD;

/

