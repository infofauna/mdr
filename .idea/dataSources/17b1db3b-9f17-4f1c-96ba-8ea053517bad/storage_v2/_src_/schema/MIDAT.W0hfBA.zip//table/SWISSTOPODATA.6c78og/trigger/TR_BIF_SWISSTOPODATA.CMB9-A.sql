create trigger TR_BIF_SWISSTOPODATA
    before insert
    on SWISSTOPODATA
    for each row
DECLARE
BEGIN
   IF :new.SWD_id IS NULL
   THEN
      :new.SWD_id := seq_SWISSTOPODATA.NEXTVAL;
   END IF;

   :new.SWD_credate := SYSDATE;
   :new.SWD_creuser := USER;
END tr_bif_SWISSTOPODATA;

/

