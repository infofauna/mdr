create trigger TR_BUF_SPEARDATALINKCSCF
    before update
    on SPEARDATALINKCSCF
    for each row
DECLARE
BEGIN
 
   :new.SDF_moddate := SYSDATE;
   :new.SDF_moduser := USER;
END tr_buf_SPEARDATALINKCSCF;

/

