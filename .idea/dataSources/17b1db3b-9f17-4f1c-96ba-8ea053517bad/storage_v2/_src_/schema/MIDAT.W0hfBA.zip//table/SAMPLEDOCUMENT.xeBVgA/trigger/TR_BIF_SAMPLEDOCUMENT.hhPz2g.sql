create trigger TR_BIF_SAMPLEDOCUMENT
    before insert
    on SAMPLEDOCUMENT
    for each row
DECLARE
BEGIN
   IF :new.SPT_id IS NULL
   THEN
      :new.SPT_id := seq_SAMPLEDOCUMENT.NEXTVAL;
   END IF;

   :new.SPT_credate := SYSDATE;
   :new.SPT_creuser := USER;
END tr_bif_SAMPLEDOCUMENT;

/

