create trigger TR_BUF_IMPORTMASSDATADETAIL
    before update
    on IMPORTMASSDATADETAIL
    for each row
DECLARE
BEGIN
 
   :new.IMD_moddate := SYSDATE;
   :new.IMD_moduser := USER;
END tr_buf_IMPORTMASSDATADETAIL;

/

