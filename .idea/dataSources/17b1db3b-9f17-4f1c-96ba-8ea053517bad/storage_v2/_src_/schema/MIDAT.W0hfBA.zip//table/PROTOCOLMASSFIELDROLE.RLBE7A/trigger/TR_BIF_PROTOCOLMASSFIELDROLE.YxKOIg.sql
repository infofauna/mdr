create trigger TR_BIF_PROTOCOLMASSFIELDROLE
    before insert
    on PROTOCOLMASSFIELDROLE
    for each row
DECLARE
BEGIN
   IF :new.PFR_id IS NULL
   THEN
      :new.PFR_id := SEQ_PROTOCOLMASSFIELDROLE.NEXTVAL;
   END IF;

   :new.PFR_credate := SYSDATE;
   :new.PFR_creuser := USER;
END TR_BIF_PROTOCOLMASSFIELDROLE;

/

