create PACKAGE       pkg_ibch
AS
    /******************************************************************************
       NAME:       PKG_IBCH
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        08.07.2015      burrif       1. Created this package.
       1.1        24.09.2019      burrif       2. Cas particulier
       1.2        23.01.2020      burrif       3. Externalisation de compteurs
    ******************************************************************************/



    TYPE t_ibchvalue IS RECORD
    (
        ibc_ptl_id          protocolmappinglabo.ptl_id%TYPE,
        ibc_counter         NUMBER,
        ibc_nbroccurence    NUMBER
    );

    TYPE t_ibchvaluemass IS RECORD
    (
        ibm_syv_id          systvalue.syv_id%TYPE,
        ibm_counter         NUMBER,
        ibm_nbroccurence    NUMBER
    );

    TYPE t_listibchvalue IS TABLE OF t_ibchvalue;

    TYPE t_listtaxonindicateur IS TABLE OF protocolmappinglabo.ptl_id%TYPE;



    TYPE t_listibchvaluemass IS TABLE OF t_ibchvaluemass;

    cst_abondanceflag_class    CONSTANT VARCHAR2 (10) := 'CLASS';
    cst_abondanceflag_absolu   CONSTANT VARCHAR2 (10) := 'ABS';

    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_getgbl_count_plecoptera
        RETURN NUMBER;

    FUNCTION f_getgbl_count_trichoptera
        RETURN NUMBER;

    FUNCTION f_getgbl_count_ephemeroptera
        RETURN NUMBER;

    FUNCTION f_getgbl_taxon_indicateur
        RETURN VARCHAR2;


    PROCEDURE p_completewithparent (p_ptv_id IN protocolversion.ptv_id%TYPE);

    PROCEDURE p_setwritelog (p_writelog IN BOOLEAN);

    FUNCTION f_getgbllistibchvaluemass
        RETURN t_listibchvaluemass;

    FUNCTION f_getgbllistibchvalue
        RETURN t_listibchvalue;

    FUNCTION f_getgbl_ibchsomme_vt
        RETURN NUMBER;

    FUNCTION f_getgbllistibchvalue_base
        RETURN t_listibchvalue;

    FUNCTION f_getgbllisttaxonindicateur
        RETURN t_listtaxonindicateur;

    FUNCTION f_normaliseabondance (p_value           IN NUMBER,
                                   p_abondanceflag   IN VARCHAR2)
        RETURN NUMBER;

    FUNCTION f_returncounttaxonloaded
        RETURN NUMBER;

    FUNCTION f_getgblibchvt
        RETURN NUMBER;

    FUNCTION f_getgbl_ibchvalue
        RETURN NUMBER;

    FUNCTION f_getgblibchgi
        RETURN NUMBER;

    PROCEDURE p_maincompute (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN     importmassdataheader%ROWTYPE,
        p_ibchindice                   OUT NUMBER);

    PROCEDURE p_ibchinit;

    PROCEDURE p_addlistibchvaluemass (p_syv_id   IN systvalue.syv_id%TYPE,
                                      p_count       NUMBER);

    PROCEDURE p_initlistibchvaluemass;

    PROCEDURE p_ibchadddata (
        p_ptl_id   IN sampleprotocollabo.spl_ptl_id%TYPE,
        p_count    IN sampleprotocollabo.spl_frequency%TYPE);

    PROCEDURE p_convertmass2ibch (p_ptv_id IN protocolversion.ptv_id%TYPE);


    PROCEDURE p_convertmass2ibch (
        p_ptv_id   IN protocolversion.ptv_id%TYPE,
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_imh_id   IN importmassdataheader.imh_id%TYPE);

    FUNCTION f_computeibchfrommemory (p_abondanceflag IN VARCHAR2)
        RETURN NUMBER;

    FUNCTION f_returnspecialcase
        RETURN VARCHAR2;

    FUNCTION f_getgblibchidentifiedtaxoncou
        RETURN NUMBER;

    FUNCTION f_returncountdistincttaxon
        RETURN NUMBER;

    PROCEDURE p_test (p_iph_id   IN importprotocolheader.iph_id%TYPE,
                      p_imh_id   IN importmassdataheader.imh_id%TYPE);
END pkg_ibch;
/

