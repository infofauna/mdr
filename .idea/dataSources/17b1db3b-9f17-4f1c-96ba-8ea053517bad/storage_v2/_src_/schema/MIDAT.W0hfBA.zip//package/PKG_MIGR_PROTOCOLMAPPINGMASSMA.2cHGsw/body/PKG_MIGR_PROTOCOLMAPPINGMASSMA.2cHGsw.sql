create PACKAGE BODY       pkg_migr_protocolmappingmassma
AS
   /******************************************************************************
      NAME:       pkg_migr_protocolmappingmassmap
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
      1.1        13.09.2017      burrif       2. MIDAT Version 2
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.1, septembre  2017' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_addv2 (p_ptv_id IN protocolmappingmassfield.pmm_ptv_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
      l_reclanguage_de                language%ROWTYPE;
      l_reclanguage_fr                language%ROWTYPE;
      l_reclanguage_it                language%ROWTYPE;
      l_recprotocolmappingmassfield   protocolmappingmassfield%ROWTYPE;
   BEGIN
      l_reclanguage_fr :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_francais);
      l_reclanguage_de :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_deutch);
      l_reclanguage_it :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_italiano);

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_remarkcode1,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'REMARQUE_CODE1');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'BEMERKUNG_CODE1');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'NOTA_CODE1');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_remarkcode2,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'REMARQUE_CODE2');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'BEMERKUNG_CODE2');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'NOTA_CODE2');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_remarkcode3,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'REMARQUE_CODE3');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'BEMERKUNG_CODE3');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'NOTA_CODE3');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_remarkcode4,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'REMARQUE_CODE4');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'BEMERKUNG_CODE4');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'NOTA_CODE4');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_remarktext,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'REMARQUE_TEXT');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'BEMERKUNG_TEXT');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'NOTA_TEXT');


      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_determinator,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'DETERMINATEUR');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'BESTIMMERLN');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'DETERMINANTE');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_oidlink,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'OID_STATION_LIE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'OID_STATION_GEBUNDEN');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'OID_STAZIONE_LEGATO');
   END;

   /*-------------------------------------------------*/
   PROCEDURE p_updateversion_2
   /*-------------------------------------------------*/
   IS
   BEGIN
      p_addv2 (4);
   END;

   /*------------------------------------------------------*/
   PROCEDURE p_rename_V2
   /*------------------------------------------------------*/
   IS
      l_reclanguage_de                language%ROWTYPE;
      l_reclanguage_fr                language%ROWTYPE;

      l_recprotocolmappingmassfield   protocolmappingmassfield%ROWTYPE;
   BEGIN
      l_reclanguage_de :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_deutch);
      l_reclanguage_fr :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_francais);

      UPDATE protocolmappingmassmap
         SET pma_aliascolumnname = 'BEMERKUNG_CODE1'
       WHERE     pma_aliascolumnname = 'HINWEIS_CODE1'
             AND pma_lan_id = l_reclanguage_de.lan_id;

      UPDATE protocolmappingmassmap
         SET pma_aliascolumnname = 'BEMERKUNG_CODE2'
       WHERE     pma_aliascolumnname = 'HINWEIS_CODE2'
             AND pma_lan_id = l_reclanguage_de.lan_id;

      UPDATE protocolmappingmassmap
         SET pma_aliascolumnname = 'BEMERKUNG_CODE3'
       WHERE     pma_aliascolumnname = 'HINWEIS_CODE3'
             AND pma_lan_id = l_reclanguage_de.lan_id;

      UPDATE protocolmappingmassmap
         SET pma_aliascolumnname = 'BEMERKUNG_CODE4'
       WHERE     pma_aliascolumnname = 'HINWEIS_CODE4'
             AND pma_lan_id = l_reclanguage_de.lan_id;

      UPDATE protocolmappingmassmap
         SET pma_aliascolumnname = 'BEMERKUNG_FAUNA'
       WHERE     pma_aliascolumnname = 'BEMERKUNG'
             AND pma_lan_id = l_reclanguage_de.lan_id;
             

      UPDATE protocolmappingmassmap
         SET pma_aliascolumnname = 'REMARQUE_FAUNE'
       WHERE     pma_aliascolumnname = 'REMARQUE'
             AND pma_lan_id = l_reclanguage_fr.lan_id;
      
      UPDATE protocolmappingmassmap
         SET pma_aliascolumnname = 'BEMERKUNG_TEXT'
       WHERE     pma_aliascolumnname = 'HINWEIS_TEXT'
             AND pma_lan_id = l_reclanguage_de.lan_id;
             

      UPDATE protocolmappingmassmap
         SET pma_aliascolumnname = 'REMARQUE_FAUNE'
       WHERE     pma_aliascolumnname = 'REMARQUE'
             AND pma_lan_id = l_reclanguage_fr.lan_id;       

      UPDATE protocolmappingmassmap
         SET pma_aliascolumnname = 'BESTIMMER'
       WHERE     pma_aliascolumnname = 'BESTIMMERLN'
             AND pma_lan_id = l_reclanguage_de.lan_id;
             
          UPDATE protocolmappingmassmap
         SET pma_aliascolumnname = 'UNTERART'
       WHERE     pma_aliascolumnname = 'UNTEART'
             AND pma_lan_id = l_reclanguage_de.lan_id;      
   END;


   /*-------------------------------------------------------------*/
   PROCEDURE p_build (p_ptv_id IN protocolversion.ptv_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
      l_reclanguage_de                language%ROWTYPE;
      l_reclanguage_fr                language%ROWTYPE;
      l_reclanguage_it                language%ROWTYPE;
      l_recprotocolmappingmassfield   protocolmappingmassfield%ROWTYPE;
      l_sql                           VARCHAR2 (512);
   /* Note: Ne sont pas repris de la table TEMP_TABCHGT
                       NHA --> peut être déterminé avec la coordonnées
                        FK_SAMPLE
                        FK_SAMPLE
                        FK_MONITORINGPOINT
                        DATE_CHGT_MIDAT
                        DATE_CHGT_BDSP
                        LOC_CODESSYSTEM --> Permeetait de déterminé comment le code commune était attribué (à partir du NHA par exemple)
                        OID_PROPOSE,
                        LOC_CODEVALUE --> Numéro de commune attribué à partir du NHA

                           */



   BEGIN
      DELETE FROM protocolmappingmassmap
            WHERE pma_pmm_id IN (SELECT pmm_id
                                   FROM protocolmappingmassfield
                                  WHERE pmm_ptv_id = p_ptv_id);

      COMMIT;
      l_sql := 'DROP SEQUENCE SEQ_protocolmappingmassmap';

      EXECUTE IMMEDIATE l_sql;

      l_sql := 'CREATE SEQUENCE SEQ_protocolmappingmassmap';

      EXECUTE IMMEDIATE l_sql;


      l_reclanguage_fr :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_francais);
      l_reclanguage_de :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_deutch);
      l_reclanguage_it :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_italiano);
      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_higher,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TAXON_SUP');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TAXON_SUP');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TAXON_SUP');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_family,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FAMILLE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FAMILIE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FAMIGLIA');


      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_genus,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'GENRE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'GATTUNG');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'GENERE');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_species,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'ESPECE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'ART');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'SPECIE');



      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_subspe,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'SS_ESPECE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'UNTEART');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'SOTTOSPECIE');


      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_freq1,
            p_ptv_id);

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FREQ1');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FREQ1');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FREQ1');



      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_freq2,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FREQ2');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FREQ2');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FREQ2');


      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_freqlum,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FREQLUM');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FREQLUM');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'FREQLUM');



      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_stadium,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'STADE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'STADIUM');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'STADIO');



      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_sampmeth,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'METHODE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'METHODE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'METODO');


      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_indicetype,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TYPE_INDICE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TYP_INDEX');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TIPO_INDICE');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_period,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PERIODE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PERIODE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PERIODO');


      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_day,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'J');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'J');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'G');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_month,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'M');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'M');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'M');



      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_year,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'A');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'A');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'A');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_water,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'COURS_EAU');

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'GEWAESSER');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'ACQUE');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_calledplace,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'LOC');


      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'LOC');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'LOC');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_locality,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'CODE_LIEU');

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'CODE_STELLE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'CODICE_LUOGO');


      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_swiss_x,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'CX');

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'CX');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'CX');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_swiss_y,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'CY');

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'CY');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'CY');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_swiss_z,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'ALT');

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'ALT');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'ALT');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_observer,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'OBSERVATEUR');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'BEOBACHTER');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'OSSERVATORE');


      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_project,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PROJET');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PROJEKT');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PROGETTO');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_taxondef,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TAXON_DEF');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TAXON_DEF');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TAXON_DEF');


      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_prec,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PR');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PR');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PR');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_systemprec,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'SYSTEM_PRECISION');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PR_SYSTEM');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PR_SISTEMA');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_canton,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'CT_SOURCE');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'KT_HERKUNFT');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'CT_ORIGINE');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_oid,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'OID');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'OID');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'OID');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_samplnum,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'NO_ECHANTILLON');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'PROBE_NR');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'NO_CAMPIONE');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_comment,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'REMARQUE');

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'BEMERKUNG');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'COMMENTO');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_repurl,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'RAPPORT');

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'BERICHT');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'RAPPORTO');


      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_taxonibch,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TAXON_IBCH');

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TAXON_IBCH');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'TAXON_IBCH');


      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_makroindex,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'MAKROINDEX');

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'MAKROINDEX');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'MAKROINDEX');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_spearindex,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'SPEARINDEX');

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'SPEARINDEX');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'SPEARINDEX');

      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_ibchindex,
            p_ptv_id);
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_fr.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'IBCHINDEX');

      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_de.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'IBCHINDEX');
      pkg_protocolmappingmassmap.p_writeifnotexist (
         l_reclanguage_it.lan_id,
         l_recprotocolmappingmassfield.pmm_id,
         'IBCHINDEX');



      NULL;
   END;
END pkg_migr_protocolmappingmassma;
/

