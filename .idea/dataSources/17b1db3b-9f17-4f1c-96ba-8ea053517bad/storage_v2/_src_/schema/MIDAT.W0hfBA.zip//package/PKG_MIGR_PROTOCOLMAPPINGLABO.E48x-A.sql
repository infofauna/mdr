create PACKAGE       pkg_migr_protocolmappinglabo
AS
   /******************************************************************************
      NAME:       pkg_migr_protocolmappinglabo
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_clearsyv_id; -- Cette procedure doit être appelé pour permeetre le rechargement complet du thésausus systématique

   PROCEDURE p_buildall_v1_v2; -- Cette procédure doit être appelé pour construire complétement le mapping

   PROCEDURE p_buildall_v1; -- Ajout de la version 1. La version 2 reste

   PROCEDURE p_build_syv_id_v1; -- Association de l'identifiant de la systématique
   PROCEDURE p_build_syv_id_v2; -- Association de l'identifiant de la systématique

   PROCEDURE p_build_syv_id_version_1_2 (
      p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE); -- Construction du mapping Excel

   PROCEDURE p_buildspearindexfactor_v1;      -- Association de l'indice spear
   PROCEDURE p_buildspearindexfactor_v2;      -- Association de l'indice spear

   PROCEDURE p_build_version1_2 (
      p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE);
END pkg_migr_protocolmappinglabo;
/

