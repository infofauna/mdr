create PACKAGE BODY       pkg_migr_ibch2019_neo
AS
    /******************************************************************************
       NAME:       pkg_MIGR_ibch2019_neo
       PURPOSE:    NEOZOAIRE

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
    ******************************************************************************/
    TYPE t_listneozoaire IS TABLE OF VARCHAR2 (128)
        INDEX BY VARCHAR2 (128);

    gbl_listneozoaire   t_listneozoaire;


    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_taxonisinhierarchy (
        p_syv_id   IN systvalue.syv_id%TYPE,
        p_name     IN systdesignation.syd_designation%TYPE)
        RETURN BOOLEAN
    /*---------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM (    SELECT syv_id, crf_code, syd_designation
                      FROM systdesignation syd1
                           INNER JOIN language lan1
                               ON lan1.lan_id = syd1.syd_lan_id
                           INNER JOIN systvalue syv1
                               ON syv1.syv_id = syd1.syd_syv_id
                           INNER JOIN codereference crf1
                               ON crf1.crf_id = syv1.syv_crf_id
                     WHERE lan1.lan_code = pkg_language.cst_lan_cde_latin
                CONNECT BY PRIOR syv_syv_id = syv_id
                START WITH syv_id = p_syv_id)
         WHERE TRIM (UPPER (syd_designation)) LIKE '%' || p_name || '%';

        IF l_count > 0
        THEN
            RETURN TRUE;
        ELSE
            RETURN FALSE;
        END IF;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_buildcode (p_taxon IN VARCHAR2)
        RETURN VARCHAR2
    /*---------------------------------------------------------------*/
    IS
        l_list     pkg_stringutil.t_listofvalue;
        l_indice   PLS_INTEGER;
        l_item1    VARCHAR2 (128);
        l_item2    VARCHAR2 (128);
    BEGIN
        l_list := pkg_stringutil.f_splitstring (p_taxon, ' ');
        l_indice := l_list.FIRST;

        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_item1 := TRIM (UPPER (l_list (l_indice)));
        l_indice := l_list.NEXT (l_indice);

        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_item2 := TRIM (UPPER (l_list (l_indice)));
        RETURN SUBSTR (l_item1, 1, 4) || '-' || SUBSTR (l_item2, 1, 4);
    END;



    /*---------------------------------------------------------------*/
    FUNCTION f_searchinsystematique (p_taxon IN VARCHAR2)
        RETURN systvalue.syv_id%TYPE
    /*---------------------------------------------------------------*/
    IS
        l_list               pkg_stringutil.t_listofvalue;
        l_item1              VARCHAR2 (128);
        l_item2              VARCHAR2 (128);
        l_indice             PLS_INTEGER;
        l_syv_id             systvalue.syv_id%TYPE;
        l_found              BOOLEAN := FALSE;

        CURSOR l_listnamefound (p_taxon_2 IN VARCHAR2)
        IS
            SELECT *
              FROM systdesignation INNER JOIN language ON lan_id = syd_lan_id
             WHERE     lan_code = pkg_language.cst_lan_cde_latin
                   AND TRIM (UPPER (syd_designation)) LIKE
                           '%' || p_taxon_2 || '%';

        l_reclistnamefound   l_listnamefound%ROWTYPE;
    BEGIN
        l_list := pkg_stringutil.f_splitstring (p_taxon, ' ');
        l_indice := l_list.FIRST;

        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_item1 := TRIM (UPPER (l_list (l_indice)));
        l_indice := l_list.NEXT (l_indice);

        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_item2 := TRIM (UPPER (l_list (l_indice)));
        DBMS_OUTPUT.put_line (
            'l_item1=' || l_item1 || ' l_item2:=' || l_item2);

        OPEN l_listnamefound (l_item2);

        LOOP
            FETCH l_listnamefound INTO l_reclistnamefound;

            EXIT WHEN l_listnamefound%NOTFOUND OR l_found;
            DBMS_OUTPUT.put_line (
                'syv_id=' || l_reclistnamefound.syd_syv_id || '  ' || l_item1);
            l_found :=
                f_taxonisinhierarchy (l_reclistnamefound.syd_syv_id, l_item1);

            IF l_found
            THEN
                l_syv_id := l_reclistnamefound.syd_syv_id;
            END IF;
        END LOOP;

        CLOSE l_listnamefound;



        RETURN l_syv_id;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;



    /*---------------------------------------------------------------*/
    PROCEDURE p_insertall
    /*---------------------------------------------------------------*/
    IS
        l_neo_id         neozoaire.neo_id%TYPE;
        l_recneozoaire   neozoaire%ROWTYPE;
        l_key            VARCHAR2 (128);
        l_sort           NUMBER := 0;
        l_code           neozoaire.neo_code%TYPE;
        l_syv_id         neozoaire.neo_syv_id%TYPE;
    BEGIN
        l_key := gbl_listneozoaire.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            l_sort := l_sort + 1;
            l_syv_id := f_searchinsystematique (l_key);

            IF NOT l_syv_id IS NULL
            THEN
                pkg_debug.p_write (
                    'pkg_migr_ibch2019_neo.p_insertall',
                       l_key
                    || ' -> '
                    || pkg_systdesignation.f_returnpathdesignation (l_syv_id,
                                                                    10,
                                                                    '/'));
                DBMS_OUTPUT.put_line (
                       l_key
                    || ' -> '
                    || pkg_systdesignation.f_returnpathdesignation (l_syv_id,
                                                                    10,
                                                                    '/'));
            ELSE
                DBMS_OUTPUT.put_line (l_key || ' -> not found');
                pkg_debug.p_write ('pkg_migr_ibch2019_neo.p_insertall',
                                   l_key || ' -> not found');
            END IF;


            l_recneozoaire := pkg_neozoaire.f_getrecordbydesignation (l_key);

            IF l_recneozoaire.neo_id IS NULL
            THEN
                l_code := f_buildcode (l_key);
                pkg_neozoaire.p_insert (l_code,
                                        l_sort,
                                        l_syv_id,
                                        l_key,                --l_designation,
                                        l_neo_id);
            END IF;

            l_key := gbl_listneozoaire.NEXT (l_key);
        END LOOP;

        NULL;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_buillistneozoaire
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        gbl_listneozoaire ('Astacus leptodactylus') :=
            'Astacus leptodactylus';
        gbl_listneozoaire ('Atyaephyra desmaresti') :=
            'Atyaephyra desmaresti';
        gbl_listneozoaire ('Barbronia weberi') := 'Barbronia weberi';
        gbl_listneozoaire ('Branchiura sowerbyi') := 'Branchiura sowerbyi';
        gbl_listneozoaire ('Caspiobdella fadejewi') :=
            'Caspiobdella fadejewi';
        gbl_listneozoaire ('Chelicorophium curvispinum') :=
            'Chelicorophium curvispinum';
        gbl_listneozoaire ('Chelicorophium robustum') :=
            'Chelicorophium robustum';
        gbl_listneozoaire ('Chelicorophium sowinskyi') :=
            'Chelicorophium sowinskyi';
        gbl_listneozoaire ('Cherax destructor') := 'Cherax destructor';
        gbl_listneozoaire ('Congeria leucophaeata') :=
            'Congeria leucophaeata';
        gbl_listneozoaire ('Corbicula fluminalis') := 'Corbicula fluminalis';
        gbl_listneozoaire ('Corbicula fluminea') := 'Corbicula fluminea';
        gbl_listneozoaire ('Cordylophora caspia') := 'Cordylophora caspia';
        gbl_listneozoaire ('Crangonyx pseudogracilis') :=
            'Crangonyx pseudogracilis';
        gbl_listneozoaire ('Craspedacusta sowerbii') :=
            'Craspedacusta sowerbii';
        gbl_listneozoaire ('Daphnia parvula') := 'Daphnia parvula';
        gbl_listneozoaire ('Dendrocoelum romanodanubiale') :=
            'Dendrocoelum romanodanubiale';
        gbl_listneozoaire ('Dikerogammarus bispinosus') :=
            'Dikerogammarus bispinosus';
        gbl_listneozoaire ('Dikerogammarus haemobaphes') :=
            'Dikerogammarus haemobaphes';
        gbl_listneozoaire ('Dikerogammarus robustus') :=
            'Dikerogammarus robustus';
        gbl_listneozoaire ('Dikerogammarus villosus') :=
            'Dikerogammarus villosus';
        gbl_listneozoaire ('Dreissena bugensis') := 'Dreissena bugensis';
        gbl_listneozoaire ('Dreissena polymorpha') := 'Dreissena polymorpha';
        gbl_listneozoaire ('Dugesia tigrina') := 'Dugesia tigrina';
        gbl_listneozoaire ('Echinogammarus berilloni') :=
            'Echinogammarus berilloni';
        gbl_listneozoaire ('Echinogammarus ischnus') :=
            'Echinogammarus ischnus';
        gbl_listneozoaire ('Echinogammarus trichiatus') :=
            'Echinogammarus trichiatus';
        gbl_listneozoaire ('Eriocheir sinensis') := 'Eriocheir sinensis';
        gbl_listneozoaire ('Eunapius carteri') := 'Eunapius carteri';
        gbl_listneozoaire ('Ferrissia clessiniana') :=
            'Ferrissia clessiniana';
        gbl_listneozoaire ('Gammarus roeseli') := 'Gammarus roeseli';
        gbl_listneozoaire ('Gammarus tigrinus') := 'Gammarus tigrinus';
        gbl_listneozoaire ('Gammarus varsoviensis') :=
            'Gammarus varsoviensis';
        gbl_listneozoaire ('Gyraulus parvus') := 'Gyraulus parvus';
        gbl_listneozoaire ('Haitia acuta') := 'Haitia acuta';
        gbl_listneozoaire ('Haitia heterostropha') := 'Haitia heterostropha';
        gbl_listneozoaire ('Hemimysis anomala') := 'Hemimysis anomala';
        gbl_listneozoaire ('Hypania invalida') := 'Hypania invalida';
        gbl_listneozoaire ('Hyalella azteca') := 'Hyalella azteca';
        gbl_listneozoaire ('Jaera istri') := 'Jaera istri';
        gbl_listneozoaire ('Katamysis warpachowski') :=
            'Katamysis warpachowski';
        gbl_listneozoaire ('Leptocerus lusitanicus') :=
            'Leptocerus lusitanicus';
        gbl_listneozoaire ('Limnomysis benedeni') := 'Limnomysis benedeni';
        gbl_listneozoaire ('Lithoglyphus naticoides') :=
            'Lithoglyphus naticoides';
        gbl_listneozoaire ('Menetus dilatatus') := 'Menetus dilatatus';
        gbl_listneozoaire ('Musculium transversum') :=
            'Musculium transversum';
        gbl_listneozoaire ('Obesogammarus crassus') :=
            'Obesogammarus crassus';
        gbl_listneozoaire ('Obesogammarus obesus') := 'Obesogammarus obesus';
        gbl_listneozoaire ('Orconectes immunis') := 'Orconectes immunis';
        gbl_listneozoaire ('Orconectes limosus') := 'Orconectes limosus';
        gbl_listneozoaire ('Pacifastacus leniusculus') :=
            'Pacifastacus leniusculus';
        gbl_listneozoaire ('Pectinatella magnifica') :=
            'Pectinatella magnifica';
        gbl_listneozoaire ('Pontogammarus robustoides') :=
            'Pontogammarus robustoides';
        gbl_listneozoaire ('Potamopyrgus antipodarum') :=
            'Potamopyrgus antipodarum';
        gbl_listneozoaire ('Proasellus coxalis') := 'Proasellus coxalis';
        gbl_listneozoaire ('Proasellus meridianus') :=
            'Proasellus meridianus';
        gbl_listneozoaire ('Procambarus clarkii') := 'Procambarus clarkii';
        gbl_listneozoaire ('Procambarus fallax') := 'Procambarus fallax';
        gbl_listneozoaire ('Procambarus spec.') := 'Procambarus spec.';
        gbl_listneozoaire ('Pseudosuccinea columella') :=
            'Pseudosuccinea columella';
        gbl_listneozoaire ('Rhithropanopeus harrisii') :=
            'Rhithropanopeus harrisii';
        gbl_listneozoaire ('Sinanodonta woodiana') := 'Sinanodonta woodiana';
        gbl_listneozoaire ('Theodoxus fluviatilis') :=
            'Theodoxus fluviatilis';
        gbl_listneozoaire ('Viviparus ater') := 'Viviparus ater';
        gbl_listneozoaire ('Viviparus viviparus') := 'Viviparus viviparus';
    END;
BEGIN
    p_buillistneozoaire;
END;
/

