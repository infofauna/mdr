create PACKAGE BODY       pkg_sampleloadcomment
AS
   /******************************************************************************
      NAME:       PKG_SAMPLELOADCOMMENT
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.07.2017      burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2017';


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_deleteby_sph_id (p_sph_id IN sampleloadcomment.slc_sph_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleloadcomment
            WHERE slc_sph_id = p_sph_id;
   END;
END pkg_sampleloadcomment;
/

