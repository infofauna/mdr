create trigger TR_BIF_IMPORTMASSMAPPINGHEADER
    before insert
    on IMPORTMASSMAPPINGHEADER
    for each row
DECLARE
BEGIN
   IF :new.IME_id IS NULL
   THEN
      :new.IME_id := seq_IIMPORTMASSMAPPINGHEADER.NEXTVAL;
   END IF;

   :new.IME_credate := SYSDATE;
   :new.IME_creuser := USER;
END TR_BIF_IMPORTMASSMAPPINGHEADER;

/

