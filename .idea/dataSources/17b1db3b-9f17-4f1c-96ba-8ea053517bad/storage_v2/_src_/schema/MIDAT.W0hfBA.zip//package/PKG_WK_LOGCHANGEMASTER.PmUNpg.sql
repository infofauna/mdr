create PACKAGE       pkg_wk_logchangemaster
AS
   /******************************************************************************
      NAME:       PKG_WK_LOGCHANGEDETAIL
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        21.03.2016      burrif       1. Created this package.
   ******************************************************************************/

   FUNCTION f_getversion
      RETURN VARCHAR2;

  PROCEDURE p_write (
      p_sph_id              IN     wk_logchangemaster.wkm_sph_id%TYPE,
      p_locality            IN     wk_logchangemaster.wkm_locality%TYPE,
      p_watercourse         IN     wk_logchangemaster.wkm_watercourse%TYPE,
      p_currentmkivalue     IN     wk_logchangemaster.wkm_currentmkivalue%TYPE,
      p_currentibchvalue    IN     wk_logchangemaster.wkm_currentibchvalue%TYPE,
      p_currentspearvalue   IN     wk_logchangemaster.wkm_currentspearvalue%TYPE,
      p_newmkivalue         IN     wk_logchangemaster.wkm_newmkivalue%TYPE,
      p_newibchvalue        IN     wk_logchangemaster.wkm_newibchvalue%TYPE,
      p_newspearvalue       IN     wk_logchangemaster.wkm_newspearvalue%TYPE,
      p_currentmkiclass     IN     wk_logchangemaster.wkm_currentmkiclass%TYPE,
      p_currentibchclass    IN     wk_logchangemaster.wkm_currentibchclass%TYPE,
      p_currentspearclass   IN     wk_logchangemaster.wkm_currentspearclass%TYPE,
      p_newmkiclass         IN     wk_logchangemaster.wkm_newmkiclass%TYPE,
      p_newibchclass        IN     wk_logchangemaster.wkm_newibchclass%TYPE,
      p_newspearclass       IN     wk_logchangemaster.wkm_newspearclass%TYPE,
      p_wkm_id                 OUT wk_logchangemaster.wkm_id%TYPE);

   PROCEDURE p_updateindexes (
      p_wkm_id          IN wk_logchangemaster.wkm_id%TYPE,
      p_newmkivalue     IN wk_logchangemaster.wkm_newmkivalue%TYPE,
      p_newibchvalue    IN wk_logchangemaster.wkm_newibchvalue%TYPE,
      p_newspearvalue   IN wk_logchangemaster.wkm_newspearvalue%TYPE);
      
        PROCEDURE p_updatenewclass (
      p_wkm_id              IN wk_logchangemaster.wkm_id%TYPE,
      p_newmkiclass     IN wk_logchangemaster.wkm_newmkiclass%TYPE,
      p_newibchclass    IN wk_logchangemaster.wkm_newibchclass%TYPE,
      p_newspearclass   IN wk_logchangemaster.wkm_newspearclass%TYPE);
      
      PROCEDURE p_updatecurrentclass (
      p_wkm_id              IN wk_logchangemaster.wkm_id%TYPE,
      p_currentmkiclass     IN wk_logchangemaster.wkm_currentmkiclass%TYPE,
      p_currentibchclass    IN wk_logchangemaster.wkm_currentibchclass%TYPE,
      p_currentspearclass   IN wk_logchangemaster.wkm_currentspearclass%TYPE);

   PROCEDURE p_deleteall;
END pkg_wk_logchangemaster;
/

