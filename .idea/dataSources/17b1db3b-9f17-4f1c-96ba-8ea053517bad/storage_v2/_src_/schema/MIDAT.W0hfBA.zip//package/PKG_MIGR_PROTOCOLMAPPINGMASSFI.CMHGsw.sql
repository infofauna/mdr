create PACKAGE       pkg_migr_protocolmappingmassfi
AS
   /******************************************************************************
      NAME:       pkg_migr_protocolmappingmassfi
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
      1.1        13.09.2017      burrif       2. MIDAT Version 2
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_build (ptv_id IN protocolmappingmassfield.pmm_ptv_id%TYPE);

   PROCEDURE p_updateversion_2;
END pkg_migr_protocolmappingmassfi;
/

