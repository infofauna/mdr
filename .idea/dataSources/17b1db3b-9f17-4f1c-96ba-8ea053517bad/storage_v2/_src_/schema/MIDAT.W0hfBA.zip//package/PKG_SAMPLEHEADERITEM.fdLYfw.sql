create PACKAGE       pkg_sampleheaderitem
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEHEADERITEM
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.10.2013   F.Burri          1. Created this package.
   ******************************************************************************/

   cst_typecodefromtableperson   CONSTANT CHAR (1) := 'P';
   cst_typecodefromexcelform     CONSTANT CHAR (1) := 'X';

   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecordfromlaboratory (
      p_sph_id         IN sampleheader.sph_id%TYPE,
      p_midathditmty   IN codevalue.cvl_code%TYPE)
      RETURN sampleheaderitem%ROWTYPE;

   PROCEDURE p_writeconditionnaly (
      p_sph_id                IN     sampleheaderitem.shm_sph_id%TYPE,
      p_lan_id                IN     sampleheaderitem.shm_lan_id%TYPE,
      p_cvl_id_midathditmty   IN     sampleheaderitem.shm_cvl_id_midathditmty%TYPE,
      p_ptv_id                IN     sampleheaderitem.shm_ptv_id%TYPE,
      p_typecode              IN     sampleheaderitem.shm_typecode%TYPE,
      p_item                  IN     sampleheaderitem.shm_item%TYPE,
      p_per_id                IN     sampleheaderitem.shm_per_id%TYPE,
      p_usr_id                IN     sampleheaderitem.shm_usr_id_create%TYPE,
      p_id                       OUT sampleheaderitem.shm_id%TYPE);

   FUNCTION f_getrecordwithtypeandlanid (
      p_sph_id         IN sampleheaderitem.shm_sph_id%TYPE,
      p_midathditmty   IN codevalue.cvl_code%TYPE,
      p_lan_id         IN sampleheaderitem.shm_lan_id%TYPE)
      RETURN sampleheaderitem%ROWTYPE;

   FUNCTION f_get_typecodefromtableperson
      RETURN VARCHAR2;

   FUNCTION f_get_typecodefromexcelform
      RETURN VARCHAR2;

   FUNCTION f_getrecord (p_shm_id IN sampleheaderitem.shm_id%TYPE)
      RETURN sampleheaderitem%ROWTYPE;

   PROCEDURE p_tr_bif_sampleheaderitem (
      p_newrec IN OUT sampleheaderitem%ROWTYPE);

   PROCEDURE p_tr_buf_sampleheaderitem (
      p_oldrec   IN     sampleheaderitem%ROWTYPE,
      p_newrec   IN OUT sampleheaderitem%ROWTYPE);


   PROCEDURE p_write (
      p_sph_id                IN     sampleheaderitem.shm_sph_id%TYPE,
      p_lan_id                IN     sampleheaderitem.shm_lan_id%TYPE,
      p_cvl_id_midathditmty   IN     sampleheaderitem.shm_cvl_id_midathditmty%TYPE,
      p_ptv_id                IN     sampleheaderitem.shm_ptv_id%TYPE,
      p_typecode              IN     sampleheaderitem.shm_typecode%TYPE,
      p_item                  IN     sampleheaderitem.shm_item%TYPE,
      p_per_id                IN     sampleheaderitem.shm_per_id%TYPE,
      p_usr_id                IN     sampleheaderitem.shm_usr_id_create%TYPE,
      p_id                       OUT sampleheaderitem.shm_id%TYPE);

   PROCEDURE p_deleteby_sph_id (p_sph_id IN sampleheaderitem.shm_sph_id%TYPE);

   PROCEDURE p_deleteby_ptv_id (
      p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE,
      p_ptv_id   IN sampleheader.sph_ptv_id%TYPE);

   PROCEDURE p_deleteby_cvl_id_protocoltype (
      p_sph_id                IN sampleheaderitem.shm_sph_id%TYPE,
      p_cvl_id_protocoltype   IN sampleheaderitem.shm_cvl_id_midatproto%TYPE);
END pkg_sampleheaderitem;
/

