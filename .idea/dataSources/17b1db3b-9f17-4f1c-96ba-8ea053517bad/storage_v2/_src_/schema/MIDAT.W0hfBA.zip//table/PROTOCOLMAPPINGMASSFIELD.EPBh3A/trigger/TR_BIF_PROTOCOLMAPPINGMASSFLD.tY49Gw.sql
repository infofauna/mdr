create trigger TR_BIF_PROTOCOLMAPPINGMASSFLD
    before insert
    on PROTOCOLMAPPINGMASSFIELD
    for each row
DECLARE
BEGIN
   IF :new.PMM_id IS NULL
   THEN
      :new.PMM_id := seq_PROTOCOLMAPPINGMASSFIELD.NEXTVAL;
   END IF;

   :new.PMM_credate := SYSDATE;
   :new.PMM_creuser := USER;
END TR_BIF_PROTOCOLMAPPINGMASSFLD;

/

