create PACKAGE       pkg_migr_spear2019_test
AS
    /******************************************************************************
      NAME:       PKG_MIGR_SPEAR2019_TEST
      PURPOSE:     Test

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package
   ******************************************************************************/

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2020';


    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_test;
END pkg_migr_spear2019_test;
/

