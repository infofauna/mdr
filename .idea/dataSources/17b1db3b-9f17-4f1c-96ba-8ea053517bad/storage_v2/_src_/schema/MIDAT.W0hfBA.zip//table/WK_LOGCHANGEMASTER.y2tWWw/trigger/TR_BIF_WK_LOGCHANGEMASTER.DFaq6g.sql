create trigger TR_BIF_WK_LOGCHANGEMASTER
    before insert
    on WK_LOGCHANGEMASTER
    for each row
BEGIN

   IF :NEW.WKM_ID IS NULL THEN
   SELECT seq_wk_logchangemaster.NEXTVAL INTO :NEW.WKM_ID FROM dual;
  END IF;

END TR_BIF_WK_LOGCHANGEMASTER;

/

