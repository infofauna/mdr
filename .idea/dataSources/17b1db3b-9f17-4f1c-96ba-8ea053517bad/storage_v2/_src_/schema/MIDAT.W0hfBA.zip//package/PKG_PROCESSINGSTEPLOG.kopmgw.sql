create PACKAGE       pkg_processingsteplog
AS
   /******************************************************************************
      NAME:       PKG_PROCESSINGSTEPLOG
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_measureunitrowcount   CONSTANT processingsteplog.psl_measureunit%TYPE
                                         := 'ROWCOUNT' ;
   cst_measureunitblobsize   CONSTANT processingsteplog.psl_measureunit%TYPE
                                         := 'BLOBSIZE' ;

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_clearmeasuredata;

   PROCEDURE p_setprocessingsteplog (p_flag IN BOOLEAN);

   PROCEDURE p_setmeasuredata (
      p_measurevalue   IN processingsteplog.psl_measurevalue%TYPE,
      p_measureunit    IN processingsteplog.psl_measureunit%TYPE);

   PROCEDURE p_parsestep (
      p_recprocessingstep      processingstep%ROWTYPE,
      p_pid_id              IN processingsteplog.psl_pid_id%TYPE);
END pkg_processingsteplog;
/

