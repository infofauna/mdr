create PACKAGE BODY       pkg_validateprotocollabo
AS
    /******************************************************************************
       NAME:       PKG_VALIDATEPROTOCOLLABO
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        11.10.2013      burrif       1. Created this package.
       1.1        19.08.2020      burrif       2. Externalisation Jav (indice calculé dans PKG_VALIDATE)
    ******************************************************************************/


    cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.1, août 2020';


    cst_minvalue         CONSTANT NUMBER := 0;
    cst_maxvalue         CONSTANT NUMBER := 99999;

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_logunexpectederror (
        p_iph_id       IN importprotocolheader.iph_id%TYPE,
        p_fieldname    IN importprotocollog.ipo_fieldname%TYPE,
        p_modulename   IN VARCHAR2)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        pkg_importprotocollog.p_writelog (p_iph_id,
                                          NULL,
                                          pkg_exception.cst_unexpectederror,
                                          p_fieldname,
                                          p_modulename);
    END;

    PROCEDURE p_getrecprotocolmappinglabo (
        p_reciimportprotocollabo   IN     importprotocollabo%ROWTYPE,
        p_recprototolmappinglabo      OUT protocolmappinglabo%ROWTYPE,
        p_returnstatus                OUT NUMBER)
    /*----------------------------------------------------------------------------------*/
    IS
        l_module   VARCHAR2 (1024);
    BEGIN
        l_module :=
               'pkg_protocolmappinglabo.f_getrecord ('
            || TO_CHAR (p_reciimportprotocollabo.ipl_ptl_id)
            || ')';
        p_recprototolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecord (
                p_reciimportprotocollabo.ipl_ptl_id);


        IF p_recprototolmappinglabo.ptl_id IS NULL
        THEN
            p_logunexpectederror (p_reciimportprotocollabo.ipl_iph_id,
                                  NULL,
                                  l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        p_returnstatus := pkg_constante.cst_returnstatusok;
    END;

    /*-------------------------------------------------*/
    PROCEDURE p_calculatespearindex (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE)
    /*------------------------------------------------*/
    IS
        l_date                           DATE;
        l_abondanceflag                  codevalue.cvl_code%TYPE;
        l_recavaliabilitycalendarspear   avaliabilitycalendar%ROWTYPE;
        l_reccodevalueindicetypespear    codevalue%ROWTYPE;
        l_spearindice                    NUMBER;
    BEGIN
        l_reccodevalueindicetypespear :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_spear);
        l_date :=
            pkg_datatype.f_validatedate (
                p_importprotocolheader.iph_observationdatetxt);

        IF NOT p_importprotocolheader.iph_absolutenumberflag IS NULL
        THEN
            l_abondanceflag := pkg_indice_utility.cst_abondanceflag_absolu;
        ELSE
            l_abondanceflag := pkg_indice_utility.cst_abondanceflag_class;
        END IF;

        pkg_spear.p_maincompute (p_importprotocolheader, NULL, l_spearindice);

        IF NOT l_spearindice IS NULL
        THEN
            /* La vérification de la validité de la fenêtre d'observation est réalisé dans PKG_VALIDATEPROTOCOLHEADER */
            l_recavaliabilitycalendarspear :=
                pkg_avaliabilitycalendar.f_getrecordbyindicetypeanddate (
                    l_reccodevalueindicetypespear.cvl_id,
                    l_date,
                    p_importprotocolheader.iph_elevation);
            pkg_importprotocolheader.p_update_spearindexnewvalue (
                p_importprotocolheader.iph_id,
                l_spearindice,
                l_recavaliabilitycalendarspear.iac_cvl_id_midatwindow);

            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,                                                -- IMH_ID
                pkg_exception.cst_displayindexcategory,
                NULL,                                            -- Field name
                TO_CHAR (l_spearindice, '9999'),
                pkg_codevalue.cst_midatindice_spear,
                pkg_codevalue.cst_midatindice_spear,
                TO_CHAR (l_spearindice, '9999'),
                pkg_codevalue.cst_midatindice_spear);
        END IF;

        NULL;
    END;

    /*-------------------------------------------------*/
    PROCEDURE p_calculatespear2019index (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE)
    /*------------------------------------------------*/
    IS
        l_date                           DATE;

        l_recavaliabilitycalendarspear   avaliabilitycalendar%ROWTYPE;
        l_reccodevalueindicetypespear    codevalue%ROWTYPE;
        l_spearindice                    NUMBER;
    BEGIN
        l_reccodevalueindicetypespear :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_spear);
        l_date :=
            pkg_datatype.f_validatedate (
                p_importprotocolheader.iph_observationdatetxt);



        pkg_spear2019.p_maincompute (p_importprotocolheader, NULL);
        l_spearindice := pkg_spear2019.f_getspear;

        IF NOT l_spearindice IS NULL
        THEN
            /* La vérification de la validité de la fenêtre d'observation est réalisé dans PKG_VALIDATEPROTOCOLHEADER */
            l_recavaliabilitycalendarspear :=
                pkg_avaliabilitycalendar.f_getrecordbyindicetypeanddate (
                    l_reccodevalueindicetypespear.cvl_id,
                    l_date,
                    p_importprotocolheader.iph_elevation);
            pkg_importprotocolheader.p_update_spearindexnewvalue (
                p_importprotocolheader.iph_id,
                l_spearindice,
                l_recavaliabilitycalendarspear.iac_cvl_id_midatwindow);

            IF ROUND (l_spearindice) !=
               ROUND (p_importprotocolheader.iph_spearvalue)
            THEN
                pkg_importprotocollog.p_writelog (
                    p_importprotocolheader.iph_id,
                    NULL,                                            -- IMH_ID
                    pkg_exception.cst_indicevaluemissmatch,
                    NULL,                                        -- Field name
                    TO_CHAR (l_spearindice, '9999'),
                    pkg_codevalue.cst_midatindice_spear,
                    TO_CHAR (p_importprotocolheader.iph_spearvalue, '9999'));
            END IF;
        END IF;


        NULL;
    END;

    /*-------------------------------------------------*/
    PROCEDURE p_calculateibchindex (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE)
    /*------------------------------------------------*/
    IS
        l_date                          DATE;

        l_recavaliabilitycalendaribch   avaliabilitycalendar%ROWTYPE;
        l_reccodevalueindicetypeibch    codevalue%ROWTYPE;
        l_ibchindice                    NUMBER;
        l_ibchvalueprovide              NUMBER;
    BEGIN
        l_reccodevalueindicetypeibch :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_ibch);
        l_date :=
            pkg_datatype.f_validatedate (
                p_importprotocolheader.iph_observationdatetxt);



        pkg_ibch.p_maincompute (p_importprotocolheader, NULL, l_ibchindice);

        IF l_ibchindice = 0
        THEN
            -- L'indice IBCH est défini avec la valeur 0 en raison de l'absence significative de taxons indicateurs
            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,                                                -- IMH_ID
                pkg_exception.cst_midatnotaxonindicator,
                NULL);
            RETURN;
        END IF;

        IF NOT l_ibchindice IS NULL
        THEN
            /* La vérification de la validité de la fenêtre d'observation est réalisé dans PKG_VALIDATEPROTOCOLHEADER */
            l_recavaliabilitycalendaribch :=
                pkg_avaliabilitycalendar.f_getrecordbyindicetypeanddate (
                    l_reccodevalueindicetypeibch.cvl_id,
                    l_date,
                    p_importprotocolheader.iph_elevation);
            pkg_importprotocolheader.p_update_ibchnewvalue (
                p_importprotocolheader.iph_id,
                l_ibchindice,
                l_recavaliabilitycalendaribch.iac_cvl_id_midatwindow);

            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,                                                -- IMH_ID
                pkg_exception.cst_displayindexcategory,
                NULL,                                            -- Field name
                TO_CHAR (l_ibchindice, '9999'),
                pkg_codevalue.cst_midatindice_ibch,
                pkg_codevalue.cst_midatindice_ibch,
                TO_CHAR (l_ibchindice, '9999'),
                pkg_codevalue.cst_midatindice_ibch);
        END IF;

        l_ibchvalueprovide :=
            pkg_datatype.f_validatedouble (
                p_importprotocolheader.iph_ibchvalue);

        IF NOT l_ibchvalueprovide IS NULL
        THEN
            IF l_ibchindice != l_ibchvalueprovide
            THEN
                pkg_importprotocollog.p_writelog (
                    p_importprotocolheader.iph_id,
                    NULL,
                    pkg_exception.cst_indicevaluemissmatch,
                    NULL,                                        -- Filed name
                    TO_CHAR (l_ibchvalueprovide),
                    pkg_codevalue.cst_midatindice_ibch,
                    TO_CHAR (l_ibchindice));
            END IF;
        END IF;

        NULL;
    END;

    /*-------------------------------------------------*/
    PROCEDURE p_calculateibch2019index (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE)
    /*------------------------------------------------*/
    IS
        l_date                          DATE;

        l_recavaliabilitycalendaribch   avaliabilitycalendar%ROWTYPE;
        l_reccodevalueindicetypeibch    codevalue%ROWTYPE;
        l_ibchindice                    NUMBER;
        l_ibchvalueprovide              NUMBER;
    BEGIN
        DBMS_OUTPUT.put_line ('p_calculateibch2019index');
        l_reccodevalueindicetypeibch :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_ibch);
        l_date :=
            pkg_datatype.f_validatedate (
                p_importprotocolheader.iph_observationdatetxt);



        pkg_ibch2019.p_maincompute (p_importprotocolheader, NULL);
        l_ibchindice := pkg_ibch2019.f_getibch;
        DBMS_OUTPUT.put_line ('l_ibchindice=' || l_ibchindice);

        IF l_ibchindice = 0
        THEN
            -- L'indice IBCH est défini avec la valeur 0 en raison de l'absence significative de taxons indicateurs
            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,                                                -- IMH_ID
                pkg_exception.cst_midatnotaxonindicator,
                NULL);
            RETURN;
        END IF;

        IF NOT l_ibchindice IS NULL
        THEN
            /* La vérification de la validité de la fenêtre d'observation est réalisé dans PKG_VALIDATEPROTOCOLHEADER */
            l_recavaliabilitycalendaribch :=
                pkg_avaliabilitycalendar.f_getrecordbyindicetypeanddate (
                    l_reccodevalueindicetypeibch.cvl_id,
                    l_date,
                    p_importprotocolheader.iph_elevation);
            pkg_importprotocolheader.p_update_computed_data (
                p_importprotocolheader.iph_id,
                l_ibchindice,
                l_recavaliabilitycalendaribch.iac_cvl_id_midatwindow,
                pkg_ibch2019.f_gettaxonindicateur,        -- p_taxonindicateur
                pkg_ibch2019.f_getibchrobust,             --      p_ibchrobust
                pkg_ibch2019.f_getclassevariete,       --      p_classevariete
                pkg_ibch2019.f_getclassevariete_corr, --     p_classevariete_corr
                pkg_ibch2019.f_getclassevarieterobust, --      p_classevarieterobust
                pkg_ibch2019.f_getclassevarieterobust_corr, --      p_classevarieterobust_corr
                pkg_ibch2019.f_getclassevariete_final, --      p_classevariete_final
                pkg_ibch2019.f_getclassevarieterobust_final, --      p_classevarieterobust_final
                pkg_ibch2019.f_gettaxonfrequencesum, --      p_taxonfrequencesum
                pkg_ibch2019.f_getgimax,                       --      p_gimax
                pkg_ibch2019.f_getgimaxrobust,           --      p_gimaxrobust
                pkg_ibch2019.f_getgi_final,                  --     p_gi_final
                pkg_ibch2019.f_getgirobust_final,      --     p_girobust_final
                pkg_ibch2019.f_getsumfamily,               --      p_sumfamily
                pkg_ibch2019.f_getsumfamilycorrected, --     p_sumfamilycorrected
                pkg_ibch2019.f_getsumfamilyrobust,     --    p_sumfamilyrobust
                pkg_ibch2019.f_getsumfamilyrobustcorrected, --    p_sumfamilyrobustcorrected
                pkg_ibch2019.f_getephemeropteracounter, --   p_ephemeropteracounter
                pkg_ibch2019.f_getplecopteracounter, --    p_plecopteracounter
                pkg_ibch2019.f_gettrichopteracounter); --   p_tricopteracounter



            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,                                                -- IMH_ID
                pkg_exception.cst_displayindexcategory,
                NULL,                                            -- Field name
                TO_CHAR (l_ibchindice, '9990.999'),
                pkg_codevalue.cst_midatindice_ibch2019,
                pkg_codevalue.cst_midatindice_ibch2019,
                TO_CHAR (l_ibchindice, '9990.999'),
                pkg_codevalue.cst_midatindice_ibch2019);
        END IF;

        l_ibchvalueprovide :=
            pkg_datatype.f_validatedouble (
                p_importprotocolheader.iph_ibchvalue);

        IF NOT l_ibchvalueprovide IS NULL
        THEN
            IF ROUND (l_ibchindice, 2) != ROUND (l_ibchvalueprovide, 2)
            THEN
                pkg_importprotocollog.p_writelog (
                    p_importprotocolheader.iph_id,
                    NULL,
                    pkg_exception.cst_indicevaluemissmatch,
                    NULL,                                        -- Filed name
                    TO_CHAR (l_ibchvalueprovide, '9990.99'),
                    pkg_codevalue.cst_midatindice_ibch2019,
                    TO_CHAR (l_ibchindice, '9990.99'));
            END IF;
        END IF;

        NULL;
    END;

    /*-------------------------------------------------*/
    PROCEDURE p_compute_allindice (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE)
    /*------------------------------------------------*/
    IS
        l_recprotocolversion   protocolversion%ROWTYPE;
    BEGIN
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                p_importprotocolheader.iph_ptv_id);
        DBMS_OUTPUT.put_line (
               ' Version:'
            || pkg_datatype.f_validatedouble (
                   l_recprotocolversion.ptv_version));

        IF pkg_datatype.f_validatedouble (l_recprotocolversion.ptv_version) <
           pkg_ibch2019.cst_startprotversion_ibch2019
        THEN
            p_calculateibchindex (p_importprotocolheader);
        ELSE
            pkg_debug.p_write (
                'PKG_VALIDATEPROTOCOLLABO.p_compute_allindice',
                'p_calculateibch2019index');
            p_calculateibch2019index (p_importprotocolheader);
        END IF;

        IF pkg_datatype.f_validatedouble (l_recprotocolversion.ptv_version) <
           pkg_spear2019.cst_startprotversion_spear2019
        THEN
            p_calculatespearindex (p_importprotocolheader);
        ELSE
            p_calculatespear2019index (p_importprotocolheader);
        END IF;
    END;

    /*-------------------------------------------------*/
    PROCEDURE p_compute_allindiceold (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE)
    /*------------------------------------------------*/
    IS
        /* L'indice MAKROINDEX NE doit pas être calculé pour les protocole de laboratoire.
            Le niveau taxonomique de ce type de protocole est la FAMILLE alors que le
            MAKROINDEX s'appuie sur le GENRE
            cf: Téléphone avec Y.G. le 14.08.2014 */
        l_abondanceflag                  codevalue.cvl_code%TYPE;
        l_ibchvalue                      importprotocolheader.iph_ibchnewvalue%TYPE;
        l_ibchvalueprovide               importprotocolheader.iph_ibchnewvalue%TYPE;
        l_spearvalue                     importprotocolheader.iph_spearindexnewvalue%TYPE;
        l_mkivalue                       importprotocolheader.iph_makroindexnewvalue%TYPE;
        l_status                         NUMBER;
        l_date                           DATE;
        l_recavaliabilitycalendaribch    avaliabilitycalendar%ROWTYPE;
        l_recavaliabilitycalendarspear   avaliabilitycalendar%ROWTYPE;
        l_recavaliabilitycalendarmki     avaliabilitycalendar%ROWTYPE;
        l_reccodevalueindicetypeibch     codevalue%ROWTYPE;
        l_reccodevalueindicetypespear    codevalue%ROWTYPE;
        l_reccodevalueindicetypemki      codevalue%ROWTYPE;
    BEGIN
        l_reccodevalueindicetypeibch :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_ibch);
        l_reccodevalueindicetypespear :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_spear);
        l_date :=
            pkg_datatype.f_validatedate (
                p_importprotocolheader.iph_observationdatetxt);

        IF NOT p_importprotocolheader.iph_absolutenumberflag IS NULL
        THEN
            l_abondanceflag := pkg_indice_utility.cst_abondanceflag_absolu;
        ELSE
            l_abondanceflag := pkg_indice_utility.cst_abondanceflag_class;
        END IF;

        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLLABO.p_compute_allindice',
                           'Start IBCH');

        l_ibchvalue :=
            pkg_indice_utility.f_computeibchfromimport (
                p_importprotocolheader.iph_id,
                l_abondanceflag);

        IF NOT l_ibchvalue IS NULL
        THEN
            /* La vérification de la validité de la fenêtre d'observation est réalisé dans PKG_VALIDATEPROTOCOLHEADER */
            l_recavaliabilitycalendaribch :=
                pkg_avaliabilitycalendar.f_getrecordbyindicetypeanddate (
                    l_reccodevalueindicetypeibch.cvl_id,
                    l_date,
                    p_importprotocolheader.iph_elevation);
            pkg_importprotocolheader.p_update_ibchnewvalue (
                p_importprotocolheader.iph_id,
                l_ibchvalue,
                l_recavaliabilitycalendarspear.iac_cvl_id_midatwindow);


            IF l_ibchvalue = 0
            THEN
                -- L'indice IBCH est défini avec la valeur 0 en raison de l'absence significative de taxons indicateurs
                pkg_importprotocollog.p_writelog (
                    p_importprotocolheader.iph_id,
                    NULL,                                            -- IMH_ID
                    pkg_exception.cst_midatnotaxonindicator,
                    NULL);
            END IF;

            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,                                                -- IMH_ID
                pkg_exception.cst_displayindexcategory,
                NULL,                                            -- Field name
                TO_CHAR (l_ibchvalue, '9999'),
                pkg_codevalue.cst_midatindice_ibch,
                pkg_codevalue.cst_midatindice_ibch,
                TO_CHAR (l_ibchvalue, '9999'),
                pkg_codevalue.cst_midatindice_ibch);
        END IF;

        l_ibchvalueprovide :=
            pkg_datatype.f_validatedouble (
                p_importprotocolheader.iph_ibchvalue);

        IF NOT l_ibchvalueprovide IS NULL
        THEN
            IF l_ibchvalue != l_ibchvalueprovide
            THEN
                pkg_importprotocollog.p_writelog (
                    p_importprotocolheader.iph_id,
                    NULL,
                    pkg_exception.cst_indicevaluemissmatch,
                    NULL,                                        -- Filed name
                    TO_CHAR (l_ibchvalueprovide),
                    pkg_codevalue.cst_midatindice_ibch,
                    TO_CHAR (l_ibchvalue));
            END IF;
        END IF;

        /* Cette procedure copie aussi les données IBCH dans le BUFFER SPEAR */
        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLLABO.p_compute_allindice',
                           'Start SPEAR');
        pkg_indice_utility.p_checkifspearcanbecomputed (
            p_importprotocolheader.iph_id,
            l_status);

        IF l_status = pkg_constante.cst_returnstatusok
        THEN
            l_spearvalue :=
                pkg_indice_utility.f_computespearfrommemory (l_abondanceflag);
        ELSE
            l_spearvalue := NULL;
        END IF;

        IF NOT l_spearvalue IS NULL
        THEN
            /* La vérification de la validité de la fenêtre d'observation est réalisé dans PKG_VALIDATEPROTOCOLHEADER */
            l_recavaliabilitycalendarspear :=
                pkg_avaliabilitycalendar.f_getrecordbyindicetypeanddate (
                    l_reccodevalueindicetypespear.cvl_id,
                    l_date,
                    p_importprotocolheader.iph_elevation);
            pkg_importprotocolheader.p_update_spearindexnewvalue (
                p_importprotocolheader.iph_id,
                l_spearvalue,
                l_recavaliabilitycalendarspear.iac_cvl_id_midatwindow);

            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,                                                -- IMH_ID
                pkg_exception.cst_displayindexcategory,
                NULL,                                            -- Field name
                TO_CHAR (l_spearvalue, '9999'),
                pkg_codevalue.cst_midatindice_spear,
                pkg_codevalue.cst_midatindice_spear,
                TO_CHAR (l_spearvalue, '9999'),
                pkg_codevalue.cst_midatindice_spear);
        END IF;

        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLLABO.p_compute_allindice',
                           'Start MKI');
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_validatedetail (
        p_iph_id         IN     importprotocollog.ipo_iph_id%TYPE,
        p_usr_id         IN     importprotocollabo.ipl_usr_id_create%TYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------*/
    IS
        CURSOR l_cursorimportprotocollabo IS
            SELECT *
              FROM importprotocollabo
             WHERE ipl_iph_id = p_iph_id AND NOT ipl_value IS NULL
            FOR UPDATE;

        l_reccursorimportprotocollabo   l_cursorimportprotocollabo%ROWTYPE;
        l_recprotocolmappinglabo        protocolmappinglabo%ROWTYPE;
        l_recimportprotocolheader       importprotocolheader%ROWTYPE;
        l_returnstatus                  NUMBER;
        l_number                        NUMBER;
        l_ok                            BOOLEAN;
        l_ibchvalue                     NUMBER;
        l_ibchvalueprovide              NUMBER;
        l_abondanceflag                 VARCHAR2 (12);
        l_recavaliabilitycalendar       avaliabilitycalendar%ROWTYPE;
        l_reccodevalueindicetypeibch    codevalue%ROWTYPE;
        l_reccodevalueindicetypespear   codevalue%ROWTYPE;
        l_date                          DATE;
        l_indice                        PLS_INTEGER;
        l_status                        NUMBER;
        l_valueindicespear              NUMBER;
        l_recbiologicalstate            biologicalstate%ROWTYPE;
        l_category                      VARCHAR2 (256);
        l_listcategory                  VARCHAR2 (1024);
        l_computeindice                 BOOLEAN := TRUE;
    BEGIN
        l_reccodevalueindicetypeibch :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_ibch);
        l_reccodevalueindicetypespear :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_spear);
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);
        p_returnstatus := pkg_constante.cst_returnstatusok;

        OPEN l_cursorimportprotocollabo;

        LOOP
            FETCH l_cursorimportprotocollabo
                INTO l_reccursorimportprotocollabo;

            EXIT WHEN l_cursorimportprotocollabo%NOTFOUND;
            l_ok := TRUE;
            l_number :=
                pkg_datatype.f_validatedouble (
                    l_reccursorimportprotocollabo.ipl_value);

            IF l_number IS NULL
            THEN
                p_getrecprotocolmappinglabo (l_reccursorimportprotocollabo,
                                             l_recprotocolmappinglabo,
                                             l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    p_returnstatus := l_returnstatus;
                    RETURN;
                END IF;

                l_ok := FALSE;
                pkg_importprotocollog.p_writelog (
                    p_iph_id,
                    NULL,
                    pkg_exception.cst_numvalueinvalid,
                    NULL,                                        -- Filed name
                    l_reccursorimportprotocollabo.ipl_value,
                    l_recprotocolmappinglabo.ptl_taxa,
                    pkg_stringutil.f_buildexcelcellref (
                        l_recprotocolmappinglabo.ptl_cellrowvalue,
                        l_recprotocolmappinglabo.ptl_cellcolumnvalue));
            END IF;

            IF l_number < cst_minvalue OR l_number > cst_maxvalue
            THEN
                p_getrecprotocolmappinglabo (l_reccursorimportprotocollabo,
                                             l_recprotocolmappinglabo,
                                             l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    p_returnstatus := l_returnstatus;
                    RETURN;
                END IF;

                l_ok := FALSE;
                pkg_importprotocollog.p_writelog (
                    p_iph_id,
                    NULL,
                    pkg_exception.cst_numberoutofrange,
                    NULL,                                        -- Filed name
                    l_reccursorimportprotocollabo.ipl_value,
                    pkg_stringutil.f_buildexcelcellref (
                        l_recprotocolmappinglabo.ptl_cellrowvalue,
                        l_recprotocolmappinglabo.ptl_cellcolumnvalue),
                    l_recprotocolmappinglabo.ptl_taxa,
                    cst_minvalue,
                    cst_maxvalue);
            END IF;

            IF l_number != ROUND (l_number, 0)
            THEN
                p_getrecprotocolmappinglabo (l_reccursorimportprotocollabo,
                                             l_recprotocolmappinglabo,
                                             l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    p_returnstatus := l_returnstatus;
                    RETURN;
                END IF;

                l_ok := FALSE;
                pkg_importprotocollog.p_writelog (
                    p_iph_id,
                    NULL,
                    pkg_exception.cst_integeronly,
                    NULL,                                        -- Filed name
                    l_reccursorimportprotocollabo.ipl_value,
                    pkg_stringutil.f_buildexcelcellref (
                        l_recprotocolmappinglabo.ptl_cellrowvalue,
                        l_recprotocolmappinglabo.ptl_cellcolumnvalue),
                    l_recprotocolmappinglabo.ptl_taxa);
            END IF;


            IF l_ok
            THEN
                pkg_importprotocollabo.p_updatevalidatestatus (
                    l_reccursorimportprotocollabo.ipl_id,
                    pkg_importprotocolheader.cst_validstatusok,
                    p_usr_id);
                pkg_debug.p_write (
                    'PKG_VALIDATEPROTOCOLLABO.p_validatedetail',
                    'Status OK');
            ELSE
                pkg_importprotocollabo.p_updatevalidatestatus (
                    l_reccursorimportprotocollabo.ipl_id,
                    pkg_importprotocolheader.cst_validstatusnotok,
                    p_usr_id);
                pkg_debug.p_write (
                    'PKG_VALIDATEPROTOCOLLABO.p_validatedetail',
                    'Status NOT OK');
                l_computeindice := FALSE;
            END IF;
        END LOOP;

        CLOSE l_cursorimportprotocollabo;

        IF l_computeindice
        THEN
            p_compute_allindice (l_recimportprotocolheader);
        END IF;


        NULL;
    END;
END pkg_validateprotocollabo;
/

