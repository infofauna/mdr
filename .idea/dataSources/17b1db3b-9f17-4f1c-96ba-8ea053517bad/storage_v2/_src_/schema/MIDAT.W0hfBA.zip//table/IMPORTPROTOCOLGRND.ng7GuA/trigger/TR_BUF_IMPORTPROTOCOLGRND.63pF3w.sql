create trigger TR_BUF_IMPORTPROTOCOLGRND
    before update
    on IMPORTPROTOCOLGRND
    for each row
DECLARE
BEGIN
 
   :new.ipn_moddate := SYSDATE;
   :new.ipn_moduser := USER;
END tr_buf_IMPORTPROTOCOLGRND;

/

