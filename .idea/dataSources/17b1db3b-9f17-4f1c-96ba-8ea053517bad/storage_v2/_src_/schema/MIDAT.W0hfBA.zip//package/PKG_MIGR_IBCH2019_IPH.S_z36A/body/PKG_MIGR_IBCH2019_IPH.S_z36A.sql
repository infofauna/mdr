create PACKAGE BODY       pkg_migr_ibch2019_iph
AS
    /******************************************************************************
       NAME:       PKG_MIGR_IBCH2019_iph
       PURPOSE:    Modification dans la table IMPORTPROTOCOLHEADER

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       15.05.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-------------------------------------------------------------------*/
    PROCEDURE p_deletebyptv_id (
        p_ptv_id   IN importprotocolheader.iph_ptv_id%TYPE)
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM importprotocolheader
              WHERE iph_ptv_id = p_ptv_id;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_add_iph_columns
    /*--------------------------------------------------------------*/
    IS
        l_done   BOOLEAN;
    BEGIN
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_autreneoz_1,
            'VARCHAR2(120)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_autreneoz_2,
            'VARCHAR2(120)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_sommeept,
            'VARCHAR2(30)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_sommeneoz,
            'VARCHAR2(30)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_sommeabon,
            'VARCHAR2(30)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_sommetxobs,
            'VARCHAR2(30)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_sommetxcor,
            'VARCHAR2(30)',
            NULL,
            l_done);

        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_valeurvt,
            'VARCHAR2(30)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_valeurgi,
            'VARCHAR2(30)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_valeurgimax,
            'VARCHAR2(30)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_ibchq,
            'VARCHAR2(30)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_vc,
            'VARCHAR2(30)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_ibchvalue_r,
            'VARCHAR2(30)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'IMPORTPROTOCOLHEADER',
            'IPH_' || pkg_codevalue.cst_midathditem_spearvalue,
            'VARCHAR2(30)',
            NULL,
            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_TAXONINDICATEUR',
                                            'VARCHAR2(1024 CHAR)',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_IBCHROBUST',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_CLASSEVARIETE',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_CLASSEVARIETE_CORR',
                                            'NUMBER',
                                            NULL,
                                            l_done);


        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_CLASSEVARIETEROBUST',
                                            'NUMBER',
                                            NULL,
                                            l_done);


        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_CLASSEVARIETEROBUST_CORR',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_CLASSEVARIETE_FINAL',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_CLASSEVARIETEROBUST_FINAL',
                                            'NUMBER',
                                            NULL,
                                            l_done);



        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_TAXONFREQUENCESUM',
                                            'NUMBER',
                                            NULL,
                                            l_done);


        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_GIMAX',
                                            'NUMBER',
                                            NULL,
                                            l_done);


        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_GIMAXROBUST',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_GI_FINAL',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_GIROBUST_FINAL',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_SUMFAMILY',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_SUMFAMILYCORRECTED',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_SUMFAMILYROBUST',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_SUMFAMILYROBUSTCORRECTED',
                                            'NUMBER',
                                            NULL,
                                            l_done);



        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_EPHEMEROPTERACOUNTER',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_PLECOPTERACOUNTER',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('IMPORTPROTOCOLHEADER',
                                            'IPH_TRICOPTERACOUNTER',
                                            'NUMBER',
                                            NULL,
                                            l_done);
    END;
END pkg_migr_ibch2019_iph;
/

