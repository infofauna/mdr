create PACKAGE       pkg_importprotocolgrid
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLMAPPINGGRID
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_deletebyiphidmaster (
      p_iph_id IN importprotocolgrid.ipg_iph_id%TYPE);

   PROCEDURE p_updatevalidatestatus (
      p_ipg_id   IN importprotocolgrid.ipg_id%TYPE,
      p_status   IN importprotocolgrid.ipg_validstatus%TYPE,
      p_usr_id   IN importprotocolgrid.ipg_usr_id_modify%TYPE);

   PROCEDURE p_insert (p_iph_id   IN importprotocolgrid.ipg_iph_id%TYPE,
                       p_pmg_id   IN importprotocolgrid.ipg_pmg_id%TYPE,
                       p_value    IN importprotocolgrid.ipg_value%TYPE);

   PROCEDURE p_deletebyiphid (p_iph_id IN importprotocolgrid.ipg_iph_id%TYPE);
END pkg_importprotocolgrid;
/

