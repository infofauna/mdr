create PACKAGE pkg_job
AS
   /******************************************************************************
      NAME:       PKG_JOB
      PURPOSE:    Gestion de JOB

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.09.2009  F.Burri          1. Created this package.
   ******************************************************************************/
   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getjobstatus (p_jobname IN VARCHAR2)
      RETURN VARCHAR2;

   PROCEDURE p_sendjob (p_jobname   IN VARCHAR2,
                        p_command   IN VARCHAR2,
                        p_comment   IN VARCHAR2);

   PROCEDURE p_dropjobbychainname (p_chainname IN VARCHAR2);

   FUNCTION f_chainexist (
      p_chainname IN user_scheduler_chains.chain_name%TYPE)
      RETURN BOOLEAN;

   FUNCTION f_jobexist (p_jobname IN user_scheduler_jobs.job_name%TYPE)
      RETURN BOOLEAN;

   FUNCTION f_programexist (
      p_programname IN user_scheduler_programs.program_name%TYPE)
      RETURN BOOLEAN;

   FUNCTION f_scheduleexist (
      p_schedulename IN user_scheduler_schedules.schedule_name%TYPE)
      RETURN BOOLEAN;

   PROCEDURE p_dropchain (p_name IN VARCHAR2);

   PROCEDURE p_stopalljob;

   PROCEDURE p_enablealljob;

   PROCEDURE p_dropall;

   PROCEDURE p_createchainwith2job (p_chain_name       IN VARCHAR2,
                                    p_program_name_1   IN VARCHAR2,
                                    p_program_name_2   IN VARCHAR2);

   PROCEDURE p_schedulechainjob (p_jobname        IN VARCHAR2,
                                 p_schedulename   IN VARCHAR2,
                                 p_chainname      IN VARCHAR2,
                                 p_comment        IN VARCHAR2);

   PROCEDURE p_returnlastjobinfo (
      p_date             IN     DATE,
      p_jobname          IN     VARCHAR2,
      p_jobsubname       IN     VARCHAR2,
      p_status              OUT user_scheduler_job_run_details.status%TYPE,
      p_runduration         OUT user_scheduler_job_run_details.run_duration%TYPE,
      p_additionalinfo      OUT user_scheduler_job_run_details.additional_info%TYPE,
      p_startdate           OUT user_scheduler_job_run_details.actual_start_date%TYPE,
      p_returnstatus        OUT NUMBER);

   PROCEDURE p_returnlastjobinfo (
      p_date             IN     DATE,
      p_jobname          IN     VARCHAR2,
      p_status              OUT user_scheduler_job_run_details.status%TYPE,
      p_runduration         OUT user_scheduler_job_run_details.run_duration%TYPE,
      p_additionalinfo      OUT user_scheduler_job_run_details.additional_info%TYPE,
      p_startdate           OUT user_scheduler_job_run_details.actual_start_date%TYPE,
      p_returnstatus        OUT NUMBER);

   PROCEDURE p_stopjob (p_job_name IN VARCHAR2, p_returnstatus OUT NUMBER);


   PROCEDURE p_disablejob (p_job_name IN VARCHAR2, p_returnstatus OUT NUMBER);

   PROCEDURE p_enablejob (p_job_name IN VARCHAR2, p_returnstatus OUT NUMBER);

   PROCEDURE p_createprogram (p_name         IN VARCHAR2,
                              p_actionname   IN VARCHAR2,
                              p_comment      IN VARCHAR2);

   PROCEDURE p_createschedule (p_name      IN VARCHAR2,
                               p_repeat    IN VARCHAR2,
                               p_comment   IN VARCHAR2);


   PROCEDURE p_schedulejob (p_jobname        IN VARCHAR2,
                            p_schedulename   IN VARCHAR2,
                            p_programname    IN VARCHAR2,
                            p_comment        IN VARCHAR2);

   PROCEDURE p_dropjob (p_jobname IN VARCHAR2);

   PROCEDURE p_dropschedule (p_name IN VARCHAR2);

   PROCEDURE p_dropprogram (p_programname IN VARCHAR2);

   PROCEDURE p_createscriptprogram (p_name         IN VARCHAR2,
                                    p_actionname   IN VARCHAR2,
                                    p_comment      IN VARCHAR2);
END pkg_job;
/

