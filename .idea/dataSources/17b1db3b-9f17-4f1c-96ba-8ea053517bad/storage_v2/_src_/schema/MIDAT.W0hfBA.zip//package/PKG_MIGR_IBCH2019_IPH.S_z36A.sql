create PACKAGE       pkg_migr_ibch2019_iph
AS
    /******************************************************************************
      NAME:       PKG_MIGR_IBCH2019_PMH
      PURPOSE:    Modification dans la table IMPORTPROTOCOLHEADER

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       15.05.2020  F.Burri           1. Created this package
   ******************************************************************************/

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, mai 2020';

    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_add_iph_columns;

    PROCEDURE p_deletebyptv_id (
        p_ptv_id   IN importprotocolheader.iph_ptv_id%TYPE);
END pkg_migr_ibch2019_iph;
/

