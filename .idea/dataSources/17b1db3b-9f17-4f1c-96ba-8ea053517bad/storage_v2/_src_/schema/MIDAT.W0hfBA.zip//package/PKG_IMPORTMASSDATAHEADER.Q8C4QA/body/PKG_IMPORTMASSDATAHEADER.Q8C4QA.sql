create PACKAGE BODY       pkg_importmassdataheader
AS
    /******************************************************************************
       NAME:       pkg_importmassdataheader
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        02.10.2013      burrif       1. Created this package.
       2.0         11.07.2017     burrif       2. Ajout de la gestion de projets
       2.1         13.09.2017     burrif       3. Ajout des nouvelles colonnes Version 2
       2.2         17.01.2020      burrif       4. Mise à jour des champs statistique IBCH
    ******************************************************************************/



    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 2.2, janvier  2020' ;


    TYPE t_listremark
        IS TABLE OF sampleloadcomment.slc_cvl_id_midatloadcmt%TYPE
        INDEX BY importmassdataheader.imh_remarkcode1%TYPE;

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getcountims_id (
        p_ims_id   IN importmassdataheader.imh_ims_id%TYPE)
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM importmassdataheader
         WHERE imh_ims_id = p_ims_id;

        RETURN l_count;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getcountvalidentries (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE)
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM importmassdataheader
         WHERE     imh_iph_id = p_iph_id
               AND imh_validstatus = pkg_constante.cst_validstatusok;

        RETURN l_count;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_update_imh_sst_id_oidlink (
        p_imh_id   IN importmassdataheader.imh_id%TYPE,
        p_sst_id   IN importmassdataheader.imh_sst_id_oidlink%TYPE,
        p_usr_id   IN importmassdataheader.imh_usr_id_modify%TYPE)
    /*------------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_sst_id_oidlink = p_sst_id,
               imh_usr_id_modify = p_usr_id,
               imh_usr_modify_date = SYSDATE
         WHERE imh_id = p_imh_id;

        NULL;
    END;

    PROCEDURE p_update_imh_cvl_id_canton (
        p_imh_id              IN importmassdataheader.imh_id%TYPE,
        p_imh_cvl_id_canton   IN importmassdataheader.imh_cvl_id_canton%TYPE,
        p_usr_id              IN importmassdataheader.imh_usr_id_modify%TYPE)
    /*------------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_cvl_id_canton = p_imh_cvl_id_canton,
               imh_usr_id_modify = p_usr_id,
               imh_usr_modify_date = SYSDATE
         WHERE imh_id = p_imh_id;
    END;


    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_update_imh_prj_id (
        p_imh_id       IN importmassdataheader.imh_id%TYPE,
        p_imh_prj_id   IN importmassdataheader.imh_prj_id%TYPE,
        p_usr_id       IN importmassdataheader.imh_usr_id_modify%TYPE)
    /*------------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_prj_id = p_imh_prj_id,
               imh_usr_id_modify = p_usr_id,
               imh_usr_modify_date = SYSDATE
         WHERE imh_id = p_imh_id;
    END;


    /*--------------------------------------------------------------*/
    PROCEDURE p_updatemkierrornumber (
        p_imh_id           IN importmassdataheader.imh_id%TYPE,
        p_mkierrornumber   IN importmassdataheader.imh_mkierrornumber%TYPE)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_mkierrornumber = p_mkierrornumber
         WHERE imh_id = p_imh_id;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_writeinvalidatemessagebyoid (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE,
        p_oid      IN importmassdataheader.imh_oid%TYPE)
    /*-------------------------------------------------------------*/
    IS
        CURSOR l_cursor
        IS
            SELECT importmassstation.*
              FROM importmassdataheader
                   INNER JOIN importmassstation ON ims_id = imh_ims_id
             WHERE imh_iph_id = p_iph_id AND ims_oid = p_oid;

        l_reccursor   l_cursor%ROWTYPE;
    BEGIN
        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;


            EXIT WHEN l_cursor%NOTFOUND;
            p_writeinvalidatemessage (p_iph_id, l_reccursor.ims_id, p_oid);

            NULL;
        END LOOP;

        CLOSE l_cursor;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_writeinvalidatemessage (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE,
        p_ims_id   IN importmassdataheader.imh_ims_id%TYPE,
        p_oid      IN importmassdataheader.imh_oid%TYPE)
    /*--------------------------------------------------------------*/
    IS
        /* Permet de définir le message d'invalidation du header à cause d'un problème sur la stations */
        CURSOR l_cursor
        IS
            SELECT *
              FROM importmassdataheader
             WHERE imh_ims_id = p_ims_id AND imh_iph_id = p_iph_id;

        l_reccursor    l_cursor%ROWTYPE;

        l_coordinate   VARCHAR2 (256);
    BEGIN
        -- Les données associées à station définie par (OID: %p1% Localité : %p1% Cours d'eau: %p2% Coordonnée: %p3%) sont invalidées en raison d'une erreur liée à la définition de la station
        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND;
            pkg_debug.p_write (
                'pkg_importmassdataheader.p_writeinvalidatemessage',
                'IMH_ID=' || l_reccursor.imh_id);

            l_coordinate :=
                   TO_CHAR (l_reccursor.imh_startpoint_x, '9999999.9')
                || '/'
                || TO_CHAR (l_reccursor.imh_startpoint_y, '9999999.9');
            pkg_importprotocollog.p_writelog (
                p_iph_id,
                l_reccursor.imh_id,
                pkg_exception.cst_headerinvalidatedbystation,
                NULL,
                p_oid,
                l_reccursor.imh_locality,
                l_reccursor.imh_watercourse,
                l_coordinate);
        END LOOP;

        CLOSE l_cursor;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getrecordbyims_id (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE,
        p_ims_id   IN importmassdataheader.imh_ims_id%TYPE)
        RETURN importmassdataheader%ROWTYPE
    /*----------------------------------------------------------------*/
    IS
        l_recimportmassdataheader   importmassdataheader%ROWTYPE;
    BEGIN
        pkg_debug.p_write ('PKG_IMPORTMASSDATAHEADER.f_getrecordbyims_id',
                           'p_ims_id=' || p_ims_id);

        SELECT *
          INTO l_recimportmassdataheader
          FROM importmassdataheader
         WHERE imh_ims_id = p_ims_id AND imh_iph_id = p_iph_id;


        RETURN l_recimportmassdataheader;
    EXCEPTION
        WHEN OTHERS
        THEN
            pkg_debug.p_write (
                'PKG_IMPORTMASSDATAHEADER.f_getrecordbyims_id',
                'Erreur');
            RETURN NULL;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_addstring (p_string         IN VARCHAR2,
                          p_appendstring   IN VARCHAR2,
                          p_counter        IN NUMBER)
        RETURN VARCHAR2
    /*---------------------------------------------------------------*/
    IS
        l_returnstring   VARCHAR2 (1024);
    BEGIN
        IF NVL (p_counter, 0) = 0
        THEN
            IF p_string IS NULL
            THEN
                l_returnstring := p_appendstring;
            ELSE
                l_returnstring := p_string || ', ' || p_appendstring;
            END IF;
        ELSE
            IF p_string IS NULL
            THEN
                l_returnstring :=
                    TRIM (TO_CHAR (p_counter)) || ') ' || p_appendstring;
            ELSE
                l_returnstring :=
                       p_string
                    || ', '
                    || TRIM (TO_CHAR (p_counter))
                    || ') '
                    || p_appendstring;
            END IF;
        END IF;

        RETURN l_returnstring;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_formatlistvarchar (p_list    IN t_listvarchar,
                                  p_field   IN VARCHAR2)
        RETURN VARCHAR2
    /*---------------------------------------------------------------*/
    IS
        l_returnstring              VARCHAR2 (1024);
        l_indice                    VARCHAR2 (128);
        l_recimportmassdataheader   importmassdataheader%ROWTYPE;
        l_count                     NUMBER := 0;
    BEGIN
        l_indice := p_list.FIRST;
        l_count := 0;

        WHILE NOT l_indice IS NULL
        LOOP
            IF p_list.COUNT > 1
            THEN
                l_count := l_count + 1;
            END IF;

            l_recimportmassdataheader :=
                pkg_importmassdataheader.f_getrecord (p_list (l_indice));


            CASE p_field
                WHEN cst_fieldlocality
                THEN
                    l_returnstring :=
                        f_addstring (l_returnstring,
                                     l_recimportmassdataheader.imh_locality,
                                     l_count);
                WHEN cst_fieldwatercourse
                THEN
                    l_returnstring :=
                        f_addstring (
                            l_returnstring,
                            l_recimportmassdataheader.imh_watercourse,
                            l_count);
                WHEN cst_fielddate
                THEN
                    l_returnstring :=
                        f_addstring (
                            l_returnstring,
                               NVL (l_recimportmassdataheader.imh_day, '--')
                            || '/'
                            || NVL (l_recimportmassdataheader.imh_month,
                                    '--')
                            || '/'
                            || NVL (l_recimportmassdataheader.imh_year, '--'),
                            l_count);
            END CASE;

            l_returnstring := l_returnstring || '  ';
            l_indice := p_list.NEXT (l_indice);
        END LOOP;

        RETURN l_returnstring;
    END;



    /*---------------------------------------------------------------*/
    PROCEDURE p_returninfoheaderbycoordinate (
        p_iph_id            IN     importmassdataheader.imh_iph_id%TYPE,
        p_oid               IN     importmassdataheader.imh_oid%TYPE,
        p_elevation         IN     importmassdataheader.imh_elevation%TYPE,
        p_x                 IN     importmassdataheader.imh_startpoint_x%TYPE,
        p_y                 IN     importmassdataheader.imh_startpoint_y%TYPE,
        p_listlocality         OUT t_listvarchar,
        p_listwatercourse      OUT t_listvarchar,
        p_listdate             OUT t_listvarchar)
    /*---------------------------------------------------------------*/
    IS
        -- Il peut y avoir plusieurs header identique sauf la date
        CURSOR l_list
        IS
            SELECT *
              FROM importmassdataheader
             WHERE     imh_iph_id = p_iph_id
                   AND NVL (p_oid, 'XXX') = NVL (imh_oid, 'XXX')
                   AND NVL (p_x, 'XXX') = NVL (imh_startpoint_x, 'XXX')
                   AND NVL (p_y, 'XXX') = NVL (imh_startpoint_y, 'XXX')
                   AND NVL (p_elevation, 'XXX') = NVL (imh_elevation, 'XXX')
                   AND imh_validstatus !=
                       pkg_importprotocolheader.cst_validstatusnotok;

        l_reclist      l_list%ROWTYPE;
        l_datestring   VARCHAR2 (30);
    BEGIN
        p_listlocality.delete ();
        p_listwatercourse.delete ();
        p_listdate.delete ();

        OPEN l_list;

        LOOP
            FETCH l_list INTO l_reclist;

            EXIT WHEN l_list%NOTFOUND;

            IF NOT p_listwatercourse.EXISTS (
                       UPPER (l_reclist.imh_watercourse))
            THEN
                p_listwatercourse (UPPER (l_reclist.imh_watercourse)) :=
                    l_reclist.imh_id;
            END IF;

            IF NOT p_listlocality.EXISTS (UPPER (l_reclist.imh_locality))
            THEN
                p_listlocality (UPPER (l_reclist.imh_locality)) :=
                    l_reclist.imh_id;
            END IF;

            l_datestring :=
                   NVL (l_reclist.imh_day, '--')
                || '/'
                || NVL (l_reclist.imh_month, '--')
                || '/'
                || NVL (l_reclist.imh_year, '--');

            IF NOT p_listdate.EXISTS (l_datestring)
            THEN
                p_listdate (l_datestring) := l_reclist.imh_id;
            END IF;
        END LOOP;

        CLOSE l_list;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_returninfoheaderbyims_id (
        p_ims_id            IN     importmassdataheader.imh_ims_id%TYPE,
        p_listlocality         OUT t_listvarchar,
        p_listwatercourse      OUT t_listvarchar,
        p_listdate             OUT t_listvarchar)
    /*---------------------------------------------------------------*/
    IS
        -- Il peut y avoir plusieurs header identique sauf la date
        CURSOR l_list
        IS
            SELECT *
              FROM importmassdataheader
             WHERE imh_ims_id = p_ims_id;


        l_reclist      l_list%ROWTYPE;
        l_datestring   VARCHAR2 (30);
    BEGIN
        p_listlocality.delete ();
        p_listwatercourse.delete ();
        p_listdate.delete ();

        OPEN l_list;

        LOOP
            FETCH l_list INTO l_reclist;

            EXIT WHEN l_list%NOTFOUND;
            pkg_debug.p_write (
                'PKG_IMPORTMASSDATAHEADER.p_returninfoheaderbyims_id',
                l_reclist.imh_watercourse);

            IF NOT p_listwatercourse.EXISTS (
                       UPPER (l_reclist.imh_watercourse))
            THEN
                p_listwatercourse (UPPER (l_reclist.imh_watercourse)) :=
                    l_reclist.imh_id;
            END IF;

            IF NOT p_listlocality.EXISTS (UPPER (l_reclist.imh_locality))
            THEN
                p_listlocality (UPPER (l_reclist.imh_locality)) :=
                    l_reclist.imh_id;
            END IF;

            l_datestring :=
                   NVL (l_reclist.imh_day, '--')
                || '/'
                || NVL (l_reclist.imh_month, '--')
                || '/'
                || NVL (l_reclist.imh_year, '--');

            IF NOT p_listdate.EXISTS (l_datestring)
            THEN
                p_listdate (l_datestring) := l_reclist.imh_id;
            END IF;
        END LOOP;

        CLOSE l_list;
    END;



    /*----------------------------------------------------------------*/
    FUNCTION f_addandsql (p_sql IN VARCHAR2, p_andsql IN VARCHAR2)
        RETURN VARCHAR2
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        IF p_sql IS NULL
        THEN
            RETURN p_andsql;
        ELSE
            RETURN p_sql || ' AND ' || p_andsql;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_updatestatusbycoord (
        p_oid      IN importmassdataheader.imh_oid%TYPE,
        p_x        IN importmassdataheader.imh_startpoint_x%TYPE,
        p_y        IN importmassdataheader.imh_startpoint_y%TYPE,
        p_z        IN importmassdataheader.imh_elevation%TYPE,
        p_status   IN importmassdataheader.imh_status%TYPE)
    /*----------------------------------------------------------------*/
    IS
        l_sql   VARCHAR2 (1024);
    BEGIN
        IF p_oid IS NULL
        THEN
            l_sql := f_addandsql (l_sql, ' IMH_OID IS NULL');
        ELSE
            l_sql :=
                f_addandsql (l_sql,
                             '  TRIM(IMH_OID) = TRIM(''' || p_oid || ''')');
        END IF;

        IF p_x IS NULL
        THEN
            l_sql := f_addandsql (l_sql, ' IMH_STARTPOINT_X IS NULL');
        ELSE
            l_sql :=
                f_addandsql (l_sql, '  IMH_STARTPOINT_X =''' || p_x || '''');
        END IF;

        IF p_y IS NULL
        THEN
            l_sql := f_addandsql (l_sql, ' IMH_STARTPOINT_Y IS NULL');
        ELSE
            l_sql :=
                f_addandsql (l_sql, '  IMH_STARTPOINT_Y =''' || p_y || '''');
        END IF;

        IF p_z IS NULL
        THEN
            l_sql := f_addandsql (l_sql, ' IMH_ELEVATION IS NULL');
        ELSE
            l_sql :=
                f_addandsql (l_sql, '  IMH_ELEVATION =''' || p_z || '''');
        END IF;

        l_sql :=
               'UPDATE IMPORTMASSDATAHEADER SET IMH_STATUS='''
            || p_status
            || ''' WHERE '
            || l_sql;

        EXECUTE IMMEDIATE l_sql;
    END;

    /*............................................................................*/
    PROCEDURE p_test
    /*---------------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (15);
        DBMS_OUTPUT.put_line (
            f_makroindexmussbecomputed (l_recimportprotocolheader));
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_makroindexmussbecomputed (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE)
        RETURN CHAR
    /*----------------------------------------------------------------*/
    IS
        CURSOR l_listimportmassdataheader
        IS
            SELECT *
              FROM importmassdataheader
             WHERE     imh_iph_id = p_recimportprotocolheader.iph_id
                   AND imh_validstatus = pkg_constante.cst_validstatusok;

        l_recimportmassdataheader   l_listimportmassdataheader%ROWTYPE;
        l_found                     BOOLEAN := FALSE;
        l_listindice                pkg_stringutil.t_listofvalue;
        l_indice                    PLS_INTEGER;
    BEGIN
        OPEN l_listimportmassdataheader;

        LOOP
            FETCH l_listimportmassdataheader INTO l_recimportmassdataheader;

            EXIT WHEN l_listimportmassdataheader%NOTFOUND OR l_found;

            IF NOT l_recimportmassdataheader.imh_indicetype IS NULL
            THEN
                l_listindice :=
                    pkg_stringutil.f_splitstring (
                        l_recimportmassdataheader.imh_indicetype,
                        ';');
                l_indice := l_listindice.FIRST;

                WHILE NOT l_indice IS NULL AND NOT l_found
                LOOP
                    IF TRIM (UPPER (l_listindice (l_indice))) =
                       pkg_codevalue.cst_midatindice_makroindex
                    THEN
                        l_found := TRUE;
                    ELSE
                        l_indice := l_listindice.NEXT (l_indice);
                    END IF;
                END LOOP;
            ELSE
                l_found := TRUE;
            END IF;
        END LOOP;

        CLOSE l_listimportmassdataheader;

        IF l_found
        THEN
            RETURN pkg_constante.cst_yes;
        ELSE
            RETURN pkg_constante.cst_no;
        END IF;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_returnindexcalculationforall (
        p_iph_id                  IN     importmassdataheader.imh_iph_id%TYPE,
        p_spearindexcalculation      OUT BOOLEAN,
        p_makroindexcalculation      OUT BOOLEAN,
        p_ibchindexcalculation       OUT BOOLEAN)
    /*---------------------------------------------------------------*/
    IS
        CURSOR l_importmassdataheader
        IS
            SELECT *
              FROM importmassdataheader
             WHERE imh_validstatus != pkg_constante.cst_validstatusnotok;

        l_recimportmassdataheader   l_importmassdataheader%ROWTYPE;
        l_listindice                pkg_stringutil.t_listofvalue;
        l_indice                    PLS_INTEGER;
    BEGIN
        p_spearindexcalculation := FALSE;
        p_makroindexcalculation := FALSE;
        p_ibchindexcalculation := FALSE;

        OPEN l_importmassdataheader;

        LOOP
            FETCH l_importmassdataheader INTO l_recimportmassdataheader;

            EXIT WHEN l_importmassdataheader%NOTFOUND;

            IF l_recimportmassdataheader.imh_indicetype IS NULL
            THEN
                p_spearindexcalculation := TRUE;
                p_ibchindexcalculation := TRUE;
            END IF;


            l_listindice :=
                pkg_stringutil.f_splitstring (
                    l_recimportmassdataheader.imh_indicetype,
                    ';');
            l_indice := l_listindice.FIRST;

            WHILE NOT l_indice IS NULL
            LOOP
                IF TRIM (UPPER (l_listindice (l_indice))) =
                   pkg_codevalue.cst_midatindice_ibch
                THEN
                    p_ibchindexcalculation := TRUE;
                ELSIF TRIM (UPPER (l_listindice (l_indice))) =
                      pkg_codevalue.cst_midatindice_spear
                THEN
                    p_spearindexcalculation := TRUE;
                ELSIF TRIM (UPPER (l_listindice (l_indice))) =
                      pkg_codevalue.cst_midatindice_makroindex
                THEN
                    p_makroindexcalculation := TRUE;
                END IF;

                l_indice := l_listindice.NEXT (l_indice);
            END LOOP;
        END LOOP;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_returnindexcalculation (
        p_imh_id                  IN     importmassdataheader.imh_id%TYPE,
        p_spearindexcalculation      OUT BOOLEAN,
        p_makroindexcalculation      OUT BOOLEAN,
        p_ibchindexcalculation       OUT BOOLEAN)
    /*---------------------------------------------------------------*/
    IS
        l_recimportmassdataheader   importmassdataheader%ROWTYPE;
        l_listindice                pkg_stringutil.t_listofvalue;
        l_indice                    PLS_INTEGER;
    BEGIN
        p_spearindexcalculation := TRUE;
        p_makroindexcalculation := TRUE;
        p_ibchindexcalculation := TRUE;
        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (p_imh_id);

        IF l_recimportmassdataheader.imh_indicetype IS NULL
        THEN
            p_makroindexcalculation := FALSE;
            RETURN;                           -- On calcule l'ibch et le spear
        END IF;

        p_spearindexcalculation := FALSE;
        p_makroindexcalculation := FALSE;
        p_ibchindexcalculation := FALSE;
        l_listindice :=
            pkg_stringutil.f_splitstring (
                l_recimportmassdataheader.imh_indicetype,
                ';');
        l_indice := l_listindice.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            IF TRIM (UPPER (l_listindice (l_indice))) =
               pkg_codevalue.cst_midattypecal_ibch
            THEN
                p_ibchindexcalculation := TRUE;
            ELSIF TRIM (UPPER (l_listindice (l_indice))) =
                  pkg_codevalue.cst_midattypecal_spear
            THEN
                p_spearindexcalculation := TRUE;
            ELSIF TRIM (UPPER (l_listindice (l_indice))) =
                  pkg_codevalue.cst_midattypecal_makroindex
            THEN
                p_makroindexcalculation := TRUE;
            ELSIF TRIM (UPPER (l_listindice (l_indice))) =
                  pkg_codevalue.cst_midattypecal_all
            THEN
                p_spearindexcalculation := TRUE;
                p_makroindexcalculation := TRUE;
                p_ibchindexcalculation := TRUE;
            END IF;

            l_indice := l_listindice.NEXT (l_indice);
        END LOOP;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_deleteby_sst_id (
        p_sst_id   IN importmassdataheader.imh_sst_id%TYPE)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM importprotocollogparam
              WHERE ipr_ipo_id IN
                        (SELECT ipo_id
                           FROM importprotocollog
                          WHERE ipo_imh_id IN (SELECT imh_id
                                                 FROM importmassdataheader
                                                WHERE imh_sst_id = p_sst_id));

        DELETE FROM importprotocollog
              WHERE ipo_imh_id IN (SELECT imh_id
                                     FROM importmassdataheader
                                    WHERE imh_sst_id = p_sst_id);

        DELETE FROM importmassdatadetail
              WHERE imd_imh_id IN (SELECT imh_id
                                     FROM importmassdataheader
                                    WHERE imh_sst_id = p_sst_id);

        DELETE FROM importmassdataheader
              WHERE imh_sst_id = p_sst_id;
    END;



    /*--------------------------------------------------------------*/
    PROCEDURE p_purgeinvalidemassdata (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE)
    /*--------------------------------------------------------------*/
    IS
        CURSOR l_recordingpurge
        IS
            SELECT *
              FROM importmassdataheader
             WHERE     imh_iph_id = p_iph_id
                   AND imh_validstatus =
                       pkg_importprotocolheader.cst_validstatusnotok;

        l_recrecordingpurge   l_recordingpurge%ROWTYPE;
    BEGIN
        OPEN l_recordingpurge;

        LOOP
            FETCH l_recordingpurge INTO l_recrecordingpurge;

            EXIT WHEN l_recordingpurge%NOTFOUND;
            pkg_importmassdatadetail.p_deletebyimhid (
                l_recrecordingpurge.imh_id);
            pkg_importprotocollog.p_purgebyimh_id (
                l_recrecordingpurge.imh_id);
        END LOOP;

        CLOSE l_recordingpurge;

        DELETE FROM importmassdataheader
              WHERE     imh_iph_id = p_iph_id
                    AND imh_validstatus =
                        pkg_importprotocolheader.cst_validstatusnotok;


        NULL;
    END;


    /*-------------------------------------------------------------*/
    PROCEDURE p_updateibchindex (
        p_imh_id       IN importmassdataheader.imh_id%TYPE,
        p_ibchvalue    IN importmassdataheader.imh_ibchvalue%TYPE,
        p_windowibch   IN importmassdataheader.imh_cvl_id_windowibch%TYPE)
    /*------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_ibchvalue = p_ibchvalue,
               imh_cvl_id_windowibch = p_windowibch,
               imh_usr_modify_date = SYSDATE
         WHERE imh_id = p_imh_id;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_updatemakroindex (
        p_imh_id      IN importmassdataheader.imh_id%TYPE,
        p_mkivalue    IN importmassdataheader.imh_makroindexvalue%TYPE,
        p_windowmki   IN importmassdataheader.imh_cvl_id_windowmakroindex%TYPE)
    /*------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_makroindexvalue = p_mkivalue,
               imh_cvl_id_windowmakroindex = p_windowmki
         WHERE imh_id = p_imh_id;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_updatespearindex (
        p_imh_id        IN importmassdataheader.imh_id%TYPE,
        p_spearvalue    IN importmassdataheader.imh_spearvalue%TYPE,
        p_windowspear   IN importmassdataheader.imh_cvl_id_windowspear%TYPE)
    /*------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_spearvalue = p_spearvalue,
               imh_cvl_id_windowspear = p_windowspear
         WHERE imh_id = p_imh_id;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_returncountindice (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_ibchcounter                  OUT NUMBER,
        p_mkicounter                   OUT NUMBER)
    /*--------------------------------------------------------------*/
    /* Retourne le nombre de header pour lesquels chaque indice doit être calculé */
    IS
    BEGIN
        SELECT COUNT (*)
          INTO p_ibchcounter
          FROM importmassdataheader
         WHERE     imh_ibchcanbecalculated = pkg_constante.cst_yes
               AND imh_iph_id = p_recimportprotocolheader.iph_id
               AND imh_validstatus = pkg_constante.cst_validstatusok;

        SELECT COUNT (*)
          INTO p_mkicounter
          FROM importmassdataheader
         WHERE     imh_mkicanbecalculated = pkg_constante.cst_yes
               AND imh_iph_id = p_recimportprotocolheader.iph_id
               AND imh_validstatus = pkg_constante.cst_validstatusok;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_updatevalidtatuspending (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_lan_id                    IN language.lan_id%TYPE,
        p_usr_id                    IN sampleprotocolgrnd.spd_usr_id_create%TYPE)
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_validstatus = pkg_constante.cst_validstatusok,
               imh_usr_id_create = p_usr_id
         WHERE     imh_iph_id = p_recimportprotocolheader.iph_id
               AND imh_validstatus = pkg_constante.cst_validstatuspending;

        pkg_debug.p_write (
            'PKG_IMPORTMASSDATAHEADER.p_updatevalidtatuspending',
            'Nombre de PENDING SQL%ROWCOUNT=' || SQL%ROWCOUNT);

        NULL;
    END;

    /*-------------------------------------------------------------------*/
    PROCEDURE p_test1
    /*------------------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (252);
        p_logendstatistique (l_recimportprotocolheader);
    END;

    /*-------------------------------------------------------------------*/
    PROCEDURE p_test2
    /*------------------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (933);
        p_saveprotocolmassheader (l_recimportprotocolheader,
                                  1,
                                  3,
                                  NULL,
                                  NULL,
                                  NULL);
    END;

    /*-------------------------------------------------------------------------------------------------*/
    PROCEDURE p_identifiecodeprecisionsource (
        p_recimportprotocolheader      IN     importprotocolheader%ROWTYPE,
        p_recimportmassdataheader      IN     importmassdataheader%ROWTYPE,
        p_sph_cvl_id_sysprecisionref      OUT sampleheader.sph_cvl_id_sysprecisionref%TYPE,
        p_sph_cvl_id_sysprecision         OUT sampleheader.sph_cvl_id_sysprecision%TYPE)
    /*-------------------------------------------------------------------------------------------------*/
    IS
        l_codevaluecodeprecision   codevalue%ROWTYPE;
        l_codevaluesystemprec      codevalue%ROWTYPE;
    BEGIN
        p_sph_cvl_id_sysprecisionref :=
            p_recimportprotocolheader.iph_cvl_id_systlref;
        p_sph_cvl_id_sysprecision :=
            p_recimportprotocolheader.iph_cvl_id_systlprec;

        IF    p_recimportmassdataheader.imh_systemprecision IS NULL
           OR p_recimportmassdataheader.imh_codeprecision IS NULL
        THEN
            RETURN;
        END IF;

        l_codevaluecodeprecision :=
            pkg_codevalue.f_getfromcode (
                p_recimportmassdataheader.imh_codeprecision,
                pkg_codereference.cst_crf_systlprec);

        IF l_codevaluecodeprecision.cvl_id IS NULL
        THEN
            RETURN; -- Cette sitruqtion n'est pas normal mais on ne bloque pas le processu car la validation a déjà eu lieu
        END IF;

        l_codevaluesystemprec :=
            pkg_codevalue.f_getfromcode (
                p_recimportmassdataheader.imh_systemprecision,
                pkg_codereference.cst_crf_systlref);

        IF l_codevaluesystemprec.cvl_id IS NULL
        THEN
            RETURN; -- Cette sitruqtion n'est pas normal mais on ne bloque pas le processu car la validation a déjà eu lieu
        END IF;

        p_sph_cvl_id_sysprecisionref := l_codevaluecodeprecision.cvl_id;
        p_sph_cvl_id_sysprecision := l_codevaluesystemprec.cvl_id;
    END;

    /*-------------------------------------------------------------------*/
    FUNCTION f_formatlistindex (
        p_importmassdataheader   IN importmassdataheader%ROWTYPE)
        RETURN VARCHAR2
    /*-------------------------------------------------------------------*/
    IS
        l_text   VARCHAR2 (1024);
    BEGIN
        IF NOT p_importmassdataheader.imh_makroindexvalue IS NULL
        THEN
            l_text :=
                   pkg_codevalue.cst_midatindice_makroindex
                || ': '
                || TO_CHAR (p_importmassdataheader.imh_makroindexvalue);
        END IF;

        IF NOT p_importmassdataheader.imh_ibchvalue IS NULL
        THEN
            IF NOT l_text IS NULL
            THEN
                l_text :=
                       l_text
                    || '; '
                    || pkg_codevalue.cst_midatindice_ibch
                    || ': '
                    || TO_CHAR (p_importmassdataheader.imh_ibchvalue);
            ELSE
                l_text :=
                       pkg_codevalue.cst_midatindice_ibch
                    || ': '
                    || TO_CHAR (p_importmassdataheader.imh_ibchvalue);
            END IF;
        END IF;

        IF NOT p_importmassdataheader.imh_spearvalue IS NULL
        THEN
            IF NOT l_text IS NULL
            THEN
                l_text :=
                       l_text
                    || '; '
                    || pkg_codevalue.cst_midatindice_spear
                    || ': '
                    || TO_CHAR (p_importmassdataheader.imh_spearvalue);
            ELSE
                l_text :=
                       pkg_codevalue.cst_midatindice_spear
                    || ': '
                    || TO_CHAR (p_importmassdataheader.imh_spearvalue);
            END IF;
        END IF;

        RETURN l_text;
    END;


    /*-------------------------------------------------------------------*/
    PROCEDURE p_logendstatistique (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE)
    /*-------------------------------------------------------------------*/
    IS
        CURSOR l_listmasterheaderok
        IS
            SELECT *
              FROM importmassdataheader
             WHERE     imh_iph_id = p_recimportprotocolheader.iph_id
                   AND imh_validstatus = pkg_constante.cst_validstatusok;

        CURSOR l_listmasterheadernotok
        IS
            SELECT *
              FROM importmassdataheader
             WHERE     imh_iph_id = p_recimportprotocolheader.iph_id
                   AND imh_validstatus != pkg_constante.cst_validstatusok;

        l_reclistmasterheaderok      l_listmasterheaderok%ROWTYPE;
        l_reclistmasterheadernotok   l_listmasterheadernotok%ROWTYPE;
        l_string                     VARCHAR2 (1024);
        l_day                        VARCHAR2 (2);
        l_month                      VARCHAR2 (2);
        l_year                       VARCHAR2 (4);
        l_validcount                 NUMBER;
        l_invalidcount               NUMBER;
        l_indice                     PLS_INTEGER := 0;
        l_coordonnee                 VARCHAR2 (60);
        l_line                       VARCHAR2 (170) := RPAD (' ', 170, '-');
        /*
        -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        | Statut; Cours d'eau  et  Localité ,  Date ;    Makroindex fourni|calculé; IBCH fourni/calculé; SPEAR fournicalculé; Nombre de ligne de détail valide/invalide

     */



        l_text                       VARCHAR2 (1024);
    BEGIN
        pkg_importprotocollog.p_writelog (p_recimportprotocolheader.iph_id,
                                          l_reclistmasterheaderok.imh_id, -- IMH_ID
                                          pkg_exception.cst_info,
                                          NULL,                  -- Field name
                                          l_line);
        pkg_importprotocollog.p_writelog (
            p_recimportprotocolheader.iph_id,
            l_reclistmasterheaderok.imh_id,                          -- IMH_ID
            pkg_exception.cst_resumevalidheader,
            NULL);                                               -- Field name
        l_indice := 0;

        OPEN l_listmasterheaderok;

        LOOP
            FETCH l_listmasterheaderok INTO l_reclistmasterheaderok;

            EXIT WHEN l_listmasterheaderok%NOTFOUND;
            l_indice := l_indice + 1;
            l_day := NVL (l_reclistmasterheaderok.imh_day, '--');
            l_month := NVL (l_reclistmasterheaderok.imh_month, '--');
            l_year := NVL (l_reclistmasterheaderok.imh_year, '--');
            l_validcount :=
                pkg_importmassdatadetail.f_getvalidrowcount (
                    l_reclistmasterheaderok.imh_id);
            l_invalidcount :=
                pkg_importmassdatadetail.f_getinvalidrowcount (
                    l_reclistmasterheaderok.imh_id);
            l_coordonnee :=
                   NVL (l_reclistmasterheaderok.imh_startpoint_x, '----')
                || '; '
                || NVL (l_reclistmasterheaderok.imh_startpoint_y, '----')
                || '; '
                || NVL (l_reclistmasterheaderok.imh_elevation, '----');
            --        %p1%. Coordonnée: %p2% Cours d'eau: %p3%, localité: %p4%  date=%p5%; Statut=f$returnvalidstatus#1(%p6%); %p7%; Nombre de lignes de l'entrée=%p8%
            l_text := f_formatlistindex (l_reclistmasterheaderok);
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                l_reclistmasterheaderok.imh_id,                      -- IMH_ID
                pkg_exception.cst_massendresume,
                NULL,                                            -- Field name
                TRIM (TO_CHAR (l_indice)),
                l_coordonnee,
                NVL (l_reclistmasterheaderok.imh_watercourse, '-----------'),
                NVL (l_reclistmasterheaderok.imh_locality, '-----------'),
                   NVL (l_day, '--')
                || '/'
                || NVL (l_month, '--')
                || '/'
                || NVL (l_year, '----'),
                l_reclistmasterheaderok.imh_validstatus,
                l_text,
                TO_CHAR (l_validcount + l_invalidcount));
        END LOOP;

        CLOSE l_listmasterheaderok;

        pkg_importprotocollog.p_writelog (p_recimportprotocolheader.iph_id,
                                          l_reclistmasterheaderok.imh_id, -- IMH_ID
                                          pkg_exception.cst_info,
                                          NULL,                  -- Field name
                                          l_line);
        pkg_importprotocollog.p_writelog (
            p_recimportprotocolheader.iph_id,
            l_reclistmasterheaderok.imh_id,                          -- IMH_ID
            pkg_exception.cst_resumeinvalidheader,
            NULL);

        l_indice := 0;

        OPEN l_listmasterheadernotok;

        LOOP
            FETCH l_listmasterheadernotok INTO l_reclistmasterheadernotok;

            EXIT WHEN l_listmasterheadernotok%NOTFOUND;
            l_indice := l_indice + 1;
            l_day := NVL (l_reclistmasterheadernotok.imh_day, '--');
            l_month := NVL (l_reclistmasterheadernotok.imh_month, '--');
            l_year := NVL (l_reclistmasterheadernotok.imh_year, '--');
            l_validcount :=
                pkg_importmassdatadetail.f_getvalidrowcount (
                    l_reclistmasterheadernotok.imh_id);
            l_invalidcount :=
                pkg_importmassdatadetail.f_getinvalidrowcount (
                    l_reclistmasterheadernotok.imh_id);
            l_coordonnee :=
                   NVL (l_reclistmasterheadernotok.imh_startpoint_x, '----')
                || '; '
                || NVL (l_reclistmasterheadernotok.imh_startpoint_y, '----')
                || '; '
                || NVL (l_reclistmasterheadernotok.imh_elevation, '----');

            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                l_reclistmasterheadernotok.imh_id,                   -- IMH_ID
                pkg_exception.cst_massendresumenotok,
                NULL,                                            -- Field name
                TRIM (TO_CHAR (l_indice)),
                l_coordonnee,
                NVL (l_reclistmasterheadernotok.imh_watercourse,
                     '-----------'),
                NVL (l_reclistmasterheadernotok.imh_locality, '-----------'),
                   NVL (l_day, '--')
                || '/'
                || NVL (l_month, '--')
                || '/'
                || NVL (l_year, '----'),
                l_reclistmasterheadernotok.imh_validstatus,
                   TO_CHAR (l_validcount + l_invalidcount)
                || '/'
                || TO_CHAR (l_invalidcount));
            pkg_importprotocollog.p_recopyerrorbyimh_id (
                l_reclistmasterheadernotok.imh_id);
        END LOOP;

        CLOSE l_listmasterheadernotok;

        NULL;
    END;

    /*--------------------------------------------------------------------------------*/
    PROCEDURE p_update_comment (
        p_sph_id    IN sampleheader.sph_id%TYPE,
        p_comment   IN sampleheader.sph_comment%TYPE,
        p_usr_id    IN sampleheader.sph_usr_id_modify%TYPE)
    /*--------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE sampleheader
           SET sph_comment = p_comment,
               sph_usr_id_modify = p_usr_id,
               sph_usr_modify_date = SYSDATE
         WHERE sph_id = p_sph_id;
    END;

    /*--------------------------------------------------------------------------------*/
    PROCEDURE p_insert_remarkcode (
        p_sph_id       IN sampleloadcomment.slc_sph_id%TYPE,
        p_listremark   IN t_listremark,
        p_usr_id       IN sampleloadcomment.slc_usr_id_create%TYPE)
    /*--------------------------------------------------------------------------------*/
    IS
        l_remarkcode   importmassdataheader.imh_remarkcode1%TYPE;
        l_order        NUMBER := 0;
    BEGIN
        l_remarkcode := p_listremark.FIRST;

        WHILE NOT l_remarkcode IS NULL
        LOOP
            l_order := l_order + 1;

            INSERT INTO sampleloadcomment (slc_sph_id,
                                           slc_cvl_id_midatloadcmt,
                                           slc_sortorder,
                                           slc_usr_id_create,
                                           slc_usr_create_date)
                 VALUES (p_sph_id,
                         p_listremark (l_remarkcode),
                         l_order,
                         p_usr_id,
                         SYSDATE);

            l_remarkcode := p_listremark.NEXT (l_remarkcode);
        END LOOP;
    END;



    /*---------------------------------------------------------------------------------*/
    FUNCTION f_add2listremark (
        p_remark       IN importmassdataheader.imh_remarkcode1%TYPE,
        p_listremark   IN t_listremark)
        RETURN t_listremark
    /*---------------------------------------------------------------------------------*/
    IS
        l_listremark     t_listremark;
        l_reccodevalue   codevalue%ROWTYPE;
    BEGIN
        l_listremark := p_listremark;

        IF NOT p_remark IS NULL
        THEN
            IF NOT p_listremark.EXISTS (UPPER (p_remark))
            THEN
                l_reccodevalue :=
                    pkg_codevalue.f_getfromcode (
                        p_remark,
                        pkg_codereference.cst_crf_midatloadcmt);

                IF NOT l_reccodevalue.cvl_id IS NULL
                THEN -- En pricipe cette condition est toujours vrai puisque cela a été testé
                    l_listremark (UPPER (p_remark)) := l_reccodevalue.cvl_id;
                END IF;
            END IF;
        END IF;

        RETURN l_listremark;
    END;

    /*-----------------------------------------------------------------------------------*/
    PROCEDURE p_savedeterminator (
        p_sph_id         IN sampleheader.sph_id%TYPE,
        p_determinator   IN sampleheaderitem.shm_item%TYPE,
        p_usr_id         IN sampleheaderitem.shm_usr_id_create%TYPE,
        p_ptv_id         IN sampleheaderitem.shm_ptv_id%TYPE,
        p_lan_id         IN sampleheaderitem.shm_lan_id%TYPE)
    /*-----------------------------------------------------------------------------------*/
    IS
        l_recordvaluedeterminator   codevalue%ROWTYPE;
        l_shm_id                    sampleheaderitem.shm_id%TYPE;
    BEGIN
        l_recordvaluedeterminator :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_determinator,
                pkg_codereference.cst_crf_midathditmty);

        IF l_recordvaluedeterminator.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_determinator
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        pkg_sampleheaderitem.p_write (
            p_sph_id,
            p_lan_id,
            l_recordvaluedeterminator.cvl_id,
            p_ptv_id,
            pkg_sampleheaderitem.cst_typecodefromexcelform,
            p_determinator,
            NULL,                                                   --p_per_id
            p_usr_id,
            l_shm_id);

        NULL;
    END;


    /*-----------------------------------------------------------------------------------*/
    PROCEDURE p_save_v2_data (
        p_sph_id         IN sampleheader.sph_id%TYPE,
        p_remarktext     IN sampleheader.sph_comment%TYPE,
        p_remarkcode1    IN importmassdataheader.imh_remarkcode1%TYPE,
        p_remarkcode2    IN importmassdataheader.imh_remarkcode2%TYPE,
        p_remarkcode3    IN importmassdataheader.imh_remarkcode3%TYPE,
        p_remarkcode4    IN importmassdataheader.imh_remarkcode4%TYPE,
        p_determinator   IN sampleheaderitem.shm_item%TYPE,
        p_ptv_id         IN sampleheaderitem.shm_ptv_id%TYPE,
        p_lan_id         IN sampleheaderitem.shm_lan_id%TYPE,
        p_usr_id         IN sampleheader.sph_usr_id_modify%TYPE)
    /*-----------------------------------------------------------------------------------*/
    IS
        -- On filtre aussi les remarque pour ne pas enregistrer de doublons
        l_listremark   t_listremark;
    BEGIN
        -- On met a jour le text de la remarque textuel
        IF NOT p_remarktext IS NULL
        THEN
            p_update_comment (p_sph_id, p_remarktext, p_usr_id);
        END IF;

        IF NOT p_remarkcode1 IS NULL
        THEN
            l_listremark := f_add2listremark (p_remarkcode1, l_listremark);
        END IF;

        IF NOT p_remarkcode2 IS NULL
        THEN
            l_listremark := f_add2listremark (p_remarkcode2, l_listremark);
        END IF;

        IF NOT p_remarkcode3 IS NULL
        THEN
            l_listremark := f_add2listremark (p_remarkcode3, l_listremark);
        END IF;

        IF NOT p_remarkcode4 IS NULL
        THEN
            l_listremark := f_add2listremark (p_remarkcode4, l_listremark);
        END IF;

        p_insert_remarkcode (p_sph_id, l_listremark, p_usr_id);

        IF NOT p_determinator IS NULL
        THEN
            p_savedeterminator (p_sph_id,
                                p_determinator,
                                p_usr_id,
                                p_ptv_id,
                                p_lan_id);
        END IF;
    END;


    /*-------------------------------------------------------------------*/
    PROCEDURE p_saveprotocolmassheader (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_lan_id                    IN language.lan_id%TYPE,
        p_usr_id                    IN sampleprotocolgrnd.spd_usr_id_create%TYPE,
        p_smf_id                    IN sampleheader.sph_smf_id%TYPE,
        p_visibilitystatus          IN sampleheader.sph_visibilitystatus%TYPE,
        p_publicstatus              IN VARCHAR2)
    /*------------------------------------------------------------------------*/

    IS
        CURSOR l_protocolmassheader
        IS
            SELECT *
              FROM importmassdataheader
             WHERE     imh_iph_id = p_recimportprotocolheader.iph_id
                   AND imh_validstatus = pkg_constante.cst_validstatusok;

        l_recprotocolmassheader        l_protocolmassheader%ROWTYPE;

        l_observationdate              DATE;
        l_sph_id                       sampleheader.sph_id%TYPE;
        l_codevalue                    codevalue%ROWTYPE;
        l_makroindexprovide            sampleheader.sph_makroindexvalue_orig%TYPE;
        l_sph_cvl_id_sysprecisionref   sampleheader.sph_cvl_id_sysprecisionref%TYPE;
        l_sph_cvl_id_sysprecision      sampleheader.sph_cvl_id_sysprecision%TYPE;
        l_spearindexcalculation        BOOLEAN;
        l_makroindexcalculation        BOOLEAN;
        l_ibchindexcalculation         BOOLEAN;
        l_reporturl                    importmassdataheader.imh_reporturl%TYPE;

        l_ivr_id_spear                 indiceversion.ivr_id%TYPE;
        l_ivr_id_ibch                  indiceversion.ivr_id%TYPE;
        l_ivr_id_makroindex            indiceversion.ivr_id%TYPE;
    BEGIN
        l_ivr_id_spear := NULL;
        l_ivr_id_ibch := NULL;
        l_ivr_id_makroindex := NULL;


        OPEN l_protocolmassheader;

        LOOP
            FETCH l_protocolmassheader INTO l_recprotocolmassheader;

            EXIT WHEN l_protocolmassheader%NOTFOUND;
            pkg_sampleheader.p_setiffilledivr_id (
                l_recprotocolmassheader.imh_spearvalue,
                l_recprotocolmassheader.imh_ibchvalue,
                l_recprotocolmassheader.imh_makroindexvalue,
                l_ivr_id_spear,
                l_ivr_id_ibch,
                l_ivr_id_makroindex);



            l_observationdate :=
                pkg_datatype.f_validatedate (
                       l_recprotocolmassheader.imh_day
                    || '/'
                    || l_recprotocolmassheader.imh_month
                    || '/'
                    || l_recprotocolmassheader.imh_year);
            pkg_debug.p_write (
                'PKG_IMPORTMASSDATAHEADER.p_saveprotocolmassheader',
                'Observation:=' || l_observationdate);

            IF NOT l_recprotocolmassheader.imh_indicetype IS NULL
            THEN
                p_returnindexcalculation (l_recprotocolmassheader.imh_id,
                                          l_spearindexcalculation,
                                          l_makroindexcalculation,
                                          l_ibchindexcalculation);

                -- On sauve dans  imh_cvl_id_midatstat la valeur de l'identifiant makroindex ou IBCH. Le SPEAR est calculé pour tout
                IF l_makroindexcalculation
                THEN
                    l_codevalue :=
                        pkg_codevalue.f_getfromcode (
                            pkg_codevalue.cst_midatindice_makroindex,
                            pkg_codereference.cst_crf_midatindice);
                ELSIF l_ibchindexcalculation
                THEN
                    l_codevalue :=
                        pkg_codevalue.f_getfromcode (
                            pkg_codevalue.cst_midatindice_ibch,
                            pkg_codereference.cst_crf_midatindice);
                END IF;
            ELSIF l_spearindexcalculation
            THEN
                l_codevalue :=
                    pkg_codevalue.f_getfromcode (
                        pkg_codevalue.cst_midatindice_spear,
                        pkg_codereference.cst_crf_midatindice);
            ELSE
                l_codevalue.cvl_id := NULL;
            END IF;

            IF NOT l_recprotocolmassheader.imh_makroindexprovide IS NULL
            THEN
                l_makroindexprovide :=
                    pkg_datatype.f_validatedouble (
                        l_recprotocolmassheader.imh_makroindexprovide);
            ELSE
                l_makroindexprovide := NULL;
            END IF;

            p_identifiecodeprecisionsource (p_recimportprotocolheader,
                                            l_recprotocolmassheader,
                                            l_sph_cvl_id_sysprecisionref,
                                            l_sph_cvl_id_sysprecision);
            l_reporturl := NULL;

            IF l_recprotocolmassheader.imh_reporturl IS NULL
            THEN
                IF NOT p_recimportprotocolheader.iph_reporturl IS NULL
                THEN
                    l_reporturl := p_recimportprotocolheader.iph_reporturl;
                END IF;
            ELSE
                l_reporturl := l_recprotocolmassheader.imh_reporturl;
            END IF;

            pkg_sampleheader.p_savealldata (
                p_recimportprotocolheader.iph_lan_id,
                p_usr_id,
                p_smf_id,
                l_recprotocolmassheader.imh_sst_id,
                p_recimportprotocolheader.iph_id,
                l_recprotocolmassheader.imh_id,
                p_recimportprotocolheader.iph_ins_id_principal,
                p_recimportprotocolheader.iph_ins_id_mandatary,
                l_sph_cvl_id_sysprecisionref,
                l_sph_cvl_id_sysprecision,
                p_recimportprotocolheader.iph_ptv_id,
                p_recimportprotocolheader.iph_cvl_id_windowibch,
                NULL,                         -- indice makroindex pas calculé
                p_recimportprotocolheader.iph_cvl_id_windowspear,
                l_recprotocolmassheader.imh_project,
                p_recimportprotocolheader.iph_determinateddate,
                l_codevalue.cvl_id, --- l_recprotocolmassheader.imh_cvl_id_midatstat,
                p_recimportprotocolheader.iph_absolutenumberflag,
                l_observationdate,
                l_recprotocolmassheader.imh_day,
                l_recprotocolmassheader.imh_month,
                l_recprotocolmassheader.imh_year,
                l_recprotocolmassheader.imh_period,
                l_recprotocolmassheader.imh_locality,
                l_recprotocolmassheader.imh_watercourse,
                l_recprotocolmassheader.imh_calledplace,
                NULL,                                                 ---Title
                l_reporturl,
                l_recprotocolmassheader.imh_ibchindexprovide, -- sph_indexvalueibch_orig
                l_recprotocolmassheader.imh_ibchvalue,
                l_makroindexprovide,
                l_recprotocolmassheader.imh_makroindexvalue,
                l_recprotocolmassheader.imh_spearindexprovide,
                l_recprotocolmassheader.imh_spearvalue,
                l_recprotocolmassheader.imh_cvl_id_mkicase,
                l_recprotocolmassheader.imh_mkirangecount,
                l_recprotocolmassheader.imh_mkiinsectacount,
                l_recprotocolmassheader.imh_mkinonisectacount,
                l_recprotocolmassheader.imh_mkiplecopteracount,
                l_recprotocolmassheader.imh_mkitricopteracount,
                l_recprotocolmassheader.imh_mkiephemeropteracount,
                l_recprotocolmassheader.imh_mkibaetidaecount,
                l_recprotocolmassheader.imh_mkigammaruscount,
                l_recprotocolmassheader.imh_mkihydropsychecount,
                l_recprotocolmassheader.imh_mkiaselluscount,
                l_recprotocolmassheader.imh_mkihirudinaecount,
                l_recprotocolmassheader.imh_mkitubificidaecount,
                l_recprotocolmassheader.imh_mkierrornumber,
                l_recprotocolmassheader.imh_identifiedtaxoncount,
                l_recprotocolmassheader.imh_identifiedtaxoncountlowlev,
                l_recprotocolmassheader.imh_identifiedtaxoncountuplev,
                l_recprotocolmassheader.imh_ibchidentifiedtaxoncount,
                l_recprotocolmassheader.imh_spearidentifiedtaxoncount,
                l_recprotocolmassheader.imh_ibchgivalue,
                l_recprotocolmassheader.imh_ibchvtvalue,
                p_visibilitystatus,
                l_recprotocolmassheader.imh_observers,
                l_recprotocolmassheader.imh_prj_id,
                l_ivr_id_spear,
                l_ivr_id_ibch,
                l_ivr_id_makroindex,
                l_sph_id);
            pkg_importmassdataheader.p_save_v2_data (
                l_sph_id,
                l_recprotocolmassheader.imh_remarktext,
                l_recprotocolmassheader.imh_remarkcode1,
                l_recprotocolmassheader.imh_remarkcode2,
                l_recprotocolmassheader.imh_remarkcode3,
                l_recprotocolmassheader.imh_remarkcode4,
                l_recprotocolmassheader.imh_determinator,
                p_recimportprotocolheader.iph_ptv_id,
                p_lan_id,
                p_usr_id);
            pkg_importmassdatadetail.p_saveprotocolmassdetail (
                p_recimportprotocolheader,
                l_recprotocolmassheader,
                l_sph_id,
                p_lan_id,
                p_usr_id);
            -- On met à jour la liste des droit d'accès en fonction de la distance pas rapport au canton
            pkg_sampleheaderadmingroup.p_updateadmingroup (l_sph_id,
                                                           p_usr_id);
            -- On met à jour les droits s'accès par rapport au droit public
            pkg_sampleheaderadmingroup.p_setorunsetrightpublic (
                l_sph_id,
                p_publicstatus,
                p_usr_id);
            -- On met à jour l'ordre de tri
            pkg_sampleprotocollabo.p_routeupdatesortorder (l_sph_id);
            pkg_sampleheader.p_saveibch_statdata (l_sph_id);
        END LOOP;

        CLOSE l_protocolmassheader;
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_update_imh_ims_id (
        p_ims_id_concerve   IN importmassdataheader.imh_ims_id%TYPE,
        p_ims_id_supprime   IN importmassdataheader.imh_ims_id%TYPE,
        p_usr_id            IN importmassdataheader.imh_usr_id_modify%TYPE)
    /*------------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_ims_id = p_ims_id_concerve,
               imh_usr_id_modify = p_usr_id,
               imh_usr_modify_date = SYSDATE
         WHERE imh_ims_id = p_ims_id_supprime;
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_update_imh_sst_id (
        p_imh_id   IN importmassdataheader.imh_id%TYPE,
        p_sst_id   IN importmassdataheader.imh_sst_id%TYPE,
        p_usr_id   IN importmassdataheader.imh_usr_id_modify%TYPE)
    /*------------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_sst_id = p_sst_id,
               imh_usr_id_modify = p_usr_id,
               imh_usr_modify_date = SYSDATE
         WHERE imh_id = p_imh_id;
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_update_imh_sst_id_by_ims_id (
        p_ims_id   IN importmassdataheader.imh_ims_id%TYPE,
        p_sst_id   IN importmassdataheader.imh_sst_id%TYPE,
        p_usr_id   IN importmassdataheader.imh_usr_id_modify%TYPE)
    /*------------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_sst_id = p_sst_id,
               imh_usr_id_modify = p_usr_id,
               imh_usr_modify_date = SYSDATE
         WHERE imh_ims_id = p_ims_id;
    END;


    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_update_imh_ims_id (
        p_iph_id         IN importmassdataheader.imh_iph_id%TYPE,
        p_ims_id         IN importmassdataheader.imh_ims_id%TYPE,
        p_oid            IN importmassdataheader.imh_oid%TYPE,
        p_startpoint_x   IN importmassdataheader.imh_startpoint_x%TYPE,
        p_startpoint_y   IN importmassdataheader.imh_startpoint_y%TYPE,
        p_elevation      IN importmassdataheader.imh_elevation%TYPE,
        p_usr_id         IN importmassdataheader.imh_usr_id_modify%TYPE)
    /*-----------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_ims_id = p_ims_id,
               imh_usr_id_modify = p_usr_id,
               imh_usr_modify_date = SYSDATE
         WHERE     NVL (p_oid, 'XXX') = NVL (imh_oid, 'XXX')
               AND NVL (p_startpoint_x, 'XXX') =
                   NVL (imh_startpoint_x, 'XXX')
               AND NVL (p_startpoint_y, 'XXX') =
                   NVL (imh_startpoint_y, 'XXX')
               AND NVL (p_elevation, 'XXX') = NVL (imh_elevation, 'XXX')
               AND imh_validstatus !=
                   pkg_importprotocolheader.cst_validstatusnotok
               AND imh_iph_id = p_iph_id;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_returncounter (
        p_iph_id                 IN     importmassdataheader.imh_iph_id%TYPE,
        p_totalcounter              OUT NUMBER,
        p_validcounter              OUT NUMBER,
        p_invalidcounter            OUT NUMBER,
        p_allreadyexistcounter      OUT NUMBER)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        SELECT COUNT (*)
          INTO p_totalcounter
          FROM importmassdataheader
         WHERE imh_iph_id = p_iph_id;

        SELECT COUNT (*)
          INTO p_validcounter
          FROM importmassdataheader
         WHERE     imh_iph_id = p_iph_id
               AND imh_validstatus = pkg_constante.cst_validstatusok;

        SELECT COUNT (*)
          INTO p_invalidcounter
          FROM importmassdataheader
         WHERE     imh_iph_id = p_iph_id
               AND imh_validstatus = pkg_constante.cst_validstatusnotok;


        SELECT COUNT (*)
          INTO p_allreadyexistcounter
          FROM importmassdataheader
         WHERE     imh_iph_id = p_iph_id
               AND imh_validstatus =
                   pkg_constante.cst_validstatusallreadyexist;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_updateelevation (
        p_imh_id                   IN importmassdataheader.imh_id%TYPE,
        p_elevation                IN importmassdataheader.imh_elevation%TYPE,
        p_cvl_id_elevationorigin   IN importmassdataheader.imh_cvl_id_elevationorigin%TYPE,
        p_elevationprecision       IN importmassdataheader.imh_elevationprecision%TYPE)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_elevation = p_elevation,
               imh_cvl_id_elevationorigin = p_cvl_id_elevationorigin,
               imh_elevationprecision = p_elevationprecision,
               imh_usr_modify_date = SYSDATE
         WHERE imh_id = p_imh_id;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_setvalidstatuscascade (
        p_imh_id        IN importmassdataheader.imh_id%TYPE,
        p_validstatus   IN importmassdataheader.imh_validstatus%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        IF p_validstatus = pkg_constante.cst_validstatusnotok
        THEN
            -- UPDATE par CASCADE
            UPDATE importmassdatadetail
               SET imd_validstatus = p_validstatus
             WHERE imd_imh_id = p_imh_id;

            UPDATE importmassdataheader
               SET imh_validstatus = p_validstatus
             WHERE imh_id = p_imh_id;
        ELSE
            UPDATE importmassdataheader
               SET imh_validstatus = p_validstatus
             WHERE imh_id = p_imh_id;
        END IF;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_builddatetxt (
        p_recimportmassdataheader   IN importmassdataheader%ROWTYPE)
        RETURN VARCHAR2
    /*---------------------------------------------------------------*/
    IS
        l_datetxt   VARCHAR2 (256);
    BEGIN
        l_datetxt :=
               p_recimportmassdataheader.imh_day
            || '/'
            || p_recimportmassdataheader.imh_month
            || '/'
            || p_recimportmassdataheader.imh_year;
        RETURN l_datetxt;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_countrows (p_iph_id IN importmassdataheader.imh_iph_id%TYPE)
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM importmassdataheader
         WHERE imh_iph_id = p_iph_id;

        RETURN l_count;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_countrowsstatusvalid (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE)
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM importmassdataheader
         WHERE     imh_iph_id = p_iph_id
               AND imh_validstatus = pkg_constante.cst_validstatusok;

        RETURN l_count;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_countrowsstatuspending (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE)
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM importmassdataheader
         WHERE     imh_iph_id = p_iph_id
               AND imh_validstatus = pkg_constante.cst_validstatuspending;

        RETURN l_count;
    END;


    /*---------------------------------------------------------------*/
    FUNCTION f_buildswisscoord (
        p_recimportmassdataheader   IN importmassdataheader%ROWTYPE)
        RETURN VARCHAR2
    /*---------------------------------------------------------------*/
    IS
        l_swisscoord   VARCHAR2 (256);
    BEGIN
        l_swisscoord :=
               p_recimportmassdataheader.imh_startpoint_x
            || '; '
            || p_recimportmassdataheader.imh_startpoint_y
            || '; '
            || p_recimportmassdataheader.imh_elevation;
        RETURN l_swisscoord;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_getrecord (p_imh_id IN importmassdataheader.imh_id%TYPE)
        RETURN importmassdataheader%ROWTYPE
    /*----------------------------------------------------------------*/
    IS
        l_record   importmassdataheader%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_record
          FROM importmassdataheader
         WHERE imh_id = p_imh_id;

        RETURN l_record;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addsystemprecision (
        p_value             IN     importmassdataheader.imh_systemprecision%TYPE,
        p_systemprecision   IN OUT t_systemprecision)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_systemprecision.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_systemprecision (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_systemprecision.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_systemprecision.EXTEND (1);
            p_systemprecision (p_systemprecision.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addcodeprecision (
        p_value           IN     importmassdataheader.imh_codeprecision%TYPE,
        p_codeprecision   IN OUT t_codeprecision)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_codeprecision.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_codeprecision (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_codeprecision.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_codeprecision.EXTEND (1);
            p_codeprecision (p_codeprecision.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addoid (p_value   IN     importmassdataheader.imh_oid%TYPE,
                        p_oid     IN OUT t_oid)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_oid.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_oid (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_oid.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_oid.EXTEND (1);
            p_oid (p_oid.LAST) := p_value;
        END IF;
    END;


    /*----------------------------------------------------------------*/
    PROCEDURE p_addwatercourse (
        p_value         IN     importmassdataheader.imh_watercourse%TYPE,
        p_watercourse   IN OUT t_watercourse)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_watercourse.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_watercourse (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_watercourse.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_watercourse.EXTEND (1);
            p_watercourse (p_watercourse.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addlocality (
        p_value      IN     importmassdataheader.imh_locality%TYPE,
        p_locality   IN OUT t_locality)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_locality.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_locality (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_locality.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_locality.EXTEND (1);
            p_locality (p_locality.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addcalledplace (
        p_value         IN     importmassdataheader.imh_calledplace%TYPE,
        p_calledplace   IN OUT t_calledplace)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_calledplace.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_calledplace (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_calledplace.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_calledplace.EXTEND (1);
            p_calledplace (p_calledplace.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addobservers (
        p_value       IN     importmassdataheader.imh_observers%TYPE,
        p_observers   IN OUT t_observers)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_observers.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_observers (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_observers.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_observers.EXTEND (1);
            p_observers (p_observers.LAST) := p_value;
        END IF;
    END;


    /*----------------------------------------------------------------*/
    PROCEDURE p_addperiod (
        p_value    IN     importmassdataheader.imh_period%TYPE,
        p_period   IN OUT t_period)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_period.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_period (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_period.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_period.EXTEND (1);
            p_period (p_period.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addproject (
        p_value     IN     importmassdataheader.imh_project%TYPE,
        p_project   IN OUT t_project)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_project.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_project (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_project.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_project.EXTEND (1);
            p_project (p_project.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addreporturl (
        p_value       IN     importmassdataheader.imh_reporturl%TYPE,
        p_reporturl   IN OUT t_reporturl)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_reporturl.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_reporturl (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_reporturl.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_reporturl.EXTEND (1);
            p_reporturl (p_reporturl.LAST) := p_value;
        END IF;
    END;


    /*----------------------------------------------------------------*/
    PROCEDURE p_addmakroindexprovide (
        p_value               IN     importmassdataheader.imh_makroindexprovide%TYPE,
        p_makroindexprovide   IN OUT t_makroindexprovide)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_makroindexprovide.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_makroindexprovide (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_makroindexprovide.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_makroindexprovide.EXTEND (1);
            p_makroindexprovide (p_makroindexprovide.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addspearindexprovide (
        p_value               IN     importmassdataheader.imh_spearindexprovide%TYPE,
        p_spearindexprovide   IN OUT t_spearindexprovide)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_spearindexprovide.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_spearindexprovide (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_spearindexprovide.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_spearindexprovide.EXTEND (1);
            p_spearindexprovide (p_spearindexprovide.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addibchindexprovide (
        p_value              IN     importmassdataheader.imh_ibchindexprovide%TYPE,
        p_ibchindexprovide   IN OUT t_ibchindexprovide)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        l_indice := p_ibchindexprovide.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_ibchindexprovide (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_ibchindexprovide.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_ibchindexprovide.EXTEND (1);
            p_ibchindexprovide (p_ibchindexprovide.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addelevation (
        p_value       IN     importmassdataheader.imh_elevation%TYPE,
        p_elevation   IN OUT t_elevation)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        pkg_debug.p_write ('PKG_IMPORTMASSDATAHEADER.p_addelevation',
                           'p_value=' || p_value);

        l_indice := p_elevation.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_elevation (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_elevation.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_elevation.EXTEND (1);
            p_elevation (p_elevation.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addindicetype (
        p_value        IN     importmassdataheader.imh_indicetype%TYPE,
        p_indicetype   IN OUT t_indicetype)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        pkg_debug.p_write ('PKG_IMPORTMASSDATAHEADER.p_addindicetype',
                           'p_value=' || p_value);

        l_indice := p_indicetype.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_indicetype (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_indicetype.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_indicetype.EXTEND (1);
            p_indicetype (p_indicetype.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addremarkcode1 (
        p_value         IN     importmassdataheader.imh_remarkcode1%TYPE,
        p_remarkcode1   IN OUT t_remarkcode1)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        pkg_debug.p_write ('PKG_IMPORTMASSDATAHEADER.p_addremarkcode1',
                           'p_value=' || p_value);

        l_indice := p_remarkcode1.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_remarkcode1 (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_remarkcode1.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_remarkcode1.EXTEND (1);
            p_remarkcode1 (p_remarkcode1.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addremarkcode2 (
        p_value         IN     importmassdataheader.imh_remarkcode2%TYPE,
        p_remarkcode2   IN OUT t_remarkcode2)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        pkg_debug.p_write ('PKG_IMPORTMASSDATAHEADER.p_addremarkcode2',
                           'p_value=' || p_value);

        l_indice := p_remarkcode2.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_remarkcode2 (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_remarkcode2.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_remarkcode2.EXTEND (1);
            p_remarkcode2 (p_remarkcode2.LAST) := p_value;
        END IF;
    END;


    /*----------------------------------------------------------------*/
    PROCEDURE p_addremarkcode3 (
        p_value         IN     importmassdataheader.imh_remarkcode3%TYPE,
        p_remarkcode3   IN OUT t_remarkcode3)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        pkg_debug.p_write ('PKG_IMPORTMASSDATAHEADER.p_addremarkcode3',
                           'p_value=' || p_value);

        l_indice := p_remarkcode3.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_remarkcode3 (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_remarkcode3.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_remarkcode3.EXTEND (1);
            p_remarkcode3 (p_remarkcode3.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addremarkcode4 (
        p_value         IN     importmassdataheader.imh_remarkcode4%TYPE,
        p_remarkcode4   IN OUT t_remarkcode4)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        pkg_debug.p_write ('PKG_IMPORTMASSDATAHEADER.p_addremarkcode4',
                           'p_value=' || p_value);

        l_indice := p_remarkcode4.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_remarkcode4 (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_remarkcode4.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_remarkcode4.EXTEND (1);
            p_remarkcode4 (p_remarkcode4.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addremarktext (
        p_value        IN     importmassdataheader.imh_remarktext%TYPE,
        p_remarktext   IN OUT t_remarktext)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        pkg_debug.p_write ('PKG_IMPORTMASSDATAHEADER.p_addremarktest',
                           'p_value=' || p_value);

        l_indice := p_remarktext.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_remarktext (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_remarktext.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_remarktext.EXTEND (1);
            p_remarktext (p_remarktext.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addoidlink (
        p_value     IN     importmassdataheader.imh_oidlink%TYPE,
        p_oidlink   IN OUT t_oidlink)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        pkg_debug.p_write ('PKG_IMPORTMASSDATAHEADER.p_addoidlink',
                           'p_value=' || p_value);

        l_indice := p_oidlink.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_oidlink (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_oidlink.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_oidlink.EXTEND (1);
            p_oidlink (p_oidlink.LAST) := p_value;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_adddeterminator (
        p_value          IN     importmassdataheader.imh_determinator%TYPE,
        p_determinator   IN OUT t_determinator)
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        IF p_value IS NULL
        THEN
            RETURN;
        END IF;

        pkg_debug.p_write ('PKG_IMPORTMASSDATAHEADER.p_adddeterminator',
                           'p_value=' || p_value);

        l_indice := p_determinator.FIRST;

        WHILE NOT l_found AND NOT l_indice IS NULL
        LOOP
            IF p_determinator (l_indice) = p_value
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_determinator.NEXT (l_indice);
        END LOOP;

        IF NOT l_found
        THEN
            p_determinator.EXTEND (1);
            p_determinator (p_determinator.LAST) := p_value;
        END IF;
    END;



    /*---------------------------------------------------------------*/
    PROCEDURE p_delete (p_imh_id IN importmassdataheader.imh_id%TYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        pkg_importprotocollog.p_purgebyimh_id (p_imh_id);
        pkg_importmassdatadetail.p_deletebyimhid (p_imh_id);

        DELETE FROM importmassdataheader
              WHERE imh_id = p_imh_id;
    END;



    /*---------------------------------------------------------------*/
    PROCEDURE p_deletebyiph_id (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        pkg_importmassdatadetail.p_deletebyiph_id (p_iph_id);

        DELETE FROM importmassdataheader
              WHERE imh_iph_id = p_iph_id;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_setvalidstatus (
        p_imh_id   IN importmassdataheader.imh_id%TYPE,
        p_status   IN importmassdataheader.imh_validstatus%TYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_validstatus = p_status
         WHERE imh_id = p_imh_id;
    END;


    /*--------------------------------------------------------------*/

    PROCEDURE p_updateheader (
        p_imh_id                  IN importmassdataheader.imh_id%TYPE,
        p_imh_systemprecision     IN importmassdataheader.imh_systemprecision%TYPE,
        p_imh_codeprecision       IN importmassdataheader.imh_codeprecision%TYPE,
        p_imh_oid                 IN importmassdataheader.imh_oid%TYPE,
        p_imh_watercourse         IN importmassdataheader.imh_watercourse%TYPE,
        p_imh_locality            IN importmassdataheader.imh_locality%TYPE,
        p_imh_calledplace         IN importmassdataheader.imh_calledplace%TYPE,
        p_imh_observers           IN importmassdataheader.imh_observers%TYPE,
        p_imh_period              IN importmassdataheader.imh_period%TYPE,
        p_imh_project             IN importmassdataheader.imh_project%TYPE,
        p_imh_reporturl           IN importmassdataheader.imh_reporturl%TYPE,
        p_imh_makroindexprovide   IN importmassdataheader.imh_makroindexprovide%TYPE,
        p_imh_spearindexprovide   IN importmassdataheader.imh_spearindexprovide%TYPE,
        p_imh_ibchindexprovide    IN importmassdataheader.imh_spearindexprovide%TYPE,
        p_imh_elevation           IN importmassdataheader.imh_elevation%TYPE,
        p_imh_indicetype          IN importmassdataheader.imh_indicetype%TYPE,
        p_remarkcode1             IN importmassdataheader.imh_remarkcode1%TYPE,
        p_remarkcode2             IN importmassdataheader.imh_remarkcode2%TYPE,
        p_remarkcode3             IN importmassdataheader.imh_remarkcode3%TYPE,
        p_remarkcode4             IN importmassdataheader.imh_remarkcode4%TYPE,
        p_remarktext              IN importmassdataheader.imh_remarktext%TYPE,
        p_oidlink                 IN importmassdataheader.imh_oidlink%TYPE,
        p_determinator            IN importmassdataheader.imh_determinator%TYPE)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        pkg_debug.p_write (
            'PKG_IMPORTMASSDATAHEADER.p_updateheader',
               ' p_imh_makroindexprovide='
            || p_imh_makroindexprovide
            || ' p_imh_id='
            || p_imh_id);

        UPDATE importmassdataheader
           SET imh_systemprecision = p_imh_systemprecision,
               imh_codeprecision = p_imh_codeprecision,
               imh_oid = p_imh_oid,
               imh_watercourse = p_imh_watercourse,
               imh_locality = p_imh_locality,
               imh_calledplace = p_imh_calledplace,
               imh_observers = p_imh_observers,
               imh_period = p_imh_period,
               imh_project = p_imh_project,
               imh_makroindexprovide = p_imh_makroindexprovide,
               imh_spearindexprovide = p_imh_spearindexprovide,
               imh_ibchindexprovide = p_imh_ibchindexprovide,
               imh_elevation = p_imh_elevation,
               imh_indicetype = p_imh_indicetype,
               imh_remarkcode1 = p_remarkcode1,
               imh_remarkcode2 = p_remarkcode2,
               imh_remarkcode3 = p_remarkcode3,
               imh_remarkcode4 = p_remarkcode4,
               imh_remarktext = p_remarktext,
               imh_oidlink = p_oidlink,
               imh_determinator = p_determinator
         WHERE imh_id = p_imh_id;

        NULL;
    END;


    /*--------------------------------------------------------------*/

    PROCEDURE p_addheader (
        p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
        p_day            IN     importmassdataheader.imh_day%TYPE,
        p_month          IN     importmassdataheader.imh_month%TYPE,
        p_year           IN     importmassdataheader.imh_year%TYPE,
        p_startpoint_x   IN     importmassdataheader.imh_startpoint_x%TYPE,
        p_startpoint_y   IN     importmassdataheader.imh_startpoint_y%TYPE,
        p_elevation      IN     importmassdataheader.imh_elevation%TYPE,
        p_prj_id         IN     importmassdataheader.imh_prj_id%TYPE,
        p_imh_id            OUT importmassdataheader.imh_id%TYPE)
    /*-------------------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);
        p_imh_id := seq_importmassdataheader.NEXTVAL;

        INSERT INTO importmassdataheader (imh_id,
                                          imh_iph_id,
                                          imh_day,
                                          imh_month,
                                          imh_year,
                                          imh_startpoint_x,
                                          imh_startpoint_y,
                                          imh_elevation,
                                          imh_usr_id_create,
                                          imh_usr_create_date)
             VALUES (p_imh_id,
                     p_iph_id,
                     p_day,
                     p_month,
                     p_year,
                     p_startpoint_x,
                     p_startpoint_y,
                     p_elevation,
                     l_recimportprotocolheader.iph_usr_id_create,
                     SYSDATE);

        NULL;
    END;

    /*--------------------------------------------------------------------------------*/
    PROCEDURE p_updatetaxoncounterinfodata (
        p_imh_id                       IN importmassdataheader.imh_id%TYPE,
        p_identifiedtaxoncount         IN importmassdataheader.imh_identifiedtaxoncount%TYPE,
        p_identifiedtaxoncountlowlev   IN importmassdataheader.imh_identifiedtaxoncountlowlev%TYPE,
        p_identifiedtaxoncountuplev    IN importmassdataheader.imh_identifiedtaxoncountuplev%TYPE)
    /*--------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_identifiedtaxoncount = p_identifiedtaxoncount,
               imh_identifiedtaxoncountlowlev = p_identifiedtaxoncountlowlev,
               imh_identifiedtaxoncountuplev = p_identifiedtaxoncountuplev
         WHERE imh_id = p_imh_id;
    END;

    /*------------------------------------------------------------------------------*/
    PROCEDURE p_updatemkiinfodata (
        p_imh_id                  IN importmassdataheader.imh_id%TYPE,
        p_cvl_id_mkicase          IN importmassdataheader.imh_cvl_id_mkicase%TYPE,
        p_mkiinsectacount         IN importmassdataheader.imh_mkiinsectacount%TYPE,
        p_mkinonisectacount       IN importmassdataheader.imh_mkinonisectacount%TYPE,
        p_mkirangecount           IN importmassdataheader.imh_mkirangecount%TYPE,
        p_mkiplecopteracount      IN importmassdataheader.imh_mkiplecopteracount%TYPE,
        p_mkitricopteracount      IN importmassdataheader.imh_mkitricopteracount%TYPE,
        p_mkiephemeropteracount   IN importmassdataheader.imh_mkiephemeropteracount%TYPE,
        p_mkigaetidaecount        IN importmassdataheader.imh_mkibaetidaecount%TYPE,
        p_mkigammaruscount        IN importmassdataheader.imh_mkigammaruscount%TYPE,
        p_mkihydropsychecount     IN importmassdataheader.imh_mkihydropsychecount%TYPE,
        p_mkiaselluscount         IN importmassdataheader.imh_mkiaselluscount%TYPE,
        p_mkihirudinaecount       IN importmassdataheader.imh_mkihirudinaecount%TYPE,
        p_mkitubificidaecount     IN importmassdataheader.imh_mkitubificidaecount%TYPE,
        p_mkierrornumber          IN importmassdataheader.imh_mkierrornumber%TYPE)
    /*----------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_cvl_id_mkicase = p_cvl_id_mkicase,
               imh_mkiinsectacount = p_mkiinsectacount,
               imh_mkinonisectacount = p_mkinonisectacount,
               imh_mkirangecount = p_mkirangecount,
               imh_mkiplecopteracount = p_mkiplecopteracount,
               imh_mkitricopteracount = p_mkitricopteracount,
               imh_mkiephemeropteracount = p_mkiephemeropteracount,
               imh_mkibaetidaecount = p_mkigaetidaecount,
               imh_mkigammaruscount = p_mkigammaruscount,
               imh_mkihydropsychecount = p_mkihydropsychecount,
               imh_mkiaselluscount = p_mkiaselluscount,
               imh_mkihirudinaecount = p_mkihirudinaecount,
               imh_mkitubificidaecount = p_mkitubificidaecount,
               imh_mkierrornumber = p_mkierrornumber
         WHERE imh_id = p_imh_id;
    END;

    /*---------------------------------------------------------------------------------------------*/
    PROCEDURE p_updateibchinfodata (
        p_imh_id                     IN importmassdataheader.imh_id%TYPE,
        p_ibchidentifiedtaxoncount   IN importmassdataheader.imh_ibchidentifiedtaxoncount%TYPE,
        p_ibchgivalue                IN importmassdataheader.imh_ibchgivalue%TYPE,
        p_ibchvtvalue                   importmassdataheader.imh_ibchvtvalue%TYPE)
    /*---------------------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_ibchidentifiedtaxoncount = p_ibchidentifiedtaxoncount,
               imh_ibchgivalue = p_ibchgivalue,
               imh_ibchvtvalue = p_ibchvtvalue
         WHERE imh_id = p_imh_id;
    END;

    /*---------------------------------------------------------------------------------------------*/
    PROCEDURE p_updatespearinfodata (
        p_imh_id                      IN importmassdataheader.imh_id%TYPE,
        p_spearidentifiedtaxoncount   IN importmassdataheader.imh_spearidentifiedtaxoncount%TYPE)
    /*--------------------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_spearidentifiedtaxoncount = p_spearidentifiedtaxoncount
         WHERE imh_id = p_imh_id;
    END;
END;
/

