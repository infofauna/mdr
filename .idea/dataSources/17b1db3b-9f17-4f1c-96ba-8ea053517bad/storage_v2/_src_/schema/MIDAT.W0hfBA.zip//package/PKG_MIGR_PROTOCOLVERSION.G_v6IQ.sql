create PACKAGE       pkg_migr_protocolversion
AS
   /******************************************************************************
      NAME:       PKG_MIGR_PROTOCOLVERSION
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_insertdatatest;
END pkg_migr_protocolversion;
/

