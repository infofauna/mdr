create PACKAGE BODY       pkg_protocolmappinggrnd
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLMAPPINGGRND
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_returnfullpath (p_pmr_id IN protocolmappinggrnd.pmr_id%TYPE)
      RETURN VARCHAR2
   /*-------------------------------------------------------------*/
   IS
      l_string   VARCHAR2 (4096);
   BEGIN
      DBMS_OUTPUT.put_line ('p_pmr_id=' || TO_CHAR (p_pmr_id));

          SELECT SYS_CONNECT_BY_PATH (
                    pkg_protocolmappinggrnd.f_returndatalabel (pmr_id, 1),
                    '-->')
            INTO l_string
            FROM protocolmappinggrnd
           WHERE pmr_id = p_pmr_id
      CONNECT BY PRIOR pmr_id = pmr_pmr_id
      START WITH pmr_pmr_id IS NULL;

      RETURN l_string;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_identifiypmr_id (p_string           IN VARCHAR2,
                               p_pmr_separator    IN VARCHAR2,
                               p_levelseparator   IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE
   /*-------------------------------------------------------------*/
   IS
      l_pospmr     PLS_INTEGER;
      l_poslevel   PLS_INTEGER;
      l_pmr_id     protocolmappinggrnd.pmr_id%TYPE;
   BEGIN
      l_pospmr := INSTR (p_string, p_pmr_separator);

      IF l_pospmr = 0
      THEN
         RETURN NULL;
      END IF;

      l_poslevel := INSTR (p_string, p_levelseparator, l_pospmr);

      IF l_poslevel = 0
      THEN
         l_pmr_id := TO_NUMBER (SUBSTR (p_string, l_pospmr + 1));
      ELSE
         l_pmr_id :=
            TO_NUMBER (
               SUBSTR (p_string, l_pospmr + 1, l_poslevel - l_pospmr - 1));
      END IF;

      RETURN l_pmr_id;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_likeinstring (p_string IN VARCHAR2, p_keys IN VARCHAR2)
      RETURN NUMBER
   /*------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM DUAL
       WHERE p_string LIKE p_keys;

      RETURN l_count;
   END;



   /*-------------------------------------------------------------*/
   FUNCTION f_identifymaxleaf (
      p_ptv_id       IN protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_keymaxleaf   IN codevalue.cvl_code%TYPE,
      p_allkeys      IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE
   /*-----------------------------------------------------------*/
   IS
      CURSOR l_cursor
      IS
             SELECT SYS_CONNECT_BY_PATH (cvl_code || '#' || pmr_id, '/')
                       connect_path
               FROM protocolmappinggrnd
                    INNER JOIN codevalue c1 ON c1.cvl_id = pmr_cvl_id_midatgrnd
         CONNECT BY pmr_id = PRIOR pmr_pmr_id
         START WITH cvl_code = p_keymaxleaf;

      l_reccursor   l_cursor%ROWTYPE;
      l_pmr_id      protocolmappinggrnd.pmr_id%TYPE := NULL;
      l_count       NUMBER;
      l_error       BOOLEAN := FALSE;
   BEGIN
      DBMS_OUTPUT.put_line (' p_keymaxleaf=' || p_keymaxleaf);
      DBMS_OUTPUT.put_line (' p_allkeys=' || p_allkeys);
      pkg_debug.p_write (
         'PKG_PROTOCOLMAPPINGGRND.f_identifymaxleaf',
         'p_keymaxleaf=' || p_keymaxleaf || ' p_allkeys=' || p_allkeys);

      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         DBMS_OUTPUT.put_line (l_reccursor.connect_path);


         EXIT WHEN l_cursor%NOTFOUND AND NOT l_error;
         l_count := f_likeinstring (l_reccursor.connect_path, p_allkeys);

         IF l_count > 0
         THEN
            IF NOT l_pmr_id IS NULL
            THEN
               -- Existe déjà : pas identifié
               l_error := TRUE;
            ELSE
               l_pmr_id :=
                  f_identifiypmr_id (l_reccursor.connect_path, '#', '/');

               IF l_pmr_id IS NULL
               THEN
                  l_error := TRUE;
               END IF;
            END IF;
         END IF;
      END LOOP;

      CLOSE l_cursor;

      DBMS_OUTPUT.put_line (' l_pmr_id=' || l_pmr_id);
      pkg_debug.p_write ('PKG_PROTOCOLMAPPINGGRND.f_identifymaxleaf',
                         'l_pmr_id=' || l_pmr_id);
      RETURN l_pmr_id;
      NULL;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_test
   /*--------------------------------------------------------------*/
   IS
      l_keymaxleaf   VARCHAR2 (256);
      l_allkeys      VARCHAR2 (1024);
      l_pmr_id       protocolmappinggrnd.pmr_id%TYPE;
   BEGIN
      l_keymaxleaf := 'RIVEGAUCHE';
      l_allkeys := '%RIVEGAUCHE%PERMRENFORG%ECOMORPH%';
      l_pmr_id := f_identifymaxleaf (3, l_keymaxleaf, l_allkeys);
      DBMS_OUTPUT.put_line ('l_pmr_id=' || l_pmr_id);
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_countchildren (p_pmr_id IN protocolmappinggrnd.pmr_id%TYPE)
      RETURN NUMBER
   /*--------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM protocolmappinggrnd
       WHERE pmr_pmr_id = p_pmr_id;
       

      RETURN l_count;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_countsettedchildren (
      p_iph_id   IN importprotocolheader.iph_id%TYPE,
      p_pmr_id   IN protocolmappinggrnd.pmr_id%TYPE)
      RETURN NUMBER
   /*---------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM importprotocolgrnd
       WHERE     ipn_iph_id = p_iph_id
             AND ipn_pmr_id IN (SELECT pmr_id
                                  FROM protocolmappinggrnd
                                 WHERE pmr_pmr_id = p_pmr_id)
             AND NOT ipn_value IS NULL;

      RETURN l_count;
   END;


   /*---------------------------------------------------------------*/
   FUNCTION f_getpmridbykeys (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_key1     IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE
   /*---------------------------------------------------------------*/
   IS
      l_allkeys   VARCHAR2 (1024);
   BEGIN
      l_allkeys := '%' || p_key1 || '%';
      RETURN f_identifymaxleaf (p_ptv_id, p_key1, l_allkeys);
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getpmridbykeys (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE
   /*---------------------------------------------------------------*/
   IS
      l_allkeys   VARCHAR2 (1024);
   BEGIN
      l_allkeys := '%' || p_key1 || '%' || p_key2 || '%';
      RETURN f_identifymaxleaf (p_ptv_id, p_key1, l_allkeys);
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getpmridbykeys (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE
   /*---------------------------------------------------------------*/
   IS
      l_allkeys   VARCHAR2 (1024);
   BEGIN
      l_allkeys := '%' || p_key1 || '%' || p_key2 || '%' || p_key3 || '%';

      RETURN f_identifymaxleaf (p_ptv_id, p_key1, l_allkeys);
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getpmridbykeys (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2,
      p_key4     IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE
   /*---------------------------------------------------------------*/
   IS
      l_allkeys   VARCHAR2 (1024);
   BEGIN
      l_allkeys :=
            '%'
         || p_key1
         || '%'
         || p_key2
         || '%'
         || p_key3
         || '%'
         || p_key4
         || '%';
      RETURN f_identifymaxleaf (p_ptv_id, p_key1, l_allkeys);
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getpmridbykeys (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2,
      p_key4     IN VARCHAR2,
      p_key5     IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE
   /*---------------------------------------------------------------*/
   IS
      l_allkeys   VARCHAR2 (1024);
   BEGIN
      l_allkeys :=
            '%'
         || p_key1
         || '%'
         || p_key2
         || '%'
         || p_key3
         || '%'
         || p_key4
         || '%'
         || p_key5
         || '%';
      RETURN f_identifymaxleaf (p_ptv_id, p_key1, l_allkeys);
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_test1
   /*--------------------------------------------------------------*/
   IS
      l_key1      VARCHAR2 (10) := 'PRONONCE';
      l_allkeys   VARCHAR2 (30) := '%PRONONCE%VARIALIT%ECOMORPH%';
      l_pmr_id    protocolmappinggrnd.pmr_id%TYPE := NULL;
   BEGIN
      l_pmr_id := f_identifymaxleaf (3, l_key1, l_allkeys);
      DBMS_OUTPUT.put_line ('l_pmr_id:=' || l_pmr_id);
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_getattr (
      p_pmr_id      IN     protocolmappinggrnd.pmr_id%TYPE,
      p_morevalue      OUT protocolmappinggrnd.pmr_morevalue%TYPE,
      p_isnotnull      OUT protocolmappinggrnd.pmr_isnotnull%TYPE)
   /*--------------------------------------------------------------*/
   IS
      l_recprotocolmappinggrnd         protocolmappinggrnd%ROWTYPE;
      l_recprotocolmappinggrndparent   protocolmappinggrnd%ROWTYPE;
   BEGIN
      p_morevalue := NULL;
      p_isnotnull := NULL;
      l_recprotocolmappinggrnd := f_getrecord (p_pmr_id);

      IF l_recprotocolmappinggrnd.pmr_id IS NULL
      THEN
         RETURN;
      END IF;

      p_morevalue := l_recprotocolmappinggrnd.pmr_morevalue;
      p_isnotnull := l_recprotocolmappinggrnd.pmr_isnotnull;

      IF l_recprotocolmappinggrnd.pmr_pmr_id IS NULL
      THEN
         RETURN;
      END IF;

      l_recprotocolmappinggrndparent :=
         f_getrecord (l_recprotocolmappinggrnd.pmr_pmr_id);

      IF p_morevalue IS NULL
      THEN
         p_morevalue := l_recprotocolmappinggrndparent.pmr_morevalue;
      END IF;

      IF p_isnotnull IS NULL
      THEN
         p_isnotnull := l_recprotocolmappinggrndparent.pmr_isnotnull;
      END IF;
   END;


   /*-------------------------------------------------------------*/
   PROCEDURE p_deleteversion (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM protocolmappinggrnd
            WHERE pmr_ptv_id = p_ptv_id;
   END;



   /*----------------------------------------------------------*/
   FUNCTION f_gethierarchy (p_pmr_id      IN protocolmappinggrnd.pmr_id%TYPE,
                            p_lan_id      IN codedesignation.cdn_lan_id%TYPE,
                            p_separator   IN VARCHAR2)
      RETURN VARCHAR2
   /*----------------------------------------------------------*/
   IS
   BEGIN
      NULL;
   END;

   /*---------------------------------------------------------*/
   FUNCTION f_getrecordparent (p_pmr_id IN protocolmappinggrnd.pmr_id%TYPE)
      RETURN protocolmappinggrnd%ROWTYPE
   /*---------------------------------------------------------*/
   IS
      l_morevalue                      protocolmappinggrnd.pmr_morevalue%TYPE;
      l_recprotocolmappinggrnd         protocolmappinggrnd%ROWTYPE;
      l_recprotocolmappinggrndparent   protocolmappinggrnd%ROWTYPE;
   BEGIN
      l_recprotocolmappinggrnd := f_getrecord (p_pmr_id);

      IF l_recprotocolmappinggrnd.pmr_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      l_recprotocolmappinggrndparent :=
         f_getrecord (l_recprotocolmappinggrnd.pmr_pmr_id);



      RETURN l_recprotocolmappinggrndparent;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_getrecord (p_pmr_id IN protocolmappinggrnd.pmr_id%TYPE)
      RETURN protocolmappinggrnd%ROWTYPE
   /*-------------------------------------------------------------*/
   IS
      l_record   protocolmappinggrnd%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM protocolmappinggrnd
       WHERE pmr_id = p_pmr_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------------------------*/
   FUNCTION f_returndatalabel (p_pmr_id   IN protocolmappinggrnd.pmr_id%TYPE,
                               p_lan_id   IN language.lan_id%TYPE)
      RETURN codedesignation.cdn_designation%TYPE
   /*--------------------------------------------------------------------------------*/
   IS
      l_recprotocolmappinggrnd   protocolmappinggrnd%ROWTYPE;
      l_reccodedesignation       codedesignation%ROWTYPE;
   BEGIN
      l_recprotocolmappinggrnd := f_getrecord (p_pmr_id);

      IF l_recprotocolmappinggrnd.pmr_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      l_reccodedesignation :=
         pkg_codedesignation.f_returnrecmaintypeatleastone (
            l_recprotocolmappinggrnd.pmr_cvl_id_midatgrnd,
            p_lan_id);

      IF l_reccodedesignation.cdn_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      RETURN l_reccodedesignation.cdn_designation;
   END;



   /*-------------------------------------------------------------------------------*/
   PROCEDURE p_write (
      p_ptv_id             IN     protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_sortorder          IN     protocolmappinggrnd.pmr_sortorder%TYPE,
      p_pmr_id_parent      IN     protocolmappinggrnd.pmr_pmr_id%TYPE,
      p_cvl_id_midatgrnd   IN     protocolmappinggrnd.pmr_cvl_id_midatgrnd%TYPE,
      p_cellrowvalue       IN     protocolmappinggrnd.pmr_cellrowvalue%TYPE,
      p_cellcolumnvalue    IN     protocolmappinggrnd.pmr_cellcolumnvalue%TYPE,
      p_cvl_id_datatype    IN     protocolmappinggrnd.pmr_cvl_id_datatype%TYPE,
      p_morevalue          IN     protocolmappinggrnd.pmr_morevalue%TYPE,
      p_isnotnull          IN     protocolmappinggrnd.pmr_isnotnull%TYPE,
      p_id                    OUT protocolmappinggrnd.pmr_id%TYPE)
   /*-------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_protocolmappinggrnd.NEXTVAL;

      INSERT INTO protocolmappinggrnd (pmr_id,
                                       pmr_ptv_id,
                                       pmr_sortorder,
                                       pmr_pmr_id,
                                       pmr_cvl_id_midatgrnd,
                                       pmr_cellrowvalue,
                                       pmr_cellcolumnvalue,
                                       pmr_cvl_id_datatype,
                                       pmr_morevalue,
                                       pmr_isnotnull)
           VALUES (p_id,
                   p_ptv_id,
                   p_sortorder,
                   p_pmr_id_parent,
                   p_cvl_id_midatgrnd,
                   p_cellrowvalue,
                   p_cellcolumnvalue,
                   p_cvl_id_datatype,
                   p_morevalue,
                   p_isnotnull);
   END;

   /*-------------------------------------------------------------------------------*/
   PROCEDURE p_update (
      p_id                    OUT protocolmappinggrnd.pmr_id%TYPE,
      p_ptv_id             IN     protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_sortorder          IN     protocolmappinggrnd.pmr_sortorder%TYPE,
      p_pmr_id_parent      IN     protocolmappinggrnd.pmr_pmr_id%TYPE,
      p_cvl_id_midatgrnd   IN     protocolmappinggrnd.pmr_cvl_id_midatgrnd%TYPE,
      p_cellrowvalue       IN     protocolmappinggrnd.pmr_cellrowvalue%TYPE,
      p_cellcolumnvalue    IN     protocolmappinggrnd.pmr_cellcolumnvalue%TYPE,
      p_cvl_id_datatype    IN     protocolmappinggrnd.pmr_cvl_id_datatype%TYPE,
      pmr_morevalue        IN     protocolmappinggrnd.pmr_morevalue%TYPE)
   /*-------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE protocolmappinggrnd
         SET pmr_ptv_id = p_ptv_id,
             pmr_sortorder = p_sortorder,
             pmr_pmr_id = p_pmr_id_parent,
             pmr_cvl_id_midatgrnd = p_cvl_id_midatgrnd,
             pmr_cellrowvalue = p_cellrowvalue,
             pmr_cellcolumnvalue = p_cellcolumnvalue,
             pmr_cvl_id_datatype = p_cvl_id_datatype,
             pmr_morevalue = pmr_morevalue,
             pmr_isnotnull = pmr_isnotnull
       WHERE pmr_id = p_id;
   END;
END;
/

