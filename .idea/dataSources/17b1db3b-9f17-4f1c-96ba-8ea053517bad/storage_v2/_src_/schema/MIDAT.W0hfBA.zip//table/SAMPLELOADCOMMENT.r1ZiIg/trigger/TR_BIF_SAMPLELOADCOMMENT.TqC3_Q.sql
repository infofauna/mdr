create trigger TR_BIF_SAMPLELOADCOMMENT
    before insert
    on SAMPLELOADCOMMENT
    for each row
BEGIN
   IF :new.slc_id IS NULL
   THEN
      :new.slc_id := seq_sampleloadcomment.NEXTVAL;
   END IF;

   :new.slc_credate := SYSDATE;
   :new.slc_moduser := USER;
END;

/

