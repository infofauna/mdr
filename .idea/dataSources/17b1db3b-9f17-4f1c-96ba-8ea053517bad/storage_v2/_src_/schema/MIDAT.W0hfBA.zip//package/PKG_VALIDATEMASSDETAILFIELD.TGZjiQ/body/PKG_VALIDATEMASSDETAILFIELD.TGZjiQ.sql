create PACKAGE BODY       pkg_validatemassdetailfield
AS
    /******************************************************************************
       NAME:       pkg_validatemassheaderfield
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        25.09.2013      burrif       1. Created this package.
       1.1        17.02.2016       burrif      2. Modification de la règle d'identification des niveaux
                                                             Dans le champ SOUS-ESPECE on cherche les niveaux FORM, Aggrégat de sous espèce, saus-espèce
                                                             Dans le champ Espece on cheche les niveaus ESPECES, agrégat d'espèce
                                                             Dans le champ genre on cherche le GENRE, le SOUS-GENRE
                                                             Dans le champ FAMILLE on cherche la sous-famille, la tribut
                                                             Dans le champ TAXON_SUP on cherche PHYLUM, SUBPHILUM,  INFRAPHYLUM,  CLASS, SUBCLASS, INFRACLASS,
                                                              SUPERORDRE, ORDRE, SOUS-ORDRE,INFRAORDRE, SUPERFAMILLE
        1.2          20.02.2020       burrif      3. Prise en compte des taxon ibch de deux familles dans le même champ
 ******************************************************************************/



    TYPE t_recdesignationbuffer IS RECORD
    (
        tlb_crf_code    codereference.crf_code%TYPE,
        tlb_taxon       systdesignation.syd_designation%TYPE
    );

    TYPE t_listdesignationbuffer IS TABLE OF t_recdesignationbuffer
        INDEX BY PLS_INTEGER;



    cst_packageversion      CONSTANT VARCHAR2 (30)
                                         := 'Version 1.2, février 2020' ;

    gbl_skipibchtaxa                 BOOLEAN := FALSE;
    gbl_identifiedtaxoncountlowlev   NUMBER := 0;
    gbl_identifiedtaxoncountuplev    NUMBER := 0;
    gbl_identifiedtaxoncount         NUMBER := 0;


    /*
      IMD_ID               NUMBER,
     IMD_STATUS           CHAR(1 BYTE)             DEFAULT 'A',
     IMD_VALIDSTATUS      CHAR(1 BYTE)             DEFAULT 'P',
     IMD_IMH_ID           NUMBER,                                                         --  Calculé par PKG_IMPORTMASSDATADETAIL.p_identifyheader
     IMD_IPH_ID           NUMBER,                                                          -- Initialisé par PKG_IMPORTMASSDATADETAIL.p_flushfielddata
     IMD_SOURCELINE       NUMBER,                                                     -- Initialisé par PKG_IMPORTMASSDATADETAIL.p_flushfielddata
     IMD_HIGHERTAXON      VARCHAR2(60 BYTE),                                 -- Validé par pkg_validatemassdetalfield
     IMD_FAMILY           VARCHAR2(60 BYTE),                                       -- Validé par pkg_validatemassdetalfield
     IMD_GENUS            VARCHAR2(60 BYTE),                                       -- Validé par pkg_validatemassdetalfield
     IMD_SPECIES          VARCHAR2(60 BYTE),                                       -- Validé par pkg_validatemassdetalfield
     IMD_SUBSPECIES       VARCHAR2(60 BYTE),                                     Validé par pkg_validatemassdetalfield
     IMD_FREQ1            VARCHAR2(30 BYTE),                                         Validé par pkg_validatemassdetalfield
     IMD_FREQ2            VARCHAR2(30 BYTE),                                         Validé par pkg_validatemassdetalfield
     IMD_FREQLUM          VARCHAR2(30 BYTE),                                       Validé par pkg_validatemassdetalfield
     IMD_STADIUM          VARCHAR2(60 BYTE),                                        Validé par pkg_validatemassdetalfield
     IMD_SAMPLINGMETHOD   VARCHAR2(60 BYTE),                                 Validé par pkg_validatemassheaderield
     IMD_INDICETYPE       VARCHAR2(39 BYTE),                                        Validé par pkg_validatemassheaderield
     IMD_PERIOD           VARCHAR2(60 BYTE),                                          Validé par pkg_validatemassheaderield
     IMD_DAY              VARCHAR2(10 BYTE),                                            Validé par pkg_validatemassheaderield
     IMD_MONTH            VARCHAR2(10 BYTE),                                         Validé par pkg_validatemassheaderield
     IMD_YEAR             VARCHAR2(10 BYTE),                                            Validé par pkg_validatemassheaderield
     IMD_WATERCOURSE      VARCHAR2(60 BYTE),                                    Validé par pkg_validatemassheaderield
     IMD_LOCALITY         VARCHAR2(60 BYTE),                                         Validé par pkg_validatemassheaderield
     IMD_CALLEDPLACE      VARCHAR2(256 BYTE),                                     Validé par pkg_validatemassheaderield
     IMD_SWISSCOORD_X     VARCHAR2(30 BYTE),                                   Validé par pkg_validatemassheaderield
     IMD_SWISSCOORD_Y     VARCHAR2(30 BYTE),                                    Validé par pkg_validatemassheaderield
     IMD_SWISSCOORD_Z     VARCHAR2(30 BYTE),                                    Validé par pkg_validatemassheaderield
     IMD_OBSERVERS        VARCHAR2(60 BYTE),                                       Validé par pkg_validatemassheaderield
     IMD_PROJECT          VARCHAR2(256 BYTE),                                         Validé par pkg_validatemassheaderield
     IMD_TAXON_DEF        VARCHAR2(30 BYTE),
     IMD_CODEPRECISION    VARCHAR2(60 BYTE),                                      Validé par pkg_validatemassheaderield
     IMD_SYSTEMPRECISION  VARCHAR2(60 BYTE),                                    Validé par pkg_validatemassheaderield
     IMD_SAMPLENUMBER     VARCHAR2(60 BYTE),                                     Validé par pkg_validatemassheaderield
     IMD_CANTON           VARCHAR2(10 BYTE),                                          Validé par pkg_validatemassheaderield
     IMD_OID              VARCHAR2(30 BYTE),                                              Validé par pkg_validatemassheaderield
     IMD_PRCODE           VARCHAR2(60 BYTE),                                           Validé par pkg_validatemassheaderield
     IMD_COMMENT          VARCHAR2(256 BYTE),                                       Validé par pkg_validatemassheaderield
     IMD_REPORTURL        VARCHAR2(512 BYTE),                                        Validé par pkg_validatemassheaderield
     */
    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_resetgblidenttaxoncounter
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        gbl_identifiedtaxoncountlowlev := 0;
        gbl_identifiedtaxoncountuplev := 0;
        gbl_identifiedtaxoncount := 0;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_addidentifiedtaxoncount (p_count IN NUMBER)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        gbl_identifiedtaxoncount := gbl_identifiedtaxoncount + p_count;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_addidentifiedtaxoncountuplev (p_count IN NUMBER)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        gbl_identifiedtaxoncountuplev :=
            gbl_identifiedtaxoncountuplev + p_count;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_identifiedtaxoncountlowlev (p_count IN NUMBER)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        gbl_identifiedtaxoncountlowlev :=
            gbl_identifiedtaxoncountlowlev + p_count;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_computeskipibchtaxa (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE)
    /*-------------------------------------------------*/
    IS
        l_recprotocolversion           protocolversion%ROWTYPE;
        l_recprotocolversionlabo       protocolversion%ROWTYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;

        l_count                        NUMBER;
        l_excelfield                   VARCHAR2 (256);
    BEGIN
        gbl_skipibchtaxa := FALSE;
        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_fieldrefispresent (
                p_recimportprotocolheader.iph_id,
                pkg_codevalue.cst_midatfldcmt_taxonibch);

        IF l_recimportmassmappingheader.ime_id IS NULL
        THEN
            gbl_skipibchtaxa := TRUE;
            RETURN;
        END IF;


        -- Le champ existe mais il n'est peut-être pas renseigné
        l_count :=
            pkg_importmassdatadetail.f_countfieldfilled (
                p_recimportprotocolheader,
                pkg_codevalue.cst_midatfldcmt_taxonibch);

        IF l_count = 0
        THEN
            gbl_skipibchtaxa := TRUE;
            RETURN;
        END IF;

        l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;
        pkg_importprotocollog.p_writelog (p_recimportprotocolheader.iph_id,
                                          NULL,
                                          pkg_exception.cst_taxonibchchecked,
                                          'IMD_TAXONIBCH',
                                          l_excelfield);

        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                p_recimportprotocolheader.iph_ptv_id);

        IF l_recprotocolversion.ptv_ptv_id_labofrommass IS NULL
        THEN
            -- Ce cas est une erreur

            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_taxonibchsettingmissing,
                'IMD_TAXONIBCH');
            gbl_skipibchtaxa := TRUE;
        ELSE
            l_recprotocolversionlabo :=
                pkg_protocolversion.f_getrecord (
                    l_recprotocolversion.ptv_ptv_id_labofrommass);

            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_taxonibchlaboused,
                'IMD_TAXONIBCH',
                l_recprotocolversionlabo.ptv_text);
        END IF;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_buildsystdesignationfromxls (
        p_importmassdatadetail   IN importmassdatadetail%ROWTYPE)
        RETURN VARCHAR2
    /*------------------------------------------------------------------*/
    IS
        l_systdesignation   VARCHAR2 (1024) := NULL;
    BEGIN
        IF NOT p_importmassdatadetail.imd_highertaxon IS NULL
        THEN
            IF l_systdesignation IS NULL
            THEN
                l_systdesignation := p_importmassdatadetail.imd_highertaxon;
            ELSE
                l_systdesignation :=
                       l_systdesignation
                    || '/'
                    || p_importmassdatadetail.imd_highertaxon;
            END IF;
        END IF;

        IF NOT p_importmassdatadetail.imd_family IS NULL
        THEN
            IF l_systdesignation IS NULL
            THEN
                l_systdesignation := p_importmassdatadetail.imd_family;
            ELSE
                l_systdesignation :=
                       l_systdesignation
                    || '/'
                    || p_importmassdatadetail.imd_family;
            END IF;
        END IF;

        IF NOT p_importmassdatadetail.imd_genus IS NULL
        THEN
            IF l_systdesignation IS NULL
            THEN
                l_systdesignation := p_importmassdatadetail.imd_genus;
            ELSE
                l_systdesignation :=
                       l_systdesignation
                    || '/'
                    || p_importmassdatadetail.imd_genus;
            END IF;
        END IF;


        IF NOT p_importmassdatadetail.imd_species IS NULL
        THEN
            IF l_systdesignation IS NULL
            THEN
                l_systdesignation := p_importmassdatadetail.imd_species;
            ELSE
                l_systdesignation :=
                       l_systdesignation
                    || '/'
                    || p_importmassdatadetail.imd_species;
            END IF;
        END IF;

        IF NOT p_importmassdatadetail.imd_subspecies IS NULL
        THEN
            IF l_systdesignation IS NULL
            THEN
                l_systdesignation := p_importmassdatadetail.imd_subspecies;
            ELSE
                l_systdesignation :=
                       l_systdesignation
                    || '/'
                    || p_importmassdatadetail.imd_species;
            END IF;
        END IF;



        RETURN l_systdesignation;

        NULL;
    END;

    /*-------------------------------------------------------------------*/
    PROCEDURE p_checkibchtaxa (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_importmassdatadetail      IN     importmassdatadetail%ROWTYPE,
        p_lan_id                    IN     language.lan_id%TYPE,
        p_returnstatus                 OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        l_module                       VARCHAR2 (256);
        l_excelfield                   VARCHAR2 (256);
        l_recprotocolmappinglabo       protocolmappinglabo%ROWTYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_recprotocolversion           protocolversion%ROWTYPE;
        l_recprotocolversionlabo       protocolversion%ROWTYPE;
    BEGIN
        RETURN;                                                -- Plus utilisé
        p_returnstatus := pkg_constante.cst_returnstatusok;

        IF gbl_skipibchtaxa
        THEN
            RETURN;
        END IF;

        IF p_importmassdatadetail.imd_taxonibch IS NULL
        THEN
            RETURN;
        END IF;

        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);

        -- On va chercher l'enregistrement de la version du protocol de masse
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                p_recimportprotocolheader.iph_ptv_id);
        l_recprotocolversionlabo :=
            pkg_protocolversion.f_getrecord (
                l_recprotocolversion.ptv_ptv_id_labofrommass);
        -- A partir de la version du prottocol e masse, on dispose de la colonne  PTV_PTV_ID_LABO_FROMMASS
        l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecordbytaxa (
                l_recprotocolversion.ptv_ptv_id_labofrommass,
                p_importmassdatadetail.imd_taxonibch);



        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                l_recimportmassdataheader.imh_iph_id,
                pkg_codevalue.cst_midatfldcmt_taxonibch);

        IF l_recimportmassmappingheader.ime_id IS NULL
        THEN
            l_module :=
                   'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
                || TO_CHAR (l_recimportmassdataheader.imh_iph_id)
                || ','''
                || pkg_codevalue.cst_midatfldcmt_taxonibch
                || ''')';
            pkg_importprotocollog.p_logunexpectederror (
                l_recimportmassdataheader.imh_iph_id,
                'IMD_TAXONIBCH',
                l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;


        IF l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            -- Non trouvé
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                pkg_exception.cst_taxonibchnotfound,
                'IMD_TAXONIBCH',
                l_excelfield,
                p_importmassdatadetail.imd_taxonibch,
                l_recprotocolversionlabo.ptv_text,
                TO_CHAR (p_importmassdatadetail.imd_sourceline));
            pkg_importmassdataheader.p_setvalidstatus (
                p_importmassdatadetail.imd_imh_id,
                pkg_constante.cst_validstatusnotok);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        IF l_recprotocolmappinglabo.ptl_cellcolumnvalue IS NULL
        THEN
            -- Cette valeur n'entre pas dans le calcul de l'IBCH. On fait comme si elle était NULL
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                pkg_exception.cst_taxonibchnotfound,
                'IMD_TAXONIBCH',
                l_excelfield,
                p_importmassdatadetail.imd_taxonibch,
                l_recprotocolversionlabo.ptv_text,
                TO_CHAR (p_importmassdatadetail.imd_sourceline));
            pkg_importmassdataheader.p_setvalidstatus (
                p_importmassdatadetail.imd_imh_id,
                pkg_constante.cst_validstatusnotok);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;


        IF p_returnstatus = pkg_constante.cst_returnstatusok
        THEN
            pkg_importmassdatadetail.p_setptl_id (
                p_importmassdatadetail.imd_id,
                l_recprotocolmappinglabo.ptl_id);
        END IF;

        NULL;
    END;

    /*-------------------------------------------------------------------*/
    PROCEDURE p_checkstadiump (
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_lan_id                 IN     language.lan_id%TYPE,
        p_returnstatus              OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        /*
         pkg_codedesignation.f_findrecbycodeordesignation (
           p_crf_code      IN codereference.crf_code%TYPE,
           p_lan_code      IN language.lan_code%TYPE,
           p_designation   IN codedesignation.cdn_designation%TYPE)
           RETURN codedesignation%ROWTYPE;
           */
        NULL;
    END;

    /*-------------------------------------------------------------------*/
    FUNCTION f_findlevelhyghertaxon (p_taxa IN VARCHAR2)
        RETURN codereference.crf_code%TYPE
    /*--------------------------------------------------------------------*/
    IS
        l_crf_code   codereference.crf_code%TYPE;
        l_response   CHAR (1);
    BEGIN
        l_crf_code := pkg_codereference.cst_crf_superfamil;
        l_response :=
            pkg_systdesignation.f_designationexistatlevel (
                p_taxa,
                l_crf_code,
                pkg_language.cst_lan_cde_latin);

        IF l_response = pkg_constante.cst_yes
        THEN
            RETURN l_crf_code;
        END IF;



        l_crf_code := pkg_codereference.cst_crf_infraclass;
        l_response :=
            pkg_systdesignation.f_designationexistatlevel (
                p_taxa,
                l_crf_code,
                pkg_language.cst_lan_cde_latin);

        IF l_response = pkg_constante.cst_yes
        THEN
            RETURN l_crf_code;
        END IF;

        l_crf_code := pkg_codereference.cst_crf_subclass;
        l_response :=
            pkg_systdesignation.f_designationexistatlevel (
                p_taxa,
                l_crf_code,
                pkg_language.cst_lan_cde_latin);

        IF l_response = pkg_constante.cst_yes
        THEN
            RETURN l_crf_code;
        END IF;

        l_crf_code := pkg_codereference.cst_crf_class;
        l_response :=
            pkg_systdesignation.f_designationexistatlevel (
                p_taxa,
                l_crf_code,
                pkg_language.cst_lan_cde_latin);

        IF l_response = pkg_constante.cst_yes
        THEN
            RETURN l_crf_code;
        END IF;

        l_crf_code := pkg_codereference.cst_crf_infraorder;
        l_response :=
            pkg_systdesignation.f_designationexistatlevel (
                p_taxa,
                l_crf_code,
                pkg_language.cst_lan_cde_latin);

        IF l_response = pkg_constante.cst_yes
        THEN
            RETURN l_crf_code;
        END IF;

        l_crf_code := pkg_codereference.cst_crf_suborder;
        l_response :=
            pkg_systdesignation.f_designationexistatlevel (
                p_taxa,
                l_crf_code,
                pkg_language.cst_lan_cde_latin);

        IF l_response = pkg_constante.cst_yes
        THEN
            RETURN l_crf_code;
        END IF;

        l_crf_code := pkg_codereference.cst_crf_order;
        l_response :=
            pkg_systdesignation.f_designationexistatlevel (
                p_taxa,
                l_crf_code,
                pkg_language.cst_lan_cde_latin);

        IF l_response = pkg_constante.cst_yes
        THEN
            RETURN l_crf_code;
        END IF;

        l_crf_code := pkg_codereference.cst_crf_infraphylu;
        l_response :=
            pkg_systdesignation.f_designationexistatlevel (
                p_taxa,
                l_crf_code,
                pkg_language.cst_lan_cde_latin);

        IF l_response = pkg_constante.cst_yes
        THEN
            RETURN l_crf_code;
        END IF;


        l_crf_code := pkg_codereference.cst_crf_subphylum;
        l_response :=
            pkg_systdesignation.f_designationexistatlevel (
                p_taxa,
                l_crf_code,
                pkg_language.cst_lan_cde_latin);

        IF l_response = pkg_constante.cst_yes
        THEN
            RETURN l_crf_code;
        END IF;


        l_crf_code := pkg_codereference.cst_crf_phylum;
        l_response :=
            pkg_systdesignation.f_designationexistatlevel (
                p_taxa,
                l_crf_code,
                pkg_language.cst_lan_cde_latin);

        IF l_response = pkg_constante.cst_yes
        THEN
            RETURN l_crf_code;
        END IF;



        l_crf_code := pkg_codereference.cst_crf_kingdom;
        l_response :=
            pkg_systdesignation.f_designationexistatlevel (
                p_taxa,
                l_crf_code,
                pkg_language.cst_lan_cde_latin);

        IF l_response = pkg_constante.cst_yes
        THEN
            RETURN l_crf_code;
        END IF;



        RETURN NULL;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
            NULL;
    END;

    /*-------------------------------------------------------------------*/
    FUNCTION f_findlevelsubspecies (p_subspecies IN VARCHAR2)
        RETURN codereference.crf_code%TYPE
    /*--------------------------------------------------------------------*/
    IS
        l_crf_code   codereference.crf_code%TYPE;
    BEGIN
        SELECT DISTINCT crf_code
          INTO l_crf_code
          FROM systdesignation
               INNER JOIN systvalue ON syd_syv_id = syv_id
               INNER JOIN codereference ON crf_id = syv_crf_id
         WHERE     pkg_utility.f_normalisestring (p_subspecies) =
                   pkg_utility.f_normalisestring (syd_designation)
               AND crf_code IN
                       (pkg_codereference.cst_crf_subspecies,
                        pkg_codereference.cst_crf_form);

        RETURN l_crf_code;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
            NULL;
    END;

    /*-------------------------------------------------------------------*/
    FUNCTION f_findlevelspecies (p_species IN VARCHAR2)
        RETURN codereference.crf_code%TYPE
    /*--------------------------------------------------------------------*/
    IS
        l_crf_code   codereference.crf_code%TYPE;
    BEGIN
        SELECT DISTINCT crf_code -- Il peut y avoir plusieurs especes qui porte le même nom
          INTO l_crf_code
          FROM systdesignation
               INNER JOIN systvalue ON syd_syv_id = syv_id
               INNER JOIN codereference ON crf_id = syv_crf_id
         WHERE     pkg_utility.f_normalisestring (p_species) =
                   pkg_utility.f_normalisestring (syd_designation)
               AND crf_code IN
                       (pkg_codereference.cst_crf_species,
                        pkg_codereference.cst_crf_aggspecies,
                        pkg_codereference.cst_crf_aggsubspec);

        RETURN l_crf_code;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
            NULL;
        WHEN TOO_MANY_ROWS
        THEN
            RETURN NULL;
    END;



    /*------------------------------------------------------------------*/
    PROCEDURE p_testhydracarina
    /*------------------------------------------------------------------*/
    IS
        l_crf_code                 codereference.crf_code%TYPE;
        l_syv_startwith            systvalue.syv_id%TYPE; -- Identifiant du niveau le plus bas
        l_crf_id                   codereference.crf_id%TYPE;
        l_flagprecisionmax         CHAR (1);
        l_textwithoutparenthesis   VARCHAR2 (1024) := 'Hydracarina';
    BEGIN
        pkg_systdesignation.p_clearfindbydesignation;
        l_crf_code := f_findlevelhyghertaxon (l_textwithoutparenthesis);

        IF NOT l_crf_code IS NULL
        THEN
            pkg_systdesignation.p_addfindbydesignation (
                pkg_language.cst_lan_cde_latin,
                l_crf_code,
                l_textwithoutparenthesis);
            pkg_systdesignation.p_processfindbydesignation (
                l_syv_startwith,           -- Identifiant du niveu le plus bas
                l_crf_id,                  -- Identifiant du code de référence
                l_flagprecisionmax); -- Flag (Y/N) permttant de savoir si l'élément le plus précis est utilisé
            DBMS_OUTPUT.put_line ('  l_syv_startwith=' || l_syv_startwith);
        END IF;
    END;



    /*-------------------------------------------------------------------*/
    PROCEDURE p_checksystematiqueonlabo (
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_taxa                   IN     protocolmappinglabo.ptl_taxa%TYPE,
        p_fieldcode              IN     codevalue.cvl_code%TYPE,
        p_crf_code                  OUT codereference.crf_code%TYPE, -- Si c'est null, rien trouvé dans le thésaurus et dans protocolmappinglabo
        p_taxa_used                 OUT protocolmappinglabo.ptl_taxacscf%TYPE)
    /*--------------------------------------------------------------------*/
    IS
        l_recprotocolmappinglabo       protocolmappinglabo%ROWTYPE;
        l_recimportprotocolheader      importprotocolheader%ROWTYPE;

        l_recprotocolversion           protocolversion%ROWTYPE;
        l_recprotocolversionlabomass   protocolversion%ROWTYPE;
        l_recsystvalue                 systvalue%ROWTYPE;
        l_reccodereference             codereference%ROWTYPE;
        l_recsystdesignation           systdesignation%ROWTYPE;
        l_fieldname                    VARCHAR2 (30);
        l_listcrf_code                 pkg_systdesignation.t_listcrf_code;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_listtext                     VARCHAR2 (1024);
        l_indice                       PLS_INTEGER;
        l_response                     CHAR (1);
    BEGIN
        IF p_taxa IS NULL
        THEN
            RETURN;
        END IF;

        IF p_fieldcode = pkg_codevalue.cst_midatfldcmt_subspe
        THEN
            p_crf_code := pkg_codereference.cst_crf_subspecies;
            l_response :=
                pkg_systdesignation.f_designationexistatlevel (
                    p_taxa,
                    p_crf_code,
                    pkg_language.cst_lan_cde_latin);

            IF l_response = pkg_constante.cst_no
            THEN
                p_crf_code := pkg_codereference.cst_crf_form;
                l_response :=
                    pkg_systdesignation.f_designationexistatlevel (
                        p_taxa,
                        p_crf_code,
                        pkg_language.cst_lan_cde_latin);

                IF l_response = pkg_constante.cst_no
                THEN
                    p_crf_code := NULL;
                END IF;
            END IF;
        ELSIF p_fieldcode = pkg_codevalue.cst_midatfldcmt_species
        THEN
            p_crf_code := pkg_codereference.cst_crf_species;
            l_response :=
                pkg_systdesignation.f_designationexistatlevel (
                    p_taxa,
                    p_crf_code,
                    pkg_language.cst_lan_cde_latin);

            IF l_response = pkg_constante.cst_no
            THEN
                p_crf_code := pkg_codereference.cst_crf_aggsubspec;
                l_response :=
                    pkg_systdesignation.f_designationexistatlevel (
                        p_taxa,
                        p_crf_code,
                        pkg_language.cst_lan_cde_latin);

                IF l_response = pkg_constante.cst_no
                THEN
                    p_crf_code := pkg_codereference.cst_crf_aggspecies;
                    l_response :=
                        pkg_systdesignation.f_designationexistatlevel (
                            p_taxa,
                            p_crf_code,
                            pkg_language.cst_lan_cde_latin);

                    IF l_response = pkg_constante.cst_no
                    THEN
                        p_crf_code := NULL;
                    END IF;
                END IF;
            END IF;
        ELSIF p_fieldcode = pkg_codevalue.cst_midatfldcmt_genus
        THEN
            l_fieldname := 'IMD_GENUS';
            p_crf_code := pkg_codereference.cst_crf_genus;
            l_response :=
                pkg_systdesignation.f_designationexistatlevel (
                    p_taxa,
                    p_crf_code,
                    pkg_language.cst_lan_cde_latin);

            IF l_response = pkg_constante.cst_no
            THEN
                p_crf_code := NULL;
            END IF;
        ELSIF p_fieldcode = pkg_codevalue.cst_midatfldcmt_family
        THEN
            p_crf_code := pkg_codereference.cst_crf_family;
            l_fieldname := 'IMD_FAMILY';
            l_response :=
                pkg_systdesignation.f_designationexistatlevel (
                    p_taxa,
                    p_crf_code,
                    pkg_language.cst_lan_cde_latin);

            IF l_response = pkg_constante.cst_no
            THEN
                p_crf_code := NULL;
            END IF;
        ELSIF p_fieldcode = pkg_codevalue.cst_midatfldcmt_higher
        THEN
            DBMS_OUTPUT.put_line ('HIGHERTAXON ' || p_taxa);
            p_crf_code := f_findlevelhyghertaxon (p_taxa);
            l_fieldname := 'IMD_HIGHERTAXON';
        END IF;

        IF NOT p_crf_code IS NULL
        THEN
            DBMS_OUTPUT.put_line ('p_crf_code=' || p_crf_code);
            p_taxa_used := p_taxa;

            RETURN;
        END IF;

        DBMS_OUTPUT.put_line ('ICI ' || p_taxa);
        -- On regarde si on trouve ce nom de taxon dans un autre niveau
        l_listcrf_code :=
            pkg_systdesignation.f_finlistcrfidbydesignation (p_taxa);

        IF l_listcrf_code.COUNT > 0
        THEN
            DBMS_OUTPUT.put_line ('AUTRE NIVEAU');
            -- Il est trouvé dans un autre niveau
            --    Le taxon %p1% defini dans la colonne %p2% n'a pas été trouvé dans le thésaurus à ce niveau. Ce nom de taxon est  cependant défini dans le thésaurus au(x) niveau(x) %p3%
            l_indice := l_listcrf_code.FIRST;
            l_listtext := NULL;

            WHILE NOT l_indice IS NULL
            LOOP
                DBMS_OUTPUT.put_line (
                    'AUTRE NIVEAU ' || l_listcrf_code (l_indice));

                IF NOT l_listtext IS NULL
                THEN
                    l_listtext :=
                        l_listtext || ',' || l_listcrf_code (l_indice);
                ELSE
                    l_listtext := l_listcrf_code (l_indice);
                END IF;

                l_indice := l_listcrf_code.NEXT (l_indice);
            END LOOP;

            l_recimportmassmappingheader :=
                pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                    p_importmassdatadetail.imd_iph_id,
                    p_fieldcode);

            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                pkg_exception.cst_taxonlevelmissmatch,
                l_fieldname,
                p_taxa,
                l_recimportmassmappingheader.ime_excelfieldname,
                l_listtext);
            RETURN;
        END IF;


        -- On va essayer de trouver dans protocolmappinglabo
        DBMS_OUTPUT.put_line (
            'On va essayer de trouver dans protocolmappinglabo');


        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (
                p_importmassdatadetail.imd_iph_id);
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                l_recimportprotocolheader.iph_ptv_id);
        l_recprotocolversionlabomass :=
            pkg_protocolversion.f_getrecord (
                l_recprotocolversion.ptv_ptv_id_labofrommass);


        l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecordbytaxa (
                l_recprotocolversion.ptv_ptv_id_labofrommass,
                p_taxa);

        IF l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            RETURN;
        END IF;

        l_recsystvalue :=
            pkg_systvalue.f_getrecord (l_recprotocolmappinglabo.ptl_syv_id);
        l_reccodereference :=
            pkg_codereference.f_getrecord (l_recsystvalue.syv_crf_id);
        p_crf_code := l_reccodereference.crf_code;
        p_taxa_used := l_recprotocolmappinglabo.ptl_taxacscf;
        --Le taxon %p1% n'est pas défini dans le thésaurus global. Il a  été défini uniquement dans le protocole de laboraroire
        -- (version %p2%) qui le référencie comme synonyme du taxon %p3%. Ce nom de taxon (%p4%) est utilisé pour la suite du traitement
        pkg_importprotocollog.p_writelog (
            p_importmassdatadetail.imd_iph_id,
            p_importmassdatadetail.imd_imh_id,
            pkg_exception.cst_taxondefinedinprotocollabo,
            l_fieldname,
            p_taxa,
            l_recprotocolversionlabomass.ptv_version,
            p_taxa_used,
            p_taxa_used);
    END;

    /*---------------------------------------------------------------------*/
    PROCEDURE p_testnemathelminthes
    /*---------------------------------------------------------------------*/
    IS
        l_taxa                      protocolmappinglabo.ptl_taxa%TYPE;
        l_fieldcode                 codevalue.cvl_code%TYPE;
        l_crf_code                  codereference.crf_code%TYPE;
        l_taxa_used                 protocolmappinglabo.ptl_taxacscf%TYPE;
        l_recimportmassdatadetail   importmassdatadetail%ROWTYPE;
    BEGIN
        l_recimportmassdatadetail :=
            pkg_importmassdatadetail.f_getrecord (11363);
        l_taxa := l_recimportmassdatadetail.imd_highertaxon;
        p_checksystematiqueonlabo (l_recimportmassdatadetail,
                                   l_taxa,
                                   pkg_codevalue.cst_midatfldcmt_higher,
                                   l_crf_code,
                                   l_taxa_used);
        DBMS_OUTPUT.put_line ('l_taxa_used:=' || l_taxa_used);
    END;

    /*------------------------------------------------------------------------------*/
    FUNCTION f_getmappingheader (
        p_midatfldcmt   IN codevalue.cvl_code%TYPE,
        p_iph_id           importprotocolheader.iph_id%TYPE)
        RETURN importmassmappingheader%ROWTYPE
    /*------------------------------------------------------------------------------*/
    IS
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_module                       VARCHAR2 (256)
            := 'pkg_validatemassheaderfield.f_getmappingheader';
    BEGIN
        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                p_iph_id,
                p_midatfldcmt);

        IF l_recimportmassmappingheader.ime_id IS NULL
        THEN
            l_module :=
                   'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
                || p_iph_id
                || ','''
                || p_midatfldcmt
                || ''')';
            pkg_importprotocollog.p_logunexpectederror (
                p_iph_id,
                'IMD_HIGHERTAXON, IMD_FAMILY, IMD_GENUS, IMD_SPECIES, IMD_SUBSPECIES',
                l_module);

            RETURN NULL;
        ELSE
            RETURN l_recimportmassmappingheader;
        END IF;
    END;

    /*-----------------------------------------------------------------------------------------------*/
    PROCEDURE p_logparenthesisexist (
        p_importmassdatadetail      IN     importmassdatadetail%ROWTYPE,
        p_taxonoriginal             IN     VARCHAR2,
        p_excelfield                IN     VARCHAR2,
        p_dbfield                   IN     VARCHAR2,
        p_taxonwithoutparenthesis      OUT VARCHAR2)
    /*-----------------------------------------------------------------------------------------------*/
    IS
        l_textbetweenparenthesis   VARCHAR2 (1024);
    BEGIN
        p_taxonwithoutparenthesis :=
            pkg_stringutil.f_removedatainparenthesis (p_taxonoriginal);

        IF p_taxonwithoutparenthesis != p_taxonoriginal
        THEN
            l_textbetweenparenthesis :=
                pkg_stringutil.f_getdatainparenthesis (p_taxonoriginal);
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                pkg_exception.cst_parenthesisvalueremoved,
                p_dbfield,
                p_taxonoriginal,
                p_excelfield,
                l_textbetweenparenthesis,
                TO_CHAR (p_importmassdatadetail.imd_sourceline));
        END IF;
    END;

    /*-----------------------------------------------*/
    PROCEDURE p_processfindbydesignation_spe (
        p_syv_startwith      OUT systvalue.syv_id%TYPE,
        p_crf_id             OUT systvalue.syv_crf_id%TYPE,
        p_flagprecisionmax   OUT VARCHAR2)
    /*-----------------------------------------------*/
    IS
        l_returnstatus   NUMBER;
    /* A faire: Prendre en compte le champ SUBSPE
    */
    BEGIN
        pkg_systdesignation.p_processfindbydesignation (p_syv_startwith, -- Identifiant du niveau le plus bas
                                                        p_crf_id, -- Identifiant du code de référence
                                                        p_flagprecisionmax -- Flag (Y/N) permettant de savoir si l'élément le plus précis est utilisé
                                                                          );

        IF p_syv_startwith IS NULL
        THEN
            -- On essaye avec SAGGUBSPEC
            pkg_systdesignation.p_updcrfcodefindbydesignation (
                1,                      -- Indice l'ordre de l'élément 1,2,3,4
                pkg_codereference.cst_crf_aggsubspec,
                l_returnstatus);

            IF l_returnstatus = pkg_constante.cst_returnstatusok
            THEN
                pkg_systdesignation.p_processfindbydesignation (
                    p_syv_startwith,      -- Identifiant du niveau le plus bas
                    p_crf_id,              -- Identifiant du code de référence
                    p_flagprecisionmax -- Flag (Y/N) permettant de savoir si l'élément le plus précis est utilisé
                                      );

                IF p_syv_startwith IS NULL
                THEN
                    -- On essaye avec AGGSPECIES
                    pkg_systdesignation.p_updcrfcodefindbydesignation (
                        1,              -- Indice l'ordre de l'élément 1,2,3,4
                        pkg_codereference.cst_crf_aggspecies,
                        l_returnstatus);

                    IF l_returnstatus = pkg_constante.cst_returnstatusok
                    THEN
                        pkg_systdesignation.p_processfindbydesignation (
                            p_syv_startwith, -- Identifiant du niveu le plus bas
                            p_crf_id,      -- Identifiant du code de référence
                            p_flagprecisionmax -- Flag (Y/N) permettant de savoir si l'élément le plus précis est utilisé
                                              );
                    END IF;
                END IF;
            END IF;
        END IF;
    END;

    /* ----------------------------------------------------------------------------*/
    FUNCTION f_determinefieldfromcrf_id (
        p_crf_id   IN codereference.crf_id%TYPE)
        RETURN VARCHAR2
    /*-----------------------------------------------------------------------------*/
    IS
        l_reccodereference   codereference%ROWTYPE;
    BEGIN
        l_reccodereference := pkg_codereference.f_getrecord (p_crf_id);

        IF l_reccodereference.crf_id IS NULL
        THEN
            RETURN NULL;
        END IF;

        IF l_reccodereference.crf_code IN
               (pkg_codereference.cst_crf_subspecies,
                pkg_codereference.cst_crf_form,
                pkg_codereference.cst_crf_subform)
        THEN
            RETURN pkg_codevalue.cst_midatfldcmt_subspe;
        END IF;

        IF l_reccodereference.crf_code IN
               (pkg_codereference.cst_crf_species,
                pkg_codereference.cst_crf_aggspecies,
                pkg_codereference.cst_crf_subspecies)
        THEN
            RETURN pkg_codevalue.cst_midatfldcmt_species;
        END IF;

        IF l_reccodereference.crf_code IN
               (pkg_codereference.cst_crf_genus,
                pkg_codereference.cst_crf_subgenus)
        THEN
            RETURN pkg_codevalue.cst_midatfldcmt_genus;
        END IF;

        IF l_reccodereference.crf_code IN
               (pkg_codereference.cst_crf_family,
                pkg_codereference.cst_crf_subfamily)
        THEN
            RETURN pkg_codevalue.cst_midatfldcmt_family;
        END IF;

        IF l_reccodereference.crf_code IN
               (pkg_codereference.cst_crf_superfamil,
                pkg_codereference.cst_crf_phylum,
                pkg_codereference.cst_crf_subphylum,
                pkg_codereference.cst_crf_infraphylu,
                pkg_codereference.cst_crf_class,
                pkg_codereference.cst_crf_infraclass,
                pkg_codereference.cst_crf_subclass,
                pkg_codereference.cst_crf_order,
                pkg_codereference.cst_crf_suborder,
                pkg_codereference.cst_crf_superorder,
                pkg_codereference.cst_crf_infraorder)
        THEN
            RETURN pkg_codevalue.cst_midatfldcmt_higher;
        END IF;

        RETURN NULL;
    END;



    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_refinelistcrf_subspe (
        p_listcrf_subspe   IN OUT pkg_systdesignation.t_listcrf_code)
    /*-----------------------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
    BEGIN
        -- On enleve les codes autres que ceux avec subspe
        l_indice := p_listcrf_subspe.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            IF     p_listcrf_subspe (l_indice) !=
                   pkg_codereference.cst_crf_subspecies
               AND p_listcrf_subspe (l_indice) !=
                   pkg_codereference.cst_crf_form
               AND p_listcrf_subspe (l_indice) !=
                   pkg_codereference.cst_crf_subform
            THEN
                p_listcrf_subspe.delete (l_indice);
            END IF;

            l_indice := p_listcrf_subspe.NEXT (l_indice);
        END LOOP;
    END;

    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_refinelistcrf_species (
        p_listcrf_species   IN OUT pkg_systdesignation.t_listcrf_code)
    /*-----------------------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
    BEGIN
        -- On enleve les codes autres que ceux avec species
        l_indice := p_listcrf_species.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            IF     p_listcrf_species (l_indice) !=
                   pkg_codereference.cst_crf_species
               AND p_listcrf_species (l_indice) !=
                   pkg_codereference.cst_crf_aggsubspec
            THEN
                p_listcrf_species.delete (l_indice);
            END IF;

            l_indice := p_listcrf_species.NEXT (l_indice);
        END LOOP;
    END;

    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_refinelistcrf_genus (
        p_listcrf_genus   IN OUT pkg_systdesignation.t_listcrf_code)
    /*-----------------------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
    BEGIN
        -- On enleve les codes autres que ceux avec genus
        l_indice := p_listcrf_genus.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            IF     p_listcrf_genus (l_indice) !=
                   pkg_codereference.cst_crf_genus
               AND p_listcrf_genus (l_indice) !=
                   pkg_codereference.cst_crf_subgenus
               AND p_listcrf_genus (l_indice) !=
                   pkg_codereference.cst_crf_hybrid
               AND p_listcrf_genus (l_indice) !=
                   pkg_codereference.cst_crf_aggspecies
            THEN
                p_listcrf_genus.delete (l_indice);
            END IF;

            l_indice := p_listcrf_genus.NEXT (l_indice);
        END LOOP;
    END;

    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_refinelistcrf_family (
        p_listcrf_family   IN OUT pkg_systdesignation.t_listcrf_code)
    /*-----------------------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
    BEGIN
        -- On enleve les codes autres que ceux avec family
        l_indice := p_listcrf_family.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            IF     p_listcrf_family (l_indice) !=
                   pkg_codereference.cst_crf_family
               AND p_listcrf_family (l_indice) !=
                   pkg_codereference.cst_crf_subfamily
               AND p_listcrf_family (l_indice) !=
                   pkg_codereference.cst_crf_tribe
            THEN
                p_listcrf_family.delete (l_indice);
            END IF;

            l_indice := p_listcrf_family.NEXT (l_indice);
        END LOOP;
    END;

    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_refinelistcrf_hyghertaxon (
        p_listcrf_hyghertaxon   IN OUT pkg_systdesignation.t_listcrf_code)
    /*-----------------------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
    BEGIN
        -- On enleve les codes autres que ceux avec hyghertaxon
        l_indice := p_listcrf_hyghertaxon.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            IF     p_listcrf_hyghertaxon (l_indice) !=
                   pkg_codereference.cst_crf_superfamil
               AND p_listcrf_hyghertaxon (l_indice) !=
                   pkg_codereference.cst_crf_phylum
               AND p_listcrf_hyghertaxon (l_indice) !=
                   pkg_codereference.cst_crf_subphylum
               AND p_listcrf_hyghertaxon (l_indice) !=
                   pkg_codereference.cst_crf_infraphylu
               AND p_listcrf_hyghertaxon (l_indice) !=
                   pkg_codereference.cst_crf_class
               AND p_listcrf_hyghertaxon (l_indice) !=
                   pkg_codereference.cst_crf_infraclass
               AND p_listcrf_hyghertaxon (l_indice) !=
                   pkg_codereference.cst_crf_subclass
               AND p_listcrf_hyghertaxon (l_indice) !=
                   pkg_codereference.cst_crf_order
               AND p_listcrf_hyghertaxon (l_indice) !=
                   pkg_codereference.cst_crf_suborder
               AND p_listcrf_hyghertaxon (l_indice) !=
                   pkg_codereference.cst_crf_superorder
               AND p_listcrf_hyghertaxon (l_indice) !=
                   pkg_codereference.cst_crf_infraorder
            THEN
                p_listcrf_hyghertaxon.delete (l_indice);
            END IF;

            l_indice := p_listcrf_hyghertaxon.NEXT (l_indice);
        END LOOP;
    END;

    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_swaplistcrf (
        l_listcrf_1   IN OUT pkg_systdesignation.t_listcrf_code,
        l_listcrf_2   IN OUT pkg_systdesignation.t_listcrf_code)
    /*--------------------------------------------------------------------------*/
    IS
        l_listcrf   pkg_systdesignation.t_listcrf_code;
    BEGIN
        l_listcrf := l_listcrf_1;
        l_listcrf_1 := l_listcrf_2;
        l_listcrf_2 := l_listcrf;
    END;

    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_swaptext (p_text1 IN OUT VARCHAR2, p_text2 IN OUT VARCHAR2)
    /*-----------------------------------------------------------------------------*/
    IS
        l_text   VARCHAR2 (2048);
    BEGIN
        l_text := p_text1;
        p_text1 := p_text2;
        p_text2 := l_text;
    END;

    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_sortlistcrf (
        p_listcrf_1   IN OUT pkg_systdesignation.t_listcrf_code,
        p_listcrf_2   IN OUT pkg_systdesignation.t_listcrf_code,
        p_listcrf_3   IN OUT pkg_systdesignation.t_listcrf_code,
        p_listcrf_4   IN OUT pkg_systdesignation.t_listcrf_code,
        p_listcrf_5   IN OUT pkg_systdesignation.t_listcrf_code,
        p_taxon_1     IN OUT systdesignation.syd_designation%TYPE,
        p_taxon_2     IN OUT systdesignation.syd_designation%TYPE,
        p_taxon_3     IN OUT systdesignation.syd_designation%TYPE,
        p_taxon_4     IN OUT systdesignation.syd_designation%TYPE,
        p_taxon_5     IN OUT systdesignation.syd_designation%TYPE)
    /*----------------------------------------------------------------------------*/
    IS
        -- Permet de trier la liste des liste dans l'ordre inverse du nombre d'élément
        l_listcrf   pkg_systdesignation.t_listcrf_code;
    BEGIN
        IF p_listcrf_2.COUNT > p_listcrf_1.COUNT
        THEN
            p_swaplistcrf (p_listcrf_1, p_listcrf_2);
            p_swaptext (p_taxon_1, p_taxon_2);
        END IF;

        IF p_listcrf_3.COUNT > p_listcrf_1.COUNT
        THEN
            p_swaplistcrf (p_listcrf_1, p_listcrf_3);
            p_swaptext (p_taxon_1, p_taxon_3);
        END IF;

        IF p_listcrf_4.COUNT > p_listcrf_1.COUNT
        THEN
            p_swaplistcrf (p_listcrf_1, p_listcrf_4);
            p_swaptext (p_taxon_1, p_taxon_4);
        END IF;

        IF p_listcrf_5.COUNT > p_listcrf_1.COUNT
        THEN
            p_swaplistcrf (p_listcrf_1, p_listcrf_5);
            p_swaptext (p_taxon_1, p_taxon_5);
        END IF;


        IF p_listcrf_3.COUNT > p_listcrf_2.COUNT
        THEN
            p_swaplistcrf (p_listcrf_2, p_listcrf_3);
            p_swaptext (p_taxon_2, p_taxon_3);
        END IF;

        IF p_listcrf_4.COUNT > p_listcrf_2.COUNT
        THEN
            p_swaplistcrf (p_listcrf_2, p_listcrf_4);
            p_swaptext (p_taxon_2, p_taxon_4);
        END IF;

        IF p_listcrf_5.COUNT > p_listcrf_2.COUNT
        THEN
            p_swaplistcrf (p_listcrf_2, p_listcrf_5);
            p_swaptext (p_taxon_2, p_taxon_5);
        END IF;

        IF p_listcrf_4.COUNT > p_listcrf_3.COUNT
        THEN
            p_swaplistcrf (p_listcrf_3, p_listcrf_4);
            p_swaptext (p_taxon_3, p_taxon_4);
        END IF;

        IF p_listcrf_5.COUNT > p_listcrf_3.COUNT
        THEN
            p_swaplistcrf (p_listcrf_3, p_listcrf_5);
            p_swaptext (p_taxon_3, p_taxon_5);
        END IF;

        IF p_listcrf_5.COUNT > p_listcrf_4.COUNT
        THEN
            p_swaplistcrf (p_listcrf_4, p_listcrf_5);
            p_swaptext (p_taxon_4, p_taxon_5);
        END IF;
    END;

    /*------------------------------------------------------------------------------*/
    PROCEDURE p_flushfordesignation (
        l_listdesignationbuffer   IN     t_listdesignationbuffer,
        p_syv_startwith              OUT systvalue.syv_id%TYPE,
        p_crf_id                     OUT codereference.crf_id%TYPE,
        p_flagprecisionmax           OUT CHAR)
    /*------------------------------------------------------------------------------*/
    IS
        l_indice             PLS_INTEGER;

        l_flagprecisionmax   CHAR (1);
    BEGIN
        pkg_systdesignation.p_clearfindbydesignation;
        l_indice := l_listdesignationbuffer.LAST;
        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_flushfordesignation',
            'Start addfield...');

        WHILE NOT l_indice IS NULL
        LOOP
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_flushfordesignation',
                   'CRF_CODE='
                || l_listdesignationbuffer (l_indice).tlb_crf_code
                || ' l_listdesignationbuffer (l_indice).tlb_taxon='
                || l_listdesignationbuffer (l_indice).tlb_taxon);
            pkg_systdesignation.p_addfindbydesignation (
                pkg_language.cst_lan_cde_latin,
                l_listdesignationbuffer (l_indice).tlb_crf_code,
                l_listdesignationbuffer (l_indice).tlb_taxon);
            l_indice := l_listdesignationbuffer.PRIOR (l_indice);
        END LOOP;

        pkg_systdesignation.p_processfindbydesignation (p_syv_startwith, -- Identifiant du niveu le plus bas
                                                        p_crf_id, -- Identifiant du code de référence
                                                        p_flagprecisionmax); -- Flag (Y/N) permttant de savoir si l'élément le plus précis est utilisé
        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_flushfordesignation',
               'p_syv_startwith='
            || p_syv_startwith
            || ' crf_id='
            || p_crf_id
            || ' p_flagprecisionmax='
            || p_flagprecisionmax);
    END;



    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_identifiesystematique (
        p_subspecies         IN     importmassdatadetail.imd_subspecies%TYPE,
        p_species            IN     importmassdatadetail.imd_species%TYPE,
        p_genus              IN     importmassdatadetail.imd_genus%TYPE,
        p_family             IN     importmassdatadetail.imd_family%TYPE,
        p_highertaxon        IN     importmassdatadetail.imd_highertaxon%TYPE,
        p_syv_startwith         OUT systvalue.syv_id%TYPE,
        p_crf_id                OUT codereference.crf_id%TYPE,
        p_flagprecisionmax      OUT CHAR,
        p_returnstatus          OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        l_listdesignationbuffer   t_listdesignationbuffer;
        l_listcrf_1               pkg_systdesignation.t_listcrf_code;
        l_listcrf_2               pkg_systdesignation.t_listcrf_code;
        l_listcrf_3               pkg_systdesignation.t_listcrf_code;
        l_listcrf_4               pkg_systdesignation.t_listcrf_code;
        l_listcrf_5               pkg_systdesignation.t_listcrf_code;
        l_indice1                 PLS_INTEGER;
        l_indice2                 PLS_INTEGER;
        l_indice3                 PLS_INTEGER;
        l_indice4                 PLS_INTEGER;
        l_indice5                 PLS_INTEGER;
        l_text1                   importmassdatadetail.imd_subspecies%TYPE;
        l_text2                   importmassdatadetail.imd_species%TYPE;
        l_text3                   importmassdatadetail.imd_genus%TYPE;
        l_text4                   importmassdatadetail.imd_family%TYPE;
        l_text5                   importmassdatadetail.imd_highertaxon%TYPE;
        l_level                   PLS_INTEGER;
        l_flushlevel              PLS_INTEGER;
        l_syv_startwith           systvalue.syv_id%TYPE;
        l_crf_id                  codereference.crf_id%TYPE;
        l_syv_savestartwith       systvalue.syv_id%TYPE;
        l_crf_idsave              codereference.crf_id%TYPE;
        l_flagprecisionmax        CHAR (1);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_identifiesystematique',
               ' p_subspecies='
            || p_subspecies
            || ' p_species='
            || p_species
            || ' p_genus='
            || p_genus
            || ' p_family='
            || p_family
            || ' p_highertaxon='
            || p_highertaxon);
        l_listcrf_1.delete ();
        l_listcrf_2.delete ();
        l_listcrf_3.delete ();
        l_listcrf_5.delete ();
        l_listcrf_4.delete ();

        IF NOT p_subspecies IS NULL
        THEN
            l_listcrf_1 :=
                pkg_systdesignation.f_getlistcrfbydesignation (
                    p_subspecies,
                    pkg_language.cst_lan_cde_latin);
            p_refinelistcrf_subspe (l_listcrf_1);
        END IF;

        IF NOT p_species IS NULL
        THEN
            l_listcrf_2 :=
                pkg_systdesignation.f_getlistcrfbydesignation (
                    p_species,
                    pkg_language.cst_lan_cde_latin);
            p_refinelistcrf_species (l_listcrf_2);
        END IF;

        IF NOT p_genus IS NULL
        THEN
            l_listcrf_3 :=
                pkg_systdesignation.f_getlistcrfbydesignation (
                    p_genus,
                    pkg_language.cst_lan_cde_latin);
            p_refinelistcrf_genus (l_listcrf_3);
        END IF;

        IF NOT p_family IS NULL
        THEN
            l_listcrf_4 :=
                pkg_systdesignation.f_getlistcrfbydesignation (
                    p_family,
                    pkg_language.cst_lan_cde_latin);
            p_refinelistcrf_family (l_listcrf_4);
        END IF;

        IF NOT p_highertaxon IS NULL
        THEN
            l_listcrf_5 :=
                pkg_systdesignation.f_getlistcrfbydesignation (
                    p_highertaxon,
                    pkg_language.cst_lan_cde_latin);
            p_refinelistcrf_hyghertaxon (l_listcrf_5);
        END IF;

        l_text1 := p_subspecies;
        l_text2 := p_species;
        l_text3 := p_genus;
        l_text4 := p_family;
        l_text5 := p_highertaxon;


        p_sortlistcrf (l_listcrf_1,
                       l_listcrf_2,
                       l_listcrf_3,
                       l_listcrf_4,
                       l_listcrf_5,
                       l_text1,
                       l_text2,
                       l_text3,
                       l_text4,
                       l_text5);

        -- On cherche la meilleure solution avec toute ces valeurs
        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_identifiesystematique',
               ' l_listcrf_5.COUNT='
            || l_listcrf_5.COUNT
            || ' Text'
            || l_text5
            || ' l_listcrf_4.COUNT='
            || l_listcrf_4.COUNT
            || ' Text'
            || l_text4
            || ' l_listcrf_3.COUNT='
            || l_listcrf_3.COUNT
            || ' Text'
            || l_text3
            || ' l_listcrf_2.COUNT='
            || l_listcrf_2.COUNT
            || ' Text'
            || l_text2
            || ' l_listcrf_1.COUNT='
            || l_listcrf_1.COUNT
            || ' Text'
            || l_text1);
        DBMS_OUTPUT.put_line (
               ' l_listcrf_5.COUNT='
            || l_listcrf_5.COUNT
            || ' Text'
            || l_text5
            || ' l_listcrf_4.COUNT='
            || l_listcrf_4.COUNT
            || ' Text'
            || l_text4
            || ' l_listcrf_3.COUNT='
            || l_listcrf_3.COUNT
            || ' Text'
            || l_text3
            || ' l_listcrf_2.COUNT='
            || l_listcrf_2.COUNT
            || ' Text'
            || l_text2
            || ' l_listcrf_1.COUNT='
            || l_listcrf_1.COUNT
            || ' Text'
            || l_text1);


        IF l_listcrf_5.COUNT > 0
        THEN
            l_flushlevel := 5;
        ELSIF l_listcrf_4.COUNT > 0
        THEN
            l_flushlevel := 4;
        ELSIF l_listcrf_3.COUNT > 0
        THEN
            l_flushlevel := 3;
        ELSIF l_listcrf_2.COUNT > 0
        THEN
            l_flushlevel := 2;
        ELSIF l_listcrf_1.COUNT > 0
        THEN
            l_flushlevel := 1;
        ELSE
            l_flushlevel := 0;
        END IF;


        DBMS_OUTPUT.put_line (
               'l_listcrf_1.count='
            || l_listcrf_1.COUNT
            || ' l_listcrf_2.count='
            || l_listcrf_2.COUNT
            || ' l_listcrf_3.count='
            || l_listcrf_3.COUNT
            || ' l_listcrf_4.count='
            || l_listcrf_4.COUNT
            || ' l_listcrf_5.count='
            || l_listcrf_5.COUNT);

        IF l_flushlevel = 0
        THEN
            RETURN;
        END IF;

        l_syv_savestartwith := NULL;
        l_flagprecisionmax := pkg_constante.cst_no;
        l_indice1 := l_listcrf_1.FIRST;

        -- Les élément sont déjà triés avec le plus grand nombre d'élément au plus petit
        WHILE     NOT l_indice1 IS NULL
              AND l_flagprecisionmax != pkg_constante.cst_yes
        LOOP
            l_level :=
                pkg_codereference.f_returnlevelbycode (
                    l_listcrf_1 (l_indice1));
            l_listdesignationbuffer (l_level).tlb_crf_code :=
                l_listcrf_1 (l_indice1);
            l_listdesignationbuffer (l_level).tlb_taxon := l_text1;
            l_indice2 := l_listcrf_2.FIRST;

            WHILE     NOT l_indice2 IS NULL
                  AND l_flagprecisionmax != pkg_constante.cst_yes
            LOOP
                l_level :=
                    pkg_codereference.f_returnlevelbycode (
                        l_listcrf_2 (l_indice2));
                l_listdesignationbuffer (l_level).tlb_crf_code :=
                    l_listcrf_2 (l_indice2);
                l_listdesignationbuffer (l_level).tlb_taxon := l_text2;
                l_indice3 := l_listcrf_3.FIRST;

                WHILE     NOT l_indice3 IS NULL
                      AND l_flagprecisionmax != pkg_constante.cst_yes
                LOOP
                    l_level :=
                        pkg_codereference.f_returnlevelbycode (
                            l_listcrf_3 (l_indice3));
                    l_listdesignationbuffer (l_level).tlb_crf_code :=
                        l_listcrf_3 (l_indice3);
                    l_listdesignationbuffer (l_level).tlb_taxon := l_text3;
                    l_indice4 := l_listcrf_4.FIRST;

                    WHILE     NOT l_indice4 IS NULL
                          AND l_flagprecisionmax != pkg_constante.cst_yes
                    LOOP
                        l_level :=
                            pkg_codereference.f_returnlevelbycode (
                                l_listcrf_4 (l_indice4));
                        l_listdesignationbuffer (l_level).tlb_crf_code :=
                            l_listcrf_4 (l_indice4);
                        l_listdesignationbuffer (l_level).tlb_taxon :=
                            l_text4;
                        l_indice5 := l_listcrf_5.FIRST;

                        WHILE     NOT l_indice5 IS NULL
                              AND l_flagprecisionmax != pkg_constante.cst_yes
                        LOOP
                            l_level :=
                                pkg_codereference.f_returnlevelbycode (
                                    l_listcrf_5 (l_indice5));
                            l_listdesignationbuffer (l_level).tlb_crf_code :=
                                l_listcrf_5 (l_indice5);
                            l_listdesignationbuffer (l_level).tlb_taxon :=
                                l_text5;

                            IF l_flushlevel = 5
                            THEN
                                p_flushfordesignation (
                                    l_listdesignationbuffer,
                                    l_syv_startwith,
                                    l_crf_id,
                                    l_flagprecisionmax);

                                IF NOT l_syv_startwith IS NULL
                                THEN
                                    l_syv_savestartwith := l_syv_startwith;
                                    l_crf_idsave := l_crf_id;
                                END IF;
                            END IF;

                            l_indice5 := l_listcrf_5.NEXT (l_indice5);
                        END LOOP;

                        IF l_flushlevel = 4
                        THEN
                            p_flushfordesignation (l_listdesignationbuffer,
                                                   l_syv_startwith,
                                                   l_crf_id,
                                                   l_flagprecisionmax);

                            IF NOT l_syv_startwith IS NULL
                            THEN
                                l_syv_savestartwith := l_syv_startwith;
                                l_crf_idsave := l_crf_id;
                            END IF;
                        END IF;

                        l_indice4 := l_listcrf_4.NEXT (l_indice4);
                    END LOOP;

                    IF l_flushlevel = 3
                    THEN
                        p_flushfordesignation (l_listdesignationbuffer,
                                               l_syv_startwith,
                                               l_crf_id,
                                               l_flagprecisionmax);

                        IF NOT l_syv_startwith IS NULL
                        THEN
                            l_syv_savestartwith := l_syv_startwith;
                            l_crf_idsave := l_crf_id;
                        END IF;
                    END IF;

                    l_indice3 := l_listcrf_3.NEXT (l_indice3);
                END LOOP;

                IF l_flushlevel = 2
                THEN
                    p_flushfordesignation (l_listdesignationbuffer,
                                           l_syv_startwith,
                                           l_crf_id,
                                           l_flagprecisionmax);

                    IF NOT l_syv_startwith IS NULL
                    THEN
                        l_syv_savestartwith := l_syv_startwith;
                        l_crf_idsave := l_crf_id;
                    END IF;
                END IF;

                l_indice2 := l_listcrf_2.NEXT (l_indice2);
            END LOOP;

            IF l_flushlevel = 1
            THEN
                p_flushfordesignation (l_listdesignationbuffer,
                                       l_syv_startwith,
                                       l_crf_id,
                                       l_flagprecisionmax);

                IF NOT l_syv_startwith IS NULL
                THEN
                    l_syv_savestartwith := l_syv_startwith;
                    l_crf_idsave := l_crf_id;
                END IF;
            END IF;


            l_indice1 := l_listcrf_1.NEXT (l_indice1);
        END LOOP;

        IF l_indice1 = 0
        THEN
            pkg_systdesignation.p_clearfindbydesignation;
        END IF;

        p_syv_startwith := l_syv_savestartwith;
        p_crf_id := l_crf_idsave;
        p_flagprecisionmax := l_flagprecisionmax;
        NULL;
    END;

    /*----------------------------------------------------------------------------------------------*/
    PROCEDURE p_testidentifie
    /*----------------------------------------------------------------------------------------------*/
    IS
        l_subspecies         importmassdatadetail.imd_subspecies%TYPE;
        l_species            importmassdatadetail.imd_species%TYPE;
        l_genus              importmassdatadetail.imd_genus%TYPE;
        l_family             importmassdatadetail.imd_family%TYPE;
        l_highertaxon        importmassdatadetail.imd_highertaxon%TYPE;
        l_lan_id             language.lan_id%TYPE;
        l_syv_startwith      systvalue.syv_id%TYPE;
        l_crf_id             codereference.crf_id%TYPE;
        l_flagprecisionmax   CHAR (1);
        l_returnstatus       NUMBER;
    BEGIN
        l_subspecies := NULL;
        l_species := 'lacustris';
        --   l_genus := 'Eclipidrilus';
        l_family := 'Lumbriculidae';
        l_highertaxon := NULL;
        /*
          l_subspecies := NULL;
              l_species := 'lacustris';
              l_genus := null;
              l_family := null;
              l_highertaxon := NULL;

        */



        p_identifiesystematique (l_subspecies,
                                 l_species,
                                 l_genus,
                                 l_family,
                                 l_highertaxon,
                                 l_syv_startwith,
                                 l_crf_id,
                                 l_flagprecisionmax,
                                 l_returnstatus);
        DBMS_OUTPUT.put_line (
               'L_syv_startwith='
            || l_syv_startwith
            || ' L_crf_id='
            || l_crf_id
            || ' L_flagprecisionmax='
            || l_flagprecisionmax);
    END;

    /*-------------------------------------------------------------------------------*/
    PROCEDURE p_selecttaxavalue (
        p_textwithoutparenthesis   IN     importmassdatadetail.imd_highertaxon%TYPE,
        p_taxa_used                IN     importmassdatadetail.imd_highertaxon%TYPE,
        p_textreturn                  OUT importmassdatadetail.imd_highertaxon%TYPE)
    /*--------------------------------------------------------------------------------*/
    IS
    BEGIN
        IF p_taxa_used IS NULL
        THEN
            p_textreturn := p_textwithoutparenthesis;
        ELSIF p_taxa_used = p_textwithoutparenthesis
        THEN
            -- Si   l_taxa_used =    l_textwithoutparenthesis on doit prende    l_textwithoutparenthesis pour la procedure de recheche
            p_textreturn := p_textwithoutparenthesis;
        ELSIF -- Si l_taxa_used !=     l_textwithoutparenthesis  on doit prendre     l_taxa_used dans la rpcidure de recheche
              p_taxa_used != p_textwithoutparenthesis
        THEN
            p_textreturn := p_taxa_used;
        END IF;

        RETURN;
    END;

    /*-------------------------------------------------------------------------------*/
    FUNCTION f_addfield (p_listfield IN VARCHAR2, p_field IN VARCHAR2)
        RETURN VARCHAR2
    /*-------------------------------------------------------------------------------*/
    IS
        l_listfield   VARCHAR2 (1024);
    BEGIN
        IF p_listfield IS NULL
        THEN
            l_listfield := p_field;
        ELSE
            l_listfield := p_listfield || '/' || p_field;
        END IF;

        RETURN l_listfield;
    END;

    /*-------------------------------------------------------------------------------*/
    FUNCTION f_returnlistlevelinthesaurus (p_level   IN VARCHAR2,
                                           p_taxa    IN VARCHAR2)
        RETURN VARCHAR2
    /*-------------------------------------------------------------------------------*/
    IS
        l_listcrf   pkg_systdesignation.t_listcrf_code;
        l_listtxt   VARCHAR2 (2048);
        l_indice    PLS_INTEGER;
    BEGIN
        l_listtxt := NULL;
        l_listcrf.delete ();


        l_listcrf :=
            pkg_systdesignation.f_getlistcrfbydesignation (
                p_taxa,
                pkg_language.cst_lan_cde_latin);

        IF p_level = pkg_codevalue.cst_midatfldcmt_subspe
        THEN
            p_refinelistcrf_subspe (l_listcrf);
        ELSIF p_level = pkg_codevalue.cst_midatfldcmt_species
        THEN
            p_refinelistcrf_species (l_listcrf);
        ELSIF p_level = pkg_codevalue.cst_midatfldcmt_genus
        THEN
            p_refinelistcrf_genus (l_listcrf);
        ELSIF p_level = pkg_codevalue.cst_midatfldcmt_family
        THEN
            p_refinelistcrf_family (l_listcrf);
        ELSIF p_level = pkg_codevalue.cst_midatfldcmt_higher
        THEN
            p_refinelistcrf_hyghertaxon (l_listcrf);
        END IF;

        l_indice := l_listcrf.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            IF l_listtxt IS NULL
            THEN
                l_listtxt := l_listcrf (l_indice);
            ELSE
                l_listtxt := l_listtxt || ', ' || l_listcrf (l_indice);
            END IF;

            l_indice := l_listcrf.NEXT (l_indice);
        END LOOP;

        RETURN l_listtxt;
    END;

    /*-------------------------------------------------------------------------------------------------------------*/
    FUNCTION f_buildexcludefield (
        p_importmassdatadetail   IN importmassdatadetail%ROWTYPE,
        p_firstvalidfield        IN VARCHAR2)
        RETURN VARCHAR2
    /*--------------------------------------------------------------------------------------------------------------*/
    IS
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_excludefield                 VARCHAR2 (2048);
    BEGIN
        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);
        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.f_buildexcludefield',
               ' p_importmassdatadetail.imd_subspecies='
            || p_importmassdatadetail.imd_subspecies
            || ' p_importmassdatadetail.imd_species='
            || p_importmassdatadetail.imd_species
            || ' p_importmassdatadetail.imd_genus='
            || p_importmassdatadetail.imd_genus
            || ' p_importmassdatadetail.imd_family='
            || p_importmassdatadetail.imd_family
            || ' p_importmassdatadetail.imd_highertaxon='
            || p_importmassdatadetail.imd_highertaxon);

        IF NOT p_importmassdatadetail.imd_subspecies IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_subspe,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                RETURN NULL;
            END IF;

            IF p_firstvalidfield = pkg_codevalue.cst_midatfldcmt_subspe
            THEN
                RETURN l_excludefield;
            END IF;

            IF l_excludefield IS NULL
            THEN
                l_excludefield :=
                       l_recimportmassmappingheader.ime_excelfieldname
                    || '->'
                    || p_importmassdatadetail.imd_subspecies;
            ELSE
                l_excludefield :=
                       l_excludefield
                    || l_recimportmassmappingheader.ime_excelfieldname
                    || '->'
                    || p_importmassdatadetail.imd_subspecies;
            END IF;
        END IF;

        IF NOT p_importmassdatadetail.imd_species IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_species,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                RETURN NULL;
            END IF;

            IF p_firstvalidfield = pkg_codevalue.cst_midatfldcmt_species
            THEN
                RETURN l_excludefield;
            END IF;

            IF l_excludefield IS NULL
            THEN
                l_excludefield :=
                       l_recimportmassmappingheader.ime_excelfieldname
                    || '->'
                    || p_importmassdatadetail.imd_species;
            ELSE
                l_excludefield :=
                       l_excludefield
                    || l_recimportmassmappingheader.ime_excelfieldname
                    || '->'
                    || p_importmassdatadetail.imd_species;
            END IF;
        END IF;

        IF NOT p_importmassdatadetail.imd_genus IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_genus,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                RETURN NULL;
            END IF;

            IF p_firstvalidfield = pkg_codevalue.cst_midatfldcmt_genus
            THEN
                RETURN l_excludefield;
            END IF;

            IF l_excludefield IS NULL
            THEN
                l_excludefield :=
                       l_recimportmassmappingheader.ime_excelfieldname
                    || '->'
                    || p_importmassdatadetail.imd_genus;
            ELSE
                l_excludefield :=
                       l_excludefield
                    || l_recimportmassmappingheader.ime_excelfieldname
                    || '->'
                    || p_importmassdatadetail.imd_genus;
            END IF;
        END IF;

        IF NOT p_importmassdatadetail.imd_family IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_family,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                RETURN NULL;
            END IF;

            IF p_firstvalidfield = pkg_codevalue.cst_midatfldcmt_family
            THEN
                RETURN l_excludefield;
            END IF;

            IF l_excludefield IS NULL
            THEN
                l_excludefield :=
                       l_recimportmassmappingheader.ime_excelfieldname
                    || '->'
                    || p_importmassdatadetail.imd_family;
            ELSE
                l_excludefield :=
                       l_excludefield
                    || l_recimportmassmappingheader.ime_excelfieldname
                    || '->'
                    || p_importmassdatadetail.imd_family;
            END IF;
        END IF;

        IF NOT p_importmassdatadetail.imd_highertaxon IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_higher,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                RETURN NULL;
            END IF;

            IF p_firstvalidfield = pkg_codevalue.cst_midatfldcmt_higher
            THEN
                RETURN l_excludefield;
            END IF;

            IF l_excludefield IS NULL
            THEN
                l_excludefield :=
                       l_recimportmassmappingheader.ime_excelfieldname
                    || '->'
                    || p_importmassdatadetail.imd_highertaxon;
            ELSE
                l_excludefield :=
                       l_excludefield
                    || l_recimportmassmappingheader.ime_excelfieldname
                    || '->'
                    || p_importmassdatadetail.imd_highertaxon;
            END IF;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.f_buildexcludefield',
               'p_firstvalidfield='
            || p_firstvalidfield
            || 'l_excludefield='
            || l_excludefield);
        RETURN l_excludefield;
    END;



    /*---------------------------------------------------------------------------*/
    PROCEDURE p_findonsynonym (
        p_syv_id           IN     systvalue.syv_id%TYPE,
        p_taxon                   systdesignation.syd_designation%TYPE,
        p_syv_id_synomym      OUT systvalue.syv_id%TYPE)
    /*--------------------------------------------------------------------------*/
    IS
        CURSOR l_cursor IS
            SELECT *
              FROM systvalue
                   INNER JOIN systdesignation ON syv_id = syd_syv_id
                   INNER JOIN language ON lan_id = syd_lan_id
             WHERE     syv_syv_id_synonymfor = p_syv_id
                   AND lan_code = pkg_language.cst_lan_cde_latin;

        l_reccursor   l_cursor%ROWTYPE;
    BEGIN
        p_syv_id_synomym := NULL;

        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND OR NOT p_syv_id_synomym IS NULL;

            IF pkg_stringutil.f_normalisestring (l_reccursor.syd_designation) =
               pkg_stringutil.f_normalisestring (p_taxon)
            THEN
                p_syv_id_synomym := l_reccursor.syv_id;
            END IF;
        END LOOP;

        CLOSE l_cursor;
    END;

    /*-------------------------------------------------------------------------*/
    PROCEDURE p_comparesubspecies (
        p_syv_id         IN     systvalue.syv_id%TYPE,
        p_subspecies     IN     importmassdatadetail.imd_subspecies%TYPE,
        p_syv_id_found      OUT systvalue.syv_id%TYPE)
    /*-------------------------------------------------------------------------*/
    IS
        l_recsystvalue         systvalue%ROWTYPE;
        l_reccodereference     codereference%ROWTYPE;
        l_recsystdesignation   systdesignation%ROWTYPE;
        l_syv_id_synomym       systvalue.syv_id%TYPE;
    BEGIN
        IF p_subspecies IS NULL
        THEN
            p_syv_id_found := NULL;
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_comparesubspecies',
               'p_subspecies='
            || p_subspecies
            || ' PATH='
            || pkg_systdesignation.f_returnpathdesignation (p_syv_id,
                                                            10,
                                                            '/'));


        l_recsystvalue := pkg_systvalue.f_getrecord (p_syv_id);
        l_reccodereference :=
            pkg_codereference.f_getrecord (l_recsystvalue.syv_crf_id);

        IF     l_reccodereference.crf_code !=
               pkg_codereference.cst_crf_subspecies
           AND l_reccodereference.crf_code != pkg_codereference.cst_crf_form
        THEN
            p_syv_id_found := NULL;
            RETURN;
        END IF;

        l_recsystdesignation :=
            pkg_systdesignation.f_getrecdesignationbylancode (
                l_recsystvalue.syv_id,
                pkg_language.cst_lan_cde_latin);

        IF pkg_stringutil.f_normalisestring (
               l_recsystdesignation.syd_designation) =
           pkg_stringutil.f_normalisestring (p_subspecies)
        THEN
            p_syv_id_found := l_recsystvalue.syv_id;
        ELSE
            p_findonsynonym (l_recsystvalue.syv_id,
                             p_subspecies,
                             l_syv_id_synomym);

            IF NOT l_syv_id_synomym IS NULL
            THEN
                p_syv_id_found := l_syv_id_synomym;
            ELSE
                p_syv_id_found := NULL;
            END IF;
        END IF;
    END;

    /*-------------------------------------------------------------------------*/
    PROCEDURE p_comparespecies (
        p_syv_id         IN     systvalue.syv_id%TYPE,
        p_species        IN     importmassdatadetail.imd_species%TYPE,
        p_syv_id_found      OUT systvalue.syv_id%TYPE)
    /*-------------------------------------------------------------------------*/
    IS
        l_recsystvalue         systvalue%ROWTYPE;
        l_reccodereference     codereference%ROWTYPE;
        l_recsystdesignation   systdesignation%ROWTYPE;
        l_syv_id_synomym       systvalue.syv_id%TYPE;
    BEGIN
        IF p_species IS NULL
        THEN
            p_syv_id_found := NULL;
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_comparespecies',
               'p_species='
            || p_species
            || ' PATH='
            || pkg_systdesignation.f_returnpathdesignation (p_syv_id,
                                                            10,
                                                            '/'));

        l_recsystvalue := pkg_systvalue.f_getrecord (p_syv_id);
        l_reccodereference :=
            pkg_codereference.f_getrecord (l_recsystvalue.syv_crf_id);

        IF l_reccodereference.crf_code != pkg_codereference.cst_crf_species
        THEN
            p_syv_id_found := NULL;
            RETURN;
        END IF;

        l_recsystdesignation :=
            pkg_systdesignation.f_getrecdesignationbylancode (
                l_recsystvalue.syv_id,
                pkg_language.cst_lan_cde_latin);

        IF pkg_stringutil.f_normalisestring (
               l_recsystdesignation.syd_designation) =
           pkg_stringutil.f_normalisestring (p_species)
        THEN
            p_syv_id_found := l_recsystvalue.syv_id;
        ELSE
            p_findonsynonym (l_recsystvalue.syv_id,
                             p_species,
                             l_syv_id_synomym);

            IF NOT l_syv_id_synomym IS NULL
            THEN
                p_syv_id_found := l_syv_id_synomym;
            ELSE
                p_syv_id_found := NULL;
            END IF;
        END IF;
    END;

    /*-------------------------------------------------------------------------*/
    PROCEDURE p_comparegenus (
        p_syv_id         IN     systvalue.syv_id%TYPE,
        p_genus          IN     importmassdatadetail.imd_genus%TYPE,
        p_syv_id_found      OUT systvalue.syv_id%TYPE)
    /*-------------------------------------------------------------------------*/
    IS
        l_recsystvalue         systvalue%ROWTYPE;
        l_reccodereference     codereference%ROWTYPE;
        l_recsystdesignation   systdesignation%ROWTYPE;
        l_syv_id_synomym       systvalue.syv_id%TYPE;
    BEGIN
        IF p_genus IS NULL
        THEN
            p_syv_id_found := NULL;
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_comparegenus',
               'p_genus='
            || p_genus
            || ' PATH='
            || pkg_systdesignation.f_returnpathdesignation (p_syv_id,
                                                            10,
                                                            '/'));

        l_recsystvalue := pkg_systvalue.f_getrecord (p_syv_id);
        l_reccodereference :=
            pkg_codereference.f_getrecord (l_recsystvalue.syv_crf_id);

        IF     l_reccodereference.crf_code != pkg_codereference.cst_crf_genus
           AND l_reccodereference.crf_code !=
               pkg_codereference.cst_crf_subgenus
        THEN
            p_syv_id_found := NULL;
            RETURN;
        END IF;

        l_recsystdesignation :=
            pkg_systdesignation.f_getrecdesignationbylancode (
                l_recsystvalue.syv_id,
                pkg_language.cst_lan_cde_latin);

        IF pkg_stringutil.f_normalisestring (
               l_recsystdesignation.syd_designation) =
           pkg_stringutil.f_normalisestring (p_genus)
        THEN
            p_syv_id_found := l_recsystvalue.syv_id;
        ELSE
            p_findonsynonym (l_recsystvalue.syv_id,
                             p_genus,
                             l_syv_id_synomym);

            IF NOT l_syv_id_synomym IS NULL
            THEN
                p_syv_id_found := l_syv_id_synomym;
            ELSE
                p_syv_id_found := NULL;
            END IF;
        END IF;
    END;

    /*-------------------------------------------------------------------------*/
    PROCEDURE p_comparefamily (
        p_syv_id         IN     systvalue.syv_id%TYPE,
        p_family         IN     importmassdatadetail.imd_genus%TYPE,
        p_syv_id_found      OUT systvalue.syv_id%TYPE)
    /*-------------------------------------------------------------------------*/
    IS
        l_recsystvalue         systvalue%ROWTYPE;
        l_reccodereference     codereference%ROWTYPE;
        l_recsystdesignation   systdesignation%ROWTYPE;
        l_syv_id_synomym       systvalue.syv_id%TYPE;
    BEGIN
        IF p_family IS NULL
        THEN
            p_syv_id_found := NULL;
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_comparefamily',
               'p_family='
            || p_family
            || ' PATH='
            || pkg_systdesignation.f_returnpathdesignation (p_syv_id,
                                                            10,
                                                            '/'));

        l_recsystvalue := pkg_systvalue.f_getrecord (p_syv_id);
        l_reccodereference :=
            pkg_codereference.f_getrecord (l_recsystvalue.syv_crf_id);

        IF l_reccodereference.crf_code != pkg_codereference.cst_crf_family
        THEN
            p_syv_id_found := NULL;
            RETURN;
        END IF;

        l_recsystdesignation :=
            pkg_systdesignation.f_getrecdesignationbylancode (
                l_recsystvalue.syv_id,
                pkg_language.cst_lan_cde_latin);

        IF pkg_stringutil.f_normalisestring (
               l_recsystdesignation.syd_designation) =
           pkg_stringutil.f_normalisestring (p_family)
        THEN
            p_syv_id_found := l_recsystvalue.syv_id;
        ELSE
            p_findonsynonym (l_recsystvalue.syv_id,
                             p_family,
                             l_syv_id_synomym);

            IF NOT l_syv_id_synomym IS NULL
            THEN
                p_syv_id_found := l_syv_id_synomym;
            ELSE
                p_syv_id_found := NULL;
            END IF;
        END IF;
    END;

    /*-------------------------------------------------------------------------*/
    PROCEDURE p_comparehighertaxon (
        p_syv_id         IN     systvalue.syv_id%TYPE,
        p_highertaxon    IN     importmassdatadetail.imd_highertaxon%TYPE,
        p_syv_id_found      OUT systvalue.syv_id%TYPE)
    /*-------------------------------------------------------------------------*/
    IS
        l_recsystvalue         systvalue%ROWTYPE;
        l_reccodereference     codereference%ROWTYPE;
        l_recsystdesignation   systdesignation%ROWTYPE;
        l_syv_id_synomym       systvalue.syv_id%TYPE;
        l_exit                 BOOLEAN := FALSE;
    BEGIN
        IF p_highertaxon IS NULL
        THEN
            p_syv_id_found := NULL;
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_comparehighertaxon',
               'p_highertaxon='
            || p_highertaxon
            || ' PATH='
            || pkg_systdesignation.f_returnpathdesignation (p_syv_id,
                                                            10,
                                                            '/'));

        l_recsystvalue := pkg_systvalue.f_getrecord (p_syv_id);
        l_reccodereference :=
            pkg_codereference.f_getrecord (l_recsystvalue.syv_crf_id);

        IF l_reccodereference.crf_code NOT IN
               (pkg_codereference.cst_crf_superfamil,
                pkg_codereference.cst_crf_infraclass,
                pkg_codereference.cst_crf_subclass,
                pkg_codereference.cst_crf_class,
                pkg_codereference.cst_crf_infraorder,
                pkg_codereference.cst_crf_suborder,
                pkg_codereference.cst_crf_order,
                pkg_codereference.cst_crf_superorder,
                pkg_codereference.cst_crf_infraphylu,
                pkg_codereference.cst_crf_subphylum,
                pkg_codereference.cst_crf_phylum,
                pkg_codereference.cst_crf_kingdom)
        THEN
            p_syv_id_found := NULL;
            RETURN;
        END IF;

        WHILE     l_reccodereference.crf_code IN
                      (pkg_codereference.cst_crf_superfamil,
                       pkg_codereference.cst_crf_infraclass,
                       pkg_codereference.cst_crf_subclass,
                       pkg_codereference.cst_crf_class,
                       pkg_codereference.cst_crf_infraorder,
                       pkg_codereference.cst_crf_suborder,
                       pkg_codereference.cst_crf_order,
                       pkg_codereference.cst_crf_superorder,
                       pkg_codereference.cst_crf_infraphylu,
                       pkg_codereference.cst_crf_subphylum,
                       pkg_codereference.cst_crf_phylum,
                       pkg_codereference.cst_crf_kingdom)
              AND p_syv_id_found IS NULL
              AND NOT l_exit
        LOOP
            l_recsystdesignation :=
                pkg_systdesignation.f_getrecdesignationbylancode (
                    l_recsystvalue.syv_id,
                    pkg_language.cst_lan_cde_latin);
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_comparehighertaxon',
                   'l_recsystdesignation.syd_designation='
                || l_recsystdesignation.syd_designation);

            IF pkg_stringutil.f_normalisestring (
                   l_recsystdesignation.syd_designation) =
               pkg_stringutil.f_normalisestring (p_highertaxon)
            THEN
                p_syv_id_found := l_recsystvalue.syv_id;
            ELSE
                p_findonsynonym (l_recsystvalue.syv_id,
                                 p_highertaxon,
                                 l_syv_id_synomym);

                IF NOT l_syv_id_synomym IS NULL
                THEN
                    p_syv_id_found := l_syv_id_synomym;
                ELSE
                    p_syv_id_found := NULL;
                END IF;
            END IF;

            IF NOT l_recsystvalue.syv_syv_id IS NULL
            THEN
                l_recsystvalue :=
                    pkg_systvalue.f_getrecord (l_recsystvalue.syv_syv_id);
                l_reccodereference :=
                    pkg_codereference.f_getrecord (l_recsystvalue.syv_crf_id);
            ELSE
                l_exit := TRUE;
            END IF;
        END LOOP;
    END;

    /*---------------------------------------------------------------------------*/
    FUNCTION f_returnsyvatlevel (p_syv_id     IN systvalue.syv_id%TYPE,
                                 p_crf_code   IN codereference.crf_code%TYPE)
        RETURN systvalue.syv_id%TYPE
    /*---------------------------------------------------------------------------*/
    IS
        l_recsystvalue       systvalue%ROWTYPE;
        l_reccodereference   codereference%ROWTYPE;
    BEGIN
        l_recsystvalue := pkg_systvalue.f_getrecord (p_syv_id);
        l_reccodereference :=
            pkg_codereference.f_getrecord (l_recsystvalue.syv_crf_id);

        WHILE     l_reccodereference.crf_code != p_crf_code
              AND NOT l_recsystvalue.syv_syv_id IS NULL
        LOOP
            l_recsystvalue :=
                pkg_systvalue.f_getrecord (l_recsystvalue.syv_syv_id);
            l_reccodereference :=
                pkg_codereference.f_getrecord (l_recsystvalue.syv_crf_id);
        END LOOP;

        IF l_reccodereference.crf_code = p_crf_code
        THEN
            RETURN l_recsystvalue.syv_id;
        ELSE
            RETURN NULL;
        END IF;
    END;

    /*---------------------------------------------------------------------------*/
    PROCEDURE p_findsubspeciesatlevel (
        p_syv_id_startwith    IN     systvalue.syv_id%TYPE,
        p_subspecies          IN     importmassdatadetail.imd_subspecies%TYPE,
        p_syv_id_subspecies      OUT systvalue.syv_id%TYPE)
    /*---------------------------------------------------------------------------*/
    IS
        l_syv_id   systvalue.syv_id%TYPE;
    BEGIN
        l_syv_id :=
            f_returnsyvatlevel (p_syv_id_startwith,
                                pkg_codereference.cst_crf_form);

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_subspecies);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_aggsubspec);
        END IF;

        IF NOT l_syv_id IS NULL
        THEN
            p_comparesubspecies (l_syv_id, p_subspecies, p_syv_id_subspecies);
        END IF;

        NULL;
    END;

    /*---------------------------------------------------------------------------*/
    PROCEDURE p_findspeciesatlevel (
        p_syv_id_startwith   IN     systvalue.syv_id%TYPE,
        p_species            IN     importmassdatadetail.imd_species%TYPE,
        p_syv_id_species        OUT systvalue.syv_id%TYPE)
    /*---------------------------------------------------------------------------*/
    IS
        l_syv_id   systvalue.syv_id%TYPE;
    BEGIN
        l_syv_id :=
            f_returnsyvatlevel (p_syv_id_startwith,
                                pkg_codereference.cst_crf_species);

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (l_syv_id,
                                    pkg_codereference.cst_crf_aggspecies);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (l_syv_id,
                                    pkg_codereference.cst_crf_hybrid);
        END IF;

        IF NOT l_syv_id IS NULL
        THEN
            p_comparespecies (l_syv_id, p_species, p_syv_id_species);
        END IF;

        NULL;
    END;

    /*---------------------------------------------------------------------------*/
    PROCEDURE p_findgenussatlevel (
        p_syv_id_startwith   IN     systvalue.syv_id%TYPE,
        p_genus              IN     importmassdatadetail.imd_genus%TYPE,
        p_syv_id_genus          OUT systvalue.syv_id%TYPE)
    /*---------------------------------------------------------------------------*/
    IS
        l_syv_id   systvalue.syv_id%TYPE;
    BEGIN
        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_findgenussatlevel',
               'p_genus='
            || p_genus
            || ' p_syv_id_genus='
            || p_syv_id_genus
            || ' '
            || pkg_systdesignation.f_returnpathdesignation (
                   p_syv_id_startwith,
                   10,
                   '/'));
        l_syv_id :=
            f_returnsyvatlevel (p_syv_id_startwith,
                                pkg_codereference.cst_crf_subgenus);

        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_findgenussatlevel',
            'p_genus=' || p_genus || ' SUBGENUS l_syv_id=' || l_syv_id);

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_genus);
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_findgenussatlevel',
            'p_genus=' || p_genus || ' GENUS l_syv_id=' || l_syv_id);

        IF NOT l_syv_id IS NULL
        THEN
            p_comparegenus (l_syv_id, p_genus, p_syv_id_genus);
        END IF;

        NULL;
    END;

    /*---------------------------------------------------------------------------*/
    PROCEDURE p_findfamilysatlevel (
        p_syv_id_startwith   IN     systvalue.syv_id%TYPE,
        p_family             IN     importmassdatadetail.imd_genus%TYPE,
        p_syv_id_family         OUT systvalue.syv_id%TYPE)
    /*---------------------------------------------------------------------------*/
    IS
        l_syv_id   systvalue.syv_id%TYPE;
    BEGIN
        l_syv_id :=
            f_returnsyvatlevel (p_syv_id_startwith,
                                pkg_codereference.cst_crf_tribe);

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_subfamily);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_family);
        END IF;


        IF NOT l_syv_id IS NULL
        THEN
            p_comparefamily (l_syv_id, p_family, p_syv_id_family);
        END IF;

        NULL;
    END;

    /*---------------------------------------------------------------------------*/
    PROCEDURE p_findhighertaxonatlevel (
        p_syv_id_startwith     IN     systvalue.syv_id%TYPE,
        p_highertaxon          IN     importmassdatadetail.imd_subspecies%TYPE,
        p_syv_id_highertaxon      OUT systvalue.syv_id%TYPE)
    /*---------------------------------------------------------------------------*/
    IS
        l_syv_id   systvalue.syv_id%TYPE;
    BEGIN
        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_findhighertaxonatlevel',
               'p_highertaxon='
            || p_highertaxon
            || ' PATH='
            || pkg_systdesignation.f_returnpathdesignation (
                   p_syv_id_startwith,
                   10,
                   '/'));

        l_syv_id :=
            f_returnsyvatlevel (p_syv_id_startwith,
                                pkg_codereference.cst_crf_superfamil);

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_infraorder);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_suborder);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_order);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_superorder);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_infraclass);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_subclass);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_class);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_infraphylu);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_subphylum);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_phylum);
        END IF;

        IF l_syv_id IS NULL
        THEN
            l_syv_id :=
                f_returnsyvatlevel (p_syv_id_startwith,
                                    pkg_codereference.cst_crf_kingdom);
        END IF;



        IF NOT l_syv_id IS NULL
        THEN
            p_comparehighertaxon (l_syv_id,
                                  p_highertaxon,
                                  p_syv_id_highertaxon);
        END IF;

        NULL;
    END;



    /*----------------------------------------------------------------------------*/
    PROCEDURE p_comparesystematique (
        p_syv_id_startwith     IN     systvalue.syv_id%TYPE,
        p_subspecies           IN     importmassdatadetail.imd_subspecies%TYPE,
        p_species              IN     importmassdatadetail.imd_species%TYPE,
        p_genus                IN     importmassdatadetail.imd_genus%TYPE,
        p_family               IN     importmassdatadetail.imd_family%TYPE,
        p_highertaxon          IN     importmassdatadetail.imd_highertaxon%TYPE,
        p_syv_id_subspecies       OUT systvalue.syv_id%TYPE,
        p_syv_id_species          OUT systvalue.syv_id%TYPE,
        p_syv_id_genus            OUT systvalue.syv_id%TYPE,
        p_syv_id_family           OUT systvalue.syv_id%TYPE,
        p_syv_id_highertaxon      OUT systvalue.syv_id%TYPE)
    /*------------------------------------------------------------------------------*/
    IS
        l_path                 VARCHAR2 (2048);
        l_recsystvalue         systvalue%ROWTYPE;
        l_reccodereference     codereference%ROWTYPE;
        l_recsystdesignation   systdesignation%ROWTYPE;
        l_syv_id_synomym       systvalue.syv_id%TYPE;
        l_syv_id               systvalue.syv_id%TYPE;
    BEGIN
        l_syv_id := p_syv_id_startwith;

        IF NOT p_subspecies IS NULL
        THEN
            p_findsubspeciesatlevel (p_syv_id_startwith,
                                     p_subspecies,
                                     p_syv_id_subspecies);
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_comparesystematique',
                   'p_subspecies='
                || p_subspecies
                || ' p_syv_id_subspecies='
                || p_syv_id_subspecies);
        END IF;

        IF NOT p_species IS NULL
        THEN
            p_findspeciesatlevel (p_syv_id_startwith,
                                  p_species,
                                  p_syv_id_species);
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_comparesystematique',
                   'p_species='
                || p_species
                || ' p_syv_id_species='
                || p_syv_id_species);
        END IF;

        IF NOT p_genus IS NULL
        THEN
            p_findgenussatlevel (p_syv_id_startwith, p_genus, p_syv_id_genus);
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_comparesystematique',
                'p_genus=' || p_genus || ' p_syv_id_genus=' || p_syv_id_genus);
        END IF;

        IF NOT p_family IS NULL
        THEN
            p_findfamilysatlevel (p_syv_id_startwith,
                                  p_family,
                                  p_syv_id_family);
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_comparesystematique',
                   'p_family='
                || p_family
                || ' p_syv_id_family='
                || p_syv_id_family);
        END IF;

        IF NOT p_highertaxon IS NULL
        THEN
            p_findhighertaxonatlevel (p_syv_id_startwith,
                                      p_highertaxon,
                                      p_syv_id_highertaxon);
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_comparesystematique',
                   'p_highertaxon='
                || p_highertaxon
                || ' p_syv_id_highertaxon='
                || p_syv_id_highertaxon);
        END IF;
    END;

    /*------------------------------------------------------------------------------*/
    FUNCTION f_findonhierarchysyn (p_syv_id_ref     IN systvalue.syv_id%TYPE,
                                   p_syv_id_check   IN systvalue.syv_id%TYPE)
        RETURN BOOLEAN
    /*-------------------------------------------------------------------------------*/
    IS
        CURSOR l_cursor IS
            SELECT *
              FROM systvalue
             WHERE syv_syv_id_synonymfor = p_syv_id_ref;

        l_reccursor   l_cursor%ROWTYPE;
        l_found       BOOLEAN := FALSE;
    BEGIN
        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND OR l_found;

            IF l_reccursor.syv_id = p_syv_id_check
            THEN
                l_found := TRUE;
            END IF;
        END LOOP;

        CLOSE l_cursor;

        RETURN l_found;
    END;


    /*------------------------------------------------------------------------------*/
    FUNCTION f_findonhierarchy (p_syv_id_base    IN systvalue.syv_id%TYPE,
                                p_syv_id_check   IN systvalue.syv_id%TYPE)
        RETURN BOOLEAN
    /*-------------------------------------------------------------------------------*/
    IS
        l_recsystvalue   systvalue%ROWTYPE;
        l_found          BOOLEAN := FALSE;
    BEGIN
        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.f_findonhierarchy',
               'CHECK TAXON:'
            || pkg_systdesignation.f_returnpathdesignation (p_syv_id_check,
                                                            10,
                                                            '/'));
        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.f_findonhierarchy',
               'p_syv_id_base='
            || p_syv_id_base
            || 'p_syv_id_check='
            || p_syv_id_check);

        IF p_syv_id_base = p_syv_id_check
        THEN
            l_found := TRUE;
            RETURN l_found;
        END IF;

        l_recsystvalue := pkg_systvalue.f_getrecord (p_syv_id_base);

        WHILE NOT l_found AND NOT l_recsystvalue.syv_syv_id IS NULL
        LOOP
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.f_findonhierarchy',
                   'CHECK compare:'
                || pkg_systdesignation.f_returnpathdesignation (
                       l_recsystvalue.syv_id,
                       10,
                       '/'));
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.f_findonhierarchy',
                'l_recsystvalue.syv_id=' || l_recsystvalue.syv_id);

            IF p_syv_id_check = l_recsystvalue.syv_id
            THEN
                l_found := TRUE;
            ELSE
                l_found :=
                    f_findonhierarchysyn (l_recsystvalue.syv_id,
                                          p_syv_id_check);

                IF NOT l_found
                THEN
                    l_recsystvalue :=
                        pkg_systvalue.f_getrecord (l_recsystvalue.syv_syv_id);
                END IF;
            END IF;
        END LOOP;

        RETURN l_found;
    END;

    /*------------------------------------------------------------------------------*/
    FUNCTION f_returnfilledtaxon (
        p_subspecies    IN importmassdatadetail.imd_subspecies%TYPE,
        p_species       IN importmassdatadetail.imd_species%TYPE,
        p_genus         IN importmassdatadetail.imd_genus%TYPE,
        p_family        IN importmassdatadetail.imd_family%TYPE,
        p_highertaxon   IN importmassdatadetail.imd_highertaxon%TYPE)
        RETURN VARCHAR2
    /*-----------------------------------------------------------------------------*/
    IS
        l_text   VARCHAR2 (1024);
    BEGIN
        IF NOT p_highertaxon IS NULL
        THEN
            IF l_text IS NULL
            THEN
                l_text := 'HIGHERTAXON ->' || p_highertaxon;
            ELSE
                l_text :=
                    l_text || ' / ' || 'HIGHERTAXON ->' || p_highertaxon;
            END IF;
        END IF;

        IF NOT p_family IS NULL
        THEN
            IF l_text IS NULL
            THEN
                l_text := 'FAMILY ->' || p_family;
            ELSE
                l_text := l_text || ' / ' || 'FAMILY ->' || p_family;
            END IF;
        END IF;

        IF NOT p_genus IS NULL
        THEN
            IF l_text IS NULL
            THEN
                l_text := 'GENUS ->' || p_genus;
            ELSE
                l_text := l_text || ' / ' || 'GENUS ->' || p_genus;
            END IF;
        END IF;

        IF NOT p_species IS NULL
        THEN
            IF l_text IS NULL
            THEN
                l_text := 'SPECIES ->' || p_species;
            ELSE
                l_text := l_text || ' / ' || 'SPECIES ->' || p_species;
            END IF;
        END IF;

        IF NOT p_subspecies IS NULL
        THEN
            IF l_text IS NULL
            THEN
                l_text := 'SUBSPECIES ->' || p_subspecies;
            ELSE
                l_text := l_text || ' / ' || 'SUBSPECIES ->' || p_subspecies;
            END IF;
        END IF;

        RETURN l_text;
    END;



    /*------------------------------------------------------------------------------*/
    PROCEDURE p_checktaxonibch (
        p_syv_id_startwith       IN     systvalue.syv_id%TYPE,
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_subspecies             IN     importmassdatadetail.imd_subspecies%TYPE,
        p_species                IN     importmassdatadetail.imd_species%TYPE,
        p_genus                  IN     importmassdatadetail.imd_genus%TYPE,
        p_family                 IN     importmassdatadetail.imd_family%TYPE,
        p_highertaxon            IN     importmassdatadetail.imd_highertaxon%TYPE,
        p_returnstatus              OUT NUMBER)
    /*-------------------------------------------------------------------------------*/
    /* 1. Le taxon IBCH est obligatoire
          exc_valtaxonibchrequired Une valeur doit être définie dans la colonne TAXONIBCH
       2. La valeur doit être existante dans la table protocolmappinglabo (version PTV_ID)
           exc_valtaxonibchnotfound La valeur %p1% définie dans la colonne TAXONIBCH n'existe pas dans le référentiel systématique du protocole de la laboratoire (version: %p2%) : Ligne Excel %p3%
       3. La valeur doit être dans la hiérarchie du taxon défini par les colonnes HIGHERTAXON, FAMILY, GENUS, SPECIES, SUBSPECIES
          exc_valtaxonibchnotinhierarchy La valeur %p1% définie dans la colonne TAXONIBCH (Taxonomie: %p2%) ne correspond pas avec la hiérarchie taxonomique (%p3%) définie par les colonnes %p4% : Ligne Excel %p5%
   */
    IS
        l_recprotocolmappinglabo    protocolmappinglabo%ROWTYPE;
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_recprotocolversion        protocolversion%ROWTYPE;
        l_recprotocolversionlabo    protocolversion%ROWTYPE;
        l_found                     BOOLEAN;
        l_reclanguagelatin          language%ROWTYPE;
        l_pathcscf                  VARCHAR2 (4096);
        l_pathibch                  VARCHAR2 (4096);
        l_taxonfilled               VARCHAR2 (1024);
        l_syv_id_found              protocolmappinglabo.ptl_syv_id%TYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_taxonfilled :=
            f_returnfilledtaxon (p_subspecies,
                                 p_species,
                                 p_genus,
                                 p_family,
                                 p_highertaxon);
        l_reclanguagelatin :=
            pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);


        IF p_importmassdatadetail.imd_taxonibch IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                pkg_exception.cst_valtaxonibchrequired,
                'IMD_TAXONIBCH',
                TO_CHAR (p_importmassdatadetail.imd_sourceline));
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (
                p_importmassdatadetail.imd_iph_id);
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                l_recimportprotocolheader.iph_ptv_id);
        l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecordbytaxa (
                NVL (l_recprotocolversion.ptv_ptv_id_labofrommass,
                     l_recprotocolversion.ptv_id),
                p_importmassdatadetail.imd_taxonibch);
        l_recprotocolversionlabo :=
            pkg_protocolversion.f_getrecord (
                l_recprotocolversion.ptv_ptv_id_labofrommass);

        IF l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                pkg_exception.cst_valtaxonibchnotfound,
                'IMD_TAXONIBCH',
                p_importmassdatadetail.imd_taxonibch,
                l_recprotocolversionlabo.ptv_text,
                TO_CHAR (p_importmassdatadetail.imd_sourceline));
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_checktaxonibch',
               'p_highertaxon='
            || p_highertaxon
            || ' p_syv_id_startwith='
            || p_syv_id_startwith
            || ' l_recprotocolmappinglabo.ptl_id='
            || l_recprotocolmappinglabo.ptl_id);

        -- La valeur l_recprotocolmappinglabo.ptl_syv_id doit être dans la hiérarchie de p_syv_id_startwith
        l_syv_id_found := NULL;
        l_found :=
            f_findonhierarchy (p_syv_id_startwith,
                               l_recprotocolmappinglabo.ptl_syv_id);

        IF NOT l_found
        THEN
            l_found :=
                f_findonhierarchy (l_recprotocolmappinglabo.ptl_syv_id,
                                   p_syv_id_startwith);
        END IF;

        IF l_found
        THEN
            l_syv_id_found := l_recprotocolmappinglabo.ptl_syv_id;
        END IF;

        IF NOT l_found AND NOT l_recprotocolmappinglabo.ptl_syv_id2 IS NULL
        THEN
            -- La valeur l_recprotocolmappinglabo.ptl_syv_id2 doit être dans la hiérarchie de p_syv_id_startwith
            l_found :=
                f_findonhierarchy (p_syv_id_startwith,
                                   l_recprotocolmappinglabo.ptl_syv_id2);

            IF NOT l_found
            THEN
                l_found :=
                    f_findonhierarchy (l_recprotocolmappinglabo.ptl_syv_id2,
                                       p_syv_id_startwith);
            ELSE
                l_syv_id_found := l_recprotocolmappinglabo.ptl_syv_id2;
            END IF;
        END IF;

        IF l_found AND l_syv_id_found IS NULL
        THEN
            l_syv_id_found := l_recprotocolmappinglabo.ptl_syv_id;
        END IF;

        -- La valeur %p1% définie dans la colonne TAXONIBCH (Taxonomie: %p2%) fait partie de la hiérarchie taxonomique (%p3%) définie par les colonnes %p4% : Ligne Excel %p5%
        l_pathcscf :=
            pkg_systdesignation.f_returnpathdesignation (
                p_syv_id_startwith,
                l_reclanguagelatin.lan_id,
                '/');
        l_pathibch :=
            pkg_systdesignation.f_returnpathdesignation (
                l_syv_id_found,
                l_reclanguagelatin.lan_id,
                '/');

        IF NOT l_found
        THEN
            -- La valeur %p1% définie dans la colonne TAXONIBCH (Taxonomie: %p2%) ne correspond pas avec la hiérarchie taxonomique (%p3%) définie par les colonnes %p4% : Ligne Excel %p5%
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                pkg_exception.cst_valtaxonibchnotinhierarchy,
                'IMD_TAXONIBCH',
                p_importmassdatadetail.imd_taxonibch,
                l_pathibch,
                l_pathcscf,
                l_taxonfilled,
                TO_CHAR (p_importmassdatadetail.imd_sourceline));
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        ELSE
            IF NOT l_recprotocolmappinglabo.ptl_syv_id2 IS NULL
            THEN
                -- Ce message st affiché uniquement s'il y a deux chemins possibles
                pkg_importprotocollog.p_writelog (
                    p_importmassdatadetail.imd_iph_id,
                    p_importmassdatadetail.imd_imh_id,
                    pkg_exception.cst_valtaxonibchinhierarchy,
                    'IMD_TAXONIBCH',
                    p_importmassdatadetail.imd_taxonibch,
                    l_pathibch,
                    l_pathcscf,
                    l_taxonfilled,
                    TO_CHAR (p_importmassdatadetail.imd_sourceline));
            END IF;
        END IF;

        pkg_importmassdatadetail.p_setptl_id (
            p_importmassdatadetail.imd_id,
            l_recprotocolmappinglabo.ptl_id);



        NULL;
    END;



    /*------------------------------------------------------------------------------*/
    PROCEDURE p_checksystematique (
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_lan_id                 IN     language.lan_id%TYPE,
        p_returnstatus              OUT NUMBER)
    /*-------------------------------------------------------------------------------*/
    IS
        cst_reponsenoset      CONSTANT CHAR (1) := 'X';
        l_datetxt                      VARCHAR2 (256);
        l_swisscoord                   VARCHAR2 (256);
        l_excelfield_subspe            VARCHAR2 (256);
        l_excelfield_species           VARCHAR2 (256);
        l_excelfield_genus             VARCHAR2 (256);
        l_excelfield_family            VARCHAR2 (256);
        l_excelfield_highertaxon       VARCHAR2 (256);
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_subspecies                   importmassdatadetail.imd_subspecies%TYPE;
        l_species                      importmassdatadetail.imd_species%TYPE;
        l_genus                        importmassdatadetail.imd_genus%TYPE;
        l_family                       importmassdatadetail.imd_family%TYPE;
        l_highertaxon                  importmassdatadetail.imd_highertaxon%TYPE;
        l_textwithoutparenthesis       VARCHAR2 (1024);
        l_returnstatus                 NUMBER;
        l_countexclude                 NUMBER;
        l_crf_code                     codereference.crf_code%TYPE;
        l_syv_id_subspecies            systvalue.syv_id%TYPE := NULL;
        l_syv_id_species               systvalue.syv_id%TYPE := NULL;
        l_syv_id_genus                 systvalue.syv_id%TYPE := NULL;
        l_syv_id_family                systvalue.syv_id%TYPE := NULL;
        l_syv_id_higher                systvalue.syv_id%TYPE := NULL;
        l_error                        BOOLEAN := FALSE;
        l_path                         VARCHAR2 (2048);
        l_areinhierarchy               BOOLEAN;
        l_response_subspecies          CHAR (1) := cst_reponsenoset;
        l_response_species             CHAR (1) := cst_reponsenoset;
        l_response_genus               CHAR (1) := cst_reponsenoset;
        l_response_family              CHAR (1) := cst_reponsenoset;
        l_response_highertaxon         CHAR (1) := cst_reponsenoset;
        l_syv_startwith                systvalue.syv_id%TYPE;
        l_crf_id                       codereference.crf_id%TYPE;
        l_flagprecisionmax             CHAR (1);
        l_reclanguagelatin             language%ROWTYPE;
    /* exc_taxonnotfound HIGHER: XXXXX(*1)/FAMILY: XXXXX(*1)/GENUS: XXXX(*1)/SPECIES: XXXXX(*1)/SUBSPECIES: XXXXX(*1) --> (*1) ERREUR: taxon non trouvé dans le thésaurus
             exc_taxonnotinhierarchy  HIGHER: XXXXX/FAMILY: XXXXX/GENUS: XXXX/SPECIES: XXXXX/SUBSPECIES: XXXXX --> ERREUR: Hiérarchie invalide
               cst_taxoninfo HIGHER: XXXXX/FAMILY: XXXXX/GENUS: XXXX/SPECIES: XXXXX/SUBSPECIES: XXXXX --> OK
        */
    BEGIN
        /* La valeur sp. dans la colonne espece doit être ignorée
           Les valeurs entre parenthèses doivent être ignorées
           Exemple: Chironomidae (Chironominae, Chironomini)
          */
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reclanguagelatin :=
            pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);
        l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
                l_recimportmassdataheader);

        l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
                l_recimportmassdataheader);
        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);



        IF NOT p_importmassdatadetail.imd_subspecies IS NULL
        THEN
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_subspecies,
                                   pkg_codevalue.cst_midatfldcmt_subspe,
                                   'IMD_SUBSPECIES',
                                   l_subspecies);
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
                   'IMD_SUBSPECIES='
                || p_importmassdatadetail.imd_subspecies
                || ' l_subspecies='
                || l_subspecies);

            l_response_subspecies :=
                pkg_systdesignation.f_designationexistatlevel (
                    l_subspecies,
                    pkg_codereference.cst_crf_subspecies,
                    pkg_language.cst_lan_cde_latin);



            IF l_response_subspecies = pkg_constante.cst_no
            THEN
                l_response_subspecies :=
                    pkg_systdesignation.f_designationexistatlevel (
                        l_subspecies,
                        pkg_codereference.cst_crf_form,
                        pkg_language.cst_lan_cde_latin);
            END IF;
        END IF;



        IF NOT p_importmassdatadetail.imd_species IS NULL
        THEN
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_species,
                                   pkg_codevalue.cst_midatfldcmt_species,
                                   'IMD_SPECIES',
                                   l_species);

            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
                   'IMD_SPECIES='
                || p_importmassdatadetail.imd_species
                || ' l_species='
                || l_species);
            l_countexclude :=
                pkg_codedesignation.f_countdesignation (
                    p_importmassdatadetail.imd_species,
                    pkg_codereference.cst_crf_excspekeywor);

            IF l_countexclude > 0
            THEN
                pkg_importprotocollog.p_writelog (
                    p_importmassdatadetail.imd_iph_id,
                    p_importmassdatadetail.imd_imh_id,
                    pkg_exception.cst_speciesvalueignored,
                    'IMD_SPECIES',
                    p_importmassdatadetail.imd_species,
                    TO_CHAR (p_importmassdatadetail.imd_sourceline));
                l_species := NULL;
            ELSE
                l_response_species :=
                    pkg_systdesignation.f_designationexistatlevel (
                        l_species,
                        pkg_codereference.cst_crf_aggsubspec,
                        pkg_language.cst_lan_cde_latin);

                IF l_response_species = pkg_constante.cst_no
                THEN
                    l_response_species :=
                        pkg_systdesignation.f_designationexistatlevel (
                            l_species,
                            pkg_codereference.cst_crf_species,
                            pkg_language.cst_lan_cde_latin);
                END IF;
            END IF;
        END IF;

        IF NOT p_importmassdatadetail.imd_genus IS NULL
        THEN
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_genus,
                                   pkg_codevalue.cst_midatfldcmt_genus,
                                   'IMD_GENUS',
                                   l_genus);
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
                   'IMD_genus='
                || p_importmassdatadetail.imd_genus
                || ' l_genus='
                || l_genus);

            l_response_genus :=
                pkg_systdesignation.f_designationexistatlevel (
                    l_genus,
                    pkg_codereference.cst_crf_aggspecies,
                    pkg_language.cst_lan_cde_latin);


            IF l_response_species = pkg_constante.cst_no
            THEN
                l_response_genus :=
                    pkg_systdesignation.f_designationexistatlevel (
                        l_genus,
                        pkg_codereference.cst_crf_subgenus,
                        pkg_language.cst_lan_cde_latin);
            END IF;

            IF l_response_genus = pkg_constante.cst_no
            THEN
                l_response_genus :=
                    pkg_systdesignation.f_designationexistatlevel (
                        l_genus,
                        pkg_codereference.cst_crf_genus,
                        pkg_language.cst_lan_cde_latin);
            END IF;
        END IF;


        IF NOT p_importmassdatadetail.imd_family IS NULL
        THEN
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_family,
                                   pkg_codevalue.cst_midatfldcmt_family,
                                   'IMD_FAMILY',
                                   l_family);
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
                   'IMD_FAMILY='
                || p_importmassdatadetail.imd_family
                || ' l_family='
                || l_family);

            l_response_family :=
                pkg_systdesignation.f_designationexistatlevel (
                    l_family,
                    pkg_codereference.cst_crf_tribe,
                    pkg_language.cst_lan_cde_latin);

            IF l_response_family = pkg_constante.cst_no
            THEN
                l_response_family :=
                    pkg_systdesignation.f_designationexistatlevel (
                        l_family,
                        pkg_codereference.cst_crf_subfamily,
                        pkg_language.cst_lan_cde_latin);
            END IF;

            IF l_response_family = pkg_constante.cst_no
            THEN
                l_response_family :=
                    pkg_systdesignation.f_designationexistatlevel (
                        l_family,
                        pkg_codereference.cst_crf_family,
                        pkg_language.cst_lan_cde_latin);
            END IF;
        END IF;



        IF NOT p_importmassdatadetail.imd_highertaxon IS NULL
        THEN
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_highertaxon,
                                   pkg_codevalue.cst_midatfldcmt_higher,
                                   'IMD_HIGHERTAXON',
                                   l_highertaxon);
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
                   'IMD_highertaxon='
                || p_importmassdatadetail.imd_highertaxon
                || ' l_highertaxon='
                || l_highertaxon);
            l_crf_code := f_findlevelhyghertaxon (l_highertaxon);

            IF l_crf_code IS NULL
            THEN
                l_response_highertaxon := pkg_constante.cst_no;
            END IF;
        END IF;



        l_path := ' HIGHER TAXON: ';

        IF NOT l_highertaxon IS NULL
        THEN
            IF l_response_highertaxon = pkg_constante.cst_no
            THEN
                l_error := TRUE;
                l_path := l_path || l_highertaxon || ' (*1)';
            ELSE
                l_path := l_path || p_importmassdatadetail.imd_highertaxon;
            END IF;
        ELSE
            l_path := l_path || ' <null>';
        END IF;

        l_path := l_path || ' FAMILY: ';

        IF NOT l_family IS NULL
        THEN
            IF l_response_family = pkg_constante.cst_no
            THEN
                l_error := TRUE;
                l_path := l_path || l_family || ' (*1)';
            ELSE
                l_path := l_path || l_family;
            END IF;
        ELSE
            l_path := l_path || ' <null>';
        END IF;

        l_path := l_path || ' GENUS: ';

        IF NOT l_genus IS NULL
        THEN
            IF l_response_genus = pkg_constante.cst_no
            THEN
                l_error := TRUE;
                l_path := l_path || l_genus || ' (*1)';
            ELSE
                l_path := l_path || l_genus;
            END IF;
        ELSE
            l_path := l_path || ' <null>';
        END IF;

        l_path := l_path || ' SPECIES: ';

        IF NOT l_species IS NULL
        THEN
            IF l_response_species = pkg_constante.cst_no
            THEN
                l_error := TRUE;
                l_path := l_path || l_species || ' (*1)';
            ELSE
                l_path := l_path || l_species;
            END IF;
        ELSE
            l_path := l_path || ' <null>';
        END IF;

        l_path := l_path || ' SUBSPECIES: ';

        IF NOT l_subspecies IS NULL
        THEN
            IF l_response_subspecies = pkg_constante.cst_no
            THEN
                l_error := TRUE;
                l_path := l_path || l_subspecies || ' (*1)';
            ELSE
                l_path := l_path || l_subspecies;
            END IF;
        ELSE
            l_path := l_path || ' <null>';
        END IF;



        IF l_error
        THEN
            -- HIGHER: XXXXX(*1)/FAMILY: XXXXX(*1)/GENUS: XXXX(*1)/SPECIES: XXXXX(*1)/SUBSPECIES: XXXXX(*1) --> (*1) ERREUR: taxon non trouvé dans le thésaurus
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                pkg_exception.cst_taxonnotfound,
                'IMD_HIGHERTAXON, IMD_FAMILY, IMD_GENUS, IMD_SPECIES, IMD_SUBSPECIES',
                l_path,
                TO_CHAR (p_importmassdatadetail.imd_sourceline));
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;


        pkg_identifysystematique.p_identifiesystematique (l_subspecies,
                                                          l_species,
                                                          l_genus,
                                                          l_family,
                                                          l_highertaxon,
                                                          NULL,  -- taxonibch,
                                                          NULL, --ptv_ptv_id_labofrommass,
                                                          l_syv_startwith,
                                                          l_crf_id,
                                                          l_flagprecisionmax,
                                                          l_returnstatus);


        p_comparesystematique (l_syv_startwith,
                               l_subspecies,
                               l_species,
                               l_genus,
                               l_family,
                               l_highertaxon,
                               l_syv_id_subspecies,
                               l_syv_id_species,
                               l_syv_id_genus,
                               l_syv_id_family,
                               l_syv_id_higher);

        IF    NOT l_subspecies IS NULL AND l_syv_id_subspecies IS NULL
           OR NOT l_species IS NULL AND l_syv_id_species IS NULL
           OR NOT l_genus IS NULL AND l_syv_id_genus IS NULL
           OR NOT l_family IS NULL AND l_syv_id_family IS NULL
           OR NOT l_highertaxon IS NULL AND l_syv_id_higher IS NULL
        THEN
            --  exc_taxonnotinhierarchy  Taxon fourni: %p1% - Hierarchie identifié: %p2%  -> Erreur: La hierarchie des taxons founie n''est pas celle identifiée: Ligne Excel %p3%
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                pkg_exception.cst_taxonnotinhierarchy,
                'IMD_HIGHERTAXON, IMD_FAMILY, IMD_GENUS, IMD_SPECIES, IMD_SUBSPECIES',
                l_path,
                pkg_systdesignation.f_returnpathdesignation (
                    l_syv_startwith,
                    l_reclanguagelatin.lan_id,
                    '/'),
                TO_CHAR (p_importmassdatadetail.imd_sourceline));

            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        --Taxon: %p1% Hierarchie identifié: %p2%--> OK : Ligne Excel %p3%
        pkg_importprotocollog.p_writelog (
            p_importmassdatadetail.imd_iph_id,
            p_importmassdatadetail.imd_imh_id,
            pkg_exception.cst_taxoninfo,
            'IMD_HIGHERTAXON, IMD_FAMILY, IMD_GENUS, IMD_SPECIES, IMD_SUBSPECIES',
            l_path,
            pkg_systdesignation.f_returnpathdesignation (
                l_syv_startwith,
                l_reclanguagelatin.lan_id,
                '/'),
            TO_CHAR (p_importmassdatadetail.imd_sourceline));
        p_checktaxonibch (l_syv_startwith,
                          p_importmassdatadetail,
                          l_subspecies,
                          l_species,
                          l_genus,
                          l_family,
                          l_highertaxon,
                          l_returnstatus);
        p_returnstatus := l_returnstatus;

        IF p_returnstatus = pkg_constante.cst_returnstatusok
        THEN
            p_addidentifiedtaxoncountuplev (1);
            pkg_importmassdatadetail.p_setsyv_id (
                p_importmassdatadetail.imd_id,
                l_syv_startwith);
        END IF;
    END;



    /*------------------------------------------------------------------------------*/

    PROCEDURE p_checksystematique_old (
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_lan_id                 IN     language.lan_id%TYPE,
        p_returnstatus              OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        l_null                         BOOLEAN := TRUE;
        l_syv_startwith                systvalue.syv_id%TYPE; -- Identifiant du niveau le plus bas
        l_crf_id                       codereference.crf_id%TYPE;
        l_flagprecisionmax             VARCHAR2 (1);
        l_counthierarchymatching       NUMBER;
        l_listsyv_id                   pkg_systdesignation.t_listsyv_id;
        l_systdesignation              VARCHAR2 (256);
        l_pathstring                   VARCHAR2 (512);
        cst_exception1        CONSTANT NUMBER
                                           := pkg_exception.cst_systentrynotfound ;
        cst_exception2        CONSTANT NUMBER
            := pkg_exception.cst_systentrynotmatchall ;
        cst_exception3        CONSTANT NUMBER
                                           := pkg_exception.cst_systematiquestat ;

        cst_exception4        CONSTANT NUMBER
                                           := pkg_exception.cst_systematiqueerror ;
        l_datetxt                      VARCHAR2 (256);
        l_swisscoord                   VARCHAR2 (256);
        l_excelfield_subspe            VARCHAR2 (256);
        l_excelfield_species           VARCHAR2 (256);
        l_excelfield_genus             VARCHAR2 (256);
        l_excelfield_family            VARCHAR2 (256);
        l_excelfield_highertaxon       VARCHAR2 (256);
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;

        l_module                       VARCHAR2 (256);
        l_excelfieldlist               VARCHAR2 (1024);
        l_countexclude                 NUMBER;
        l_textwithoutparenthesis       VARCHAR2 (1024);
        l_textbetweenparenthesis       VARCHAR2 (1024);
        l_crf_code                     codereference.crf_code%TYPE;
        l_protocolmappinglabo          protocolmappinglabo%ROWTYPE;
        l_taxa_used                    protocolmappinglabo.ptl_taxacscf%TYPE;
        l_datalistfindbydesignation    VARCHAR2 (1024);
        l_subspecies                   importmassdatadetail.imd_subspecies%TYPE;
        l_species                      importmassdatadetail.imd_species%TYPE;
        l_genus                        importmassdatadetail.imd_genus%TYPE;
        l_family                       importmassdatadetail.imd_family%TYPE;
        l_highertaxon                  importmassdatadetail.imd_highertaxon%TYPE;
        l_returnstatus                 NUMBER;
        l_dataprovided                 VARCHAR2 (2048);
        l_listonlevel                  VARCHAR2 (2049);
        l_firstfield                   VARCHAR2 (30);
        l_effectivefirstfield          VARCHAR2 (30);
        l_displaywarning               BOOLEAN;
        l_excludefield                 VARCHAR2 (2048);
        l_conceptfound                 VARCHAR2 (2048);
        l_conceptnotfound              VARCHAR2 (2048);
        l_conceptnotinhierarchy        VARCHAR2 (2048);
        l_appendfield                  VARCHAR2 (4096);
    BEGIN
        /* La valeur sp. dans la colonne espece doit être ignorée
         Les valeurs entre parenthèses doivent être ignorées
         Exemple: Chironomidae (Chironominae, Chironomini)
        */
        l_conceptnotinhierarchy := NULL;
        l_conceptfound := NULL;
        l_conceptnotfound := NULL;
        l_subspecies := NULL;
        l_species := NULL;
        l_genus := NULL;
        l_family := NULL;
        l_highertaxon := NULL;
        l_effectivefirstfield := NULL;
        p_returnstatus := pkg_constante.cst_returnstatusok;
        p_addidentifiedtaxoncount (1);
        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);


        l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
                l_recimportmassdataheader);

        l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
                l_recimportmassdataheader);

        IF NOT p_importmassdatadetail.imd_subspecies IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_subspe,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
                RETURN;
            END IF;

            l_excelfield_subspe :=
                l_recimportmassmappingheader.ime_excelfieldname;

            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_subspecies,
                                   l_excelfield_subspe,
                                   'IMD_SUBSPECIES',
                                   l_textwithoutparenthesis);



            p_checksystematiqueonlabo (p_importmassdatadetail,
                                       l_textwithoutparenthesis,
                                       pkg_codevalue.cst_midatfldcmt_subspe,
                                       l_crf_code,
                                       l_taxa_used);
            p_selecttaxavalue (l_textwithoutparenthesis,
                               l_taxa_used,
                               l_subspecies);

            l_listonlevel :=
                f_returnlistlevelinthesaurus (
                    pkg_codevalue.cst_midatfldcmt_subspe,
                    l_subspecies);

            IF l_subspecies != l_textwithoutparenthesis
            THEN
                l_appendfield :=
                       '['
                    || l_excelfield_subspe
                    || '] '
                    || l_textwithoutparenthesis
                    || ' -> '
                    || l_subspecies;
            ELSE
                l_appendfield :=
                    '[' || l_excelfield_subspe || '] ' || l_subspecies;
            END IF;

            l_dataprovided := f_addfield (l_dataprovided, l_appendfield);

            IF l_listonlevel IS NULL
            THEN
                l_conceptnotfound :=
                    pkg_utility.f_concatenate (l_conceptnotfound,
                                               l_appendfield,
                                               '/');
                l_dataprovided := l_dataprovided || '(?)';
            ELSE
                l_conceptfound :=
                    pkg_utility.f_concatenate (l_conceptfound,
                                               l_appendfield,
                                               '/');
            END IF;

            l_null := FALSE;
            l_excelfieldlist :=
                f_addfield (l_excelfieldlist, l_excelfield_subspe);

            IF l_effectivefirstfield IS NULL
            THEN
                l_effectivefirstfield := pkg_codevalue.cst_midatfldcmt_subspe;
            END IF;
        END IF;


        IF NOT p_importmassdatadetail.imd_species IS NULL
        THEN
            l_countexclude :=
                pkg_codedesignation.f_countdesignation (
                    p_importmassdatadetail.imd_species,
                    pkg_codereference.cst_crf_excspekeywor);

            IF l_countexclude > 0
            THEN
                pkg_importprotocollog.p_writelog (
                    p_importmassdatadetail.imd_iph_id,
                    p_importmassdatadetail.imd_imh_id,
                    pkg_exception.cst_speciesvalueignored,
                    'IMD_SPECIES',
                    p_importmassdatadetail.imd_species,
                    TO_CHAR (p_importmassdatadetail.imd_sourceline));
            ELSE
                l_recimportmassmappingheader :=
                    f_getmappingheader (
                        pkg_codevalue.cst_midatfldcmt_species,
                        l_recimportmassdataheader.imh_iph_id);

                IF l_recimportmassmappingheader.ime_id IS NULL
                THEN
                    p_returnstatus := pkg_constante.cst_returnstatusnotok;
                    RETURN;
                END IF;

                l_excelfield_species :=
                    l_recimportmassmappingheader.ime_excelfieldname;
                p_logparenthesisexist (p_importmassdatadetail,
                                       p_importmassdatadetail.imd_species,
                                       l_excelfield_species,
                                       'IMD_SPECIES',
                                       l_textwithoutparenthesis);

                p_checksystematiqueonlabo (
                    p_importmassdatadetail,
                    l_textwithoutparenthesis,
                    pkg_codevalue.cst_midatfldcmt_species,
                    l_crf_code,
                    l_taxa_used);


                p_selecttaxavalue (l_textwithoutparenthesis,
                                   l_taxa_used,
                                   l_species);
                l_listonlevel :=
                    f_returnlistlevelinthesaurus (
                        pkg_codevalue.cst_midatfldcmt_species,
                        l_species);

                IF l_species != l_textwithoutparenthesis
                THEN
                    l_appendfield :=
                           '['
                        || l_excelfield_species
                        || '] '
                        || l_textwithoutparenthesis
                        || ' -> '
                        || l_species;
                ELSE
                    l_appendfield :=
                        '[' || l_excelfield_species || '] ' || l_species;
                END IF;

                l_dataprovided := f_addfield (l_dataprovided, l_appendfield);

                IF l_listonlevel IS NULL
                THEN
                    l_conceptnotfound :=
                        pkg_utility.f_concatenate (l_conceptnotfound,
                                                   l_appendfield,
                                                   '/');
                    l_dataprovided := l_dataprovided || '(?)';
                ELSE
                    l_conceptfound :=
                        pkg_utility.f_concatenate (l_conceptfound,
                                                   l_appendfield,
                                                   '/');
                END IF;


                l_null := FALSE;
                l_excelfieldlist :=
                    f_addfield (l_excelfieldlist, l_excelfield_species);



                IF l_effectivefirstfield IS NULL
                THEN
                    l_effectivefirstfield :=
                        pkg_codevalue.cst_midatfldcmt_species;
                    l_systdesignation := p_importmassdatadetail.imd_species;
                END IF;
            END IF;
        END IF;


        IF NOT p_importmassdatadetail.imd_genus IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_genus,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
                RETURN;
            END IF;

            l_excelfield_genus :=
                l_recimportmassmappingheader.ime_excelfieldname;
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_genus,
                                   l_excelfield_genus,
                                   'IMD_GENUS',
                                   l_textwithoutparenthesis);

            p_checksystematiqueonlabo (p_importmassdatadetail,
                                       l_textwithoutparenthesis,
                                       pkg_codevalue.cst_midatfldcmt_genus,
                                       l_crf_code,
                                       l_taxa_used);


            p_selecttaxavalue (l_textwithoutparenthesis,
                               l_taxa_used,
                               l_genus);
            l_listonlevel :=
                f_returnlistlevelinthesaurus (
                    pkg_codevalue.cst_midatfldcmt_genus,
                    l_genus);

            IF l_genus != l_textwithoutparenthesis
            THEN
                l_appendfield :=
                       '['
                    || l_excelfield_genus
                    || '] '
                    || l_textwithoutparenthesis
                    || ' -> '
                    || l_genus;
            ELSE
                l_appendfield := '[' || l_excelfield_genus || '] ' || l_genus;
            END IF;

            l_dataprovided := f_addfield (l_dataprovided, l_appendfield);

            IF l_listonlevel IS NULL
            THEN
                l_conceptnotfound :=
                    pkg_utility.f_concatenate (l_conceptnotfound,
                                               l_appendfield,
                                               '/');
                l_dataprovided := l_dataprovided || '(?)';
            ELSE
                l_conceptfound :=
                    pkg_utility.f_concatenate (l_conceptfound,
                                               l_appendfield,
                                               '/');
            END IF;

            l_null := FALSE;
            l_excelfieldlist :=
                f_addfield (l_excelfieldlist, l_excelfield_genus);


            IF l_effectivefirstfield IS NULL
            THEN
                l_effectivefirstfield := pkg_codevalue.cst_midatfldcmt_genus;
                l_systdesignation := p_importmassdatadetail.imd_genus;
            END IF;
        END IF;

        IF NOT p_importmassdatadetail.imd_family IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_family,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
                RETURN;
            END IF;

            l_excelfield_family :=
                l_recimportmassmappingheader.ime_excelfieldname;
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_family,
                                   l_excelfield_family,
                                   'IMD_FAMILY',
                                   l_textwithoutparenthesis);

            p_checksystematiqueonlabo (p_importmassdatadetail,
                                       l_textwithoutparenthesis,
                                       pkg_codevalue.cst_midatfldcmt_family,
                                       l_crf_code,
                                       l_taxa_used);


            p_selecttaxavalue (l_textwithoutparenthesis,
                               l_taxa_used,
                               l_family);
            l_listonlevel :=
                f_returnlistlevelinthesaurus (
                    pkg_codevalue.cst_midatfldcmt_family,
                    l_family);

            IF l_family != l_textwithoutparenthesis
            THEN
                l_appendfield :=
                       '['
                    || l_excelfield_family
                    || '] '
                    || l_textwithoutparenthesis
                    || ' -> '
                    || l_family;
            ELSE
                l_appendfield :=
                    '[' || l_excelfield_family || '] ' || l_family;
            END IF;

            l_dataprovided := f_addfield (l_dataprovided, l_appendfield);

            IF l_listonlevel IS NULL
            THEN
                l_conceptnotfound :=
                    pkg_utility.f_concatenate (l_conceptnotfound,
                                               l_appendfield,
                                               '/');
                l_dataprovided := l_dataprovided || '(?)';
            ELSE
                l_conceptfound :=
                    pkg_utility.f_concatenate (l_conceptfound,
                                               l_appendfield,
                                               '/');
            END IF;

            l_null := FALSE;
            l_excelfieldlist :=
                f_addfield (l_excelfieldlist, l_excelfield_family);


            IF l_effectivefirstfield IS NULL
            THEN
                l_effectivefirstfield := pkg_codevalue.cst_midatfldcmt_family;
                l_systdesignation := p_importmassdatadetail.imd_family;
            END IF;
        END IF;


        IF NOT p_importmassdatadetail.imd_highertaxon IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_higher,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
                RETURN;
            END IF;

            l_excelfield_highertaxon :=
                l_recimportmassmappingheader.ime_excelfieldname;
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_highertaxon,
                                   l_excelfield_highertaxon,
                                   'IMD_TAXONSUP',
                                   l_textwithoutparenthesis);

            p_checksystematiqueonlabo (p_importmassdatadetail,
                                       l_textwithoutparenthesis,
                                       pkg_codevalue.cst_midatfldcmt_higher,
                                       l_crf_code,
                                       l_taxa_used);


            p_selecttaxavalue (l_textwithoutparenthesis,
                               l_taxa_used,
                               l_highertaxon);
            l_listonlevel :=
                f_returnlistlevelinthesaurus (
                    pkg_codevalue.cst_midatfldcmt_higher,
                    l_highertaxon);

            IF l_highertaxon != l_textwithoutparenthesis
            THEN
                l_appendfield :=
                       '['
                    || l_excelfield_highertaxon
                    || '] '
                    || l_textwithoutparenthesis
                    || ' -> '
                    || l_highertaxon;
            ELSE
                l_appendfield :=
                    '[' || l_excelfield_highertaxon || '] ' || l_highertaxon;
            END IF;

            l_dataprovided := f_addfield (l_dataprovided, l_appendfield);

            IF l_listonlevel IS NULL
            THEN
                l_conceptnotfound :=
                    pkg_utility.f_concatenate (l_conceptnotfound,
                                               l_appendfield,
                                               '/');
                l_dataprovided := l_dataprovided || '(?)';
            ELSE
                l_conceptfound :=
                    pkg_utility.f_concatenate (l_conceptfound,
                                               l_appendfield,
                                               '/');
            END IF;

            l_null := FALSE;
            l_excelfieldlist :=
                f_addfield (l_excelfieldlist, l_excelfield_highertaxon);


            IF l_effectivefirstfield IS NULL
            THEN
                l_effectivefirstfield := pkg_codevalue.cst_midatfldcmt_higher;
                l_systdesignation := p_importmassdatadetail.imd_highertaxon;
            END IF;
        END IF;



        pkg_debug.p_write (
            'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
               'IMD_SUBSPECIES='
            || p_importmassdatadetail.imd_subspecies
            || ' l_subspecies='
            || l_subspecies
            || 'IMD_SPECIES='
            || p_importmassdatadetail.imd_species
            || ' l_species='
            || l_species
            || ' IMD_GENUS='
            || p_importmassdatadetail.imd_genus
            || ' l_genus='
            || l_genus
            || ' IMD_FAMILY='
            || p_importmassdatadetail.imd_family
            || ' l_family='
            || l_family
            || ' IMD_HIGHERTAXON='
            || p_importmassdatadetail.imd_highertaxon
            || ' l_highertaxon='
            || l_highertaxon);

        IF NOT l_null
        THEN
            pkg_identifysystematique.p_identifiesystematique (
                l_subspecies,
                l_species,
                l_genus,
                l_family,
                l_highertaxon,
                NULL,                                            -- taxonibch,
                NULL,                               --ptv_ptv_id_labofrommass,
                l_syv_startwith,
                l_crf_id,
                l_flagprecisionmax,
                l_returnstatus);
            /*
         p_identifiesystematique (l_subspecies,
                                  l_species,
                                  l_genus,
                                  l_family,
                                  l_highertaxon,
                                  l_syv_startwith,
                                  l_crf_id,
                                  l_flagprecisionmax,
                                  l_returnstatus);
              */
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
                   'l_syv_startwith='
                || l_syv_startwith
                || ' l_flagprecisionmax='
                || l_flagprecisionmax);

            IF l_syv_startwith IS NULL
            THEN
                l_conceptnotinhierarchy := l_conceptfound;
            END IF;

            --Concepts trouvés dans le thésaurus : %p1%. Concepts non trouvés dans le thésaurus: %p2%. Hiérarchie non respectée entre les concepts %p3% .
            -- Ligne Excel: %p4%, date -> %p5% [x,y,z] --> %p6% colonne(s) source(s) -> %p7&
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
                   'l_conceptnotfound='
                || l_conceptnotfound
                || ' '
                || 'l_conceptnotinhierarchy='
                || l_conceptnotinhierarchy);

            IF l_conceptnotfound IS NULL AND l_conceptnotinhierarchy IS NULL
            THEN
                pkg_importprotocollog.p_writelog (
                    p_importmassdatadetail.imd_iph_id,
                    p_importmassdatadetail.imd_imh_id,
                    cst_exception3,
                    'IMD_HIGHERTAXON, IMD_FAMILY, IMD_GENUS, IMD_SPECIES, IMD_SUBSPECIES',
                    NVL (l_conceptfound, '.-.'),
                    NVL (l_conceptnotfound, '.-.'),
                    NVL (l_conceptnotinhierarchy, '.-.'),
                    TO_CHAR (p_importmassdatadetail.imd_sourceline),
                    l_datetxt,
                    l_swisscoord,
                    l_excelfieldlist);
            ELSE
                pkg_importprotocollog.p_writelog (
                    p_importmassdatadetail.imd_iph_id,
                    p_importmassdatadetail.imd_imh_id,
                    cst_exception4,
                    'IMD_HIGHERTAXON, IMD_FAMILY, IMD_GENUS, IMD_SPECIES, IMD_SUBSPECIES',
                    NVL (l_conceptfound, '.-.'),
                    NVL (l_conceptnotfound, '.-.'),
                    NVL (l_conceptnotinhierarchy, '.-.'),
                    TO_CHAR (p_importmassdatadetail.imd_sourceline),
                    l_datetxt,
                    l_swisscoord,
                    l_excelfieldlist);
                p_returnstatus :=
                    pkg_message.f_convertseveritylevel2status (
                        cst_exception4);
                RETURN;
            END IF;



            IF l_syv_startwith IS NULL
            THEN
                pkg_debug.p_write (
                    'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
                       'NOT OK l_syv_startwith='
                    || l_syv_startwith
                    || ' l_flagprecisionmax='
                    || l_flagprecisionmax);
                l_datalistfindbydesignation :=
                    pkg_systdesignation.f_returnfindbydesignation;
                pkg_importprotocollog.p_writelog (
                    p_importmassdatadetail.imd_iph_id,
                    p_importmassdatadetail.imd_imh_id,
                    cst_exception1,
                    'IMD_HIGHERTAXON, IMD_FAMILY, IMD_GENUS, IMD_SPECIES, IMD_SUBSPECIES',
                    l_dataprovided,
                    TO_CHAR (p_importmassdatadetail.imd_sourceline),
                    l_datetxt,
                    l_swisscoord,
                    l_excelfieldlist);
                p_returnstatus :=
                    pkg_message.f_convertseveritylevel2status (
                        cst_exception1);



                RETURN;
            END IF;

            l_displaywarning := FALSE;
            pkg_debug.p_write (
                'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
                'l_flagprecisionmax=' || l_flagprecisionmax);


            IF l_flagprecisionmax = pkg_constante.cst_yes -- Précision max par rapport au valeur existante mais les valeurs non trouvé dans le thésaurus ne sont pas prise en compte
            THEN
                -- la désignation la plus précisie a pu être utilisée
                l_firstfield := f_determinefieldfromcrf_id (l_crf_id);

                IF l_effectivefirstfield = l_firstfield
                THEN
                    p_identifiedtaxoncountlowlev (1);
                    pkg_importmassdatadetail.p_setsyv_id (
                        p_importmassdatadetail.imd_id,
                        l_syv_startwith);
                    pkg_debug.p_write (
                        'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
                           ' Enregistré OK l_syv_startwith='
                        || l_syv_startwith
                        || ' l_flagprecisionmax='
                        || l_flagprecisionmax
                        || 'IMD_SUBSPECIES='
                        || p_importmassdatadetail.imd_subspecies
                        || ' IMD_SPECIES='
                        || p_importmassdatadetail.imd_species
                        || '  IMD_GENUS='
                        || p_importmassdatadetail.imd_genus
                        || '  IMD_FAMILY='
                        || p_importmassdatadetail.imd_family
                        || '  IMD_HIGHERTAXON='
                        || p_importmassdatadetail.imd_highertaxon);

                    RETURN;
                ELSE
                    l_displaywarning := TRUE;
                END IF;
            ELSE                -- l_flagprecisionmax != pkg_constante.cst_yes
                IF l_effectivefirstfield != l_firstfield -- la  procédure p_identifiesystematique retourne  l_flagprecisionmax != pkg_constante.cst_yes
                THEN --  si par exemple un aggrégat de sous espece est identifié avec le non contenus colonne espece
                    l_displaywarning := TRUE;
                ELSE
                    p_identifiedtaxoncountlowlev (1);
                    pkg_importmassdatadetail.p_setsyv_id (
                        p_importmassdatadetail.imd_id,
                        l_syv_startwith);
                END IF;
            END IF;

            IF l_displaywarning
            THEN
                l_firstfield := f_determinefieldfromcrf_id (l_crf_id);
                l_excludefield :=
                    f_buildexcludefield (p_importmassdatadetail,
                                         l_firstfield);

                --    l_pathstring := pkg_systdesignation.f_returnfindbydesignationtxt;
                l_pathstring :=
                    pkg_systdesignation.f_returnpathdesignation (
                        l_syv_startwith,
                        p_lan_id,
                        '/');
                pkg_debug.p_write (
                    'PKG_VALIDATEMASSDETAILFIELD.p_checksystematique',
                       ' l_pathstring='
                    || l_pathstring
                    || ' l_firstfield='
                    || l_firstfield
                    || ' l_excludefield='
                    || l_excludefield
                    || 'IMD_SUBSPECIES='
                    || p_importmassdatadetail.imd_subspecies
                    || ' IMD_SPECIES='
                    || p_importmassdatadetail.imd_species
                    || '  IMD_GENUS='
                    || p_importmassdatadetail.imd_genus
                    || '  IMD_FAMILY='
                    || p_importmassdatadetail.imd_family
                    || '  IMD_HIGHERTAXON='
                    || p_importmassdatadetail.imd_highertaxon);
                pkg_importprotocollog.p_writelog (
                    p_importmassdatadetail.imd_iph_id,
                    p_importmassdatadetail.imd_imh_id,
                    cst_exception2,
                    'IMD_HIGHERTAXON, IMD_FAMILY, IMD_GENUS, IMD_SPECIES, IMD_SUBSPECIES',
                    l_excludefield,
                    l_pathstring,
                    TO_CHAR (p_importmassdatadetail.imd_sourceline),
                    l_datetxt,
                    l_swisscoord,
                    l_excelfieldlist);
                p_returnstatus :=
                    pkg_message.f_convertseveritylevel2status (
                        cst_exception2);

                IF p_returnstatus = pkg_constante.cst_returnstatusok
                THEN
                    p_addidentifiedtaxoncountuplev (1);
                    pkg_importmassdatadetail.p_setsyv_id (
                        p_importmassdatadetail.imd_id,
                        l_syv_startwith);
                END IF;
            END IF;
        END IF;
    END;

    /*------------------------------------------------------------------------------*/

    PROCEDURE p_checksystematiqueold (
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_lan_id                 IN     language.lan_id%TYPE,
        p_returnstatus              OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        l_null                         BOOLEAN := TRUE;
        l_syv_startwith                systvalue.syv_id%TYPE; -- Identifiant du niveau le plus bas
        l_crf_id                       codereference.crf_id%TYPE;
        l_flagprecisionmax             VARCHAR2 (1);
        l_counthierarchymatching       NUMBER;
        l_listsyv_id                   pkg_systdesignation.t_listsyv_id;
        l_systdesignation              VARCHAR2 (256);
        l_pathstring                   VARCHAR2 (512);
        cst_exception1        CONSTANT NUMBER
                                           := pkg_exception.cst_systentrynotfound ;
        cst_exception2        CONSTANT NUMBER
            := pkg_exception.cst_systentrynotmatchall ;
        l_datetxt                      VARCHAR2 (256);
        l_swisscoord                   VARCHAR2 (256);
        l_excelfield                   VARCHAR2 (256);
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;

        l_module                       VARCHAR2 (256);
        l_excelfieldlist               VARCHAR2 (1024);
        l_countexclude                 NUMBER;
        l_textwithoutparenthesis       VARCHAR2 (1024);
        l_textbetweenparenthesis       VARCHAR2 (1024);
        l_crf_code                     codereference.crf_code%TYPE;
        l_protocolmappinglabo          protocolmappinglabo%ROWTYPE;
        l_taxa_used                    protocolmappinglabo.ptl_taxacscf%TYPE;
        l_datalistfindbydesignation    VARCHAR2 (1024);
    BEGIN
        /* La valeur sp. dans la colonne espece doit être ignorée
         Les valeurs entre parenthèses doivent être ignorées
         Exemple: Chironomidae (Chironominae, Chironomini)
        */
        p_returnstatus := pkg_constante.cst_returnstatusok;
        p_addidentifiedtaxoncount (1);
        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);
        pkg_systdesignation.p_clearfindbydesignation;

        l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
                l_recimportmassdataheader);

        l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
                l_recimportmassdataheader);

        IF NOT p_importmassdatadetail.imd_subspecies IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_subspe,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
                RETURN;
            END IF;

            l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_subspecies,
                                   l_excelfield,
                                   'IMD_SUBSPECIES',
                                   l_textwithoutparenthesis);

            p_checksystematiqueonlabo (p_importmassdatadetail,
                                       l_textwithoutparenthesis,
                                       pkg_codevalue.cst_midatfldcmt_subspe,
                                       l_crf_code,
                                       l_taxa_used);

            -- SI l_taxa_used est null alors on doit prende l_textwithoutparenthesis pour la procedure de recheche

            IF l_taxa_used IS NULL
            THEN
                l_crf_code := pkg_codereference.cst_crf_subspecies;
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_textwithoutparenthesis);
            ELSIF l_taxa_used = l_textwithoutparenthesis
            THEN
                -- Si   l_taxa_used =    l_textwithoutparenthesis on doit prende    l_textwithoutparenthesis pour la procedure de recheche
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_textwithoutparenthesis);
            ELSIF -- Si l_taxa_used !=     l_textwithoutparenthesis  on doit prendre     l_taxa_used dans la rpcidure de recheche
                  l_taxa_used != l_textwithoutparenthesis
            THEN
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_taxa_used);
            END IF;

            l_null := FALSE;
            l_systdesignation := p_importmassdatadetail.imd_subspecies;

            IF l_excelfieldlist IS NULL
            THEN
                l_excelfieldlist := l_excelfield;
            ELSE
                l_excelfieldlist := l_excelfieldlist || '/' || l_excelfield;
            END IF;
        END IF;


        IF NOT p_importmassdatadetail.imd_species IS NULL
        THEN
            l_countexclude :=
                pkg_codedesignation.f_countdesignation (
                    p_importmassdatadetail.imd_species,
                    pkg_codereference.cst_crf_excspekeywor);

            IF l_countexclude > 0
            THEN
                pkg_importprotocollog.p_writelog (
                    p_importmassdatadetail.imd_iph_id,
                    p_importmassdatadetail.imd_imh_id,
                    pkg_exception.cst_speciesvalueignored,
                    'IMD_SPECIES',
                    p_importmassdatadetail.imd_species,
                    TO_CHAR (p_importmassdatadetail.imd_sourceline));
            ELSE
                l_recimportmassmappingheader :=
                    f_getmappingheader (
                        pkg_codevalue.cst_midatfldcmt_species,
                        l_recimportmassdataheader.imh_iph_id);

                IF l_recimportmassmappingheader.ime_id IS NULL
                THEN
                    p_returnstatus := pkg_constante.cst_returnstatusnotok;
                    RETURN;
                END IF;

                l_excelfield :=
                    l_recimportmassmappingheader.ime_excelfieldname;
                p_logparenthesisexist (p_importmassdatadetail,
                                       p_importmassdatadetail.imd_species,
                                       l_excelfield,
                                       'IMD_SPECIES',
                                       l_textwithoutparenthesis);

                p_checksystematiqueonlabo (
                    p_importmassdatadetail,
                    l_textwithoutparenthesis,
                    pkg_codevalue.cst_midatfldcmt_species,
                    l_crf_code,
                    l_taxa_used);

                -- SI l_taxa_used est null alors on doit prende l_textwithoutparenthesis pour la procedure de recheche

                IF l_taxa_used IS NULL
                THEN
                    l_crf_code := pkg_codereference.cst_crf_species;
                    pkg_systdesignation.p_addfindbydesignation (
                        pkg_language.cst_lan_cde_latin,
                        l_crf_code,
                        l_textwithoutparenthesis);
                ELSIF l_taxa_used = l_textwithoutparenthesis
                THEN
                    -- Si   l_taxa_used =    l_textwithoutparenthesis on doit prende    l_textwithoutparenthesis pour la procedure de recheche
                    pkg_systdesignation.p_addfindbydesignation (
                        pkg_language.cst_lan_cde_latin,
                        l_crf_code,
                        l_textwithoutparenthesis);
                ELSIF -- Si l_taxa_used !=     l_textwithoutparenthesis  on doit prendre     l_taxa_used dans la rpcidure de recheche
                      l_taxa_used != l_textwithoutparenthesis
                THEN
                    pkg_systdesignation.p_addfindbydesignation (
                        pkg_language.cst_lan_cde_latin,
                        l_crf_code,
                        l_taxa_used);
                END IF;

                l_null := FALSE;
                l_systdesignation := p_importmassdatadetail.imd_species;

                IF l_excelfieldlist IS NULL
                THEN
                    l_excelfieldlist := l_excelfield;
                ELSE
                    l_excelfieldlist :=
                        l_excelfieldlist || '/' || l_excelfield;
                END IF;
            END IF;
        END IF;


        IF NOT p_importmassdatadetail.imd_genus IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_genus,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
                RETURN;
            END IF;

            l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_genus,
                                   l_excelfield,
                                   'IMD_GENUS',
                                   l_textwithoutparenthesis);

            p_checksystematiqueonlabo (p_importmassdatadetail,
                                       l_textwithoutparenthesis,
                                       pkg_codevalue.cst_midatfldcmt_genus,
                                       l_crf_code,
                                       l_taxa_used);

            -- SI l_taxa_used est null alors on doit prende l_textwithoutparenthesis pour la procedure de recheche

            IF l_taxa_used IS NULL
            THEN
                l_crf_code := pkg_codereference.cst_crf_genus;
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_textwithoutparenthesis);
            ELSIF l_taxa_used = l_textwithoutparenthesis
            THEN
                -- Si   l_taxa_used =    l_textwithoutparenthesis on doit prende    l_textwithoutparenthesis pour la procedure de recheche
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_textwithoutparenthesis);
            ELSIF -- Si l_taxa_used !=     l_textwithoutparenthesis  on doit prendre     l_taxa_used dans la rpcidure de recheche
                  l_taxa_used != l_textwithoutparenthesis
            THEN
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_taxa_used);
            END IF;

            l_null := FALSE;
            l_systdesignation := p_importmassdatadetail.imd_genus;

            IF l_excelfieldlist IS NULL
            THEN
                l_excelfieldlist := l_excelfield;
            ELSE
                l_excelfieldlist := l_excelfieldlist || '/' || l_excelfield;
            END IF;
        END IF;

        IF NOT p_importmassdatadetail.imd_family IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_family,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
                RETURN;
            END IF;

            l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_family,
                                   l_excelfield,
                                   'IMD_FAMILY',
                                   l_textwithoutparenthesis);

            p_checksystematiqueonlabo (p_importmassdatadetail,
                                       l_textwithoutparenthesis,
                                       pkg_codevalue.cst_midatfldcmt_family,
                                       l_crf_code,
                                       l_taxa_used);

            -- SI l_taxa_used est null alors on doit prende l_textwithoutparenthesis pour la procedure de recheche

            IF l_taxa_used IS NULL
            THEN
                l_crf_code := pkg_codereference.cst_crf_family;
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_textwithoutparenthesis);
            ELSIF l_taxa_used = l_textwithoutparenthesis
            THEN
                -- Si   l_taxa_used =    l_textwithoutparenthesis on doit prende    l_textwithoutparenthesis pour la procedure de recheche
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_textwithoutparenthesis);
            ELSIF -- Si l_taxa_used !=     l_textwithoutparenthesis  on doit prendre     l_taxa_used dans la rpcidure de recheche
                  l_taxa_used != l_textwithoutparenthesis
            THEN
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_taxa_used);
            END IF;

            l_null := FALSE;
            l_systdesignation := p_importmassdatadetail.imd_family;

            IF l_excelfieldlist IS NULL
            THEN
                l_excelfieldlist := l_excelfield;
            ELSE
                l_excelfieldlist := l_excelfieldlist || '/' || l_excelfield;
            END IF;
        END IF;


        IF NOT p_importmassdatadetail.imd_highertaxon IS NULL
        THEN
            l_recimportmassmappingheader :=
                f_getmappingheader (pkg_codevalue.cst_midatfldcmt_higher,
                                    l_recimportmassdataheader.imh_iph_id);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
                RETURN;
            END IF;

            l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;
            p_logparenthesisexist (p_importmassdatadetail,
                                   p_importmassdatadetail.imd_highertaxon,
                                   l_excelfield,
                                   'IMD_TAXONSUP',
                                   l_textwithoutparenthesis);

            p_checksystematiqueonlabo (p_importmassdatadetail,
                                       l_textwithoutparenthesis,
                                       pkg_codevalue.cst_midatfldcmt_higher,
                                       l_crf_code,
                                       l_taxa_used);

            -- SI l_taxa_used est null alors on doit prende l_textwithoutparenthesis pour la procedure de recheche

            IF l_taxa_used IS NULL
            THEN
                l_crf_code := pkg_codereference.cst_crf_order;
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_textwithoutparenthesis);
            ELSIF l_taxa_used = l_textwithoutparenthesis
            THEN
                -- Si   l_taxa_used =    l_textwithoutparenthesis on doit prende    l_textwithoutparenthesis pour la procedure de recheche
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_textwithoutparenthesis);
            ELSIF -- Si l_taxa_used !=     l_textwithoutparenthesis  on doit prendre     l_taxa_used dans la rpcidure de recheche
                  l_taxa_used != l_textwithoutparenthesis
            THEN
                pkg_systdesignation.p_addfindbydesignation (
                    pkg_language.cst_lan_cde_latin,
                    l_crf_code,
                    l_taxa_used);
            END IF;

            l_null := FALSE;
            l_systdesignation := p_importmassdatadetail.imd_highertaxon;

            IF l_excelfieldlist IS NULL
            THEN
                l_excelfieldlist := l_excelfield;
            ELSE
                l_excelfieldlist := l_excelfieldlist || '/' || l_excelfield;
            END IF;
        END IF;

        IF NOT l_null
        THEN
            IF p_importmassdatadetail.imd_species IS NULL
            THEN
                pkg_systdesignation.p_processfindbydesignation (
                    l_syv_startwith,       -- Identifiant du niveu le plus bas
                    l_crf_id,              -- Identifiant du code de référence
                    l_flagprecisionmax -- Flag (Y/N) permttant de savoir si l'élément le plus précis est utilisé
                                      );
            ELSE
                /* Si la colonne p_importmassdatadetail.imd_species n'est pas null, elle peut contenir uen valeur de SPECIES, AGGSUBSPECIES */
                p_processfindbydesignation_spe (l_syv_startwith, -- Identifiant du niveu le plus bas
                                                l_crf_id, -- Identifiant du code de référence
                                                l_flagprecisionmax -- Flag (Y/N) permttant de savoir si l'élément le plus précis est utilisé
                                                                  );
            END IF;

            IF l_syv_startwith IS NULL
            THEN
                l_datalistfindbydesignation :=
                    pkg_systdesignation.f_returnfindbydesignation;
                pkg_importprotocollog.p_writelog (
                    p_importmassdatadetail.imd_iph_id,
                    p_importmassdatadetail.imd_imh_id,
                    cst_exception1,
                    'IMD_HIGHERTAXON, IMD_FAMILY, IMD_GENUS, IMD_SPECIES, IMD_SUBSPECIES',
                    l_datalistfindbydesignation,
                    TO_CHAR (p_importmassdatadetail.imd_sourceline),
                    l_datetxt,
                    l_swisscoord,
                    l_excelfieldlist);
                p_returnstatus :=
                    pkg_message.f_convertseveritylevel2status (
                        cst_exception1);
                RETURN;
            END IF;

            IF l_flagprecisionmax = pkg_constante.cst_yes
            THEN
                -- la désignation la plus précisie a pu être utilisée
                p_identifiedtaxoncountlowlev (1);
                pkg_importmassdatadetail.p_setsyv_id (
                    p_importmassdatadetail.imd_id,
                    l_syv_startwith);
                RETURN;
            END IF;

            --    l_pathstring := pkg_systdesignation.f_returnfindbydesignationtxt;
            l_pathstring :=
                pkg_systdesignation.f_returnpathdesignation (l_syv_startwith,
                                                             p_lan_id,
                                                             '/');
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                cst_exception2,
                'IMD_HIGHERTAXON, IMD_FAMILY, IMD_GENUS, IMD_SPECIES, IMD_SUBSPECIES',
                l_systdesignation,
                l_pathstring,
                TO_CHAR (p_importmassdatadetail.imd_sourceline),
                l_datetxt,
                l_swisscoord,
                l_excelfieldlist);
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (cst_exception2);

            IF p_returnstatus = pkg_constante.cst_returnstatusok
            THEN
                p_addidentifiedtaxoncountuplev (1);
                pkg_importmassdatadetail.p_setsyv_id (
                    p_importmassdatadetail.imd_id,
                    l_syv_startwith);
            END IF;
        END IF;
    END;



    /*-------------------------------------------------------------------*/

    PROCEDURE p_checkfreq1 (
        p_importmassdatadetail    IN     importmassdatadetail%ROWTYPE,
        p_lan_id                  IN     language.lan_id%TYPE,
        p_makroindexcalculation   IN     BOOLEAN,
        p_returnstatus               OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        l_number                       NUMBER;
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_module                       VARCHAR2 (256);
        cst_exception         CONSTANT NUMBER
            := pkg_exception.cst_positivevaluerequired ;
        l_datetxt                      VARCHAR2 (256);
        l_swisscoord                   VARCHAR2 (256);
        l_excelfield                   VARCHAR2 (256);
        l_recabundanceclassrange       abundanceclassrange%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;


        IF p_importmassdatadetail.imd_freq1 IS NULL
        THEN
            RETURN;
        END IF;

        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);

        l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
                l_recimportmassdataheader);

        l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
                l_recimportmassdataheader);
        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                l_recimportmassdataheader.imh_iph_id,
                pkg_codevalue.cst_midatfldcmt_freq1);

        IF l_recimportmassmappingheader.ime_id IS NULL
        THEN
            l_module :=
                   'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
                || TO_CHAR (l_recimportmassdataheader.imh_iph_id)
                || ','''
                || pkg_codevalue.cst_midatfldcmt_freq1
                || ''')';
            pkg_importprotocollog.p_logunexpectederror (
                l_recimportmassdataheader.imh_iph_id,
                'IMD_FREQ1',
                l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;


        l_number :=
            pkg_datatype.f_validateposinteger (
                p_importmassdatadetail.imd_freq1);

        IF l_number IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                cst_exception,
                'IMD_FREQ1',
                p_importmassdatadetail.imd_freq1,
                'IMD_FREQ1',
                TO_CHAR (p_importmassdatadetail.imd_sourceline),
                l_datetxt,
                l_swisscoord,
                l_excelfield);
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (cst_exception);
        END IF;

        /*
      ELSE
         IF p_makroindexcalculation
         THEN
            -- Les valeurs doivent être dans une des classes définies
            l_recabundanceclassrange :=
               pkg_abundanceclassrange.f_getrecordbyclass (
                  pkg_codevalue.cst_midatfldcmt_makroindex,
                  l_number);

            IF l_recabundanceclassrange.acr_id IS NULL
            THEN
               pkg_importprotocollog.p_writelog (
                  p_importmassdatadetail.imd_iph_id,
                  p_importmassdatadetail.imd_imh_id,
                  pkg_exception.cst_mkiclassoutofrange,
                  'IMD_FREQ1',
                  p_importmassdatadetail.imd_freq1,
                  'IMD_FREQ1',
                  TO_CHAR (p_importmassdatadetail.imd_sourceline),
                  l_datetxt,
                  l_swisscoord,
                  l_excelfield);
               p_returnstatus :=
                  pkg_message.f_convertseveritylevel2status (
                     pkg_exception.cst_mkiclassoutofrange);
            END IF;
         END IF;
      END IF;
      */



        NULL;
    END;

    /*-------------------------------------------------------------------*/

    PROCEDURE p_checkfreq2 (
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_lan_id                 IN     language.lan_id%TYPE,
        p_returnstatus              OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        l_number                       NUMBER;
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_module                       VARCHAR2 (256);
        cst_exception         CONSTANT NUMBER
            := pkg_exception.cst_positivevaluerequired ;
        l_datetxt                      VARCHAR2 (256);
        l_swisscoord                   VARCHAR2 (256);
        l_excelfield                   VARCHAR2 (256);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        IF p_importmassdatadetail.imd_freq2 IS NULL
        THEN
            RETURN;
        END IF;

        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);

        l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
                l_recimportmassdataheader);

        l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
                l_recimportmassdataheader);
        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                l_recimportmassdataheader.imh_iph_id,
                pkg_codevalue.cst_midatfldcmt_freq2);

        IF l_recimportmassmappingheader.ime_id IS NULL
        THEN
            l_module :=
                   'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
                || TO_CHAR (l_recimportmassdataheader.imh_iph_id)
                || ','''
                || pkg_codevalue.cst_midatfldcmt_freq2
                || ''')';
            pkg_importprotocollog.p_logunexpectederror (
                l_recimportmassdataheader.imh_iph_id,
                'IMD_FREQ2',
                l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;

        l_number :=
            pkg_datatype.f_validateposinteger (
                p_importmassdatadetail.imd_freq2);

        IF l_number IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                cst_exception,
                'IMD_FREQ2',
                p_importmassdatadetail.imd_freq2,
                'IMD_FREQ2',
                TO_CHAR (p_importmassdatadetail.imd_sourceline),
                l_datetxt,
                l_swisscoord,
                l_excelfield);
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (cst_exception);
        END IF;

        NULL;
    END;

    /*-------------------------------------------------------------------*/

    PROCEDURE p_checkfreqlum (
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_lan_id                 IN     language.lan_id%TYPE,
        p_returnstatus              OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        l_number                       NUMBER;
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_module                       VARCHAR2 (256);
        cst_exception         CONSTANT NUMBER
            := pkg_exception.cst_positivevaluerequired ;
        l_datetxt                      VARCHAR2 (256);
        l_swisscoord                   VARCHAR2 (256);
        l_excelfield                   VARCHAR2 (256);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        IF p_importmassdatadetail.imd_freqlum IS NULL
        THEN
            RETURN;
        END IF;

        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);

        l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
                l_recimportmassdataheader);

        l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
                l_recimportmassdataheader);
        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                l_recimportmassdataheader.imh_iph_id,
                pkg_codevalue.cst_midatfldcmt_freqlum);

        IF l_recimportmassmappingheader.ime_id IS NULL
        THEN
            l_module :=
                   'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
                || TO_CHAR (l_recimportmassdataheader.imh_iph_id)
                || ','''
                || pkg_codevalue.cst_midatfldcmt_freqlum
                || ''')';
            pkg_importprotocollog.p_logunexpectederror (
                l_recimportmassdataheader.imh_iph_id,
                'IMD_FREQLUM',
                l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;

        l_number :=
            pkg_datatype.f_validateposinteger (
                p_importmassdatadetail.imd_freqlum);

        IF l_number IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                cst_exception,
                'IMD_FREQLUM',
                p_importmassdatadetail.imd_freqlum,
                'IMD_FREQLUM',
                TO_CHAR (p_importmassdatadetail.imd_sourceline),
                l_datetxt,
                l_swisscoord,
                l_excelfield);
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (cst_exception);
        END IF;

        NULL;
    END;

    /*-------------------------------------------------------------------*/

    PROCEDURE p_checkstadium (
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_lan_id                 IN     language.lan_id%TYPE,
        p_returnstatus              OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        /* Le stade de dévellopment de l'organisme doit être identifié si
         1. La colonne "STADIUM" est définie
         2. L'organisme est un Trichoptera
         Un message de niveau Erreur est défini si la colonne "STADIUM" est définie et que:
         1. L'organisme est un Trichoptera ET que
         2. La colonne "STADIUM" n'est pas renseignée OU que
         3. La colonne "STADIUM" est renseignée avec une valeur non reconnue
         Un message de niveau WARNING est défini si la colonne "STADIUM" est définie et que
         1. L'organisme n'est PAS un Trichoptera ET que
         2. La colonne "STADIUM" est renseignée avec une valeur non reconnue

       IMPORTANT: Cette procédure doit être appelée après la validation de la systématique
        */



        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_recimportprotocolheader      importprotocolheader%ROWTYPE;
        l_syv_id_return                systvalue.syv_id%TYPE;
        l_cvl_id_zoolstadium           codevalue.cvl_id%TYPE;
        l_reclanguage                  language%ROWTYPE;
        l_reccodedesignation           codedesignation%ROWTYPE;
        l_datetxt                      VARCHAR2 (256);
        l_swisscoord                   VARCHAR2 (256);
        l_excelfield                   VARCHAR2 (256);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        IF p_importmassdatadetail.imd_syv_id IS NULL
        THEN
            -- Si l'entrée n'a pas pu être identifé on ne procède pas à la validation
            RETURN;
        END IF;

        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (
                l_recimportmassdataheader.imh_iph_id);
        -- Est-ce que la colonne "STADIUM" est définie
        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_fieldrefispresent (
                l_recimportmassdataheader.imh_iph_id,
                pkg_codevalue.cst_midatfldcmt_stadium);


        -- Si il n'y as pas de colonne STATUIN, Les valeurs "Trichoptera"  founie sont considérées comme répondans au critère "mit larvalem Köcher"
        IF l_recimportmassmappingheader.ime_id IS NULL
        THEN
            RETURN;
        END IF;

        l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
                l_recimportmassdataheader);

        l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
                l_recimportmassdataheader);
        l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;

        -- Est-ce que la colonne contient des Trichoptera
        l_syv_id_return :=
            pkg_systdesignation.f_designationisinhierarchy (
                p_importmassdatadetail.imd_syv_id,
                pkg_makroindex.cst_mki_trichoptera_crf_code,
                pkg_makroindex.cst_mki_trichoptera);

        -- Si ce n'est pas un TRICHOPTERA et que la colonne "STADIUM n'est pas renseignée on sort sans message
        IF     l_syv_id_return IS NULL
           AND p_importmassdatadetail.imd_stadium IS NULL
        THEN
            RETURN;
        END IF;

        l_reclanguage :=
            pkg_language.f_getrecord (l_recimportprotocolheader.iph_lan_id);
        -- On teste si la valeur contenue dans STADIUM est normalisé
        l_reccodedesignation :=
            pkg_codedesignation.f_findrecbycodeordesignation (
                pkg_codereference.cst_crf_zoolstadium,
                l_reclanguage.lan_code,
                p_importmassdatadetail.imd_stadium);

        IF NOT l_reccodedesignation.cdn_id IS NULL
        THEN
            pkg_importmassdatadetail.p_setcvl_id_zoostadium (
                p_importmassdatadetail.imd_id,
                l_reccodedesignation.cdn_cvl_id);
            RETURN;
        END IF;

        -- La désignation fournie n'est pas identifiée
        IF l_syv_id_return IS NULL
        THEN
            -- Ce n'est pas un Trichoptera on affiche un warning
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                pkg_exception.cst_stadiumunidentifieldwarnin,
                'IMD_STADIUM',
                p_importmassdatadetail.imd_stadium,
                TO_CHAR (p_importmassdatadetail.imd_sourceline),
                l_datetxt,
                l_swisscoord);
        ELSE
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                pkg_exception.cst_stadiumunidentifielderror,
                'IMD_STADIUM',
                p_importmassdatadetail.imd_stadium,
                TO_CHAR (p_importmassdatadetail.imd_sourceline),
                l_datetxt,
                l_swisscoord);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
        END IF;
    END;

    /*-------------------------------------------------------------------*/

    PROCEDURE p_checkmakroindex (
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_lan_id                 IN     language.lan_id%TYPE,
        p_returnstatus              OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        l_number                       NUMBER;
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_module                       VARCHAR2 (256);
        cst_exception         CONSTANT NUMBER
            := pkg_exception.cst_positivevaluerequired ;
        l_datetxt                      VARCHAR2 (256);
        l_swisscoord                   VARCHAR2 (256);
        l_excelfield                   VARCHAR2 (256);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        IF p_importmassdatadetail.imd_makroindexprovide IS NULL
        THEN
            RETURN;
        END IF;

        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);

        l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
                l_recimportmassdataheader);

        l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
                l_recimportmassdataheader);
        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                l_recimportmassdataheader.imh_iph_id,
                pkg_codevalue.cst_midatfldcmt_makroindex);

        IF l_recimportmassmappingheader.ime_id IS NULL
        THEN
            l_module :=
                   'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
                || TO_CHAR (l_recimportmassdataheader.imh_iph_id)
                || ','''
                || pkg_codevalue.cst_midatfldcmt_makroindex
                || ''')';
            pkg_importprotocollog.p_logunexpectederror (
                l_recimportmassdataheader.imh_iph_id,
                'IMD_MAKROINDEXPROVIDE',
                l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;


        l_number :=
            pkg_datatype.f_validateposinteger (
                p_importmassdatadetail.imd_makroindexprovide);

        IF l_number IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                cst_exception,
                'IMD_MAKROINDEXPROVIDE',
                p_importmassdatadetail.imd_makroindexprovide,
                'IMD_MAKROINDEXPROVIDE',
                TO_CHAR (p_importmassdatadetail.imd_sourceline),
                l_datetxt,
                l_swisscoord,
                l_excelfield);
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (cst_exception);
        END IF;

        NULL;
    END;

    /*-------------------------------------------------------------------*/

    PROCEDURE p_checkspearindex (
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_lan_id                 IN     language.lan_id%TYPE,
        p_returnstatus              OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        l_number                       NUMBER;
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_module                       VARCHAR2 (256);
        cst_exception         CONSTANT NUMBER
            := pkg_exception.cst_positivevaluerequired ;
        l_datetxt                      VARCHAR2 (256);
        l_swisscoord                   VARCHAR2 (256);
        l_excelfield                   VARCHAR2 (256);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        IF p_importmassdatadetail.imd_spearindexprovide IS NULL
        THEN
            RETURN;
        END IF;

        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);

        l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
                l_recimportmassdataheader);

        l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
                l_recimportmassdataheader);
        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                l_recimportmassdataheader.imh_iph_id,
                pkg_codevalue.cst_midatfldcmt_spearindex);

        IF l_recimportmassmappingheader.ime_id IS NULL
        THEN
            l_module :=
                   'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
                || TO_CHAR (l_recimportmassdataheader.imh_iph_id)
                || ','''
                || pkg_codevalue.cst_midatfldcmt_spearindex
                || ''')';
            pkg_importprotocollog.p_logunexpectederror (
                l_recimportmassdataheader.imh_iph_id,
                'IMD_SPEARINDEXPROVIDE',
                l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;


        l_number :=
            pkg_datatype.f_validateposdouble (
                p_importmassdatadetail.imd_spearindexprovide);

        IF l_number IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                cst_exception,
                'IMD_SPEARINDEXPROVIDE',
                p_importmassdatadetail.imd_spearindexprovide,
                'IMD_MAKROINDEXPROVIDE',
                TO_CHAR (p_importmassdatadetail.imd_sourceline),
                l_datetxt,
                l_swisscoord,
                l_excelfield);
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (cst_exception);
        END IF;

        NULL;
    END;

    /*-------------------------------------------------------------------*/

    PROCEDURE p_checkibchindex (
        p_importmassdatadetail   IN     importmassdatadetail%ROWTYPE,
        p_lan_id                 IN     language.lan_id%TYPE,
        p_returnstatus              OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        l_number                       NUMBER;
        l_recimportmassdataheader      importmassdataheader%ROWTYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_module                       VARCHAR2 (256);
        cst_exception         CONSTANT NUMBER
            := pkg_exception.cst_positivevaluerequired ;
        l_datetxt                      VARCHAR2 (256);
        l_swisscoord                   VARCHAR2 (256);
        l_excelfield                   VARCHAR2 (256);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        IF p_importmassdatadetail.imd_ibchindexprovide IS NULL
        THEN
            RETURN;
        END IF;

        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                p_importmassdatadetail.imd_imh_id);

        l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
                l_recimportmassdataheader);

        l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
                l_recimportmassdataheader);
        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                l_recimportmassdataheader.imh_iph_id,
                pkg_codevalue.cst_midatfldcmt_ibchindex);

        IF l_recimportmassmappingheader.ime_id IS NULL
        THEN
            l_module :=
                   'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
                || TO_CHAR (l_recimportmassdataheader.imh_iph_id)
                || ','''
                || pkg_codevalue.cst_midatfldcmt_ibchindex
                || ''')';
            pkg_importprotocollog.p_logunexpectederror (
                l_recimportmassdataheader.imh_iph_id,
                'IMD_IBCHINDEXPROVIDE',
                l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;


        l_number :=
            pkg_datatype.f_validateposinteger (
                p_importmassdatadetail.imd_ibchindexprovide);

        IF l_number IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_importmassdatadetail.imd_iph_id,
                p_importmassdatadetail.imd_imh_id,
                cst_exception,
                'IMD_IBCHINDEXPROVIDE',
                p_importmassdatadetail.imd_ibchindexprovide,
                'IMD_IBCHINDEXPROVIDE',
                TO_CHAR (p_importmassdatadetail.imd_sourceline),
                l_datetxt,
                l_swisscoord,
                l_excelfield);
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (cst_exception);
        END IF;

        NULL;
    END;

    /*-------------------------------------------------------------------*/

    PROCEDURE p_checkdatewindow (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
        p_returnstatus                 OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolversion        protocolversion%ROWTYPE;
        l_reccodevalue              codevalue%ROWTYPE;
        l_date                      DATE;
        l_recavaliabilitycalendar   avaliabilitycalendar%ROWTYPE;
        l_periodtype                codevalue.cvl_code%TYPE;
        l_elevation                 NUMBER;
        l_recindicetypeibch         codevalue%ROWTYPE;
        l_recindicetypespear        codevalue%ROWTYPE;
        l_returnstatus              NUMBER;
        l_jourmoislist              VARCHAR2 (1024);
        l_datetxt                   VARCHAR2 (20);
        l_datetxtdisplay            VARCHAR2 (20);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                p_recimportprotocolheader.iph_ptv_id);
        l_reccodevalue :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);

        IF l_reccodevalue.cvl_code != pkg_codevalue.cst_protocoltype_mass
        THEN
            RETURN; -- On ne test que la fenêtre de date pour le protocol de masse
        END IF;

        IF    p_recimportmassdataheader.imh_day IS NULL
           OR p_recimportmassdataheader.imh_month IS NULL
        THEN
            RETURN;
        END IF;

        IF p_recimportmassdataheader.imh_year IS NULL
        THEN
            l_datetxt :=
                   p_recimportmassdataheader.imh_day
                || '/'
                || p_recimportmassdataheader.imh_month
                || '/2000';
            l_datetxtdisplay :=
                   p_recimportmassdataheader.imh_day
                || '/'
                || p_recimportmassdataheader.imh_month
                || '/<null>';
        ELSE
            l_datetxt :=
                   p_recimportmassdataheader.imh_day
                || '/'
                || p_recimportmassdataheader.imh_month
                || p_recimportmassdataheader.imh_year;
            l_datetxtdisplay := l_datetxt;
        END IF;

        l_date := pkg_datatype.f_validatedate (l_datetxt);

        IF l_date IS NULL
        THEN
            RETURN;
        END IF;

        l_elevation :=
            pkg_datatype.f_validateswisselev (
                p_recimportmassdataheader.imh_elevation);

        IF l_elevation IS NULL
        THEN
            RETURN;
        END IF;

        l_recindicetypeibch :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_ibch);
        -- Contrôle pour le calcul de l'indice ibch
        l_periodtype :=
            pkg_avaliabilitycalendar.f_computeperiodtype (
                l_recindicetypeibch.cvl_id,
                l_date,
                l_elevation);


        IF l_periodtype = pkg_codevalue.cst_midat_window_tampon
        THEN
            pkg_avaliabilitycalendar.p_returnlistjourmoisnormal (
                l_recindicetypeibch.cvl_id,
                l_elevation,
                l_jourmoislist);

            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_midatwindowtampon,
                'IMH_DATE',
                l_datetxtdisplay,
                l_recindicetypeibch.cvl_code,
                l_jourmoislist);
            l_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_midatwindowtampon);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
            END IF;
        END IF;

        IF l_periodtype = pkg_codevalue.cst_midat_window_outer
        THEN
            pkg_avaliabilitycalendar.p_returnlistjourmoisnormal (
                l_recindicetypeibch.cvl_id,
                l_elevation,
                l_jourmoislist);

            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_midatwindowouter,
                'IMH_DATE',
                l_datetxtdisplay,
                l_recindicetypeibch.cvl_code,
                l_jourmoislist);
            l_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_midatwindowtampon);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
            END IF;
        END IF;
    END;

    /*-------------------------------------------------------------------*/

    PROCEDURE p_validealldetail (
        p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
        p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_lan_id         IN     language.lan_id%TYPE,
        p_returnstatus      OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        /* Une erreur dans lasystématique implique le rejet complet */
        CURSOR l_validheader IS
            SELECT *
              FROM importmassdataheader
             WHERE     imh_iph_id = p_iph_id
                   AND imh_validstatus != pkg_constante.cst_validstatusnotok
            FOR UPDATE;

        l_recvalidheader             l_validheader%ROWTYPE;

        -- A ce niveau, si un détail est faux, le header est faux  et ne sera pas dans la liste
        CURSOR l_detail (p_imh_id IN importmassdatadetail.imd_imh_id%TYPE)
        IS
            SELECT *
              FROM importmassdatadetail
             WHERE     imd_iph_id = p_iph_id
                   AND imd_imh_id = p_imh_id
                   AND imd_validstatus != pkg_constante.cst_validstatusnotok
            FOR UPDATE;

        l_recdetail                  l_detail%ROWTYPE;
        l_returnstatus               NUMBER;
        l_returnstatussystematique   NUMBER;
        l_returnstatusibchtaxon      NUMBER;
        l_returnstatusnotoksave      NUMBER;
        l_recordcount                NUMBER := 0;
        l_starttime                  TIMESTAMP;
        l_count                      NUMBER := 0;

        l_totalcount                 NUMBER;
        l_calculateibch              BOOLEAN := TRUE;
        l_calculatemki               BOOLEAN := TRUE;
        l_calculateok                BOOLEAN;
        l_ibchcanbecalculated        importmassdataheader.imh_ibchcanbecalculated%TYPE;
        l_mkicanbecalculated         importmassdataheader.imh_mkicanbecalculated%TYPE;
        l_spearindexcalculation      BOOLEAN;
        l_makroindexcalculation      BOOLEAN;
        l_ibchindexcalculation       BOOLEAN;
        l_mastervalid                importmassdataheader.imh_validstatus%TYPE;
        l_recimportprotocolheader    importprotocolheader%ROWTYPE;
        l_line                       VARCHAR2 (170) := RPAD (' ', 170, '-');
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        SELECT COUNT (*)
          INTO l_totalcount
          FROM importmassdatadetail
         WHERE     imd_iph_id = p_iph_id
               AND imd_imh_id IN
                       (SELECT imh_id
                          FROM importmassdataheader
                         WHERE     imh_iph_id = p_iph_id
                               AND imh_validstatus !=
                                   pkg_constante.cst_validstatusnotok);


        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);
        p_computeskipibchtaxa (l_recimportprotocolheader);


        l_starttime := SYSTIMESTAMP;
        pkg_importprotocollog.p_logstartsubprocess (
            p_iph_id,
            NULL,
            pkg_exception.cst_midatstartvalidatedetail);

        pkg_processingstatus.p_setbarstatusdisplaylimit (10);


        OPEN l_validheader;

        LOOP
            FETCH l_validheader INTO l_recvalidheader;

            EXIT WHEN l_validheader%NOTFOUND;
            pkg_importprotocollog.p_writelog (p_iph_id,
                                              l_recvalidheader.imh_id,
                                              pkg_exception.cst_info,
                                              NULL,
                                              l_line);

            pkg_importprotocollog.p_writelog (
                p_iph_id,
                l_recvalidheader.imh_id,
                pkg_exception.cst_infovalidatemassdetail,
                NULL,
                   l_recvalidheader.imh_watercourse
                || ', '
                || l_recvalidheader.imh_locality
                || ' ('
                || NVL (l_recvalidheader.imh_day, '--')
                || '/'
                || NVL (l_recvalidheader.imh_month, '--')
                || '/'
                || NVL (l_recvalidheader.imh_year, '----')
                || ')');


            l_mastervalid := pkg_constante.cst_validstatusok;


            pkg_importmassdataheader.p_returnindexcalculation (
                l_recvalidheader.imh_id,
                l_spearindexcalculation,
                l_makroindexcalculation,
                l_ibchindexcalculation);
            p_resetgblidenttaxoncounter;
            l_count := l_count + 1;
            l_calculatemki := TRUE;
            l_calculateibch := TRUE;



            OPEN l_detail (l_recvalidheader.imh_id);

            LOOP
                FETCH l_detail INTO l_recdetail;

                EXIT WHEN l_detail%NOTFOUND;
                l_recordcount := l_recordcount + 1;
                pkg_processingstatus.p_setstatusbar (l_recordcount,
                                                     l_totalcount);
                l_returnstatusnotoksave := pkg_constante.cst_returnstatusok;

                p_checksystematique (l_recdetail,
                                     l_recimportprotocolheader.iph_lan_id,
                                     l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                    l_calculateibch := FALSE;
                    l_calculatemki := FALSE;
                END IF;

                /*


                                p_checkibchtaxa (l_recimportprotocolheader,
                                                 l_recdetail,
                                                 p_lan_id,
                                                 l_returnstatus);

                                IF l_returnstatus != pkg_constante.cst_returnstatusok
                                THEN
                                    l_calculateibch := FALSE;
                                END IF;
                */



                p_checkstadium (l_recdetail,
                                l_recimportprotocolheader.iph_lan_id,
                                l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;



                p_checkfreq1 (l_recdetail,
                              l_recimportprotocolheader.iph_lan_id,
                              l_makroindexcalculation,
                              l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkfreq2 (l_recdetail,
                              l_recimportprotocolheader.iph_lan_id,
                              l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkfreqlum (l_recdetail,
                                l_recimportprotocolheader.iph_lan_id,
                                l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkstadium (l_recdetail,
                                l_recimportprotocolheader.iph_lan_id,
                                l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkmakroindex (l_recdetail,
                                   l_recimportprotocolheader.iph_lan_id,
                                   l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkspearindex (l_recdetail,
                                   l_recimportprotocolheader.iph_lan_id,
                                   l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkibchindex (l_recdetail,
                                  l_recimportprotocolheader.iph_lan_id,
                                  l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                IF l_returnstatusnotoksave = pkg_constante.cst_returnstatusok
                THEN
                    UPDATE importmassdatadetail        -- Le detail est valide
                       SET imd_validstatus = pkg_constante.cst_validstatusok
                     WHERE CURRENT OF l_detail;
                ELSE
                    UPDATE importmassdatadetail      -- Le detail est invalide
                       SET imd_validstatus =
                               pkg_constante.cst_validstatusnotok
                     WHERE CURRENT OF l_detail;

                    l_mastervalid := pkg_constante.cst_validstatusnotok;
                    l_calculateibch := FALSE;
                    l_calculatemki := FALSE;
                END IF;
            END LOOP;

            CLOSE l_detail;

            IF pkg_importmassdatadetail.f_getinvalidrowcount (
                   l_recvalidheader.imh_id) !=
               0
            THEN
                pkg_importmassdataheader.p_setvalidstatus (
                    l_recvalidheader.imh_id,
                    pkg_constante.cst_validstatusnotok);
            END IF;



            IF l_calculateibch AND l_ibchindexcalculation
            THEN
                -- Puisque l'on peut et que l'on doit calculer ibch on vérifie encore que la fenêtre de date soit ok
                p_checkdatewindow (l_recimportprotocolheader,
                                   l_recvalidheader,
                                   l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_ibchcanbecalculated := pkg_constante.cst_no;
                ELSE
                    l_ibchcanbecalculated := pkg_constante.cst_yes;
                END IF;
            ELSE
                l_ibchcanbecalculated := pkg_constante.cst_no;
            END IF;

            IF l_calculatemki AND l_makroindexcalculation
            THEN
                l_mkicanbecalculated := pkg_constante.cst_yes;
            ELSE
                l_mkicanbecalculated := pkg_constante.cst_no;
            END IF;

            IF l_mastervalid = pkg_constante.cst_validstatusok
            THEN
                -- Il doivent rester pending
                UPDATE importmassdataheader
                   SET imh_ibchcanbecalculated = l_ibchcanbecalculated,
                       imh_mkicanbecalculated = l_mkicanbecalculated
                 WHERE CURRENT OF l_validheader;

                pkg_importprotocollog.p_writelog (
                    p_iph_id,
                    l_recvalidheader.imh_id,
                    pkg_exception.cst_infovalidatemassdetailend,
                    NULL,
                       l_recvalidheader.imh_watercourse
                    || ', '
                    || l_recvalidheader.imh_locality
                    || ' ('
                    || NVL (l_recvalidheader.imh_day, '--')
                    || '/'
                    || NVL (l_recvalidheader.imh_month, '--')
                    || '/'
                    || NVL (l_recvalidheader.imh_year, '----')
                    || ')');
            ELSE
                pkg_importprotocollog.p_writelog (
                    p_iph_id,
                    l_recvalidheader.imh_id,
                    pkg_exception.cst_massheaderinvalidated,
                    NULL,
                       l_recvalidheader.imh_watercourse
                    || ', '
                    || l_recvalidheader.imh_locality
                    || ' ('
                    || NVL (l_recvalidheader.imh_day, '--')
                    || '/'
                    || NVL (l_recvalidheader.imh_month, '--')
                    || '/'
                    || NVL (l_recvalidheader.imh_year, '----')
                    || ')');



                UPDATE importmassdataheader
                   SET imh_ibchcanbecalculated = l_ibchcanbecalculated,
                       imh_mkicanbecalculated = l_mkicanbecalculated,
                       imh_validstatus = l_mastervalid
                 WHERE CURRENT OF l_validheader;
            END IF;

            pkg_importmassdataheader.p_updatetaxoncounterinfodata (
                l_recvalidheader.imh_id,
                gbl_identifiedtaxoncount,
                gbl_identifiedtaxoncountlowlev,
                gbl_identifiedtaxoncountuplev);
        END LOOP;

        pkg_importprotocollog.p_writelog (p_iph_id,
                                          l_recvalidheader.imh_id,
                                          pkg_exception.cst_info,
                                          NULL,
                                          l_line);



        CLOSE l_validheader;

        pkg_processingstatus.p_resetbarstatusdisplaylimit;

        pkg_processingsteplog.p_setmeasuredata (
            l_totalcount,
            pkg_processingsteplog.cst_measureunitrowcount);
        -- A ce niveau, tous les enregistrements de header qui n'ont pas d'erreur dans le détail reste en status valisstatuspending
        -- Il reste à les modifer en validstatusok

        pkg_importprotocollog.p_logendsubprocess (
            p_iph_id,
            NULL,
            pkg_exception.cst_midatendvalidatedetail,
            l_starttime,
            l_recordcount);

        l_recordcount :=
            pkg_importmassdataheader.f_countrowsstatuspending (p_iph_id);

        IF l_recordcount = 0
        THEN
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
        END IF;



        NULL;
    END;

    /*-------------------------------------------------------------------*/

    PROCEDURE p_validealldetailold (
        p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
        p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_lan_id         IN     language.lan_id%TYPE,
        p_returnstatus      OUT NUMBER)
    /*-------------------------------------------------------------------*/
    IS
        CURSOR l_validheader IS
            SELECT *
              FROM importmassdataheader
             WHERE     imh_iph_id = p_iph_id
                   AND imh_validstatus != pkg_constante.cst_validstatusnotok
            FOR UPDATE;

        l_recvalidheader             l_validheader%ROWTYPE;

        -- A ce niveau, si un détail est faux, le header est faux  et ne sera pas dans la liste
        CURSOR l_detail (p_imh_id IN importmassdatadetail.imd_imh_id%TYPE)
        IS
            SELECT *
              FROM importmassdatadetail
             WHERE     imd_iph_id = p_iph_id
                   AND imd_imh_id = p_imh_id
                   AND imd_validstatus != pkg_constante.cst_validstatusnotok
            FOR UPDATE;

        l_recdetail                  l_detail%ROWTYPE;
        l_returnstatus               NUMBER;
        l_returnstatussystematique   NUMBER;
        l_returnstatusibchtaxon      NUMBER;
        l_returnstatusnotoksave      NUMBER;
        l_recordcount                NUMBER := 0;
        l_starttime                  TIMESTAMP;
        l_count                      NUMBER := 0;

        l_totalcount                 NUMBER;
        l_calculateibch              BOOLEAN := TRUE;
        l_calculatemki               BOOLEAN := TRUE;
        l_calculateok                BOOLEAN;
        l_ibchcanbecalculated        importmassdataheader.imh_ibchcanbecalculated%TYPE;
        l_mkicanbecalculated         importmassdataheader.imh_mkicanbecalculated%TYPE;
        l_spearindexcalculation      BOOLEAN;
        l_makroindexcalculation      BOOLEAN;
        l_ibchindexcalculation       BOOLEAN;
        l_mastervalid                importmassdataheader.imh_validstatus%TYPE;
        l_recimportprotocolheader    importprotocolheader%ROWTYPE;
        l_line                       VARCHAR2 (170) := RPAD (' ', 170, '-');
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        SELECT COUNT (*)
          INTO l_totalcount
          FROM importmassdatadetail
         WHERE     imd_iph_id = p_iph_id
               AND imd_imh_id IN
                       (SELECT imh_id
                          FROM importmassdataheader
                         WHERE     imh_iph_id = p_iph_id
                               AND imh_validstatus !=
                                   pkg_constante.cst_validstatusnotok);


        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);
        p_computeskipibchtaxa (l_recimportprotocolheader);


        l_starttime := SYSTIMESTAMP;
        pkg_importprotocollog.p_logstartsubprocess (
            p_iph_id,
            NULL,
            pkg_exception.cst_midatstartvalidatedetail);

        pkg_processingstatus.p_setbarstatusdisplaylimit (10);


        OPEN l_validheader;

        LOOP
            FETCH l_validheader INTO l_recvalidheader;

            EXIT WHEN l_validheader%NOTFOUND;
            pkg_importprotocollog.p_writelog (p_iph_id,
                                              l_recvalidheader.imh_id,
                                              pkg_exception.cst_info,
                                              NULL,
                                              l_line);

            pkg_importprotocollog.p_writelog (
                p_iph_id,
                l_recvalidheader.imh_id,
                pkg_exception.cst_infovalidatemassdetail,
                NULL,
                   l_recvalidheader.imh_watercourse
                || ', '
                || l_recvalidheader.imh_locality
                || ' ('
                || NVL (l_recvalidheader.imh_day, '--')
                || '/'
                || NVL (l_recvalidheader.imh_month, '--')
                || '/'
                || NVL (l_recvalidheader.imh_year, '----')
                || ')');


            l_mastervalid := pkg_constante.cst_validstatusok;


            pkg_importmassdataheader.p_returnindexcalculation (
                l_recvalidheader.imh_id,
                l_spearindexcalculation,
                l_makroindexcalculation,
                l_ibchindexcalculation);
            p_resetgblidenttaxoncounter;
            l_count := l_count + 1;
            l_calculatemki := TRUE;
            l_calculateibch := TRUE;



            OPEN l_detail (l_recvalidheader.imh_id);

            LOOP
                FETCH l_detail INTO l_recdetail;

                EXIT WHEN l_detail%NOTFOUND;
                l_recordcount := l_recordcount + 1;
                pkg_processingstatus.p_setstatusbar (l_recordcount,
                                                     l_totalcount);
                l_returnstatusnotoksave := pkg_constante.cst_returnstatusok;

                p_checksystematique (l_recdetail,
                                     l_recimportprotocolheader.iph_lan_id,
                                     l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_calculatemki := FALSE;

                    IF gbl_skipibchtaxa
                    THEN
                        l_calculateibch := FALSE; -- Il n'y a pas de champ TAXON_IBCH donc aucune possibilité de calculer un indice
                    ELSE
                        p_checkibchtaxa (l_recimportprotocolheader,
                                         l_recdetail,
                                         p_lan_id,
                                         l_returnstatus);

                        IF l_returnstatus != pkg_constante.cst_returnstatusok
                        THEN
                            l_calculateibch := FALSE; -- Le champ IBCH_TAXA existe mais son contenu est invvalide
                        END IF;
                    END IF;
                END IF;


                IF NOT gbl_skipibchtaxa AND l_calculateibch -- On teste IBCH_TAXON seulement si le champ est défini
                THEN
                    p_checkibchtaxa (l_recimportprotocolheader,
                                     l_recdetail,
                                     p_lan_id,
                                     l_returnstatus);

                    IF l_returnstatus != pkg_constante.cst_returnstatusok
                    THEN
                        l_calculateibch := FALSE;
                    END IF;
                END IF;

                -- A ce niveau, si  l_calculateibch = FALSE AND  l_calculatemki = FALSE alors
                IF NOT l_calculateibch AND NOT l_calculatemki
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;



                p_checkstadium (l_recdetail,
                                l_recimportprotocolheader.iph_lan_id,
                                l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;



                p_checkfreq1 (l_recdetail,
                              l_recimportprotocolheader.iph_lan_id,
                              l_makroindexcalculation,
                              l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkfreq2 (l_recdetail,
                              l_recimportprotocolheader.iph_lan_id,
                              l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkfreqlum (l_recdetail,
                                l_recimportprotocolheader.iph_lan_id,
                                l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkstadium (l_recdetail,
                                l_recimportprotocolheader.iph_lan_id,
                                l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkmakroindex (l_recdetail,
                                   l_recimportprotocolheader.iph_lan_id,
                                   l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkspearindex (l_recdetail,
                                   l_recimportprotocolheader.iph_lan_id,
                                   l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                p_checkibchindex (l_recdetail,
                                  l_recimportprotocolheader.iph_lan_id,
                                  l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_returnstatusnotoksave := l_returnstatus;
                END IF;

                IF l_returnstatusnotoksave = pkg_constante.cst_returnstatusok
                THEN
                    UPDATE importmassdatadetail        -- Le detail est valide
                       SET imd_validstatus = pkg_constante.cst_validstatusok
                     WHERE CURRENT OF l_detail;
                ELSE
                    UPDATE importmassdatadetail      -- Le detail est invalide
                       SET imd_validstatus =
                               pkg_constante.cst_validstatusnotok
                     WHERE CURRENT OF l_detail;

                    l_mastervalid := pkg_constante.cst_validstatusnotok;
                END IF;
            END LOOP;

            CLOSE l_detail;

            IF l_calculateibch AND l_ibchindexcalculation
            THEN
                -- Puisque l'on peut et que l'on doit calculer ibch on vérifie encore que la fenêtre de date soit ok
                p_checkdatewindow (l_recimportprotocolheader,
                                   l_recvalidheader,
                                   l_returnstatus);

                IF l_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    l_ibchcanbecalculated := pkg_constante.cst_no;
                ELSE
                    l_ibchcanbecalculated := pkg_constante.cst_yes;
                END IF;
            ELSE
                l_ibchcanbecalculated := pkg_constante.cst_no;
            END IF;

            IF l_calculatemki AND l_makroindexcalculation
            THEN
                l_mkicanbecalculated := pkg_constante.cst_yes;
            ELSE
                l_mkicanbecalculated := pkg_constante.cst_no;
            END IF;

            IF l_mastervalid = pkg_constante.cst_validstatusok
            THEN
                -- Il doivent rester pending
                UPDATE importmassdataheader
                   SET imh_ibchcanbecalculated = l_ibchcanbecalculated,
                       imh_mkicanbecalculated = l_mkicanbecalculated
                 WHERE CURRENT OF l_validheader;

                pkg_importprotocollog.p_writelog (
                    p_iph_id,
                    l_recvalidheader.imh_id,
                    pkg_exception.cst_infovalidatemassdetailend,
                    NULL,
                       l_recvalidheader.imh_watercourse
                    || ', '
                    || l_recvalidheader.imh_locality
                    || ' ('
                    || NVL (l_recvalidheader.imh_day, '--')
                    || '/'
                    || NVL (l_recvalidheader.imh_month, '--')
                    || '/'
                    || NVL (l_recvalidheader.imh_year, '----')
                    || ')');
            ELSE
                pkg_importprotocollog.p_writelog (
                    p_iph_id,
                    l_recvalidheader.imh_id,
                    pkg_exception.cst_massheaderinvalidated,
                    NULL,
                       l_recvalidheader.imh_watercourse
                    || ', '
                    || l_recvalidheader.imh_locality
                    || ' ('
                    || NVL (l_recvalidheader.imh_day, '--')
                    || '/'
                    || NVL (l_recvalidheader.imh_month, '--')
                    || '/'
                    || NVL (l_recvalidheader.imh_year, '----')
                    || ')');



                UPDATE importmassdataheader
                   SET imh_ibchcanbecalculated = l_ibchcanbecalculated,
                       imh_mkicanbecalculated = l_mkicanbecalculated,
                       imh_validstatus = l_mastervalid
                 WHERE CURRENT OF l_validheader;
            END IF;

            pkg_importmassdataheader.p_updatetaxoncounterinfodata (
                l_recvalidheader.imh_id,
                gbl_identifiedtaxoncount,
                gbl_identifiedtaxoncountlowlev,
                gbl_identifiedtaxoncountuplev);
        END LOOP;

        pkg_importprotocollog.p_writelog (p_iph_id,
                                          l_recvalidheader.imh_id,
                                          pkg_exception.cst_info,
                                          NULL,
                                          l_line);



        CLOSE l_validheader;

        pkg_processingstatus.p_resetbarstatusdisplaylimit;

        pkg_processingsteplog.p_setmeasuredata (
            l_totalcount,
            pkg_processingsteplog.cst_measureunitrowcount);
        -- A ce niveau, tous les enregistrements de header qui n'ont pas d'erreur dans le détail reste en status valisstatuspending
        -- Il reste à les modifer en validstatusok

        pkg_importprotocollog.p_logendsubprocess (
            p_iph_id,
            NULL,
            pkg_exception.cst_midatendvalidatedetail,
            l_starttime,
            l_recordcount);

        l_recordcount :=
            pkg_importmassdataheader.f_countrowsstatuspending (p_iph_id);

        IF l_recordcount = 0
        THEN
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
        END IF;



        NULL;
    END;
END;
/

