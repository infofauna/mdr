create PACKAGE       pkg_migr_ibch2019_util
AS
    /******************************************************************************
      NAME:       PKG_MIGR_IBCH2019_UTIL
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       15.05.2020  F.Burri           1. Created this package
   ******************************************************************************/
    TYPE t_cursor IS REF CURSOR;

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, mai 2020';

    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_checkconstraintexist (
        p_table_name        IN user_constraints.table_name%TYPE,
        p_constraint_name   IN user_constraints.constraint_name%TYPE)
        RETURN NUMBER;

    FUNCTION f_checktableexist (p_table_name IN user_tables.table_name%TYPE)
        RETURN NUMBER;

    FUNCTION f_checkcolumnexist (
        p_table_name   IN user_tab_columns.table_name%TYPE,
        p_column       IN user_tab_columns.column_name%TYPE)
        RETURN user_tab_columns%ROWTYPE;

    PROCEDURE p_addcolumn (p_table_name   IN     VARCHAR2,
                           p_name         IN     VARCHAR2,
                           p_type         IN     VARCHAR2,
                           p_constraint   IN     VARCHAR2,
                           p_done            OUT BOOLEAN);

    PROCEDURE p_createsequence (
        p_name        IN user_sequences.sequence_name%TYPE,
        p_startwith   IN NUMBER,
        p_maxvalue    IN NUMBER);

    PROCEDURE p_recreatesequence (
        p_table_name   IN VARCHAR2,
        p_seq_name     IN user_sequences.sequence_name%TYPE,
        p_name_id      IN VARCHAR2);

    PROCEDURE p_compilepackage (p_package IN VARCHAR2);
END pkg_migr_ibch2019_util;
/

