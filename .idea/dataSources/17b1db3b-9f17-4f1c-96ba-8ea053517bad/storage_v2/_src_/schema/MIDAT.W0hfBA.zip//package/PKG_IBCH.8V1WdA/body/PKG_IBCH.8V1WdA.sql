create PACKAGE BODY       pkg_ibch
AS
    /******************************************************************************
       NAME:       PKG_IBCH
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        08.07.2015      burrif       1. Created this package.
       1.1        24.09.2019      burrif       2. Cas particulier
       1.2        23.01.2020      burrif       3. Externalisation de compteurs
    ******************************************************************************/



    cst_packageversion      CONSTANT VARCHAR2 (30)
                                         := 'Version 1.2, janvier  2020' ;
    cst_maxvalue            CONSTANT NUMBER := 999999999;
    cst_gi_undef            CONSTANT NUMBER := -999999;

    gbl_ibchsomme_vt                 NUMBER := 0;
    gbl_ibch_vt                      NUMBER := 0;
    gbl_ibch_gi                      NUMBER := 0;
    gbl_ibchidentifiedtaxoncounter   NUMBER := 0;
    gbl_ibchvalue                    NUMBER := -1;
    gbl_listibchvalue                t_listibchvalue := t_listibchvalue ();
    gbl_listibchvalue_base           t_listibchvalue := t_listibchvalue ();
    gbl_listibchvaluemass            t_listibchvaluemass
                                         := t_listibchvaluemass ();
    gbl_count_neozoa                 NUMBER := 0;
    gbl_count_ephemeroptera          NUMBER := 0;
    gbl_count_plecoptera             NUMBER := 0;
    gbl_count_tricoptera             NUMBER := 0;
    gbl_taxon_indicateur             VARCHAR2 (1024);
    gbl_count_taxonloaded            NUMBER := 0;
    gbl_count_distincttaxon          NUMBER := 0;

    cst_notfound            CONSTANT PLS_INTEGER := -1;

    gbl_specialcase                  BOOLEAN := FALSE;
    gbl_listtaxonindicateur          t_listtaxonindicateur
                                         := t_listtaxonindicateur ();

    gbl_writelog                     BOOLEAN := FALSE;

    gbl_append_counter               NUMBER := 0;


    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_getgbl_ibchvalue
        RETURN NUMBER
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_ibchvalue;
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_getgbl_count_ephemeroptera
        RETURN NUMBER
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_count_ephemeroptera;
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_getgbl_count_plecoptera
        RETURN NUMBER
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_count_plecoptera;
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_getgbl_count_trichoptera
        RETURN NUMBER
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_count_tricoptera;
    END;



    /*--------------------------------------------------------------*/
    FUNCTION f_getgbl_taxon_indicateur
        RETURN VARCHAR2
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_taxon_indicateur;
    END;


    /*--------------------------------------------------------------*/
    PROCEDURE p_displaylistibchvalue
    /*--------------------------------------------------------------*/
    IS
        l_indice                   PLS_INTEGER;
        l_reclanguage              language%ROWTYPE;
        l_designation              VARCHAR2 (4096);
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        l_reclanguage :=
            pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);
        l_indice := gbl_listibchvalue.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (
                    gbl_listibchvalue (l_indice).ibc_ptl_id);

            l_designation :=
                pkg_systdesignation.f_returnpathdesignation (
                    l_recprotocolmappinglabo.ptl_syv_id,
                    l_reclanguage.lan_id,
                    '/');
            pkg_debug.p_write (
                'PKG_IBCH.p_DISPLAYlistibchvalue',
                   'l_indice='
                || l_indice
                || 'l_recprotocolmappinglabo.ptl_id='
                || l_recprotocolmappinglabo.ptl_id
                || 'l_recprotocolmappinglabo.ptl_syv_id='
                || l_recprotocolmappinglabo.ptl_syv_id
                || ' '
                || l_designation
                || ' Count: '
                || gbl_listibchvalue (l_indice).ibc_counter);
            l_indice := gbl_listibchvalue.NEXT (l_indice);
        END LOOP;

        NULL;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_setwritelog (p_writelog IN BOOLEAN)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        gbl_writelog := p_writelog;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getgbllistibchvalue
        RETURN t_listibchvalue
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_listibchvalue;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getgbllistibchvalue_base
        RETURN t_listibchvalue
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_listibchvalue_base;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getgbllistibchvaluemass
        RETURN t_listibchvaluemass
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_listibchvaluemass;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getgbllisttaxonindicateur
        RETURN t_listtaxonindicateur
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_listtaxonindicateur;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_returncounttaxonloaded
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_count_taxonloaded;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_returncountdistincttaxon
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_count_distincttaxon;
    END;


    /*----------------------------------------------------------------*/
    FUNCTION f_returnspecialcase
        RETURN VARCHAR2
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        IF gbl_count_taxonloaded != 0 AND gbl_count_distincttaxon != 0
        THEN
            IF gbl_count_taxonloaded != gbl_count_distincttaxon
            THEN
                RETURN pkg_constante.cst_yes;
            ELSE
                RETURN pkg_constante.cst_no;
            END IF;
        ELSE
            RETURN NULL;
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_test (p_iph_id   IN importprotocolheader.iph_id%TYPE,
                      p_imh_id   IN importmassdataheader.imh_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
        CURSOR l_massdatadetail (
            p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
        IS
            SELECT *
              FROM importmassdatadetail
             WHERE     imd_imh_id = p_imh_id
                   AND imd_validstatus = pkg_constante.cst_validstatusok; -- A ce stade, tout doit être contrôler et le status doit être valide

        l_recmassdatadetail            l_massdatadetail%ROWTYPE;
        l_countexclude                 NUMBER;
        l_firstfieldvalue              importmassdatadetail.imd_species%TYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_recimportprotocolheader      importprotocolheader%ROWTYPE;
        l_reccodevalue                 codevalue%ROWTYPE;
        l_recprotocolversion           protocolversion%ROWTYPE;
        l_ptv_id                       protocolversion.ptv_id%TYPE;
        l_abondanceflag                codevalue.cvl_code%TYPE;
        l_ibchindice                   NUMBER;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);
        l_ptv_id := l_recimportprotocolheader.iph_ptv_id;
        l_recprotocolversion := pkg_protocolversion.f_getrecord (l_ptv_id);

        l_reccodevalue :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);

        IF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_mass
        THEN
            l_abondanceflag := cst_abondanceflag_absolu;
        ELSE                                      -- Pas un protocole de masse
            IF NOT l_recimportprotocolheader.iph_absolutenumberflag IS NULL
            THEN
                l_abondanceflag := cst_abondanceflag_absolu;
            ELSE
                l_abondanceflag := cst_abondanceflag_class;
            END IF;
        END IF;


        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                p_iph_id,
                pkg_codevalue.cst_midatfldcmt_taxonibch);

        IF NOT l_recimportmassmappingheader.ime_id IS NULL
        THEN
            -- La colonne IBCH a été définie dans le protocole de masse
            p_ibchinit;

            OPEN l_massdatadetail (p_imh_id);

            LOOP
                FETCH l_massdatadetail INTO l_recmassdatadetail;

                EXIT WHEN l_massdatadetail%NOTFOUND;
                p_ibchadddata (l_recmassdatadetail.imd_ptl_id,
                               l_recmassdatadetail.imd_freq1);

                IF NOT l_recmassdatadetail.imd_ptl_id IS NULL
                THEN
                    gbl_ibchidentifiedtaxoncounter :=
                        gbl_ibchidentifiedtaxoncounter + 1;
                END IF;
            END LOOP;

            CLOSE l_massdatadetail;
        ELSE                            -- La colonne IBCH n'a pas été définie
            -- Pour charger les données nécessaire au calcul de l'IBCH on doit relire le détail

            p_initlistibchvaluemass;

            -- Pour charger les données nécessaire au calcul de l'IBCH on doit relire le détail
            OPEN l_massdatadetail (p_imh_id);

            LOOP
                FETCH l_massdatadetail INTO l_recmassdatadetail;

                EXIT WHEN l_massdatadetail%NOTFOUND;
                p_addlistibchvaluemass (l_recmassdatadetail.imd_syv_id,
                                        l_recmassdatadetail.imd_freq1);
                gbl_ibchidentifiedtaxoncounter :=
                    gbl_ibchidentifiedtaxoncounter + 1;
            END LOOP;

            CLOSE l_massdatadetail;

            p_convertmass2ibch (l_recimportprotocolheader.iph_ptv_id,
                                l_recimportprotocolheader.iph_id,
                                p_imh_id);
        END IF;

        IF NOT l_recimportprotocolheader.iph_absolutenumberflag IS NULL
        THEN
            l_abondanceflag := cst_abondanceflag_absolu;
        ELSE
            l_abondanceflag := cst_abondanceflag_class;
        END IF;



        l_ibchindice := f_computeibchfrommemory (l_abondanceflag);
        DBMS_OUTPUT.put_line ('l_ibchindice=' || l_ibchindice);
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_getgbl_ibchsomme_vt
        RETURN NUMBER
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_ibchsomme_vt;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_getgblibchvt
        RETURN NUMBER
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_ibch_vt;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_getgblibchgi
        RETURN NUMBER
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_ibch_gi;
    END;


    /*---------------------------------------------------------------*/
    FUNCTION f_getgblibchidentifiedtaxoncou
        RETURN NUMBER
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_ibchidentifiedtaxoncounter;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_initlistibchvaluemass
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        gbl_ibchidentifiedtaxoncounter := 0;
        gbl_listibchvaluemass.delete;
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_ibchinit
    /*------------------------------------------------------------*/
    IS
    BEGIN
        gbl_listibchvalue.delete;
        gbl_ibch_vt := 0;
        gbl_ibch_gi := 0;
        gbl_ibchidentifiedtaxoncounter := 0;
        gbl_count_taxonloaded := 0;
        gbl_append_counter := 0;
        gbl_count_distincttaxon := 0;
        gbl_count_ephemeroptera := 0;
        gbl_count_plecoptera := 0;
        gbl_count_tricoptera := 0;
        gbl_ibchsomme_vt := 0;
    END;

    /*-------------------------------------------------------------*/
    FUNCTION f_istaxoninreflist (
        p_ptl_id   IN protocolmappinglabo.ptl_id%TYPE,
        p_taxon       systdesignation.syd_designation%TYPE)
        RETURN NUMBER
    /*------------------------------------------------------------*/
    /* permet de déterminer si le taxon défini par PTL_ID est dans la hiérarchie
       d'un des taxons à comptabiliser:

        EPHEMEROPTERA
        PLECOPTERA
        TRICHOPTERA
     */



    IS
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_recsystdesignation       systdesignation%ROWTYPE;

        l_recsystvalue             systvalue%ROWTYPE;
    BEGIN
        l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecord (p_ptl_id);


        l_recsystdesignation :=
            pkg_systdesignation.f_getrecordbydesignationcode (
                p_taxon,
                pkg_language.cst_lan_cde_latin);

        IF l_recsystdesignation.syd_id IS NULL
        THEN
            raise_application_error (
                -20000,
                   'Désignation '
                || p_taxon
                || ' non trouvée dans le référentiel CSCF',
                TRUE);
        END IF;

        l_recsystvalue :=
            pkg_systvalue.f_getrecordathierarchy (
                l_recprotocolmappinglabo.ptl_syv_id,
                l_recsystdesignation.syd_syv_id);

        IF l_recsystvalue.syv_id IS NULL
        THEN
            RETURN 0;
        ELSE
            pkg_debug.p_write (
                'PKG_IBCH.f_taxoninreflist',
                   'l_recsystdesignation.syd_syv_id='
                || l_recsystdesignation.syd_syv_id||','||l_recsystdesignation.syd_designation);
            RETURN 1;
        END IF;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_computereftaxon
    /*-------------------------------------------------------------*/
    IS
        /* Les données sont dans  gbl_listibchvalue
        */
        cst_ephemeroptera   CONSTANT systdesignation.syd_designation%TYPE
                                         := 'EPHEMEROPTERA' ;
        cst_plecoptera      CONSTANT systdesignation.syd_designation%TYPE
                                         := 'PLECOPTERA' ;
        cst_tricoptera      CONSTANT systdesignation.syd_designation%TYPE
                                         := 'TRICHOPTERA' ;

        l_indice                     PLS_INTEGER;
        l_syv_id                     NUMBER;
    BEGIN
        l_indice := gbl_listibchvalue_base.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            gbl_count_ephemeroptera :=
                  gbl_count_ephemeroptera
                + f_istaxoninreflist (
                      gbl_listibchvalue_base (l_indice).ibc_ptl_id,
                      cst_ephemeroptera);
            gbl_count_plecoptera :=
                  gbl_count_plecoptera
                + f_istaxoninreflist (
                      gbl_listibchvalue_base (l_indice).ibc_ptl_id,
                      cst_plecoptera);
            gbl_count_tricoptera :=
                  gbl_count_tricoptera
                + f_istaxoninreflist (
                      gbl_listibchvalue_base (l_indice).ibc_ptl_id,
                      cst_tricoptera);



            l_indice := gbl_listibchvalue_base.NEXT (l_indice);
        END LOOP;
    END;



    /*--------------------------------------------------------------*/
    FUNCTION f_findonlistibchvaluemass (p_syv_id IN systvalue.syv_id%TYPE)
        RETURN PLS_INTEGER
    /*-------------------------------------------------------------*/
    /* Retourne la valeur de l'indice qui contient la valeur p_syv_id.
       Si rien n'est trouvé la valeur -1 est retoruné
    */
    IS
        l_indice   PLS_INTEGER;
        l_found    PLS_INTEGER := cst_notfound;
    BEGIN
        l_indice := gbl_listibchvaluemass.FIRST;

        WHILE NOT l_indice IS NULL AND l_found = cst_notfound
        LOOP
            IF gbl_listibchvaluemass (gbl_listibchvaluemass.LAST).ibm_syv_id =
               p_syv_id
            THEN
                l_found := l_indice;
            END IF;

            l_indice := gbl_listibchvaluemass.NEXT (l_indice);
        END LOOP;

        RETURN l_found;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_addlistibchvaluemass (p_syv_id   IN systvalue.syv_id%TYPE,
                                      p_count       NUMBER)
    /*--------------------------------------------------------------*/
    IS
        l_found   PLS_INTEGER;
    BEGIN
        pkg_debug.p_write ('PKG_IBCH.p_addlistibchvaluemass',
                           'p_syv_id=' || p_syv_id || ' p_count=' || p_count);
        gbl_count_taxonloaded := gbl_count_taxonloaded + 1;
        l_found := f_findonlistibchvaluemass (p_syv_id);

        IF l_found = cst_notfound
        THEN
            gbl_listibchvaluemass.EXTEND (1);
            -- Si p_syv_id est un synomyme on va chercher le parent

            gbl_listibchvaluemass (gbl_listibchvaluemass.LAST).ibm_syv_id :=
                p_syv_id;
            gbl_listibchvaluemass (gbl_listibchvaluemass.LAST).ibm_counter :=
                p_count;
            gbl_listibchvaluemass (gbl_listibchvaluemass.LAST).ibm_nbroccurence :=
                1;
        ELSE
            -- On cumule (modification du 24.09.2019)
            gbl_listibchvaluemass (l_found).ibm_counter :=
                gbl_listibchvaluemass (l_found).ibm_counter + p_count;
            gbl_listibchvaluemass (l_found).ibm_nbroccurence :=
                gbl_listibchvaluemass (l_found).ibm_nbroccurence + 1;
        END IF;
    END;



    /*------------------------------------------------------------*/
    PROCEDURE p_ibchadddata (
        p_ptl_id   IN sampleprotocollabo.spl_ptl_id%TYPE,
        p_count    IN sampleprotocollabo.spl_frequency%TYPE)
    /*-----------------------------------------------------------*/
    IS
        l_indice        PLS_INTEGER;
        l_indicefound   PLS_INTEGER;
    BEGIN
        IF p_ptl_id IS NULL
        THEN
            RETURN;
        END IF;

        gbl_count_taxonloaded := gbl_count_taxonloaded + 1;
        l_indicefound := -1;
        l_indice := gbl_listibchvalue.FIRST;

        WHILE NOT l_indice IS NULL AND l_indicefound = -1
        LOOP
            IF gbl_listibchvalue (l_indice).ibc_ptl_id = p_ptl_id
            THEN                      -- L'entrée existe déjà, on doit cumuler
                l_indicefound := l_indice;
            END IF;

            l_indice := gbl_listibchvalue.NEXT (l_indice);
        END LOOP;

        IF l_indicefound = -1
        THEN
            pkg_debug.p_write ('PKG_IBCH.p_ibchadddata',
                               'Non trouvé ptl_id=' || p_ptl_id);
            gbl_listibchvalue.EXTEND (1);
            gbl_listibchvalue (gbl_listibchvalue.LAST).ibc_ptl_id := p_ptl_id;
            gbl_listibchvalue (gbl_listibchvalue.LAST).ibc_counter := p_count;
            gbl_listibchvalue (gbl_listibchvalue.LAST).ibc_nbroccurence := 1;
        ELSE
            pkg_debug.p_write ('PKG_IBCH.p_ibchadddata',
                               'Trouvé ptl_id=' || p_ptl_id);
            gbl_listibchvalue (l_indicefound).ibc_counter :=
                gbl_listibchvalue (l_indicefound).ibc_counter + p_count;
            gbl_listibchvalue (l_indicefound).ibc_nbroccurence :=
                gbl_listibchvalue (l_indicefound).ibc_nbroccurence + 1;
        END IF;

        NULL;
    END;

    /*-----------------------------------------------------------------*/

    PROCEDURE p_convertmass2ibch (
        p_ptv_id   IN protocolversion.ptv_id%TYPE,
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_imh_id   IN importmassdataheader.imh_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
        l_indice                   PLS_INTEGER;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_recsystdesignation       systdesignation%ROWTYPE;
        l_reclanguage              language%ROWTYPE;
        l_recprotocolversion       protocolversion%ROWTYPE;
        l_textemapping             VARCHAR2 (1024);
        l_counter                  NUMBER;
    BEGIN
        p_ibchinit;
        l_reclanguage :=
            pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);
        l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);
        l_counter := 0;
        l_indice := gbl_listibchvaluemass.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            l_recsystdesignation :=
                pkg_systdesignation.f_getrecorddesignation (
                    gbl_listibchvaluemass (l_indice).ibm_syv_id,
                    l_reclanguage.lan_id);
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_identifyentrybyhierarchy (
                    gbl_listibchvaluemass (l_indice).ibm_syv_id,
                    l_recprotocolversion.ptv_ptv_id_labofrommass);

            IF l_recprotocolmappinglabo.ptl_id IS NULL
            THEN
                l_textemapping :=
                       l_recsystdesignation.syd_designation
                    || ' -> ('
                    || pkg_codevalue.cst_midatindice_ibch
                    || ') ? ';
            ELSE
                l_textemapping :=
                       l_recsystdesignation.syd_designation
                    || ' -> ('
                    || pkg_codevalue.cst_midatindice_ibch
                    || ') '
                    || l_recprotocolmappinglabo.ptl_taxa;


                p_ibchadddata (l_recprotocolmappinglabo.ptl_id,
                               gbl_listibchvaluemass (l_indice).ibm_counter);
                gbl_ibchidentifiedtaxoncounter :=
                    gbl_ibchidentifiedtaxoncounter + 1;
            END IF;

            l_counter := l_counter + 1;
            DBMS_OUTPUT.put_line (l_textemapping);

            IF gbl_writelog
            THEN
                pkg_importprotocollog.p_writelog (
                    p_iph_id,
                    NULL,
                    pkg_exception.cst_info,
                    NULL,
                    TO_CHAR (l_counter) || '. ' || l_textemapping);
            END IF;

            l_indice := gbl_listibchvaluemass.NEXT (l_indice);
        END LOOP;

        NULL;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_convertmass2ibch (p_ptv_id IN protocolversion.ptv_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
        l_indice                   PLS_INTEGER;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_recsystdesignation       systdesignation%ROWTYPE;
        l_reclanguage              language%ROWTYPE;
        l_recprotocolversion       protocolversion%ROWTYPE;
        l_textemapping             VARCHAR2 (1024);
        l_counter                  NUMBER;
    BEGIN
        --   p_ibchinit;
        l_reclanguage :=
            pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);
        l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);
        l_counter := 0;
        l_indice := gbl_listibchvaluemass.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            l_recsystdesignation :=
                pkg_systdesignation.f_getrecorddesignation (
                    gbl_listibchvaluemass (l_indice).ibm_syv_id,
                    l_reclanguage.lan_id);
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_identifyentrybyhierarchy (
                    gbl_listibchvaluemass (l_indice).ibm_syv_id,
                    l_recprotocolversion.ptv_ptv_id_labofrommass);
            p_ibchadddata (l_recprotocolmappinglabo.ptl_id,
                           gbl_listibchvaluemass (l_indice).ibm_counter);
            gbl_ibchidentifiedtaxoncounter :=
                gbl_ibchidentifiedtaxoncounter + 1;
            l_counter := l_counter + 1;
            l_indice := gbl_listibchvaluemass.NEXT (l_indice);
        END LOOP;

        NULL;
    END;

    /*------------------------------------------------------------*/
    FUNCTION f_ibchreturnclassevariete (p_sommevt IN NUMBER)
        RETURN NUMBER
    /*------------------------------------------------------------*/
    /* Tableau 6, page 30 :http://www.sib.admin.ch/uploads/media/UV-1026-F_01.pdf
    */
    IS
        l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
    BEGIN
        l_recabundanceclassrange :=
            pkg_abundanceclassrange.f_getrecordbyindiceandvalue (
                pkg_codevalue.cst_midatindice_ibch,
                p_sommevt);
        RETURN l_recabundanceclassrange.acr_classe;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_normaliseabondance (p_value           IN NUMBER,
                                   p_abondanceflag   IN VARCHAR2)
        RETURN NUMBER
    /*-----------------------------------------------------------*/
    IS
        /* Selon commentaire dans le feuille "protocole de laboratoire"
            les abondances entre
              1 et 10 sont des nombres absolu
              11 et 100 => 11
              101 et 1000 => 101
              > 1000 => 1001

              Si p_abondanceflag= cst_abondanceflag_absolu  alors toute les valeurs sont en absolue
           */



        l_value   NUMBER;
    BEGIN
        IF NVL (p_abondanceflag, cst_abondanceflag_class) =
           cst_abondanceflag_absolu
        THEN
            RETURN p_value;
        END IF;

        -- Selon des classes
        CASE
            WHEN p_value >= 0 AND p_value <= 10
            THEN
                l_value := p_value;
            WHEN p_value >= 11 AND p_value <= 100
            THEN
                l_value := 11;
            WHEN p_value >= 101 AND p_value <= 1000
            THEN
                l_value := 101;
            WHEN p_value > 1000
            THEN
                l_value := 1001;
            ELSE
                l_value := NULL;
        END CASE;

        RETURN l_value;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_buildlisttaxonindicateur (p_abondanceflag IN VARCHAR2)
    /*----------------------------------------------------------------*/
    IS
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_indice                   PLS_INTEGER;
        l_error                    BOOLEAN := FALSE;
        l_value                    NUMBER;
    BEGIN
        gbl_listtaxonindicateur.delete ();
        l_indice := gbl_listibchvalue.FIRST;
        gbl_taxon_indicateur := NULL;

        WHILE NOT l_indice IS NULL AND NOT l_error
        LOOP
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (
                    gbl_listibchvalue (l_indice).ibc_ptl_id);

            IF l_recprotocolmappinglabo.ptl_id IS NULL
            THEN
                l_error := TRUE;
            ELSE
                l_value :=
                    f_normaliseabondance (
                        gbl_listibchvalue (l_indice).ibc_counter,
                        p_abondanceflag);


                IF l_value >=
                   NVL (l_recprotocolmappinglabo.ptl_ibchindividumin,
                        cst_maxvalue)
                THEN
                    IF NVL (l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi,
                            -1) =
                       gbl_ibch_gi
                    THEN --  Le  groupe GI avec l'indice le plus grand est déterminant
                        gbl_listtaxonindicateur.EXTEND (1);
                        gbl_listtaxonindicateur (
                            gbl_listtaxonindicateur.LAST) :=
                            gbl_listibchvalue (l_indice).ibc_ptl_id;

                        IF gbl_taxon_indicateur IS NULL
                        THEN
                            gbl_taxon_indicateur :=
                                l_recprotocolmappinglabo.ptl_taxa;
                        ELSE
                            gbl_taxon_indicateur :=
                                   gbl_taxon_indicateur
                                || ', '
                                || l_recprotocolmappinglabo.ptl_taxa;
                        END IF;
                    END IF;
                END IF;
            END IF;

            l_indice := gbl_listibchvalue.NEXT (l_indice);
        END LOOP;

        NULL;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_computeibchfrommemory (p_abondanceflag IN VARCHAR2)
        RETURN NUMBER
    /*----------------------------------------------------------------*/
    IS
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_error                    BOOLEAN := FALSE;
        l_ibchindice               NUMBER;
        l_sommevt                  NUMBER; -- Variété taxonimique: Nombre de taxon (nombre de ligne renseigné)
        l_classevt                 NUMBER; -- Classe découlant de la variété taxonomique
        l_ibch                     NUMBER;
        l_indice                   PLS_INTEGER;
        l_value                    NUMBER;
        l_gi_max                   NUMBER := cst_gi_undef;
    BEGIN
        p_displaylistibchvalue;
        l_gi_max := cst_gi_undef;

        l_sommevt := gbl_listibchvalue_base.COUNT;
        gbl_ibchsomme_vt := l_sommevt;
        pkg_debug.p_write ('pkg_IBCH.f_computeibchfrommemory',
                           'l_sommevt=' || l_sommevt);
        gbl_count_distincttaxon := gbl_listibchvalue.COUNT;


        l_classevt := f_ibchreturnclassevariete (l_sommevt);

        -- Calcul du groupe faunistique indicateur (GI)
        l_indice := gbl_listibchvalue.FIRST;
        pkg_debug.p_write (
            'PKG_IBCH.f_computeibchfrommemory',
            'gbl_listibchvalue.coun=' || gbl_listibchvalue.COUNT);

        WHILE NOT l_indice IS NULL AND NOT l_error
        LOOP
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (
                    gbl_listibchvalue (l_indice).ibc_ptl_id);

            IF l_recprotocolmappinglabo.ptl_id IS NULL
            THEN
                l_error := TRUE;
            ELSE
                l_value :=
                    f_normaliseabondance (
                        gbl_listibchvalue (l_indice).ibc_counter,
                        p_abondanceflag);


                IF l_value >=
                   NVL (l_recprotocolmappinglabo.ptl_ibchindividumin,
                        cst_maxvalue)
                THEN
                    IF NVL (l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi,
                            -1) >
                       l_gi_max
                    THEN --  Le  groupe GI avec l'indice le plus grand est déterminant
                        l_gi_max :=
                            l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi;
                    END IF;
                END IF;
            END IF;

            l_indice := gbl_listibchvalue.NEXT (l_indice);
        END LOOP;

        IF l_error
        THEN
            RETURN NULL;
        END IF;



        IF l_gi_max < 0
        THEN
            --    l_ibch := l_classevt - 1;
            l_ibch := 0;                           -- Email de PS du 7.04.2015
            l_gi_max := NULL;
        ELSE
            l_ibch := l_gi_max + l_classevt - 1;
        END IF;

        IF l_ibch > 20
        THEN
            l_ibch := 20;
        END IF;


        gbl_ibch_vt := l_classevt;
        gbl_ibch_gi := l_gi_max;
        p_buildlisttaxonindicateur (p_abondanceflag);
        gbl_ibchvalue := l_ibch;
        p_computereftaxon;

        RETURN l_ibch;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_findonlistibchvalue (
        p_listibchvalue   IN t_listibchvalue,
        p_ptl_id          IN protocolmappinglabo.ptl_id%TYPE)
        RETURN PLS_INTEGER
    /*----------------------------------------------------------------*/
    IS
        l_indice        PLS_INTEGER;
        l_foundindice   NUMBER := 0;
    BEGIN
        l_indice := p_listibchvalue.FIRST;

        WHILE NOT l_indice IS NULL AND l_foundindice = 0
        LOOP
            IF p_listibchvalue (l_indice).ibc_ptl_id = p_ptl_id
            THEN
                l_foundindice := l_indice;
            ELSE
                l_indice := p_listibchvalue.NEXT (l_indice);
            END IF;
        END LOOP;

        RETURN l_indice;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_addcounter (
        p_ptl_id          IN     protocolmappinglabo.ptl_id%TYPE,
        p_counter         IN     NUMBER,
        l_listibchvalue   IN OUT t_listibchvalue)
    /*----------------------------------------------------------------*/
    IS
        l_indicefound   PLS_INTEGER;
    BEGIN
        l_indicefound := f_findonlistibchvalue (l_listibchvalue, p_ptl_id);
        l_listibchvalue (l_indicefound).ibc_counter :=
            l_listibchvalue (l_indicefound).ibc_counter + p_counter;
        l_listibchvalue (l_indicefound).ibc_nbroccurence :=
            l_listibchvalue (l_indicefound).ibc_nbroccurence + 1;
        NULL;
    END;



    /*-----------------------------------------------------------------*/
    PROCEDURE p_completewithparent (p_ptv_id IN protocolversion.ptv_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
        /* On complete la lsite des taxons avec les parents de la même hiérarchie
       */
        cst_iteratemax          CONSTANT PLS_INTEGER := 3;
        l_indice                         PLS_INTEGER;
        l_recprotocolmappinglabo         protocolmappinglabo%ROWTYPE;
        l_recprotocolmappinglaboparent   protocolmappinglabo%ROWTYPE;
        l_recsystvalue                   systvalue%ROWTYPE;
        l_recprotocolversion             protocolversion%ROWTYPE;
        l_listibchvalue                  t_listibchvalue
                                             := t_listibchvalue ();
        l_foundindice                    PLS_INTEGER;
        l_recsystdesignation             systdesignation%ROWTYPE;
        l_recsystdesignationparent       systdesignation%ROWTYPE;
        l_iterate                        PLS_INTEGER := 0;
        l_cumul                          NUMBER;
    BEGIN
        -- RETURN;
        gbl_listibchvalue_base := gbl_listibchvalue;
        l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);
        l_indice := gbl_listibchvalue.FIRST;


        WHILE NOT l_indice IS NULL
        LOOP
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (
                    gbl_listibchvalue (l_indice).ibc_ptl_id);

            /*
      l_recsystvalue :=
         pkg_systvalue.f_getrecord (l_recprotocolmappinglabo.ptl_syv_id);
      l_recsystdesignation :=
         pkg_systdesignation.f_getrecdesignationbylancode (
            l_recsystvalue.syv_id,
            pkg_language.cst_lan_cde_latin);
      l_recsystdesignationparent :=
         pkg_systdesignation.f_getrecdesignationbylancode (
            l_recsystvalue.syv_syv_id,
            pkg_language.cst_lan_cde_latin);
      pkg_debug.p_write (
         'PKG_IBCH.p_completewithparent',
            'l_recsystvalue.syv_id :'
         || l_recsystvalue.syv_id
         || ' '
         || l_recsystdesignation.syd_designation
         || 'l_recsystvalue.syv_syv_id :'
         || l_recsystvalue.syv_syv_id
         || ' '
         || l_recsystdesignationparent.syd_designation);

      l_recprotocolmappinglaboparent :=
         pkg_protocolmappinglabo.f_identifyentrybyhierarchy (
            l_recsystvalue.syv_syv_id,
            l_recprotocolversion.ptv_ptv_id_labofrommass); */



            l_recprotocolmappinglaboparent :=
                pkg_protocolmappinglabo.f_getrecord (
                    l_recprotocolmappinglabo.ptl_ptl_id);

            l_cumul := gbl_listibchvalue (l_indice).ibc_counter;
            pkg_debug.p_write (
                'PKG_IBCH.p_completewithparent',
                   'BASE :'
                || l_recprotocolmappinglabo.ptl_id
                || ' '
                || l_recprotocolmappinglabo.ptl_taxa
                || ' Counter: '
                || gbl_listibchvalue (l_indice).ibc_counter);

            WHILE NOT l_recprotocolmappinglaboparent.ptl_id IS NULL
            LOOP
                l_foundindice :=
                    f_findonlistibchvalue (
                        l_listibchvalue,
                        l_recprotocolmappinglaboparent.ptl_id);

                IF l_foundindice IS NULL
                THEN
                    gbl_append_counter := gbl_append_counter + 1;
                    pkg_debug.p_write (
                        'PKG_IBCH.p_completewithparent',
                           'NEW PARENT :'
                        || l_recprotocolmappinglaboparent.ptl_id
                        || ' '
                        || l_recprotocolmappinglaboparent.ptl_taxa
                        || ' count: '
                        || gbl_listibchvalue (l_indice).ibc_counter);
                    l_listibchvalue.EXTEND (1);
                    l_listibchvalue (l_listibchvalue.LAST).ibc_counter :=
                        gbl_listibchvalue (l_indice).ibc_counter;
                    l_listibchvalue (l_listibchvalue.LAST).ibc_nbroccurence :=
                        1;
                    l_listibchvalue (l_listibchvalue.LAST).ibc_ptl_id :=
                        l_recprotocolmappinglaboparent.ptl_id;
                    l_cumul := gbl_listibchvalue (l_indice).ibc_counter;
                ELSE
                    l_listibchvalue (l_foundindice).ibc_counter :=
                        l_listibchvalue (l_foundindice).ibc_counter + l_cumul;
                    l_listibchvalue (l_foundindice).ibc_nbroccurence :=
                        l_listibchvalue (l_foundindice).ibc_nbroccurence + 1;
                    pkg_debug.p_write (
                        'PKG_IBCH.p_completewithparent',
                           'Cumul PARENT :'
                        || l_recprotocolmappinglaboparent.ptl_id
                        || ' '
                        || l_recprotocolmappinglaboparent.ptl_taxa
                        || ' count: '
                        || l_cumul
                        || ' new total:'
                        || l_listibchvalue (l_foundindice).ibc_counter);
                END IF;

                /*
                            l_recsystvalue :=
                               pkg_systvalue.f_getrecord (
                                  l_recprotocolmappinglaboparent.ptl_syv_id);

                            l_recprotocolmappinglaboparent :=
                               pkg_protocolmappinglabo.f_identifyentrybyhierarchy (
                                  l_recsystvalue.syv_syv_id,
                                  l_recprotocolversion.ptv_ptv_id_labofrommass); */



                l_recprotocolmappinglaboparent :=
                    pkg_protocolmappinglabo.f_getrecord (
                        l_recprotocolmappinglaboparent.ptl_ptl_id);
            END LOOP;

            l_indice := gbl_listibchvalue.NEXT (l_indice);
        END LOOP;

        p_displaylistibchvalue;


        l_indice := l_listibchvalue.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            gbl_listibchvalue.EXTEND (1);
            gbl_listibchvalue (gbl_listibchvalue.LAST) :=
                l_listibchvalue (l_indice);
            l_indice := l_listibchvalue.NEXT (l_indice);
        END LOOP;
    END;


    /*-----------------------------------------------------------------*/

    PROCEDURE p_loaddatafrommass (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN importmassdataheader%ROWTYPE)
    /*-----------------------------------------------------------------*/
    IS
        CURSOR l_massdatadetail (
            p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
        IS
            SELECT *
              FROM importmassdatadetail
             WHERE     imd_imh_id = p_imh_id
                   AND imd_validstatus = pkg_constante.cst_validstatusok; -- A ce stade, tout doit être contrôler et le status doit être valide

        l_recmassdatadetail            l_massdatadetail%ROWTYPE;
        l_countexclude                 NUMBER;
        l_firstfieldvalue              importmassdatadetail.imd_species%TYPE;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
    BEGIN
        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                p_recimportprotocolheader.iph_id,
                pkg_codevalue.cst_midatfldcmt_taxonibch);

        IF NOT l_recimportmassmappingheader.ime_id IS NULL
        THEN
            -- La colonne IBCH a été définie dans le protocole de masse

            p_ibchinit;

            OPEN l_massdatadetail (p_recmassdataheader.imh_id);

            LOOP
                FETCH l_massdatadetail INTO l_recmassdatadetail;

                EXIT WHEN l_massdatadetail%NOTFOUND;
                p_ibchadddata (l_recmassdatadetail.imd_ptl_id,
                               l_recmassdatadetail.imd_freq1);

                IF NOT l_recmassdatadetail.imd_ptl_id IS NULL
                THEN
                    gbl_ibchidentifiedtaxoncounter :=
                        gbl_ibchidentifiedtaxoncounter + 1;
                END IF;
            END LOOP;

            CLOSE l_massdatadetail;
        ELSE                            -- La colonne IBCH n'a pas été définie
            -- Pour charger les données nécessaire au calcul de l'IBCH on doit relire le détail
            pkg_debug.p_write ('PKG_IBCH.p_loaddatafrommass',
                               'TAXONIBCH NON DEFINI');
            p_initlistibchvaluemass;

            -- Pour charger les données nécessaire au calcul de l'IBCH on doit relire le détail
            OPEN l_massdatadetail (p_recmassdataheader.imh_id);

            LOOP
                FETCH l_massdatadetail INTO l_recmassdatadetail;

                EXIT WHEN l_massdatadetail%NOTFOUND;
                p_addlistibchvaluemass (l_recmassdatadetail.imd_syv_id,
                                        l_recmassdatadetail.imd_freq1);
                gbl_ibchidentifiedtaxoncounter :=
                    gbl_ibchidentifiedtaxoncounter + 1;
            END LOOP;

            CLOSE l_massdatadetail;

            p_convertmass2ibch (p_recimportprotocolheader.iph_ptv_id,
                                p_recimportprotocolheader.iph_id,
                                p_recmassdataheader.imh_id);
        END IF;


        p_completewithparent (p_recimportprotocolheader.iph_ptv_id);
    END;

    /*-------------------------------------------------------------*/

    PROCEDURE p_loaddatafromlabo (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE)
    /*-------------------------------------------------------------*/

    /*
     Référence: Calcul de l'IBCH: http://www.sib.admin.ch/uploads/media/UV-1026-F_01.pdf
  */
    IS
        CURSOR l_curimportprotocollabo
        IS
            SELECT *
              FROM importprotocollabo
             WHERE     ipl_iph_id = p_recimportprotocolheader.iph_id
                   AND NVL (ipl_value, 0) > 0;

        l_reccurimportprotocollabo   l_curimportprotocollabo%ROWTYPE;
        l_ibch                       NUMBER;
    BEGIN
        p_ibchinit;

        OPEN l_curimportprotocollabo;

        LOOP
            FETCH l_curimportprotocollabo INTO l_reccurimportprotocollabo;

            EXIT WHEN l_curimportprotocollabo%NOTFOUND;
            p_ibchadddata (l_reccurimportprotocollabo.ipl_ptl_id,
                           l_reccurimportprotocollabo.ipl_value);
        END LOOP;

        CLOSE l_curimportprotocollabo;

        p_completewithparent (p_recimportprotocolheader.iph_ptv_id);
    END;



    /*--------------------------------------------------------------------------------------*/

    PROCEDURE p_maincompute (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN     importmassdataheader%ROWTYPE, -- NULL si ce n'est pas un protocole de labo
        p_ibchindice                   OUT NUMBER)
    /*--------------------------------------------------------------------------------------*/
    IS
        l_ptv_id               protocolversion.ptv_id%TYPE;
        l_mkiindice            NUMBER := 0;
        l_recprotocolversion   protocolversion%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
        l_abondanceflag        codevalue.cvl_code%TYPE;
    BEGIN
        pkg_debug.p_write ('PKG_IBCH.p_maincompute', 'Strat');
        l_ptv_id := p_recimportprotocolheader.iph_ptv_id;
        l_recprotocolversion := pkg_protocolversion.f_getrecord (l_ptv_id);
        l_reccodevalue :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);
        pkg_debug.p_write (
            'PKG_IBCH.p_maincompute',
            'l_reccodevalue.cvl_code=' || l_reccodevalue.cvl_code);

        IF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_mass
        THEN
            pkg_debug.p_write ('PKG_IBCH.p_maincompute', 'MASS DATA');
            p_loaddatafrommass (p_recimportprotocolheader,
                                p_recmassdataheader);
            l_abondanceflag := cst_abondanceflag_absolu;
        ELSE                                      -- Pas un protocole de masse
            IF NOT p_recimportprotocolheader.iph_absolutenumberflag IS NULL
            THEN
                l_abondanceflag := cst_abondanceflag_absolu;
            ELSE
                l_abondanceflag := cst_abondanceflag_class;
            END IF;

            p_loaddatafromlabo (p_recimportprotocolheader);
        END IF;

        p_ibchindice := f_computeibchfrommemory (l_abondanceflag);

        pkg_debug.p_write (
            'PKG_IBCH.p_maincompute',
               ' gbl_count_ephemeroptera='
            || gbl_count_ephemeroptera
            || ' gbl_count_plecoptera '
            || gbl_count_plecoptera
            || ' gbl_count_tricoptera  '
            || gbl_count_tricoptera
            || ' gbl_ibch_vt '
            || gbl_ibch_vt
            || ' gbl_ibch_gi '
            || gbl_ibch_gi
            || ' gbl_taxonindicateur '
            || gbl_taxon_indicateur);

        IF gbl_writelog
        THEN
            --Indice IBCH = %p1%, VT=%p2% GI=%p3% Taxon indicateur=%p4% Nombre Ephemeroptera=%p5% Tricoptera=%p6% Plecoptera=%p7% somme vt %p8%
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_infoibchdata,
                NULL,
                TO_CHAR (p_ibchindice),
                TO_CHAR (gbl_ibch_vt),
                TO_CHAR (gbl_ibch_gi),
                gbl_taxon_indicateur,
                TO_CHAR (gbl_count_ephemeroptera),
                TO_CHAR (gbl_count_tricoptera),
                TO_CHAR (gbl_count_plecoptera),
                TO_CHAR (gbl_ibchsomme_vt));
        END IF;
    END;
END pkg_ibch;
/

