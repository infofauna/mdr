create PACKAGE BODY       pkg_importmassdatadetail
AS
    /******************************************************************************
       NAME:       pkg_importmassdatadetail
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        02.10.2013      burrif       1. Created this package.
       2.0         11.07.2017     burrif       2. Fonctionnalité version 2
      2.1         27.10.2019     burrif       3. Les détails invalides sont associés à un IMH_ID
    ******************************************************************************/



    TYPE t_cursor IS REF CURSOR;

    TYPE t_listfieldheader IS TABLE OF VARCHAR2 (1024)
        INDEX BY PLS_INTEGER;

    TYPE t_listdata IS TABLE OF VARCHAR2 (1024)
        INDEX BY protocolmappingmassfield.pmm_columnname%TYPE;



    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 2.1, octobre  2019' ;


    gbl_listfieldheader           t_listfieldheader;
    gbl_listdata                  t_listdata;
    gbl_imd_iph_id                NUMBER := NULL;
    gbl_rownum                    NUMBER := NULL;
    gbl_counter                   NUMBER := 0;


    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_returnfirstsystfieldfilled (
        p_recimportmassdatadetail   IN importmassdatadetail%ROWTYPE)
        RETURN importmassdatadetail.imd_species%TYPE
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        IF NOT p_recimportmassdatadetail.imd_subspecies IS NULL
        THEN
            RETURN p_recimportmassdatadetail.imd_subspecies;
        END IF;

        IF NOT p_recimportmassdatadetail.imd_species IS NULL
        THEN
            RETURN p_recimportmassdatadetail.imd_species;
        END IF;

        IF NOT p_recimportmassdatadetail.imd_genus IS NULL
        THEN
            RETURN p_recimportmassdatadetail.imd_genus;
        END IF;


        IF NOT p_recimportmassdatadetail.imd_family IS NULL
        THEN
            RETURN p_recimportmassdatadetail.imd_family;
        END IF;

        IF NOT p_recimportmassdatadetail.imd_highertaxon IS NULL
        THEN
            RETURN p_recimportmassdatadetail.imd_highertaxon;
        END IF;

        RETURN NULL;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_cleargblcounter
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        gbl_counter := 0;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_getvalidrowcount (
        p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM importmassdatadetail
         WHERE     imd_validstatus = pkg_constante.cst_validstatusok
               AND imd_imh_id = p_imh_id;

        RETURN l_count;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_getinvalidrowcount (
        p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM importmassdatadetail
         WHERE     imd_validstatus = pkg_constante.cst_validstatusnotok
               AND imd_imh_id = p_imh_id;

        RETURN l_count;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_purgeorphan
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM importmassdatadetail
              WHERE imd_imh_id IS NULL;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_deletebyimhid (
        p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM importmassdatadetail
              WHERE imd_imh_id = p_imh_id;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_saveprotocolmassdetail (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_importmassdataheader      IN importmassdataheader%ROWTYPE,
        p_sph_id                    IN sampleheader.sph_id%TYPE,
        p_lan_id                    IN language.lan_id%TYPE,
        p_usr_id                    IN sampleprotocolgrnd.spd_usr_id_create%TYPE)
    /*----------------------------------------------------------------*/
    IS
        /*
      IMD_ID
     IMD_STATUS
     IMD_VALIDSTATUS
     IMD_IMH_ID
     IMD_IPH_ID
     IMD_SOURCELINE
     IMD_HIGHERTAXON           SPL_SYV_ID
     IMD_FAMILY                      SPL_SYV_ID
     IMD_GENUS                       SPL_SYV_ID
     IMD_SPECIES                     SPL_SYV_ID
     IMD_SUBSPECIES               SPL_SYV_ID
     IMD_FREQ1                        SPL_FREQUENCY
     IMD_FREQ2                       SPL_FREQUENCYMODIFIED
     IMD_FREQLUM                   SPL_FREQLUM
     IMD_STADIUM                   SPL_STADIUM
     IMD_SAMPLINGMETHOD    SPH_CVL_ID<SAMPLING>
     IMD_INDICETYPE             SPH_CVL_ID<INDICETYPE>
     IMD_PERIOD                    SPH_PERIOD
     IMD_DAY                         SPH_DAY
     IMD_MONTH                    SPH_MONTH
     IMD_YEAR                       SPH_YEAR
     IMD_WATERCOURSE       SMH_ITEM, SSI_ITEM
     IMD_LOCALITY               SMH_ITEM, SSI_ITEM
     IMD_CALLEDPLACE          SMH_ITEM, SSI_ITEM
     IMD_SWISSCOORD_X      SST_COORDINATES
     IMD_SWISSCOORD_Y      SST_COORDINATES
     IMD_SWISSCOORD_Z      SST_COORDINATES
     IMD_OBSERVERS               SMH_ITEM
     IMD_PROJECT                   SPH_PROJECT
     IMD_TAXON_DEF            <non utilisé>
     IMD_CODEPRECISION      SPH_CVL_ID_SYSPRECISION
     IMD_SYSTEMPRECISIO      SPH_CVL_ID_SYSPRECISIONREF
     IMD_SAMPLENUMBER       spl_SAMPLENO
     IMD_CANTON                  <a voir>
     IMD_OID                        SST_OID <a calculer si vide>
     IMD_PRCODE                 Peut être réutilisé car sauve dans IMD_CODEPRECISION
     IMD_COMMENT              SPL_COMMENT
     IMD_REPORTURL           SPT_FILENAME
     */
        CURSOR l_importmassdatadetail
        IS
            SELECT imd_id,
                   imd_syv_id,
                   imd_highertaxon,
                   imd_family,
                   imd_genus,
                   imd_species,
                   imd_subspecies,
                   imd_taxonibch,
                   imd_cvl_id_zoostadium,
                   imd_freq1,
                   imd_freq2,
                   imd_freqlum,
                   imd_stadium,
                   imd_samplenumber,
                   imd_comment
              FROM importmassdatadetail
             WHERE imd_imh_id = p_importmassdataheader.imh_id;

        l_recimportmassdatadetail   l_importmassdatadetail%ROWTYPE;
        l_spl_id                    sampleprotocollabo.spl_id%TYPE;
        l_smx_id                    sampleprotocolmass.smx_id%TYPE;
        l_countexclude              NUMBER;
        l_undefinedspecies          importmassdatadetail.imd_species%TYPE;
    BEGIN
        OPEN l_importmassdatadetail;

        LOOP
            FETCH l_importmassdatadetail INTO l_recimportmassdatadetail;

            EXIT WHEN l_importmassdatadetail%NOTFOUND;
            -- Le terme est-il dans la liste des termes a ignorer (exemple: sp.)
            l_countexclude :=
                pkg_codedesignation.f_countdesignation (
                    l_recimportmassdatadetail.imd_species,
                    pkg_codereference.cst_crf_excspekeywor);

            IF l_countexclude > 0
            THEN
                l_undefinedspecies := l_recimportmassdatadetail.imd_species;
            ELSE
                l_undefinedspecies := NULL;
            END IF;

            pkg_sampleprotocollabo.p_writeorupdate (
                p_sph_id,
                NULL,                -- PTL_ID null pour les protocol de masse
                l_recimportmassdatadetail.imd_syv_id,
                l_recimportmassdatadetail.imd_cvl_id_zoostadium,
                l_recimportmassdatadetail.imd_freq1,
                l_recimportmassdatadetail.imd_freq2,
                l_recimportmassdatadetail.imd_freqlum,
                l_recimportmassdatadetail.imd_stadium,
                l_recimportmassdatadetail.imd_samplenumber,
                l_recimportmassdatadetail.imd_comment,
                l_undefinedspecies,
                p_usr_id,
                l_spl_id);
            pkg_sampleprotocolmass.p_write (
                l_recimportmassdatadetail.imd_syv_id,
                p_sph_id,
                l_recimportmassdatadetail.imd_cvl_id_zoostadium,
                l_recimportmassdatadetail.imd_highertaxon,
                l_recimportmassdatadetail.imd_family,
                l_recimportmassdatadetail.imd_genus,
                l_recimportmassdatadetail.imd_species,
                l_recimportmassdatadetail.imd_subspecies,
                l_recimportmassdatadetail.imd_freq1,
                l_recimportmassdatadetail.imd_freq2,
                l_recimportmassdatadetail.imd_freqlum,
                l_recimportmassdatadetail.imd_stadium,
                l_recimportmassdatadetail.imd_comment,
                l_recimportmassdatadetail.imd_taxonibch,
                p_usr_id,
                l_spl_id,
                l_recimportmassdatadetail.imd_id,
                l_recimportmassdatadetail.imd_samplenumber,
                l_smx_id);
        END LOOP;

        CLOSE l_importmassdatadetail;

        NULL;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_cleargbllistdata
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        gbl_listdata.delete;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_buildsourcelinefilled (
        p_imh_id      IN importmassdatadetail.imd_imh_id%TYPE,
        p_fieldname   IN VARCHAR2)
        RETURN VARCHAR2
    /*----------------------------------------------------------------*/
    IS
        l_listline       t_cursor;
        l_sql            VARCHAR2 (1024);


        l_line           NUMBER;
        l_listlinechar   VARCHAR2 (1024) := NULL;
    BEGIN
        l_sql := ' SELECT imd_sourceline
           FROM importmassdatadetail
          WHERE imd_imh_id =' || p_imh_id || ' 
          AND NOT ' || p_fieldname || ' IS NULL
          ORDER BY imd_sourceline';
        pkg_debug.p_write (
            'PKG_IMPORTMASSDATADETAIL.f_buildsourcelinefilled',
            l_sql);

        OPEN l_listline FOR l_sql;

        LOOP
            FETCH l_listline INTO l_line;

            EXIT WHEN l_listline%NOTFOUND;

            IF NOT l_line IS NULL
            THEN
                IF l_listlinechar IS NULL
                THEN
                    l_listlinechar := TO_CHAR (l_line);
                ELSE
                    l_listlinechar :=
                        l_listlinechar || ', ' || TO_CHAR (l_line);
                END IF;
            END IF;
        END LOOP;

        CLOSE l_listline;

        IF l_listlinechar IS NULL
        THEN
            pkg_debug.p_write (
                'PKG_IMPORTMASSDATADETAIL.f_buildsourcelinefilled',
                'NULL sourceline :   p_imh_id=' || TO_CHAR (p_imh_id));
        END IF;

        RETURN l_listlinechar;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_buildsourceline (
        p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
        RETURN VARCHAR2
    /*----------------------------------------------------------------*/
    IS
        CURSOR l_listline
        IS
              SELECT imd_sourceline
                FROM importmassdatadetail
               WHERE imd_imh_id = p_imh_id
            ORDER BY imd_sourceline;

        l_reclistline    l_listline%ROWTYPE;
        l_listlinechar   VARCHAR2 (1024) := NULL;
    BEGIN
        OPEN l_listline;

        LOOP
            FETCH l_listline INTO l_reclistline;

            EXIT WHEN l_listline%NOTFOUND;

            IF NOT l_reclistline.imd_sourceline IS NULL
            THEN
                IF l_listlinechar IS NULL
                THEN
                    l_listlinechar := TO_CHAR (l_reclistline.imd_sourceline);
                ELSE
                    l_listlinechar :=
                           l_listlinechar
                        || ', '
                        || TO_CHAR (l_reclistline.imd_sourceline);
                END IF;
            END IF;
        END LOOP;

        CLOSE l_listline;

        IF l_listlinechar IS NULL
        THEN
            pkg_debug.p_write (
                'PKG_IMPORTMASSDATADETAIL.f_buildsourceline',
                'NULL sourceline :   p_imh_id=' || TO_CHAR (p_imh_id));
        END IF;

        RETURN l_listlinechar;
    END;

    /*-------------------------------------------------------------*/
    FUNCTION f_getrowcount (p_iph_id IN importmassdatadetail.imd_iph_id%TYPE)
        RETURN NUMBER
    /*-------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM importmassdatadetail
         WHERE imd_iph_id = p_iph_id;

        RETURN l_count;
    END;

    PROCEDURE p_setgblrownum (p_rownum IN NUMBER)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        gbl_rownum := p_rownum;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_setgbliphid (p_iph_id IN NUMBER)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        gbl_imd_iph_id := p_iph_id;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_setsyv_id (
        p_imd_id   IN importmassdatadetail.imd_id%TYPE,
        p_syv_id   IN importmassdatadetail.imd_syv_id%TYPE)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdatadetail
           SET imd_syv_id = p_syv_id
         WHERE imd_id = p_imd_id;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_setcvl_id_zoostadium (
        p_imd_id              IN importmassdatadetail.imd_id%TYPE,
        p_cvl_id_zoostadium   IN importmassdatadetail.imd_cvl_id_zoostadium%TYPE)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdatadetail
           SET imd_cvl_id_zoostadium = p_cvl_id_zoostadium
         WHERE imd_id = p_imd_id;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_setptl_id (
        p_imd_id   IN importmassdatadetail.imd_id%TYPE,
        p_ptl_id   IN importmassdatadetail.imd_ptl_id%TYPE)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdatadetail
           SET imd_ptl_id = p_ptl_id
         WHERE imd_id = p_imd_id;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_setvalidstatus (
        p_imd_id   IN importmassdatadetail.imd_id%TYPE,
        p_status   IN importmassdatadetail.imd_validstatus%TYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdatadetail
           SET imd_validstatus = p_status
         WHERE imd_id = p_imd_id;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_setvalidstatusbyimh_id (
        p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE,
        p_status   IN importmassdatadetail.imd_validstatus%TYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdatadetail
           SET imd_validstatus = p_status
         WHERE imd_imh_id = p_imh_id;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_countfieldfilled (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE,
        p_codemidatfldcmt           protocolmappingmassfield.pmm_code_midatfldcmt%TYPE)
        RETURN NUMBER
    /*-----------------------------------------------------------------*/
    IS
        l_recprotocolmappingmassfield   protocolmappingmassfield%ROWTYPE;
        l_sql                           VARCHAR2 (1024);
        l_cursor                        t_cursor;
        l_count                         NUMBER;
    BEGIN
        l_recprotocolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getfromcode (
                p_codemidatfldcmt,
                p_importprotocolheader.iph_ptv_id);
        l_sql :=
               'SELECT COUNT(*) FROM IMPORTMASSDATADETAIL INNER JOIN IMPORTMASSDATAHEADER '
            || ' ON IMH_ID=IMD_IMH_ID '
            || ' WHERE IMH_IPH_ID='
            || p_importprotocolheader.iph_id
            || ' AND NOT '
            || l_recprotocolmappingmassfield.pmm_columnname
            || ' IS NULL ';

        OPEN l_cursor FOR l_sql;

        FETCH l_cursor INTO l_count;

        CLOSE l_cursor;

        RETURN l_count;
    END;



    /*-----------------------------------------------------------------*/
    PROCEDURE p_setimd_imh_id (
        p_imh_id         IN importmassdatadetail.imd_imh_id%TYPE,
        p_iph_id         IN importmassdatadetail.imd_iph_id%TYPE,
        p_swisscoord_x   IN importmassdatadetail.imd_swisscoord_x%TYPE,
        p_swisscoord_y   IN importmassdatadetail.imd_swisscoord_y%TYPE,
        p_day            IN importmassdatadetail.imd_day%TYPE,
        p_month          IN importmassdatadetail.imd_month%TYPE,
        p_year           IN importmassdatadetail.imd_year%TYPE)
    /*-----------------------------------------------------------------*/
    IS
    /*  p_day, p_month peuvent être null
    */
    BEGIN
        UPDATE importmassdatadetail
           SET imd_imh_id = p_imh_id
         WHERE     imd_swisscoord_x = p_swisscoord_x
               AND imd_swisscoord_y = p_swisscoord_y
               AND NVL (imd_day, 1) = NVL (p_day, 1)
               AND NVL (imd_month, 1) = NVL (p_month, 1)
               AND imd_year = p_year
               --      AND imd_validstatus != pkg_constante.cst_validstatusnotok
               AND imd_iph_id = p_iph_id;


        NULL;
    END;


    /*------------------------------------------------------------------*/
    PROCEDURE p_identifyheader (
        p_iph_id     IN     importmassdatadetail.imd_iph_id%TYPE,
        p_lan_id     IN     language.lan_id%TYPE,
        p_rowcount      OUT NUMBER)
    /*-----------------------------------------------------------------*/
    IS
        -- Les colonnes imd_swisscoord_x,imd_swisscoord_y,imd_year sont obligatoires.
        -- Elles sont testées par le biais du paramétrage défini dans la table protocolmappingmassfield
        /*
         Problème: L'identification des header en utilisant la coordonnées Z peut conduires à créer plusieurs headers sur la même coordonnées X,Y
          X          Y           Z
       600000   200000    null
       600000   200000    330
       600000   200000     330.5

       Aussi on utilise pas le Z pour identifier le header mais on vérifie l'unicité de la coordonnées Z comme l'unicité des champ projet, etc.
        */



        CURSOR l_header
        IS
            SELECT DISTINCT imd_swisscoord_x,
                            imd_swisscoord_y,
                            imd_day,
                            imd_month,
                            imd_year
              FROM importmassdatadetail
             WHERE imd_iph_id = p_iph_id;

        --     AND imd_validstatus != pkg_constante.cst_validstatusnotok;

        l_recheader              l_header%ROWTYPE;
        l_imh_id                 importmassdataheader.imh_id%TYPE;
        l_totalcount             NUMBER;
        l_importprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        l_importprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);

        SELECT COUNT (*)
          INTO l_totalcount
          FROM (SELECT DISTINCT imd_swisscoord_x,
                                imd_swisscoord_y,
                                imd_day,
                                imd_month,
                                imd_year
                  FROM importmassdatadetail
                 WHERE imd_iph_id = p_iph_id);

        /*         AND imd_validstatus !=
                        pkg_constante.cst_validstatusnotok);*/

        p_rowcount := 0;

        OPEN l_header;

        LOOP
            FETCH l_header INTO l_recheader;


            EXIT WHEN l_header%NOTFOUND;
            p_rowcount := p_rowcount + 1;
            pkg_processingstatus.p_setstatusbar (p_rowcount, l_totalcount);
            pkg_importmassdataheader.p_addheader (
                p_iph_id,
                l_recheader.imd_day,
                l_recheader.imd_month,
                l_recheader.imd_year,
                l_recheader.imd_swisscoord_x,
                l_recheader.imd_swisscoord_y,
                NULL,                                                     -- z
                l_importprotocolheader.iph_prj_id,
                l_imh_id);
            p_setimd_imh_id (l_imh_id,
                             p_iph_id,
                             l_recheader.imd_swisscoord_x,
                             l_recheader.imd_swisscoord_y,
                             l_recheader.imd_day,
                             l_recheader.imd_month,
                             l_recheader.imd_year);
        END LOOP;

        CLOSE l_header;

        pkg_processingsteplog.p_setmeasuredata (
            p_rowcount,
            pkg_processingsteplog.cst_measureunitrowcount);
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_deletebyiph_id (
        p_iph_id   IN importmassdatadetail.imd_iph_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM importmassdatadetail
              WHERE imd_iph_id = p_iph_id;
    END;



    /*---------------------------------------------------------------*/
    PROCEDURE p_clearlistfieldheader (
        p_iph_id   IN importmassmappingheader.ime_iph_id%TYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        pkg_debug.p_write ('PKG_IMPORTMASSDATADETAIL.p_clearlistfieldheader',
                           'iph_id for delete= ' || TO_CHAR (p_iph_id));
        gbl_listfieldheader.delete;
        gbl_listdata.delete;
        pkg_importmassmappingheader.p_deletebyiph_id (p_iph_id);
        gbl_imd_iph_id := NULL;
        gbl_rownum := NULL;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_addlistfieldheader (
        p_aliascolumnname   IN protocolmappingmassmap.pma_aliascolumnname%TYPE,
        p_column            IN PLS_INTEGER)
    /*--------------------------------------------------------------*/
    IS
        l_recimportprotocolheader    importprotocolheader%ROWTYPE;
        l_protocolmappingmassfield   protocolmappingmassfield%ROWTYPE;
        l_protocolmappingmassmap     protocolmappingmassmap%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (gbl_imd_iph_id);

        IF l_recimportprotocolheader.iph_id IS NULL
        THEN
            RETURN;
        END IF;



        l_protocolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getfromaliascolumnname (
                p_aliascolumnname,
                l_recimportprotocolheader.iph_ptv_id,
                l_recimportprotocolheader.iph_lan_id);

        IF l_protocolmappingmassfield.pmm_id IS NULL
        THEN
            pkg_debug.p_write (
                'PKG_IMPORTMASSDATADETAIL.p_addlistfieldheader',
                   'p_column='
                || p_column
                || ' p_aliascolumnname='
                || p_aliascolumnname
                || ' non trouvé');
            gbl_listfieldheader (p_column) := NULL; -- L'alias de colonne n'est pas trouvé
            RETURN;
        ELSE
            pkg_importmassmappingheader.p_insert (
                gbl_imd_iph_id,
                l_protocolmappingmassfield.pmm_id,
                p_aliascolumnname);
            gbl_listfieldheader (p_column) :=
                l_protocolmappingmassfield.pmm_columnname;
            pkg_debug.p_write (
                'PKG_IMPORTMASSDATADETAIL.p_addlistfieldheader',
                   'p_column='
                || p_column
                || ' p_aliascolumnname='
                || p_aliascolumnname
                || ' -->'
                || l_protocolmappingmassfield.pmm_columnname);
        END IF;

        NULL;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_addfielddata (p_column IN PLS_INTEGER, p_value IN VARCHAR2)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        pkg_debug.p_write ('PKG_IMPORTMASSDATADETAIL.p_addfielddata',
                           'p_column=' || p_column || ' p_value=' || p_value);

        IF gbl_listfieldheader (p_column) IS NULL
        THEN
            RETURN;
        ELSE
            gbl_listdata (gbl_listfieldheader (p_column)) := p_value;
        END IF;
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_buildinscmdfromfielddata
        RETURN VARCHAR2
    /*--------------------------------------------------------------*/
    IS
        l_field   protocolmappingmassfield.pmm_columnname%TYPE;
        l_into    VARCHAR2 (18000);
        l_value   VARCHAR2 (18000);
    BEGIN
        l_field := gbl_listdata.FIRST;

        WHILE NOT l_field IS NULL
        LOOP
            IF NOT l_into IS NULL
            THEN
                l_into := l_into || ',' || l_field;
            ELSE
                l_into := l_field;
            END IF;

            IF NOT l_value IS NULL
            THEN
                l_value :=
                       l_value
                    || ','''
                    || pkg_stringutil.f_doubleapostrophe (
                           gbl_listdata (l_field))
                    || '''';
            ELSE
                l_value :=
                       ''''
                    || pkg_stringutil.f_doubleapostrophe (
                           gbl_listdata (l_field))
                    || '''';
            END IF;

            l_field := gbl_listdata.NEXT (l_field);
        END LOOP;

        IF NOT l_into IS NULL
        THEN
            l_into := l_into || ', IMD_IPH_ID';
            l_value := l_value || ', ' || TO_CHAR (gbl_imd_iph_id);
            l_into := l_into || ', IMD_SOURCELINE';
            l_value := l_value || ', ' || TO_CHAR (gbl_rownum);
        END IF;


        RETURN    'INSERT INTO IMPORTMASSDATADETAIL('
               || l_into
               || ') VALUES('
               || l_value
               || ')';
    END;



    /*----------------------------------------------------------------*/
    PROCEDURE p_flushfielddata
    /*----------------------------------------------------------------*/
    IS
        PRAGMA AUTONOMOUS_TRANSACTION;

        l_sqlcommand   VARCHAR2 (18000);
    BEGIN
        gbl_counter := gbl_counter + 1;

        pkg_processingstatus.p_setstatusbar (gbl_counter, NULL);

        l_sqlcommand := f_buildinscmdfromfielddata;

        /*    pkg_debug.p_write ('pkg_importmassdatadetail.p_flushfielddata',
                               l_sqlcommand);
      */
        EXECUTE IMMEDIATE l_sqlcommand;

        COMMIT;
        p_cleargbllistdata;
    END;



    /*-------------------------------------------------------------*/
    FUNCTION f_getrecord (p_imd_id IN importmassdatadetail.imd_id%TYPE)
        RETURN importmassdatadetail%ROWTYPE
    /*-------------------------------------------------------------*/
    IS
        l_record   importmassdatadetail%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_record
          FROM importmassdatadetail
         WHERE imd_id = p_imd_id;

        RETURN l_record;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;
END;
/

