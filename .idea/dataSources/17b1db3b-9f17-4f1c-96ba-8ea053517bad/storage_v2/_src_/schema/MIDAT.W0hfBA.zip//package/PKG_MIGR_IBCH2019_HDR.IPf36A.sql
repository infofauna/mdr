create PACKAGE       pkg_migr_ibch2019_hdr
AS
    /******************************************************************************
       NAME:       pkg_migr_ibch2019_hdr
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        3.07.2020      burrif       1. Created this package.
    ******************************************************************************/


    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_insertalldata;

    PROCEDURE p_delete;
END pkg_migr_ibch2019_hdr;
/

