create trigger TR_BIF_WK_LOGCHANGEDETAIL
    before insert
    on WK_LOGCHANGEDETAIL
    for each row
BEGIN

   IF :NEW.WKD_ID IS NULL THEN
   SELECT seq_wk_logchangedetail.NEXTVAL INTO :NEW.WKD_ID FROM dual;
  END IF;

END TR_BIF_WK_LOGCHANGEDETAIL;

/

