create PACKAGE       pkg_manageindice
AS
   /******************************************************************************
      NAME:       PKG_MANAGEINDICE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        21.04.2016      burrif       1. Created this package.
   ******************************************************************************/

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_testrebuild;

   PROCEDURE p_check;

   
END pkg_manageindice;
/

