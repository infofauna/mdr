create PACKAGE BODY       pkg_migr_ibch2019_util
AS
    /******************************************************************************
       NAME:       PKG_MIGR_IBCH2019_UTIL
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       15.05.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_checktableexist (p_table_name IN user_tables.table_name%TYPE)
        /*-----------------------------------------------------------------*/
        RETURN NUMBER
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM user_tables
         WHERE UPPER (table_name) = UPPER (p_table_name);

        RETURN l_count;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_checkconstraintexist (
        p_table_name        IN user_constraints.table_name%TYPE,
        p_constraint_name   IN user_constraints.constraint_name%TYPE)
        /*-----------------------------------------------------------------*/
        RETURN NUMBER
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM user_constraints
         WHERE     UPPER (table_name) = UPPER (p_table_name)
               AND UPPER (constraint_name) = UPPER (p_constraint_name);

        RETURN l_count;
    END;

    FUNCTION f_checkcolumnexist (
        p_table_name   IN user_tab_columns.table_name%TYPE,
        p_column       IN user_tab_columns.column_name%TYPE)
        RETURN user_tab_columns%ROWTYPE
    /*-----------------------------------------------------------------*/
    IS
        l_user_tab_columns   user_tab_columns%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_user_tab_columns
          FROM user_tab_columns
         WHERE     column_name = UPPER (p_column)
               AND table_name = UPPER (p_table_name);

        RETURN l_user_tab_columns;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;


    /*-----------------------------------------------------------------*/
    PROCEDURE p_addcolumn (p_table_name   IN     VARCHAR2,
                           p_name         IN     VARCHAR2,
                           p_type         IN     VARCHAR2,
                           p_constraint   IN     VARCHAR2,
                           p_done            OUT BOOLEAN)
    /*-----------------------------------------------------------------*/
    IS
        l_user_tab_columns   user_tab_columns%ROWTYPE;
        l_sql                VARCHAR2 (1024);
    BEGIN
        p_done := FALSE;
        l_user_tab_columns := f_checkcolumnexist (p_table_name, p_name);

        IF NOT l_user_tab_columns.column_name IS NULL
        THEN
            pkg_debug.p_write (
                'pkg_migr_ibch2019_util.p_addcolumn',
                   'INFO*** La colonne '
                || p_name
                || ' de la table '
                || p_table_name
                || ' existe déjà');
            RETURN;
        END IF;

        l_sql :=
               'ALTER TABLE '
            || p_table_name
            || ' ADD ('
            || p_name
            || ' '
            || p_type
            || ' '
            || p_constraint
            || ')';

        EXECUTE IMMEDIATE l_sql;

        pkg_debug.p_write (
            'pkg_migr_ibch2019_util.p_addcolumn',
               'INFO*** La colonne '
            || p_name
            || ' de la table '
            || p_table_name
            || ' a été créée ');

        DBMS_OUTPUT.put_line (l_sql);

        p_done := TRUE;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_compilepackage (p_package IN VARCHAR2)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        DBMS_DDL.alter_compile ('PACKAGE', 'MIDAT', p_package);
        DBMS_DDL.alter_compile ('PACKAGE BODY', 'MIDAT', p_package);
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_checksequence (p_name IN user_sequences.sequence_name%TYPE)
        RETURN BOOLEAN
    /*--------------------------------------------------------------*/
    IS
        l_name   user_sequences.sequence_name%TYPE;
    BEGIN
        SELECT sequence_name
          INTO l_name
          FROM user_sequences
         WHERE UPPER (TRIM (p_name)) = UPPER (sequence_name);

        RETURN TRUE;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN FALSE;
    END;

    /*--------------------------------------------------------------------------*/
    FUNCTION f_returnlastid (p_table IN VARCHAR2, p_name_id VARCHAR2)
        RETURN NUMBER
    /*---------------------------------------------------------------------------*/
    IS
        l_sql      VARCHAR2 (1024);
        l_cursor   t_cursor;
        l_id       NUMBER;
    BEGIN
        l_sql := 'SELECT MAX(' || p_name_id || ') FROM ' || p_table;

        OPEN l_cursor FOR l_sql;

        FETCH l_cursor INTO l_id;

        CLOSE l_cursor;

        RETURN NVL (l_id, 0);
    END;


    /*--------------------------------------------------------------------------*/
    PROCEDURE p_createsequence (
        p_name        IN user_sequences.sequence_name%TYPE,
        p_startwith   IN NUMBER,
        p_maxvalue    IN NUMBER)
    /*--------------------------------------------------------------------------*/
    IS
        l_startwith   NUMBER;

        l_sql         VARCHAR2 (1024);
    BEGIN
        IF p_startwith IS NULL
        THEN
            l_startwith := 1;
        ELSE
            l_startwith := p_startwith;
        END IF;

        l_sql :=
               'CREATE SEQUENCE  '
            || p_name
            || ' START  WITH '
            || TO_CHAR (l_startwith);

        IF NOT p_maxvalue IS NULL
        THEN
            l_sql := l_sql || ' MAXVALUE ' || TO_CHAR (p_maxvalue);
        END IF;

        l_sql := l_sql || ' MINVALUE ' || TO_CHAR (l_startwith);

        DBMS_OUTPUT.put_line (l_sql);

        EXECUTE IMMEDIATE l_sql;
    END;

    /*-------------------------------------------------------------------------------*/
    PROCEDURE p_dropsequence (p_name IN user_sequences.sequence_name%TYPE)
    /*-------------------------------------------------------------------------------*/
    IS
        l_sql   VARCHAR2 (1024);
    BEGIN
        l_sql := 'drop sequence ' || p_name;

        EXECUTE IMMEDIATE l_sql;
    END;

    /*--------------------------------------------------------------------------*/
    PROCEDURE p_recreatesequence (
        p_table_name   IN VARCHAR2,
        p_seq_name     IN user_sequences.sequence_name%TYPE,
        p_name_id      IN VARCHAR2)
    /*--------------------------------------------------------------------------*/
    IS
        l_last_id   NUMBER;
    BEGIN
        IF f_checksequence (p_seq_name)
        THEN
            l_last_id := f_returnlastid (p_table_name, p_name_id);
            p_dropsequence (p_seq_name);
            p_createsequence (p_seq_name, l_last_id + 1, NULL);
        END IF;
    END;
END pkg_migr_ibch2019_util;
/

