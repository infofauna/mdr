create PACKAGE       pkg_sdoutil
AS
   /******************************************************************************
      NAME:       PKG_SDOUTIL
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.10.2013      burrif       1. Created this package.
   ******************************************************************************/
   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_convert3dto2d (p_coordinates IN MDSYS.sdo_geometry)
      RETURN MDSYS.sdo_geometry;

   FUNCTION f_setz (p_coordinates IN MDSYS.sdo_geometry, p_z IN NUMBER)
      RETURN MDSYS.sdo_geometry;

   FUNCTION f_convertpointto2d (p_coordinates IN MDSYS.sdo_geometry)
      RETURN MDSYS.sdo_geometry;

   FUNCTION f_formatpointcoordinates (p_coordinates   IN MDSYS.sdo_geometry,
                                      p_digit         IN PLS_INTEGER,
                                      p_decimal       IN PLS_INTEGER)
      RETURN VARCHAR2;


   FUNCTION f_buildsdo_geometry (p_x IN NUMBER, p_y IN NUMBER)
      RETURN MDSYS.sdo_geometry;

   FUNCTION f_computedistance (p_coord1   IN MDSYS.sdo_geometry,
                               p_coord2   IN MDSYS.sdo_geometry)
      RETURN NUMBER;

   FUNCTION f_computedistance2d (p_coord1   IN MDSYS.sdo_geometry,
                                 p_coord2   IN MDSYS.sdo_geometry)
      RETURN NUMBER;

   FUNCTION f_comparepoints (p_point1   IN MDSYS.sdo_geometry,
                             p_point2   IN MDSYS.sdo_geometry)
      RETURN BOOLEAN;

   PROCEDURE p_test;

   PROCEDURE p_test1;

   PROCEDURE p_returnxycoordinate (
      p_sdo_geometry   IN     MDSYS.sdo_geometry,
      p_x                 OUT NUMBER,
      p_y                 OUT NUMBER,
      p_z                 OUT NUMBER);

   FUNCTION f_buildsdo_geometry (p_x IN NUMBER, p_y IN NUMBER, p_z IN NUMBER)
      RETURN MDSYS.sdo_geometry;

   FUNCTION f_gety (p_sdo_geometry IN MDSYS.sdo_geometry)
      RETURN NUMBER;

   FUNCTION f_getx (p_sdo_geometry IN MDSYS.sdo_geometry)
      RETURN NUMBER;

   FUNCTION f_getz (p_sdo_geometry IN MDSYS.sdo_geometry)
      RETURN NUMBER;
END pkg_sdoutil;
/

