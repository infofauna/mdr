create PACKAGE       pkg_validatemassdetailfield
AS
    /******************************************************************************
       NAME:       pkg_validatemassdetailfield
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        25.04.2014      burrif       1. Created this package.
       1.1        17.02.2016       burrif      2. Modification de la règle d'identification des niveaux
                                                             Dans le champ SOUS-ESPECE on cherche les niveaux FORM, Aggrégat de sous espèce, saus-espèce
                                                             Dans le champ Espece on cheche les niveaus ESPECES, agrégat d'espèce
                                                             Dans le champ genre on cherche le GENRE, le SOUS-GENRE
                                                             Dans le champ FAMILLE on cherche la sous-famille, la tribut
                                                             Dans le champ TAXON_SUP on cherche PHYLUM, SUBPHILUM,  INFRAPHYLUM,  CLASS, SUBCLASS, INFRACLASS,
                                                              SUPERORDRE, ORDRE, SOUS-ORDRE,INFRAORDRE, SUPERFAMILLE
      1.2          20.02.2020       burrif      3. Prise en compte des taxon ibch de deux familles dans le même champ         
 ******************************************************************************/


    FUNCTION f_getversion
        RETURN VARCHAR2;


    PROCEDURE p_identifiesystematique (
        p_subspecies         IN     importmassdatadetail.imd_subspecies%TYPE,
        p_species            IN     importmassdatadetail.imd_species%TYPE,
        p_genus              IN     importmassdatadetail.imd_genus%TYPE,
        p_family             IN     importmassdatadetail.imd_family%TYPE,
        p_highertaxon        IN     importmassdatadetail.imd_highertaxon%TYPE,
        p_syv_startwith         OUT systvalue.syv_id%TYPE,
        p_crf_id                OUT codereference.crf_id%TYPE,
        p_flagprecisionmax      OUT CHAR,
        p_returnstatus          OUT NUMBER);

    PROCEDURE p_testnemathelminthes;

    PROCEDURE p_testidentifie;

    PROCEDURE p_testhydracarina;

    FUNCTION f_findlevelhyghertaxon (p_taxa IN VARCHAR2)
        RETURN codereference.crf_code%TYPE;

    PROCEDURE p_validealldetail (
        p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
        p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_lan_id         IN     language.lan_id%TYPE,
        p_returnstatus      OUT NUMBER);
END pkg_validatemassdetailfield;
/

