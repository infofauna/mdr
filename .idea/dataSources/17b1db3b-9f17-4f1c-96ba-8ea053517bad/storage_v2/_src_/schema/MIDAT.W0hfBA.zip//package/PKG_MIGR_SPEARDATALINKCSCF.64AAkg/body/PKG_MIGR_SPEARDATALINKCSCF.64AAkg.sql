create PACKAGE BODY       pkg_migr_speardatalinkcscf
AS
   /******************************************************************************
      NAME:       PKG_MIGR_SPEARDATALINKCSCF
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.10.2017      burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2017' ;

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------------*/
   PROCEDURE p_setversion1
   /*---------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE speardatalinkcscf
         SET sdf_ivr_id = 1
       WHERE sdf_credate < TO_DATE ('01/01/2016', 'DD/MM/YYYY');
   END;
END pkg_migr_speardatalinkcscf;
/

