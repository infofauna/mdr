create PACKAGE BODY pkg_debug
AS
   /******************************************************************************
      NAME:       PKG_DEBUG
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       25.07.2013  F.Burri           1. Created this package body.
   ******************************************************************************/
   gbl_debugflag   BOOLEAN;

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_truncate
   /*-----------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (1024);
   BEGIN
      l_sql := 'TRUNCATE TABLE DEBUG';

      EXECUTE IMMEDIATE l_sql;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecord (p_dbg_id IN debug.dbg_id%TYPE)
      RETURN debug%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_recdebug   debug%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recdebug
        FROM debug
       WHERE dbg_id = p_dbg_id;

      RETURN l_recdebug;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*---------------------------------------------------------------*/
   PROCEDURE p_check (p_command   IN     VARCHAR2,
                      p_oldrec    IN     debug%ROWTYPE,
                      p_newrec    IN OUT debug%ROWTYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      NULL;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_tr_buf_debug (p_oldrec   IN     debug%ROWTYPE,
                             p_newrec   IN OUT debug%ROWTYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_newrec.dbg_moddate := SYSDATE;
      p_newrec.dbg_moduser := USER;
      p_check (pkg_constante.cst_dml_command_update, p_oldrec, p_newrec);
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_tr_bif_debug (p_newrec IN OUT debug%ROWTYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_newrec.dbg_credate := SYSDATE;
      p_newrec.dbg_creuser := USER;

      IF p_newrec.dbg_id IS NULL
      THEN
         p_newrec.dbg_id := seq_debug.NEXTVAL;
      END IF;

      p_check (pkg_constante.cst_dml_command_insert, NULL, p_newrec);
   END;



   /*--------------------------------------------------------------*/
   PROCEDURE p_setdebugmode (p_flag BOOLEAN)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      gbl_debugflag := p_flag;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_write (p_module   IN debug.dbg_module%TYPE,
                      p_text     IN debug.dbg_text%TYPE)
   /*--------------------------------------------------------------*/
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      IF pkg_constante.cst_forcedebugmode OR gbl_debugflag
      THEN
   

         INSERT INTO debug (dbg_module, dbg_text)
              VALUES (p_module, p_text);

         COMMIT;
      END IF;
   END;
BEGIN
   gbl_debugflag := FALSE;
END pkg_debug;
/

