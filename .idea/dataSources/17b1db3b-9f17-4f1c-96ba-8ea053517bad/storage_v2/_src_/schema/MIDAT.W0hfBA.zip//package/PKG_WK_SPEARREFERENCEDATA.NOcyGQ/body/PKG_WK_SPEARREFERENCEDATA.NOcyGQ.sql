create PACKAGE BODY pkg_wk_spearreferencedata
AS
   /******************************************************************************
      NAME:       PKG_WK_SPEARREFERENCEDATA
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        22/08/2017      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, août  2017';



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_getrecord (p_id IN wk_spearreferencedata.wrd_id%TYPE)
      RETURN wk_spearreferencedata%ROWTYPE
   /*-----------------------------------------------------------------*/
   IS
      l_recwk_spearreferencedata   wk_spearreferencedata%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recwk_spearreferencedata
        FROM wk_spearreferencedata
       WHERE wrd_id = p_id;

      RETURN l_recwk_spearreferencedata;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
END pkg_wk_spearreferencedata;
/

