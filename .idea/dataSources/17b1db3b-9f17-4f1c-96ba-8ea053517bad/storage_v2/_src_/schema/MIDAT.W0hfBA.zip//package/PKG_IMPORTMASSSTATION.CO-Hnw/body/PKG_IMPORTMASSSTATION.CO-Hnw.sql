create PACKAGE BODY       pkg_importmassstation
AS
   /******************************************************************************
      NAME:       pkg_importmassstation
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.05.2014      burrif       1. Created this package.
      2.0         11.07.2017     burrif       2. Fonctionnalité version 2
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 2.0, juillet  2017' ;

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_delete (p_ims_id IN importmassstation.ims_id%TYPE)
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importmassstation
            WHERE ims_id = p_ims_id;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_invalidstationbyoid (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_oid            IN     importmassstation.ims_oid%TYPE,
      p_returnstatus      OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      pkg_debug.p_write ('PKG_IMPORTMASSSTATION.p_invalidstationbyoid',
                         ' p_iph_id=' || p_iph_id || ' p_oid=' || p_oid);

      UPDATE importmassstation
         SET ims_validstatus = pkg_constante.cst_validstatusnotok
       WHERE     ims_oid = p_oid
             AND ims_id IN (SELECT imh_ims_id
                              FROM importmassdataheader
                             WHERE imh_iph_id = p_iph_id);

      UPDATE importmassdataheader
         SET imh_validstatus = pkg_constante.cst_validstatusnotok
       WHERE imh_ims_id IN
                (SELECT ims_id
                   FROM importmassstation
                  WHERE     ims_oid = p_oid
                        AND ims_id IN (SELECT imh_ims_id
                                         FROM importmassdataheader
                                        WHERE imh_iph_id = p_iph_id));
   EXCEPTION
      WHEN OTHERS
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
   END;

   /*-----------------------------------------------------------------*/
   FUNCTION f_getrecordbyoid (
      p_ins_id   IN importmassstation.ims_ins_id%TYPE,
      p_oid      IN importmassstation.ims_oid%TYPE)
      RETURN importmassstation%ROWTYPE
   /*-----------------------------------------------------------------*/
   IS
      l_recimportmassstation   importmassstation%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recimportmassstation
        FROM importmassstation
       WHERE ims_ins_id = p_ins_id AND ims_oid = p_oid;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;



   /*----------------------------------------------------------------*/
   FUNCTION f_getrecmassdataheader (
      p_ims_id   IN importmassstation.ims_id%TYPE)
      RETURN importmassdataheader%ROWTYPE
   /*-----------------------------------------------------------------*/
   IS
      l_recimportmassstation      importmassstation%ROWTYPE;
      l_recimportmassdataheader   importmassdataheader%ROWTYPE;
   BEGIN
      l_recimportmassstation := pkg_importmassstation.f_getrecord (p_ims_id);

      IF l_recimportmassstation.ims_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      l_recimportmassdataheader :=
         pkg_importmassdataheader.f_getrecord (
            l_recimportmassstation.ims_imh_id);
      RETURN l_recimportmassdataheader;
   END;


   /*-----------------------------------------------------------------*/
   PROCEDURE p_deleteconditionnal (
      p_ims_id   IN importmassdataheader.imh_ims_id%TYPE)
   /*-----------------------------------------------------------------*/
   IS
   -- Supprime la sation si elle n'est plus référencé dans  aucun header
   BEGIN
      DELETE FROM importmassstation
            WHERE     ims_id NOT IN (SELECT imh_ims_id
                                       FROM importmassdataheader)
                  AND ims_id = p_ims_id;

      NULL;
   END;

   /*-------------------------------------------------------------------------------------------------*/
   PROCEDURE p_checkifstationallreadeyexist (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*-------------------------------------------------------------------------------------------------*/
   IS
      -- On cherche les stations déjà sauvées qui sont dans un rayon de tolérance
      -- Utilisé lors de la validation

      CURSOR l_station
      IS
         SELECT *
           FROM importmassstation
          WHERE     ims_id IN (SELECT imh_ims_id
                                 FROM importmassdataheader
                                WHERE imh_iph_id = p_iph_id)
                AND ims_oid IS NULL
                AND ims_validstatus = pkg_constante.cst_validstatuspending;

      l_reccursor                 l_station%ROWTYPE;
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
      l_sst_id                    samplestation.sst_id%TYPE;
      l_distance                  NUMBER;
      l_coordinate                VARCHAR2 (100);
   /*
              AND pkg_sdoutil.f_computedistance2d (p_coordinates,
                                                 ims_coordinates) <
                     pkg_samplestation.cst_rayontolerance;
                     */
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);

      OPEN l_station;

      LOOP
         FETCH l_station INTO l_reccursor;

         EXIT WHEN l_station%NOTFOUND;
         pkg_samplestation.p_getnearsst_id (
            l_reccursor.ims_coordinates,
            l_recimportprotocolheader.iph_ins_id_principal,
            l_sst_id,
            l_distance);

         IF NVL (l_distance, pkg_codevalue.f_get_midatparam_rayontol + 1) <=
               pkg_codevalue.f_get_midatparam_rayontol
         THEN
            /*
           Les coordonnées (%p1%) fournies dans la feuille Excel pour cette station sont à une distance %p2% de celles déjà enregistrées dans la banque de données pour la même station. Cette distance est dans les limites de tolérance (%p3%)
           qui permettent le remplacement automatique des coordonnées fournies par celles déjà existantes.
           */
            l_coordinate :=
                  TO_CHAR (l_reccursor.ims_coordinates.sdo_point.x)
               || '; '
               || TO_CHAR (l_reccursor.ims_coordinates.sdo_point.y);
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               NULL,
               pkg_exception.cst_distanceininfolimit,
               NULL,
               l_coordinate,
               TO_CHAR (l_distance) || ' m',
               TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol) || ' m');
         END IF;
      END LOOP;

      CLOSE l_station;
   END;

   /*--------------------------------------------------------------------------------------------------*/
   PROCEDURE p_consolidatestation (
      p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                    IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id                    IN     language.lan_id%TYPE,
      p_returnstatus                 OUT NUMBER)
   /*-------------------------------------------------------------------------------------------------*/
   IS
   /* Après avoir construit les stations  pkg_validatemassstation.p_buildimportstation
         on pourrait se retrouver avec plusieurs enregistrement de la même station
        avec des valeur x et Y identique mais un z différents.
        Cette procédure permet du supprimer les doublons
        Si
        Cette procédure doit être appelé après pkg_validatemassstation.p_main.
        Les stations définis ont déjà été contrôler avec les controle suivant:
        - On identifie les stations sans OID qui sont dans un rayon de tolérance défini pour les fusionner
        -- On identifie les stations pour lesquelle le même OID est défini alors que les coordonnées sont hors des tolérances admise
       -- On identifie les stations avec OID qui sont proches (rayon de tolérance) de station sans OID. Les station sans OID
         qui répondent à ce critère sont fusionner avec les stations avec OID.
         -- On cherche dans la table SAMPLESTATION les stations qui peuvent être associées ( coordonnées dans le rayon de tolérance)
          --Permet de vérifier que la station avec OID a les même coordonnées que la station avec l'OID équivalent dans la table SAMPLESTATION
         --  On invalide les entrées de IMPORTMASSDATAHEADER qui référencie une station invalide

    Le status de validité des stations peut être :


   cst_validstatuspending   CONSTANT CHAR (1) := 'P';
   cst_validstatusnotok     CONSTANT CHAR (1) := 'N';
   cst_validstatusmerged    CONSTANT CHAR (1) := 'M';
         */



   BEGIN
      NULL;
   END;



   /*-------------------------------------------------------------------------------------------------*/
   PROCEDURE p_saveprotocolmassstation (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_lan_id                    IN language.lan_id%TYPE,
      p_usr_id                    IN sampleprotocolgrnd.spd_usr_id_create%TYPE)
   /*------------------------------------------------------------------------------------------------*/
   IS
      /* Entre la validtion et la confirmation il est possible que la station disparaisse */
      l_smf_id                    sampleheadermassfile.smf_id%TYPE;

      CURSOR l_headerforstation (p_ims_id IN importmassstation.ims_id%TYPE)
      IS
         SELECT importmassdataheader.*
           FROM importmassdataheader
          WHERE imh_ims_id = p_ims_id;

      l_recheaderforstation       l_headerforstation%ROWTYPE;


      CURSOR l_liststation
      IS
         SELECT importmassstation.*
           FROM importmassstation
          WHERE     ims_validstatus != pkg_constante.cst_validstatusnotok
                AND ims_validstatus != pkg_constante.cst_validstatusmerged
                AND ims_id IN
                       (SELECT imh_ims_id
                          FROM importmassdataheader
                         WHERE imh_iph_id = p_recimportprotocolheader.iph_id)
                AND ims_sst_id IS NULL;

      l_recliststation            l_liststation%ROWTYPE;
      l_sst_id                    samplestation.sst_id%TYPE;
      l_sst_id_new                samplestation.sst_id%TYPE;
      l_sst_id_recalculated       samplestation.sst_id%TYPE;
      l_reccodevaluelocality      codevalue%ROWTYPE;
      l_reccodevaluewatercourse   codevalue%ROWTYPE;
      l_reccodevaluecalledplace   codevalue%ROWTYPE;
      l_ssi_id                    samplestationitem.ssi_id%TYPE;
      l_oidcalculated             samplestation.sst_oid_calculated%TYPE;
      l_oidprovided               samplestation.sst_oid_provided%TYPE;
      l_oid                       samplestation.sst_oid%TYPE;
      l_distance                  NUMBER;
      l_gwn25name                 VARCHAR2 (256);
   BEGIN
      l_sst_id_new := NULL;
      l_reccodevaluelocality :=
         pkg_codevalue.f_getfromcode (
            pkg_codevalue.cst_midatstitmty_locality,
            pkg_codereference.cst_crf_midatstitmty);
      l_reccodevaluewatercourse :=
         pkg_codevalue.f_getfromcode (
            pkg_codevalue.cst_midatstitmty_watercourse,
            pkg_codereference.cst_crf_midatstitmty);
      l_reccodevaluecalledplace :=
         pkg_codevalue.f_getfromcode (
            pkg_codevalue.cst_midatstitmty_calledplace,
            pkg_codereference.cst_crf_midatstitmty);

      OPEN l_liststation;

      LOOP
         FETCH l_liststation INTO l_recliststation;

         EXIT WHEN l_liststation%NOTFOUND;

         /* Entre la validation et la confirmation il est possible que la station disparaisse */
         /* A voir pour le traitement des statons de proximité
                  pkg_samplestation.p_getnearsst_id (
                     l_recliststation.ims_coordinates,
                     p_recimportprotocolheader.iph_ins_id_principal,
                     l_sst_id_recalculated,
                     l_distance);

                  IF NVL (l_distance, pkg_samplestation.cst_rayontolerance + 1) <=
                        pkg_samplestation.cst_rayontolerance
                  THEN
                     pkg_debug.p_write (
                        'PKG_IMPORTMASSSTATION.p_saveprotocolmassstation',
                           ' l_sst_id_recalculated`'
                        || l_sst_id_recalculated
                        || ' Distance '
                        || l_distance
                        || 'l_recliststation.ims_id '
                        || l_recliststation.ims_id);
                     l_sst_id_new := l_sst_id_recalculated;
                  ELSE
                     l_sst_id_new := NULL;
                  END IF;
                  */



         IF l_sst_id_new IS NULL
         THEN
            IF NOT l_recliststation.ims_oid IS NULL
            THEN
               l_oidcalculated := NULL;
               l_oidprovided := l_recliststation.ims_oid;
               l_oid := l_recliststation.ims_oid;
            ELSE
               l_oid :=
                  pkg_samplestation.f_calculateoid (
                     p_recimportprotocolheader.iph_ins_id_principal);
               l_oidcalculated := l_oid;
               l_oidprovided := NULL;
            END IF;

            pkg_debug.p_write (
               'PKG_IMPORTMASSSTATION.p_saveprotocolmassstation',
               'P_WRITE(l_oid=' || l_oid);


            pkg_samplestation.p_write (
               p_lan_id,
               l_oid,
               l_oidcalculated,
               l_oidprovided,
               p_recimportprotocolheader.iph_ins_id_principal,
               l_recliststation.ims_coordinates.sdo_point.x,
               l_recliststation.ims_coordinates.sdo_point.y,
                l_recliststation.ims_z,
               l_recliststation.ims_cvl_id_elevationorigin,
               l_recliststation.ims_elevationprecision,
               NULL,                                                 -- Title,
               l_recliststation.ims_gewissnr,
               p_usr_id,
               l_recliststation.ims_cvl_id_canton,
               l_sst_id);
            pkg_importmassdataheader.p_update_imh_sst_id_by_ims_id (
               l_recliststation.ims_id,
               l_sst_id,
               p_usr_id);
         ELSE
            l_sst_id := l_sst_id_new;
         END IF;

         -- Une station peut découler de plusieurs IMPORTMASSDATAHEADER. Il peut donc y avoir plusieurs localités, lieu-dits et rivières
         OPEN l_headerforstation (l_recliststation.ims_id);

         LOOP
            FETCH l_headerforstation INTO l_recheaderforstation;

            EXIT WHEN l_headerforstation%NOTFOUND;

            IF NOT l_recheaderforstation.imh_locality IS NULL
            THEN
               pkg_samplestationitem.p_writeifnotexist (
                  l_sst_id,
                  p_lan_id,
                  l_reccodevaluelocality.cvl_id,
                  l_recheaderforstation.imh_locality,
                  p_usr_id,
                  l_ssi_id);
            END IF;

            IF NOT l_recheaderforstation.imh_watercourse IS NULL
            THEN
               pkg_samplestationitem.p_writeifnotexist (
                  l_sst_id,
                  p_lan_id,
                  l_reccodevaluewatercourse.cvl_id,
                  l_recheaderforstation.imh_watercourse,
                  p_usr_id,
                  l_ssi_id);
            END IF;

            IF NOT l_recheaderforstation.imh_calledplace IS NULL
            THEN
               pkg_samplestationitem.p_writeifnotexist (
                  l_sst_id,
                  p_lan_id,
                  l_reccodevaluecalledplace.cvl_id,
                  l_recheaderforstation.imh_calledplace,
                  p_usr_id,
                  l_ssi_id);
            END IF;
         END LOOP;

         CLOSE l_headerforstation;

         -- On ajoute aussi le nom découlant du gewissnr si il n'existe pas
         IF NVL (l_recliststation.ims_gewissnr, 0) != 0
         THEN
            l_gwn25name :=
               pkg_gis.f_returnname (l_recliststation.ims_gewissnr);

            IF l_gwn25name IS NULL
            THEN
               pkg_samplestationitem.p_writeifnotexist (
                  l_sst_id,
                  p_lan_id,
                  l_reccodevaluewatercourse.cvl_id,
                  l_gwn25name,
                  p_usr_id,
                  l_ssi_id);
            END IF;
         END IF;

         IF     NOT l_sst_id IS NULL
            AND NOT l_recliststation.ims_sst_id_oidlink IS NULL
         THEN
            pkg_samplestation.p_update_sst_sst_id (
               l_sst_id,
               l_recliststation.ims_sst_id_oidlink,
               p_usr_id);
         END IF;
      END LOOP;

      CLOSE l_liststation;
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_processwhensamecoordinates (
      p_ims_id_1   IN importmassstation.ims_id%TYPE,
      p_ims_id_2   IN importmassstation.ims_id%TYPE,
      p_usr_id     IN importmassstation.ims_usr_id_modify%TYPE)
   /*---------------------------------------------------------------*/
   IS
      /*----------------------------------------------------------------
       Cette procédure est appelée lorsque il existe deux stations
       distinctes séparées par une distance dans la tolérance de fusion
       des deux stations
      */
      l_importmassstation_1   importmassstation%ROWTYPE;
      l_importmassstation_2   importmassstation%ROWTYPE;
      l_ims_id_concerve       importmassstation.ims_id%TYPE;
      l_ims_id_supprime       importmassstation.ims_id%TYPE;
   BEGIN
      IF p_ims_id_1 = p_ims_id_2
      THEN
         RETURN;
      END IF;

      l_ims_id_concerve := p_ims_id_1;
      l_ims_id_supprime := p_ims_id_2;
      pkg_importmassdataheader.p_update_imh_ims_id (l_ims_id_concerve,
                                                    l_ims_id_supprime,
                                                    p_usr_id);

      pkg_importmassstation.p_updatevalidstatus (
         l_ims_id_supprime,
         pkg_importprotocolheader.cst_validstatusmerged);
      NULL;
   END;

   /*-------------------------------------------------------------*/

   FUNCTION f_getrecord (p_ims_id importmassstation.ims_id%TYPE)
      RETURN importmassstation%ROWTYPE
   /*-------------------------------------------------------------*/
   IS
      l_recimportmassstation   importmassstation%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recimportmassstation
        FROM importmassstation
       WHERE ims_id = p_ims_id;

      RETURN l_recimportmassstation;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-----------------------------------------------------------------------------------*/

   PROCEDURE p_deletebyimh_id (p_imh_id IN importmassstation.ims_imh_id%TYPE)
   /*-----------------------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importmassstation
            WHERE ims_imh_id = p_imh_id;
   END;

   /*------------------------------------------------------------------------------------*/

   PROCEDURE p_updatevalidstatus (
      p_ims_id        IN importmassstation.ims_id%TYPE,
      p_validstatus   IN importmassstation.ims_validstatus%TYPE)
   /*-----------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE importmassstation
         SET ims_validstatus = p_validstatus
       WHERE ims_id = p_ims_id;

      IF p_validstatus = pkg_constante.cst_validstatusnotok
      THEN
         UPDATE importmassdataheader
            SET imh_validstatus = p_validstatus
          WHERE imh_ims_id = p_ims_id;

         NULL;
      END IF;
   END;

   /*------------------------------------------------------------------------------------*/

   PROCEDURE p_updatevalidstatusbyoid (
      p_iph_id        IN importmassdataheader.imh_iph_id%TYPE,
      p_oid           IN importmassstation.ims_oid%TYPE,
      p_validstatus   IN importmassstation.ims_validstatus%TYPE)
   /*------------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE importmassstation
         SET ims_validstatus = p_validstatus
       WHERE     ims_oid = p_oid
             AND ims_imh_id IN (SELECT imh_id
                                  FROM importmassdataheader
                                 WHERE imh_iph_id = p_iph_id);

      IF p_validstatus = pkg_constante.cst_validstatusnotok
      THEN
         UPDATE importmassdataheader
            SET imh_validstatus = p_validstatus
          WHERE imh_ims_id IN
                   (SELECT ims_id
                      FROM importmassstation
                     WHERE     ims_oid = p_oid
                           AND ims_imh_id IN (SELECT imh_id
                                                FROM importmassdataheader
                                               WHERE imh_iph_id = p_iph_id));

         NULL;
      END IF;
   END;



   /*------------------------------------------------------------------------------------*/

   PROCEDURE p_update_ims_cvl_id_canton (
      p_ims_id              IN importmassstation.ims_id%TYPE,
      p_ims_cvl_id_canton   IN importmassstation.ims_cvl_id_canton%TYPE,
      p_usr_id              IN importmassstation.ims_usr_id_modify%TYPE)
   /*------------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE importmassstation
         SET ims_cvl_id_canton = p_ims_cvl_id_canton,
             ims_usr_id_modify = p_usr_id
       WHERE ims_id = p_ims_id;
   END;

   /*------------------------------------------------------------------------------------*/

   PROCEDURE p_update_ims_sst_id (
      p_ims_id       IN importmassstation.ims_id%TYPE,
      p_ims_sst_id   IN importmassstation.ims_sst_id%TYPE,
      p_usr_id       IN importmassstation.ims_usr_id_modify%TYPE)
   /*------------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE importmassstation
         SET ims_sst_id = p_ims_sst_id, ims_usr_id_modify = p_usr_id
       WHERE ims_id = p_ims_id;
   END;

   /*-----------------------------------------------------------------------------------*/
   PROCEDURE p_deletebyiph_id (p_iph_id IN importprotocolheader.iph_id%TYPE)
   /*-----------------------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importmassstation
            WHERE ims_id IN (SELECT imh_ims_id
                               FROM importmassdataheader
                              WHERE imh_iph_id = p_iph_id);
   END;

   /*----------------------------------------------------------------------------------*/

   PROCEDURE p_write_old (
      p_lan_id                   IN     language.lan_id%TYPE,
      p_oid                      IN     importmassstation.ims_oid%TYPE,
      p_ins_id                   IN     importmassstation.ims_ins_id%TYPE,
      p_coordinate_x             IN     NUMBER,
      p_coordinate_y             IN     NUMBER,
      p_coordinate_z             IN     NUMBER,
      p_cvl_id_elevationorigin   IN     importmassstation.ims_cvl_id_elevationorigin%TYPE,
      p_elevationprecision       IN     importmassstation.ims_elevationprecision%TYPE,
      p_title                    IN     importmassstation.ims_title%TYPE,
      p_usr_id                   IN     importmassstation.ims_usr_id_create%TYPE,
      p_id                          OUT importmassstation.ims_id%TYPE)
   /*---------------------------------------------------------------------------------*/
   IS
      /* Attention: IMS_IMH_ID n'est pas pertinent  (doit être supprimé) car une même station
                           peut concerner plusieurs IMH_ID */
      l_sdo_geometry   MDSYS.sdo_geometry;
      l_ssi_id         importmassstation.ims_id%TYPE;
   BEGIN
      pkg_debug.p_write ('PKG_IMPORTMASSSTATION.p_buildimportstation',
                         ' p_coordinate_z=' || p_coordinate_z);
      -- La coordonnee z doit être stockée avec la valeur NULL si le z n'est pas défini
      l_sdo_geometry :=
         pkg_sdoutil.f_buildsdo_geometry (p_coordinate_x,
                                          p_coordinate_y,
                                          p_coordinate_z);


      p_id := seq_importmassstation.NEXTVAL;

      INSERT INTO importmassstation (ims_id,
                                     ims_oid,
                                     ims_ins_id,
                                     ims_coordinates,
                                     ims_cvl_id_elevationorigin,
                                     ims_elevationprecision,
                                     ims_title,
                                     ims_usr_id_create,
                                     ims_usr_create_date)
           VALUES (p_id,
                   p_oid,
                   p_ins_id,
                   l_sdo_geometry,
                   p_cvl_id_elevationorigin,
                   p_elevationprecision,
                   p_title,
                   p_usr_id,
                   SYSDATE);
   END;

   /*----------------------------------------------------------------------------------*/

   PROCEDURE p_write (
      p_lan_id                   IN     language.lan_id%TYPE,
      p_oid                      IN     importmassstation.ims_oid%TYPE,
      p_ins_id                   IN     importmassstation.ims_ins_id%TYPE,
      p_coordinate_x             IN     NUMBER,
      p_coordinate_y             IN     NUMBER,
      p_coordinate_z             IN     NUMBER,
      p_cvl_id_elevationorigin   IN     importmassstation.ims_cvl_id_elevationorigin%TYPE,
      p_elevationprecision       IN     importmassstation.ims_elevationprecision%TYPE,
      p_title                    IN     importmassstation.ims_title%TYPE,
      p_usr_id                   IN     importmassstation.ims_usr_id_create%TYPE,
      p_id                          OUT importmassstation.ims_id%TYPE)
   /*---------------------------------------------------------------------------------*/
   IS
      /* Attention: IMS_IMH_ID n'est pas pertinent  (doit être supprimé) car une même station
                           peut concerner plusieurs IMH_ID */
      l_sdo_geometry   MDSYS.sdo_geometry;
      l_ssi_id         importmassstation.ims_id%TYPE;
   BEGIN
      pkg_debug.p_write ('PKG_IMPORTMASSSTATION.p_buildimportstation',
                         ' p_coordinate_z=' || p_coordinate_z);
      -- La coordonnee z doit être stockée avec la valeur NULL si le z n'est pas défini
      l_sdo_geometry :=
         pkg_sdoutil.f_buildsdo_geometry (p_coordinate_x, p_coordinate_y);


      p_id := seq_importmassstation.NEXTVAL;

      INSERT INTO importmassstation (ims_id,
                                     ims_oid,
                                     ims_ins_id,
                                     ims_coordinates,
                                     ims_z,
                                     ims_cvl_id_elevationorigin,
                                     ims_elevationprecision,
                                     ims_title,
                                     ims_usr_id_create,
                                     ims_usr_create_date)
           VALUES (p_id,
                   p_oid,
                   p_ins_id,
                   l_sdo_geometry,
                   p_coordinate_z,
                   p_cvl_id_elevationorigin,
                   p_elevationprecision,
                   p_title,
                   p_usr_id,
                   SYSDATE);
   END;
END;
/

