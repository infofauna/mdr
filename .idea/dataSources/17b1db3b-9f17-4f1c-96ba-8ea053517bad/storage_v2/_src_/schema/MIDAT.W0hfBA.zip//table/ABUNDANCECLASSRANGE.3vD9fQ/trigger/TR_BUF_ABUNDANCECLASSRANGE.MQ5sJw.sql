create trigger TR_BUF_ABUNDANCECLASSRANGE
    before update
    on ABUNDANCECLASSRANGE
    for each row
DECLARE
BEGIN
 
   :new.ACR_moddate := SYSDATE;
   :new.ACR_moduser := USER;
END tr_buf_ABUNDANCECLASSRANGE;

/

