create PACKAGE       pkg_migr_ibch2019_buildhistory
AS
    /******************************************************************************
       NAME:       pkg_migr_ibch2019_buildhistory
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        3.07.2020      burrif       1. Created this package.
    ******************************************************************************/
    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2020';

    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_main;
END pkg_migr_ibch2019_buildhistory;
/

