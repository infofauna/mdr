create PACKAGE       pkg_protocolmappinggrid
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLMAPPINGGRID
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecord (p_pmg_id IN protocolmappinggrid.pmg_id%TYPE)
      RETURN protocolmappinggrid%ROWTYPE;

   PROCEDURE p_write (
      p_ptv_id                  IN     protocolmappinggrid.pmg_ptv_id%TYPE,
      p_cvl_id_midatitgrdro     IN     protocolmappinggrid.pmg_cvl_id_midatitgrdro%TYPE,
      p_cvl_id_midatitgrdcl     IN     protocolmappinggrid.pmg_cvl_id_midatitgrdcl%TYPE,
      p_cvl_id_MIDATITGRDCE      IN     protocolmappinggrid.pmg_cvl_id_midatitgrdce%TYPE,
      p_cellrowvalue            IN     protocolmappinggrid.pmg_cellrowvalue%TYPE,
      p_cellcolumnvalue         IN     protocolmappinggrid.pmg_cellcolumnvalue%TYPE,
      p_cvl_code_midatitgrdro   IN     protocolmappinggrid.pmg_cvl_code_midatitgrdro%TYPE,
      p_cvl_code_midatitgrdcl   IN     protocolmappinggrid.pmg_cvl_code_midatitgrdcl%TYPE,
      p_cvl_code_MIDATITGRDCE    IN     protocolmappinggrid.pmg_cvl_code_midatitgrdce%TYPE,
      p_id                         OUT protocolmappinggrid.pmg_id%TYPE);


   PROCEDURE p_update (
      p_id                      IN protocolmappinggrid.pmg_id%TYPE,
      p_ptv_id                  IN protocolmappinggrid.pmg_ptv_id%TYPE,
      p_cvl_id_midatitgrdro     IN protocolmappinggrid.pmg_cvl_id_midatitgrdro%TYPE,
      p_cvl_id_midatitgrdcl     IN protocolmappinggrid.pmg_cvl_id_midatitgrdcl%TYPE,
      p_cvl_id_MIDATITGRDCE      IN protocolmappinggrid.pmg_cvl_id_midatitgrdce%TYPE,
      p_cellrowvalue            IN protocolmappinggrid.pmg_cellrowvalue%TYPE,
      p_cellcolumnvalue         IN protocolmappinggrid.pmg_cellcolumnvalue%TYPE,
      p_cvl_code_midatitgrdro   IN protocolmappinggrid.pmg_cvl_code_midatitgrdro%TYPE,
      p_cvl_code_midatitgrdcl   IN protocolmappinggrid.pmg_cvl_code_midatitgrdcl%TYPE,
      p_cvl_code_MIDATITGRDCE    IN protocolmappinggrid.pmg_cvl_code_midatitgrdce%TYPE);

   FUNCTION f_getrecordbyitemrocol (
      p_ptv_id                IN protocolmappinggrid.pmg_ptv_id%TYPE,
      p_cvl_id_midatitgrdro   IN protocolmappinggrid.pmg_cvl_id_midatitgrdro%TYPE,
      p_cvl_id_midatitgrdcl   IN protocolmappinggrid.pmg_cvl_id_midatitgrdcl%TYPE)
      RETURN protocolmappinggrid%ROWTYPE;

   PROCEDURE p_update (p_protocolmapping IN protocolmappinggrid%ROWTYPE);

   FUNCTION f_getrecordbyitemcell (
      p_ptv_id               IN protocolmappinggrid.pmg_ptv_id%TYPE,
      p_cvl_id_MIDATITGRDCE   IN protocolmappinggrid.pmg_cvl_id_midatitgrdce%TYPE)
      RETURN protocolmappinggrid%ROWTYPE;
END pkg_protocolmappinggrid;
/

