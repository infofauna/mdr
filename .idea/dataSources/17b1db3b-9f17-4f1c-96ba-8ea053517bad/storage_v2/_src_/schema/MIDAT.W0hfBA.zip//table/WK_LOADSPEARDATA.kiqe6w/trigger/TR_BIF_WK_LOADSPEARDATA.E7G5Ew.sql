create trigger TR_BIF_WK_LOADSPEARDATA
    before insert
    on WK_LOADSPEARDATA
    for each row
DECLARE
BEGIN
   IF :new.WLS_ID IS NULL
   THEN
      :new.WLS_ID := seq_WK_LOADSPEARDATA.NEXTVAL;
   END IF;

   :new.WLS_credate := SYSDATE;
   :new.WLS_creuser := USER;
END TR_BIF_WK_LOADSPEARDATA;

/

