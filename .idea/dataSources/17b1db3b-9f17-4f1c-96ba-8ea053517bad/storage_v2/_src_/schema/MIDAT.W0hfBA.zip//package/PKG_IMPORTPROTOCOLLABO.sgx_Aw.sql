create PACKAGE       pkg_importprotocollabo
AS
   /******************************************************************************
      NAME:       PKG_IMPORTPROTOCOLLABO
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        08.10.2013      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_deletebyiphid (p_iph_id IN importprotocollabo.ipl_iph_id%TYPE);

   PROCEDURE p_updatevalidatestatus (
      p_ipl_id   IN importprotocollabo.ipl_id%TYPE,
      p_status   IN importprotocollabo.ipl_validstatus%TYPE,
      p_usr_id   IN importprotocollabo.ipl_usr_id_modify%TYPE);

   FUNCTION f_getrecord (p_ipl_id IN importprotocollabo.ipl_id%TYPE)
      RETURN importprotocollabo%ROWTYPE;

   PROCEDURE p_insert (p_iph_id   IN importprotocollabo.ipl_iph_id%TYPE,
                       p_ptl_id   IN importprotocollabo.ipl_ptl_id%TYPE,
                       p_value    IN importprotocollabo.ipl_value%TYPE);

   PROCEDURE p_countentry (
      p_iph_id               IN     importprotocollabo.ipl_iph_id%TYPE,
      p_countdistincttaxon      OUT NUMBER,
      p_counttaxon              OUT NUMBER);
END pkg_importprotocollabo;
/

