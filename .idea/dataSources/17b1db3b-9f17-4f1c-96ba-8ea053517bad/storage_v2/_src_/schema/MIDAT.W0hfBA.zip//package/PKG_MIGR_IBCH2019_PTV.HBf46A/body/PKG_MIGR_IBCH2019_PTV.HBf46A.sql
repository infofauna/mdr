create PACKAGE BODY       pkg_migr_ibch2019_ptv
AS
    /******************************************************************************
       NAME:       PKG_MIGR_IBCH2019
       PURPOSE:    Modification dans la table PROTOCOLVERSION

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       15.05.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-------------------------------------------------------------------*/
    FUNCTION f_returnversionbytext (p_text IN protocolversion.ptv_text%TYPE)
        RETURN protocolversion%ROWTYPE
    /*-------------------------------------------------------------------*/
    IS
        l_recprotocolversion   protocolversion%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recprotocolversion
          FROM protocolversion
         WHERE UPPER (p_text) = UPPER (ptv_text);

        RETURN l_recprotocolversion;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_deleteversion (p_ptv_id IN protocolversion.ptv_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM protocolversion
              WHERE ptv_id = p_ptv_id;

        pkg_debug.p_write (
            'pkg_migr_ibch2019_ptv.P_DELETEVERSION',
               ' INFO*** Données sur la structure de la version ptv_id='
            || p_ptv_id
            || ' supprimées. Nombre d''enregitrements effacés: '
            || SQL%ROWCOUNT);
        pkg_migr_ibch2019_util.p_recreatesequence ('PROTOCOLMAPPINGLABO',
                                                   'SEQ_PROTOCOLMAPPINGLABO',
                                                   'PTL_ID');
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_deleteversionbytext (p_text IN protocolversion.ptv_text%TYPE)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM protocolversion
              WHERE ptv_text = p_text;
    END;



    /*------------------------------------------------------------------*/
    PROCEDURE p_addversion (p_text     IN     protocolversion.ptv_text%TYPE,
                            p_ptv_id      OUT protocolversion.ptv_id%TYPE,
                            p_exist       OUT BOOLEAN)
    /*------------------------------------------------------------------*/
    IS
        l_reccodevalue          codevalue%ROWTYPE;
        l_reccodevalueversion   codevalue%ROWTYPE;
        l_ptv_id                protocolversion.ptv_id%TYPE;
        l_recprotocolversion    protocolversion%ROWTYPE;
    BEGIN
        pkg_debug.p_write ('pkg_migr_ibch2019_ptl.p_addversion',
                           'INFO*** Ajout de la version: ' || p_text);
        l_recprotocolversion := f_returnversionbytext (p_text);

        IF NOT l_recprotocolversion.ptv_id IS NULL
        THEN
            p_exist := TRUE;
            pkg_debug.p_write (
                'pkg_migr_ibch2019_ptl.p_addversion',
                'INFO*** La version: ' || p_text || ' existe déjà');
            p_ptv_id := l_recprotocolversion.ptv_id;
            RETURN;
        END IF;

        p_exist := FALSE;

        l_reccodevalue :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_protocoltype_laboratory,
                pkg_codereference.cst_crf_midatproto);
        l_reccodevalueversion :=
            pkg_codevalue.f_getfromcode (pkg_codevalue.cst_version_labov3,
                                         pkg_codereference.cst_crf_version);

        IF l_reccodevalueversion.cvl_id IS NULL
        THEN
            raise_application_error (
                -20000,
                   'FATAL*** COde :'
                || pkg_codevalue.cst_version_labov3
                || ' non trouvé',
                TRUE);
        END IF;

        p_ptv_id := seq_protocolversion.NEXTVAL;

        INSERT INTO protocolversion (ptv_id,
                                     ptv_status,
                                     ptv_cvl_id_protocoltype,
                                     ptv_defaultflag,
                                     ptv_text,
                                     ptv_startdate,
                                     ptv_enddate,
                                     ptv_ptv_id_labofrommass,
                                     ptv_massdetailerrortolerance,
                                     ptv_version,
                                     ptv_order,
                                     ptv_cvl_id,
                                     ptv_code)
             VALUES (p_ptv_id,
                     'N',
                     l_reccodevalue.cvl_id,
                     'Y',
                     p_text,
                     TO_DATE ('19/02/2019', 'DD/MM/YYYY'),
                     NULL,
                     NULL,
                     NULL,
                     '3.0',
                     1,
                     l_reccodevalueversion.cvl_id,
                     pkg_codevalue.cst_version_labov3);

        pkg_debug.p_write (
            'pkg_migr_ibch2019_ptl.p_addversion',
               'INFO*** La version: '
            || p_text
            || ' à été créé dans la table  protocolversion');
    END;
END pkg_migr_ibch2019_ptv;
/

