create PACKAGE BODY       pkg_importprotocollabo
AS
   /******************************************************************************
      NAME:       PKG_IMPORTPROTOCOLLABO
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        08.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, juillet 2013';


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------------------------------*/
   PROCEDURE p_updatevalidatestatus (
      p_ipl_id   IN importprotocollabo.ipl_id%TYPE,
      p_status   IN importprotocollabo.ipl_validstatus%TYPE,
      p_usr_id   IN importprotocollabo.ipl_usr_id_modify%TYPE)
   /*----------------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE importprotocollabo
         SET ipl_validstatus = p_status,
             ipl_usr_id_modify = p_usr_id,
             ipl_usr_modify_date = SYSDATE
       WHERE ipl_id = p_ipl_id;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_deletebyiphidatlevel (
      p_iph_id   IN importprotocollabo.ipl_iph_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importprotocollabo
            WHERE ipl_iph_id = p_iph_id;
   END;

   /*-----------------------------------------------------------------------*/
   PROCEDURE p_deletebyiphid (p_iph_id IN importprotocollabo.ipl_iph_id%TYPE)
   /*-----------------------------------------------------------------------------*/
   IS
      CURSOR l_cursorfils                                   -- Fils de l'iphid
      IS
         SELECT iph_id
           FROM importprotocolheader
          WHERE iph_iph_id = p_iph_id;

      l_reccursorfils   l_cursorfils%ROWTYPE;
   BEGIN
      OPEN l_cursorfils;

      LOOP
         FETCH l_cursorfils INTO l_reccursorfils;

         EXIT WHEN l_cursorfils%NOTFOUND;
         p_deletebyiphidatlevel (l_reccursorfils.iph_id);
      END LOOP;

      CLOSE l_cursorfils;

      p_deletebyiphidatlevel (p_iph_id);
   END;

   /*------------------------------------------------------------*/
   FUNCTION f_getrecord (p_ipl_id IN importprotocollabo.ipl_id%TYPE)
      RETURN importprotocollabo%ROWTYPE
   /*------------------------------------------------------------*/
   IS
      l_record   importprotocollabo%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM importprotocollabo
       WHERE ipl_id = p_ipl_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*----------------------------------------------------------------------*/
   PROCEDURE p_insert (p_iph_id   IN importprotocollabo.ipl_iph_id%TYPE,
                       p_ptl_id   IN importprotocollabo.ipl_ptl_id%TYPE,
                       p_value    IN importprotocollabo.ipl_value%TYPE)
   /*---------------------------------------------------------------------*/
   IS
   /* ATTENTION: Utilisé uniquement par JAVA a cause du COMMIT */
   BEGIN
      INSERT INTO importprotocollabo (ipl_iph_id, ipl_ptl_id, ipl_value)
           VALUES (p_iph_id, p_ptl_id, p_value);

      COMMIT;
   END;

   /*---------------------------------------------------------------------*/
   PROCEDURE p_countentry (
      p_iph_id               IN     importprotocollabo.ipl_iph_id%TYPE,
      p_countdistincttaxon      OUT NUMBER,
      p_counttaxon              OUT NUMBER)
   /*----------------------------------------------------------------------*/
   IS
   BEGIN
      SELECT COUNT (*)
        INTO p_countdistincttaxon
        FROM importprotocollabo
       WHERE ipl_iph_id = p_iph_id AND NOT ipl_value IS NULL;

      SELECT SUM (pkg_stringutil.f_validatenumber (ipl_value))
        INTO p_counttaxon
        FROM importprotocollabo
       WHERE ipl_iph_id = p_iph_id AND NOT ipl_value IS NULL;
   END;
END pkg_importprotocollabo;
/

