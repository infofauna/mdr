create PACKAGE BODY       pkg_migr_ibch2019_bls
AS
    /******************************************************************************
       NAME:       pkg_migr_ibch2019_bls
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_getrecordbyorder (
        p_cvl_id_midatindice   IN biologicalstate.bls_cvl_id_midatindice%TYPE,
        p_order                IN biologicalstate.bls_order%TYPE,
        p_ivr_id               IN biologicalstate.bls_ivr_id%TYPE)
        RETURN biologicalstate%ROWTYPE
    /*-------------------------------------------------------------------*/
    IS
        l_recbiologicalliststate   biologicalstate%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recbiologicalliststate
          FROM biologicalstate
         WHERE     bls_cvl_id_midatindice = p_cvl_id_midatindice
               AND bls_order = p_order
               AND bls_ivr_id = p_ivr_id;

        RETURN l_recbiologicalliststate;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_write (
        p_code_midatindice        IN     codevalue.cvl_code%TYPE,
        p_order                   IN     biologicalstate.bls_order%TYPE,
        p_cvl_id_biolstatetxt     IN     biologicalstate.bls_cvl_id_biolstatetxt%TYPE,
        p_cvl_id_colorindex       IN     biologicalstate.bls_cvl_id_colorindex%TYPE,
        p_cvl_id_colorindextext   IN     biologicalstate.bls_cvl_id_colorindextext%TYPE,
        p_fromvalue               IN     biologicalstate.bls_fromvalue%TYPE,
        p_tovalue                 IN     biologicalstate.bls_tovalue%TYPE,
        p_literalrange            IN     biologicalstate.bls_literalrange%TYPE,
        p_ivr_id                  IN     biologicalstate.bls_ivr_id%TYPE,
        p_id                         OUT biologicalstate.bls_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
        l_reccodevalue         codevalue%ROWTYPE;
        l_recbiologicalstate   biologicalstate%ROWTYPE;
    BEGIN
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                p_code_midatindice);
        l_recbiologicalstate :=
            f_getrecordbyorder (l_reccodevalue.cvl_id, p_order, p_ivr_id);

        IF l_recbiologicalstate.bls_id IS NULL
        THEN
            pkg_biologicalstate.p_write (p_order,
                                         l_reccodevalue.cvl_id,
                                         p_cvl_id_biolstatetxt,
                                         p_cvl_id_colorindex,
                                         p_cvl_id_colorindextext,
                                         p_fromvalue,
                                         p_tovalue,
                                         p_literalrange,
                                         p_ivr_id,
                                         p_id);
        END IF;



        NULL;
    END;

    /*----------------------------------------------------------------------------*/
    PROCEDURE p_delete
    /*----------------------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM biologicalstate
              WHERE bls_cvl_id_midatindice =
                    (SELECT cvl_id
                       FROM codevalue
                            INNER JOIN codereference ON cvl_crf_id = crf_id
                      WHERE     cvl_code =
                                pkg_codevalue.cst_midatindice_ibch2019
                            AND crf_code =
                                pkg_codereference.cst_crf_midatindice);
    END;


    /*------------------------------------------------------------------*/
    PROCEDURE p_insertall
    /*------------------------------------------------------------------*/
    IS
        l_recbiologicalstate   biologicalstate%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
        l_id                   biologicalstate.bls_id%TYPE;
        l_reccodevalue_ibch    codevalue%ROWTYPE;
        l_recindiceversion     indiceversion%ROWTYPE;
        l_recindiceversion2010     indiceversion%ROWTYPE;
        l_done                 BOOLEAN;
    BEGIN
        l_recindiceversion :=
            pkg_indiceversion.f_getrecordbyversion (
                'IBCH2019',
                pkg_codevalue.cst_midatindice_ibch);
                 l_recindiceversion2010 :=
            pkg_indiceversion.f_getrecordbyversion (
                'IBCH 2010',
                pkg_codevalue.cst_midatindice_ibch);       
        pkg_migr_ibch2019_util.p_addcolumn ('BIOLOGICALSTATE',
                                            'BLS_IVR_ID',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_recreatesequence ('BIOLOGICALSTATE',
                                                   'SEQ_BIOLOGICALSTATE',
                                                   'BLS_ID');
        l_reccodevalue_ibch :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_ibch);
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_ibch);
        l_recbiologicalstate :=
            f_getrecordbyorder (l_reccodevalue_ibch.cvl_id,
                                1,
                                l_recindiceversion2010.ivr_id);

        p_write (pkg_codevalue.cst_midatindice_ibch,
                 1,                               --p_order                  ,
                 l_recbiologicalstate.bls_cvl_id_biolstatetxt, ---  p_cvl_id_biolstatetxt
                 l_recbiologicalstate.bls_cvl_id_colorindex, -- p_cvl_id_colorindex
                 l_recbiologicalstate.bls_cvl_id_colorindextext, -- p_cvl_id_colorindextext
                 0.8,                                            --p_fromvalue
                 1.0,                                             -- p_tovalue
                 '0.8   ≤  IBCH ≤ 1.0 ',                 -- p_literalrange
                 l_recindiceversion.ivr_id,
                 l_id);

        l_recbiologicalstate :=
            f_getrecordbyorder (l_reccodevalue_ibch.cvl_id,
                                2,
                                l_recindiceversion2010.ivr_id);

        p_write (pkg_codevalue.cst_midatindice_ibch,
                 2,                               --p_order                  ,
                 l_recbiologicalstate.bls_cvl_id_biolstatetxt, ---  p_cvl_id_biolstatetxt
                 l_recbiologicalstate.bls_cvl_id_colorindex, -- p_cvl_id_colorindex
                 l_recbiologicalstate.bls_cvl_id_colorindextext, -- p_cvl_id_colorindextext
                 0.6,                                            --p_fromvalue
                 0.799999999,                                     -- p_tovalue
                 '0.6   ≤  IBCH < 0.8 ',                   -- p_literalrange
                 l_recindiceversion.ivr_id,
                 l_id);

        l_recbiologicalstate :=
            f_getrecordbyorder (l_reccodevalue_ibch.cvl_id,
                                3,
                                l_recindiceversion2010.ivr_id);

        p_write (pkg_codevalue.cst_midatindice_ibch,
                 3,                               --p_order                  ,
                 l_recbiologicalstate.bls_cvl_id_biolstatetxt, ---  p_cvl_id_biolstatetxt
                 l_recbiologicalstate.bls_cvl_id_colorindex, -- p_cvl_id_colorindex
                 l_recbiologicalstate.bls_cvl_id_colorindextext, -- p_cvl_id_colorindextext
                 0.4,                                            --p_fromvalue
                 0.599999999,                                     -- p_tovalue
                 '0.4   ≤  IBCH < 0.6 ',                   -- p_literalrange
                 l_recindiceversion.ivr_id,
                 l_id);
        l_recbiologicalstate :=
            f_getrecordbyorder (l_reccodevalue_ibch.cvl_id,
                                4,
                                l_recindiceversion2010.ivr_id);

        p_write (pkg_codevalue.cst_midatindice_ibch,
                 4,                               --p_order                  ,
                 l_recbiologicalstate.bls_cvl_id_biolstatetxt, ---  p_cvl_id_biolstatetxt
                 l_recbiologicalstate.bls_cvl_id_colorindex, -- p_cvl_id_colorindex
                 l_recbiologicalstate.bls_cvl_id_colorindextext, -- p_cvl_id_colorindextext
                 0.2,                                            --p_fromvalue
                 0.399999999,                                     -- p_tovalue
                 '0.2   ≤  IBCH < 0.4 ',                   -- p_literalrange
                 l_recindiceversion.ivr_id,
                 l_id);
        l_recbiologicalstate :=
            f_getrecordbyorder (l_reccodevalue_ibch.cvl_id,
                                5,
                                l_recindiceversion2010.ivr_id);

        p_write (pkg_codevalue.cst_midatindice_ibch,
                 5,                               --p_order                  ,
                 l_recbiologicalstate.bls_cvl_id_biolstatetxt, ---  p_cvl_id_biolstatetxt
                 l_recbiologicalstate.bls_cvl_id_colorindex, -- p_cvl_id_colorindex
                 l_recbiologicalstate.bls_cvl_id_colorindextext, -- p_cvl_id_colorindextext
                 0,                                              --p_fromvalue
                 0.199999999,                                     -- p_tovalue
                 '0   ≤  IBCH < 0.2 ',                     -- p_literalrange
                 l_recindiceversion.ivr_id,
                 l_id);
    END;

    /*---------------------------------------------------------------------------*/
    PROCEDURE p_update_bls_ivr_id
    /*---------------------------------------------------------------------------*/
    /* Doit être exécuté avant p_insertall
    */
    IS
        l_recindiceversion   indiceversion%ROWTYPE;
        
    BEGIN
        l_recindiceversion :=
            pkg_indiceversion.f_getrecordbyversion (
                'IBCH 2010',
                pkg_codevalue.cst_midatindice_ibch);

        UPDATE biologicalstate
           SET bls_ivr_id = l_recindiceversion.ivr_id
         WHERE bls_cvl_id_midatindice =
               l_recindiceversion.ivr_cvl_id_midatindice;

        l_recindiceversion :=
            pkg_indiceversion.f_getrecordbyversion (
                'SPEAR 2017',
                pkg_codevalue.cst_midatindice_spear);

        UPDATE biologicalstate                   -- 2017 et 2014 même légewnde
           SET bls_ivr_id = l_recindiceversion.ivr_id
         WHERE bls_cvl_id_midatindice =
               l_recindiceversion.ivr_cvl_id_midatindice;

        l_recindiceversion :=
            pkg_indiceversion.f_getrecordbyversion (
                'MAKROINDEX 2005',
                pkg_codevalue.cst_midatindice_makroindex);

        UPDATE biologicalstate
           SET bls_ivr_id = l_recindiceversion.ivr_id
         WHERE bls_cvl_id_midatindice =
               l_recindiceversion.ivr_cvl_id_midatindice;


        NULL;
    END;
END;
/

