create PACKAGE       pkg_identifysystematique
AS
   /******************************************************************************
      NAME:       PKG_IDENTIFYSYSTEMATIQUE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        17.03.2016      burrif       1. Created this package.
   ******************************************************************************/
   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_identifiesystematique (
      p_subspecies            IN     importmassdatadetail.imd_subspecies%TYPE,
      p_species               IN     importmassdatadetail.imd_species%TYPE,
      p_genus                 IN     importmassdatadetail.imd_genus%TYPE,
      p_family                IN     importmassdatadetail.imd_family%TYPE,
      p_highertaxon           IN     importmassdatadetail.imd_highertaxon%TYPE,
      p_taxonibch             IN     importmassdatadetail.imd_taxonibch%TYPE,
      p_ptv_id_ibchfrommass   IN     protocolversion.ptv_id%TYPE,
      p_syv_startwith            OUT systvalue.syv_id%TYPE,
      p_crf_id                   OUT codereference.crf_id%TYPE,
      p_flagprecisionmax         OUT CHAR,
      p_returnstatus             OUT NUMBER);
END pkg_identifysystematique;
/

