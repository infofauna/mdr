create PACKAGE       pkg_migr_ibch2019_ivr
AS
    /******************************************************************************
       NAME:       pkg_migr_ibch2019_ivr
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        3.07.2020      burrif       1. Created this package.
    ******************************************************************************/
    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2020';

    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_write (
        p_current       IN     indiceversion.ivr_current%TYPE,
        p_midatindice   IN     codevalue.cvl_code%TYPE,
        p_ptv_id        IN     indiceversion.ivr_ptv_id%TYPE,
        p_version       IN     indiceversion.ivr_version%TYPE,
        p_designation          indiceversion.ivr_designation%TYPE,
        p_id               OUT indiceversion.ivr_id%TYPE);

    PROCEDURE p_addcolumn;

    PROCEDURE p_updateorder;

    PROCEDURE p_addindiceversion (p_newversiontext              IN VARCHAR2,
                                  p_newibchindiceversion        IN VARCHAR2,
                                  p_newibchindicedesignation    IN VARCHAR2,
                                  p_newspearindiceversion       IN VARCHAR2,
                                  p_newspearindicedesignation   IN VARCHAR2);
END pkg_migr_ibch2019_ivr;
/

