create PACKAGE       pkg_lob
AS
   /******************************************************************************
      NAME:       PKG_LOB
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        27.09.2013      burrif       1. Created this package.
   ******************************************************************************/
   PROCEDURE p_insertprotocol (
      p_iph_id                       importprotocolheader.iph_id%TYPE,
      p_iph_iph_id                   importprotocolheader.iph_iph_id%TYPE,
      p_iph_ins_id_principal         importprotocolheader.iph_ins_id_principal%TYPE,
      p_iph_ins_id_mandatary         importprotocolheader.iph_ins_id_mandatary%TYPE,
      p_iph_ptv_id                   importprotocolheader.iph_ptv_id%TYPE,
      p_iph_cvl_id_midatstat         importprotocolheader.iph_cvl_id_midatstat%TYPE,
      p_iph_per_id_determinator      importprotocolheader.iph_per_id_determinator%TYPE,
      p_iph_cvl_id_systlprec         importprotocolheader.iph_cvl_id_systlprec%TYPE,
      p_iph_cvl_id_systlref          importprotocolheader.iph_cvl_id_systlref%TYPE,
      p_iph_inputfilename            importprotocolheader.iph_inputfilename%TYPE,
      p_iph_sheetname                importprotocolheader.iph_sheetname%TYPE,
      p_directoryref              IN VARCHAR2);


   PROCEDURE p_insertdatatest;
END pkg_lob;
/

