create function setMaxMemorySize(num number) return number
is language java name
 'oracle.aurora.vm.OracleRuntime.setMaxMemorySize(long) returns long';
/

