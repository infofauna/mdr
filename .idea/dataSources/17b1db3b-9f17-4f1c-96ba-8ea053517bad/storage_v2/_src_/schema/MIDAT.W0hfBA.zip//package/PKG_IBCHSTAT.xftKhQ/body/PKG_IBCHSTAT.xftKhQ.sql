create PACKAGE BODY       pkg_ibchstat
AS
    /******************************************************************************
       NAME:       PKG_ibchstat
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        08.10.2019      burrif       1. Created this package.
       1.1        23.01.2020      burrif       2. Identification TAXON_IBCH lorsque non fourni

    ******************************************************************************/



    TYPE t_cursor IS REF CURSOR;


    cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.1, janvier  2020';

    gbl_sph_done                  sampleheader.sph_id%TYPE := -1;

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-------------------------------------------------------------------*/
    FUNCTION f_getsumbytaxonibch_spl (
        p_sph_id   IN sampleheader.sph_id%TYPE,
        p_taxon    IN protocolmappinglabo.ptl_taxa%TYPE)
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
        l_sql      VARCHAR2 (4096);
        l_cursor   t_cursor;
        l_count    NUMBER;
    BEGIN
        l_sql :=
               '
    SELECT COUNT(*) FROM (
SELECT ptl_syv_id, COUNT(*)
                  
  FROM sampleprotocollabo spl1
       INNER JOIN protocolmappinglabo ptl1
       
           ON     ptl1.ptl_syv_id =spl1.spl_syv_id
           INNER JOIN SAMPLEHEADER ON SPH_ID=spl_sph_id
              AND ptl1.ptl_ptv_id =sph_ptv_id          
 WHERE     sph_id ='
            || p_sph_id
            || '
       AND (SELECT ptl_syv_id
              FROM protocolmappinglabo ptl2
             WHERE     UPPER (ptl2.ptl_taxa) = '''
            || p_taxon
            || ''' AND ptl2.ptl_ptv_id = ptl1.ptl_ptv_id) IN
               (    SELECT syv_id
                      FROM systvalue
                CONNECT BY PRIOR syv_syv_id = syv_id
                START WITH syv_id =
                           (SELECT ptl_syv_id
                              FROM protocolmappinglabo ptl3
                             WHERE     ptl3.ptl_syv_id =spl1.spl_syv_id
                                     
                                   AND ptl3.ptl_ptv_id = ptl1.ptl_ptv_id))
                                   GROUP BY ptl_syv_id)';

        OPEN l_cursor FOR l_sql;

        FETCH l_cursor INTO l_count;

        CLOSE l_cursor;

        RETURN l_count;
    END;



    /*-------------------------------------------------------------------*/
    FUNCTION f_getsumbytaxonibch_smx (
        p_sph_id   IN sampleheader.sph_id%TYPE,
        p_taxon    IN protocolmappinglabo.ptl_taxa%TYPE)
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
        l_sql      VARCHAR2 (4096);
        l_cursor   t_cursor;
        l_count    NUMBER;
    BEGIN
        l_sql := 'SELECT COUNT(*) FROM (
    SELECT SMX_TAXONIBCH, COUNT(*)                 
  FROM sampleprotocolmass smx1
       INNER JOIN protocolmappinglabo ptl1
           ON     ptl_taxa = smx_taxonibch
              AND ptl_ptv_id =
                  (SELECT NVL (ptv1.ptv_ptv_id_labofrommass, ptv1.ptv_id)
                     FROM sampleheader sph1
                          INNER JOIN protocolversion ptv1
                              ON sph1.sph_ptv_id = ptv1.ptv_id
                    WHERE sph1.sph_id = smx_sph_id)
 WHERE     smx_sph_id = ' || p_sph_id || '
       AND (SELECT ptl_syv_id
              FROM protocolmappinglabo ptl2
             WHERE     UPPER (ptl2.ptl_taxa) = ''' || p_taxon || '''
                   AND ptl2.ptl_ptv_id = ptl1.ptl_ptv_id) IN
               (    SELECT syv_id
                      FROM systvalue
                CONNECT BY PRIOR syv_syv_id = syv_id
                START WITH syv_id =
                           (SELECT ptl_syv_id
                              FROM protocolmappinglabo ptl3
                             WHERE     UPPER (ptl_taxa) =
                                       UPPER (smx_taxonibch)
                                   AND ptl3.ptl_ptv_id = ptl1.ptl_ptv_id))
                                   GROUP BY SMX_TAXONIBCH)';

        pkg_debug.p_write ('PKG_IBCHSTAT.f_getsumbytaxonibch_smx', l_sql);

        OPEN l_cursor FOR l_sql;

        FETCH l_cursor INTO l_count;

        CLOSE l_cursor;

        RETURN l_count;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_getsumbytaxonibch (
        p_sph_id   IN sampleheader.sph_id%TYPE,
        p_taxon    IN protocolmappinglabo.ptl_taxa%TYPE)
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
        l_recsampleheader      sampleheader%ROWTYPE;
        l_recprotocolversion   protocolversion%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
        l_count                NUMBER;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);

        IF NOT l_recsampleheader.sph_indexvalueibch IS NULL
        THEN
            l_recprotocolversion :=
                pkg_protocolversion.f_getrecord (
                    l_recsampleheader.sph_ptv_id);
            l_reccodevalue :=
                pkg_codevalue.f_getrecord (
                    l_recprotocolversion.ptv_cvl_id_protocoltype);

            IF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_mass
            THEN
                l_count := f_getsumbytaxonibch_smx (p_sph_id, p_taxon);
            ELSE
                l_count := f_getsumbytaxonibch_spl (p_sph_id, p_taxon);
            END IF;

            RETURN l_count;
        ELSE
            RETURN 0;
        END IF;
    END;

    /*------------------------------------------------------------------------*/
    FUNCTION f_hascolumntaxonibchexist (
        p_sph_id   IN sampleprotocolmass.smx_sph_id%TYPE)
        RETURN VARCHAR2
    /*------------------------------------------------------------------------*/
    IS
    BEGIN
        IF f_columntaxonibchexist (p_sph_id)
        THEN
            RETURN pkg_constante.cst_yes;
        ELSE
            RETURN pkg_constante.cst_no;
        END IF;
    END;

    /*------------------------------------------------------------------------*/
    FUNCTION f_columntaxonibchexist (
        p_sph_id   IN sampleprotocolmass.smx_sph_id%TYPE)
        RETURN BOOLEAN
    /*------------------------------------------------------------------------*/
    IS
        l_countline         NUMBER;
        l_countlinefilled   NUMBER;
    BEGIN
        SELECT COUNT (*), COUNT (smx_taxonibch)
          INTO l_countline, l_countlinefilled
          FROM sampleprotocolmass
         WHERE smx_sph_id = p_sph_id;

        IF l_countline = l_countlinefilled
        THEN
            RETURN TRUE;
        ELSE
            RETURN FALSE;
        END IF;
    END;



    /*------------------------------------------------------------------------*/
    FUNCTION f_getibch_bysmxtaxonibch (
        p_sph_id   IN sampleprotocolmass.smx_sph_id%TYPE)
        RETURN NUMBER
    /*-----------------------------------------------------------------------*/
    IS
        CURSOR l_cursor
        IS
            SELECT *
              FROM sampleprotocolmass
             WHERE smx_sph_id = p_sph_id AND NVL (smx_freq1, 0) > 0;

        l_reccursor            l_cursor%ROWTYPE;

        l_recsampleheader      sampleheader%ROWTYPE;
        l_recprotocolversion   protocolversion%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
        l_count                NUMBER;
        l_ptv_id               protocolversion.ptv_id%TYPE;
        l_recprotocolmapping   protocolmappinglabo%ROWTYPE;
        l_ibch                 NUMBER;
        l_error                BOOLEAN := FALSE;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (l_recsampleheader.sph_ptv_id);
        l_ptv_id :=
            NVL (l_recprotocolversion.ptv_ptv_id_labofrommass,
                 l_recprotocolversion.ptv_id);



        pkg_ibch.p_ibchinit;

        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND OR l_error;
            l_recprotocolmapping :=
                pkg_protocolmappinglabo.f_getrecordbytaxa (
                    l_ptv_id,
                    l_reccursor.smx_taxonibch);

            IF NOT l_recprotocolmapping.ptl_id IS NULL
            THEN
                pkg_ibch.p_ibchadddata (l_recprotocolmapping.ptl_id,
                                           l_reccursor.smx_freq1);
            ELSE
                l_error := TRUE;
            END IF;
        END LOOP;


        CLOSE l_cursor;

        pkg_ibch.p_completewithparent (l_ptv_id);


        IF l_error
        THEN
            RETURN -9999;
        END IF;

        IF l_recsampleheader.sph_absolutenumberflag = pkg_constante.cst_yes
        THEN
            l_ibch :=
                pkg_ibch.f_computeibchfrommemory (
                    pkg_ibch.cst_abondanceflag_absolu);
        ELSE
            l_ibch :=
                pkg_ibch.f_computeibchfrommemory (
                    pkg_ibch.cst_abondanceflag_class);
        END IF;

        RETURN l_ibch;
    END;

    /*------------------------------------------------------------------------*/
    FUNCTION f_getibch_bysmx (p_sph_id IN sampleprotocolmass.smx_sph_id%TYPE)
        RETURN NUMBER
    /*-----------------------------------------------------------------------*/
    IS
        CURSOR l_cursor
        IS
            SELECT *
              FROM sampleprotocolmass
             WHERE smx_sph_id = p_sph_id AND NVL (smx_freq1, 0) > 0;

        l_reccursor            l_cursor%ROWTYPE;

        l_recsampleheader      sampleheader%ROWTYPE;
        l_recprotocolversion   protocolversion%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
        l_count                NUMBER;
        l_ptv_id               protocolversion.ptv_id%TYPE;
        l_recprotocolmapping   protocolmappinglabo%ROWTYPE;
        l_ibch                 NUMBER;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (l_recsampleheader.sph_ptv_id);
        l_ptv_id := l_recprotocolversion.ptv_id;
        pkg_debug.p_write ('PKG_IBCHSTAT.f_getibch_bysmx',
                           'ICI l_ptv_id=' || l_ptv_id);



        pkg_ibch.p_ibchinit;
        pkg_ibch.p_initlistibchvaluemass;

        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND;


            pkg_ibch.p_addlistibchvaluemass (l_reccursor.smx_syy_id,
                                                l_reccursor.smx_freq1);
        END LOOP;


        CLOSE l_cursor;

        pkg_ibch.p_convertmass2ibch (l_ptv_id);
        pkg_ibch.p_completewithparent (l_ptv_id);


        IF l_recsampleheader.sph_absolutenumberflag = pkg_constante.cst_yes
        THEN
            l_ibch :=
                pkg_ibch.f_computeibchfrommemory (
                    pkg_ibch.cst_abondanceflag_absolu);
        ELSE
            l_ibch :=
                pkg_ibch.f_computeibchfrommemory (
                    pkg_ibch.cst_abondanceflag_class);
        END IF;

        RETURN l_ibch;
    END;



    /*------------------------------------------------------------------------*/
    FUNCTION f_getibch_smx (p_sph_id IN sampleprotocolmass.smx_sph_id%TYPE)
        RETURN NUMBER
    /*-----------------------------------------------------------------------*/
    IS
    BEGIN
        IF f_columntaxonibchexist (p_sph_id)
        THEN
            RETURN f_getibch_bysmxtaxonibch (p_sph_id);
        ELSE
            RETURN f_getibch_bysmx (p_sph_id);
        END IF;
    END;

    /*------------------------------------------------------------------------*/
    FUNCTION f_getibch_spl (p_sph_id IN sampleprotocolmass.smx_sph_id%TYPE)
        RETURN NUMBER
    /*-----------------------------------------------------------------------*/
    IS
        CURSOR l_cursor
        IS
            SELECT *
              FROM sampleprotocollabo
             WHERE spl_sph_id = p_sph_id AND NVL (spl_frequency, 0) > 0;

        l_reccursor            l_cursor%ROWTYPE;

        l_recsampleheader      sampleheader%ROWTYPE;
        l_recprotocolversion   protocolversion%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
        l_count                NUMBER;
        l_ptv_id               protocolversion.ptv_id%TYPE;
        l_recprotocolmapping   protocolmappinglabo%ROWTYPE;
        l_ibch                 NUMBER;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (l_recsampleheader.sph_ptv_id);
        l_ptv_id := l_recprotocolversion.ptv_id;



        pkg_ibch.p_ibchinit;

        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND;


            pkg_ibch.p_ibchadddata (l_reccursor.spl_ptl_id,
                                       l_reccursor.spl_frequency);
        END LOOP;


        CLOSE l_cursor;

        pkg_ibch.p_completewithparent (l_ptv_id);



        IF l_recsampleheader.sph_absolutenumberflag = pkg_constante.cst_yes
        THEN
            l_ibch :=
                pkg_ibch.f_computeibchfrommemory (
                    pkg_ibch.cst_abondanceflag_absolu);
        ELSE
            l_ibch :=
                pkg_ibch.f_computeibchfrommemory (
                    pkg_ibch.cst_abondanceflag_class);
        END IF;

        RETURN l_ibch;
    END;


    /*---------------------------------------------------------------------*/

    FUNCTION f_getibch (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN NUMBER
    /*---------------------------------------------------------------------*/
    IS
        l_recsampleheader      sampleheader%ROWTYPE;
        l_recprotocolversion   protocolversion%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
        l_count                NUMBER;
    BEGIN
        pkg_debug.p_write (
            'PKG_IBCHSTAT.f_getibch',
            'gbl_sph_done=' || gbl_sph_done || 'p_sph_id=' || p_sph_id);
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);

        IF NOT l_recsampleheader.sph_indexvalueibch IS NULL
        THEN
            IF gbl_sph_done != p_sph_id
            THEN
                l_recprotocolversion :=
                    pkg_protocolversion.f_getrecord (
                        l_recsampleheader.sph_ptv_id);
                l_reccodevalue :=
                    pkg_codevalue.f_getrecord (
                        l_recprotocolversion.ptv_cvl_id_protocoltype);

                IF l_reccodevalue.cvl_code =
                   pkg_codevalue.cst_protocoltype_mass
                THEN
                    l_count := f_getibch_smx (p_sph_id);
                ELSE
                    l_count := f_getibch_spl (p_sph_id);
                END IF;


                gbl_sph_done := p_sph_id;
            ELSE
                l_count := pkg_ibch.f_getgbl_ibchvalue;
            END IF;
        ELSE
            l_count := 0;
            pkg_ibch.p_ibchinit;
        END IF;


        RETURN l_count;
    END;

    /*------------------------------------------------------------------------*/
    FUNCTION f_getibchgi (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN NUMBER
    /*---------------------------------------------------------------------*/
    IS
        l_ibch   NUMBER;
    BEGIN
        l_ibch := f_getibch (p_sph_id);
        RETURN pkg_ibch.f_getgblibchgi;
    END;

    /*------------------------------------------------------------------------*/
    FUNCTION f_getibchvt (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN NUMBER
    /*---------------------------------------------------------------------*/
    IS
        l_ibch   NUMBER;
    BEGIN
        l_ibch := f_getibch (p_sph_id);
        RETURN pkg_ibch.f_getgblibchvt;
    END;

    /*------------------------------------------------------------------------*/
    FUNCTION f_getibchsumtaxon (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN NUMBER
    /*---------------------------------------------------------------------*/
    IS
        l_ibch   NUMBER;
    BEGIN
        l_ibch := f_getibch (p_sph_id);
        RETURN pkg_ibch.f_returncountdistincttaxon;
    END;

    /*------------------------------------------------------------------------*/
    FUNCTION f_getibchsomme_vt (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN NUMBER
    /*---------------------------------------------------------------------*/
    IS
        l_ibch   NUMBER;
    BEGIN
        l_ibch := f_getibch (p_sph_id);
        RETURN pkg_ibch.f_getgbl_ibchsomme_vt;
    END;

    /*-----------------------------------------------------------------------*/
    FUNCTION f_gettaxonindicateur (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN VARCHAR2
    /*-----------------------------------------------------------------------*/
    IS
        l_listtaxonindicateur      pkg_ibch.t_listtaxonindicateur;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_recsampleheader          sampleheader%ROWTYPE;
        l_text                     VARCHAR2 (4096);
        l_ibch                     NUMBER;
        l_indice                   PLS_INTEGER;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);

        IF NOT l_recsampleheader.sph_indexvalueibch IS NULL
        THEN
            l_ibch := f_getibch (p_sph_id);
            l_listtaxonindicateur := pkg_ibch.f_getgbllisttaxonindicateur;
            l_indice := l_listtaxonindicateur.FIRST;

            WHILE NOT l_indice IS NULL
            LOOP
                l_recprotocolmappinglabo :=
                    pkg_protocolmappinglabo.f_getrecord (
                        l_listtaxonindicateur (l_indice));

                IF l_text IS NULL
                THEN
                    l_text := l_recprotocolmappinglabo.ptl_taxa;
                ELSE
                    l_text :=
                        l_text || ', ' || l_recprotocolmappinglabo.ptl_taxa;
                END IF;

                l_indice := l_listtaxonindicateur.NEXT (l_indice);
            END LOOP;

            RETURN l_text;
        ELSE
            RETURN NULL;
        END IF;
    END;
END;
/

