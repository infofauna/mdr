create PACKAGE BODY       pkg_sampledocument
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEDOCUMENT
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       25.07.2013  F.Burri           1. Created this package body.
   ******************************************************************************/

   cst_packageversion   VARCHAR2 (30) := 'Version 1.0, novembre  2013';

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_write (
      p_sph_id     IN     sampledocument.spt_sph_id%TYPE,
      p_ptv_id     IN     sampledocument.spt_ptv_id%TYPE,
      p_filename   IN     sampledocument.spt_filename%TYPE,
      p_title      IN     sampledocument.spt_title%TYPE,
      p_usr_id     IN     sampledocument.spt_usr_id_create%TYPE,
      p_spt_id        OUT sampledocument.spt_id%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_spt_id := seq_sampledocument.NEXTVAL;

      INSERT INTO sampledocument (spt_id,
                                  spt_sph_id,
                                  spt_ptv_id,
                                  spt_filename,
                                  spt_title,
                                  spt_usr_id_create,
                                  spt_usr_create_date)
           VALUES (p_spt_id,
                   p_sph_id,
                   p_ptv_id,
                   p_filename,
                   p_title,
                   p_usr_id,
                   SYSDATE);
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_deleteby_ptv_id (p_sph_id   IN sampledocument.spt_sph_id%TYPE,
                                p_ptv_id   IN sampledocument.spt_ptv_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampledocument
            WHERE spt_ptv_id = p_ptv_id AND spt_sph_id = p_sph_id;
   END;

   /*-----------------------------------------------------------------------*/
   PROCEDURE p_deleteby_sph_id (p_sph_id IN sampledocument.spt_sph_id%TYPE)
   /*----------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampledocument
            WHERE spt_sph_id = p_sph_id;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecord (p_spt_id IN sampledocument.spt_id%TYPE)
      RETURN sampledocument%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record   sampledocument%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM sampledocument
       WHERE spt_id = p_spt_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
END pkg_sampledocument;
/

