create trigger TR_BIF_SAMPLEMKIDETAILGROUP
    before insert
    on SAMPLEMKIDETAILGROUP
    for each row
DECLARE
BEGIN
   IF :new.MKD_id IS NULL
   THEN
      :new.MKD_id := seq_SAMPLEMKIDETAILGROUP.NEXTVAL;
   END IF;

   :new.MKD_credate := SYSDATE;
   :new.MKD_creuser := USER;
END tr_bif_SAMPLEMKIDETAILGROUP;

/

