create PACKAGE       pkg_migr_protocolmassfieldrole
AS
   /******************************************************************************
      NAME:       PKG_MIGR_PROTOCOLMASSFIELDROLE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        16.10.2017      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_load;
END pkg_migr_protocolmassfieldrole;
/

