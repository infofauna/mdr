create PACKAGE BODY       pkg_importprotocolgrid
AS
   /******************************************************************************
      NAME:       PKG_IMPORTPROTOCOLGRID
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_deletebyiphidmaster (
      p_iph_id   IN importprotocolgrid.ipg_iph_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importprotocolgrid
            WHERE ipg_iph_id IN (SELECT iph_id
                                   FROM importprotocolheader
                                  WHERE iph_iph_id = p_iph_id);
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_deletebyiphidatlevel (
      p_iph_id   IN importprotocolgrid.ipg_iph_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importprotocolgrid
            WHERE ipg_iph_id = p_iph_id;
   END;

   /*-----------------------------------------------------------------------*/
   PROCEDURE p_deletebyiphid (p_iph_id IN importprotocolgrid.ipg_iph_id%TYPE)
   /*-----------------------------------------------------------------------------*/
   IS
      CURSOR l_cursorfils                                   -- Fils de l'iphid
      IS
         SELECT iph_id
           FROM importprotocolheader
          WHERE iph_iph_id = p_iph_id;

      l_reccursorfils   l_cursorfils%ROWTYPE;
   BEGIN
      OPEN l_cursorfils;

      LOOP
         FETCH l_cursorfils INTO l_reccursorfils;

         EXIT WHEN l_cursorfils%NOTFOUND;
         p_deletebyiphidatlevel (l_reccursorfils.iph_id);
      END LOOP;

      CLOSE l_cursorfils;

      p_deletebyiphidatlevel (p_iph_id);
   END;

   /*----------------------------------------------------------------------------------------*/
   PROCEDURE p_updatevalidatestatus (
      p_ipg_id   IN importprotocolgrid.ipg_id%TYPE,
      p_status   IN importprotocolgrid.ipg_validstatus%TYPE,
      p_usr_id   IN importprotocolgrid.ipg_usr_id_modify%TYPE)
   /*----------------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE importprotocolgrid
         SET ipg_validstatus = p_status,
             ipg_usr_id_modify = p_usr_id,
             ipg_usr_modify_date = SYSDATE
       WHERE ipg_id = p_ipg_id;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_getrecord (p_ipg_id IN importprotocolgrid.ipg_id%TYPE)
      RETURN importprotocolgrid%ROWTYPE
   /*-------------------------------------------------------------*/
   IS
      l_record   importprotocolgrid%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM importprotocolgrid
       WHERE ipg_id = p_ipg_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*-------------------------------------------------------------------------------*/
   PROCEDURE p_insert (p_iph_id   IN importprotocolgrid.ipg_iph_id%TYPE,
                       p_pmg_id   IN importprotocolgrid.ipg_pmg_id%TYPE,
                       p_value    IN importprotocolgrid.ipg_value%TYPE)
   /*-------------------------------------------------------------------------------*/
   IS
      /* ATTENTION: Utilisé uniquement par JAVA a cause du COMMIT */
      l_id   importprotocolgrid.ipg_iph_id%TYPE;
   BEGIN
      l_id := seq_importprotocolgrid.NEXTVAL;

      INSERT INTO importprotocolgrid (ipg_id,
                                      ipg_iph_id,
                                      ipg_pmg_id,
                                      ipg_value)
           VALUES (l_id,
                   p_iph_id,
                   p_pmg_id,
                   p_value);

      COMMIT;
   END;
END;
/

