create trigger TR_BIF_PROCESSINGSTEP
    before insert
    on PROCESSINGSTEP
    for each row
DECLARE
BEGIN
   IF :new.psi_id IS NULL
   THEN
      :new.psi_id := seq_processingstep.NEXTVAL;
   END IF;

   :new.psi_credate := SYSDATE;
   :new.psi_creuser := USER;
END tr_bif_processingstep;

/

