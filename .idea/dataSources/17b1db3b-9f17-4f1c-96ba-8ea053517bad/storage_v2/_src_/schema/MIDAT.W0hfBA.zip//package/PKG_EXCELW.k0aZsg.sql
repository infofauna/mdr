create PACKAGE       pkg_excelw
AS
   /******************************************************************************
      NAME:       PKG_EXCEL
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.10.2013      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;
      
    

   PROCEDURE p_buildsheetlist (
      p_blob         IN     BLOB, -- Fichier contenant la feuille Excel
      p_sheetlist       OUT pkg_worksheetlist.t_cursor, -- Curseur contenant la liste des feuilles. 
      p_sheetcount      OUT NUMBER); -- Nombre de feuille. Si ce nombre est égal à zéro, le curseur p_sheetlist n'est pas renseigné.
                                                      -- Le nombre de feuille est égale à zéro si le contenu du blob n'est pas un fichier Excel  
                                                      
        /*-------------------------------------------------------------------------------------------------------------
      Colonnes  retournées par le curseur  p_sheetlist:
       1: wsl_sheetnumber --> NUMBER 
       2: wsl_sheetname --> VARCHAR2
       Les noms sont fourni dans l'ordre des feuilles (wsl_sheetnumber)
      ---------------------------------------------------------------------------------------------------------------*/                                                
      
END pkg_excelw;
/

