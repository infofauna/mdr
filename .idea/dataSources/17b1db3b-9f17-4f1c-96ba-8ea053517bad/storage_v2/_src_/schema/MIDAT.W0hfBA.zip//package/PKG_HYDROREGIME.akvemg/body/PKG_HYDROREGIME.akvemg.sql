create PACKAGE BODY       pkg_hydroregime
AS
    /******************************************************************************
       NAME:       pkg_hydroregime
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
         1.0        3.07.2020      burrif       1. Created this package.
    ******************************************************************************/


    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.0, juillet  2020' ;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_getrecord (p_hdr_id IN hydroregime.hdr_id%TYPE)
        RETURN hydroregime%ROWTYPE
    /*-----------------------------------------------------------------*/
    IS
        l_rechydroregime   hydroregime%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_rechydroregime
          FROM hydroregime
         WHERE hdr_id = p_hdr_id;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_getrecordbyibch_q_id (
        p_hdr_cvl_id_ibch_q   IN hydroregime.hdr_cvl_id_ibch_q%TYPE)
        RETURN hydroregime%ROWTYPE
    /*-----------------------------------------------------------------*/
    IS
        l_rechydroregime   hydroregime%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_rechydroregime
          FROM hydroregime
         WHERE hdr_cvl_id_ibch_q = p_hdr_cvl_id_ibch_q;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
        WHEN TOO_MANY_ROWS
        THEN
            RETURN NULL;
    END;


    /*-----------------------------------------------------------------*/
    FUNCTION f_getrecordbyibch_q_code (p_ibch_q IN codevalue.cvl_code%TYPE)
        RETURN hydroregime%ROWTYPE
    /*-----------------------------------------------------------------*/
    IS
        l_rechydroregime   hydroregime%ROWTYPE;
    BEGIN
        SELECT hydroregime.*
          INTO l_rechydroregime
          FROM hydroregime
               INNER JOIN codevalue ON cvl_id = hdr_cvl_id_ibch_q
               INNER JOIN codereference ON crf_id = cvl_crf_id
         WHERE     cvl_code = p_ibch_q
               AND crf_code = pkg_codereference.cst_crf_ibch_q;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
        WHEN TOO_MANY_ROWS
        THEN
            RETURN NULL;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_getrecordbycode (p_code IN hydroregime.hdr_code%TYPE)
        RETURN hydroregime%ROWTYPE
    /*-----------------------------------------------------------------*/
    IS
        l_rechydroregime   hydroregime%ROWTYPE;
    BEGIN
        SELECT hydroregime.*
          INTO l_rechydroregime
          FROM hydroregime
         WHERE hdr_code = p_code;

        RETURN l_rechydroregime;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
        WHEN TOO_MANY_ROWS
        THEN
            RETURN NULL;
    END;

    /*---------------------------------------------------------------------*/
    PROCEDURE p_writewithcode (
        p_ibch_q      IN     codevalue.cvl_code%TYPE,
        p_hdr_order   IN     hydroregime.hdr_order%TYPE,
        p_hdr_value   IN     hydroregime.hdr_value%TYPE,
        p_hdr_id         OUT hydroregime.hdr_id%TYPE)
    /*----------------------------------------------------------------------*/
    IS
        l_reccodevalue   codevalue%ROWTYPE;
    BEGIN
        p_hdr_id := NULL;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_ibch_q,
                p_ibch_q);

        IF l_reccodevalue.cvl_id IS NULL
        THEN
            RETURN;
        END IF;

        p_write (p_ibch_q,
                 l_reccodevalue.cvl_id,
                 p_hdr_order,
                 p_hdr_value,
                 p_hdr_id);
        NULL;
    END;


    /*---------------------------------------------------------------------*/
    PROCEDURE p_write (
        p_code            IN     hydroregime.hdr_code%TYPE,
        p_cvl_id_ibch_q   IN     hydroregime.hdr_cvl_id_ibch_q%TYPE,
        p_hdr_order       IN     hydroregime.hdr_order%TYPE,
        p_hdr_value       IN     hydroregime.hdr_value%TYPE,
        p_hdr_id             OUT hydroregime.hdr_id%TYPE)
    /*----------------------------------------------------------------------*/
    IS
    BEGIN
        p_hdr_id := seq_hydroregime.NEXTVAL;

        INSERT INTO hydroregime (hdr_id,
                                 hdr_code,
                                 hdr_cvl_id_ibch_q,
                                 hdr_order,
                                 hdr_value)
             VALUES (p_hdr_id,
                     p_code,
                     p_cvl_id_ibch_q,
                     p_hdr_order,
                     p_hdr_value);
    END;
END pkg_hydroregime;
/

