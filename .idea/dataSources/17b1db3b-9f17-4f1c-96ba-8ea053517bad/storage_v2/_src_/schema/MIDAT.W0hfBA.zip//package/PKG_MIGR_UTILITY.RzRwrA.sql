create PACKAGE       pkg_migr_utility
AS
   /******************************************************************************
      NAME:       PKG_MIGR_UTILITY
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10/11/2013      burrif       1. Created this package.
   ******************************************************************************/

   TYPE t_cursor IS REF CURSOR;

   cst_contraint_type_fk      CONSTANT CHAR (1) := 'R';

   cst_contraint_type_check   CONSTANT CHAR (1) := 'C';
   cst_contraint_type_uk      CONSTANT CHAR (1) := 'U';

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_create_index (p_column_name   IN VARCHAR2,
                             p_table_name       user_indexes.table_name%TYPE,
                             p_bitmap        IN BOOLEAN);

   PROCEDURE p_drop_index (p_index_name IN VARCHAR2);

   PROCEDURE p_drop_constraint (
      p_table_name        IN user_constraints.table_name%TYPE,
      p_constraint_name   IN user_constraints.constraint_name%TYPE);

   PROCEDURE p_create_fk (p_table_name        IN VARCHAR2,
                          p_column_name       IN VARCHAR2,
                          p_ref_table_name    IN VARCHAR2,
                          p_ref_column_name   IN VARCHAR2);

   PROCEDURE p_recreatesequence (
      p_table_name   IN VARCHAR2,
      p_seq_name     IN user_sequences.sequence_name%TYPE,
      p_name_id      IN VARCHAR2);



   PROCEDURE p_drop_constraint_one_table (
      p_table_name        IN user_constraints.table_name%TYPE,
      p_constraint_type      user_constraints.constraint_type%TYPE);
END pkg_migr_utility;
/

