create trigger TR_BIF_SAMPLEHEADERITEM
    before insert
    on SAMPLEHEADERITEM
    for each row
DECLARE
BEGIN
   IF :new.SHM_id IS NULL
   THEN
      :new.SHM_id := seq_SAMPLEHEADERITEM.NEXTVAL;
   END IF;

   :new.SHM_credate := SYSDATE;
   :new.SHM_creuser := USER;
END tr_bif_SAMPLEHEADERITEM;

/

