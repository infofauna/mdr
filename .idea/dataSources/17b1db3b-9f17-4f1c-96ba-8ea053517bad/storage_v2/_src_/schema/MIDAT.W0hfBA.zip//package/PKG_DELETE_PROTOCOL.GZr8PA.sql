create PACKAGE       pkg_delete_protocol
AS
    /******************************************************************************
       NAME:       PKG_DELETE
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        19.10.2017      burrif       1. Created this package.
       1.1        17.12.2018      burrif       2. Correction bug suppression de masse (fonction f_getcountims_id)
    ******************************************************************************/



    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_purgeallinvalide;

    PROCEDURE p_deleteprotocolentry (
        p_sph_id   IN sampleheader.sph_id%TYPE,
        p_ptv_id   IN protocolversion.ptv_id%TYPE);

    PROCEDURE p_deleteprotocolentry (p_sph_id IN sampleheader.sph_id%TYPE);

    PROCEDURE p_purgeby_iph_id (p_iph_id IN importprotocolheader.iph_id%TYPE);

    PROCEDURE p_delete_mass (p_sph_id IN sampleheader.sph_id%TYPE);

    PROCEDURE p_delete_labo (p_sph_id IN sampleheader.sph_id%TYPE);

    PROCEDURE p_delete_grid (p_sph_id IN sampleheader.sph_id%TYPE);

    PROCEDURE p_delete_grnd (p_sph_id IN sampleheader.sph_id%TYPE);

    PROCEDURE p_purgeallnotconfirmed;

    PROCEDURE p_purgenotconfirmed (
        p_sph_id   IN importprotocolheader.iph_sph_id_parent%TYPE);
END pkg_delete_protocol;
/

