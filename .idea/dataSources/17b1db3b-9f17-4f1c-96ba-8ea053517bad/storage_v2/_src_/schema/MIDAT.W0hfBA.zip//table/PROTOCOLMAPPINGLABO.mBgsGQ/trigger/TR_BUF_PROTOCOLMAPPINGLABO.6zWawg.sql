create trigger TR_BUF_PROTOCOLMAPPINGLABO
    before update
    on PROTOCOLMAPPINGLABO
    for each row
DECLARE
BEGIN
 
   :new.PTL_moddate := SYSDATE;
   :new.PTL_moduser := USER;
END tr_buf_PROTOCOLMAPPINGLABO;

/

