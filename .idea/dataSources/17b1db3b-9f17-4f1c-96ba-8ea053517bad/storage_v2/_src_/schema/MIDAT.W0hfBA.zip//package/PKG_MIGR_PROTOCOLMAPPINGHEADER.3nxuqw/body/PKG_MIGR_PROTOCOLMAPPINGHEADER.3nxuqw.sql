create PACKAGE BODY       pkg_migr_protocolmappingheader
AS
   /******************************************************************************
      NAME:       pkg_migr_protocolmappingheader
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_build_all
   /*-----------------------------------------------------------------*/
   IS
   BEGIN
     DELETE FROM protocolmappingheader;
      pkg_migr_utility.p_recreatesequence ('PROTOCOLMAPPINGHEADER',
                                           'SEQ_PROTOCOLMAPPINGHEADER',
                                           'PMH_ID');
      p_build_labo_v2;
      p_build_labo_v1;
      p_build_grid_v1;
      p_build_terrain_v1;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_build_labo_v2
   /*-----------------------------------------------------------------*/
   IS
      l_ptv_id                         protocolmappingheader.pmh_ptv_id%TYPE := 1;
      l_reccodevalue                   codevalue%ROWTYPE;
      l_currentitem                    protocolmappingheader.pmh_cvl_code_midathditem%TYPE;
      l_reccodevaluedatatypeint        codevalue%ROWTYPE;
      l_reccodevaluedatatypedouble     codevalue%ROWTYPE;
      l_reccodevaluedatatypestring     codevalue%ROWTYPE;
      l_reccodevaluedatatypedate       codevalue%ROWTYPE;
      l_reccodevaluedatatypecheckbox   codevalue%ROWTYPE;
      l_reccodevaluedatatypeposint     codevalue%ROWTYPE;
      l_reccodevaluedatatypeposdbl     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissx     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissy     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissz     codevalue%ROWTYPE;
      l_pmh_id                         protocolmappingheader.pmh_id%TYPE;
   BEGIN
      l_reccodevaluedatatypeint :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_integer); --24000
      l_reccodevaluedatatypedouble :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_double); --24001
      l_reccodevaluedatatypestring :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_string); --24002
      l_reccodevaluedatatypedate :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_date); --24003
      l_reccodevaluedatatypecheckbox :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_checkbox);                      --24004

      l_reccodevaluedatatypeposint :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_posinteger);                    --24005

      l_reccodevaluedatatypeposdbl :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_posdouble);                      --2400

      l_reccodevaluedatatypeswissx :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisscoordx);                   --24007

      l_reccodevaluedatatypeswissy :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisscoordy);                   --24008

      l_reccodevaluedatatypeswissz :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisselev);                     --24009


      l_currentitem := pkg_codevalue.cst_midathditem_id;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         1,                        -- Rowvalue
                                         'AC',                   --ColumnValue
                                         'IPH_OID',           -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_startpointx;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'AC',                   --ColumnValue
                                         'IPH_STARTPOINT_X',  -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissx.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_startpointy;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'AD',                   --ColumnValue
                                         'IPH_STARTPOINT_Y',  -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissy.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_watercourse;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'C:L',                  --ColumnValue
                                         'IPH_WATERCOURSE',   -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_date;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'N:S',                  --ColumnValue
                                         'IPH_OBSERVATIONDATETXT', -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypedate.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_locality;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'C:L',                  --ColumnValue
                                         'IPH_LOCALITY',      -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_elevation;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'N:S',                  --ColumnValue
                                         'IPH_ELEVATION',     -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissz.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);


      l_currentitem := pkg_codevalue.cst_midathditem_determinator;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'Z:AD',                 --ColumnValue
                                         'IPH_DETERMINATOR',  -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);


      l_currentitem := pkg_codevalue.cst_midathditem_absoluteflag;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (
         l_ptv_id,
         l_reccodevalue.cvl_id,                            -- cvl_id_midatitem
         96,                                                       -- Rowvalue
         'W',                                                    --ColumnValue
         'IPH_ABSOLUTENUMBERFLAG',                            -- p_fieldnameto
         l_currentitem,                          -- p_cvl_code_midathditem   ,
         l_reccodevaluedatatypecheckbox.cvl_id,           -- p_cvl_id_datatype
         pkg_constante.cst_no,                   -- p_isnotnull             ,
         NULL,                                       -- p_isnotnullgroup     ,
         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_ibchvalue;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         99,                       -- Rowvalue
                                         'AE',                   --ColumnValue
                                         'IPH_IBCHVALUE',     -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeint.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_operator;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         99,                       -- Rowvalue
                                         'B',                    --ColumnValue
                                         'IPH_OPERATOR',      -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_build_labo_v1
   /*-----------------------------------------------------------------*/
   IS
      l_ptv_id                         protocolmappingheader.pmh_ptv_id%TYPE := 5;
      l_reccodevalue                   codevalue%ROWTYPE;
      l_currentitem                    protocolmappingheader.pmh_cvl_code_midathditem%TYPE;
      l_reccodevaluedatatypeint        codevalue%ROWTYPE;
      l_reccodevaluedatatypedouble     codevalue%ROWTYPE;
      l_reccodevaluedatatypestring     codevalue%ROWTYPE;
      l_reccodevaluedatatypedate       codevalue%ROWTYPE;
      l_reccodevaluedatatypecheckbox   codevalue%ROWTYPE;
      l_reccodevaluedatatypeposint     codevalue%ROWTYPE;
      l_reccodevaluedatatypeposdbl     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissx     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissy     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissz     codevalue%ROWTYPE;
      l_pmh_id                         protocolmappingheader.pmh_id%TYPE;
   BEGIN
      l_reccodevaluedatatypeint :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_integer); --24000
      l_reccodevaluedatatypedouble :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_double); --24001
      l_reccodevaluedatatypestring :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_string); --24002
      l_reccodevaluedatatypedate :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_date); --24003
      l_reccodevaluedatatypecheckbox :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_checkbox);                      --24004

      l_reccodevaluedatatypeposint :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_posinteger);                    --24005

      l_reccodevaluedatatypeposdbl :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_posdouble);                      --2400

      l_reccodevaluedatatypeswissx :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisscoordx);                   --24007

      l_reccodevaluedatatypeswissy :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisscoordy);                   --24008

      l_reccodevaluedatatypeswissz :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisselev);                     --24009


      l_currentitem := pkg_codevalue.cst_midathditem_id;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         1,                        -- Rowvalue
                                         'AC',                   --ColumnValue
                                         'IPH_OID',           -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_startpointx;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'AC',                   --ColumnValue
                                         'IPH_STARTPOINT_X',  -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissx.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_startpointy;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'AD',                   --ColumnValue
                                         'IPH_STARTPOINT_Y',  -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissy.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_watercourse;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'C:L',                  --ColumnValue
                                         'IPH_WATERCOURSE',   -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_date;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'N:S',                  --ColumnValue
                                         'IPH_OBSERVATIONDATETXT', -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypedate.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_locality;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'C:L',                  --ColumnValue
                                         'IPH_LOCALITY',      -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_elevation;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'N:S',                  --ColumnValue
                                         'IPH_ELEVATION',     -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissz.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);


      l_currentitem := pkg_codevalue.cst_midathditem_operator;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'Z:AD',                 --ColumnValue
                                         'IPH_OPERATOR',      -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);



      l_currentitem := pkg_codevalue.cst_midathditem_ibchvalue;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         99,                       -- Rowvalue
                                         'AE',                   --ColumnValue
                                         'IPH_IBCHVALUE',     -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeint.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_build_grid_v1
   /*-----------------------------------------------------------------*/
   IS
      l_ptv_id                         protocolmappingheader.pmh_ptv_id%TYPE := 2;
      l_reccodevalue                   codevalue%ROWTYPE;
      l_currentitem                    protocolmappingheader.pmh_cvl_code_midathditem%TYPE;
      l_reccodevaluedatatypeint        codevalue%ROWTYPE;
      l_reccodevaluedatatypedouble     codevalue%ROWTYPE;
      l_reccodevaluedatatypestring     codevalue%ROWTYPE;
      l_reccodevaluedatatypedate       codevalue%ROWTYPE;
      l_reccodevaluedatatypecheckbox   codevalue%ROWTYPE;
      l_reccodevaluedatatypeposint     codevalue%ROWTYPE;
      l_reccodevaluedatatypeposdbl     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissx     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissy     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissz     codevalue%ROWTYPE;
      l_pmh_id                         protocolmappingheader.pmh_id%TYPE;
   BEGIN
      l_reccodevaluedatatypeint :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_integer); --24000
      l_reccodevaluedatatypedouble :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_double); --24001
      l_reccodevaluedatatypestring :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_string); --24002
      l_reccodevaluedatatypedate :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_date); --24003
      l_reccodevaluedatatypecheckbox :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_checkbox);                      --24004

      l_reccodevaluedatatypeposint :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_posinteger);                    --24005

      l_reccodevaluedatatypeposdbl :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_posdouble);                      --2400

      l_reccodevaluedatatypeswissx :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisscoordx);                   --24007

      l_reccodevaluedatatypeswissy :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisscoordy);                   --24008

      l_reccodevaluedatatypeswissz :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisselev);                     --24009

      l_currentitem := pkg_codevalue.cst_midathditem_id;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         1,                        -- Rowvalue
                                         'J',                    --ColumnValue
                                         'IPH_OID',           -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_startpointx;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'I',                    --ColumnValue
                                         'IPH_STARTPOINT_X',  -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissx.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_startpointy;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'J',                    --ColumnValue
                                         'IPH_STARTPOINT_Y',  -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissy.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_watercourse;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'B',                    --ColumnValue
                                         'IPH_WATERCOURSE',   -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_date;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'G',                    --ColumnValue
                                         'IPH_OBSERVATIONDATETXT', -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypedate.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_locality;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'B',                    --ColumnValue
                                         'IPH_LOCALITY',      -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_elevation;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'G',                    --ColumnValue
                                         'IPH_ELEVATION',     -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissz.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);


      l_currentitem := pkg_codevalue.cst_midathditem_operator;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'I',                    --ColumnValue
                                         'IPH_OPERATOR',      -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);
   END;


   /*-----------------------------------------------------------------*/
   PROCEDURE p_build_terrain_v1
   /*-----------------------------------------------------------------*/
   IS
      l_ptv_id                         protocolmappingheader.pmh_ptv_id%TYPE := 3;
      l_reccodevalue                   codevalue%ROWTYPE;
      l_currentitem                    protocolmappingheader.pmh_cvl_code_midathditem%TYPE;
      l_reccodevaluedatatypeint        codevalue%ROWTYPE;
      l_reccodevaluedatatypedouble     codevalue%ROWTYPE;
      l_reccodevaluedatatypestring     codevalue%ROWTYPE;
      l_reccodevaluedatatypedate       codevalue%ROWTYPE;
      l_reccodevaluedatatypecheckbox   codevalue%ROWTYPE;
      l_reccodevaluedatatypeposint     codevalue%ROWTYPE;
      l_reccodevaluedatatypeposdbl     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissx     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissy     codevalue%ROWTYPE;
      l_reccodevaluedatatypeswissz     codevalue%ROWTYPE;
      l_pmh_id                         protocolmappingheader.pmh_id%TYPE;
   BEGIN
      l_reccodevaluedatatypeint :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_integer); --24000
      l_reccodevaluedatatypedouble :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_double); --24001
      l_reccodevaluedatatypestring :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_string); --24002
      l_reccodevaluedatatypedate :=
         pkg_codevalue.f_getrecordbycode (pkg_codereference.cst_crf_datatype,
                                          pkg_codevalue.cst_datatype_date); --24003
      l_reccodevaluedatatypecheckbox :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_checkbox);                      --24004

      l_reccodevaluedatatypeposint :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_posinteger);                    --24005

      l_reccodevaluedatatypeposdbl :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_posdouble);                     --24006

      l_reccodevaluedatatypeswissx :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisscoordx);                   --24007

      l_reccodevaluedatatypeswissy :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisscoordy);                   --24008

      l_reccodevaluedatatypeswissz :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_datatype,
            pkg_codevalue.cst_datatype_swisselev);                     --24009
      l_currentitem := pkg_codevalue.cst_midathditem_id;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         1,                        -- Rowvalue
                                         'S',                    --ColumnValue
                                         'IPH_OID',           -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_startpointx;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'R',                    --ColumnValue
                                         'IPH_STARTPOINT_X',  -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissx.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_startpointy;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'T',                    --ColumnValue
                                         'IPH_STARTPOINT_Y',  -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissy.cvl_id, -- p_cvl_id_datatype I
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_watercourse;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'C',                    --ColumnValue
                                         'IPH_WATERCOURSE',   -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_date;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         3,                        -- Rowvalue
                                         'M',                    --ColumnValue
                                         'IPH_OBSERVATIONDATETXT', -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypedate.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_locality;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'C',                    --ColumnValue
                                         'IPH_LOCALITY',      -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);

      l_currentitem := pkg_codevalue.cst_midathditem_elevation;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'M',                    --ColumnValue
                                         'IPH_ELEVATION',     -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypeswissz.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);


      l_currentitem := pkg_codevalue.cst_midathditem_operator;
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midathditem,
            l_currentitem);

      pkg_protocolmappingheader.p_write (l_ptv_id,
                                         l_reccodevalue.cvl_id, -- cvl_id_midatitem
                                         5,                        -- Rowvalue
                                         'R',                    --ColumnValue
                                         'IPH_OPERATOR',      -- p_fieldnameto
                                         l_currentitem, -- p_cvl_code_midathditem   ,
                                         l_reccodevaluedatatypestring.cvl_id, -- p_cvl_id_datatype
                                         pkg_constante.cst_yes, -- p_isnotnull             ,
                                         NULL,       -- p_isnotnullgroup     ,
                                         l_pmh_id);
   END;

   /*------------------------------------------------------------------*/
   PROCEDURE p_build_cvl_midatitem (
      p_ptv_id   IN protocolmappingheader.pmh_ptv_id%TYPE)
   /*------------------------------------------------------------------*/
   IS
      CURSOR l_protocolmappingheader
      IS
         SELECT *
           FROM protocolmappingheader
          WHERE pmh_ptv_id = p_ptv_id
         FOR UPDATE;

      l_codevalue                  codevalue%ROWTYPE;

      l_recprotocolmappingheader   l_protocolmappingheader%ROWTYPE;
   BEGIN
      OPEN l_protocolmappingheader;

      LOOP
         FETCH l_protocolmappingheader INTO l_recprotocolmappingheader;

         EXIT WHEN l_protocolmappingheader%NOTFOUND;
         l_codevalue :=
            pkg_codevalue.f_getfromcode (
               l_recprotocolmappingheader.pmh_cvl_id_midathditem,
               pkg_codereference.cst_crf_midathditem);

         IF NOT l_codevalue.cvl_id IS NULL
         THEN
            DBMS_OUTPUT.put_line (
                  '  l_recprotocolmappingheader.PMH_CVL_ID_MIDATHDITEM='
               || l_recprotocolmappingheader.pmh_cvl_id_midathditem
               || ' cvl_id='
               || l_codevalue.cvl_id);
         ELSE
            DBMS_OUTPUT.put_line (
                  '  l_recprotocolmappingheader.PMH_CVL_ID_MIDATHDITEM='
               || l_recprotocolmappingheader.pmh_cvl_id_midathditem
               || ' not found ');
         END IF;
      END LOOP;

      CLOSE l_protocolmappingheader;
   END;



   /*------------------------------------------------------------------*/
   PROCEDURE p_deleteall
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      --   DELETE FROM protocolmappinglabo;
      NULL;
   END;
END pkg_migr_protocolmappingheader;
/

