create trigger TR_BIF_SPEARDATA
    before insert
    on SPEARDATA
    for each row
DECLARE
BEGIN
   IF :new.SRA_ID IS NULL
   THEN
      :new.SRA_ID := seq_SPEARDATA.NEXTVAL;
   END IF;

   :new.SRA_credate := SYSDATE;
   :new.SRA_creuser := USER;
END TR_BIF_SPEARDATA;

/

