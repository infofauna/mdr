create PACKAGE       pkg_migr_abundanceclassrange
AS
   /******************************************************************************
      NAME:       PKG_MIGR_ABUNDANCECLASSRANGE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.02.2015      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_loadinchvarietyclass;

   PROCEDURE p_loadmakroindexabundanceclass;
END pkg_migr_abundanceclassrange;
/

