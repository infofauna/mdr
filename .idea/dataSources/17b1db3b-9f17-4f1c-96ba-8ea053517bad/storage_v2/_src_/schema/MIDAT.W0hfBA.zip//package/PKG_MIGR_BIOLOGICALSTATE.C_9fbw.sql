create PACKAGE       pkg_migr_biologicalstate
AS
   /******************************************************************************
      NAME:       pkg_migr_biologicalstate
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_buildall;

   PROCEDURE p_build_ibchrange;

   PROCEDURE p_build_makroindexrange;
END pkg_migr_biologicalstate;
/

