create PACKAGE       pkg_importmassdataheader
AS
    /******************************************************************************
       NAME:       pkg_importmassdataheader
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        02.10.2013      burrif       1. Created this package.
       2.0         11.07.2017     burrif       2. Fonctionnalité version 2
       2.1         13.09.2017     burrif       3. Ajout des nouvelles colonnes Version 2
       2.2         20.01.2020      burrif       4. Mise à jour des champs statistique IBCH
    ******************************************************************************/



    TYPE t_systemprecision
        IS TABLE OF importmassdataheader.imh_systemprecision%TYPE;

    TYPE t_codeprecision
        IS TABLE OF importmassdataheader.imh_codeprecision%TYPE;

    TYPE t_oid IS TABLE OF importmassdataheader.imh_oid%TYPE;

    TYPE t_watercourse IS TABLE OF importmassdataheader.imh_watercourse%TYPE;

    TYPE t_locality IS TABLE OF importmassdataheader.imh_locality%TYPE;

    TYPE t_calledplace IS TABLE OF importmassdataheader.imh_calledplace%TYPE;

    TYPE t_observers IS TABLE OF importmassdataheader.imh_observers%TYPE;

    TYPE t_period IS TABLE OF importmassdataheader.imh_period%TYPE;

    TYPE t_project IS TABLE OF importmassdataheader.imh_project%TYPE;

    TYPE t_reporturl IS TABLE OF importmassdataheader.imh_reporturl%TYPE;

    TYPE t_makroindexprovide
        IS TABLE OF importmassdataheader.imh_makroindexprovide%TYPE;

    TYPE t_spearindexprovide
        IS TABLE OF importmassdataheader.imh_spearindexprovide%TYPE;

    TYPE t_ibchindexprovide
        IS TABLE OF importmassdataheader.imh_ibchindexprovide%TYPE;

    TYPE t_elevation IS TABLE OF importmassdataheader.imh_elevation%TYPE;

    TYPE t_indicetype IS TABLE OF importmassdataheader.imh_indicetype%TYPE;

    TYPE t_remarkcode1 IS TABLE OF importmassdataheader.imh_remarkcode1%TYPE;

    TYPE t_remarkcode2 IS TABLE OF importmassdataheader.imh_remarkcode2%TYPE;

    TYPE t_remarkcode3 IS TABLE OF importmassdataheader.imh_remarkcode3%TYPE;

    TYPE t_remarkcode4 IS TABLE OF importmassdataheader.imh_remarkcode4%TYPE;

    TYPE t_remarktext IS TABLE OF importmassdataheader.imh_remarktext%TYPE;

    TYPE t_oidlink IS TABLE OF importmassdataheader.imh_oidlink%TYPE;

    TYPE t_determinator
        IS TABLE OF importmassdataheader.imh_determinator%TYPE;

    TYPE t_listvarchar IS TABLE OF importmassdataheader.imh_id%TYPE
        INDEX BY VARCHAR2 (128);

    cst_fieldlocality      CONSTANT VARCHAR2 (30) := 'locality';
    cst_fieldwatercourse   CONSTANT VARCHAR2 (30) := 'watercourse';
    cst_fielddate          CONSTANT VARCHAR2 (30) := 'date';


    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_getcountims_id (
        p_ims_id   IN importmassdataheader.imh_ims_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_getcountvalidentries (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE)
        RETURN NUMBER;

    PROCEDURE p_save_v2_data (
        p_sph_id         IN sampleheader.sph_id%TYPE,
        p_remarktext     IN sampleheader.sph_comment%TYPE,
        p_remarkcode1    IN importmassdataheader.imh_remarkcode1%TYPE,
        p_remarkcode2    IN importmassdataheader.imh_remarkcode2%TYPE,
        p_remarkcode3    IN importmassdataheader.imh_remarkcode3%TYPE,
        p_remarkcode4    IN importmassdataheader.imh_remarkcode4%TYPE,
        p_determinator   IN sampleheaderitem.shm_item%TYPE,
        p_ptv_id         IN sampleheaderitem.shm_ptv_id%TYPE,
        p_lan_id         IN sampleheaderitem.shm_lan_id%TYPE,
        p_usr_id         IN sampleheader.sph_usr_id_modify%TYPE);

    PROCEDURE p_update_imh_sst_id_oidlink (
        p_imh_id   IN importmassdataheader.imh_id%TYPE,
        p_sst_id   IN importmassdataheader.imh_sst_id_oidlink%TYPE,
        p_usr_id   IN importmassdataheader.imh_usr_id_modify%TYPE);

    PROCEDURE p_update_imh_cvl_id_canton (
        p_imh_id              IN importmassdataheader.imh_id%TYPE,
        p_imh_cvl_id_canton   IN importmassdataheader.imh_cvl_id_canton%TYPE,
        p_usr_id              IN importmassdataheader.imh_usr_id_modify%TYPE);

    PROCEDURE p_update_imh_prj_id (
        p_imh_id       IN importmassdataheader.imh_id%TYPE,
        p_imh_prj_id   IN importmassdataheader.imh_prj_id%TYPE,
        p_usr_id       IN importmassdataheader.imh_usr_id_modify%TYPE);

    PROCEDURE p_writeinvalidatemessagebyoid (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE,
        p_oid      IN importmassdataheader.imh_oid%TYPE);

    PROCEDURE p_writeinvalidatemessage (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE,
        p_ims_id   IN importmassdataheader.imh_ims_id%TYPE,
        p_oid      IN importmassdataheader.imh_oid%TYPE);

    FUNCTION f_getrecordbyims_id (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE,
        p_ims_id   IN importmassdataheader.imh_ims_id%TYPE)
        RETURN importmassdataheader%ROWTYPE;

    PROCEDURE p_returninfoheaderbycoordinate (
        p_iph_id            IN     importmassdataheader.imh_iph_id%TYPE,
        p_oid               IN     importmassdataheader.imh_oid%TYPE,
        p_elevation         IN     importmassdataheader.imh_elevation%TYPE,
        p_x                 IN     importmassdataheader.imh_startpoint_x%TYPE,
        p_y                 IN     importmassdataheader.imh_startpoint_y%TYPE,
        p_listlocality         OUT t_listvarchar,
        p_listwatercourse      OUT t_listvarchar,
        p_listdate             OUT t_listvarchar);

    PROCEDURE p_returninfoheaderbyims_id (
        p_ims_id            IN     importmassdataheader.imh_ims_id%TYPE,
        p_listlocality         OUT t_listvarchar,
        p_listwatercourse      OUT t_listvarchar,
        p_listdate             OUT t_listvarchar);

    FUNCTION f_formatlistvarchar (p_list    IN t_listvarchar,
                                  p_field   IN VARCHAR2)
        RETURN VARCHAR2;

    PROCEDURE p_test2;

    PROCEDURE p_logendstatistique (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE);

    FUNCTION f_makroindexmussbecomputed (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE)
        RETURN CHAR;

    PROCEDURE p_returnindexcalculationforall (
        p_iph_id                  IN     importmassdataheader.imh_iph_id%TYPE,
        p_spearindexcalculation      OUT BOOLEAN,
        p_makroindexcalculation      OUT BOOLEAN,
        p_ibchindexcalculation       OUT BOOLEAN);

    PROCEDURE p_returnindexcalculation (
        p_imh_id                  IN     importmassdataheader.imh_id%TYPE,
        p_spearindexcalculation      OUT BOOLEAN,
        p_makroindexcalculation      OUT BOOLEAN,
        p_ibchindexcalculation       OUT BOOLEAN);

    PROCEDURE p_deleteby_sst_id (
        p_sst_id   IN importmassdataheader.imh_sst_id%TYPE);

    PROCEDURE p_delete (p_imh_id IN importmassdataheader.imh_id%TYPE);

    PROCEDURE p_purgeinvalidemassdata (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE);

    PROCEDURE p_updateelevation (
        p_imh_id                   IN importmassdataheader.imh_id%TYPE,
        p_elevation                IN importmassdataheader.imh_elevation%TYPE,
        p_cvl_id_elevationorigin   IN importmassdataheader.imh_cvl_id_elevationorigin%TYPE,
        p_elevationprecision       IN importmassdataheader.imh_elevationprecision%TYPE);

    PROCEDURE p_updateibchindex (
        p_imh_id       IN importmassdataheader.imh_id%TYPE,
        p_ibchvalue    IN importmassdataheader.imh_ibchvalue%TYPE,
        p_windowibch   IN importmassdataheader.imh_cvl_id_windowibch%TYPE);

    PROCEDURE p_updatemakroindex (
        p_imh_id      IN importmassdataheader.imh_id%TYPE,
        p_mkivalue    IN importmassdataheader.imh_makroindexvalue%TYPE,
        p_windowmki   IN importmassdataheader.imh_cvl_id_windowmakroindex%TYPE);

    PROCEDURE p_updatespearindex (
        p_imh_id        IN importmassdataheader.imh_id%TYPE,
        p_spearvalue    IN importmassdataheader.imh_spearvalue%TYPE,
        p_windowspear   IN importmassdataheader.imh_cvl_id_windowspear%TYPE);

    PROCEDURE p_returncountindice (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_ibchcounter                  OUT NUMBER,
        p_mkicounter                   OUT NUMBER);

    PROCEDURE p_updatevalidtatuspending (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_lan_id                    IN language.lan_id%TYPE,
        p_usr_id                    IN sampleprotocolgrnd.spd_usr_id_create%TYPE);

    PROCEDURE p_saveprotocolmassheader (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_lan_id                    IN language.lan_id%TYPE,
        p_usr_id                    IN sampleprotocolgrnd.spd_usr_id_create%TYPE,
        p_smf_id                    IN sampleheader.sph_smf_id%TYPE,
        p_visibilitystatus          IN sampleheader.sph_visibilitystatus%TYPE,
        p_publicstatus              IN VARCHAR2);

    PROCEDURE p_update_imh_sst_id (
        p_imh_id   IN importmassdataheader.imh_id%TYPE,
        p_sst_id   IN importmassdataheader.imh_sst_id%TYPE,
        p_usr_id   IN importmassdataheader.imh_usr_id_modify%TYPE);

    PROCEDURE p_update_imh_sst_id_by_ims_id (
        p_ims_id   IN importmassdataheader.imh_ims_id%TYPE,
        p_sst_id   IN importmassdataheader.imh_sst_id%TYPE,
        p_usr_id   IN importmassdataheader.imh_usr_id_modify%TYPE);

    PROCEDURE p_update_imh_ims_id (
        p_ims_id_concerve   IN importmassdataheader.imh_ims_id%TYPE,
        p_ims_id_supprime   IN importmassdataheader.imh_ims_id%TYPE,
        p_usr_id            IN importmassdataheader.imh_usr_id_modify%TYPE);

    PROCEDURE p_update_imh_ims_id (
        p_iph_id         IN importmassdataheader.imh_iph_id%TYPE,
        p_ims_id         IN importmassdataheader.imh_ims_id%TYPE,
        p_oid            IN importmassdataheader.imh_oid%TYPE,
        p_startpoint_x   IN importmassdataheader.imh_startpoint_x%TYPE,
        p_startpoint_y   IN importmassdataheader.imh_startpoint_y%TYPE,
        p_elevation      IN importmassdataheader.imh_elevation%TYPE,
        p_usr_id         IN importmassdataheader.imh_usr_id_modify%TYPE);

    PROCEDURE p_returncounter (
        p_iph_id                 IN     importmassdataheader.imh_iph_id%TYPE,
        p_totalcounter              OUT NUMBER,
        p_validcounter              OUT NUMBER,
        p_invalidcounter            OUT NUMBER,
        p_allreadyexistcounter      OUT NUMBER);

    PROCEDURE p_setvalidstatuscascade (
        p_imh_id        IN importmassdataheader.imh_id%TYPE,
        p_validstatus   IN importmassdataheader.imh_validstatus%TYPE);

    FUNCTION f_countrowsstatuspending (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_countrowsstatusvalid (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_countrows (p_iph_id IN importmassdataheader.imh_iph_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_getrecord (p_imh_id IN importmassdataheader.imh_id%TYPE)
        RETURN importmassdataheader%ROWTYPE;

    FUNCTION f_buildswisscoord (
        p_recimportmassdataheader   IN importmassdataheader%ROWTYPE)
        RETURN VARCHAR2;

    FUNCTION f_builddatetxt (
        p_recimportmassdataheader   IN importmassdataheader%ROWTYPE)
        RETURN VARCHAR2;

    PROCEDURE p_setvalidstatus (
        p_imh_id   IN importmassdataheader.imh_id%TYPE,
        p_status   IN importmassdataheader.imh_validstatus%TYPE);

    PROCEDURE p_addsystemprecision (
        p_value             IN     importmassdataheader.imh_systemprecision%TYPE,
        p_systemprecision   IN OUT t_systemprecision);

    PROCEDURE p_addcodeprecision (
        p_value           IN     importmassdataheader.imh_codeprecision%TYPE,
        p_codeprecision   IN OUT t_codeprecision);

    PROCEDURE p_addoid (p_value   IN     importmassdataheader.imh_oid%TYPE,
                        p_oid     IN OUT t_oid);

    PROCEDURE p_addwatercourse (
        p_value         IN     importmassdataheader.imh_watercourse%TYPE,
        p_watercourse   IN OUT t_watercourse);

    PROCEDURE p_addlocality (
        p_value      IN     importmassdataheader.imh_locality%TYPE,
        p_locality   IN OUT t_locality);

    PROCEDURE p_addcalledplace (
        p_value         IN     importmassdataheader.imh_calledplace%TYPE,
        p_calledplace   IN OUT t_calledplace);

    PROCEDURE p_addobservers (
        p_value       IN     importmassdataheader.imh_observers%TYPE,
        p_observers   IN OUT t_observers);

    PROCEDURE p_addperiod (
        p_value    IN     importmassdataheader.imh_period%TYPE,
        p_period   IN OUT t_period);


    PROCEDURE p_addproject (
        p_value     IN     importmassdataheader.imh_project%TYPE,
        p_project   IN OUT t_project);

    PROCEDURE p_addreporturl (
        p_value       IN     importmassdataheader.imh_reporturl%TYPE,
        p_reporturl   IN OUT t_reporturl);

    PROCEDURE p_addmakroindexprovide (
        p_value               IN     importmassdataheader.imh_makroindexprovide%TYPE,
        p_makroindexprovide   IN OUT t_makroindexprovide);

    PROCEDURE p_addspearindexprovide (
        p_value               IN     importmassdataheader.imh_spearindexprovide%TYPE,
        p_spearindexprovide   IN OUT t_spearindexprovide);

    PROCEDURE p_addibchindexprovide (
        p_value              IN     importmassdataheader.imh_ibchindexprovide%TYPE,
        p_ibchindexprovide   IN OUT t_ibchindexprovide);

    PROCEDURE p_addelevation (
        p_value       IN     importmassdataheader.imh_elevation%TYPE,
        p_elevation   IN OUT t_elevation);

    PROCEDURE p_addindicetype (
        p_value        IN     importmassdataheader.imh_indicetype%TYPE,
        p_indicetype   IN OUT t_indicetype);

    PROCEDURE p_addremarkcode1 (
        p_value         IN     importmassdataheader.imh_remarkcode1%TYPE,
        p_remarkcode1   IN OUT t_remarkcode1);

    PROCEDURE p_addremarkcode2 (
        p_value         IN     importmassdataheader.imh_remarkcode2%TYPE,
        p_remarkcode2   IN OUT t_remarkcode2);

    PROCEDURE p_addremarkcode3 (
        p_value         IN     importmassdataheader.imh_remarkcode3%TYPE,
        p_remarkcode3   IN OUT t_remarkcode3);

    PROCEDURE p_addremarkcode4 (
        p_value         IN     importmassdataheader.imh_remarkcode4%TYPE,
        p_remarkcode4   IN OUT t_remarkcode4);

    PROCEDURE p_addremarktext (
        p_value        IN     importmassdataheader.imh_remarktext%TYPE,
        p_remarktext   IN OUT t_remarktext);

    PROCEDURE p_addoidlink (
        p_value     IN     importmassdataheader.imh_oidlink%TYPE,
        p_oidlink   IN OUT t_oidlink);

    PROCEDURE p_adddeterminator (
        p_value          IN     importmassdataheader.imh_determinator%TYPE,
        p_determinator   IN OUT t_determinator);

    PROCEDURE p_addheader (
        p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
        p_day            IN     importmassdataheader.imh_day%TYPE,
        p_month          IN     importmassdataheader.imh_month%TYPE,
        p_year           IN     importmassdataheader.imh_year%TYPE,
        p_startpoint_x   IN     importmassdataheader.imh_startpoint_x%TYPE,
        p_startpoint_y   IN     importmassdataheader.imh_startpoint_y%TYPE,
        p_elevation      IN     importmassdataheader.imh_elevation%TYPE,
        p_prj_id         IN     importmassdataheader.imh_prj_id%TYPE,
        p_imh_id            OUT importmassdataheader.imh_id%TYPE);



    PROCEDURE p_updateheader (
        p_imh_id                  IN importmassdataheader.imh_id%TYPE,
        p_imh_systemprecision     IN importmassdataheader.imh_systemprecision%TYPE,
        p_imh_codeprecision       IN importmassdataheader.imh_codeprecision%TYPE,
        p_imh_oid                 IN importmassdataheader.imh_oid%TYPE,
        p_imh_watercourse         IN importmassdataheader.imh_watercourse%TYPE,
        p_imh_locality            IN importmassdataheader.imh_locality%TYPE,
        p_imh_calledplace         IN importmassdataheader.imh_calledplace%TYPE,
        p_imh_observers           IN importmassdataheader.imh_observers%TYPE,
        p_imh_period              IN importmassdataheader.imh_period%TYPE,
        p_imh_project             IN importmassdataheader.imh_project%TYPE,
        p_imh_reporturl           IN importmassdataheader.imh_reporturl%TYPE,
        p_imh_makroindexprovide   IN importmassdataheader.imh_makroindexprovide%TYPE,
        p_imh_spearindexprovide   IN importmassdataheader.imh_spearindexprovide%TYPE,
        p_imh_ibchindexprovide    IN importmassdataheader.imh_spearindexprovide%TYPE,
        p_imh_elevation           IN importmassdataheader.imh_elevation%TYPE,
        p_imh_indicetype          IN importmassdataheader.imh_indicetype%TYPE,
        p_remarkcode1             IN importmassdataheader.imh_remarkcode1%TYPE,
        p_remarkcode2             IN importmassdataheader.imh_remarkcode2%TYPE,
        p_remarkcode3             IN importmassdataheader.imh_remarkcode3%TYPE,
        p_remarkcode4             IN importmassdataheader.imh_remarkcode4%TYPE,
        p_remarktext              IN importmassdataheader.imh_remarktext%TYPE,
        p_oidlink                 IN importmassdataheader.imh_oidlink%TYPE,
        p_determinator            IN importmassdataheader.imh_determinator%TYPE);

    PROCEDURE p_deletebyiph_id (
        p_iph_id   IN importmassdataheader.imh_iph_id%TYPE);

    PROCEDURE p_test;

    PROCEDURE p_test1;

    PROCEDURE p_updatetaxoncounterinfodata (
        p_imh_id                       IN importmassdataheader.imh_id%TYPE,
        p_identifiedtaxoncount         IN importmassdataheader.imh_identifiedtaxoncount%TYPE,
        p_identifiedtaxoncountlowlev   IN importmassdataheader.imh_identifiedtaxoncountlowlev%TYPE,
        p_identifiedtaxoncountuplev    IN importmassdataheader.imh_identifiedtaxoncountuplev%TYPE);

    PROCEDURE p_updatemkiinfodata (
        p_imh_id                  IN importmassdataheader.imh_id%TYPE,
        p_cvl_id_mkicase          IN importmassdataheader.imh_cvl_id_mkicase%TYPE,
        p_mkiinsectacount         IN importmassdataheader.imh_mkiinsectacount%TYPE,
        p_mkinonisectacount       IN importmassdataheader.imh_mkinonisectacount%TYPE,
        p_mkirangecount           IN importmassdataheader.imh_mkirangecount%TYPE,
        p_mkiplecopteracount      IN importmassdataheader.imh_mkiplecopteracount%TYPE,
        p_mkitricopteracount      IN importmassdataheader.imh_mkitricopteracount%TYPE,
        p_mkiephemeropteracount   IN importmassdataheader.imh_mkiephemeropteracount%TYPE,
        p_mkigaetidaecount        IN importmassdataheader.imh_mkibaetidaecount%TYPE,
        p_mkigammaruscount        IN importmassdataheader.imh_mkigammaruscount%TYPE,
        p_mkihydropsychecount     IN importmassdataheader.imh_mkihydropsychecount%TYPE,
        p_mkiaselluscount         IN importmassdataheader.imh_mkiaselluscount%TYPE,
        p_mkihirudinaecount       IN importmassdataheader.imh_mkihirudinaecount%TYPE,
        p_mkitubificidaecount     IN importmassdataheader.imh_mkitubificidaecount%TYPE,
        p_mkierrornumber          IN importmassdataheader.imh_mkierrornumber%TYPE);

    PROCEDURE p_updateibchinfodata (
        p_imh_id                     IN importmassdataheader.imh_id%TYPE,
        p_ibchidentifiedtaxoncount   IN importmassdataheader.imh_ibchidentifiedtaxoncount%TYPE,
        p_ibchgivalue                IN importmassdataheader.imh_ibchgivalue%TYPE,
        p_ibchvtvalue                   importmassdataheader.imh_ibchvtvalue%TYPE);

    PROCEDURE p_updatespearinfodata (
        p_imh_id                      IN importmassdataheader.imh_id%TYPE,
        p_spearidentifiedtaxoncount   IN importmassdataheader.imh_spearidentifiedtaxoncount%TYPE);

    PROCEDURE p_updatemkierrornumber (
        p_imh_id           IN importmassdataheader.imh_id%TYPE,
        p_mkierrornumber   IN importmassdataheader.imh_mkierrornumber%TYPE);
END pkg_importmassdataheader;
/

