create PACKAGE BODY       pkg_migr_mkiidentifygroupcount
AS
   /******************************************************************************
      NAME:       PKG_MIGR_MKIIDENTIFYGROUPCOUNT
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        23.02.2015      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, février  2015' ;

   TYPE rec_mkiidentifygroup IS RECORD
   (
      l_taxonname            mkiidentifygroupcounter.mig_taxonname%TYPE,
      l_crf_code             codereference.crf_code%TYPE,
      l_crf_code_leveltrap   codereference.crf_code%TYPE,
      l_syv_id               systvalue.syv_id%TYPE,
      l_searchorder          NUMBER
   );



   TYPE t_listmkiidentifygroup IS TABLE OF rec_mkiidentifygroup;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_load
   /*--------------------------------------------------------------*/
   IS
      l_taxonname                   mkiidentifygroupcounter.mig_taxonname%TYPE;
      l_recsystdesignation          systdesignation%ROWTYPE;

      l_listmkiidentifygroup        t_listmkiidentifygroup
                                       := t_listmkiidentifygroup ();
      l_reccodereference            codereference%ROWTYPE;
      l_reccodereferenceleveltrap   codereference%ROWTYPE;
      l_id                          mkiidentifygroupcounter.mig_id%TYPE;
      l_indice                      PLS_INTEGER;
      l_sql                         VARCHAR2 (1024);
      l_syv_id_return               systvalue.syv_id%TYPE;
   BEGIN
      l_sql := 'DROP SEQUENCE SEQ_mkiidentifygroupcounter';

      EXECUTE IMMEDIATE l_sql;

      l_sql := 'CREATE SEQUENCE SEQ_mkiidentifygroupcounter';


      EXECUTE IMMEDIATE l_sql;

      DELETE FROM mkiidentifygroupcounter;

      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Turbellaria';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_subphylum;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_species;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 2;


      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Hirudinea';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_class;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_species;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 2;
      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Gammaridea';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_suborder;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_species;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 2;
      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Asellota';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_suborder;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_species;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 2;
      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Coleoptera';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_order;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_species;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 2;
      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Simuliidae';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_family;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_species;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 2;

      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Eulamellibranchia';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_subclass;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_genus;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 3;

      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Ephemeroptera';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_order;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_genus;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 3;


      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Plecoptera';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_order;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_genus;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 3;



      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Megaloptera';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_order;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_genus;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 3;



      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Trichoptera';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_order;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_genus;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 3;


      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Diptera';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_order;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_genus;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 3;



      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Gastropoda';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_class;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_family;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 4;



      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Oligochaeta';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_class;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_family;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 4;

      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Baetidae';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_family;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_family;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 1;

      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Odonata';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_order;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_family;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 4;

      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Heteroptera';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_suborder;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_family;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 4;

      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Chironomidae';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_family;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_family;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 1;

      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Ceratopogonidae';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_family;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_family;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 1;


      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Nematomorpha';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_phylum;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_phylum;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 5;

      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Nematoda';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_phylum;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_phylum;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 5;
      l_listmkiidentifygroup.EXTEND (1);
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_taxonname :=
         'Hydracarina';
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code :=
         pkg_codereference.cst_crf_superfamil;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_crf_code_leveltrap :=
         pkg_codereference.cst_crf_phylum;
      l_listmkiidentifygroup (l_listmkiidentifygroup.LAST).l_searchorder := 5;



      l_indice := l_listmkiidentifygroup.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         IF NOT l_listmkiidentifygroup (l_indice).l_crf_code_leveltrap
                   IS NULL
         THEN
            l_reccodereferenceleveltrap :=
               pkg_codereference.f_getrecordbycode (
                  l_listmkiidentifygroup (l_indice).l_crf_code_leveltrap);
         ELSE
            l_reccodereferenceleveltrap.crf_id := NULL;
         END IF;



         l_reccodereference :=
            pkg_codereference.f_getrecordbycode (
               l_listmkiidentifygroup (l_indice).l_crf_code);

         l_recsystdesignation :=
            pkg_systdesignation.f_getrecordbydesignation (
               l_listmkiidentifygroup (l_indice).l_taxonname,
               pkg_language.cst_lan_cde_latin,
               l_reccodereference.crf_code);
         DBMS_OUTPUT.put_line (
               'l_listmkiidentifygroup (l_indice).l_taxonname='
            || l_listmkiidentifygroup (l_indice).l_taxonname);
         DBMS_OUTPUT.put_line (
            'l_reccodereference.crf_code=' || l_reccodereference.crf_code);

         pkg_mkiidentifygroupcounter.p_insert (
            l_recsystdesignation.syd_syv_id,
            l_reccodereference.crf_id,
            l_reccodereferenceleveltrap.crf_id,
            l_listmkiidentifygroup (l_indice).l_taxonname,
            l_listmkiidentifygroup (l_indice).l_searchorder,
            l_id);

         l_indice := l_listmkiidentifygroup.NEXT (l_indice);
      END LOOP;
   END;
END pkg_migr_mkiidentifygroupcount;
/

