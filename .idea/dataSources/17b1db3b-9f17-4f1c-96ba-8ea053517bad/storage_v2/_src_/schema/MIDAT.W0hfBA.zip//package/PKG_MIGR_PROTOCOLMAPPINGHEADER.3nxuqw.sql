create PACKAGE       pkg_migr_protocolmappingheader
AS
   /******************************************************************************
      NAME:       pkg_migr_protocolmappingheader
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_build_all;

   PROCEDURE p_build_labo_v2;

   PROCEDURE p_build_labo_v1;

   PROCEDURE p_build_grid_v1;

   PROCEDURE p_build_terrain_v1;

   PROCEDURE p_build_cvl_midatitem (
      p_ptv_id   IN protocolmappingheader.pmh_ptv_id%TYPE);
END pkg_migr_protocolmappingheader;
/

