create PACKAGE BODY       pkg_abundanceclassrange
AS
   /******************************************************************************
      NAME:       PKG_ABUNDANCECLASSRANGE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.02.2015      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, février 2015' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_test
   /*------------------------------------------------------------------*/
   IS
      l_indice                   PLS_INTEGER;
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
   BEGIN
      FOR l_indice IN 1 .. 1000
      LOOP
         l_recabundanceclassrange :=
            f_getrecordbyindiceandvalue (pkg_codevalue.cst_midatindice_ibch,
                                         l_indice);
         DBMS_OUTPUT.put_line (
               'Indice:'
            || l_indice
            || ' Classe: '
            || l_recabundanceclassrange.acr_classe);
      END LOOP;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_test1
   /*------------------------------------------------------------------*/
   IS
      l_indice                   PLS_INTEGER;
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
   BEGIN
      FOR l_indice IN 1 .. 1000
      LOOP
         l_recabundanceclassrange :=
            f_getrecordbyindiceandvalue (
               pkg_codevalue.cst_midatindice_makroindex,
               l_indice);
         DBMS_OUTPUT.put_line (
               'Indice:'
            || l_indice
            || ' Classe: '
            || l_recabundanceclassrange.acr_classe
            || ' Substitute value:'
            || l_recabundanceclassrange.acr_substitutevalue);
      END LOOP;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_getrecordbyclass (
      p_code_midatindice   IN codevalue.cvl_code%TYPE,
      p_class              IN abundanceclassrange.acr_classe%TYPE)
      RETURN abundanceclassrange%ROWTYPE
   /*-----------------------------------------------------------------*/
   IS
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
   BEGIN
      SELECT abundanceclassrange.*
        INTO l_recabundanceclassrange
        FROM abundanceclassrange
             INNER JOIN codevalue ON cvl_id = acr_cvl_id_midatindice
       WHERE cvl_code = p_code_midatindice AND p_class = acr_classe;

      RETURN l_recabundanceclassrange;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_getrecordbyindiceandvalue (
      p_code_midatindice   IN codevalue.cvl_code%TYPE,
      p_value              IN abundanceclassrange.acr_minvalue%TYPE)
      RETURN abundanceclassrange%ROWTYPE
   /*-----------------------------------------------------------------*/
   IS
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
   BEGIN
      SELECT abundanceclassrange.*
        INTO l_recabundanceclassrange
        FROM abundanceclassrange
             INNER JOIN codevalue ON cvl_id = acr_cvl_id_midatindice
       WHERE     cvl_code = p_code_midatindice
             AND p_value BETWEEN acr_minvalue AND acr_maxvalue;

      RETURN l_recabundanceclassrange;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_write (
      p_cvl_id_midatindice   IN     abundanceclassrange.acr_cvl_id_midatindice%TYPE,
      p_minvalue             IN     abundanceclassrange.acr_minvalue%TYPE,
      p_maxvalue             IN     abundanceclassrange.acr_maxvalue%TYPE,
      p_classe               IN     abundanceclassrange.acr_classe%TYPE,
      p_substitutevalue      IN     abundanceclassrange.acr_substitutevalue%TYPE,
      p_id                      OUT abundanceclassrange.acr_id%TYPE)
   /*--------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_abundanceclassrange.NEXTVAL;

      INSERT INTO abundanceclassrange (acr_cvl_id_midatindice,
                                       acr_minvalue,
                                       acr_maxvalue,
                                       acr_classe,
                                       acr_substitutevalue,
                                       acr_id)
           VALUES (p_cvl_id_midatindice,
                   p_minvalue,
                   p_maxvalue,
                   p_classe,
                   p_substitutevalue,
                   p_id);
   END;
END pkg_abundanceclassrange;
/

