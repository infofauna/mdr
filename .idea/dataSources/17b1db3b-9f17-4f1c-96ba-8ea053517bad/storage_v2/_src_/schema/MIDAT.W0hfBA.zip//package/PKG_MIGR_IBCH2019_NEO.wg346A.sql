create PACKAGE       pkg_migr_ibch2019_neo
AS
    /******************************************************************************
      NAME:       pkg_MIGR_ibch2019_neo
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
   ******************************************************************************/

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2020';


    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_insertall;
END;
/

