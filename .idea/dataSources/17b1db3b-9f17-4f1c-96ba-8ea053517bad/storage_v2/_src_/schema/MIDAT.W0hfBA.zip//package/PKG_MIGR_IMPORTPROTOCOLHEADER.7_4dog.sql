create PACKAGE       pkg_migr_importprotocolheader
AS
   /******************************************************************************
      NAME:       pkg_migr_importprotocolheader
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;


END pkg_migr_importprotocolheader;
/

