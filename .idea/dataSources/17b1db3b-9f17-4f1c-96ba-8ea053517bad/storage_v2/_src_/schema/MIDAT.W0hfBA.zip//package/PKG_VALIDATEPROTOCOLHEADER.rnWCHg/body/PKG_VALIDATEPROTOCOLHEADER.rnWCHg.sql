create PACKAGE BODY       pkg_validateprotocolheader
AS
    /******************************************************************************
       NAME:       PKG_VALIDATEPROTOCOLHEADER
       PURPOSE:

       NOTE: iph_observationdate (fournie normalement par le formulaire n'est pas demandé. On prend la date du formulaire iph_observationdatetxt)

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        08.10.2013      burrif       1. Created this package.
       1.1        16.03.2017      burrif       2. Règles de proximité
       1.2        21.01.2018      burrif       3. Nouvelle règles de gestion des droits
       1.3        11.09.2020      burrif       4. Externalisation Java
    ******************************************************************************/



    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.3, septembre 2020' ;



    gbl_coordinatesstatus         BOOLEAN := TRUE;

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_setcoordinatesstatus (p_status IN BOOLEAN)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        gbl_coordinatesstatus := p_status;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getcoordinatesstatus
        RETURN BOOLEAN
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_coordinatesstatus;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_logunexpectederror (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_fieldname                 IN importprotocollog.ipo_fieldname%TYPE,
        p_modulename                IN VARCHAR2)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        pkg_importprotocollog.p_writelog (p_recimportprotocolheader.iph_id,
                                          NULL,
                                          pkg_exception.cst_unexpectederror,
                                          p_fieldname,
                                          p_modulename);
    END;



    /*--------------------------------------------------------------*/
    PROCEDURE p_getsamplestationitemold (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_recsamplestation          IN     samplestation%ROWTYPE,
        p_smpstaitmtyp_code         IN     codevalue.cvl_code%TYPE,
        p_fieldname                 IN     importprotocollog.ipo_fieldname%TYPE,
        p_recsamplestationitem         OUT samplestationitem%ROWTYPE)
    /*---------------------------------------------------------------*/
    IS
        l_module   VARCHAR2 (1024);
    BEGIN
        p_recsamplestationitem :=
            pkg_samplestationitem.f_getatleastonerecord (
                p_recsamplestation.sst_id,
                p_recimportprotocolheader.iph_lan_id,
                p_smpstaitmtyp_code);

        IF p_recsamplestationitem.ssi_id IS NULL
        THEN
            l_module :=
                   '"pkg_samplestationitem.f_getatleastonerecord('
                || TO_CHAR (p_recsamplestation.sst_id)
                || ', '
                || TO_CHAR (p_recimportprotocolheader.iph_lan_id)
                || ', '
                || p_smpstaitmtyp_code
                || ')';
            p_logunexpectederror (p_recimportprotocolheader,
                                  p_fieldname,
                                  l_module);
        END IF;
    END;



    /*--------------------------------------------------------------*/
    PROCEDURE p_getreccodedesignation (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_fieldname                 IN     protocolmappingheader.pmh_fieldnameto%TYPE,
        p_cvl_id                    IN     codevalue.cvl_id%TYPE,
        p_module                    IN     VARCHAR2,
        p_lan_id                    IN     language.lan_id%TYPE,
        p_reccodedesignation           OUT codedesignation%ROWTYPE,
        p_returnstatus                 OUT NUMBER)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_getreccodedesignation',
            'p_cvl_id=' || p_cvl_id || ' _lan_id=' || p_lan_id);
        p_reccodedesignation :=
            pkg_codedesignation.f_returnrecmaintypeatleastone (p_cvl_id,
                                                               p_lan_id);

        IF p_reccodedesignation.cdn_id IS NULL
        THEN
            p_logunexpectederror (p_recimportprotocolheader,
                                  p_fieldname,
                                  p_module);

            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        p_returnstatus := pkg_constante.cst_returnstatusok;
    END;



    /*-------------------------------------------------------------*/
    PROCEDURE p_getrecprotocolmappingheader (
        p_recimportprotocolheader    IN     importprotocolheader%ROWTYPE,
        p_fieldnameto                IN     protocolmappingheader.pmh_fieldnameto%TYPE,
        p_module                     IN     VARCHAR2,
        p_recprototolmappingheader      OUT protocolmappingheader%ROWTYPE,
        p_returnstatus                  OUT NUMBER)
    /*----------------------------------------------------------------------------------*/
    IS
    BEGIN
        p_recprototolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandfieldnameto (
                p_recimportprotocolheader.iph_ptv_id,
                p_fieldnameto);
        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_getrecprotocolmappingheader',
               'p_filenameto='
            || p_fieldnameto
            || ' p_recimportprotocolheader.iph_ptv_id= '
            || p_recimportprotocolheader.iph_ptv_id);

        IF p_recprototolmappingheader.pmh_id IS NULL
        THEN
            p_logunexpectederror (p_recimportprotocolheader,
                                  p_fieldnameto,
                                  p_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        p_returnstatus := pkg_constante.cst_returnstatusok;
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_getrecdesignationbyrechd (
        p_record                     IN     importprotocolheader%ROWTYPE,
        p_fieldnameto                IN     VARCHAR2,
        p_reccodedesignation            OUT codedesignation%ROWTYPE,
        p_recprototolmappingheader      OUT protocolmappingheader%ROWTYPE,
        p_returnstatus                  OUT NUMBER)
    /*------------------------------------------------------------*/
    IS
        l_module         VARCHAR2 (1024);

        l_returnstatus   NUMBER;
    BEGIN
        l_module :=
               '"PKG_PROTOCOLMAPPINGHEADER.f_getrecordbyptvandfieldnameto('
            || TO_CHAR (p_record.iph_ptv_id)
            || ','
            || p_fieldnameto
            || ') "';
        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_getrecdesignationbyrechd',
            'l_module=' || l_module);

        p_getrecprotocolmappingheader (p_record,
                                       p_fieldnameto,
                                       l_module,
                                       p_recprototolmappingheader,
                                       l_returnstatus);



        IF l_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_returnstatus := l_returnstatus;
            RETURN;
        END IF;

        l_module :=
               '"pkg_codedesignation.f_returnrecmaintypeatleastone('
            || TO_CHAR (p_recprototolmappingheader.pmh_cvl_id_midathditem)
            || ','
            || TO_CHAR (p_record.iph_lan_id)
            || ') "';

        p_getreccodedesignation (
            p_record,
            p_fieldnameto,
            p_recprototolmappingheader.pmh_cvl_id_midathditem,
            l_module,
            p_record.iph_lan_id, -- On prend la langue du formulaire car le nom du champ affiché est dans cette langue dans la feuille
            p_reccodedesignation,
            l_returnstatus);

        IF l_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_returnstatus := l_returnstatus;
            RETURN;
        END IF;

        p_returnstatus := pkg_constante.cst_returnstatusok;
    END;

    /*-----------------------------------------------------------------------------------------*/
    PROCEDURE p_logstationproximity (
        p_record    IN     importprotocolheader%ROWTYPE,
        p_usr_id    IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_counter      OUT NUMBER)
    /*-----------------------------------------------------------------------------------------*/
    /*
   On entre dans cette procedure si on n'a pas pu trouver de station par son OID
   On dresse la liste des stations dans le rayon de proximités
 */
    IS
        CURSOR l_cursor (p1 IN MDSYS.sdo_geometry)
        IS
            SELECT samplestation.*,
                   pkg_sdoutil.f_computedistance2d (p1, sst_coordinates) distance
              FROM samplestation
                   INNER JOIN sampleheader ON sst_id = sph_sst_id
             WHERE     pkg_sdoutil.f_computedistance2d (p1, sst_coordinates) <=
                       pkg_codevalue.f_get_midatparam_rayontol
                   AND sph_ins_id_principal = p_record.iph_ins_id_principal;

        l_reccursor             l_cursor%ROWTYPE;
        l_headerdisplay         BOOLEAN := FALSE;
        l_x1                    NUMBER;
        l_y1                    NUMBER;
        l_z1                    NUMBER;
        l_point                 MDSYS.sdo_geometry;
        l_locality              sampleheaderitem.shm_item%TYPE;
        l_watercourse           sampleheaderitem.shm_item%TYPE;
        l_recsamplestation      samplestation%ROWTYPE;
        l_recsampleheader       sampleheader%ROWTYPE;
        l_recsampleheaderitem   sampleheaderitem%ROWTYPE;
        l_count                 NUMBER := 0;
    BEGIN
        l_x1 := pkg_datatype.f_validatedouble (p_record.iph_startpoint_x);
        l_y1 := pkg_datatype.f_validatedouble (p_record.iph_startpoint_y);
        l_z1 := pkg_datatype.f_validatedouble (p_record.iph_elevation);
        l_point :=
            pkg_sdoutil.f_buildsdo_geometry (TO_NUMBER (l_x1),
                                             TO_NUMBER (l_y1),
                                             TO_NUMBER (l_z1));

        OPEN l_cursor (l_point);



        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND;
            l_count := l_count + 1;

            IF NOT l_headerdisplay
            THEN --Liste des stations dans le rayon de tolérance %p1% (m) autour de la station (OID: %p2%, cours d'eau: %p3%, localité: %p4%)
                l_headerdisplay := TRUE;
                pkg_importprotocollog.p_writelog (
                    p_record.iph_id,
                    NULL,
                    pkg_exception.cst_stationproximitylist,
                    'IPH_STARTPOINT_X, IPH_STARTPOINT_Y, IPH_ELEVATION',
                    TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol),   -- p1
                    p_record.iph_oid,                                    -- p2
                    p_record.iph_watercourse,                            -- p3
                    p_record.iph_locality);                              -- p4
            END IF;

            l_recsampleheader :=
                pkg_sampleheader.f_returnlastrecordbysstid (
                    l_reccursor.sst_id);
            l_recsampleheaderitem :=
                pkg_sampleheaderitem.f_getrecordfromlaboratory (
                    l_recsampleheader.sph_id,
                    pkg_codevalue.cst_midathditem_locality);
            l_locality := l_recsampleheaderitem.shm_item;
            l_recsampleheaderitem :=
                pkg_sampleheaderitem.f_getrecordfromlaboratory (
                    l_recsampleheader.sph_id,
                    pkg_codevalue.cst_midathditem_watercourse);
            l_watercourse := l_recsampleheaderitem.shm_item;
            --%p1%. OID=%p2%, cours d'eau: %p3%, localité: %p4%. Distance par rapport à la station %p5%: %p6% m
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_stationproximitydetail,
                'IPH_STARTPOINT_X, IPH_STARTPOINT_Y, IPH_ELEVATION',
                TRIM (TO_CHAR (l_count)),
                l_reccursor.sst_oid,
                l_watercourse,
                l_locality,
                p_record.iph_oid,
                TRIM (TO_CHAR (l_reccursor.distance)));
        END LOOP;

        CLOSE l_cursor;

        p_counter := l_count;



        NULL;
    END;


    /*-----------------------------------------------------------------------------------------*/
    PROCEDURE p_checkstationlaboratory (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------------*/
    /*
      On entre dans cette procedure si on n'a pas pu trouver de station par son OID
      On cherche une station existante par sa coordonnées
    */
    IS
        cst_distancemax   CONSTANT NUMBER := 999999999;
        l_returnstatus             NUMBER;
        l_point                    MDSYS.sdo_geometry;
        l_distance                 NUMBER;
        l_x                        NUMBER;
        l_y                        NUMBER;
        l_z                        NUMBER;
        l_sst_id                   samplestation.sst_id%TYPE;

        CURSOR l_cursor (p1 IN MDSYS.sdo_geometry)
        IS
            SELECT samplestation.*,
                   pkg_sdoutil.f_computedistance2d (p1, sst_coordinates) distance
              FROM samplestation
                   INNER JOIN sampleheader ON sst_id = sph_sst_id
             WHERE     pkg_sdoutil.f_computedistance2d (p1, sst_coordinates) <=
                       pkg_codevalue.f_get_midatparam_rayontol
                   AND sph_ins_id_principal = p_record.iph_ins_id_principal;

        CURSOR l_cursormatch (p1 IN MDSYS.sdo_geometry)
        IS
            SELECT samplestation.*,
                   pkg_sdoutil.f_computedistance2d (p1, sst_coordinates) distance
              FROM samplestation
                   INNER JOIN sampleheader ON sst_id = sph_sst_id
             WHERE     pkg_sdoutil.f_computedistance2d (p1, sst_coordinates) <=
                       pkg_codevalue.f_get_midatparam_rayonmatch
                   AND sph_ins_id_principal = p_record.iph_ins_id_principal;

        l_reccursor                l_cursor%ROWTYPE;
        l_headerdisplay            BOOLEAN := FALSE;
        l_locality                 sampleheaderitem.shm_item%TYPE;
        l_watercourse              sampleheaderitem.shm_item%TYPE;
        l_recsamplestation         samplestation%ROWTYPE;
        l_recsampleheader          sampleheader%ROWTYPE;
        l_recsampleheaderitem      sampleheaderitem%ROWTYPE;
        l_x1                       NUMBER;
        l_y1                       NUMBER;
        l_z1                       NUMBER;
        l_countdisplay             NUMBER;

        l_coordinates              SDO_GEOMETRY;
        l_count                    NUMBER := 0;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        IF (NOT f_getcoordinatesstatus)
        THEN
            RETURN;
        END IF;

        p_logstationproximity (p_record, p_usr_id, l_countdisplay);

        IF l_countdisplay = 0
        THEN
            -- Pas de station dans les alentours, on peut sortir car on va en créer une nouvelle
            RETURN;
        END IF;

        -- On cherche si la coordonnée est dans les tolérances de proximité d'une station existante
        l_x1 := pkg_datatype.f_validatedouble (p_record.iph_startpoint_x);
        l_y1 := pkg_datatype.f_validatedouble (p_record.iph_startpoint_y);
        l_z1 := pkg_datatype.f_validatedouble (p_record.iph_elevation);
        l_point :=
            pkg_sdoutil.f_buildsdo_geometry (TO_NUMBER (l_x1),
                                             TO_NUMBER (l_y1));
        l_count := 0;
        l_distance := cst_distancemax;

        OPEN l_cursormatch (l_point);

        LOOP
            FETCH l_cursormatch INTO l_reccursor;

            EXIT WHEN l_cursormatch%NOTFOUND;


            l_count := l_count + 1;

            IF l_reccursor.distance < l_distance
            THEN
                l_sst_id := l_reccursor.sst_id;
                l_distance := l_reccursor.distance;
                l_recsampleheader :=
                    pkg_sampleheader.f_returnlastrecordbysstid (
                        l_reccursor.sst_id);
                l_recsampleheaderitem :=
                    pkg_sampleheaderitem.f_getrecordfromlaboratory (
                        l_recsampleheader.sph_id,
                        pkg_codevalue.cst_midathditem_locality);
                l_locality := l_recsampleheaderitem.shm_item;
                l_recsampleheaderitem :=
                    pkg_sampleheaderitem.f_getrecordfromlaboratory (
                        l_recsampleheader.sph_id,
                        pkg_codevalue.cst_midathditem_watercourse);
                l_watercourse := l_recsampleheaderitem.shm_item;
                l_coordinates := l_reccursor.sst_coordinates;
            END IF;
        END LOOP;

        CLOSE l_cursormatch;

        IF l_count >= 1
        THEN
            -- exc_infostationfusion: La station (Cours d'eau: %p1% Localité %p2% Coordonnée: %p3%) se trouve à une distance de %p4% de la station
            --            (Cours d'eau: %p5% Localité %p6% Coordonnée: %p7%) . Ces deux stations (%p8%) sont fusionnées
            --            (les données de la première station sont concervées) car elles sont dans le rayon de tolérance (%p9%) de proximité autorisant la fusion

            pkg_importprotocolheader.p_updateexistingstation (
                p_record.iph_id,
                l_sst_id,
                p_usr_id);

            l_recsamplestation := pkg_samplestation.f_getrecord (l_sst_id);
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_infostationfusion,
                'IPH_SST_ID',
                p_record.iph_watercourse,
                p_record.iph_locality,
                   p_record.iph_startpoint_x
                || ';'
                || p_record.iph_startpoint_y
                || ';'
                || p_record.iph_elevation,
                TO_CHAR (l_distance) || ' m',
                l_watercourse,
                l_locality,
                   l_coordinates.sdo_point.x
                || ';'
                || l_coordinates.sdo_point.y
                || ';'
                || l_z,
                p_record.iph_oid || ' -> ' || l_recsamplestation.sst_oid,
                TO_CHAR (pkg_codevalue.f_get_midatparam_rayonmatch) || ' m',
                l_recsamplestation.sst_oid);
            p_returnstatus := pkg_constante.cst_returnstatusok;
            RETURN;
        END IF;

        IF l_countdisplay > 0
        THEN
            -- La nouvelle station définie (OID: %p1%, cours d''eau: %p2%, localité: %p3%, coordonnées: %p4%
            -- est dans le rayon de tolérance (%p5) m d'une ou plusieurs stations existante (voir ci-dessus)
            -- Si vous confirmez l'importation, une nouvelle station sera créée
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_stationintolerancproximity,
                'IPH_STARTPOINT_X, IPH_STARTPOINT_Y, IPH_ELEVATION',
                p_record.iph_oid,                                        -- p1
                p_record.iph_watercourse,                                -- p2
                p_record.iph_locality,                                   -- p3
                   'x='
                || p_record.iph_startpoint_x
                || ', y='
                || p_record.iph_startpoint_y
                || ', z='
                || p_record.iph_elevation,                                --p4
                pkg_codevalue.f_get_midatparam_rayontol);                -- p5

            NULL;
        END IF;



        p_returnstatus := pkg_constante.cst_returnstatusok;
    END;

    /*------------------------------------------------------------------------------------------*/
    PROCEDURE p_checkitemnotlaboratory (
        p_record             IN     importprotocolheader%ROWTYPE,
        p_value              IN     VARCHAR2,
        p_midathditmty       IN     codevalue.cvl_code%TYPE,
        p_fieldname          IN     importprotocollog.ipo_fieldname%TYPE,
        p_warningexception   IN     importprotocollog.ipo_exceptionnumber%TYPE,
        p_errorexception     IN     importprotocollog.ipo_exceptionnumber%TYPE,
        p_returnstatus          OUT NUMBER)
    /*-------------------------------------------------------------------------------------------*/

    IS
        l_designation                codedesignation.cdn_designation%TYPE;
        l_recprototolmappingheader   protocolmappingheader%ROWTYPE;
        l_recprotocolversion         protocolversion%ROWTYPE;
        l_codevalue                  codevalue%ROWTYPE;

        l_recsampleheaderitem        sampleheaderitem%ROWTYPE;
        l_recsampleheaderitemlabo    sampleheaderitem%ROWTYPE;
        l_recsampleheader_master     sampleheader%ROWTYPE;
        l_reclanguage_master         language%ROWTYPE;
        l_reclanguage_current        language%ROWTYPE;
        l_module                     VARCHAR2 (1024);
        l_returnstatus               NUMBER;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_recsampleheader_master :=
            pkg_sampleheader.f_getrecord (p_record.iph_sph_id_parent);

        IF l_recsampleheader_master.sph_id IS NULL
        THEN
            l_module :=
                   '"pkg_sampleheader.f_getrecord( '
                || NVL (TO_CHAR (p_record.iph_sph_id_parent), 'NULL')
                || ') "';
            pkg_importprotocollog.p_logunexpectederror (p_record.iph_id,
                                                        p_fieldname,
                                                        l_module);
        END IF;

        l_recprototolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidatitmstr (
                p_record.iph_ptv_id,
                p_midathditmty);

        IF l_recprototolmappingheader.pmh_id IS NULL
        THEN
            l_module :=
                   '" pkg_protocolmappingheader.f_getrecordbyptvandmidatitmstr( '
                || NVL (TO_CHAR (p_record.iph_ptv_id), 'NULL')
                || ','
                || p_midathditmty
                || ') "';
            pkg_importprotocollog.p_logunexpectederror (p_record.iph_id,
                                                        p_fieldname,
                                                        l_module);
        END IF;

        l_recsampleheaderitemlabo :=
            pkg_sampleheaderitem.f_getrecordfromlaboratory (
                p_record.iph_sph_id_parent,
                p_midathditmty);
        l_reclanguage_master :=
            pkg_language.f_getrecord (l_recsampleheaderitemlabo.shm_lan_id);

        l_reclanguage_current :=
            pkg_language.f_getrecord (p_record.iph_lan_id);

        l_recsampleheaderitem :=
            pkg_sampleheaderitem.f_getrecordwithtypeandlanid (
                l_recsampleheader_master.sph_id,
                p_midathditmty,
                p_record.iph_lan_id);


        IF l_recsampleheaderitem.shm_id IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                p_warningexception,
                p_fieldname,
                p_value,                                                 -- p1
                p_fieldname,                                             -- p2
                l_reclanguage_current.lan_designation,
                l_reclanguage_master.lan_designation);                    --p2
        ELSE
            IF TRIM (UPPER (p_value)) !=
               TRIM (UPPER (l_recsampleheaderitem.shm_item))
            THEN
                l_recprotocolversion :=
                    pkg_protocolversion.f_getrecord (
                        l_recsampleheaderitem.shm_ptv_id);
                l_codevalue :=
                    pkg_codevalue.f_getrecord (
                        l_recprotocolversion.ptv_cvl_id_protocoltype);
                l_designation :=
                    pkg_codedesignation.f_returndesignation (
                        l_codevalue.cvl_id,
                        p_record.iph_lan_id);
                pkg_importprotocollog.p_writelog (
                    p_record.iph_id,
                    NULL,
                    p_errorexception,
                    p_fieldname,
                    p_value,                                             -- p1
                    p_fieldname,                                          --p2
                    l_recsampleheaderitem.shm_item,                      -- p3
                    l_designation,                                        --p4
                    pkg_stringutil.f_buildexcelcellref (
                        l_recprototolmappingheader.pmh_cellrowvalue,
                        l_recprototolmappingheader.pmh_cellcolumnvalue)); --p5

                p_returnstatus :=
                    pkg_message.f_convertseveritylevel2status (
                        pkg_exception.cst_stationnotmatch);

                IF p_returnstatus != pkg_constante.cst_returnstatusok
                THEN
                    RETURN;
                END IF;
            END IF;
        END IF;
    END;

    /*-----------------------------------------------------------------------------------------*/
    PROCEDURE p_checkstationnotlaboratory (
        p_record             IN     importprotocolheader%ROWTYPE,
        p_recsamplestation   IN     samplestation%ROWTYPE,
        p_returnstatus          OUT NUMBER)
    /*------------------------------------------------------------------------------------------*/
    IS
        /*
        1) Le nom de la rivère doit exister dans une des langues  dans laquelle les autres formulaires (laboratory, grid, données principales) ont été saisies
        2) Si la langue de définition du header n'a pas encore été utilisé pour définir un formalaire alors la données est accepté
        3) Idem pour la localité et le lieu dit
        4) La coordonnées doit être identique à celle du protocol de laboratoire ou dans les limite accepté

        Attention: A ce niveau, le sampleheader est identifié
        */



        l_recsampleheaderitem   sampleheaderitem%ROWTYPE;
        l_returnstatus          NUMBER;
        l_point                 MDSYS.sdo_geometry;
        l_distance              NUMBER;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        p_checkitemnotlaboratory (p_record,
                                  p_record.iph_locality,
                                  pkg_codevalue.cst_midathditmty_locality,
                                  'IPH_LOCALITY',
                                  pkg_exception.cst_subformvaluenotinlanid,
                                  pkg_exception.cst_subformvaluenotmatch,
                                  l_returnstatus);

        IF l_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_returnstatus := l_returnstatus;
        END IF;

        p_checkitemnotlaboratory (p_record,
                                  p_record.iph_watercourse,
                                  pkg_codevalue.cst_midathditmty_watercourse,
                                  'IPH_WATERCOURSE',
                                  pkg_exception.cst_subformvaluenotinlanid,
                                  pkg_exception.cst_subformvaluenotmatch,
                                  l_returnstatus);

        IF l_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_returnstatus := l_returnstatus;
        END IF;

        -- Le point de départ doit être dans un rayon de 10 mètres du point déjà enregistré
        l_point :=
            pkg_sdoutil.f_buildsdo_geometry (p_record.iph_startpoint_x,
                                             p_record.iph_startpoint_y);
        l_distance :=
            pkg_sdoutil.f_computedistance2d (
                l_point,
                p_recsamplestation.sst_coordinates);

        IF     l_distance > 0
           AND l_distance <= pkg_codevalue.f_get_midatparam_startptinfo
        THEN
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_distanceininfolimit,
                'IPH_STARTPOINT_X, IPH_STARTPOINT_Y, IPH_ELEVATION',
                   'x='
                || p_record.iph_startpoint_x
                || ', y='
                || p_record.iph_startpoint_y
                || ', z='
                || p_record.iph_elevation,                               -- p1
                TO_CHAR (l_distance) || ' m',                             --p2
                TO_CHAR (pkg_codevalue.f_get_midatparam_startptinfo) || ' m'); -- p3

            l_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_distanceininfolimit);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
                RETURN;
            END IF;
        ELSIF     l_distance > pkg_codevalue.f_get_midatparam_startptinfo
              AND l_distance <= pkg_codevalue.f_get_midatparam_startptwarn
        THEN
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_distancewarninglimit,
                'IPH_STARTPOINT_X, IPH_STARTPOINT_Y, IPH_ELEVATION',
                   'x='
                || p_record.iph_startpoint_x
                || ', y='
                || p_record.iph_startpoint_y
                || ', z='
                || p_record.iph_elevation,                               -- p1
                TO_CHAR (l_distance) || ' m',                             --p2
                TO_CHAR (pkg_codevalue.f_get_midatparam_startptinfo) || ' m'); -- p3
            l_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_distancewarninglimit);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
                RETURN;
            END IF;
        ELSIF l_distance > pkg_codevalue.f_get_midatparam_startptwarn
        THEN
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_distanceoutofrange,
                'IPH_STARTPOINT_X, IPH_STARTPOINT_Y, IPH_ELEVATION',
                   'x='
                || p_record.iph_startpoint_x
                || ', y='
                || p_record.iph_startpoint_y
                || ', z='
                || p_record.iph_elevation,                               -- p1
                TO_CHAR (l_distance) || ' m',                             --p2
                TO_CHAR (pkg_codevalue.f_get_midatparam_startptwarn) || ' m'); -- p3
            l_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_distanceoutofrange);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
                RETURN;
            END IF;
        END IF;
    END;

    /*-----------------------------------------------------------------------------------------*/
    PROCEDURE p_checkstationoidexistlaborato (
        p_record             IN     importprotocolheader%ROWTYPE,
        p_recsamplestation   IN     samplestation%ROWTYPE,
        p_returnstatus          OUT NUMBER)
    /*------------------------------------------------------------------------------------------*/
    IS
        /*

        1) La coordonnées doit être identique à celle du protocol de laboratoire ou dans les limite accepté

        Attention: A ce niveau, le sampleheader est identifié
        */



        l_recsampleheaderitem   sampleheaderitem%ROWTYPE;
        l_returnstatus          NUMBER;
        l_point                 MDSYS.sdo_geometry;
        l_distance              NUMBER;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;


        -- Le point de départ doit être dans un rayon de 10 mètres du point déjà enregistré
        l_point :=
            pkg_sdoutil.f_buildsdo_geometry (p_record.iph_startpoint_x,
                                             p_record.iph_startpoint_y,
                                             p_record.iph_elevation);
        l_distance :=
            pkg_sdoutil.f_computedistance2d (
                l_point,
                p_recsamplestation.sst_coordinates);

        IF     l_distance > 0
           AND l_distance <= pkg_codevalue.f_get_midatparam_startptinfo
        THEN
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_distanceininfolimit,
                'IPH_STARTPOINT_X, IPH_STARTPOINT_Y, IPH_ELEVATION',
                   'x='
                || p_record.iph_startpoint_x
                || ', y='
                || p_record.iph_startpoint_y
                || ', z='
                || p_record.iph_elevation,                               -- p1
                TO_CHAR (l_distance) || ' m',                             --p2
                TO_CHAR (pkg_codevalue.f_get_midatparam_startptinfo) || ' m'); -- p3

            l_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_distanceininfolimit);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
                RETURN;
            END IF;
        ELSIF     l_distance > pkg_codevalue.f_get_midatparam_startptinfo
              AND l_distance <= pkg_codevalue.f_get_midatparam_startptwarn
        THEN
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_distancewarninglimit,
                'IPH_STARTPOINT_X, IPH_STARTPOINT_Y, IPH_ELEVATION',
                   'x='
                || p_record.iph_startpoint_x
                || ', y='
                || p_record.iph_startpoint_y
                || ', z='
                || p_record.iph_elevation,                               -- p1
                TO_CHAR (l_distance) || ' m',                             --p2
                TO_CHAR (pkg_codevalue.f_get_midatparam_startptinfo) || ' m'); -- p3
            l_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_distancewarninglimit);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
                RETURN;
            END IF;
        ELSIF l_distance > pkg_codevalue.f_get_midatparam_startptwarn
        THEN
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_distanceoutofrange,
                'IPH_STARTPOINT_X, IPH_STARTPOINT_Y, IPH_ELEVATION',
                   'x='
                || p_record.iph_startpoint_x
                || ', y='
                || p_record.iph_startpoint_y
                || ', z='
                || p_record.iph_elevation,                               -- p1
                TO_CHAR (l_distance) || ' m',                             --p2
                TO_CHAR (pkg_codevalue.f_get_midatparam_startptinfo) || ' m'); -- p3
            l_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_distanceoutofrange);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
                RETURN;
            END IF;
        END IF;
    END;



    /*-----------------------------------------------------------------------------------------*/
    PROCEDURE p_checkstationbycoordinateold (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*----------------------------------------------------------------------------------------*/
    IS
    BEGIN
        NULL;
    END;

    /*------------------------------------------------------------------------------*/

    PROCEDURE p_verifynotallreadyexist (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------*/
    IS
        /* Cette procedure ne doit être appelé qui si aucune erreur n'est détecté */
        l_sampleheader               sampleheader%ROWTYPE;


        l_date                       DATE;

        l_virtimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;


        -- Si le protocol n'est pas de type laboratre, le INS_id_principal n'est pas défini
        l_virtimportprotocolheader :=
            pkg_importprotocolheader.f_getvirtimportheaderprotocol (
                p_record.iph_id);


        IF l_virtimportprotocolheader.iph_id IS NULL
        THEN
            p_logunexpectederror (
                p_record,
                NULL,
                   'pkg_importprotocolheader.f_getvirtimportheaderprotocol ('
                || TO_CHAR (p_record.iph_id)
                || ')');
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;


        l_date := TO_DATE (p_record.iph_observationdatetxt, 'DD/MM/YYYY');


        l_sampleheader :=
            pkg_sampleheader.f_getrecordbyoidanddate (
                p_record.iph_oid,
                l_virtimportprotocolheader.iph_ins_id_principal,
                l_date,
                p_record.iph_ptv_id);

        IF NOT l_sampleheader.sph_id IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_protocolallreadyexist,
                'ALL FIELDS',
                p_record.iph_sheetname,
                TO_CHAR (l_sampleheader.sph_credate, 'DD/MM/YYYY hh24:mi:ss'));
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_protocolallreadyexist);

            IF p_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                RETURN;
            END IF;
        END IF;
    END;



    /*-------------------------------------------------------------*/
    PROCEDURE p_validaterequired (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_fieldcontent   IN     VARCHAR2,
        p_fieldnameto    IN     VARCHAR2,
        p_returnstatus      OUT NUMBER)
    /*-------------------------------------------------------------*/
    IS
        /*
         Champ obligatoire
        */
        l_reccodedesignation         codedesignation%ROWTYPE;
        l_recprototolmappingheader   protocolmappingheader%ROWTYPE;
        l_severity                   MESSAGE.msg_severity%TYPE;
        l_message                    MESSAGE.msg_message%TYPE;
        l_returnstatus               NUMBER;
        l_module                     VARCHAR2 (1024);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        IF p_fieldcontent IS NULL
        THEN
            pkg_debug.p_write (
                'PKG_VALIDATEPROTOCOLHEADER.p_validaterequired',
                'start..');
            p_getrecdesignationbyrechd (p_record,
                                        p_fieldnameto,
                                        l_reccodedesignation,
                                        l_recprototolmappingheader,
                                        l_returnstatus);


            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
                RETURN;
            END IF;

            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_fieldrequired,
                p_fieldnameto,
                l_reccodedesignation.cdn_designation,
                pkg_stringutil.f_buildexcelcellref (
                    l_recprototolmappingheader.pmh_cellrowvalue,
                    l_recprototolmappingheader.pmh_cellcolumnvalue));
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_fieldrequired);

            IF p_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                RETURN;
            END IF;
        END IF;

        p_returnstatus := pkg_constante.cst_returnstatusok;
    END;


    /*-------------------------------------------------------------*/
    PROCEDURE p_validatedatatype (
        p_record                     IN     importprotocolheader%ROWTYPE,
        p_recprotocolmappingheader   IN     protocolmappingheader%ROWTYPE,
        p_fieldcontent               IN     VARCHAR2,
        p_returnstatus                  OUT NUMBER)
    /*-------------------------------------------------------------*/
    IS
        /*
         Dattype
        */
        l_reccodedesignation         codedesignation%ROWTYPE;
        l_recprototolmappingheader   protocolmappingheader%ROWTYPE;
        l_severity                   MESSAGE.msg_severity%TYPE;
        l_message                    MESSAGE.msg_message%TYPE;
        l_returnstatus               NUMBER;
        l_module                     VARCHAR2 (1024);
        l_datatypeok                 BOOLEAN;
        l_reccodevaluedatatype       codevalue%ROWTYPE;
        l_limite                     VARCHAR2 (100);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevaluedatatype :=
            pkg_codevalue.f_getrecord (
                p_recprotocolmappingheader.pmh_cvl_id_datatype);



        IF p_fieldcontent IS NULL
        THEN
            RETURN;
        END IF;

        l_datatypeok :=
            pkg_datatype.f_checkdatatypebyid (
                p_fieldcontent,
                p_recprotocolmappingheader.pmh_cvl_id_datatype);

        IF NOT l_datatypeok
        THEN
            l_module := 'pkg_validateprotocolheader.p_getreccodedesignation';
            p_getreccodedesignation (
                p_record,
                p_recprotocolmappingheader.pmh_fieldnameto,
                p_recprotocolmappingheader.pmh_cvl_id_midathditem,
                l_module,
                p_record.iph_lan_id, -- On prend la langue du formulaire car le nom du champ affiché est dans cette langue dans la feuille
                l_reccodedesignation,
                l_returnstatus);

            IF l_reccodevaluedatatype.cvl_code =
               pkg_codevalue.cst_datatype_swisscoordx
            THEN
                l_limite :=
                       '(Xmin: '
                    || TO_CHAR (pkg_datatype.cst_swisscoordinate_x_min)
                    || ', '
                    || ' Xmax: '
                    || TO_CHAR (pkg_datatype.cst_swisscoordinate_x_max)
                    || ')';
            ELSIF l_reccodevaluedatatype.cvl_code =
                  pkg_codevalue.cst_datatype_swisscoordy
            THEN
                l_limite :=
                       '(Ymin: '
                    || TO_CHAR (pkg_datatype.cst_swisscoordinate_y_min)
                    || ', '
                    || ' Ymax: '
                    || TO_CHAR (pkg_datatype.cst_swisscoordinate_y_max)
                    || ')';
            ELSIF l_reccodevaluedatatype.cvl_code =
                  pkg_codevalue.cst_datatype_swisselev
            THEN
                l_limite :=
                       '(Zmin: '
                    || TO_CHAR (pkg_datatype.cst_swisscoordinate_z_min)
                    || ', '
                    || ' Zmax: '
                    || TO_CHAR (pkg_datatype.cst_swisscoordinate_z_max)
                    || ')';
            END IF;



            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_datatypeexcelinvalid,
                p_recprotocolmappingheader.pmh_fieldnameto,
                p_fieldcontent,
                pkg_stringutil.f_buildexcelcellref (
                    p_recprotocolmappingheader.pmh_cellrowvalue,
                    p_recprotocolmappingheader.pmh_cellcolumnvalue),
                l_reccodedesignation.cdn_designation || l_limite);
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_datatypeexcelinvalid);

            IF p_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                RETURN;
            END IF;
        END IF;

        p_returnstatus := pkg_constante.cst_returnstatusok;
    END;

    /*--------------------------------------------------------------------------------------*/

    PROCEDURE p_getmidatitemdesignationtext (
        p_record            IN     importprotocolheader%ROWTYPE,
        p_cvl_code          IN     codevalue.cvl_code%TYPE,
        p_codedesignation      OUT codedesignation%ROWTYPE,
        p_returnstatus         OUT NUMBER)
    /*--------------------------------------------------------------------------------------*/
    IS
        l_codevalue         codevalue%ROWTYPE;
        l_codedesignation   codedesignation%ROWTYPE;
        l_module            VARCHAR2 (1024);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_codevalue :=
            pkg_codevalue.f_getfromcode (
                p_cvl_code,
                pkg_codereference.cst_crf_midathditem);

        IF l_codevalue.cvl_id IS NULL
        THEN
            l_module :=
                   'pkg_codevalue.f_getfromcode ('
                || p_cvl_code
                || ', '
                || pkg_codereference.cst_crf_midathditem
                || ')';
            p_logunexpectederror (p_record, NULL, l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        l_codedesignation :=
            pkg_codedesignation.f_returnrecmaintypeatleastone (
                l_codevalue.cvl_id,
                p_record.iph_lan_id);

        IF l_codedesignation.cdn_id IS NULL
        THEN
            l_module :=
                   'pkg_codedesignation.f_returnrecmaintypeatleastone('
                || TO_CHAR (l_codevalue.cvl_id)
                || ', '
                || TO_CHAR (p_record.iph_lan_id)
                || ')';
            p_logunexpectederror (p_record, NULL, l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        p_codedesignation := l_codedesignation;


        NULL;
    END;



    /*-------------------------------------------------------------------------------------*/

    PROCEDURE p_validateheadernotlaboratory (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_returnstatus      OUT NUMBER)
    /*--------------------------------------------------------------------------------------*/
    IS
        /* Permet de contrôler que l'entête du formulaire est identique à celui du formulaire d'échantillonage de référence
           l'entête de ce formulaire doit déjà avoir été préalablement validé */
        l_reccodevaluemidatproto    codevalue%ROWTYPE;
        l_recprotocolversion        protocolversion%ROWTYPE;
        l_recsampleprotocolheader   sampleheader%ROWTYPE;
        l_recsamplestation          samplestation%ROWTYPE;
        l_module                    VARCHAR2 (1024);
        l_reccodedesignation        codedesignation%ROWTYPE;
        l_recsamplestationitem      samplestationitem%ROWTYPE;
        l_date                      DATE;
    BEGIN
        -- Le formulaire ne doit pas être de type formulaire d'échantillonage
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (p_record.iph_ptv_id);

        IF l_recprotocolversion.ptv_id IS NULL
        THEN
            l_module :=
                   'pkg_protocolversion.f_getrecord ('
                || p_record.iph_ptv_id
                || ')';
            p_logunexpectederror (p_record, NULL, l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        l_reccodevaluemidatproto :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);

        IF l_reccodevaluemidatproto.cvl_id IS NULL
        THEN
            l_module :=
                   'pkg_codevalue.f_getrecord ('
                || l_recprotocolversion.ptv_cvl_id_protocoltype
                || ')';
            p_logunexpectederror (p_record, NULL, l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        IF     l_reccodevaluemidatproto.cvl_code !=
               pkg_codevalue.cst_protocoltype_grdeval
           AND l_reccodevaluemidatproto.cvl_code !=
               pkg_codevalue.cst_protocoltype_ground
        THEN
            RETURN; -- Cette procédure ne doit pas être appelé pour d'autre protocole que ceux ci-dessous
        END IF;

        -- La colonne IPH_SPH_ID_PARENT doit contenir une valuer
        l_recsampleprotocolheader :=
            pkg_sampleheader.f_getrecord (p_record.iph_sph_id_parent);

        IF l_recsampleprotocolheader.sph_id IS NULL
        THEN
            l_module :=
                   'pkg_sampleheader.f_getrecord('
                || NVL (TO_CHAR (p_record.iph_sph_id_parent), 'NULL')
                || ')';

            p_logunexpectederror (p_record, NULL, l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;


        -- la date de l'observation doit être identique

        l_date := TO_DATE (p_record.iph_observationdatetxt, 'DD/MM/YYYY');


        IF l_recsampleprotocolheader.sph_observationdate != l_date
        THEN
            p_getmidatitemdesignationtext (
                p_record,
                pkg_codevalue.cst_midathditem_date,
                l_reccodedesignation,
                p_returnstatus);

            IF p_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                RETURN;
            END IF;

            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_protoheaderfieldnotmatch,
                'IPH_OBSERVATIONDATE',
                TO_CHAR (l_date, 'DD/MM/YYYY'),                           --p1
                l_reccodedesignation.cdn_designation,                     --p2
                p_record.iph_sheetname,                                   --p3
                l_reccodevaluemidatproto.cvl_code,                        --p4
                TO_CHAR (l_recsampleprotocolheader.sph_observationdate,
                         'DD/MM/YYYY'));                                 -- p5
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_protoheaderfieldnotmatch);

            IF p_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                RETURN;
            END IF;
        END IF;

        l_recsamplestation :=
            pkg_samplestation.f_getrecord (
                l_recsampleprotocolheader.sph_sst_id);

        IF l_recsamplestation.sst_id IS NULL
        THEN
            l_module :=
                   'pkg_samplestation.f_getrecord('
                || l_recsampleprotocolheader.sph_sst_id
                || ')';
            p_logunexpectederror (p_record, NULL, l_module);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        -- l'OID doit être identique
        IF l_recsamplestation.sst_oid != p_record.iph_oid
        THEN
            p_getmidatitemdesignationtext (p_record,
                                           pkg_codevalue.cst_midathditem_id,
                                           l_reccodedesignation,
                                           p_returnstatus);

            IF p_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                RETURN;
            END IF;

            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_protoheaderfieldnotmatch,
                'IPH_OID',
                p_record.iph_oid,
                l_reccodedesignation.cdn_designation,
                p_record.iph_sheetname,
                l_reccodevaluemidatproto.cvl_code,
                l_recsamplestation.sst_oid);
            p_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_protoheaderfieldnotmatch);

            IF p_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                RETURN;
            END IF;
        END IF;



        p_checkstationnotlaboratory (p_record,
                                     l_recsamplestation,
                                     p_returnstatus);

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;
    END;

    /*-------------------------------------------------------------------------------------*/
    PROCEDURE p_validateheaderlaboratory (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_returnstatus      OUT NUMBER)
    /*--------------------------------------------------------------------------------------^*/
    IS
        l_recsamplestation   samplestation%ROWTYPE;
        l_returnstatus       NUMBER;
    BEGIN
        p_verifynotallreadyexist (p_record, p_usr_id, l_returnstatus); -- La procédure ne s'exécute que si il n'y a pas encore d'erreur

        IF l_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_returnstatus := l_returnstatus;
            RETURN;
        END IF;


        l_recsamplestation :=
            pkg_samplestation.f_getrecordbyinsidandoid (
                p_record.iph_ins_id_principal,
                p_record.iph_oid);
        DBMS_OUTPUT.put_line (
               'ins_id: '
            || p_record.iph_ins_id_principal
            || ' oid: '
            || p_record.iph_oid
            || ' sst_id: '
            || l_recsamplestation.sst_id);

        IF l_recsamplestation.sst_id IS NULL
        THEN
            p_checkstationlaboratory (p_record, p_usr_id, p_returnstatus);
        ELSE
            -- Il faut encore vérifeir si la coordonnées fournie correspond aux valeur contenues dans la station exsitante
            /*-----------------------------------------------------------------------------------------*/

            p_checkstationoidexistlaborato (p_record,
                                            l_recsamplestation,
                                            l_returnstatus);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
                RETURN;
            END IF;

            pkg_importprotocolheader.p_updateexistingstation (
                p_record.iph_id,
                l_recsamplestation.sst_id,
                p_usr_id);
            p_returnstatus := l_returnstatus;
        END IF;
    END;

    /*-------------------------------------------------------------------------------------*/

    FUNCTION f_returnprotocoltype (p_record IN importprotocolheader%ROWTYPE)
        RETURN codevalue.cvl_code%TYPE
    /*-------------------------------------------------------------------------------------*/
    IS
        l_recprotocolversion       protocolversion%ROWTYPE;
        l_reccodevaluemidatproto   codevalue%ROWTYPE;
        l_module                   VARCHAR2 (1024);
    BEGIN
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (p_record.iph_ptv_id);

        IF l_recprotocolversion.ptv_id IS NULL
        THEN
            l_module :=
                   'pkg_protocolversion.f_getrecord ('
                || p_record.iph_ptv_id
                || ')';
            p_logunexpectederror (p_record, NULL, l_module);

            RETURN NULL;
        END IF;

        l_reccodevaluemidatproto :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);

        IF l_reccodevaluemidatproto.cvl_id IS NULL
        THEN
            l_module :=
                   'pkg_codevalue.f_getrecord ('
                || l_recprotocolversion.ptv_cvl_id_protocoltype
                || ')';
            p_logunexpectederror (p_record, NULL, l_module);

            RETURN NULL;
        END IF;

        RETURN l_reccodevaluemidatproto.cvl_code;
    END;

    /*-------------------------------------------------------------------------------------*/

    PROCEDURE p_postvalidateheader (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_returnstatus      OUT NUMBER)
    /*--------------------------------------------------------------------------------------^*/
    IS
        l_module         VARCHAR2 (1024);
        l_protocoltype   codevalue.cvl_code%TYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        l_protocoltype := f_returnprotocoltype (p_record);

        IF l_protocoltype IS NULL
        THEN
            RETURN;
        END IF;



        IF    l_protocoltype = pkg_codevalue.cst_protocoltype_grdeval
           OR l_protocoltype = pkg_codevalue.cst_protocoltype_ground
        THEN
            -- La station défini doit être identique au protocol du formulaire principal.
            -- Il ne doit pas exister un protocol de ce type déjà associé au protocol principal
            p_validateheadernotlaboratory (p_record,
                                           p_usr_id,
                                           p_returnstatus);
            RETURN;
        ELSIF l_protocoltype = pkg_codevalue.cst_protocoltype_laboratory
        THEN
            p_validateheaderlaboratory (p_record, p_usr_id, p_returnstatus);
            RETURN;
        END IF;
    END;

    /*------------------------------------------------------------------------------------*/

    PROCEDURE p_validatewatercourse (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_watercourse);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_watercourse,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_watercourse,
                            p_returnstatus);
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validateibch_q (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_ibchq);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;



        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            pkg_debug.p_write ('PKG_VALIDATEPROTOCOLHEADER.p_validateibch_q',
                               'Validate required IBCH_Q');
            p_validaterequired (p_record,
                                p_record.iph_ibchq,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_ibchq,
                            p_returnstatus);
    END;


    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatevc (p_record         IN     importprotocolheader%ROWTYPE,
                            p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_vc);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_vc,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_vc,
                            p_returnstatus);
    END;


    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatesommeept (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_sommeept);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);
        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLHEADER.p_validatesommeept',
                           'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validatesommeept',
               'l_recprotocolmappingheader.pmh_isnotnull='
            || l_recprotocolmappingheader.pmh_isnotnull);

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_sommeept,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_sommeept,
                            p_returnstatus);
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatesommeneoz (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_sommeneoz);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);
        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLHEADER.p_validatesommeneoz',
                           'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validatesommeneoz',
               'l_recprotocolmappingheader.pmh_isnotnull='
            || l_recprotocolmappingheader.pmh_isnotnull);

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_sommeneoz,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_sommeneoz,
                            p_returnstatus);
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatesommeabon (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_sommeabon);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);
        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLHEADER.p_validatesommeabon',
                           'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validatesommeabon',
               'l_recprotocolmappingheader.pmh_isnotnull='
            || l_recprotocolmappingheader.pmh_isnotnull);

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_sommeabon,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_sommeabon,
                            p_returnstatus);
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatesommetxobs (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_sommetxobs);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);
        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLHEADER.p_validatesommetxobs',
                           'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validatesommetxobs',
               'l_recprotocolmappingheader.pmh_isnotnull='
            || l_recprotocolmappingheader.pmh_isnotnull);

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_sommetxobs,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_sommetxobs,
                            p_returnstatus);
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatesommetxcor (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_sommetxcor);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);
        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLHEADER.p_validatesommetxcor',
                           'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validatesommetxcor',
               'l_recprotocolmappingheader.pmh_isnotnull='
            || l_recprotocolmappingheader.pmh_isnotnull);

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_sommetxcor,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_sommetxcor,
                            p_returnstatus);
    END;


    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatevaleurgimax (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_valeurgimax);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);
        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validatevaleurgimax',
            'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validatevaleurgimax',
               'l_recprotocolmappingheader.pmh_isnotnull='
            || l_recprotocolmappingheader.pmh_isnotnull);

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_valeurgimax,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_valeurgimax,
                            p_returnstatus);
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatevaleurvt (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_valeurvt);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);
        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLHEADER.p_validatevaleurvt',
                           'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validatevaleurvt',
               'l_recprotocolmappingheader.pmh_isnotnull='
            || l_recprotocolmappingheader.pmh_isnotnull);

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_valeurvt,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_valeurvt,
                            p_returnstatus);
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatevaleurgi (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_valeurgi);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);
        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLHEADER.p_validatevaleurgi',
                           'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validatevaleurgi',
               'l_recprotocolmappingheader.pmh_isnotnull='
            || l_recprotocolmappingheader.pmh_isnotnull);

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_valeurgi,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_valeurgi,
                            p_returnstatus);
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validateibchvalue (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_ibchvalue);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);
        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLHEADER.p_validateibchvalue',
                           'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validateibchvalue',
               'l_recprotocolmappingheader.pmh_isnotnull='
            || l_recprotocolmappingheader.pmh_isnotnull);

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_ibchvalue,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_ibchvalue,
                            p_returnstatus);
    END;


    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validateibchvalue_r (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_ibchvalue_r);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);
        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLHEADER.p_validateibchvalue',
                           'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validateibchvalue_r',
               'l_recprotocolmappingheader.pmh_isnotnull='
            || l_recprotocolmappingheader.pmh_isnotnull);

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_ibchvalue_r,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_ibchvalue_r,
                            p_returnstatus);
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatespearvalue (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_spearvalue);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);
        pkg_debug.p_write ('PKG_VALIDATEPROTOCOLHEADER.p_validatespearvalue',
                           'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLHEADER.p_validatespearvalue',
               'l_recprotocolmappingheader.pmh_isnotnull='
            || l_recprotocolmappingheader.pmh_isnotnull);

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_spearvalue,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;

        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_spearvalue,
                            p_returnstatus);
    END;


    /*-----------------------------------------------------------------------------------*/
    PROCEDURE p_logdatewindowrange (
        p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_recindicetype          IN     codevalue%ROWTYPE,
        p_returnstatus              OUT NUMBER)
    /*-----------------------------------------------------------------------------------*/
    IS
        l_elevation      NUMBER;
        l_date           DATE;
        l_jourmoislist   VARCHAR2 (1024);
        l_periodetype    codevalue.cvl_code%TYPE;
        l_returnstatus   NUMBER;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        l_date :=
            pkg_datatype.f_validatedate (
                p_importprotocolheader.iph_observationdatetxt);

        IF l_date IS NULL
        THEN
            RETURN;
        END IF;

        l_elevation :=
            pkg_datatype.f_validateswisselev (
                p_importprotocolheader.iph_elevation);

        IF l_elevation IS NULL
        THEN
            RETURN;
        END IF;

        l_periodetype :=
            pkg_avaliabilitycalendar.f_computeperiodtype (
                p_recindicetype.cvl_id,
                l_date,
                l_elevation);

        IF l_periodetype IS NULL
        THEN
            RETURN;            -- Pas de période définie pour ce type d'indice
        END IF;


        IF l_periodetype = pkg_codevalue.cst_midat_window_tampon
        THEN
            pkg_avaliabilitycalendar.p_returnlistjourmoisnormal (
                p_recindicetype.cvl_id,
                l_elevation,
                l_jourmoislist);

            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_midatwindowtampon,
                'IPH_DATE',
                p_importprotocolheader.iph_observationdatetxt,
                p_recindicetype.cvl_code,
                l_jourmoislist);
            l_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_midatwindowtampon);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
            END IF;
        END IF;

        IF l_periodetype = pkg_codevalue.cst_midat_window_outer
        THEN
            pkg_avaliabilitycalendar.p_returnlistjourmoisnormal (
                p_recindicetype.cvl_id,
                l_elevation,
                l_jourmoislist);

            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_midatwindowouter,
                'IPH_DATE',
                p_importprotocolheader.iph_observationdatetxt,
                p_recindicetype.cvl_code,
                l_jourmoislist);
            l_returnstatus :=
                pkg_message.f_convertseveritylevel2status (
                    pkg_exception.cst_midatwindowtampon);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
                p_returnstatus := l_returnstatus;
            END IF;
        END IF;
    END;

    /*-----------------------------------------------------------------------------------*/
    PROCEDURE p_checkdatewindow (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        /* Le MAKROINDEX ne doit pas être calculé pour les protocole de laboratoire */

        l_recprotocolversion   protocolversion%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;


        l_recindicetypeibch    codevalue%ROWTYPE;
        l_recindicetypespear   codevalue%ROWTYPE;
        l_returnstatus         NUMBER;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (p_record.iph_ptv_id);
        l_reccodevalue :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);

        IF l_reccodevalue.cvl_code !=
           pkg_codevalue.cst_protocoltype_laboratory
        THEN
            RETURN; -- On ne test que la fenêtre de date pour le protocol de laboratoire
        END IF;



        l_recindicetypeibch :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_ibch);

        l_recindicetypespear :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_spear);



        p_logdatewindowrange (p_record, l_recindicetypeibch, l_returnstatus);

        IF l_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_returnstatus := l_returnstatus;
            RETURN;
        END IF;

        p_logdatewindowrange (p_record, l_recindicetypespear, l_returnstatus);

        IF l_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_returnstatus := l_returnstatus;
            RETURN;
        END IF;
    END;


    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatedate (p_record         IN     importprotocolheader%ROWTYPE,
                              p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_date);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_observationdatetxt,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;



        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_observationdatetxt,
                            p_returnstatus);

        IF p_returnstatus = pkg_constante.cst_returnstatusok
        THEN
            p_checkdatewindow (p_record, p_returnstatus);
        END IF;
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatestartx (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_startpointx);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_startpoint_x,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_setcoordinatesstatus (FALSE);
            RETURN;
        END IF;



        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_startpoint_x,
                            p_returnstatus);

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_setcoordinatesstatus (FALSE);
            RETURN;
        END IF;
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatestarty (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_startpointy);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_startpoint_y,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_setcoordinatesstatus (FALSE);
            RETURN;
        END IF;



        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_startpoint_y,
                            p_returnstatus);

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_setcoordinatesstatus (FALSE);
            RETURN;
        END IF;
    END;

    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_validatestationright (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_usr_id         IN     importprotocolheader.iph_usr_id_create%TYPE,
        p_returnstatus      OUT NUMBER)
    /*-------------------------------------------------------------------------------*/
    IS
        l_x                    NUMBER;
        l_y                    NUMBER;
        l_rightaccess          NUMBER;
        l_coordinates          SDO_GEOMETRY;
        l_recch_canton         ch_canton%ROWTYPE;
        l_reccodesesignation   codedesignation%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
        l_cantonfound          BOOLEAN := TRUE;
        l_distance             NUMBER;
        l_outofborder          BOOLEAN := FALSE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        IF NOT f_getcoordinatesstatus
        THEN
            RETURN;
        END IF;

        l_x := pkg_datatype.f_validatedouble (p_record.iph_startpoint_x);
        l_y := pkg_datatype.f_validatedouble (p_record.iph_startpoint_y);
        l_coordinates := pkg_sdoutil.f_buildsdo_geometry (l_x, l_y);
        pkg_ch_canton.p_findcontaincanton (l_coordinates, l_recch_canton);

        IF l_recch_canton.code IS NULL
        THEN
            -- Les coordonnées fournies (%p1%) pour la station %p2% ne permettent pas d'identifier le canton
            l_outofborder := TRUE;
            pkg_importprotocollog.p_writelog (
                p_record.iph_id,
                NULL,
                pkg_exception.cst_coordoutofswissboundary,
                NULL,
                TO_CHAR (l_x) || ';' || TO_CHAR (l_y),
                p_record.iph_oid);

            pkg_ch_canton.p_findnearcanton (l_coordinates,
                                            l_recch_canton,
                                            l_distance);
            l_distance := ROUND (l_distance);

            IF l_distance > pkg_codevalue.f_get_midatparam_rayoncnt
            THEN
                -- La frontière cantonale la plus proche "f$returncanton#1(%p1%)" se trouve a une distance de %p2% mètres. Cette distance est plus grande que le rayon de tolérance de %p3% mètres.
                l_cantonfound := FALSE;
                pkg_importprotocollog.p_writelog (
                    p_record.iph_id,
                    NULL,
                    pkg_exception.cst_cantonoutoftoleranceradius,
                    NULL,
                    l_recch_canton.code,
                    ROUND (l_distance, 2),
                    pkg_codevalue.f_get_midatparam_rayoncnt);
            ELSE
                -- Le canton "f$returncanton#1(%p1%)" est le plus proche de la coordonnées fournies (%p2%) pour la station %p3%. La frontière avec ce canton se situe à une distance de %p4% mètres. Cette distance se situe dans la tolérance admise de %p5% mètres
                pkg_importprotocollog.p_writelog (
                    p_record.iph_id,
                    NULL,
                    pkg_exception.cst_sampleassociatedtocanton,
                    NULL,
                    l_recch_canton.code,
                    TO_CHAR (l_x) || ';' || TO_CHAR (l_y),
                    p_record.iph_oid,
                    TO_CHAR (l_distance, '999990.99'),
                    pkg_codevalue.f_get_midatparam_rayoncnt);
                l_reccodevalue :=
                    pkg_codevalue.f_getfromcode (
                        pkg_codevalue.cst_canton_outofborder,
                        pkg_codereference.cst_crf_canton);
                pkg_importprotocolheader.p_update_iph_cvl_id_canton (
                    p_record.iph_id,
                    l_reccodevalue.cvl_id);
            END IF;
        ELSE
            l_reccodevalue :=
                pkg_codevalue.f_getfromcode (
                    l_recch_canton.code,
                    pkg_codereference.cst_crf_canton);
            pkg_importprotocolheader.p_update_iph_cvl_id_canton (
                p_record.iph_id,
                l_reccodevalue.cvl_id);
        END IF;

        IF l_cantonfound
        THEN
            pkg_rightutility_v2.p_checkwriteright (l_x,
                                                   l_y,
                                                   p_usr_id,
                                                   l_rightaccess);

            IF l_rightaccess = pkg_rightutility_v2.cst_rightaccessdenied
            THEN
                --La coordonnée géographique (%p1%) de la station %p2% est associée au canton "f$returncanton#1(%p3%)". Vous n'avez pas le droit d'enregistrer des données dans ce canton.

                pkg_importprotocollog.p_writelog (
                    p_record.iph_id,
                    NULL,
                    pkg_exception.cst_noprivilegetoinsertstation,
                    NULL,
                    TO_CHAR (l_x) || ';' || TO_CHAR (l_y),
                    p_record.iph_oid,
                    l_recch_canton.code);
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
            ELSE
                IF NOT l_outofborder
                THEN
                    -- Les coordonnées géographiques (%p1%) de la station %p2% se trouvent dans le canton de f$returncanton#1(%p3%)
                    pkg_importprotocollog.p_writelog (
                        p_record.iph_id,
                        NULL,
                        pkg_exception.cst_infocanton,
                        NULL,
                        TRIM (TO_CHAR (l_x) || ', ' || TO_CHAR (l_y)),
                        p_record.iph_oid,
                        l_recch_canton.code);
                END IF;
            END IF;
        END IF;
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_completedata (p_record         IN     importprotocolheader%ROWTYPE,
                              p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        cst_identifiedmodebyname   CONSTANT NUMBER := 0;
        cst_identifiedmodebyxy     CONSTANT NUMBER := 1;
        l_x                                 NUMBER;
        l_y                                 NUMBER;
        l_gwn25                             ch_gwn25%ROWTYPE;
        l_distance                          NUMBER;
        l_returnstatus                      NUMBER;
        l_gewissnr_gwn25                    NUMBER;
        l_identifiedmode                    NUMBER;
        l_gewissnrwrite                     NUMBER := NULL;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        IF NOT f_getcoordinatesstatus
        THEN
            RETURN;
        END IF;

        l_x := pkg_datatype.f_validatedouble (p_record.iph_startpoint_x);
        l_y := pkg_datatype.f_validatedouble (p_record.iph_startpoint_y);

        pkg_gis.p_returngewiss (l_x,
                                l_y,
                                l_gwn25,
                                l_distance,
                                l_returnstatus);

        IF l_returnstatus = pkg_constante.cst_returnstatusok
        THEN
            l_identifiedmode := cst_identifiedmodebyxy;
            l_gewissnrwrite := l_gwn25.gewissnr;
            NULL;
        ELSE
            IF l_distance < pkg_gis.cst_distancetolgewiss
            THEN
                IF NVL (l_gwn25.gewissnr, 0) != 0
                THEN
                    --  Impossible d'identifier le cours d'eau avec les données swisstopo car plusieurs cours d'eau se trouvent dans le rayon de tolérance (%p1%) autour de la coordonnée(%p2%)
                    pkg_importprotocollog.p_writelog (
                        p_record.iph_id,
                        NULL,
                        pkg_exception.cst_unableidentifywtcbyswissto,
                        NULL,
                        TO_CHAR (
                              pkg_gis.cst_othernotindeltatolerance
                            + pkg_gis.cst_distancetolgewiss),
                        TO_CHAR (l_x) || ' : ' || TO_CHAR (l_y));
                    --  cst_unableidentifywtcbyswissto
                    NULL;
                ELSE
                    --  Un cours d'eau a été trouvé avec les données swisstopo dans le rayon de tolérance (%p1%) autour de la coordonnée (%p2%) à une distance de %p3% mètres. Ce
                    --  cours d'eau n'a pas pu être identifié car il ne possède pas de valeur dans la colonne "gewissnr"
                    --cst_gewissnrmissing
                    pkg_importprotocollog.p_writelog (
                        p_record.iph_id,
                        NULL,
                        pkg_exception.cst_gewissnrmissing,
                        NULL,
                        TO_CHAR (pkg_gis.cst_distancetolgewiss),
                        TO_CHAR (l_x) || ' : ' || TO_CHAR (l_y),
                        TO_CHAR (l_distance, '9999999.9'));

                    NULL;
                END IF;
            ELSE
                -- Le cours d'eau n'a pu être identifié par ses coordonnées (%p1%)  dans la rayon de %p2% mètres. Le cours d'eau le plus proche se trouve à %p3% mètres (Nom: %p4%)
                -- cst_wtcoutofradius

                pkg_importprotocollog.p_writelog (
                    p_record.iph_id,
                    NULL,
                    pkg_exception.cst_wtcoutofradius,
                    NULL,
                    TO_CHAR (l_x) || ' : ' || TO_CHAR (l_y),
                    TO_CHAR (pkg_gis.cst_distancetolgewiss),
                    TO_CHAR (l_distance, '9999999.9'),
                    NVL (l_gwn25.name, '<nul>'));
            END IF;
        END IF;

        IF l_gewissnrwrite IS NULL
        THEN
            IF NOT p_record.iph_watercourse IS NULL
            THEN
                l_gewissnr_gwn25 :=
                    pkg_ch_gwn25.f_returngewissnrbyname (
                        p_record.iph_watercourse);

                IF NVL (l_gewissnr_gwn25, 0) != 0
                THEN
                    l_identifiedmode := cst_identifiedmodebyname;
                    l_gewissnrwrite := l_gewissnr_gwn25;
                END IF;
            END IF;
        END IF;

        IF NOT l_gewissnrwrite IS NULL
        THEN
            UPDATE importprotocolheader
               SET iph_gewissnr = l_gewissnrwrite
             WHERE iph_id = p_record.iph_id;

            IF l_identifiedmode = cst_identifiedmodebyxy
            THEN
                -- Le cours d'eau a pu être identifié dans le données de Swisstopo. Il est automatiquement renseignée avec les valeurs: Nom: %p1%, "gewissnr": %p2%
                -- cst_autocompletegewissnr
                pkg_importprotocollog.p_writelog (
                    p_record.iph_id,
                    NULL,
                    pkg_exception.cst_autocompletegewissnr,
                    NULL,
                    l_gwn25.name,
                    l_gwn25.gewissnr);
            END IF;

            IF l_identifiedmode = cst_identifiedmodebyname
            THEN
                -- Le cours d'eau a pu être identifié par son nom  (%p1%) qui est identique à celui contenu dans les données de Swisstopo
                pkg_importprotocollog.p_writelog (
                    p_record.iph_id,
                    NULL,
                    pkg_exception.cst_toponamematch,
                    NULL,
                    p_record.iph_watercourse);
            END IF;
        END IF;
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validateelevation (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
        l_x                          NUMBER;
        l_y                          NUMBER;
        l_elevation                  NUMBER;
        l_returnstatus               NUMBER;
        l_distance                   NUMBER;
        l_cvl_code                   codevalue.cvl_code%TYPE;
        l_cvl_code_origin            codevalue.cvl_code%TYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_elevation);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_elevation,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_setcoordinatesstatus (FALSE);
            RETURN;
        END IF;



        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_elevation,
                            p_returnstatus);

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_setcoordinatesstatus (FALSE);
            RETURN;
        END IF;

        l_x := pkg_datatype.f_validatedouble (p_record.iph_startpoint_x);
        l_y := pkg_datatype.f_validatedouble (p_record.iph_startpoint_y);

        IF NOT l_x IS NULL AND NOT l_y IS NULL
        THEN
            pkg_gis.p_returnelevation (p_record.iph_startpoint_x,
                                       p_record.iph_startpoint_y,
                                       l_elevation,
                                       l_cvl_code_origin,
                                       l_returnstatus);
            pkg_gis.p_checkorigineelevation (p_record.iph_id,
                                             l_cvl_code_origin);

            IF l_returnstatus = pkg_constante.cst_returnstatusok
            THEN
                IF ABS (
                         l_elevation
                       - pkg_datatype.f_validatedouble (
                             p_record.iph_elevation)) >
                   pkg_validateprotocolheader.cst_elevationtolerance
                THEN
                    -- L'altitude fournie (%p1%) ne correspond pas avec celle (%p2%) fournie par le service Swisstopo
                    pkg_importprotocollog.p_writelog (
                        p_record.iph_id,
                        NULL,
                        pkg_exception.cst_elevationformnotmatchprovi,
                        NULL,
                        p_record.iph_elevation,
                        TO_CHAR (l_elevation));
                END IF;
            END IF;
        END IF;
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validateoperator (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_operator);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_operator,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;



        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_operator,
                            p_returnstatus);

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatedeterminator (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_determinator);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_determinator,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;



        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_determinator,
                            p_returnstatus);

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validateabsolutenumberflag (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_absoluteflag);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_absolutenumberflag,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;



        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_absolutenumberflag,
                            p_returnstatus);

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;
    END;

    /*------------------------------------------------------------------------------------*/
    PROCEDURE p_validatelocality (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingheader   protocolmappingheader%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                pkg_codevalue.cst_midathditem_locality);


        l_recprotocolmappingheader :=
            pkg_protocolmappingheader.f_getrecordbyptvandmidathditem (
                p_record.iph_ptv_id,
                l_reccodevalue.cvl_id);

        IF l_recprotocolmappingheader.pmh_id IS NULL
        THEN
            -- Le protocole  en question ne comporte pas ce champ. Rien à valider
            RETURN;
        END IF;

        IF NVL (l_recprotocolmappingheader.pmh_isnotnull,
                pkg_constante.cst_no) =
           pkg_constante.cst_yes
        THEN
            p_validaterequired (p_record,
                                p_record.iph_locality,
                                l_recprotocolmappingheader.pmh_fieldnameto,
                                p_returnstatus);
        END IF;

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;



        p_validatedatatype (p_record,
                            l_recprotocolmappingheader,
                            p_record.iph_locality,
                            p_returnstatus);

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN;
        END IF;
    END;



    /*----------------------------------------------------------------------------------------*/

    PROCEDURE p_checklaboallreadyexist (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE)
    /*---------------------------------------------------------------------------------------*/
    IS
    -- Permet de contrôler si le protocole de laboratoire a déjà été chargé

    BEGIN
        /*
         SELECT * FROM sampleheader inner join samplestation on sph_sst_id=sst_id
                        inner join samplestationitem on sst_id= ssi_sst_id
                        inner join sampleheaderitem on shm_sph_id = sph_id;

         */



        NULL;
    END;



    /*------------------------------------------------------------------------------*/

    PROCEDURE p_validateoid (
        p_record         IN     importprotocolheader%ROWTYPE,
        p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_returnstatus      OUT NUMBER)
    /*------------------------------------------------------------------------------------*/
    IS
        cst_fieldnameto   CONSTANT protocolmappingheader.pmh_fieldnameto%TYPE
                                       := 'IPH_OID' ;

        l_returnstatus             NUMBER;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        p_validaterequired (p_record,
                            p_record.iph_oid,
                            cst_fieldnameto,
                            l_returnstatus);

        IF l_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            p_returnstatus := l_returnstatus;
            RETURN;
        END IF;
    END;

    /*------------------------------------------------------------------------*/

    FUNCTION f_preservebadstatus (p_currentstatus   IN NUMBER,
                                  p_oldstatus          NUMBER)
        RETURN NUMBER
    /*-----------------------------------------------------------------------*/
    IS
    BEGIN
        IF p_currentstatus != pkg_constante.cst_returnstatusok
        THEN
            RETURN p_currentstatus;
        ELSE
            RETURN p_oldstatus;
        END IF;
    END;



    /*-----------------------------------------------------------------------*/

    PROCEDURE p_validatemain (
        p_iph_id         IN     importprotocolheader.iph_id%TYPE,
        p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_returnstatus      OUT NUMBER)
    /*----------------------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_returnstatus              NUMBER;
        l_masterstatus              NUMBER
                                        := pkg_constante.cst_returnstatusok;
        l_recprotocolversion        protocolversion%ROWTYPE;
    BEGIN
        p_setcoordinatesstatus (TRUE);

        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                l_recimportprotocolheader.iph_ptv_id);

        p_validatewatercourse (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatedate (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatestartx (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatestarty (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validateelevation (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_completedata (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validateoperator (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatedeterminator (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);


        p_validateabsolutenumberflag (l_recimportprotocolheader,
                                      l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatelocality (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validateoid (l_recimportprotocolheader, p_usr_id, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);
        p_validateibch_q (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatevc (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatesommeept (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatesommeneoz (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatesommeabon (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatesommetxobs (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);


        p_validatesommetxcor (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatevaleurgimax (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatevaleurvt (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);


        p_validatevaleurgi (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validateibchvalue (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validateibchvalue_r (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatespearvalue (l_recimportprotocolheader, l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        p_validatestationright (l_recimportprotocolheader,
                                p_usr_id,
                                l_returnstatus);
        l_masterstatus :=
            f_preservebadstatus (l_masterstatus, l_returnstatus);

        IF l_masterstatus = pkg_constante.cst_returnstatusok
        THEN
            p_postvalidateheader (l_recimportprotocolheader,
                                  p_usr_id,
                                  l_returnstatus);

            l_masterstatus :=
                f_preservebadstatus (l_masterstatus, l_returnstatus);
        END IF;

        p_returnstatus := l_masterstatus;
    END;
END pkg_validateprotocolheader;
/

