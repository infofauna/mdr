create PACKAGE       pkg_test
AS
    /******************************************************************************
       NAME:       PKG_TEST
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        19.01.2016      burrif       1. Created this package.
    ******************************************************************************/

    FUNCTION f_getversion
        RETURN VARCHAR2;
PROCEDURE p_testspear;

    PROCEDURE p_testidentifiesystematique;

    PROCEDURE p_testfindbydesignation;

    PROCEDURE testvalidate;
END pkg_test;
/

