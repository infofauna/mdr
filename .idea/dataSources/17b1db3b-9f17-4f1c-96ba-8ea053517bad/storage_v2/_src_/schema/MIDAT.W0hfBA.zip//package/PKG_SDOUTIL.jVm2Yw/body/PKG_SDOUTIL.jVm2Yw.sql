create PACKAGE BODY       pkg_sdoutil
AS
   /******************************************************************************
      NAME:       PKG_SDOUTIL
      PURPOSE:

       AIDE: SELECT * FROM  MDSYS.CS_SRS where upper(wktext) like '%CH1903%';
      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.10.2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, octobre  2013' ;
   cst_srid_ch_lv03     CONSTANT NUMBER := 21781;              -- CH1903 /LV03



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------------------*/
   PROCEDURE p_test
   /*---------------------------------------------------------------------------*/
   IS
      l_reccoordinates   MDSYS.sdo_geometry;
      l_x                NUMBER;
      l_y                NUMBER;
      l_sst_id           NUMBER;
      l_distance         NUMBER;
   BEGIN
      l_x := 627300;
      l_y := 265350;


      SELECT sst_id, sdo_nn_distance (1)
        INTO l_sst_id, l_distance
        FROM samplestation m1
       WHERE     sdo_nn (
                    sst_coordinates,
                    f_buildsdo_geometry (l_x,
                                         l_y,
                                         m1.sst_coordinates.sdo_point.z),
                    'sdo_num_res=1,
                     unit=M',
                    1) = 'TRUE'
             AND sst_ins_id = 4;

      DBMS_OUTPUT.put_line (
         'L_SST_ID=' || l_sst_id || ' distance=' || l_distance);
   END;

   /*---------------------------------------------------------------------------*/
   FUNCTION f_setz (p_coordinates IN MDSYS.sdo_geometry, p_z IN NUMBER)
      RETURN MDSYS.sdo_geometry
   /*---------------------------------------------------------------------------*/
   IS
      l_reccoordinates   MDSYS.sdo_geometry;
   BEGIN
     IF p_coordinates.sdo_gtype = 2001
      THEN                                                      -- Déjà en 2 d
         RETURN p_coordinates;
      END IF;
      l_reccoordinates:=p_coordinates;
      l_reccoordinates.sdo_point.x := p_coordinates.sdo_point.x;
      l_reccoordinates.sdo_point.y := p_coordinates.sdo_point.y;
      l_reccoordinates.sdo_point.z := p_z;
      RETURN l_reccoordinates;
      NULL;
   END;


   /*---------------------------------------------------------------------------*/
   FUNCTION f_convert3dto2d (p_coordinates IN MDSYS.sdo_geometry)
      RETURN MDSYS.sdo_geometry
   /*---------------------------------------------------------------------------*/
   IS
      l_reccoordinates   MDSYS.sdo_geometry;
   BEGIN
      IF p_coordinates.sdo_gtype = 2001
      THEN                                                      -- Déjà en 2 d
         RETURN p_coordinates;
      END IF;

      l_reccoordinates :=
         f_buildsdo_geometry (p_coordinates.sdo_point.x,
                              p_coordinates.sdo_point.y);
      RETURN l_reccoordinates;
   END;

   /*---------------------------------------------------------------------------*/
   FUNCTION f_formatpointcoordinates (p_coordinates   IN MDSYS.sdo_geometry,
                                      p_digit         IN PLS_INTEGER,
                                      p_decimal       IN PLS_INTEGER)
      RETURN VARCHAR2
   /*---------------------------------------------------------------------------*/
   IS
      l_string   VARCHAR2 (1024);
      l_format   VARCHAR2 (100);
   BEGIN
      l_format := pkg_stringutil.f_formatdecimalformat (p_digit, p_decimal);

      IF p_coordinates.sdo_gtype = 2001
      THEN                                                      -- Point en 2D
         l_string :=
               '(x; y) ={'
            || TO_CHAR (p_coordinates.sdo_point.x, l_format)
            || '; '
            || TO_CHAR (p_coordinates.sdo_point.y, l_format)
            || '}';
      ELSIF p_coordinates.sdo_gtype = 3001
      THEN                                                      -- Point en 3D
         l_string :=
               '(x; y; z) ={'
            || TO_CHAR (p_coordinates.sdo_point.x, l_format)
            || '; '
            || TO_CHAR (p_coordinates.sdo_point.y, l_format)
            || '; '
            || TO_CHAR (p_coordinates.sdo_point.z, l_format)
            || '}';
      END IF;

      RETURN l_string;
   END;

   /*--------------------------------------------------------------------------*/
   PROCEDURE p_test2
   /*-------------------------------------------------------------------------*/
   IS
      p_x1         NUMBER := 600000;
      p_y1         NUMBER := 200000;
      p_z1         NUMBER := 300;
      p_x2         NUMBER := 600001;
      p_y2         NUMBER := 200000;
      p_z2         NUMBER := 301;
      l_point1     MDSYS.sdo_geometry;
      l_point2     MDSYS.sdo_geometry;
      l_distance   NUMBER;
   BEGIN
      l_point1 := f_buildsdo_geometry (p_x1, p_y1);
      l_point2 := f_buildsdo_geometry (p_x2, p_y2);
      l_distance := f_computedistance (l_point1, l_point2);
      DBMS_OUTPUT.put_line ('Distance= ' || l_distance);
      l_point1 := f_buildsdo_geometry (p_x1, p_y1, p_z1);
      l_point2 := f_buildsdo_geometry (p_x2, p_y2, p_z2);
      l_distance := f_computedistance (l_point1, l_point2);
      DBMS_OUTPUT.put_line ('Distance avec z= ' || l_distance);

      l_point1 := f_buildsdo_geometry (p_x1, p_y1, p_z1);
      l_point2 := f_buildsdo_geometry (p_x2, p_y2);
      l_distance := f_computedistance (l_point1, l_point2);
      DBMS_OUTPUT.put_line ('Distance avec z= ' || l_distance);
   END;

   /*--------------------------------------------------------------------------*/
   FUNCTION f_comparepoints (p_point1   IN MDSYS.sdo_geometry,
                             p_point2   IN MDSYS.sdo_geometry)
      RETURN BOOLEAN
   /*---------------------------------------------------------------------------*/
   IS
   BEGIN
    NULL; -- Not use relate
    RETURN FALSE;
   END;

   /*------------------------------------------------------------------------*/
   PROCEDURE p_test1
   /*------------------------------------------------------------------------*/
   IS
      l_point1   MDSYS.sdo_geometry;
      l_point2   MDSYS.sdo_geometry;
   BEGIN
      l_point1 := f_buildsdo_geometry (600000, 200000);
      l_point2 := f_buildsdo_geometry (600001, 200000, 600);

      IF f_comparepoints (l_point1, l_point2)
      THEN
         DBMS_OUTPUT.put_line ('Identique');
      ELSE
         DBMS_OUTPUT.put_line ('Différent');
      END IF;
   END;

   /*-------------------------------------------------------------------------*/
   PROCEDURE p_returnxycoordinate (
      p_sdo_geometry   IN     MDSYS.sdo_geometry,
      p_x                 OUT NUMBER,
      p_y                 OUT NUMBER)
   /*--------------------------------------------------------------------------*/
   IS
   BEGIN
      p_x := p_sdo_geometry.sdo_point.x;
      p_y := p_sdo_geometry.sdo_point.y;
   END;

   /*-------------------------------------------------------------------------*/
   PROCEDURE p_returnxycoordinate (
      p_sdo_geometry   IN     MDSYS.sdo_geometry,
      p_x                 OUT NUMBER,
      p_y                 OUT NUMBER,
      p_z                 OUT NUMBER)
   /*--------------------------------------------------------------------------*/
   IS
   BEGIN
      p_x := p_sdo_geometry.sdo_point.x;
      p_y := p_sdo_geometry.sdo_point.y;
      p_z := p_sdo_geometry.sdo_point.z;
   END;

   /*-------------------------------------------------------------------------*/
   FUNCTION f_getx (p_sdo_geometry IN MDSYS.sdo_geometry)
      RETURN NUMBER
   /*-------------------------------------------------------------------------*/
   IS
   BEGIN
      RETURN p_sdo_geometry.sdo_point.x;
   END;

   /*-------------------------------------------------------------------------*/
   FUNCTION f_gety (p_sdo_geometry IN MDSYS.sdo_geometry)
      RETURN NUMBER
   /*-------------------------------------------------------------------------*/
   IS
   BEGIN
      RETURN p_sdo_geometry.sdo_point.y;
   END;

   /*-------------------------------------------------------------------------*/
   FUNCTION f_getz (p_sdo_geometry IN MDSYS.sdo_geometry)
      RETURN NUMBER
   /*-------------------------------------------------------------------------*/
   IS
   BEGIN
      RETURN p_sdo_geometry.sdo_point.z;
   END;

   /*-------------------------------------------------------------------------*/
   FUNCTION f_buildsdo_geometry (p_x IN NUMBER, p_y IN NUMBER)
      RETURN MDSYS.sdo_geometry
   /*-------------------------------------------------------------------------*/
   IS
      l_sdo_geometry   MDSYS.sdo_geometry;
   BEGIN
      l_sdo_geometry :=
         mdsys.sdo_geometry (2001,                              -- Point en 2d
                             cst_srid_ch_lv03,                 -- CH1903 /LV03
                             mdsys.sdo_point_type (p_x, p_y, NULL),
                             NULL,
                             NULL);
      RETURN l_sdo_geometry;
   END;

   /*-------------------------------------------------------------------------*/
   FUNCTION f_buildsdo_geometry (p_x IN NUMBER, p_y IN NUMBER, p_z IN NUMBER)
      RETURN MDSYS.sdo_geometry
   /*-------------------------------------------------------------------------*/
   IS
      l_sdo_geometry   MDSYS.sdo_geometry;
   BEGIN
      l_sdo_geometry :=
         mdsys.sdo_geometry (3001,                              -- Point en 3d
                             cst_srid_ch_lv03,                 -- CH1903 /LV03
                             mdsys.sdo_point_type (p_x, p_y, p_z),
                             NULL,
                             NULL);
      RETURN l_sdo_geometry;
   END;

   /*------------------------------------------------------------------------*/
   FUNCTION f_convertpointto2d (p_coordinates IN MDSYS.sdo_geometry)
      RETURN MDSYS.sdo_geometry
   /*------------------------------------------------------------------------*/
   IS
      l_coordinates   MDSYS.sdo_geometry;
   BEGIN
      IF p_coordinates.sdo_gtype = 3001
      THEN
         l_coordinates :=
            mdsys.sdo_geometry (
               2001,                                            -- Point en 2d
               cst_srid_ch_lv03,                               -- CH1903 /LV03
               mdsys.sdo_point_type (p_coordinates.sdo_point.x,
                                     p_coordinates.sdo_point.y,
                                     NULL),
               NULL,
               NULL);
         RETURN l_coordinates;
      END IF;

      RETURN p_coordinates;
   END;

   /*-------------------------------------------------------------------------*/
   FUNCTION f_computedistance2d (p_coord1   IN MDSYS.sdo_geometry,
                                 p_coord2   IN MDSYS.sdo_geometry)
      RETURN NUMBER
   /*-------------------------------------------------------------------------*/

   IS
      l_distance   NUMBER;
   BEGIN
      l_distance :=
         SDO_GEOM.sdo_distance (f_convertpointto2d (p_coord1),
                                f_convertpointto2d (p_coord2),
                                0.1,        -- 0.1 metre de tolerance d'erreur
                                'unit=M');

      RETURN l_distance;
   END;


   /*-------------------------------------------------------------------------*/
   FUNCTION f_computedistance (p_coord1   IN MDSYS.sdo_geometry,
                               p_coord2   IN MDSYS.sdo_geometry)
      RETURN NUMBER
   /*-------------------------------------------------------------------------*/

   IS
      l_distance   NUMBER;
   BEGIN
      l_distance :=
         SDO_GEOM.sdo_distance (p_coord1,
                                p_coord2,
                                0.1,        -- 0.1 metre de tolerance d'erreur
                                'unit=M');

      RETURN l_distance;
   END;
END pkg_sdoutil;
/

