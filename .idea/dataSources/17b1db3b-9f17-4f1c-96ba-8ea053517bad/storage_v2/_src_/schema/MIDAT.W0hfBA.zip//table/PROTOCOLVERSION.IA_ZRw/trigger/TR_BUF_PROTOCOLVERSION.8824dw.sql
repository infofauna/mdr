create trigger TR_BUF_PROTOCOLVERSION
    before update
    on PROTOCOLVERSION
    for each row
DECLARE
BEGIN
 
   :new.PTV_moddate := SYSDATE;
   :new.PTV_moduser := USER;
END tr_buf_PROTOCOLVERSION;

/

