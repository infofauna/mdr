create trigger TR_BUF_PROTOCOLMAPPINGMASSFLD
    before update
    on PROTOCOLMAPPINGMASSFIELD
    for each row
DECLARE
BEGIN
 

   :new.PMM_moddate := SYSDATE;
   :new.PMM_moduser := USER;
END TR_BUF_PROTOCOLMAPPINGMASSFLD;

/

