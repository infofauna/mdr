create trigger TR_BIF_PROTOCOLINDICEVERSION
    before insert
    on PROTOCOLINDICEVERSION
    for each row
DECLARE
BEGIN
   IF :new.PiV_id IS NULL
   THEN
      :new.PiV_id := seq_PROTOCOLINDICEVERSION.NEXTVAL;
   END IF;

   :new.PiV_credate := SYSDATE;
   :new.PiV_creuser := USER;
END tr_bif_PROTOCOLINDICEVERSION;

/

