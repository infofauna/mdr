create PACKAGE BODY       pkg_migr_protocolmassfieldrole
AS
   /******************************************************************************
      NAME:       PKG_MIGR_PROTOCOLMASSFIELDROLE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        16.10.2017      burrif       1. Created this package.
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, octobre  2017' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_load
   /*---------------------------------------------------------------*/
   IS
      l_recrolemanager                admin_role%ROWTYPE;
      l_recprotocolmappingmassfield   protocolmappingmassfield%ROWTYPE;
      cst_ptv_id             CONSTANT protocolversion.ptv_id%TYPE := 4; -- Protocol de masse
      l_pfr_id                        protocolmassfieldrole.pfr_id%TYPE;
   BEGIN
      l_recrolemanager :=
         pkg_admin_role.f_getrecordbyname (
            pkg_admin_role.cst_admin_role_manager);
      -- Champ OIDLINK ROle adim associé uniquement au rôle ADMIN
      l_recprotocolmappingmassfield :=
         pkg_protocolmappingmassfield.f_getfromcode (
            pkg_codevalue.cst_midatfldcmt_oidlink,
            cst_ptv_id);

      pkg_protocolmassfieldrole.p_write (
         l_recrolemanager.apr_id,
         l_recprotocolmappingmassfield.pmm_id,
         l_pfr_id);
   END;
END pkg_migr_protocolmassfieldrole;
/

