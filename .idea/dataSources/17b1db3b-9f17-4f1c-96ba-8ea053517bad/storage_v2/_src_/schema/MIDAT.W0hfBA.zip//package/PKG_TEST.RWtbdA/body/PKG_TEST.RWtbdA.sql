create PACKAGE BODY       pkg_test
AS
    /******************************************************************************
       NAME:       PKG_TEST
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        19.01.2016      burrif       1. Created this package.
    ******************************************************************************/

    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.0, décembre 2017' ;

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_testspear
    /*-------------------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_recimportmassdataheader   importmassdataheader%ROWTYPE;
        l_recsampleheader           sampleheader%ROWTYPE;
        l_sph_id                    sampleheader.sph_id%TYPE:= 233;
        l_spear                     NUMBER ;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecord (l_sph_id);
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (
                l_recsampleheader.sph_iph_id);
        DBMS_OUTPUT.put_line (
               'l_recimportprotocolheader.iph_id='
            || l_recimportprotocolheader.iph_id);
        l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                l_recsampleheader.sph_imh_id);
        DBMS_OUTPUT.put_line (
               'l_recimportmassdataheader.imh_id='
            || l_recimportmassdataheader.imh_id);
        pkg_spear.p_maincompute (l_recimportprotocolheader,
                                 l_recimportmassdataheader,
                                 l_spear);
        DBMS_OUTPUT.put_line ('Spear=' || l_spear);


        NULL;
    END;


    /*-----------------------------------------------------------------*/
    PROCEDURE testvalidate
    /*------------------------------------------------------------------*/
    IS
        l_cursorerror   pkg_importprotocollog.t_cursor;
        l_errorlevel    VARCHAR2 (256);
    BEGIN
        pkg_validate.p_validateprocess_v2 (562,             --p_iph_id       ,
                                           1,                       --p_lan_id
                                           1400,             --p_usr_id      ,
                                           NULL,                    --p_pid_id
                                           l_cursorerror,
                                           l_errorlevel);
    END;



    /*-----------------------------------------------------------------*/

    PROCEDURE p_testfindbydesignation
    /*-----------------------------------------------------------------*/

    IS
        l_syv_startwith            systvalue.syv_id%TYPE; -- Identifiant du niveu le plus bas

        l_effectivecountpath       NUMBER; --  Nombre de désignation trouvé dans le thésaurus

        l_totalcountpath           NUMBER; -- Nombre de designation total à trouver aux différents niveau

        l_levelstartwith           NUMBER;   -- Niveau de départ du start WITH

        l_counthierarchymatching   NUMBER;
        l_crf_id                   NUMBER;
        l_flagprecisionmax         VARCHAR2 (1);
    BEGIN
        pkg_systdesignation.p_clearfindbydesignation;

        pkg_systdesignation.p_addfindbydesignation (
            pkg_language.cst_lan_cde_latin,
            pkg_codereference.cst_crf_species,
            'braueri');

        pkg_systdesignation.p_addfindbydesignation (
            pkg_language.cst_lan_cde_latin,
            pkg_codereference.cst_crf_genus,
            'Leuctra');

        pkg_systdesignation.p_addfindbydesignation (
            pkg_language.cst_lan_cde_latin,
            pkg_codereference.cst_crf_order,
            'Leuctridae');



        pkg_systdesignation.p_processfindbydesignation (l_syv_startwith,
                                                        l_crf_id,
                                                        l_flagprecisionmax); -- Identifiant du niveu le plus bas


        DBMS_OUTPUT.put_line ('l_syv_startwith=' || l_syv_startwith);
        DBMS_OUTPUT.put_line ('l_crf_id=' || l_crf_id);
        DBMS_OUTPUT.put_line ('l_flagprecisionmax=' || l_flagprecisionmax);

        DBMS_OUTPUT.put_line (
            pkg_systdesignation.f_returnpathdesignation (l_syv_startwith,
                                                         1,
                                                         '/'));
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_testidentifiesystematique
    /*---------------------------------------------------------------*/
    IS
        l_subspecies            importmassdatadetail.imd_subspecies%TYPE;
        l_species               importmassdatadetail.imd_species%TYPE;
        l_genus                 importmassdatadetail.imd_genus%TYPE;
        l_family                importmassdatadetail.imd_family%TYPE;
        l_highertaxon           importmassdatadetail.imd_highertaxon%TYPE;
        l_taxonibch             importmassdatadetail.imd_taxonibch%TYPE;
        l_ptv_id_ibchfrommass   protocolversion.ptv_id%TYPE;
        l_syv_startwith         systvalue.syv_id%TYPE;
        l_crf_id                codereference.crf_id%TYPE;
        l_flagprecisionmax      CHAR;
        l_returnstatus          NUMBER;
    BEGIN
        l_subspecies := NULL;
        l_species := 'braueri';
        l_genus := 'Leuctra';
        l_family := 'Leuctridae';
        l_ptv_id_ibchfrommass := 1;
        pkg_identifysystematique.p_identifiesystematique (
            l_subspecies,
            l_species,
            l_genus,
            l_family,
            l_highertaxon,
            l_taxonibch,
            l_ptv_id_ibchfrommass,
            l_syv_startwith,
            l_crf_id,
            l_flagprecisionmax,
            l_returnstatus);

        DBMS_OUTPUT.put_line ('l_syv_startwith=' || l_syv_startwith);
        DBMS_OUTPUT.put_line ('l_crf_id=' || l_crf_id);
        DBMS_OUTPUT.put_line ('l_flagprecisionmax=' || l_flagprecisionmax);

        DBMS_OUTPUT.put_line (
            pkg_systdesignation.f_returnpathdesignation (l_syv_startwith,
                                                         1,
                                                         '/'));
    END;
END pkg_test;
/

