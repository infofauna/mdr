create PACKAGE BODY       pkg_protocolmappingheader
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLMAPPINGHEADER
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbyptvandmidatitmstr (
      p_ptv_id        IN protocolmappingheader.pmh_ptv_id%TYPE,
      p_midathditem   IN codevalue.cvl_code%TYPE)
      RETURN protocolmappingheader%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_record   protocolmappingheader%ROWTYPE;
   BEGIN
      SELECT protocolmappingheader.*
        INTO l_record
        FROM protocolmappingheader
             INNER JOIN codevalue ON cvl_id = pmh_cvl_id_midathditem
             INNER JOIN codereference ON cvl_crf_id = crf_id
       WHERE     pmh_ptv_id = p_ptv_id
             AND cvl_code = p_midathditem
             AND crf_code = pkg_codereference.cst_crf_midathditem;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbyptvandmidathditem (
      p_ptv_id        IN protocolmappingheader.pmh_ptv_id%TYPE,
      p_midathditem   IN protocolmappingheader.pmh_cvl_id_midathditem%TYPE)
      RETURN protocolmappingheader%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_record   protocolmappingheader%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM protocolmappingheader
       WHERE pmh_ptv_id = p_ptv_id AND pmh_cvl_id_midathditem = p_midathditem;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbyptvandfieldnameto (
      p_ptv_id        IN protocolmappingheader.pmh_ptv_id%TYPE,
      p_fieldnameto   IN protocolmappingheader.pmh_fieldnameto%TYPE)
      RETURN protocolmappingheader%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_record   protocolmappingheader%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM protocolmappingheader
       WHERE pmh_ptv_id = p_ptv_id AND pmh_fieldnameto = p_fieldnameto;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_write (
      p_ptv_id                 IN     protocolmappingheader.pmh_ptv_id%TYPE,
      p_cvl_id_midathditem     IN     protocolmappingheader.pmh_cvl_id_midathditem%TYPE,
      p_cellrowvalue           IN     protocolmappingheader.pmh_cellrowvalue%TYPE,
      p_cellcolumnvalue        IN     protocolmappingheader.pmh_cellcolumnvalue%TYPE,
      p_fieldnameto            IN     protocolmappingheader.pmh_fieldnameto%TYPE,
      p_cvl_code_midahdtitem   IN     protocolmappingheader.pmh_cvl_code_midathditem%TYPE,
      p_cvl_id_datatype        IN     protocolmappingheader.pmh_cvl_id_datatype%TYPE,
      p_isnotnull              IN     protocolmappingheader.pmh_isnotnull%TYPE,
      p_isnotnullgroup         IN     protocolmappingheader.pmh_isnotnullgroup%TYPE,
      p_id                        OUT protocolmappingheader.pmh_id%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_protocolmappingheader.NEXTVAL;

      INSERT INTO protocolmappingheader (pmh_id,
                                         pmh_ptv_id,
                                         pmh_cvl_id_midathditem,
                                         pmh_cellrowvalue,
                                         pmh_cellcolumnvalue,
                                         pmh_fieldnameto,
                                         pmh_cvl_code_midathditem,
                                         pmh_cvl_id_datatype,
                                         pmh_isnotnull,
                                         pmh_isnotnullgroup)
           VALUES (p_id,
                   p_ptv_id,
                   p_cvl_id_midathditem,
                   p_cellrowvalue,
                   p_cellcolumnvalue,
                   p_fieldnameto,
                   p_cvl_code_midahdtitem,
                   p_cvl_id_datatype,
                   p_isnotnull,
                   p_isnotnullgroup);
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_getrecord (p_pmh_id IN protocolmappingheader.pmh_id%TYPE)
      RETURN protocolmappingheader%ROWTYPE
   /*-------------------------------------------------------------*/
   IS
      l_record   protocolmappingheader%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM protocolmappingheader
       WHERE pmh_id = p_pmh_id;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
END;
/

