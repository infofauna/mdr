create trigger TR_BUF_MKIIDENTIFYGROUPCOUNTER
    before update
    on MKIIDENTIFYGROUPCOUNTER
    for each row
DECLARE
BEGIN
   :new.mig_moddate := SYSDATE;
   :new.mig_moduser := USER;
END tr_buf_mkiidentifygroupcounter;

/

