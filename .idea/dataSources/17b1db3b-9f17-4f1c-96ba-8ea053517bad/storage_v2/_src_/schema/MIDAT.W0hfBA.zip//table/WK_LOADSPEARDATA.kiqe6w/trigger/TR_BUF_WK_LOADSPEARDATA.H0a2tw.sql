create trigger TR_BUF_WK_LOADSPEARDATA
    before update
    on WK_LOADSPEARDATA
    for each row
DECLARE
BEGIN
 
   :new.WLS_moddate := SYSDATE;
   :new.WLS_moduser := USER;
END tr_buf_WK_LOADSPEARDATA;

/

