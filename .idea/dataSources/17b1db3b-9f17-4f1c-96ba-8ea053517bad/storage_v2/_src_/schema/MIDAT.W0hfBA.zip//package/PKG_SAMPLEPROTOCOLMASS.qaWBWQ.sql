create PACKAGE       pkg_sampleprotocolmass
AS
   /******************************************************************************
      NAME:       pkg_SAMPLEPROTOCOLMASS
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecord (p_id IN sampleprotocolmass.smx_id%TYPE)
      RETURN sampleprotocolmass%ROWTYPE;

   PROCEDURE p_deleteby_sph_id (
      p_sph_id   IN sampleprotocolmass.smx_sph_id%TYPE);

   PROCEDURE p_write (
      p_syy_id              IN     sampleprotocolmass.smx_syy_id%TYPE,
      p_sph_id              IN     sampleprotocolmass.smx_sph_id%TYPE,
      p_cvl_id_zoostadium   IN     sampleprotocolmass.smx_cvl_id_zoostadium%TYPE,
      p_highertaxon         IN     sampleprotocolmass.smx_highertaxon%TYPE,
      p_family              IN     sampleprotocolmass.smx_family%TYPE,
      p_genus               IN     sampleprotocolmass.smx_genus%TYPE,
      p_species             IN     sampleprotocolmass.smx_species%TYPE,
      p_subspecies          IN     sampleprotocolmass.smx_subspecies%TYPE,
      p_freq1               IN     sampleprotocolmass.smx_freq1%TYPE,
      p_freq2               IN     sampleprotocolmass.smx_freq2%TYPE,
      p_freqlum             IN     sampleprotocolmass.smx_freqlum%TYPE,
      p_stadium             IN     sampleprotocolmass.smx_stadium%TYPE,
      p_comment             IN     sampleprotocolmass.smx_comment%TYPE,
      p_taxonibch           IN     sampleprotocolmass.smx_taxonibch%TYPE,
      p_usr_id_create       IN     sampleprotocolmass.smx_usr_id_create%TYPE,
      p_id                     OUT sampleprotocolmass.smx_id%TYPE);

   PROCEDURE p_write (
      p_syy_id              IN     sampleprotocolmass.smx_syy_id%TYPE,
      p_sph_id              IN     sampleprotocolmass.smx_sph_id%TYPE,
      p_cvl_id_zoostadium   IN     sampleprotocolmass.smx_cvl_id_zoostadium%TYPE,
      p_highertaxon         IN     sampleprotocolmass.smx_highertaxon%TYPE,
      p_family              IN     sampleprotocolmass.smx_family%TYPE,
      p_genus               IN     sampleprotocolmass.smx_genus%TYPE,
      p_species             IN     sampleprotocolmass.smx_species%TYPE,
      p_subspecies          IN     sampleprotocolmass.smx_subspecies%TYPE,
      p_freq1               IN     sampleprotocolmass.smx_freq1%TYPE,
      p_freq2               IN     sampleprotocolmass.smx_freq2%TYPE,
      p_freqlum             IN     sampleprotocolmass.smx_freqlum%TYPE,
      p_stadium             IN     sampleprotocolmass.smx_stadium%TYPE,
      p_comment             IN     sampleprotocolmass.smx_comment%TYPE,
      p_taxonibch           IN     sampleprotocolmass.smx_taxonibch%TYPE,
      p_usr_id_create       IN     sampleprotocolmass.smx_usr_id_create%TYPE,
      p_spl_id              IN     sampleprotocolmass.smx_spl_id%TYPE,
      p_id                     OUT sampleprotocolmass.smx_id%TYPE);

   PROCEDURE p_write (
      p_syy_id              IN     sampleprotocolmass.smx_syy_id%TYPE,
      p_sph_id              IN     sampleprotocolmass.smx_sph_id%TYPE,
      p_cvl_id_zoostadium   IN     sampleprotocolmass.smx_cvl_id_zoostadium%TYPE,
      p_highertaxon         IN     sampleprotocolmass.smx_highertaxon%TYPE,
      p_family              IN     sampleprotocolmass.smx_family%TYPE,
      p_genus               IN     sampleprotocolmass.smx_genus%TYPE,
      p_species             IN     sampleprotocolmass.smx_species%TYPE,
      p_subspecies          IN     sampleprotocolmass.smx_subspecies%TYPE,
      p_freq1               IN     sampleprotocolmass.smx_freq1%TYPE,
      p_freq2               IN     sampleprotocolmass.smx_freq2%TYPE,
      p_freqlum             IN     sampleprotocolmass.smx_freqlum%TYPE,
      p_stadium             IN     sampleprotocolmass.smx_stadium%TYPE,
      p_comment             IN     sampleprotocolmass.smx_comment%TYPE,
      p_taxonibch           IN     sampleprotocolmass.smx_taxonibch%TYPE,
      p_usr_id_create       IN     sampleprotocolmass.smx_usr_id_create%TYPE,
      p_spl_id              IN     sampleprotocolmass.smx_spl_id%TYPE,
      p_imd_id              IN     sampleprotocolmass.smx_imd_id%TYPE,
      p_id                     OUT sampleprotocolmass.smx_id%TYPE);

   PROCEDURE p_write (
      p_syy_id              IN     sampleprotocolmass.smx_syy_id%TYPE,
      p_sph_id              IN     sampleprotocolmass.smx_sph_id%TYPE,
      p_cvl_id_zoostadium   IN     sampleprotocolmass.smx_cvl_id_zoostadium%TYPE,
      p_highertaxon         IN     sampleprotocolmass.smx_highertaxon%TYPE,
      p_family              IN     sampleprotocolmass.smx_family%TYPE,
      p_genus               IN     sampleprotocolmass.smx_genus%TYPE,
      p_species             IN     sampleprotocolmass.smx_species%TYPE,
      p_subspecies          IN     sampleprotocolmass.smx_subspecies%TYPE,
      p_freq1               IN     sampleprotocolmass.smx_freq1%TYPE,
      p_freq2               IN     sampleprotocolmass.smx_freq2%TYPE,
      p_freqlum             IN     sampleprotocolmass.smx_freqlum%TYPE,
      p_stadium             IN     sampleprotocolmass.smx_stadium%TYPE,
      p_comment             IN     sampleprotocolmass.smx_comment%TYPE,
      p_taxonibch           IN     sampleprotocolmass.smx_taxonibch%TYPE,
      p_usr_id_create       IN     sampleprotocolmass.smx_usr_id_create%TYPE,
      p_spl_id              IN     sampleprotocolmass.smx_spl_id%TYPE,
      p_imd_id              IN     sampleprotocolmass.smx_imd_id%TYPE,
      p_sampleno            IN     sampleprotocolmass.smx_sampleno%TYPE,
      p_id                     OUT sampleprotocolmass.smx_id%TYPE);
END pkg_sampleprotocolmass;
/

