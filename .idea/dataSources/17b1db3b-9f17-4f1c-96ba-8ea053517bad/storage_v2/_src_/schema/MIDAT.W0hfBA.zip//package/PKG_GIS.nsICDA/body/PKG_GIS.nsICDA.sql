create PACKAGE BODY       pkg_gis
AS
   /******************************************************************************
      NAME:       PKG_GIS
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2015      burrif       1. Created this package.
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, février 2015' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_returncanton (p_coordinates IN SDO_GEOMETRY)
      RETURN ch_canton.code%TYPE
   /*--------------------------------------------------------------*/
   IS
      l_ch_canton   ch_canton%ROWTYPE;
   BEGIN
      pkg_ch_canton.p_findcontaincanton (p_coordinates, l_ch_canton);
      RETURN l_ch_canton.code;
   END;


   /*-------------------------------------------------------------------------------------------------------------------------------------------------------*/
   PROCEDURE p_returnelevation (
      p_x                 IN     NUMBER,
      p_y                 IN     NUMBER,
      p_elevation            OUT NUMBER,
      p_cvl_code_origin      OUT codevalue.cvl_code%TYPE,
      p_returnstatus         OUT NUMBER)
   /*------------------------------------------------------------------------------------------------------------------------------------------------------*/
   IS
      l_returnstatus   NUMBER;
      l_distance       NUMBER;
   BEGIN
      -- On essaye sur swisstopo
      pkg_swisstopo.p_returnelevation (p_x,
                                       p_y,
                                       p_elevation,
                                       l_returnstatus);

      IF l_returnstatus = pkg_constante.cst_returnstatusok
      THEN
         p_cvl_code_origin := pkg_codevalue.cst_elevorigin_swisstopo;
         p_returnstatus := pkg_constante.cst_returnstatusok;
         RETURN;
      END IF;


      -- On essaye localement
      pkg_ch_mnt25.p_returnelevation (p_x,
                                      p_y,
                                      p_elevation,
                                      l_distance);

      IF NOT p_elevation IS NULL
      THEN
         p_cvl_code_origin := pkg_codevalue.cst_elevorigin_localtopo;
         p_returnstatus := pkg_constante.cst_returnstatusok;
      ELSE
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         p_cvl_code_origin := NULL;
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_checkorigineelevation (
      p_iph_id            IN importmassdataheader.imh_iph_id%TYPE,
      p_cvl_code_origin   IN codevalue.cvl_code%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      IF p_cvl_code_origin IS NULL
      THEN
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            NULL,
            pkg_exception.cst_unabletopoelevationquery,
            NULL);
         RETURN;
      END IF;

      IF p_cvl_code_origin = pkg_codevalue.cst_elevorigin_swisstopo
      THEN
         RETURN;                                                      --Normal
      END IF;

      IF p_cvl_code_origin = pkg_codevalue.cst_elevorigin_localtopo
      THEN
         -- Le service de détermination des altitudes de Swisstopo n'est pas accessible. Le service local a été utilisé
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            NULL,
            pkg_exception.cst_elevservicetopounreachable,
            NULL);
      END IF;
   END;

   /*-------------------------------------------------------------------------------------------------------------------------------------------------------*/
   PROCEDURE p_returngewiss (
      p_x                          IN     NUMBER,
      p_y                          IN     NUMBER,
      p_distancetolerance          IN     NUMBER,
      p_othernotindeltatolerance   IN     NUMBER, -- Les autres ne doivent pas être dans un rayon de p_distancetolerance + p_othernotindeltatolerance
      p_ch_gwn25                      OUT ch_gwn25%ROWTYPE, -- Record le plus proche
      p_distance                      OUT NUMBER, -- Distance du record le plus proche au poin donnée
      p_returnstatus                  OUT NUMBER)
   /*-------------------------------------------------------------------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      pkg_ch_gwn25.p_returngewiss (p_x,
                                   p_y,
                                   p_distancetolerance,
                                   p_othernotindeltatolerance,
                                   p_ch_gwn25,
                                   p_distance,
                                   p_returnstatus);
   END;

   /*-------------------------------------------------------------------------------------------------------------------------------------------------------*/
   PROCEDURE p_returngewiss (p_x              IN     NUMBER,
                             p_y              IN     NUMBER,
                             p_ch_gwn25          OUT ch_gwn25%ROWTYPE, -- Record le plus proche
                             p_distance          OUT NUMBER, -- Distance du record le plus proche au poin donnée
                             p_returnstatus      OUT NUMBER)
   /*-------------------------------------------------------------------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      pkg_ch_gwn25.p_returngewiss (p_x,
                                   p_y,
                                   cst_distancetolgewiss,
                                   cst_othernotindeltatolerance,
                                   p_ch_gwn25,
                                   p_distance,
                                   p_returnstatus);
   END;

   /*------------------------------------------------------------------------------------------*/
   FUNCTION f_returngewissnrbyname (p_name IN ch_gwn25.name%TYPE)
      RETURN ch_gwn25.gewissnr%TYPE
   /*------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      RETURN pkg_ch_gwn25.f_returngewissnrbyname (p_name);
   END;

   /*------------------------------------------------------------------------------------------*/
   FUNCTION f_returnname (p_gewissnr IN ch_gwn25.gewissnr%TYPE)
      RETURN ch_gwn25.name%TYPE
   /*------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      RETURN pkg_ch_gwn25.f_returnname (p_gewissnr);
   END;
END pkg_gis;
/

