create PACKAGE BODY       pkg_migr_biologicalstate
AS
   /******************************************************************************
      NAME:       pkg_migr_biologicalstate
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_delete_ibchrange
   /*-----------------------------------------------------------------*/
   IS
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_ibch);

      DELETE FROM biologicalstate
            WHERE bls_cvl_id_midatindice = l_reccodevalue.cvl_id;


      NULL;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_delete_mkmrange
   /*-----------------------------------------------------------------*/
   IS
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_makroindex);

      DELETE FROM biologicalstate
            WHERE bls_cvl_id_midatindice = l_reccodevalue.cvl_id;


      NULL;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_delete_spearrange
   /*-----------------------------------------------------------------*/
   IS
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_spear);

      DELETE FROM biologicalstate
            WHERE bls_cvl_id_midatindice = l_reccodevalue.cvl_id;


      NULL;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_build_ibchrange
   /*-----------------------------------------------------------------*/
   IS
      l_reccodevalue_midatindiceibch   codevalue%ROWTYPE;
      l_reccodevalue_biolstatetxt      codevalue%ROWTYPE;
      l_reccodevalue_colorindex        codevalue%ROWTYPE;
      l_reccodevalue_colorindextext    codevalue%ROWTYPE;
      l_id                             biologicalstate.bls_id%TYPE;
   BEGIN
      p_delete_ibchrange;

      l_reccodevalue_midatindiceibch :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_ibch);

      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_verygood);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_blue);

      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_white);


      pkg_biologicalstate.p_write (1,
                                   l_reccodevalue_midatindiceibch.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   17,
                                   20,
                                   '17   ≥  IBCH ≤ 20 ',
                                   l_id);

      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_good);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_green);
      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_black);


      pkg_biologicalstate.p_write (2,
                                   l_reccodevalue_midatindiceibch.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   13,
                                   16,
                                   '13  ≥  IBCH ≤ 16 ',
                                   l_id);


      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_middle);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_yellow);
      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_black);

      pkg_biologicalstate.p_write (3,
                                   l_reccodevalue_midatindiceibch.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   9,
                                   12,
                                   '9  ≥  IBCH  ≤ 12',
                                   l_id);

      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_poor);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_orange);

      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_black);


      pkg_biologicalstate.p_write (4,
                                   l_reccodevalue_midatindiceibch.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   5,
                                   8,
                                   '5  ≥  IBCH  ≤ 8 ',
                                   l_id);
      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_bad);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_red);

      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_white);


      pkg_biologicalstate.p_write (5,
                                   l_reccodevalue_midatindiceibch.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   1,
                                   4,
                                   '1  ≥  IBCH  ≤ 4 ',
                                   l_id);

      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_undefined);

      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_gray);


      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_black);


      pkg_biologicalstate.p_write (6,
                                   l_reccodevalue_midatindiceibch.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   0,
                                   0,
                                   '  IBCH  = 0 ',
                                   l_id);
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_build_spearrange
   /*-----------------------------------------------------------------*/
   IS
      l_reccodevalue_midatindicespea   codevalue%ROWTYPE;
      l_reccodevalue_biolstatetxt      codevalue%ROWTYPE;
      l_reccodevalue_colorindex        codevalue%ROWTYPE;
      l_reccodevalue_colorindextext    codevalue%ROWTYPE;
      l_id                             biologicalstate.bls_id%TYPE;
   BEGIN
      -- Spear
      p_delete_spearrange;

      l_reccodevalue_midatindicespea :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_spear);


      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_verygood);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_blue);

      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_white);


      pkg_biologicalstate.p_write (1,
                                   l_reccodevalue_midatindicespea.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   44,
                                   9999,
                                   'SPEAR  ≥ 44 %',
                                   l_id);

      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_good);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_green);
      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_black);
      pkg_biologicalstate.p_write (2,
                                   l_reccodevalue_midatindicespea.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   33,
                                   43.9,
                                   '33%  ≥ SPEAR < 44 %',
                                   l_id);


      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_middle);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_yellow);

      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_black);
      pkg_biologicalstate.p_write (3,
                                   l_reccodevalue_midatindicespea.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   22,
                                   32.9,
                                   '22 %  ≥ SPEAR < 33 %',
                                   l_id);

      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_poor);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_orange);

      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_black);
      pkg_biologicalstate.p_write (4,
                                   l_reccodevalue_midatindicespea.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   11,
                                   21.9,
                                   '11 %  ≥ 22 %',
                                   l_id);

      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_bad);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_red);

      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_white);
      pkg_biologicalstate.p_write (5,
                                   l_reccodevalue_midatindicespea.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   0,
                                   10.9,
                                   'SPEAR < 11%',
                                   l_id);



      NULL;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_build_makroindexrange
   /*-----------------------------------------------------------------*/
   IS
      l_reccodevalue_midatindicemkm   codevalue%ROWTYPE;
      l_reccodevalue_biolstatetxt     codevalue%ROWTYPE;
      l_reccodevalue_colorindex       codevalue%ROWTYPE;
      l_reccodevalue_colorindextext   codevalue%ROWTYPE;
      l_id                            biologicalstate.bls_id%TYPE;
   /* 23 Taxonomische Zusammensetzung des Makrozoobenthos.pdf Page 7*/
   BEGIN
      p_delete_mkmrange;
      l_reccodevalue_midatindicemkm :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_makroindex);

      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_verygood);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_blue);

      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_white);

      pkg_biologicalstate.p_write (1,
                                   l_reccodevalue_midatindicemkm.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   1,
                                   2,
                                   '1 ≥  MAKROINDEX ≤ 2',
                                   l_id);

      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_good);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_green);

      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_black);


      pkg_biologicalstate.p_write (2,
                                   l_reccodevalue_midatindicemkm.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   3,
                                   3,
                                   'MAKROINDEX = 3',
                                   l_id);


      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_middle);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_yellow);
      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_black);

      pkg_biologicalstate.p_write (3,
                                   l_reccodevalue_midatindicemkm.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   4,
                                   4,
                                   'MAKROINDEX = 4 ',
                                   l_id);

      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_poor);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_orange);

      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_black);

      pkg_biologicalstate.p_write (4,
                                   l_reccodevalue_midatindicemkm.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   5,
                                   6,
                                   '5 ≥  MAKROINDEX ≤ 6',
                                   l_id);
      l_reccodevalue_biolstatetxt :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_biolstatetxt,
            pkg_codevalue.cst_biolstatetxt_bad);
      l_reccodevalue_colorindex :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_red);

      l_reccodevalue_colorindextext :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_colorindex,
            pkg_codevalue.cst_colorindex_white);
      pkg_biologicalstate.p_write (5,
                                   l_reccodevalue_midatindicemkm.cvl_id,
                                   l_reccodevalue_biolstatetxt.cvl_id,
                                   l_reccodevalue_colorindex.cvl_id,
                                   l_reccodevalue_colorindextext.cvl_id,
                                   7,
                                   8,
                                   '7 ≥  MAKROINDEX ≤ 8',
                                   l_id);



      NULL;
   END;

   /*----------------------------------------------------------------------------*/
   PROCEDURE p_buildall
   /*----------------------------------------------------------------------------*/
   IS
   BEGIN
      p_delete_spearrange;
      p_delete_mkmrange;
      p_delete_ibchrange;
      pkg_migr_utility.p_recreatesequence ('BIOLOGICALSTATE',
                                           'SEQ_BIOLOGICALSTATE',
                                           'BLS_ID');
      p_build_makroindexrange;
      p_build_ibchrange;
      p_build_spearrange;
   END;
END pkg_migr_biologicalstate;
/

