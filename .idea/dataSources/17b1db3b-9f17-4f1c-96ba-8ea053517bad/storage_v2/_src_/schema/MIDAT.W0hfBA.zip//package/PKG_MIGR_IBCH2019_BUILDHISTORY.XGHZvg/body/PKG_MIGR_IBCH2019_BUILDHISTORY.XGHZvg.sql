create PACKAGE BODY       pkg_migr_ibch2019_buildhistory
AS
    /******************************************************************************
       NAME:       pkg_migr_ibch2019_buildhistory
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getsampleheaderfromimh_id (
        p_imh_id   IN importmassdataheader.imh_id%TYPE)
        RETURN sampleheader%ROWTYPE
    /*--------------------------------------------------------------*/
    IS
        l_recsampleheader   sampleheader%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recsampleheader
          FROM sampleheader
         WHERE sph_imh_id = p_imh_id;

        RETURN l_recsampleheader;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_computeandsavepreviousindice (
        p_sampleheader   IN sampleheader%ROWTYPE)
    /*---------------------------------------------------------------*/
    IS
        l_ibchindice              NUMBER;
        l_ibchvalue               indicehistory.ihy_indexvalueibch%TYPE;
        l_ibchgi                  indicehistory.ihy_gi_final%TYPE;
        l_count_plecoptera        indicehistory.ihy_plecopteracounter%TYPE;
        l_count_trichoptera       indicehistory.ihy_tricopteracounter%TYPE;
        l_count_ephemeroptera     indicehistory.ihy_ephemeropteracounter%TYPE;
        l_taxon_indicateur        indicehistory.ihy_taxonindicateur%TYPE;
        l_ibchvt                  indicehistory.ihy_sumfamily%TYPE;
        l_ihy_id                  indicehistory.ihy_id%TYPE;
        l_spearindice             indicehistory.ihy_spearvalue%TYPE;
        l_recindiceversionibch    indiceversion%ROWTYPE;
        l_recindiceversionspear   indiceversion%ROWTYPE;
        l_recsampleheader         sampleheader%ROWTYPE;
        l_sum_familly             indicehistory.ihy_sumfamily%TYPE;
        l_sequence                NUMBER := -1;
    BEGIN
        l_sum_familly :=
            pkg_ibchutil.f_getibchsomme_vt (p_sampleheader.sph_id);

        l_taxon_indicateur :=
            pkg_ibchutil.f_gettaxonindicateur (p_sampleheader.sph_id);

        l_ibchgi := pkg_ibchutil.f_getibchgi (p_sampleheader.sph_id);

        l_ibchvt := pkg_ibchutil.f_getibchvt (p_sampleheader.sph_id);

        l_ibchvalue := pkg_ibchutil.f_getibch (p_sampleheader.sph_id);

        l_count_ephemeroptera :=
            pkg_ibchutil.f_getsumbytaxonibch (p_sampleheader.sph_id,
                                              'EPHEMEROPTERA');

        l_count_plecoptera :=
            pkg_ibchutil.f_getsumbytaxonibch (p_sampleheader.sph_id,
                                              'PLECOPTERA');

        l_count_trichoptera :=
            pkg_ibchutil.f_getsumbytaxonibch (p_sampleheader.sph_id,
                                              'TRICHOPTERA');



        pkg_indicehistory.p_append (p_sampleheader.sph_id,
                                    l_recindiceversionibch.ivr_id,
                                    l_recindiceversionspear.ivr_id,
                                    l_sequence,
                                    l_taxon_indicateur,
                                    NULL,                 -- p_ibch_ibchrobust
                                    l_ibchvalue,
                                    NULL,                  -- p_ibch_classevar
                                    NULL,             -- p_ibch_classevar_corr
                                    NULL,            -- p_ibch_classevarrobust
                                    NULL,       -- p_ibch_classevarrobust_corr
                                    NULL,            -- p_ibch_classevar_final
                                    NULL,      -- p_ibch_classevarrobust_final
                                    l_ibchgi,                     -- p_ibch_gi
                                    NULL,                -- p_ibch_gimaxrobust
                                    NULL,                   -- p_ibch_gi_final
                                    NULL,             -- p_ibch_girobust_final
                                    l_sum_familly,            -- p_ibch_sumfam
                                    NULL,            -- p_ibch_sumfamcorrected
                                    NULL,               -- p_ibch_sumfamrobust
                                    NULL,      -- p_ibch_sumfamrobustcorrected
                                    l_count_ephemeroptera, --p_ibch_ephemeropteracounter
                                    l_count_plecoptera, --p_ibch_plecopteracounter
                                    l_count_trichoptera, --p_ibch_tricopteracounter
                                    p_sampleheader.sph_spearindexvalue, --p_spearvalue
                                    l_ihy_id);
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_routecompute (p_sph_id IN sampleheader.sph_id%TYPE)
    /*---------------------------------------------------------------*/
    IS
        l_recsampleheader           sampleheader%ROWTYPE;
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_recimportmassdataheader   importmassdataheader%ROWTYPE;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (
                l_recsampleheader.sph_iph_id);

        IF NOT l_recsampleheader.sph_imh_id IS NULL
        THEN
            l_recimportmassdataheader :=
                pkg_importmassdataheader.f_getrecord (
                    l_recsampleheader.sph_imh_id);
            DBMS_OUTPUT.put_line ('SPH_ID=' || p_sph_id || ' Mass data');
        ELSE
            DBMS_OUTPUT.put_line ('SPH_ID=' || p_sph_id || ' LAbo data');
        END IF;

        p_computeandsavepreviousindice (l_recsampleheader);
    END;

    /*--------------------------------------------------------------------------*/
    PROCEDURE p_main
    /*--------------------------------------------------------------------------*/
    IS
        CURSOR l_sampleheader IS SELECT * FROM sampleheader;

        l_recsampleheader   sampleheader%ROWTYPE;
        l_sql               VARCHAR2 (1024);
    BEGIN
        /*
            l_sql := 'DELETE FROM INDICEHISTORY';

            EXECUTE IMMEDIATE l_sql;

            pkg_migr_ibch2019_util.p_recreatesequence ('INDICEHISTORY',
                                                       'SEQ_INDICEHISTORY',
                                                       'IHY_ID');
    */
        OPEN l_sampleheader;

        LOOP
            FETCH l_sampleheader INTO l_recsampleheader;

            EXIT WHEN l_sampleheader%NOTFOUND;
            p_routecompute (l_recsampleheader.sph_id);
        END LOOP;

        CLOSE l_sampleheader;

        NULL;
    END;
END;
/

