create PACKAGE BODY       pkg_samplestation
AS
    /******************************************************************************
       NAME:       PKG_SAMPLESTATION
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       25.07.2013  F.Burri           1. Created this package body.
       2.0         11.07.2017     burrif       2. Fonctionnalité version 2
    ******************************************************************************/



    /*
    Pour utiliser la table sample station il faut:
  1)  IINSERT INTO user_sdo_geom_metadata
       VALUES ('SAMPLESTATION',
               'SST_COORDINATES',
               mdsys.sdo_dim_array (mdsys.sdo_dim_element ('X',
                                                           480000,
                                                           837000,
                                                           1),
                                    mdsys.sdo_dim_element ('Y',
                                                           75000,
                                                           300000,
                                                           1),

               21781);

    2) CREATE INDEX idx_samplestation
     ON SAMPLESTATION(SST_COORDINATES)
     INDEXTYPE IS MDSYS.SPATIAL_INDEX
     PARAMETERS('layer_gtype=point,TABLESPACE=MIDAT_INDEX');
     */



    gbl_debugflag   BOOLEAN;

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_returncounterreference (p_sst_id IN samplestation.sst_id%TYPE)
        RETURN NUMBER
    /*--------------------------------------------------------------*/
    IS
        l_counter   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_counter
          FROM samplestation
         WHERE sst_sst_id = p_sst_id;

        RETURN l_counter;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_buildswisscoord (p_recsamplestation IN samplestation%ROWTYPE)
        RETURN VARCHAR2
    /*---------------------------------------------------------------*/
    IS
        l_swisscoord   VARCHAR2 (256);
    BEGIN
        l_swisscoord :=
               p_recsamplestation.sst_coordinates.sdo_point.x
            || '; '
            || p_recsamplestation.sst_coordinates.sdo_point.y
            || '; '
            || p_recsamplestation.sst_coordinates.sdo_point.z;
        RETURN l_swisscoord;
    END;



    /*--------------------------------------------------------------*/
    PROCEDURE p_purge
    /*--------------------------------------------------------------*/
    IS
    /* PErmet de supprimer les station non référencé */

    BEGIN
        DELETE FROM samplestationitem
              WHERE ssi_id IN
                        (SELECT ssi_id
                           FROM samplestationitem
                          WHERE ssi_sst_id IN
                                    (SELECT sst_id
                                       FROM samplestation
                                      WHERE sst_id NOT IN
                                                (SELECT sph_sst_id
                                                   FROM sampleheader)));

        DELETE FROM samplestation
              WHERE sst_id IN
                        (SELECT sst_id
                           FROM samplestation
                          WHERE sst_id NOT IN
                                    (SELECT sph_sst_id FROM sampleheader));
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_clear_sst_sst_id (p_sst_id IN samplestation.sst_id%TYPE)
    /*-------------------------------------------------------------*/
    IS
    /* Si la station est référencée on défini à NULL le lien des stations qui la référencie
    */
    BEGIN
        UPDATE samplestation
           SET sst_sst_id = NULL
         WHERE sst_sst_id = p_sst_id;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_deleteifnomoreused (p_sph_id   IN sampleheader.sph_id%TYPE,
                                    p_sst_id   IN samplestation.sst_id%TYPE)
    /*--------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        l_count :=
            pkg_sampleheader.f_countother_sph_id_and_sst_id (p_sph_id,
                                                             p_sst_id);

        IF l_count > 0
        THEN
            RETURN;
        END IF;

        pkg_samplestationitem.p_deletebysstid (p_sst_id);
        -- SI LA STATION EST LIE ON DOIT LA DELIER
        p_clear_sst_sst_id (p_sst_id);
        -- La station peut être définie dans IMPORTMASSDATAHEADER dans la colonne IMH_SST_ID.
        pkg_importmassdataheader.p_deleteby_sst_id (p_sst_id);
        pkg_importprotocolheader.p_clear_iph_sst_id_existing (p_sst_id);

        DELETE FROM samplestation
              WHERE sst_id = p_sst_id;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_deleteconditional (p_sst_id IN samplestation.sst_id%TYPE)
    /*--------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        l_count := pkg_sampleheader.f_getcountbysstid (p_sst_id);

        IF l_count > 0
        THEN
            RETURN;
        END IF;

        pkg_samplestationitem.p_deletebysstid (p_sst_id);
        pkg_importmassdataheader.p_deleteby_sst_id (p_sst_id);
        pkg_importprotocolheader.p_clear_iph_sst_id_existing (p_sst_id);
        p_clear_sst_sst_id (p_sst_id);

        DELETE FROM samplestation
              WHERE sst_id = p_sst_id;
    END;


    /*--------------------------------------------------------------*/
    PROCEDURE p_getnearsst_id (
        p_coordinates   IN     SDO_GEOMETRY,
        p_ins_id        IN     samplestation.sst_ins_id%TYPE,
        p_sst_id           OUT samplestation.sst_id%TYPE,
        p_distance         OUT NUMBER)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        SELECT sst_id, sdo_nn_distance (1)
          INTO p_sst_id, p_distance
          FROM samplestation
         WHERE     sdo_nn (sst_coordinates,
                           p_coordinates,
                           'sdo_num_res=1,
                     unit=M',
                           1) = 'TRUE'
               AND sst_ins_id = p_ins_id;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            p_sst_id := NULL;
            p_distance := NULL;
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_getrecord (p_sst_id IN samplestation.sst_id%TYPE)
        RETURN samplestation%ROWTYPE
    /*--------------------------------------------------------------*/
    IS
        l_record   samplestation%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_record
          FROM samplestation
         WHERE sst_id = p_sst_id;

        RETURN l_record;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_returnstationinfo (
        p_sst_id         IN     samplestation.sst_id%TYPE,
        p_lan_id         IN     language.lan_id%TYPE,
        p_oid               OUT samplestation.sst_oid%TYPE,
        p_watercourse       OUT VARCHAR2,
        p_locality          OUT VARCHAR2,
        p_returnstatus      OUT NUMBER)
    /*---------------------------------------------------------------*/
    IS
        l_recsamplestation       samplestation%ROWTYPE;
        l_recsamplestationitem   samplestationitem%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        l_recsamplestation := f_getrecord (p_sst_id);

        IF l_recsamplestation.sst_id IS NULL
        THEN
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
        END IF;

        l_recsamplestationitem :=
            pkg_samplestationitem.f_getatleastonerecord (
                p_sst_id,
                p_lan_id,
                pkg_codevalue.cst_midathditmty_watercourse);
        p_watercourse := l_recsamplestationitem.ssi_item;
        l_recsamplestationitem :=
            pkg_samplestationitem.f_getatleastonerecord (
                p_sst_id,
                p_lan_id,
                pkg_codevalue.cst_midathditmty_locality);
        p_locality := l_recsamplestationitem.ssi_item;
        p_oid := l_recsamplestation.sst_oid;



        NULL;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_check (p_command   IN     VARCHAR2,
                       p_oldrec    IN     samplestation%ROWTYPE,
                       p_newrec    IN OUT samplestation%ROWTYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        NULL;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_tr_bif_samplestation (p_newrec IN OUT samplestation%ROWTYPE)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        p_newrec.sst_credate := SYSDATE;
        p_newrec.sst_creuser := USER;

        IF p_newrec.sst_id IS NULL
        THEN
            p_newrec.sst_id := seq_samplestation.NEXTVAL;
        END IF;

        p_check (pkg_constante.cst_dml_command_insert, NULL, p_newrec);
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_tr_buf_samplestation (
        p_oldrec   IN     samplestation%ROWTYPE,
        p_newrec   IN OUT samplestation%ROWTYPE)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        p_newrec.sst_moddate := SYSDATE;
        p_newrec.sst_moduser := USER;
        p_check (pkg_constante.cst_dml_command_update, p_oldrec, p_newrec);
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_getrecordbyoid (p_oid IN samplestation.sst_oid%TYPE)
        RETURN samplestation%ROWTYPE
    /*---------------------------------------------------------------*/
    IS
        l_record   samplestation%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_record
          FROM samplestation
         WHERE sst_oid = p_oid;

        RETURN l_record;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_getrecordbyinsidandoid (
        p_ins_id   IN sampleheader.sph_ins_id_principal%TYPE,
        p_oid      IN samplestation.sst_oid%TYPE)
        RETURN samplestation%ROWTYPE
    /*---------------------------------------------------------------*/
    IS
        l_record   samplestation%ROWTYPE;
    BEGIN
        SELECT samplestation.*
          INTO l_record
          FROM samplestation
         WHERE sst_oid = p_oid AND sst_ins_id = p_ins_id;

        RETURN l_record;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;


    /*----------------------------------------------------------------------------------*/
    FUNCTION f_calculateoid (p_ins_id IN NUMBER)
        RETURN NUMBER
    /*---------------------------------------------------------------------------------*/
    IS
        l_sequence   VARCHAR2 (30);
        l_number     NUMBER;
    BEGIN
        l_sequence := 'SEQ_FOROIDINSID' || TRIM (TO_CHAR (p_ins_id));
        pkg_stringutil.p_createsequence (l_sequence, 1, FALSE);
        l_number := pkg_stringutil.f_returnsequencevalue (l_sequence);
        RETURN l_number;
    END;

    /*---------------------------------------------------------------------------------*/
    PROCEDURE p_update_sst_sst_id (
        p_sst_id       IN samplestation.sst_id%TYPE,
        p_sst_sst_id   IN samplestation.sst_sst_id%TYPE,
        p_usr_id       IN samplestation.sst_usr_id_create%TYPE)
    /*----------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE samplestation
           SET sst_sst_id = p_sst_sst_id,
               sst_usr_id_modify = p_usr_id,
               sst_usr_modify_date = SYSDATE
         WHERE sst_id = p_sst_id;
    END;



    /*----------------------------------------------------------------------------------*/
    PROCEDURE p_write (
        p_lan_id                   IN     language.lan_id%TYPE,
        p_oid                      IN     samplestation.sst_oid%TYPE,
        p_oid_calculated           IN     samplestation.sst_oid_calculated%TYPE,
        p_oid_provided             IN     samplestation.sst_oid_provided%TYPE,
        p_ins_id                   IN     samplestation.sst_ins_id%TYPE,
        p_coordinate_x             IN     NUMBER,
        p_coordinate_y             IN     NUMBER,
        p_coordinate_z             IN     NUMBER,
        p_cvl_id_elevationorigin   IN     samplestation.sst_cvl_id_elevationorigin%TYPE,
        p_elevationprecision       IN     samplestation.sst_elevationprecision%TYPE,
        p_title                    IN     samplestation.sst_title%TYPE,
        p_gewissnr                 IN     samplestation.sst_gewissnr%TYPE,
        p_usr_id                   IN     samplestation.sst_usr_id_create%TYPE,
        p_cvl_id_canton            IN     samplestation.sst_cvl_id_canton%TYPE,
        p_id                          OUT samplestation.sst_id%TYPE)
    /*---------------------------------------------------------------------------------*/
    IS
        l_sdo_geometry   MDSYS.sdo_geometry;
        l_ssi_id         samplestationitem.ssi_id%TYPE;
    BEGIN
        l_sdo_geometry :=
            pkg_sdoutil.f_buildsdo_geometry (p_coordinate_x, p_coordinate_y);


        p_id := seq_samplestation.NEXTVAL;


        INSERT INTO samplestation (sst_id,
                                   sst_oid,
                                   sst_oid_calculated,
                                   sst_oid_provided,
                                   sst_ins_id,
                                   sst_coordinates,
                                   sst_cvl_id_elevationorigin,
                                   sst_elevationprecision,
                                   sst_title,
                                   sst_gewissnr,
                                   sst_cvl_id_canton,
                                   sst_z,
                                   sst_usr_id_create,
                                   sst_usr_create_date)
             VALUES (p_id,
                     p_oid,
                     p_oid_calculated,
                     p_oid_provided,
                     p_ins_id,
                     l_sdo_geometry,
                     p_cvl_id_elevationorigin,
                     p_elevationprecision,
                     p_title,
                     p_gewissnr,
                     p_cvl_id_canton,
                     p_coordinate_z,
                     p_usr_id,
                     SYSDATE);
    END;



    /*-----------------------------------------------------------------------------------*/
    PROCEDURE p_writefulldata (
        p_lan_id                   IN     language.lan_id%TYPE,
        p_oid                      IN     samplestation.sst_oid%TYPE,
        p_oid_calculated           IN     samplestation.sst_oid_calculated%TYPE,
        p_oid_provided             IN     samplestation.sst_oid_provided%TYPE,
        p_ins_id                   IN     samplestation.sst_ins_id%TYPE,
        p_coordinate_x             IN     NUMBER,
        p_coordinate_y             IN     NUMBER,
        p_coordinate_z             IN     NUMBER,
        p_cvl_id_elevationorigin   IN     samplestation.sst_cvl_id_elevationorigin%TYPE,
        p_elevationprecision       IN     samplestation.sst_elevationprecision%TYPE,
        p_title                    IN     samplestation.sst_title%TYPE,
        p_locality                 IN     samplestationitem.ssi_item%TYPE,
        p_calledplace              IN     samplestationitem.ssi_item%TYPE,
        p_watercourse              IN     samplestationitem.ssi_item%TYPE,
        p_gewissnr                 IN     samplestation.sst_gewissnr%TYPE,
        p_usr_id                   IN     samplestation.sst_usr_id_create%TYPE,
        p_cvl_id_canton            IN     samplestation.sst_cvl_id_canton%TYPE,
        p_id                          OUT samplestation.sst_id%TYPE)
    /*---------------------------------------------------------------------------------*/
    IS
        l_cvl_id_midatstitmty   samplestationitem.ssi_cvl_id_midatstitmty%TYPE;
        l_reccodevalue          codevalue%ROWTYPE;
        l_ssi_id                samplestationitem.ssi_id%TYPE;
    BEGIN
        p_write (p_lan_id,
                 p_oid,
                 p_oid_calculated,
                 p_oid_provided,
                 p_ins_id,
                 p_coordinate_x,
                 p_coordinate_y,
                 p_coordinate_z,
                 p_cvl_id_elevationorigin,
                 p_elevationprecision,
                 p_title,
                 p_gewissnr,
                 p_usr_id,
                 p_cvl_id_canton,
                 p_id);

        IF NOT p_watercourse IS NULL
        THEN
            l_reccodevalue :=
                pkg_codevalue.f_getfromcode (
                    pkg_codevalue.cst_midatstitmty_watercourse,
                    pkg_codereference.cst_crf_midatstitmty);

            pkg_samplestationitem.p_writeifnotexist (p_id,
                                                     p_lan_id,
                                                     l_reccodevalue.cvl_id,
                                                     p_watercourse,
                                                     p_usr_id,
                                                     l_ssi_id);
        END IF;

        IF NOT p_locality IS NULL
        THEN
            l_reccodevalue :=
                pkg_codevalue.f_getfromcode (
                    pkg_codevalue.cst_midatstitmty_locality,
                    pkg_codereference.cst_crf_midatstitmty);

            pkg_samplestationitem.p_writeifnotexist (p_id,
                                                     p_lan_id,
                                                     l_reccodevalue.cvl_id,
                                                     p_locality,
                                                     p_usr_id,
                                                     l_ssi_id);
        END IF;

        IF NOT p_calledplace IS NULL
        THEN
            l_reccodevalue :=
                pkg_codevalue.f_getfromcode (
                    pkg_codevalue.cst_midatstitmty_calledplace,
                    pkg_codereference.cst_crf_midatstitmty);

            pkg_samplestationitem.p_writeifnotexist (p_id,
                                                     p_lan_id,
                                                     l_reccodevalue.cvl_id,
                                                     p_calledplace,
                                                     p_usr_id,
                                                     l_ssi_id);
        END IF;
    END;



    /*----------------------------------------------------------------------------------------------*/
    PROCEDURE p_findstationbycoordinates (
        p_point           IN     MDSYS.sdo_geometry,
        p_ins_id          IN     samplestation.sst_ins_id%TYPE,
        p_samplestation      OUT samplestation%ROWTYPE,
        p_distance           OUT NUMBER)
    /*----------------------------------------------------------------------------------------------*/
    IS
        l_point      MDSYS.sdo_geometry;
        l_distance   NUMBER;
        l_sst_id     samplestation.sst_id%TYPE;
    BEGIN
        SELECT sst_id, sdo_nn_distance (1)
          INTO l_sst_id, p_distance
          FROM samplestation
         WHERE     sdo_nn (sst_coordinates,
                           p_point,
                           'sdo_num_res=1,
                     unit=M',
                           1) = 'TRUE'
               AND sst_ins_id = p_ins_id;

        p_samplestation := pkg_samplestation.f_getrecord (l_sst_id);
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            p_distance := NULL;
            p_samplestation.sst_id := NULL;
    END;

    /*----------------------------------------------------------------------------------------------*/
    PROCEDURE p_findstationbycoordinates (
        p_x               IN     NUMBER,
        p_y               IN     NUMBER,
        p_z               IN     NUMBER,
        p_ins_id          IN     samplestation.sst_ins_id%TYPE,
        p_samplestation      OUT samplestation%ROWTYPE,
        p_distance           OUT NUMBER)
    /*----------------------------------------------------------------------------------------------*/
    IS
        l_point              MDSYS.sdo_geometry;
        l_distance           NUMBER;
        l_recsamplestation   samplestation%ROWTYPE;
    BEGIN
        IF p_z IS NULL
        THEN
            l_point := pkg_sdoutil.f_buildsdo_geometry (p_x, p_y);
        ELSE
            l_point := pkg_sdoutil.f_buildsdo_geometry (p_x, p_y, p_z);
        END IF;

        p_findstationbycoordinates (l_point,
                                    p_ins_id,
                                    p_samplestation,
                                    p_distance);
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            p_distance := NULL;
            p_samplestation.sst_id := NULL;
    END;
END pkg_samplestation;
/

