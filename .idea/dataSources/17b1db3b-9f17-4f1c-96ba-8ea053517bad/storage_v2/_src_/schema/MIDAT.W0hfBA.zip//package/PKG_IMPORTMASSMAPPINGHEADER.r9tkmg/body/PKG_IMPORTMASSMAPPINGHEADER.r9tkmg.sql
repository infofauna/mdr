create PACKAGE BODY       pkg_importmassmappingheader
AS
   /******************************************************************************
      NAME:       pkg_importmassmappingheader
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecord (p_ime_id IN importmassmappingheader.ime_id%TYPE)
      RETURN importmassmappingheader%ROWTYPE
   /*----------------------------------------------------------------*/
   IS
      l_record   importmassmappingheader%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM importmassmappingheader
       WHERE ime_id = p_ime_id;

      RETURN l_record;
   END;


   /*-------------------------------------------------------------*/
   FUNCTION f_getrecordbymidatfldcnt (
      p_iph_id        IN importmassmappingheader.ime_iph_id%TYPE,
      p_midatfldcnt   IN protocolmappingmassfield.pmm_code_midatfldcmt%TYPE)
      RETURN importmassmappingheader%ROWTYPE
   /*----------------------------------------------------------------*/

   IS
      l_record   importmassmappingheader%ROWTYPE;
   BEGIN
      SELECT importmassmappingheader.*
        INTO l_record
        FROM importmassmappingheader
             INNER JOIN protocolmappingmassfield ON ime_pmm_id = pmm_id
       WHERE ime_iph_id = p_iph_id AND pmm_code_midatfldcmt = p_midatfldcnt;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         pkg_debug.p_write (
            'PKG_IMPORTMASSMAPPINGHEADER.f_getrecordbymidatfldcnt',
            'p_midatfldcnt=<' || p_midatfldcnt || '>');
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_deletebyiph_idconditionnal (
      p_iph_id   IN importmassmappingheader.ime_iph_id%TYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importmassmappingheader
            WHERE     ime_iph_id = p_iph_id
                  AND ime_iph_id NOT IN (SELECT imd_iph_id
                                           FROM importmassdatadetail)
                  AND ime_iph_id NOT IN (SELECT imh_iph_id
                                           FROM importmassdataheader);
   END;


   /*--------------------------------------------------------------*/
   PROCEDURE p_deletebyiph_id (
      p_iph_id   IN importmassmappingheader.ime_iph_id%TYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importmassmappingheader
            WHERE ime_iph_id = p_iph_id;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_fieldispresent (
      p_iph_id       IN importmassmappingheader.ime_iph_id%TYPE,
      p_columnname      protocolmappingmassfield.pmm_columnname%TYPE)
      RETURN importmassmappingheader%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
   BEGIN
      SELECT importmassmappingheader.*
        INTO l_recimportmassmappingheader
        FROM importmassmappingheader
             INNER JOIN protocolmappingmassfield ON (ime_pmm_id = pmm_id)
       WHERE pmm_columnname = p_columnname AND ime_iph_id = p_iph_id;

      RETURN l_recimportmassmappingheader;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_fieldrefispresent (
      p_iph_id            IN importmassmappingheader.ime_iph_id%TYPE,
      p_codemidatfldcmt      protocolmappingmassfield.pmm_code_midatfldcmt%TYPE)
      RETURN importmassmappingheader%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
   BEGIN
      SELECT importmassmappingheader.*
        INTO l_recimportmassmappingheader
        FROM importmassmappingheader
             INNER JOIN protocolmappingmassfield ON (ime_pmm_id = pmm_id)
       WHERE     pmm_code_midatfldcmt = p_codemidatfldcmt
             AND ime_iph_id = p_iph_id;

      RETURN l_recimportmassmappingheader;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_insert (
      p_iph_id           IN importmassmappingheader.ime_iph_id%TYPE,
      p_pmm_id           IN importmassmappingheader.ime_pmm_id%TYPE,
      p_excelfieldname   IN importmassmappingheader.ime_excelfieldname%TYPE)
   /*---------------------------------------------------------------*/
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      INSERT
        INTO importmassmappingheader (ime_iph_id,
                                      ime_pmm_id,
                                      ime_excelfieldname)
      VALUES (p_iph_id, p_pmm_id, p_excelfieldname);

      COMMIT;
   END;

   /*---------------------------------------------------------------------------------*/
   PROCEDURE p_logmapping (
      p_iph_id   IN importmassmappingheader.ime_iph_id%TYPE,
      p_lan_id   IN importprotocolheader.iph_lan_id%TYPE)
   /*---------------------------------------------------------------------------------*/
   IS
      CURSOR l_listfield
      IS
         SELECT *
           FROM importmassmappingheader
                INNER JOIN protocolmappingmassfield ON pmm_id = ime_pmm_id
          WHERE ime_iph_id = p_iph_id;

      l_reclistfield              l_listfield%ROWTYPE;
      l_count                     NUMBER := 0;
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
      l_reccodedesignation        codedesignation%ROWTYPE;
   BEGIN
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);
      pkg_importprotocollog.p_writelog (
         p_iph_id,
         NULL,
         pkg_exception.cst_midatmassinfomapping,
         NULL);

      OPEN l_listfield;

      LOOP
         FETCH l_listfield INTO l_reclistfield;

         EXIT WHEN l_listfield%NOTFOUND;
         l_reccodedesignation :=
            pkg_codedesignation.f_getrecordbycode (
               l_reclistfield.pmm_code_midatfldcmt,
               pkg_codereference.cst_crf_midatfldcmt,
               p_lan_id);
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            NULL,
            pkg_exception.cst_info,
            NULL,
               l_reclistfield.ime_excelfieldname
            || ' -> '
            || l_reclistfield.pmm_columnname
            || ': '
            || l_reccodedesignation.cdn_designation);
      END LOOP;

      CLOSE l_listfield;
   END;
END;
/

