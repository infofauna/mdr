create PACKAGE       pkg_ibchstat
AS
    /******************************************************************************
       NAME:       pkg_ibchstat
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        08.10.2019      burrif       1. Created this package.
       1.1        23.01.2020      burrif       2. Identification TAXON_IBCH lorsque non fourni

    ******************************************************************************/



    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_getibchsomme_vt (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_getsumbytaxonibch (
        p_sph_id   IN sampleheader.sph_id%TYPE,
        p_taxon    IN protocolmappinglabo.ptl_taxa%TYPE)
        RETURN NUMBER;

    FUNCTION f_getibch (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_getibchgi (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_getibchvt (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_getibchsumtaxon (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_gettaxonindicateur (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN VARCHAR2;

    FUNCTION f_columntaxonibchexist (
        p_sph_id   IN sampleprotocolmass.smx_sph_id%TYPE)
        RETURN BOOLEAN;

    FUNCTION f_hascolumntaxonibchexist (
        p_sph_id   IN sampleprotocolmass.smx_sph_id%TYPE)
        RETURN VARCHAR2;
END;
/

