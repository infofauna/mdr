create PACKAGE BODY       pkg_wk_logchangedetail
AS
   /******************************************************************************
      NAME:       PKG_WK_LOGCHANGEDETAIL
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        21.03.2016      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, mars 2016';



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------*/
     PROCEDURE p_write (
      p_wkm_id               IN     wk_logchangedetail.wkd_wkm_id%TYPE,
      p_smx_id               IN     wk_logchangedetail.wkd_smx_id%TYPE,
      p_highertaxon          IN     wk_logchangedetail.wkd_highertaxon%TYPE,
      p_family               IN     wk_logchangedetail.wkd_family%TYPE,
      p_genus                IN     wk_logchangedetail.wkd_genus%TYPE,
      p_species              IN     wk_logchangedetail.wkd_species%TYPE,
      p_subspecies           IN     wk_logchangedetail.wkd_subspecies%TYPE,
      p_calculatedfullpath   IN     wk_logchangedetail.wkd_calculatedfullpath%TYPE,
      p_savedfullpath        IN     wk_logchangedetail.wkd_savedfullpath%TYPE,
      p_syv_id_calculated    IN     wk_logchangedetail.wkd_syv_id_calculated%TYPE,
      p_syv_id_saved         IN     wk_logchangedetail.wkd_syv_id_saved%TYPE,
      p_spl_id IN wk_logchangedetail.wkd_spl_id%type,
      p_wkd_id                  OUT wk_logchangedetail.wkd_id%TYPE)
   IS
   BEGIN
      p_wkd_id := seq_wk_logchangedetail.NEXTVAL;

      INSERT INTO wk_logchangedetail (wkd_id,
                                      wkd_wkm_id,
                                      wkd_smx_id,
                                      wkd_highertaxon,
                                      wkd_family,
                                      wkd_genus,
                                      wkd_species,
                                      wkd_subspecies,
                                      wkd_calculatedfullpath,
                                      wkd_savedfullpath,
                                      wkd_syv_id_calculated,
                                      wkd_syv_id_saved,
                                      wkd_spl_id)
           VALUES (p_wkd_id,
                   p_wkm_id,
                   p_smx_id,
                   p_highertaxon,
                   p_family,
                   p_genus,
                   p_species,
                   p_subspecies,
                   p_calculatedfullpath,
                   p_savedfullpath,
                   p_syv_id_calculated,
                   p_syv_id_saved,
                   p_spl_id);
   END;
END pkg_wk_logchangedetail;
/

