create PACKAGE       pkg_avaliabilitycalendar
AS
   /******************************************************************************
      NAME:       PKG_AVALIABILITYCALENDAR
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        28/07/2014      burrif       1. Created this package.
   ******************************************************************************/
   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_returnlistjourmoisnormal (
      p_indicetype     IN     avaliabilitycalendar.iac_cvl_id_midatindice%TYPE,
      p_elevation      IN     avaliabilitycalendar.iac_elevationmin%TYPE,
      p_jourmoislist      OUT VARCHAR2);



   FUNCTION f_getrecordbyindicetypeanddate (
      p_indicetype   IN avaliabilitycalendar.iac_cvl_id_midatindice%TYPE,
      p_date         IN DATE,
      p_elevation    IN avaliabilitycalendar.iac_elevationmin%TYPE)
      RETURN avaliabilitycalendar%ROWTYPE;

   FUNCTION f_getrecordbyindicetypeanddate (
      p_indicetype   IN avaliabilitycalendar.iac_cvl_id_midatindice%TYPE,
      p_date         IN DATE)
      RETURN avaliabilitycalendar%ROWTYPE;


   FUNCTION f_computeperiodtype (
      p_indicetype   IN avaliabilitycalendar.iac_cvl_id_midatindice%TYPE,
      p_date         IN DATE,
      p_elevation    IN avaliabilitycalendar.iac_elevationmin%TYPE)
      RETURN codevalue.cvl_code%TYPE;

   PROCEDURE p_write (
      p_cvl_id_midatindice   IN     avaliabilitycalendar.iac_cvl_id_midatindice%TYPE,
      p_cvl_id_midatwindow   IN     avaliabilitycalendar.iac_cvl_id_midatwindow%TYPE,
      p_elevationmin         IN     avaliabilitycalendar.iac_elevationmin%TYPE,
      p_elevationmax         IN     avaliabilitycalendar.iac_elevationmax%TYPE,
      p_startday             IN     avaliabilitycalendar.iac_startday%TYPE,
      p_endday               IN     avaliabilitycalendar.iac_endday%TYPE,
      p_startmonth           IN     avaliabilitycalendar.iac_startmonth%TYPE,
      p_endmonth             IN     avaliabilitycalendar.iac_endmonth%TYPE,
      p_id                      OUT avaliabilitycalendar.iac_id%TYPE);

   FUNCTION f_getrecord (p_id IN avaliabilitycalendar.iac_id%TYPE)
      RETURN avaliabilitycalendar%ROWTYPE;

   PROCEDURE p_deleteall;
END pkg_avaliabilitycalendar;
/

