create trigger TR_BIF_SAMPLEPROTOCOLLABO
    before insert
    on SAMPLEPROTOCOLLABO
    for each row
DECLARE
BEGIN
   IF :new.SPL_id IS NULL
   THEN
      :new.SPL_id := seq_SAMPLEPROTOCOLLABO.NEXTVAL;
   END IF; 

   :new.SPL_credate := SYSDATE;
   :new.SPL_creuser := USER;
END tr_bif_SAMPLEPROTOCOLLABO;

/

