create PACKAGE BODY       pkg_validateprotocolground
AS
   /******************************************************************************
      NAME:       PKG_VALIDATEPROTOCOLGROUND
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
      1.1        13.10.2017      burrif       2. Modification règle 
   ******************************************************************************/
   cst_checkboxvaluesetted         CONSTANT CHAR (1) := 'X';

   cst_packageversion              CONSTANT VARCHAR2 (30)
                                               := 'Version 1.0, septembre  2013' ;
   cst_presence_ok                 CONSTANT NUMBER := 1;
   cst_presence_missing_cause      CONSTANT NUMBER := -100;
   cst_presence_notreq_cause       CONSTANT NUMBER := -101;

   cst_cause_ok                    CONSTANT NUMBER := 1;
   cst_cause_notreq                CONSTANT NUMBER := -1; -- La case présence non est saisie et il y a un ou plusieurs cases définies -dans cause -> Erreur
   cst_cause_setted                CONSTANT NUMBER := -2; -- Aucune case présence n'est définie et il y a une ou plusieurs cases définies dans cause -> Warning
   cst_cause_unsetted              CONSTANT NUMBER := -3; -- Une case présence autre que non est définie mais la colonne cause est vide-> Warning
   
   cst_remarque_ok                 CONSTANT NUMBER := 1;
   cst_remarque_notreq             CONSTANT NUMBER := -10; -- La case présence non est saisie et il y a un ou plusieurs cases définies -dans remarque -> Erreur
   cst_remarque_setted             CONSTANT NUMBER := -11; -- Aucune case présence n'est définie et il y a une ou plusieurs cases définies dans remarque -> Warning
   cst_remarque_unsetted           CONSTANT NUMBER := -12; -- - Une case présence autre que non est définie mais la colonne remarque est vide-> Warning
   cst_remarque_autreunsetted      CONSTANT NUMBER := -14; -- - La case à cocher autre n'est pas définie mais un text est définie-> Warning
   cst_remarque_autresetted        CONSTANT NUMBER := -15; -- - La case à cocher autre est définie mais un text  n'est est définie-> Warning



   cst_infosup_raison_unsetted     CONSTANT NUMBER := -100;
   cst_infosup_checkbox_unsetted   CONSTANT NUMBER := -101;
   cst_infosup_ok                  CONSTANT NUMBER := 1;

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*------------------------------------------------------------------------*/
   FUNCTION f_countmemberofgroup (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_pmr_id                 IN importprotocolgrnd.ipn_pmr_id%TYPE)
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM importprotocolgrnd
       WHERE     ipn_pmr_id IN (SELECT pmr_id
                                  FROM protocolmappinggrnd
                                 WHERE     pmr_pmr_id = p_pmr_id
                                       AND pmr_ptv_id =
                                              p_importprotocolheader.iph_ptv_id)
             AND ipn_iph_id = p_importprotocolheader.iph_id
             AND NOT ipn_value IS NULL;

      RETURN l_count;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_checkpresencecause (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_key_non                IN codevalue.cvl_code%TYPE, --  Clé d'accès au non, non0, aucun
      p_key_parent_level       IN codevalue.cvl_code%TYPE) -- Boue,  turbidité,...
      RETURN NUMBER
   /*-------------------------------------------------------------*/
   IS
      l_pmr_id_group_presence       protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_group_cause          protocolmappinggrnd.pmr_id%TYPE;
      l_recimportprotocolgrnd_non   importprotocolgrnd%ROWTYPE;
      l_countchildrenrenpresence    NUMBER;
      l_countsettedrenpresence      NUMBER;
      l_countchildrenrencause       NUMBER;
      l_countsettedrencause         NUMBER;
      l_status                      NUMBER;
   BEGIN
      l_status := cst_cause_ok;


      l_pmr_id_group_presence :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_presence,
            p_key_parent_level,
            pkg_codevalue.cst_midatgrnd_aspectgen);
      l_recimportprotocolgrnd_non :=
         pkg_importprotocolgrnd.f_getrecordbykeys (
            p_importprotocolheader.iph_id,
            p_key_non,
            pkg_codevalue.cst_midatgrnd_presence,
            p_key_parent_level,
            pkg_codevalue.cst_midatgrnd_aspectgen);

      l_pmr_id_group_cause :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_cause,
            p_key_parent_level,
            pkg_codevalue.cst_midatgrnd_aspectgen);



      l_countchildrenrenpresence :=
         pkg_protocolmappinggrnd.f_countchildren (l_pmr_id_group_presence);
      l_countsettedrenpresence :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_group_presence);

      l_countchildrenrencause :=
         pkg_protocolmappinggrnd.f_countchildren (l_pmr_id_group_cause);
      l_countsettedrencause :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_group_cause);

      IF     pkg_datatype.f_ischeckboxsetted (
                l_recimportprotocolgrnd_non.ipn_value)
         AND l_countsettedrencause > 0
      -- La case présence non est saisie et il y a un ou plusieurs cases définies -dans cause -> Erreur
      THEN
         l_status := cst_cause_notreq;
         RETURN l_status;
      END IF;

      IF l_countsettedrenpresence = 0 AND l_countsettedrencause > 0
      THEN
         -- Aucune case présence n'est définie et il y a une ou plusieurs cases définies dans cause -> Warning
         l_status := cst_cause_setted;
         RETURN l_status;
      END IF;
/* Supprimé pour la version 2
      IF     NOT pkg_datatype.f_ischeckboxsetted (
                    l_recimportprotocolgrnd_non.ipn_value)
         AND l_countsettedrenpresence = 1
         AND l_countsettedrencause = 0
      THEN
         -- Une case présence autre que non est définie mais la colonne cause est vide
         l_status := cst_cause_unsetted;
         RETURN l_status;
         NULL;
      END IF;
*/
   



      RETURN l_status;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_checkpresenceremarque (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_keyword_non            IN     VARCHAR2,
      p_key_parent_level       IN     codevalue.cvl_code%TYPE, -- Boue,  turbidité,...
      p_flagpresence           IN     BOOLEAN, -- Si FALSE, le niveau présence n'existe pas
      p_status                    OUT NUMBER,
      p_autocompleteautre         OUT BOOLEAN)
   /*-------------------------------------------------------------*/
   IS
      l_pmr_id_group_presence          protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_group_remarque          protocolmappinggrnd.pmr_id%TYPE;
      l_recimportprotocolgrnd_non      importprotocolgrnd%ROWTYPE;
      l_recimportprotocolgrnd_remarq   importprotocolgrnd%ROWTYPE;
      l_recimportprotocolgrnd_autre    importprotocolgrnd%ROWTYPE;
      l_recimportprotocolgrnd_text     importprotocolgrnd%ROWTYPE;
      l_countchildrenrenpresence       NUMBER;
      l_countsettedrenpresence         NUMBER;
      l_countchildrenrenremarque       NUMBER;
      l_countsettedrenremarque         NUMBER;
   BEGIN
      p_status := cst_remarque_ok;
      p_autocompleteautre := FALSE;

      IF p_flagpresence
      THEN
         l_pmr_id_group_presence :=
            pkg_protocolmappinggrnd.f_getpmridbykeys (
               p_importprotocolheader.iph_ptv_id,
               pkg_codevalue.cst_midatgrnd_presence,
               p_key_parent_level,
               pkg_codevalue.cst_midatgrnd_aspectgen);
         l_recimportprotocolgrnd_non :=
            pkg_importprotocolgrnd.f_getrecordbykeys (
               p_importprotocolheader.iph_id,
               p_keyword_non,
               pkg_codevalue.cst_midatgrnd_presence,
               p_key_parent_level,
               pkg_codevalue.cst_midatgrnd_aspectgen);
      ELSE
         l_pmr_id_group_presence :=
            pkg_protocolmappinggrnd.f_getpmridbykeys (
               p_importprotocolheader.iph_ptv_id,
               p_key_parent_level,
               pkg_codevalue.cst_midatgrnd_aspectgen);
         l_recimportprotocolgrnd_non :=
            pkg_importprotocolgrnd.f_getrecordbykeys (
               p_importprotocolheader.iph_id,
               p_keyword_non,
               p_key_parent_level,
               pkg_codevalue.cst_midatgrnd_aspectgen);
      END IF;



      l_pmr_id_group_remarque :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_remarque,
            p_key_parent_level,
            pkg_codevalue.cst_midatgrnd_aspectgen);

      l_recimportprotocolgrnd_autre :=
         pkg_importprotocolgrnd.f_getrecordbykeys (
            p_importprotocolheader.iph_id,
            pkg_codevalue.cst_midatgrnd_oui,
            pkg_codevalue.cst_midatgrnd_autre,
            pkg_codevalue.cst_midatgrnd_remarque,
            p_key_parent_level,
            pkg_codevalue.cst_midatgrnd_aspectgen);
      l_recimportprotocolgrnd_text :=
         pkg_importprotocolgrnd.f_getrecordbykeys (
            p_importprotocolheader.iph_id,
            pkg_codevalue.cst_midatgrnd_nolabel,
            pkg_codevalue.cst_midatgrnd_autre,
            pkg_codevalue.cst_midatgrnd_remarque,
            p_key_parent_level,
            pkg_codevalue.cst_midatgrnd_aspectgen);
      pkg_debug.p_write ('PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
                         'p_key_parent_level=' || p_key_parent_level);

      pkg_debug.p_write (
         'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
            'l_recimportprotocolgrnd_non.ipn_value='
         || l_recimportprotocolgrnd_non.ipn_value);
      pkg_debug.p_write (
         'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
            'l_recimportprotocolgrnd_autre.ipn_value='
         || l_recimportprotocolgrnd_autre.ipn_value);

      pkg_debug.p_write (
         'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
            'l_recimportprotocolgrnd_text.ipn_value='
         || l_recimportprotocolgrnd_text.ipn_value);


      l_countchildrenrenpresence :=
         pkg_protocolmappinggrnd.f_countchildren (l_pmr_id_group_presence);
      l_countsettedrenpresence :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_group_presence);
      pkg_debug.p_write (
         'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
         'l_countchildrenrenpresence=' || l_countchildrenrenpresence);
      pkg_debug.p_write (
         'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
         'l_countsettedrenpresence=' || l_countsettedrenpresence);

      l_countchildrenrenremarque :=
         pkg_protocolmappinggrnd.f_countchildren (l_pmr_id_group_remarque);
      l_countsettedrenremarque :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_group_remarque);
      pkg_debug.p_write (
         'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
         'l_countchildrenrenremarque=' || l_countchildrenrenremarque);
      pkg_debug.p_write (
         'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
         'l_countsettedrenremarque=' || l_countsettedrenremarque);

      IF pkg_datatype.f_ischeckboxsetted (
            l_recimportprotocolgrnd_autre.ipn_value)
      THEN
         -- Si la case autre remarque est coché on la considère comme une autre
         l_countsettedrenremarque := l_countsettedrenremarque + 1;
      END IF;

      IF NOT l_recimportprotocolgrnd_text.ipn_value IS NULL
      THEN
         -- Si la valeur textuelle de la remarque remarque est définie, on la considère comme une autre
         l_countsettedrenremarque := l_countsettedrenremarque + 1;
      END IF;



      IF     pkg_datatype.f_ischeckboxsetted (
                l_recimportprotocolgrnd_non.ipn_value)
         AND l_countsettedrenremarque > 0
      -- La case présence non est saisie et il y a un ou plusieurs cases définies -dans remarque -> Erreur
      THEN
         p_status := cst_remarque_notreq;
         pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
            'Sortie: non défini et remarque défini');
         RETURN;
      END IF;


      IF l_countsettedrenpresence = 0 AND l_countsettedrenremarque > 0
      THEN
         -- Aucune case présence n'est définie et il y a une ou plusieurs cases définies dans remarque -> Warning
         p_status := cst_remarque_setted;

         IF     NOT pkg_datatype.f_ischeckboxsetted (
                       l_recimportprotocolgrnd_autre.ipn_value)
            AND NOT l_recimportprotocolgrnd_text.ipn_value IS NULL
         THEN
            p_autocompleteautre := TRUE;
            pkg_importprotocolgrnd.p_setvalue (
               l_recimportprotocolgrnd_autre.ipn_id,
               pkg_constante.cst_casesetted);
         END IF;

         pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
            'Sortie: Pas de présence et remarque définie');
         RETURN;
      END IF;

      IF     NOT pkg_datatype.f_ischeckboxsetted (
                    l_recimportprotocolgrnd_non.ipn_value)
         AND l_countsettedrenpresence = 1
         AND l_countsettedrenremarque = 0
      THEN
         -- Une case présence autre que non est définie mais la colonne cause est vide
         p_status := cst_remarque_unsetted;
         pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
            'Sortie: Non pas défini, une présence définie, pas de remarque');
         RETURN;
         NULL;
      END IF;

      IF     pkg_datatype.f_ischeckboxsetted (
                l_recimportprotocolgrnd_autre.ipn_value)
         AND l_recimportprotocolgrnd_text.ipn_value IS NULL
      THEN
         -- Si la case autre remarque est coché on la considère comme une autre  et que le texte est vide, message d'attention
         -- La valeur
         pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
            'Sortie: Autre défini et text pas défini');
         p_status := cst_remarque_autresetted;
         RETURN;
         NULL;
      END IF;

      IF     NOT pkg_datatype.f_ischeckboxsetted (
                    l_recimportprotocolgrnd_autre.ipn_value)
         AND NOT l_recimportprotocolgrnd_text.ipn_value IS NULL
      THEN
         -- Si la case à coche autre remarque n'est pas définie et que la valeur textuelle autre est définie, message d'attention
         p_status := cst_remarque_autreunsetted;
         p_autocompleteautre := TRUE;
         pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
            'Sortie: Autre pas défini et text défini');
         pkg_importprotocolgrnd.p_setvalue (
            l_recimportprotocolgrnd_autre.ipn_id,
            pkg_constante.cst_casesetted);
         pkg_debug.p_write (
            'PKG_VALIDATEPROTOCOLGRND.p_checkpresenceremarque',
            'Autre setted, ipn_id=: ' || l_recimportprotocolgrnd_autre.ipn_id);

         RETURN;
      END IF;
   END;



   /*----------------------------------------------------------------*/
   FUNCTION f_checkpresencecause (
      p_iph_id              IN importprotocolheader.iph_id%TYPE,
      p_key_parent_level1   IN codevalue.cvl_code%TYPE,
      p_key_parent_level2   IN codevalue.cvl_code%TYPE,
      p_key_presence_non    IN codevalue.cvl_code%TYPE,
      p_key_cause_1         IN codevalue.cvl_code%TYPE,
      p_key_cause_2         IN codevalue.cvl_code%TYPE,
      p_key_cause_3         IN codevalue.cvl_code%TYPE)
      RETURN NUMBER
   /*-------------------------------------------------------------*/
   IS
      /*
      Return
   cst_presence_ok   Si pas d'erreur
   cst_presence_missing_cause la colonne p_key_presence_1 ou p_key_presence_2 est renseigné mais pas un élément  p_key_cause_1, p_key_cause_2,p_key_cause_3;
   cst_presence_notrequiered_cause    la colonne p_key_presence_non  est renseigné et un élément  p_key_cause_1, p_key_cause_2,p_key_cause_3 est renseigné
   */
      l_recimportprotocolgrnd_non      importprotocolgrnd%ROWTYPE;
      l_recimportprotocolgrnd_caus_1   importprotocolgrnd%ROWTYPE;
      l_recimportprotocolgrnd_caus_2   importprotocolgrnd%ROWTYPE;
      l_recimportprotocolgrnd_caus_3   importprotocolgrnd%ROWTYPE;
      l_status                         NUMBER;
      l_pmr_id_group_presence          protocolmappinggrnd.pmr_id%TYPE;
   BEGIN
      l_recimportprotocolgrnd_non :=
         pkg_importprotocolgrnd.f_getrecordbykeys (p_iph_id,
                                                   p_key_presence_non,
                                                   p_key_parent_level2,
                                                   p_key_parent_level1);

      l_recimportprotocolgrnd_caus_1 :=
         pkg_importprotocolgrnd.f_getrecordbykeys (p_iph_id,
                                                   p_key_cause_1,
                                                   p_key_parent_level2,
                                                   p_key_parent_level1);
      DBMS_OUTPUT.put_line (
            'l_recimportprotocolgrnd_caus_1.ipn_value= '
         || l_recimportprotocolgrnd_caus_1.ipn_value);
      l_recimportprotocolgrnd_caus_2 :=
         pkg_importprotocolgrnd.f_getrecordbykeys (p_iph_id,
                                                   p_key_cause_2,
                                                   p_key_parent_level2,
                                                   p_key_parent_level1);
      DBMS_OUTPUT.put_line (
            'l_recimportprotocolgrnd_caus_2.ipn_value= '
         || l_recimportprotocolgrnd_caus_2.ipn_value);
      l_recimportprotocolgrnd_caus_3 :=
         pkg_importprotocolgrnd.f_getrecordbykeys (p_iph_id,
                                                   p_key_cause_3,
                                                   p_key_parent_level2,
                                                   p_key_parent_level1);
      DBMS_OUTPUT.put_line (
            'l_recimportprotocolgrnd_caus_3.ipn_value= '
         || l_recimportprotocolgrnd_caus_3.ipn_value);
      l_status := cst_presence_ok;

      -- Si non  dans présence est coché,  aucune des 3 case de cause ne doit être coché
      IF pkg_datatype.f_ischeckboxsetted (
            l_recimportprotocolgrnd_non.ipn_value)
      THEN
         IF    pkg_datatype.f_ischeckboxsetted (
                  l_recimportprotocolgrnd_caus_1.ipn_value)
            OR pkg_datatype.f_ischeckboxsetted (
                  l_recimportprotocolgrnd_caus_2.ipn_value)
            OR pkg_datatype.f_ischeckboxsetted (
                  l_recimportprotocolgrnd_caus_3.ipn_value)
         THEN
            l_status := cst_presence_notreq_cause;
         END IF;
      END IF;


      IF NOT pkg_datatype.f_ischeckboxsetted (
                l_recimportprotocolgrnd_non.ipn_value)
      THEN
         IF     NOT pkg_datatype.f_ischeckboxsetted (
                       l_recimportprotocolgrnd_caus_1.ipn_value)
            AND NOT pkg_datatype.f_ischeckboxsetted (
                       l_recimportprotocolgrnd_caus_2.ipn_value)
            AND NOT pkg_datatype.f_ischeckboxsetted (
                       l_recimportprotocolgrnd_caus_3.ipn_value)
         THEN
            l_status := cst_presence_missing_cause;
         END IF;
      END IF;


      RETURN l_status;
      NULL;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_checkinfosup (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_root_keyword           IN VARCHAR2)
      RETURN NUMBER
   /*---------------------------------------------------------------*/
   IS
      l_recimportprotocolgrnd_oui      importprotocolgrnd%ROWTYPE;
      l_recimportprotocolgrnd_raison   importprotocolgrnd%ROWTYPE;
   BEGIN
      l_recimportprotocolgrnd_oui :=
         pkg_importprotocolgrnd.f_getrecordbykeys (
            p_importprotocolheader.iph_id,
            pkg_codevalue.cst_midatgrnd_oui,
            p_root_keyword,
            pkg_codevalue.cst_midatgrnd_infosup);
      pkg_debug.p_write (
         'PKG_VALIDATEPROTOCOLGRND.f_checkinfosup',
            ' root_keyword='
         || p_root_keyword
         || 'iph_id='
         || p_importprotocolheader.iph_id
         || '  l_recimportprotocolgrnd_oui.ipn_value='
         || l_recimportprotocolgrnd_oui.ipn_value
         || '      l_recimportprotocolgrnd_oui.ipn_id='
         || l_recimportprotocolgrnd_oui.ipn_id);

      l_recimportprotocolgrnd_raison :=
         pkg_importprotocolgrnd.f_getrecordbykeys (
            p_importprotocolheader.iph_id,
            pkg_codevalue.cst_midatgrnd_nolabel,
            pkg_codevalue.cst_midatgrnd_raison,
            p_root_keyword,
            pkg_codevalue.cst_midatgrnd_infosup);
      pkg_debug.p_write (
         'PKG_VALIDATEPROTOCOLGRND.f_checkinfosup',
            ' root_keyword='
         || p_root_keyword
         || 'iph_id='
         || p_importprotocolheader.iph_id
         || '  l_recimportprotocolgrnd_raison.ipn_value='
         || l_recimportprotocolgrnd_raison.ipn_value
         || '      l_recimportprotocolgrnd_raison.ipn_id='
         || l_recimportprotocolgrnd_raison.ipn_id);

      IF pkg_datatype.f_ischeckboxsetted (
            l_recimportprotocolgrnd_oui.ipn_value)
      THEN
         IF l_recimportprotocolgrnd_raison.ipn_value IS NULL
         THEN
            -- La case à cocher de la rubrique %p1% est activée mais aucune valeur n'est saisie dans la colonne %p2%
            RETURN cst_infosup_raison_unsetted;
         END IF;
      ELSE
         IF NOT l_recimportprotocolgrnd_raison.ipn_value IS NULL
         THEN
            -- La case à cocher de la rubrique %p1% n'est pas activée alors qu'un valeur est saisie dans la colonne %p2% . Cette case à cocher est automatiquement activée.
            pkg_importprotocolgrnd.p_setvalue (
               l_recimportprotocolgrnd_oui.ipn_id,
               pkg_constante.cst_casesetted);
            RETURN cst_infosup_checkbox_unsetted;
         END IF;
      END IF;

      RETURN cst_infosup_ok;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_test1
   /*---------------------------------------------------------------*/
   IS
      l_status   NUMBER;
      l_iph_id   NUMBER := 9;
   BEGIN
      l_status :=
         f_checkpresencecause (l_iph_id,
                               pkg_codevalue.cst_midatgrnd_aspectgen,
                               pkg_codevalue.cst_midatgrnd_organisme,
                               pkg_codevalue.cst_midatgrnd_non,
                               pkg_codevalue.cst_midatgrnd_naturelle,
                               pkg_codevalue.cst_midatgrnd_artificiel,
                               pkg_codevalue.cst_midatgrnd_inconnue);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_validatecause (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_keyword_non            IN     VARCHAR2,
      p_keyword                IN     VARCHAR2,
      p_returnstatus              OUT NUMBER)
   /*-----------------------------------------------------------------*/

   IS
      l_status                       NUMBER;
      l_reccodedesignationrubrique   codedesignation%ROWTYPE;
      l_reccodedesignationcol1       codedesignation%ROWTYPE;
      l_reccodedesignationcol2       codedesignation%ROWTYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_status :=
         f_checkpresencecause (p_importprotocolheader,
                               p_keyword_non,
                               p_keyword);


      IF l_status = cst_cause_ok
      THEN
         RETURN;
      END IF;

      p_returnstatus := pkg_constante.cst_returnstatusnotok;
      l_reccodedesignationrubrique :=
         pkg_codedesignation.f_getrecordbycode (
            p_keyword,
            pkg_codereference.cst_crf_midatgrnd,
            p_importprotocolheader.iph_lan_id);
      l_reccodedesignationcol1 :=
         pkg_codedesignation.f_getrecordbycode (
            pkg_codevalue.cst_midatgrnd_presence,
            pkg_codereference.cst_crf_midatgrnd,
            p_importprotocolheader.iph_lan_id);
      l_reccodedesignationcol2 :=
         pkg_codedesignation.f_getrecordbycode (
            pkg_codevalue.cst_midatgrnd_cause,
            pkg_codereference.cst_crf_midatgrnd,
            p_importprotocolheader.iph_lan_id);


      IF l_status = cst_cause_notreq
      THEN
         --  Si une valeur "non" est saisie dans la colonne %p1% de la rubrique %p2%, alors la saisie de valeur dans la colonne %p3% n'est pas autorisé
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_noreqcause,
            NULL,                                                 -- Fieldname
            p_keyword_non,
            l_reccodedesignationcol1.cdn_designation,
            l_reccodedesignationrubrique.cdn_designation,
            l_reccodedesignationcol2.cdn_designation);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_noreqcause);
         RETURN;
      END IF;

      IF l_status = cst_cause_setted
      THEN
         --Aucune valeur n'est saisie dans la colonne %p1% de la rubrique %p2% et une ou plusieurs valeurs sont saisies dans la colonne %p3%
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_missingcause,
            NULL,                                                 -- Fieldname
            l_reccodedesignationcol1.cdn_designation,
            l_reccodedesignationrubrique.cdn_designation,
            l_reccodedesignationcol2.cdn_designation);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_missingcause);
         RETURN;
      END IF;

      IF l_status = cst_cause_unsetted
      THEN
         --Aucune valeur n'est saisie dans la colonne %p1% de la rubrique %p2% et une ou plusieurs valeurs sont saisies dans la colonne %p3%
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_causeunsetted,
            NULL,                                                 -- Fieldname
            l_reccodedesignationcol1.cdn_designation,
            l_reccodedesignationrubrique.cdn_designation,
            l_reccodedesignationcol2.cdn_designation);

         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_causeunsetted);
         RETURN;
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_validateremarque (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_keyword_non            IN     VARCHAR2,
      p_keyword                IN     VARCHAR2,
      p_flagpresence           IN     BOOLEAN,
      p_returnstatus              OUT NUMBER)
   /*-----------------------------------------------------------------*/

   IS
      l_status                       NUMBER;
      l_reccodedesignationrubrique   codedesignation%ROWTYPE;
      l_reccodedesignationcol1       codedesignation%ROWTYPE;
      l_reccodedesignationcol2       codedesignation%ROWTYPE;
      l_autocompleteautre            BOOLEAN;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      p_checkpresenceremarque (p_importprotocolheader,
                               p_keyword_non,
                               p_keyword,
                               p_flagpresence,
                               l_status,
                               l_autocompleteautre);



      IF l_status = cst_remarque_ok
      THEN
         RETURN;
      END IF;

      p_returnstatus := pkg_constante.cst_returnstatusnotok;
      l_reccodedesignationrubrique :=
         pkg_codedesignation.f_getrecordbycode (
            p_keyword,
            pkg_codereference.cst_crf_midatgrnd,
            p_importprotocolheader.iph_lan_id);
      l_reccodedesignationcol1 :=
         pkg_codedesignation.f_getrecordbycode (
            pkg_codevalue.cst_midatgrnd_presence,
            pkg_codereference.cst_crf_midatgrnd,
            p_importprotocolheader.iph_lan_id);
      l_reccodedesignationcol2 :=
         pkg_codedesignation.f_getrecordbycode (
            pkg_codevalue.cst_midatgrnd_remarque,
            pkg_codereference.cst_crf_midatgrnd,
            p_importprotocolheader.iph_lan_id);

      pkg_debug.p_write ('pkg_validateprotocolgrnd.p_validateremarque',
                         'l_status=' || l_status);

      IF l_status = cst_remarque_notreq
      THEN
         --  Si une valeur "non" est saisie dans la colonne %p1% de la rubrique %p2%, alors la saisie de valeur dans la colonne %p3% n'est pas autorisé
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_noreqcause,
            NULL,                                                 -- Fieldname
            p_keyword_non,
            l_reccodedesignationcol1.cdn_designation,
            l_reccodedesignationrubrique.cdn_designation,
            l_reccodedesignationcol2.cdn_designation);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_noreqcause);
         RETURN;
      END IF;

      IF l_status = cst_remarque_setted
      THEN
         --Aucune valeur n'est saisie dans la colonne %p1% de la rubrique %p2% et une ou plusieurs valeurs sont saisies dans la colonne %p3%
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_missingcause,
            NULL,                                                 -- Fieldname
            l_reccodedesignationcol1.cdn_designation,
            l_reccodedesignationrubrique.cdn_designation,
            l_reccodedesignationcol2.cdn_designation);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_missingcause);

         IF l_autocompleteautre
         THEN
            -- La valeur textuelle de la remarque de la rubrique %p1% est définie, mais la case à cocher correspondante ne l'est pas. Mise à jour automatique de la valeur de la case à cocher.
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_remarkcheckboxmissing,
               NULL,                                              -- Fieldname
               l_reccodedesignationrubrique.cdn_designation);

            IF p_returnstatus = pkg_constante.cst_returnstatusok
            THEN
               p_returnstatus :=
                  pkg_message.f_convertseveritylevel2status (
                     pkg_exception.cst_remarkcheckboxmissing);
            END IF;

            RETURN;
         END IF;
      END IF;

      IF l_status = cst_remarque_unsetted
      THEN
         --Aucune valeur n'est saisie dans la colonne %p1% de la rubrique %p2% et une ou plusieurs valeurs sont saisies dans la colonne %p3%
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_causeunsetted,
            NULL,                                                 -- Fieldname
            l_reccodedesignationcol1.cdn_designation,
            l_reccodedesignationrubrique.cdn_designation,
            l_reccodedesignationcol2.cdn_designation);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_causeunsetted);
         RETURN;
      END IF;

      pkg_debug.p_write ('pkg_validateprotocolgrnd.p_validateremarque',
                         'l_status=' || l_status);

      IF l_status = cst_remarque_autresetted
      THEN
         -- La case à cocher autre de la colonne remarque de la rubrique %p1% est défini, mais le texte de la remarque n'est pas défini
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_remarkmissing,
            NULL,                                                 -- Fieldname
            l_reccodedesignationrubrique.cdn_designation);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_remarkmissing);
         RETURN;
      END IF;

      IF l_status = cst_remarque_autreunsetted
      THEN
         -- La valeur textuelle de la remarque de la rubrique %p1% est définie, mais la case à cocher correspondante ne l'est pas. Mise à jour automatique de la valeur de la case à cocher.
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_remarkcheckboxmissing,
            NULL,                                                 -- Fieldname
            l_reccodedesignationrubrique.cdn_designation);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_remarkcheckboxmissing);
         RETURN;
      END IF;
   END;



   /*----------------------------------------------------------------*/
   PROCEDURE p_validateboue (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_returnstatus              OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_returnstatuscause      NUMBER;
      l_returnstatusremarque   NUMBER;
   BEGIN
      p_validatecause (p_importprotocolheader,
                       pkg_codevalue.cst_midatgrnd_non,
                       pkg_codevalue.cst_midatgrnd_boue,
                       l_returnstatuscause);
      p_validateremarque (p_importprotocolheader,
                          pkg_codevalue.cst_midatgrnd_non,
                          pkg_codevalue.cst_midatgrnd_boue,
                          TRUE,
                          l_returnstatusremarque);

      IF l_returnstatuscause != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatuscause;
      END IF;

      IF l_returnstatusremarque != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatusremarque;
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_validateturbidite (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_returnstatus              OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_returnstatuscause      NUMBER;
      l_returnstatusremarque   NUMBER;
   BEGIN
      p_validatecause (p_importprotocolheader,
                       pkg_codevalue.cst_midatgrnd_non,
                       pkg_codevalue.cst_midatgrnd_turbidite,
                       l_returnstatuscause);
      p_validateremarque (p_importprotocolheader,
                          pkg_codevalue.cst_midatgrnd_non,
                          pkg_codevalue.cst_midatgrnd_turbidite,
                          TRUE,
                          l_returnstatusremarque);

      IF l_returnstatuscause != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatuscause;
      END IF;

      IF l_returnstatusremarque != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatusremarque;
      END IF;
   END;



   /*----------------------------------------------------------------*/
   PROCEDURE p_validatecoloration (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_returnstatus              OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_returnstatuscause      NUMBER;
      l_returnstatusremarque   NUMBER;
   BEGIN
      p_validatecause (p_importprotocolheader,
                       pkg_codevalue.cst_midatgrnd_non,
                       pkg_codevalue.cst_midatgrnd_coloration,
                       l_returnstatuscause);
      p_validateremarque (p_importprotocolheader,
                          pkg_codevalue.cst_midatgrnd_non,
                          pkg_codevalue.cst_midatgrnd_coloration,
                          TRUE,
                          l_returnstatusremarque);

      IF l_returnstatuscause != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatuscause;
      END IF;

      IF l_returnstatusremarque != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatusremarque;
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_validatemousse (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_returnstatus              OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_returnstatuscause      NUMBER;
      l_returnstatusremarque   NUMBER;
   BEGIN
      p_validatecause (p_importprotocolheader,
                       pkg_codevalue.cst_midatgrnd_non,
                       pkg_codevalue.cst_midatgrnd_mousse,
                       l_returnstatuscause);
      p_validateremarque (p_importprotocolheader,
                          pkg_codevalue.cst_midatgrnd_non,
                          pkg_codevalue.cst_midatgrnd_mousse,
                          TRUE,
                          l_returnstatusremarque);

      IF l_returnstatuscause != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatuscause;
      END IF;

      IF l_returnstatusremarque != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatusremarque;
      END IF;
   END;


   /*----------------------------------------------------------------*/
   PROCEDURE p_validateodeur (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_returnstatus              OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_returnstatuscause      NUMBER;
      l_returnstatusremarque   NUMBER;
   BEGIN
      p_validatecause (p_importprotocolheader,
                       pkg_codevalue.cst_midatgrnd_non,
                       pkg_codevalue.cst_midatgrnd_odeur,
                       l_returnstatuscause);
      p_validateremarque (p_importprotocolheader,
                          pkg_codevalue.cst_midatgrnd_non,
                          pkg_codevalue.cst_midatgrnd_odeur,
                          TRUE,
                          l_returnstatusremarque);

      IF l_returnstatuscause != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatuscause;
      END IF;

      IF l_returnstatusremarque != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatusremarque;
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_validatesulfurefer (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_returnstatus              OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_returnstatuscause      NUMBER;
      l_returnstatusremarque   NUMBER;
   BEGIN
      p_validatecause (p_importprotocolheader,
                       pkg_codevalue.cst_midatgrnd_non0,
                       pkg_codevalue.cst_midatgrnd_sulfurefer,
                       l_returnstatuscause);
      p_validateremarque (p_importprotocolheader,
                          pkg_codevalue.cst_midatgrnd_non0,
                          pkg_codevalue.cst_midatgrnd_sulfurefer,
                          TRUE,
                          l_returnstatusremarque);

      IF l_returnstatuscause != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatuscause;
      END IF;

      IF l_returnstatusremarque != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatusremarque;
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_validatecolmatage (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_returnstatus              OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_returnstatuscause      NUMBER;
      l_returnstatusremarque   NUMBER;
   BEGIN
      p_validatecause (p_importprotocolheader,
                       pkg_codevalue.cst_midatgrnd_non,
                       pkg_codevalue.cst_midatgrnd_colmatage,
                       l_returnstatuscause);
      p_validateremarque (p_importprotocolheader,
                          pkg_codevalue.cst_midatgrnd_non,
                          pkg_codevalue.cst_midatgrnd_colmatage,
                          TRUE,
                          l_returnstatusremarque);

      IF l_returnstatuscause != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatuscause;
      END IF;

      IF l_returnstatusremarque != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatusremarque;
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_validatedechets (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_returnstatus              OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_returnstatusremarque          NUMBER;
      l_recprotocolversion            protocolversion%ROWTYPE;
      l_reccodevalueprotocoltype      codevalue%ROWTYPE;
      l_recimportprotocolgrnd         importprotocolgrnd%ROWTYPE;
      l_recimportprotocolgrnd_autre   importprotocolgrnd%ROWTYPE;
      l_pmr_id_solide                 protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_remarque               protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_remarque_autre         protocolmappinggrnd.pmr_id%TYPE;
      l_aucunsolidesetted             BOOLEAN;
      l_aucundechetsetted             BOOLEAN;
      l_autreremarquesetted           BOOLEAN;
      l_countremarque                 NUMBER;
      l_countautreremarque            NUMBER;
      l_reccodedesignation2           codedesignation%ROWTYPE;
      l_reccodedesignation1           codedesignation%ROWTYPE;
      l_fieldname                     importprotocollog.ipo_fieldname%TYPE;
   -- Solide est devenu Dechets EE*
   -- Dechet est devenu Autre dechet
   BEGIN
      l_recprotocolversion :=
         pkg_protocolversion.f_getrecord (p_importprotocolheader.iph_ptv_id);
      l_reccodevalueprotocoltype :=
         pkg_codevalue.f_getrecord (
            l_recprotocolversion.ptv_cvl_id_protocoltype);

      IF l_reccodevalueprotocoltype.cvl_code !=
            pkg_codevalue.cst_protocoltype_ground
      THEN
         RETURN;
      END IF;

      IF l_recprotocolversion.ptv_version !=
            pkg_protocolversion.cst_version_1_0
      THEN
         RETURN;               -- Pas de règle pour les versions autre que 1.0
      END IF;

      l_recimportprotocolgrnd :=
         pkg_importprotocolgrnd.f_getrecordbykeys (
            p_importprotocolheader.iph_id,
            pkg_codevalue.cst_midatgrnd_aucun,
            pkg_codevalue.cst_midatgrnd_solide,
            pkg_codevalue.cst_midatgrnd_aspectgen);

      l_aucunsolidesetted :=
         UPPER (TRIM (l_recimportprotocolgrnd.ipn_value)) =
            pkg_datatype.cst_checkboxvaluesetted;

      l_recimportprotocolgrnd :=
         pkg_importprotocolgrnd.f_getrecordbykeys (
            p_importprotocolheader.iph_id,
            pkg_codevalue.cst_midatgrnd_aucun,
            pkg_codevalue.cst_midatgrnd_dechets,
            pkg_codevalue.cst_midatgrnd_aspectgen);
      pkg_debug.p_write (
         'pkg_validateprotocolground.p_validatedechets',
         'l_recimportprotocolgrnd.ipn_id=' || l_recimportprotocolgrnd.ipn_id);

      l_aucundechetsetted :=
         UPPER (TRIM (l_recimportprotocolgrnd.ipn_value)) =
            pkg_datatype.cst_checkboxvaluesetted;

      l_pmr_id_remarque :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_remarque,
            pkg_codevalue.cst_midatgrnd_dechets,
            pkg_codevalue.cst_midatgrnd_aspectgen);
      l_countremarque :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_remarque);
      l_pmr_id_remarque_autre :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_autre,
            pkg_codevalue.cst_midatgrnd_remarque,
            pkg_codevalue.cst_midatgrnd_dechets,
            pkg_codevalue.cst_midatgrnd_aspectgen);

      l_countautreremarque :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_remarque_autre);



      pkg_debug.p_write ('pkg_validateprotocolground.p_validatedechets',
                         'l_countremarque=' || l_countremarque);
      pkg_debug.p_write ('pkg_validateprotocolground.p_validatedechets',
                         'l_countautreremarque=' || l_countautreremarque);


      IF l_aucundechetsetted
      THEN
         pkg_debug.p_write ('pkg_validateprotocolground.p_validatedechets',
                            'autre déchet setted');
      ELSE
         pkg_debug.p_write ('pkg_validateprotocolground.p_validatedechets',
                            'autre déchet unsetted');
      END IF;

      pkg_debug.p_write ('pkg_validateprotocolground.p_validatedechets',
                         'l_countremarque=' || l_countremarque);

      IF l_aucunsolidesetted
      THEN
         pkg_debug.p_write ('pkg_validateprotocolground.p_validatedechets',
                            'aucun solide setted');
      ELSE
         pkg_debug.p_write ('pkg_validateprotocolground.p_validatedechets',
                            'aucun solide unsetted');
      END IF;

      l_reccodedesignation1 :=
         pkg_codedesignation.f_getrecordbycode (
            pkg_codevalue.cst_midatgrnd_solide,
            pkg_codereference.cst_crf_midatgrnd,
            p_importprotocolheader.iph_lan_id);
      l_reccodedesignation2 :=
         pkg_codedesignation.f_getrecordbycode (
            pkg_codevalue.cst_midatgrnd_dechets,
            pkg_codereference.cst_crf_midatgrnd,
            p_importprotocolheader.iph_lan_id);

      /*
      -- message d'erreur si les deux cases 142 ET 145 sont cochées et une des cases 148-153 sont cochées!
      IF l_aucunsolidesetted AND l_aucundechetsetted
      THEN

         -- La saisie d'une remarque n'est pas autorisée  si les rubriques "%p1%" et "%p2%" sont simultanément renseignés avec les valeurs "Aucun"
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_dechetaucundisableremark,
            l_fieldname,
            l_reccodedesignation1.cdn_designation,
            l_reccodedesignation2.cdn_designation);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_dechetaucundisableremark);

         RETURN;
      END IF;
*/
      -- Reste a réaliser l'auto remarque autre
      IF l_countautreremarque = 0 OR l_countautreremarque = 2
      THEN
         RETURN;    -- Pas de problème, autre pas coché ou autre + texte coché
      END IF;

      IF l_countautreremarque = 1
      THEN
         l_recimportprotocolgrnd_autre :=
            pkg_importprotocolgrnd.f_getrecordbykeys (
               p_importprotocolheader.iph_id,
               pkg_codevalue.cst_midatgrnd_oui,
               pkg_codevalue.cst_midatgrnd_autre,
               pkg_codevalue.cst_midatgrnd_remarque,
               pkg_codevalue.cst_midatgrnd_dechets,
               pkg_codevalue.cst_midatgrnd_aspectgen);
         l_autreremarquesetted :=
            UPPER (TRIM (l_recimportprotocolgrnd_autre.ipn_value)) =
               pkg_datatype.cst_checkboxvaluesetted;

         IF l_autreremarquesetted
         THEN
            pkg_debug.p_write (
               'pkg_validateprotocolground.p_validatedechets',
               'autre setted');
            -- La case à cocher autre de la colonne remarque de la rubrique %p1% est défini, mais le texte de la remarque n'est pas défini
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_remarkmissing,
               NULL,                                              -- Fieldname
                  '"'
               || l_reccodedesignation1.cdn_designation
               || ' + '
               || l_reccodedesignation2.cdn_designation
               || '"');
            p_returnstatus :=
               pkg_message.f_convertseveritylevel2status (
                  pkg_exception.cst_remarkmissing);
            RETURN;
         ELSE
            pkg_debug.p_write (
               'pkg_validateprotocolground.p_validatedechets',
               'autre unsetted');
            -- La valeur textuelle de la remarque de la rubrique %p1% est définie, mais la case à cocher correspondante ne l'est pas. Mise à jour automatique de la valeur de la case à cocher.
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_remarkcheckboxmissing,
               NULL,                                              -- Fieldname
                  '"'
               || l_reccodedesignation1.cdn_designation
               || ' + '
               || l_reccodedesignation2.cdn_designation
               || '"');
            pkg_importprotocolgrnd.p_setvalue (
               l_recimportprotocolgrnd_autre.ipn_id,
               pkg_constante.cst_casesetted);


            p_returnstatus :=
               pkg_message.f_convertseveritylevel2status (
                  pkg_exception.cst_remarkcheckboxmissing);
         END IF;
      END IF;
   /*
         p_validateremarque (p_importprotocolheader,
                             pkg_codevalue.cst_midatgrnd_aucun,
                             pkg_codevalue.cst_midatgrnd_dechets,
                             FALSE,                     -- Pas de niveau présence
                             l_returnstatusremarque);



         IF l_returnstatusremarque != pkg_constante.cst_returnstatusok
         THEN
            p_returnstatus := l_returnstatusremarque;
         END IF;
         */
   END;


   /*----------------------------------------------------------------*/
   PROCEDURE p_validateorganisme (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_returnstatus              OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_returnstatuscause      NUMBER;
      l_returnstatusremarque   NUMBER;
   BEGIN
      p_validatecause (p_importprotocolheader,
                       pkg_codevalue.cst_midatgrnd_non,
                       pkg_codevalue.cst_midatgrnd_organisme,
                       l_returnstatuscause);
      p_validateremarque (p_importprotocolheader,
                          pkg_codevalue.cst_midatgrnd_non,
                          pkg_codevalue.cst_midatgrnd_organisme,
                          TRUE,
                          l_returnstatusremarque);

      IF l_returnstatuscause != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatuscause;
      END IF;

      IF l_returnstatusremarque != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatusremarque;
      END IF;
   END;



   /*----------------------------------------------------------------*/
   PROCEDURE p_testpresencecause
   /*----------------------------------------------------------------*/
   IS
      l_check   NUMBER;
   BEGIN
      l_check :=
         f_checkpresencecause (2,                                 --  p_iph_id
                               pkg_codevalue.cst_midatgrnd_aspectgen,
                               pkg_codevalue.cst_midatgrnd_boue,
                               pkg_codevalue.cst_midatgrnd_non,
                               pkg_codevalue.cst_midatgrnd_naturelle,
                               pkg_codevalue.cst_midatgrnd_artificiel,
                               pkg_codevalue.cst_midatgrnd_inconnue);
      DBMS_OUTPUT.put_line ('l_check=' || l_check);
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_validatepermrenforgauche (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_recprotocolmappinggrnd      protocolmappinggrnd%ROWTYPE;
      l_rivegauchenulsetted         BOOLEAN := FALSE;
      l_countpermeabilitegauche     NUMBER;
      l_countsettedrenforgauche     NUMBER;
      l_countchildrenrenforgauche   NUMBER;
      l_countsettedpermgauche       NUMBER;
      l_countchildrenpermgauche     NUMBER;
      l_fieldname                   importprotocollog.ipo_fieldname%TYPE;
      l_recimportprotocolgrnd       importprotocolgrnd%ROWTYPE;
      l_pmr_id_group_perm           protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_group_renf           protocolmappinggrnd.pmr_id%TYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_pmr_id_group_perm :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_rivegauche,
            pkg_codevalue.cst_midatgrnd_permrenforg,
            pkg_codevalue.cst_midatgrnd_ecomorph);
      l_pmr_id_group_renf :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_rivegauche,
            pkg_codevalue.cst_midatgrnd_renforpied,
            pkg_codevalue.cst_midatgrnd_ecomorph);
      l_countchildrenrenforgauche :=
         pkg_protocolmappinggrnd.f_countchildren (l_pmr_id_group_renf);
      l_countsettedrenforgauche :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_group_renf);
      l_countchildrenpermgauche :=
         pkg_protocolmappinggrnd.f_countchildren (l_pmr_id_group_perm);
      l_countsettedpermgauche :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_group_perm);


      IF l_countsettedrenforgauche > 1
      THEN
         -- S'il y a plusieurs case cochées dans le groupe Renforcement du pied de berge rive gauche, on sont sans erreur car une erreur est déjà définie
         RETURN;
      END IF;



      l_recimportprotocolgrnd :=
         pkg_importprotocolgrnd.f_getrecordbykeys (
            p_importprotocolheader.iph_id,
            pkg_codevalue.cst_midatgrnd_nul,
            pkg_codevalue.cst_midatgrnd_rivegauche,
            pkg_codevalue.cst_midatgrnd_renforpied,
            pkg_codevalue.cst_midatgrnd_ecomorph);

      l_rivegauchenulsetted :=
         UPPER (TRIM (l_recimportprotocolgrnd.ipn_value)) =
            pkg_datatype.cst_checkboxvaluesetted;

      IF l_rivegauchenulsetted
      THEN
         IF l_countsettedpermgauche > 0
         THEN
            -- La saisie de la valeur "nul" dans la  case à cocher "perméabilité du renforcement de la rive gauche"  est incompatible avec la saisie d'une valeur dans les case à cocher "Perméabilité du renforcement gauche
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_strengtheningleftbankinco,
               l_fieldname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
         END IF;

         RETURN; -- Ok  rivegauche null défini et pas de valeur saisie dans  perméabilité.
      END IF;

      --  null non choisi dans rivegauche
      IF l_countsettedrenforgauche > 0
      THEN
         IF l_countsettedpermgauche = 0
         THEN
            -- La saisie d'une valeur autre que nul dans le groupe "Renforcement du pied de la berge rive gauche"  nécessite la saisie d'une valeur dans le groupe "Perméabilité du renforcement de berge gauche"
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_leftpermrenforunset,
               l_fieldname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
         END IF;

         IF l_countsettedpermgauche > 1
         THEN
            -- Une seule des deux cases du groupe "Perméabilité du renforcement de berge gauche" doit être saisie
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_onlyoneleftmatamenauth,
               l_fieldname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
         END IF;
      ELSE                                      -- l_countsettedrenforgauche=0
         IF l_countsettedpermgauche > 0
         THEN
            --  La saisie de valeur(s) dans le groupe "Perméabilité du renforcement de berge gauche" nécessite la saisie d'une valeur autre que nul dans le groupe "Renforcement du pied de la berge rive gauche"  "Renforcement du pied de la berge rive gauche"
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_leftpermrenforunset,
               l_fieldname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
         END IF;
      END IF;



      IF NOT l_rivegauchenulsetted AND l_countsettedpermgauche > 0 -- Un autre valeur que null est setter
      THEN
         --  La saisie de valeur(s) dans le groupe "Perméabilité du renforcement de berge gauche" nécessite la saisie d'une valeur autre que nul dans le groupe "Renforcement du pied de la berge rive gauche"  "Renforcement du pied de la berge rive gauche"
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_leftpermrenforunset,
            l_fieldname);
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_validatepermrenfordroite (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_recprotocolmappinggrnd      protocolmappinggrnd%ROWTYPE;
      l_rivedroitenulsetted         BOOLEAN := FALSE;
      l_countpermeabilitedroite     NUMBER;
      l_countsettedrenfordroite     NUMBER;
      l_countchildrenrenfordroite   NUMBER;
      l_countsettedpermdroite       NUMBER;
      l_countchildrenpermdroite     NUMBER;
      l_fieldname                   importprotocollog.ipo_fieldname%TYPE;
      l_recimportprotocolgrnd       importprotocolgrnd%ROWTYPE;
      l_pmr_id_group_perm           protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_group_renf           protocolmappinggrnd.pmr_id%TYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_pmr_id_group_perm :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_rivedroite,
            pkg_codevalue.cst_midatgrnd_permrenforg,
            pkg_codevalue.cst_midatgrnd_ecomorph);
      l_pmr_id_group_renf :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_rivedroite,
            pkg_codevalue.cst_midatgrnd_renforpied,
            pkg_codevalue.cst_midatgrnd_ecomorph);
      l_countchildrenrenfordroite :=
         pkg_protocolmappinggrnd.f_countchildren (l_pmr_id_group_renf);
      l_countsettedrenfordroite :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_group_renf);
      l_countchildrenpermdroite :=
         pkg_protocolmappinggrnd.f_countchildren (l_pmr_id_group_perm);
      l_countsettedpermdroite :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_group_perm);


      IF l_countsettedrenfordroite > 1
      THEN
         -- S'il y a plusieurs case cochées dans le groupe Renforcement du pied de berge rive droite, on sont sans erreur car une erreur est déjà définie
         RETURN;
      END IF;



      l_recimportprotocolgrnd :=
         pkg_importprotocolgrnd.f_getrecordbykeys (
            p_importprotocolheader.iph_id,
            pkg_codevalue.cst_midatgrnd_nul,
            pkg_codevalue.cst_midatgrnd_rivedroite,
            pkg_codevalue.cst_midatgrnd_renforpied,
            pkg_codevalue.cst_midatgrnd_ecomorph);

      l_rivedroitenulsetted :=
         UPPER (TRIM (l_recimportprotocolgrnd.ipn_value)) =
            pkg_datatype.cst_checkboxvaluesetted;

      IF l_rivedroitenulsetted
      THEN
         IF l_countsettedpermdroite > 0
         THEN
            -- La saisie de la valeur "nul" dans la  case à cocher "perméabilité du renforcement de la rive droite"  est incompatible avec la saisie d'une valeur dans les case à cocher "Perméabilité du renforcement droite
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_strengtheningrightbankinco,
               l_fieldname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
         END IF;

         RETURN; -- Ok  rivedroite null défini et pas de valeur saisie dans  perméabilité.
      END IF;

      --  null non choisi dans rivedroite
      IF l_countsettedrenfordroite > 0
      THEN
         IF l_countsettedpermdroite = 0
         THEN
            -- La saisie d'une valeur autre que nul dans le groupe "Renforcement du pied de la berge rive droite"  nécessite la saisie d'une valeur dans le groupe "Perméabilité du renforcement de berge droite"
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_leftpermrenforunset,
               l_fieldname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
         END IF;

         IF l_countsettedpermdroite > 1
         THEN
            -- Une seule des deux cases du groupe "Perméabilité du renforcement de berge droite" doit être saisie
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_onlyonerigthmatamenauth,
               l_fieldname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
         END IF;
      ELSE                                      -- l_countsettedrenfordroite=0
         IF l_countsettedpermdroite > 0
         THEN
            --  La saisie de valeur(s) dans le groupe "Perméabilité du renforcement de berge droite" nécessite la saisie d'une valeur autre que nul dans le groupe "Renforcement du pied de la berge rive droite"  "Renforcement du pied de la berge rive droite"
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_leftpermrenforunset,
               l_fieldname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
         END IF;
      END IF;



      IF NOT l_rivedroitenulsetted AND l_countsettedpermdroite > 0 -- Un autre valeur que null est setter
      THEN
         --  La saisie de valeur(s) dans le groupe "Perméabilité du renforcement de berge droite" nécessite la saisie d'une valeur autre que nul dans le groupe "Renforcement du pied de la berge rive droite"  "Renforcement du pied de la berge rive droite"
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_leftpermrenforunset,
            l_fieldname);
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;
   END;



   /*--------------------------------------------------------------*/
   PROCEDURE p_validatenaturerivegauche (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_recprotocolmappinggrnd      protocolmappinggrnd%ROWTYPE;
      l_rivegauchenulsetted         BOOLEAN := FALSE;

      l_countchildrennaturegauche   NUMBER;
      l_countsettednaturegauche     NUMBER;
      l_fieldname                   importprotocollog.ipo_fieldname%TYPE;
      l_recimportprotocolgrnd       importprotocolgrnd%ROWTYPE;
      l_pmr_id_group_nature         protocolmappinggrnd.pmr_id%TYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_pmr_id_group_nature :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_rivegauche,
            pkg_codevalue.cst_midatgrnd_naturerive,
            pkg_codevalue.cst_midatgrnd_ecomorph);

      l_countchildrennaturegauche :=
         pkg_protocolmappinggrnd.f_countchildren (l_pmr_id_group_nature);
      l_countsettednaturegauche :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_group_nature);

      IF l_countsettednaturegauche = 0
      THEN
         NULL;
      END IF;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_validatenaturerivedroite (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_recprotocolmappinggrnd      protocolmappinggrnd%ROWTYPE;
      l_rivedroitenulsetted         BOOLEAN := FALSE;

      l_countchildrennaturedroite   NUMBER;
      l_countsettednaturedroite     NUMBER;
      l_fieldname                   importprotocollog.ipo_fieldname%TYPE;
      l_recimportprotocolgrnd       importprotocolgrnd%ROWTYPE;
      l_pmr_id_group_nature         protocolmappinggrnd.pmr_id%TYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_pmr_id_group_nature :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_rivedroite,
            pkg_codevalue.cst_midatgrnd_naturerive,
            pkg_codevalue.cst_midatgrnd_ecomorph);

      l_countchildrennaturedroite :=
         pkg_protocolmappinggrnd.f_countchildren (l_pmr_id_group_nature);
      l_countsettednaturedroite :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_group_nature);

      IF l_countsettednaturedroite = 0
      THEN
         NULL;
      END IF;
   END;



   /*---------------------------------------------------------------*/
   PROCEDURE p_validatenaturerive (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_recprotocolversion         protocolversion%ROWTYPE;
      l_reccodevalueprotocoltype   codevalue%ROWTYPE;
      l_returnstatusdroite         NUMBER;
      l_returnstatusgauche         NUMBER;
   BEGIN
      l_recprotocolversion :=
         pkg_protocolversion.f_getrecord (p_importprotocolheader.iph_ptv_id);
      l_reccodevalueprotocoltype :=
         pkg_codevalue.f_getrecord (
            l_recprotocolversion.ptv_cvl_id_protocoltype);

      IF l_reccodevalueprotocoltype.cvl_code !=
            pkg_codevalue.cst_protocoltype_ground
      THEN
         RETURN;
      END IF;

      IF l_recprotocolversion.ptv_version !=
            pkg_protocolversion.cst_version_1_0
      THEN
         RETURN;               -- Pas de règle pour les versions autre que 1.0
      END IF;

      p_validatenaturerivegauche (p_importprotocolheader,
                                  p_usr_id,
                                  l_returnstatusgauche);
      p_validatenaturerivedroite (p_importprotocolheader,
                                  p_usr_id,
                                  l_returnstatusdroite);

      IF    l_returnstatusgauche = pkg_constante.cst_returnstatusnotok
         OR l_returnstatusdroite = pkg_constante.cst_returnstatusnotok
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
      ELSE
         p_returnstatus := pkg_constante.cst_returnstatusok;
      END IF;
   END;



   /*---------------------------------------------------------------*/
   PROCEDURE p_validateinfosup (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_returnstatus   NUMBER;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_returnstatus :=
         f_checkinfosup (p_importprotocolheader,
                         pkg_codevalue.cst_midatgrnd_depechan);

      IF l_returnstatus = cst_infosup_raison_unsetted
      THEN
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_checkboxsetandtextnotset,
            NULL,                                                 -- Fieldname
            pkg_codevalue.cst_midatgrnd_depechan,
            pkg_codevalue.cst_midatgrnd_raison);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_checkboxsetandtextnotset);
      END IF;

      IF l_returnstatus = cst_infosup_checkbox_unsetted
      THEN
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_checkboxnotsetandtextset,
            NULL,                                                 -- Fieldname
            pkg_codevalue.cst_midatgrnd_depechan,
            pkg_codevalue.cst_midatgrnd_raison);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_checkboxnotsetandtextset);
      END IF;

      l_returnstatus :=
         f_checkinfosup (p_importprotocolheader,
                         pkg_codevalue.cst_midatgrnd_abansta);

      IF l_returnstatus = cst_infosup_raison_unsetted
      THEN
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_checkboxsetandtextnotset,
            NULL,                                                 -- Fieldname
            pkg_codevalue.cst_midatgrnd_abansta,
            pkg_codevalue.cst_midatgrnd_raison);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_checkboxsetandtextnotset);
      END IF;

      IF l_returnstatus = cst_infosup_checkbox_unsetted
      THEN
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_checkboxnotsetandtextset,
            NULL,                                                 -- Fieldname
            pkg_codevalue.cst_midatgrnd_abansta,
            pkg_codevalue.cst_midatgrnd_raison);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_checkboxnotsetandtextset);
      END IF;


      NULL;
   END;



   /*---------------------------------------------------------------*/
   PROCEDURE p_validatepermrenfor (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_recprotocolversion         protocolversion%ROWTYPE;
      l_reccodevalueprotocoltype   codevalue%ROWTYPE;
      l_returnstatusdroite         NUMBER;
      l_returnstatusgauche         NUMBER;
   BEGIN
      l_recprotocolversion :=
         pkg_protocolversion.f_getrecord (p_importprotocolheader.iph_ptv_id);
      l_reccodevalueprotocoltype :=
         pkg_codevalue.f_getrecord (
            l_recprotocolversion.ptv_cvl_id_protocoltype);

      IF l_reccodevalueprotocoltype.cvl_code !=
            pkg_codevalue.cst_protocoltype_ground
      THEN
         RETURN;
      END IF;

      IF l_recprotocolversion.ptv_version !=
            pkg_protocolversion.cst_version_1_0
      THEN
         RETURN;               -- Pas de règle pour les versions autre que 1.0
      END IF;

      p_validatepermrenforgauche (p_importprotocolheader,
                                  p_usr_id,
                                  l_returnstatusgauche);
      p_validatepermrenfordroite (p_importprotocolheader,
                                  p_usr_id,
                                  l_returnstatusdroite);

      IF    l_returnstatusgauche = pkg_constante.cst_returnstatusnotok
         OR l_returnstatusdroite = pkg_constante.cst_returnstatusnotok
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
      ELSE
         p_returnstatus := pkg_constante.cst_returnstatusok;
      END IF;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_validatematamenfondlit (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_recprotocolversion         protocolversion%ROWTYPE;
      l_reccodevalueprotocoltype   codevalue%ROWTYPE;
      l_pmr_id_matamenfond         protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_amenfondlit         protocolmappinggrnd.pmr_id%TYPE;
      l_recimportprotocolgrnd      importprotocolgrnd%ROWTYPE;
      l_nullamenfondsetted         BOOLEAN;
      l_countamenfond              NUMBER;
      l_countmatfond               NUMBER;
      l_fieldname                  importprotocollog.ipo_fieldname%TYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      pkg_debug.p_write ('pkg_validateprotocolgrnd.p_validatematamenfondlit',
                         'start...');

      l_recprotocolversion :=
         pkg_protocolversion.f_getrecord (p_importprotocolheader.iph_ptv_id);
      l_reccodevalueprotocoltype :=
         pkg_codevalue.f_getrecord (
            l_recprotocolversion.ptv_cvl_id_protocoltype);

      IF l_reccodevalueprotocoltype.cvl_code !=
            pkg_codevalue.cst_protocoltype_ground
      THEN
         RETURN;
      END IF;

      pkg_debug.p_write (
         'pkg_validateprotocolgrnd.p_validatematamenfondlit',
            'l_recprotocolversion.ptv_version='
         || l_recprotocolversion.ptv_version);

      IF l_recprotocolversion.ptv_version !=
            pkg_protocolversion.cst_version_1_0
      THEN
         RETURN;               -- Pas de règle pour les versions autre que 1.0
      END IF;

      l_pmr_id_amenfondlit :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_amenfond,
            pkg_codevalue.cst_midatgrnd_ecomorph);

      l_pmr_id_matamenfond :=
         pkg_protocolmappinggrnd.f_getpmridbykeys (
            p_importprotocolheader.iph_ptv_id,
            pkg_codevalue.cst_midatgrnd_matamenfond,
            pkg_codevalue.cst_midatgrnd_ecomorph);
      l_countmatfond :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_matamenfond);
      l_countamenfond :=
         pkg_protocolmappinggrnd.f_countsettedchildren (
            p_importprotocolheader.iph_id,
            l_pmr_id_amenfondlit);


      pkg_debug.p_write ('pkg_validateprotocolgrnd.p_validatematamenfondlit',
                         'l_countmatfond=' || l_countmatfond);

      pkg_debug.p_write ('pkg_validateprotocolgrnd.p_validatematamenfondlit',
                         'l_countamenfond=' || l_countamenfond);

      IF l_countamenfond > 1
      THEN
         -- S'il y a plusieurs case cochées dans le groupe  on sort sans erreur car une erreur est déjà définie
         RETURN;
      END IF;



      l_recimportprotocolgrnd :=
         pkg_importprotocolgrnd.f_getrecordbykeys (
            p_importprotocolheader.iph_id,
            pkg_codevalue.cst_midatgrnd_nul,
            pkg_codevalue.cst_midatgrnd_amenfond,
            pkg_codevalue.cst_midatgrnd_ecomorph);

      l_nullamenfondsetted :=
         UPPER (TRIM (l_recimportprotocolgrnd.ipn_value)) =
            pkg_datatype.cst_checkboxvaluesetted;

      pkg_debug.p_write (
         'pkg_validateprotocolgrnd.p_validatematamenfondlit',
            'l_recimportprotocolgrnd.ipn_value='
         || l_recimportprotocolgrnd.ipn_value);



      IF l_nullamenfondsetted
      THEN
         -- Si La valeur null est saisie dans "Aménagement du fond du lit, aucune des 2 cases de ce groupe ne doit être coché
         IF l_countmatfond > 0
         THEN
            -- La saisie de la valeur "nul" dans la case à cocher "Aménagement du fond du lit" interdit la saisie de valeur dans  une des cases à cocher "Matériau du l'aménagement du fond du lit"
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_matamenagementnotauth,
               l_fieldname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
         END IF;

         RETURN;     -- Nul coché et pas de valeur coché dans le groupe --> OK
      END IF;

      IF l_countamenfond = 0
      THEN
         IF l_countmatfond > 0
         THEN
            -- La rubrique "Matériau de l'aménagement du fond du lit"  ne doit pas être rensiegné si aucune valeur n'a été définie dans la rubrique "Aménagement du fond du lit"
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_amennotsetandmatset,
               l_fieldname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
         END IF;

         -- NUL pas coché  et l_countmatfond = 0
         -- La saisie d'une valeur autre que "nul" dans la case à cocher "Aménagement du fond du lit" nécessite la saisie d'une valeur dans une des case à cocher "Matériau de l'aménagement du fond du lit"
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_matamenagementreq,
            l_fieldname);
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;

      IF l_countamenfond > 0
      THEN
         IF l_countmatfond = 0
         THEN
            -- La rubrique "Matériau de l'aménagement du fond du lit"  doit  être renseigné si une valeur autre que "nul"a été définie dans la rubrique "Aménagement du fond du lit"
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_matamenfondmussbefilled,
               l_fieldname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            RETURN;
         END IF;
      END IF;
   END;



   /*---------------------------------------------------------------*/

   PROCEDURE p_validateadvanced (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_returnstatus   NUMBER;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      p_validatematamenfondlit (p_importprotocolheader,
                                p_usr_id,
                                l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;

      p_validatenaturerive (p_importprotocolheader, p_usr_id, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;

      p_validatepermrenfor (p_importprotocolheader, p_usr_id, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;



      p_validateboue (p_importprotocolheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;

      p_validateturbidite (p_importprotocolheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;

      p_validatecoloration (p_importprotocolheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;

      p_validatemousse (p_importprotocolheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;

      p_validateodeur (p_importprotocolheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;

      p_validatesulfurefer (p_importprotocolheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;

      p_validatecolmatage (p_importprotocolheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;

      p_validatedechets (p_importprotocolheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;

      p_validateorganisme (p_importprotocolheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;

      p_validateinfosup (p_importprotocolheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         p_returnstatus := l_returnstatus;
      END IF;
   END;

   /*--------------------------------------------------------------*/

   PROCEDURE p_logunexpectederror (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_fieldname                 IN importprotocollog.ipo_fieldname%TYPE,
      p_modulename                IN VARCHAR2)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      pkg_importprotocollog.p_writelog (p_recimportprotocolheader.iph_id,
                                        NULL,
                                        pkg_exception.cst_unexpectederror,
                                        p_fieldname,
                                        p_modulename);
   END;


   /* -------------------------------------------------------------------*/

   PROCEDURE p_returncodevalue (
      p_cvl_id                    IN     codevalue.cvl_id%TYPE,
      p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_reccodevalue                 OUT codevalue%ROWTYPE)
   /*--------------------------------------------------------------------*/
   IS
   BEGIN
      p_reccodevalue := pkg_codevalue.f_getrecord (p_cvl_id);

      IF p_reccodevalue.cvl_id IS NULL
      THEN
         p_logunexpectederror (
            p_recimportprotocolheader,
            NULL,
               'p_returncodevalue->pkg_codevalue.f_getrecord('
            || TO_CHAR (p_cvl_id)
            || ')');
      END IF;
   END;



   /*--------------------------------------------------------------*/

   PROCEDURE p_validatemorevaluegroup (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_count                    NUMBER;
      l_string                   VARCHAR2 (4096);
      l_reccodevalue             codevalue%ROWTYPE;

      CURSOR l_cursor
      IS
           SELECT DISTINCT pmr_id, pmr_sortorder, pmr_morevalue
             FROM protocolmappinggrnd
            WHERE     pmr_id IN (SELECT DISTINCT pmr_pmr_id
                                   FROM protocolmappinggrnd
                                  WHERE NOT pmr_pmr_id IS NULL)
                  AND NOT pmr_morevalue IS NULL
                  AND pmr_morevalue IN (pkg_constante.cst_no,
                                        pkg_constante.cst_warning)
         ORDER BY pmr_sortorder;

      l_reccursor                l_cursor%ROWTYPE;
      l_recprotocolmappinggrnd   protocolmappinggrnd%ROWTYPE;
   /* Si le groupe est défini avec morevalue=No, il ne doit pas exister plusieurs entrées
    référencées par PMR_PMR_ID dans importprotocolmapping
   */
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         l_count :=
            f_countmemberofgroup (p_importprotocolheader, l_reccursor.pmr_id);
         pkg_debug.p_write (
            'pkg_validateprotocolground.p_validatemorevaluegroup',
               'Groupe= '
            || l_reccursor.pmr_id
            || ' Nombre élément='
            || l_count);

         IF l_count > 1
         THEN
            l_recprotocolmappinggrnd :=
               pkg_protocolmappinggrnd.f_getrecord (l_reccursor.pmr_id);

            IF l_recprotocolmappinggrnd.pmr_id IS NULL
            THEN
               p_logunexpectederror (
                  p_importprotocolheader,
                  NULL,                                         -- p_fieldname
                     'p_validatemorevaluegroup->pkg_protocolmappinggrnd.f_getrecord ('
                  || TO_CHAR (l_reccursor.pmr_id)
                  || ')');
               p_returnstatus := pkg_constante.cst_returnstatusnotok;
               RETURN;
            END IF;

            l_reccodevalue :=
               pkg_codevalue.f_getrecord (
                  l_recprotocolmappinggrnd.pmr_cvl_id_midatgrnd);

            IF l_reccodevalue.cvl_id IS NULL
            THEN
               p_logunexpectederror (
                  p_importprotocolheader,
                  NULL,                                         -- p_fieldname
                     'p_validatemorevaluegroup->pkg_codevalue.f_getrecord ('
                  || TO_CHAR (l_recprotocolmappinggrnd.pmr_cvl_id_midatgrnd)
                  || ')');
               p_returnstatus := pkg_constante.cst_returnstatusnotok;
               RETURN;
            END IF;

            l_string :=
               pkg_protocolmappinggrnd.f_returnfullpath (l_reccursor.pmr_id);

            IF l_reccursor.pmr_morevalue = pkg_constante.cst_no
            THEN
               pkg_importprotocollog.p_writelog (
                  p_importprotocolheader.iph_id,
                  NULL,
                  pkg_exception.cst_morevalueingroup,
                  l_reccodevalue.cvl_code,
                  l_string);
               p_returnstatus := pkg_constante.cst_returnstatusnotok;
            END IF;

            IF l_reccursor.pmr_morevalue = pkg_constante.cst_warning
            THEN
               pkg_importprotocollog.p_writelog (
                  p_importprotocolheader.iph_id,
                  NULL,
                  pkg_exception.cst_morevalueingroupwarning,
                  l_reccodevalue.cvl_code,
                  l_string);
               p_returnstatus := pkg_constante.cst_returnstatusnotok;
            END IF;
         END IF;
      END LOOP;

      CLOSE l_cursor;
   END;

   /*--------------------------------------------------------------*/

   PROCEDURE p_validateisnotnullgroup (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_count                    NUMBER;
      l_string                   VARCHAR2 (4096);
      l_reccodevalue             codevalue%ROWTYPE;

      CURSOR l_cursor
      IS
           SELECT pmr_id, pmr_isnotnull
             FROM protocolmappinggrnd
            WHERE     pmr_id IN (SELECT DISTINCT pmr_pmr_id
                                   FROM protocolmappinggrnd
                                  WHERE NOT pmr_pmr_id IS NULL)
                  AND NOT pmr_morevalue IS NULL
                  AND NVL (pmr_isnotnull, pkg_constante.cst_no) IN (pkg_constante.cst_yes,
                                                                    pkg_constante.cst_warning)
         ORDER BY pmr_sortorder;



      l_reccursor                l_cursor%ROWTYPE;
      l_recprotocolmappinggrnd   protocolmappinggrnd%ROWTYPE;
   /* Si le groupe est défini avec isnotnull=Yes ou  isnotnull=Warning, il doit exister au moins une entrée
   */
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         l_count :=
            f_countmemberofgroup (p_importprotocolheader, l_reccursor.pmr_id);
         pkg_debug.p_write (
            'pkg_validateprotocolground.p_validateisnotnullgroup',
               'Groupe= '
            || l_reccursor.pmr_id
            || ' Nombre élément='
            || l_count);

         IF l_count = 0
         THEN
            l_recprotocolmappinggrnd :=
               pkg_protocolmappinggrnd.f_getrecord (l_reccursor.pmr_id);

            IF l_recprotocolmappinggrnd.pmr_id IS NULL
            THEN
               p_logunexpectederror (
                  p_importprotocolheader,
                  NULL,                                         -- p_fieldname
                     'p_validatemorevaluegroup->pkg_protocolmappinggrnd.f_getrecord ('
                  || TO_CHAR (l_reccursor.pmr_id)
                  || ')');
               p_returnstatus := pkg_constante.cst_returnstatusnotok;
               RETURN;
            END IF;

            l_reccodevalue :=
               pkg_codevalue.f_getrecord (
                  l_recprotocolmappinggrnd.pmr_cvl_id_midatgrnd);

            IF l_reccodevalue.cvl_id IS NULL
            THEN
               p_logunexpectederror (
                  p_importprotocolheader,
                  NULL,                                         -- p_fieldname
                     'p_validatemorevaluegroup->pkg_codevalue.f_getrecord ('
                  || TO_CHAR (l_recprotocolmappinggrnd.pmr_cvl_id_midatgrnd)
                  || ')');
               p_returnstatus := pkg_constante.cst_returnstatusnotok;
               RETURN;
            END IF;

            l_string :=
               pkg_protocolmappinggrnd.f_returnfullpath (l_reccursor.pmr_id);

            IF l_recprotocolmappinggrnd.pmr_isnotnull = pkg_constante.cst_yes
            THEN
               pkg_importprotocollog.p_writelog (
                  p_importprotocolheader.iph_id,
                  NULL,
                  pkg_exception.cst_isnotnullgroup,
                  l_reccodevalue.cvl_code,
                  l_string);
            ELSIF l_recprotocolmappinggrnd.pmr_isnotnull =
                     pkg_constante.cst_warning
            THEN
               pkg_importprotocollog.p_writelog (
                  p_importprotocolheader.iph_id,
                  NULL,
                  pkg_exception.cst_isnotnullgroupwarning,
                  l_reccodevalue.cvl_code,
                  l_string);
            END IF;

            p_returnstatus := pkg_constante.cst_returnstatusnotok;
         END IF;
      END LOOP;

      CLOSE l_cursor;
   END;

   /*--------------------------------------------------------------*/

   PROCEDURE p_validateonevalue (
      p_importprotocolgrnd     IN     importprotocolgrnd%ROWTYPE,
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_recprotocolmappinggrnd   protocolmappinggrnd%ROWTYPE;
      l_reccodevalue             codevalue%ROWTYPE;
      l_string                   VARCHAR2 (4096);
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;


      l_recprotocolmappinggrnd :=
         pkg_protocolmappinggrnd.f_getrecord (
            p_importprotocolgrnd.ipn_pmr_id);

      IF l_recprotocolmappinggrnd.pmr_id IS NULL
      THEN
         p_logunexpectederror (
            p_importprotocolheader,
            NULL,                                               -- p_fieldname
               'p_validateonevalue->pkg_protocolmappinggrnd.f_getrecord ('
            || TO_CHAR (p_importprotocolgrnd.ipn_pmr_id)
            || ')');
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;

      l_reccodevalue :=
         pkg_codevalue.f_getrecord (
            l_recprotocolmappinggrnd.pmr_cvl_id_datatype);
      pkg_debug.p_write (
         'PKG_VALIDATEPROTOCOLGROUND.p_validateonevalue',
            ' Value='
         || p_importprotocolgrnd.ipn_value
         || ' Datatype='
         || l_reccodevalue.cvl_code);



      IF l_reccodevalue.cvl_id IS NULL
      THEN
         p_logunexpectederror (
            p_importprotocolheader,
            NULL,                                               -- p_fieldname
               'p_validateonevalue->pkg_codevalue.f_getrecord ('
            || TO_CHAR (l_recprotocolmappinggrnd.pmr_cvl_id_datatype)
            || ')');
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;

      IF p_importprotocolgrnd.ipn_value IS NULL
      THEN
         RETURN;
      END IF;

      IF NOT pkg_datatype.f_checkdatatype (p_importprotocolgrnd.ipn_value,
                                           l_reccodevalue.cvl_code)
      THEN
         l_string :=
            pkg_protocolmappinggrnd.f_returnfullpath (
               p_importprotocolgrnd.ipn_pmr_id);

         pkg_importprotocollog.p_writelog (p_importprotocolheader.iph_id,
                                           NULL,
                                           pkg_exception.cst_invaliddatatype,
                                           l_string,
                                           p_importprotocolgrnd.ipn_value,
                                           l_string,
                                           l_reccodevalue.cvl_code);
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
      END IF;

      NULL;
   END;

   /*------------------------------------------------------------------------*/

   FUNCTION f_preservebadstatus (p_currentstatus   IN NUMBER,
                                 p_oldstatus          NUMBER)
      RETURN NUMBER
   /*-----------------------------------------------------------------------*/
   IS
   BEGIN
      IF p_currentstatus != pkg_constante.cst_returnstatusok
      THEN
         RETURN p_currentstatus;
      ELSE
         RETURN p_oldstatus;
      END IF;
   END;

   /*--------------------------------------------------------------*/

   PROCEDURE p_validatevalues (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      CURSOR l_cursor
      IS
         SELECT *
           FROM importprotocolgrnd
          WHERE ipn_iph_id = p_importprotocolheader.iph_id;


      l_reccursor      l_cursor%ROWTYPE;
      l_returnstatus   NUMBER;
      l_savestatus     NUMBER;
   BEGIN
      l_savestatus := pkg_constante.cst_returnstatusok;

      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         p_validateonevalue (l_reccursor,
                             p_importprotocolheader,
                             p_usr_id,
                             l_returnstatus);
         l_savestatus := f_preservebadstatus (l_returnstatus, l_savestatus);
      END LOOP;

      p_returnstatus := l_savestatus;
   END;

   /*---------------------------------------------------------------*/

   PROCEDURE p_test
   /*---------------------------------------------------------------*/
   IS
      l_importprotocolheader   importprotocolheader%ROWTYPE;
      l_usr_id                 importprotocolheader.iph_usr_id_modify%TYPE;
      l_returnstatus           NUMBER;
   BEGIN
      DELETE FROM importprotocollogparam
            WHERE ipr_ipo_id IN (SELECT ipo_id
                                   FROM importprotocollog
                                  WHERE ipo_iph_id = 336);

      DELETE FROM importprotocollog
            WHERE ipo_iph_id = 336;

      COMMIT;

      l_importprotocolheader := pkg_importprotocolheader.f_getrecord (336);
      p_validatedetail (l_importprotocolheader, l_usr_id, l_returnstatus);
   END;



   /*--------------------------------------------------------------*/

   PROCEDURE p_validatedetail (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_returnstatus   NUMBER;
      l_savestatus     NUMBER;
   BEGIN
      l_savestatus := pkg_constante.cst_returnstatusok;
      p_validateisnotnullgroup (p_importprotocolheader,
                                p_usr_id,
                                l_returnstatus);
      DBMS_OUTPUT.put_line ('null group status=' || l_returnstatus);
      l_savestatus := l_returnstatus;
      p_validatemorevaluegroup (p_importprotocolheader,
                                p_usr_id,
                                l_returnstatus);
      DBMS_OUTPUT.put_line ('more group status=' || l_returnstatus);
      l_savestatus := f_preservebadstatus (l_returnstatus, l_savestatus);
      p_validatevalues (p_importprotocolheader, p_usr_id, l_returnstatus);
      DBMS_OUTPUT.put_line ('validatevalues status=' || l_returnstatus);
      l_savestatus := f_preservebadstatus (l_returnstatus, l_savestatus);

      p_validateadvanced (p_importprotocolheader, p_usr_id, l_returnstatus);
      l_savestatus := f_preservebadstatus (l_returnstatus, l_savestatus);
      p_returnstatus := l_savestatus;
   END;
END pkg_validateprotocolground;
/

