create PACKAGE       pkg_sampleprotocolgrnd
AS
   /******************************************************************************
      NAME:       pkg_pkg_sampleprotocolgrnd
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.10.2013   F.Burri          1. Created this package.
   ******************************************************************************/

   cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2013';

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_deleteby_sph_id (
      p_sph_id IN sampleprotocolgrnd.spd_sph_id%TYPE);

    PROCEDURE p_write (
      p_sph_id          IN     sampleprotocolgrnd.spd_sph_id%TYPE,
      p_pmr_id          IN     sampleprotocolgrnd.spd_pmr_id%TYPE,
      p_value           IN     sampleprotocolgrnd.spd_value%TYPE,
      p_usr_id_create   IN     sampleprotocolgrnd.spd_usr_id_create%TYPE,
      p_spd_id             OUT sampleprotocolgrnd.spd_id%TYPE);
END pkg_sampleprotocolgrnd;
/

