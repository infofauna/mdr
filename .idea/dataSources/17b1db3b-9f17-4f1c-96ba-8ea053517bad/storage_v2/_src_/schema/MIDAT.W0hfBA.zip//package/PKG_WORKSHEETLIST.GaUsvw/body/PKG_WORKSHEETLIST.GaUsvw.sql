create PACKAGE BODY       pkg_worksheetlist
AS
   /******************************************************************************
      NAME:       PKG_WORKSHEETLIST
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, octobre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_purge
   /*--------------------------------------------------------------*/
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      DELETE FROM worksheetlist
            WHERE wsl_credate <= SYSDATE - 1 / 24;

      COMMIT;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_getrecord (p_wsl_id IN worksheetlist.wsl_id%TYPE)
      RETURN worksheetlist%ROWTYPE
   /*-------------------------------------------------------------*/
   IS
      l_record   worksheetlist%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM worksheetlist
       WHERE wsl_id = p_wsl_id;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-----------------------------------------------------------------------------*/
   FUNCTION f_getnewworksheetgroupid
      RETURN NUMBER
   /*----------------------------------------------------------------------------*/
   IS
   BEGIN
      RETURN seq_worksheetgroup.NEXTVAL;
   END;


   /*----------------------------------------------------------------------------*/
   PROCEDURE p_insert (
      p_worksheetgroup_id   IN worksheetlist.wsl_worksheetgroup_id%TYPE,
      p_sheetname           IN worksheetlist.wsl_sheetname%TYPE,
      p_sheetnumber         IN worksheetlist.wsl_sheetnumber%TYPE)
   /*---------------------------------------------------------------------------*/
   IS
   BEGIN
      INSERT
        INTO worksheetlist (wsl_worksheetgroup_id,
                            wsl_sheetname,
                            wsl_sheetnumber)
      VALUES (p_worksheetgroup_id, p_sheetname, p_sheetnumber);
   END;

   /*---------------------------------------------------------------------*/
   PROCEDURE p_listsheetname (
      p_worksheetgroup_id   IN     worksheetlist.wsl_worksheetgroup_id%TYPE,
      p_sheetlist              OUT t_cursor,
      p_sheetcount             OUT NUMBER)
   /*----------------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (1024);
   BEGIN
      l_sql :=
            'SELECT wsl_sheetnumber, wsl_sheetname FROM worksheetlist WHERE wsl_worksheetgroup_id = '
         || TO_CHAR (p_worksheetgroup_id)
         || ' ORDER BY WSL_SHEETNUMBER';

      SELECT COUNT (*)
        INTO p_sheetcount
        FROM worksheetlist
       WHERE wsl_worksheetgroup_id = p_worksheetgroup_id;

      OPEN p_sheetlist FOR l_sql;
   END;
END pkg_worksheetlist;
/

