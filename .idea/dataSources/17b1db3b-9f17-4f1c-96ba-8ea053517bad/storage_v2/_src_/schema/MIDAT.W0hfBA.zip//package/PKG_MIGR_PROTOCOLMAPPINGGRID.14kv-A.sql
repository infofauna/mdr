create PACKAGE       pkg_migr_protocolmappinggrid
AS
   /******************************************************************************
      NAME:       pkg_migr_protocolmappinggrid
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_buildbycvlcode (
      p_ptv_id   IN protocolmappinggrid.pmg_ptv_id%TYPE); -- A utilisé pour mettre à jour les CVL_ID à partir des CODE_ID

   PROCEDURE p_buildgrid (p_ptv_id IN protocolmappinggrid.pmg_ptv_id%TYPE); -- A utilisé pour remplir une première fois la tables (1)

   PROCEDURE p_buildcell (p_ptv_id IN protocolmappinggrid.pmg_ptv_id%TYPE); -- A utlisé la première fois pour insérer les éléments non en colonne (2)

   PROCEDURE p_complete (p_ptv_id IN protocolmappinggrid.pmg_ptv_id%TYPE);
END pkg_migr_protocolmappinggrid;
/

