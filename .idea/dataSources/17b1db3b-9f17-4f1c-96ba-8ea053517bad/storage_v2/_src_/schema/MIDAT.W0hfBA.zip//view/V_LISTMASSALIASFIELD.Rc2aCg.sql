create view V_LISTMASSALIASFIELD as
SELECT cvl_code, cdn_designation, pma_aliascolumnname, pmm_isnotnull, pmm_isnotnullgroup
  FROM protocolmappingmassfield
       INNER JOIN codevalue ON cvl_code = pmm_code_midatfldcmt
       INNER JOIN protocolmappingmassmap on pmm_id=pma_pmm_id
       INNER JOIN codereference ON cvl_crf_id=crf_id
       INNER JOIN codedesignation ON cdn_cvl_id = cvl_id
       WHERE CDN_LAN_ID=1
       AND CRF_ID=53
       ORDER BY pmm_isnotnull
/

