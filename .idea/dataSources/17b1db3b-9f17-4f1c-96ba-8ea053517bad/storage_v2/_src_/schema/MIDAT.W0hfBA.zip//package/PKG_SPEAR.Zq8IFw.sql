create PACKAGE       pkg_spear
AS
    /******************************************************************************
       NAME:       PKG_SPEAR
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        08.07.2015      burrif       1. Created this package.
       1.1        02.10.2017      burrif       2. Version 2
    ******************************************************************************/
    TYPE t_spearvalue IS RECORD
    (
        spr_syv_id              speardatalinkcscf.sdf_syv_id%TYPE,
        spr_spearindexfactor    NUMBER,
        spr_counter             NUMBER
    );

    TYPE t_listspearvalue IS TABLE OF t_spearvalue;

    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_getgblidentifiedtaxoncount
        RETURN NUMBER;

    PROCEDURE p_maincompute (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN     importmassdataheader%ROWTYPE, -- NULL si le type de protocol n'est pas MASS
        p_spearindice                  OUT NUMBER);

    PROCEDURE p_spearinit;

    PROCEDURE p_spearadddata (
        p_syv_id    IN     speardatalinkcscf.sdf_syv_id%TYPE,
        p_counter   IN     NUMBER,
        p_ptv_id    IN     protocolversion.ptv_id%TYPE,
        p_status       OUT NUMBER);

    FUNCTION f_computespearfrommemory (p_abondanceflag IN VARCHAR2)
        RETURN NUMBER;
END;
/

