create trigger TR_BUF_SWISSTOPODATA
    before update
    on SWISSTOPODATA
    for each row
DECLARE
BEGIN
  

   :new.SWD_moddate := SYSDATE;
   :new.SWD_moduser := USER;
END tr_buf_SWISSTOPODATA;

/

