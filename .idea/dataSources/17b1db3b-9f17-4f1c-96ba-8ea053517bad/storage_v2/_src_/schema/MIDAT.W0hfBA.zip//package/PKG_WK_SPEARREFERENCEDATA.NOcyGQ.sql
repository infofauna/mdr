create PACKAGE       pkg_wk_spearreferencedata
AS
   /******************************************************************************
      NAME:       PKG_WK_SPEARREFERENCEDATA
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        22/08/2017      burrif       1. Created this package.
   ******************************************************************************/

   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecord (p_id IN wk_spearreferencedata.wrd_id%TYPE)
      RETURN wk_spearreferencedata%ROWTYPE;
END pkg_wk_spearreferencedata;
/

