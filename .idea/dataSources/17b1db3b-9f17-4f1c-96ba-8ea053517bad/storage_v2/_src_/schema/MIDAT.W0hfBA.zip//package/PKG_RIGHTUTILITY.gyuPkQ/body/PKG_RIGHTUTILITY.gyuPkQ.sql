create PACKAGE BODY       pkg_rightutility
AS
   /******************************************************************************
      NAME:       pkg_rightutility
      PURPOSE:


      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        26.02.2015     burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, février 2015' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*------------------------------------------------------------*/
   FUNCTION f_buillistcodetxt (p_listcode IN pkg_ch_canton.t_listcode)
      RETURN VARCHAR2
   /*------------------------------------------------------------*/
   IS
      l_key    VARCHAR2 (30);
      l_text   VARCHAR2 (1024);
   BEGIN
      l_key := p_listcode.FIRST;

      WHILE NOT l_key IS NULL
      LOOP
         IF l_text IS NULL
         THEN
            l_text := l_key;
         ELSE
            l_text := l_text || ', ' || l_key;
         END IF;

         l_key := p_listcode.NEXT (l_key);
      END LOOP;

      RETURN l_text;
   END;

   /*------------------------------------------------------------*/
   FUNCTION f_buillistgrouptxt (p_listgroup IN pkg_admin_group.t_listgroup)
      RETURN VARCHAR2
   /*------------------------------------------------------------*/
   IS
      l_indice   PLS_INTEGER;
      l_text     VARCHAR2 (1024);
   BEGIN
      l_indice := p_listgroup.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         IF l_text IS NULL
         THEN
            l_text := p_listgroup (l_indice);
         ELSE
            l_text := l_text || ', ' || p_listgroup (l_indice);
         END IF;

         l_indice := p_listgroup.NEXT (l_indice);
      END LOOP;

      RETURN l_text;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_checkinrolelist (p_rolelist   IN pkg_admin_role.t_listrole,
                               p_role       IN VARCHAR2)
      RETURN BOOLEAN
   /*-------------------------------------------------------------*/
   IS
      l_indice   PLS_INTEGER;
      l_found    BOOLEAN := FALSE;
   BEGIN
      l_found := FALSE;
      l_indice := p_rolelist.FIRST;

      WHILE NOT l_indice IS NULL AND NOT l_found
      LOOP
         IF p_rolelist (l_indice) = p_role
         THEN
            l_found := TRUE;
         END IF;

         l_indice := p_rolelist.NEXT (l_indice);
      END LOOP;

      RETURN l_found;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_checkmatchinggroup (
      p_listgroup   IN pkg_admin_group.t_listgroup,
      p_listcode    IN pkg_ch_canton.t_listcode)
      RETURN BOOLEAN
   /*---------------------------------------------------------------*/
   IS
      /* On compare la liste des GROUPES associé aux droits de l'utilisateur et celle des GROUP associé à la coordonnées */
      l_indice   PLS_INTEGER;
      l_found    BOOLEAN;
   BEGIN
      l_found := FALSE;
      l_indice := p_listgroup.FIRST;

      WHILE NOT l_indice IS NULL AND NOT l_found
      LOOP
         IF p_listcode.EXISTS (p_listgroup (l_indice))
         THEN
            l_found := TRUE;
         END IF;

         l_indice := p_listgroup.NEXT (l_indice);
      END LOOP;

      RETURN l_found;
   END;



   /*---------------------------------------------------------------*/
   PROCEDURE p_checkwriteright (
      p_x             IN     NUMBER,
      p_y             IN     NUMBER,
      p_usr_id        IN     sampleheader.sph_usr_id_create%TYPE,
      p_rightaccess      OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      /*
      1) Le point est dans quel canton
      2) est ce que l'utilisateur est administateur de ce canton
      3) Est -ce que ce point est à moins de 3 km du canton ou la personne administre
     */
      l_coordinates          SDO_GEOMETRY;
      l_recch_canton         ch_canton%ROWTYPE;
      l_listcode             pkg_ch_canton.t_listcode;
      l_listrole             pkg_admin_role.t_listrole;
      l_listgroup            pkg_admin_group.t_listgroup;
      l_contributorfound     BOOLEAN;
      l_nationalwritefound   BOOLEAN;
      l_groupfound           BOOLEAN;
   BEGIN
      -- Est-ce que l'utilisateur dispose du droit NATIONALREAD
      l_listrole := pkg_admin_role.f_returnlistrole (p_usr_id);

      l_nationalwritefound :=
         f_checkinrolelist (l_listrole,
                            pkg_admin_role.cst_admin_role_nationalwrite);

      IF l_nationalwritefound
      THEN                             -- Dispose du droit d'écriture National
         p_rightaccess := pkg_rightutility.cst_rightaccessok;
         RETURN;
      END IF;

      l_contributorfound :=
         f_checkinrolelist (l_listrole,
                            pkg_admin_role.cst_admin_role_contributor);

      IF NOT l_contributorfound
      THEN    -- N'a pas le role contributor. N'a donc pas de droit d'écriture
         p_rightaccess := pkg_rightutility.cst_rightaccessdenied;
         RETURN;
      END IF;

      -- Peut écrire mais dans quel canton
      l_listgroup := pkg_admin_group.f_returnlistgroup (p_usr_id);

      l_coordinates := pkg_sdoutil.f_buildsdo_geometry (p_x, p_y);
      l_listcode :=
         pkg_ch_canton.f_returncantonnearbuffer (
            l_coordinates,
            pkg_codevalue.f_get_midatparam_rayoncnt);
      l_groupfound := f_checkmatchinggroup (l_listgroup, l_listcode);

      IF l_groupfound
      THEN
         p_rightaccess := pkg_rightutility.cst_rightaccessok;
      ELSE
         p_rightaccess := pkg_rightutility.cst_rightaccessdenied;
      END IF;

      NULL;
   END;

   /*------------------------------------------------------------*/
   FUNCTION f_returngrouprightlist (
      p_usr_id   IN sampleheader.sph_usr_id_create%TYPE)
      RETURN VARCHAR2
   /*-------------------------------------------------------------*/
   IS
      l_grouplist            VARCHAR2 (1024);
      l_listrole             pkg_admin_role.t_listrole;
      l_listgroup            pkg_admin_group.t_listgroup;
      l_listcode             pkg_ch_canton.t_listcode;
      l_contributorfound     BOOLEAN;
      l_nationalwritefound   BOOLEAN;
      l_groupfound           BOOLEAN;
   BEGIN
      -- Est-ce que l'utilisateur dispose du droit


      l_listrole := pkg_admin_role.f_returnlistrole (p_usr_id);

      l_nationalwritefound :=
         f_checkinrolelist (l_listrole,
                            pkg_admin_role.cst_admin_role_nationalwrite);

      IF l_nationalwritefound
      THEN                             -- Dispose du droit d'écriture National
         -- On charge la liste des cantons suisses
         l_listcode := pkg_ch_canton.f_returnalllistcodecanton;
         l_grouplist := f_buillistcodetxt (l_listcode);
         RETURN l_grouplist;
      END IF;

      l_contributorfound :=
         f_checkinrolelist (l_listrole,
                            pkg_admin_role.cst_admin_role_contributor);

      IF NOT l_contributorfound
      THEN    -- N'a pas le role contributor. N'a donc pas de droit d'écriture
         l_grouplist := '----------';
         RETURN l_grouplist;
      END IF;



      l_listgroup := pkg_admin_group.f_returnlistgroup (p_usr_id);
      l_grouplist := f_buillistgrouptxt (l_listgroup);
      RETURN l_grouplist;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_test
   /*--------------------------------------------------------------*/
   IS
      l_reponse   NUMBER;
   BEGIN
      p_checkwriteright (559038,
                         213081,
                         3,
                         l_reponse);
      DBMS_OUTPUT.put_line ('L-reponse:=' || l_reponse);
   END;
END pkg_rightutility;
/

