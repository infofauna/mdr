create PACKAGE       pkg_migr_protocolmappinggrnd
AS
   /******************************************************************************
      NAME:       pkg_migr_protocolmappinggrnd
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
     1.1        06.11.2013      burrif       2. Modification de la structure dans la rubrique végétation
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_build (p_ptv_id IN protocolmappinggrnd.pmr_ptv_id%TYPE);
END pkg_migr_protocolmappinggrnd;
/

