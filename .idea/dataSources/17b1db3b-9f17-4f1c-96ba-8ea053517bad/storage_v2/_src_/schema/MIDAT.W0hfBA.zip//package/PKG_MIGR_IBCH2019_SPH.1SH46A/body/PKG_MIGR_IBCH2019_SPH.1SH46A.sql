create PACKAGE BODY       pkg_migr_ibch2019_sph
AS
    /******************************************************************************
       NAME:       PKG_MIGR_IBCH2019_iph
       PURPOSE:    Modification dans la table SAMPLEHEADER

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       15.05.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;


    /*--------------------------------------------------------------*/
    PROCEDURE p_add_sph_columns
    /*--------------------------------------------------------------*/
    IS
        l_done   BOOLEAN;
    BEGIN
        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_IVR_ID_SPEAR',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_IVR_ID_MAKROINDEX',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_autreneoz_1,
            'VARCHAR2(120)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_autreneoz_2,
            'VARCHAR2(120)',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_sommeept,
            'NUMBER',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_sommeneoz,
            'NUMBER',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_sommeabon,
            'NUMBER',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_sommetxobs,
            'NUMBER',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_sommetxcor,
            'NUMBER',
            NULL,
            l_done);

        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_valeurvt,
            'NUMBER',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_valeurgi,
            'NUMBER',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_valeurgimax,
            'NUMBER',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_ibchq,
            'NUMBER',
            NULL,
            l_done);
        pkg_migr_ibch2019_util.p_addcolumn (
            'SAMPLEHEADER',
            'SPH_' || pkg_codevalue.cst_midathditem_vc,
            'NUMBER',
            NULL,
            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_TAXONINDICATEUR',
                                            'VARCHAR2(1024 CHAR)',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_IBCHROBUST',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_CLASSEVARIETE',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_CLASSEVARIETE_CORR',
                                            'NUMBER',
                                            NULL,
                                            l_done);


        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_CLASSEVARIETEROBUST',
                                            'NUMBER',
                                            NULL,
                                            l_done);


        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_CLASSEVARIETEROBUST_CORR',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_CLASSEVARIETE_FINAL',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_CLASSEVARIETEROBUST_FINAL',
                                            'NUMBER',
                                            NULL,
                                            l_done);



        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_TAXONFREQUENCESUM',
                                            'NUMBER',
                                            NULL,
                                            l_done);


        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_GIMAX',
                                            'NUMBER',
                                            NULL,
                                            l_done);


        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_GIMAXROBUST',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_GI_FINAL',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_GIROBUST_FINAL',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_SUMFAMILY',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_SUMFAMILYCORRECTED',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_SUMFAMILYROBUST',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_SUMFAMILYROBUSTCORRECTED',
                                            'NUMBER',
                                            NULL,
                                            l_done);



        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_EPHEMEROPTERACOUNTER',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_PLECOPTERACOUNTER',
                                            'NUMBER',
                                            NULL,
                                            l_done);
        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_TRICOPTERACOUNTER',
                                            'NUMBER',
                                            NULL,
                                            l_done);

        pkg_migr_ibch2019_util.p_addcolumn ('SAMPLEHEADER',
                                            'SPH_IVR_ID_IBCH',
                                            'NUMBER',
                                            NULL,
                                            l_done);
    END;
END pkg_migr_ibch2019_sph;
/

