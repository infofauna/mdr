create PACKAGE BODY       pkg_indicehistory
AS
    /******************************************************************************
       NAME:       PKG_INDICEHISTORY
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        06.10.2017      burrif       1. Created this package.
    ******************************************************************************/



    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.0, octobre 2017' ;


    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_getrecord (p_ihy_id IN indicehistory.ihy_id%TYPE)
        RETURN indicehistory%ROWTYPE
    /*----------------------------------------------------------*/
    IS
        l_recindicehistory   indicehistory%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recindicehistory
          FROM indicehistory
         WHERE ihy_id = p_ihy_id;

        RETURN l_recindicehistory;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_getrecordby_ivr_ibch (
        p_sph_id     IN indicehistory.ihy_sph_id%TYPE,
        p_ivr_ibch   IN indicehistory.ihy_ivr_id_ibch%TYPE)
        RETURN indicehistory%ROWTYPE
    /*----------------------------------------------------------*/
    IS
        l_recindicehistory   indicehistory%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recindicehistory
          FROM indicehistory
         WHERE ihy_sph_id = p_sph_id AND ihy_ivr_id_ibch = p_ivr_ibch;

        RETURN l_recindicehistory;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_getrecordby_ivr_spear (
        p_sph_id      IN indicehistory.ihy_sph_id%TYPE,
        p_ivr_spear   IN indicehistory.ihy_ivr_id_spear%TYPE)
        RETURN indicehistory%ROWTYPE
    /*----------------------------------------------------------*/
    IS
        l_recindicehistory   indicehistory%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recindicehistory
          FROM indicehistory
         WHERE ihy_sph_id = p_sph_id AND ihy_ivr_id_ibch = p_ivr_spear;

        RETURN l_recindicehistory;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*------------------------------------------------------------*/
    FUNCTION f_getrecordbykeys (
        p_sph_id         IN indicehistory.ihy_sph_id%TYPE,
        p_ivr_id_ibch    IN indicehistory.ihy_ivr_id_ibch%TYPE,
        p_ivr_id_spear   IN indicehistory.ihy_ivr_id_spear%TYPE)
        RETURN indicehistory%ROWTYPE
    /*------------------------------------------------------------*/
    IS
        l_recindicehistory   indicehistory%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recindicehistory
          FROM indicehistory
         WHERE     ihy_sph_id = p_sph_id
               AND NVL (ihy_ivr_id_ibch, 0) = NVL (p_ivr_id_ibch, 0)
               AND NVL (ihy_ivr_id_spear, 0) = NVL (p_ivr_id_spear, 0);

        RETURN l_recindicehistory;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_getsequence (p_sph_id IN indicehistory.ihy_sequence%TYPE)
        RETURN NUMBER
    /*-----------------------------------------------------------*/
    IS
        l_sequence   indicehistory.ihy_sequence%TYPE;
    BEGIN
        SELECT MAX (ihy_sequence)
          INTO l_sequence
          FROM indicehistory
         WHERE ihy_sph_id = p_sph_id;

        RETURN l_sequence;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN 0;
    END;

    /*----------------------------------------------------------*/
    PROCEDURE p_updatesequence (p_sph_id IN indicehistory.ihy_sph_id%TYPE)
    /*----------------------------------------------------------*/
    IS
    BEGIN
        UPDATE indicehistory
           SET ihy_sequence = ihy_sequence - 1
         WHERE ihy_sph_id = p_sph_id;
    END;



    /*-----------------------------------------------------------*/
    PROCEDURE p_append (
        p_sph_id                      IN     indicehistory.ihy_sph_id%TYPE,
        p_ivr_id_ibch                 IN     indicehistory.ihy_ivr_id_ibch%TYPE,
        p_ivr_id_spear                IN     indicehistory.ihy_ivr_id_spear%TYPE,
        p_sequence                    IN     indicehistory.ihy_sequence%TYPE,
        p_taxonindicateur             IN     indicehistory.ihy_taxonindicateur%TYPE,
        p_ibchrobust                  IN     indicehistory.ihy_ibchrobust%TYPE,
        p_indexvalueibch              IN     indicehistory.ihy_indexvalueibch%TYPE,
        p_classevariete               IN     indicehistory.ihy_classevariete%TYPE,
        p_classevariete_corr          IN     indicehistory.ihy_classevariete_corr%TYPE,
        p_classevarieterobust         IN     indicehistory.ihy_classevarieterobust%TYPE,
        p_classevarieterobust_corr    IN     indicehistory.ihy_classevarieterobust_corr%TYPE,
        p_classevariete_final         IN     indicehistory.ihy_classevariete_final%TYPE,
        p_classevarieterobust_final   IN     indicehistory.ihy_classevarieterobust_final%TYPE,
        p_gimax                       IN     indicehistory.ihy_gimax%TYPE,
        p_gimaxrobust                 IN     indicehistory.ihy_gimaxrobust%TYPE,
        p_gi_final                    IN     indicehistory.ihy_gi_final%TYPE,
        p_girobust_final              IN     indicehistory.ihy_girobust_final%TYPE,
        p_sumfamily                   IN     indicehistory.ihy_sumfamily%TYPE,
        p_sumfamilycorrected          IN     indicehistory.ihy_sumfamilycorrected%TYPE,
        p_sumfamilyrobust             IN     indicehistory.ihy_sumfamilyrobust%TYPE,
        p_sumfamilyrobustcorrected    IN     indicehistory.ihy_sumfamilyrobustcorrected%TYPE,
        p_ephemeropteracounter        IN     indicehistory.ihy_ephemeropteracounter%TYPE,
        p_plecopteracounter           IN     indicehistory.ihy_plecopteracounter%TYPE,
        p_tricopteracounter           IN     indicehistory.ihy_tricopteracounter%TYPE,
        p_spearvalue                  IN     indicehistory.ihy_spearvalue%TYPE,
        p_ihy_id                         OUT indicehistory.ihy_id%TYPE)
    /*----------------------------------------------------------------------------*/
    IS
        l_recindicehistory   indicehistory%ROWTYPE;
        l_sequence           indicehistory.ihy_sequence%TYPE;
    BEGIN
        l_recindicehistory :=
            f_getrecordbykeys (p_sph_id, p_ivr_id_ibch, p_ivr_id_spear);

        IF NOT l_recindicehistory.ihy_id IS NULL
        THEN
            RETURN;
        END IF;

        p_updatesequence (p_sph_id);
        l_sequence := -1;

        p_ihy_id := seq_indicehistory.NEXTVAL;

        INSERT INTO indicehistory (ihy_id,
                                   ihy_sph_id,
                                   ihy_ivr_id_ibch,
                                   ihy_ivr_id_spear,
                                   ihy_sequence,
                                   ihy_taxonindicateur,
                                   ihy_ibchrobust,
                                   ihy_indexvalueibch,
                                   ihy_classevariete,
                                   ihy_classevariete_corr,
                                   ihy_classevarieterobust,
                                   ihy_classevarieterobust_corr,
                                   ihy_classevariete_final,
                                   ihy_classevarieterobust_final,
                                   ihy_gimax,
                                   ihy_gimaxrobust,
                                   ihy_gi_final,
                                   ihy_girobust_final,
                                   ihy_sumfamily,
                                   ihy_sumfamilycorrected,
                                   ihy_sumfamilyrobust,
                                   ihy_sumfamilyrobustcorrected,
                                   ihy_ephemeropteracounter,
                                   ihy_plecopteracounter,
                                   ihy_tricopteracounter,
                                   ihy_spearvalue)
             VALUES (p_ihy_id,
                     p_sph_id,
                     p_ivr_id_ibch,
                     p_ivr_id_spear,
                     p_sequence,
                     p_taxonindicateur,
                     p_ibchrobust,
                     p_indexvalueibch,
                     p_classevariete,
                     p_classevariete_corr,
                     p_classevarieterobust,
                     p_classevarieterobust_corr,
                     p_classevariete_final,
                     p_classevarieterobust_final,
                     p_gimax,
                     p_gimaxrobust,
                     p_gi_final,
                     p_girobust_final,
                     p_sumfamily,
                     p_sumfamilycorrected,
                     p_sumfamilyrobust,
                     p_sumfamilyrobustcorrected,
                     p_ephemeropteracounter,
                     p_plecopteracounter,
                     p_tricopteracounter,
                     p_spearvalue);

        NULL;
    END;

    /*-------------------------------------------------------------------*/
    PROCEDURE p_deleteby_ihy_sph_id (p_sph_id indicehistory.ihy_sph_id%TYPE)
    /*--------------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM indicehistory
              WHERE ihy_sph_id = p_sph_id;
    END;
END pkg_indicehistory;
/

