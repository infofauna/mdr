create PACKAGE BODY       pkg_avaliabilitycalendar
AS
   /******************************************************************************
      NAME:       PKG_AVALIABILITYCALENDAR
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        28/07/2014      burrif       1. Created this package.
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, novembre  2013' ;
   cst_elevationmin     CONSTANT NUMBER := -9999;
   cst_elevationmax     CONSTANT NUMBER := 9999;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getrecord (p_id IN avaliabilitycalendar.iac_id%TYPE)
      RETURN avaliabilitycalendar%ROWTYPE
   /*----------------------------------------------------------------*/
   IS
      l_recavaliabilitycalendar   avaliabilitycalendar%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recavaliabilitycalendar
        FROM avaliabilitycalendar
       WHERE iac_id = p_id;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_deleteall
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM avaliabilitycalendar;

      pkg_migr_utility.p_recreatesequence ('AVALIABILITYCALENDAR',
                                           'SEQ_AVALIABILITYCALENDAR',
                                           'IAC_ID');
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_write (
      p_cvl_id_midatindice   IN     avaliabilitycalendar.iac_cvl_id_midatindice%TYPE,
      p_cvl_id_midatwindow   IN     avaliabilitycalendar.iac_cvl_id_midatwindow%TYPE,
      p_elevationmin         IN     avaliabilitycalendar.iac_elevationmin%TYPE,
      p_elevationmax         IN     avaliabilitycalendar.iac_elevationmax%TYPE,
      p_startday             IN     avaliabilitycalendar.iac_startday%TYPE,
      p_endday               IN     avaliabilitycalendar.iac_endday%TYPE,
      p_startmonth           IN     avaliabilitycalendar.iac_startmonth%TYPE,
      p_endmonth             IN     avaliabilitycalendar.iac_endmonth%TYPE,
      p_id                      OUT avaliabilitycalendar.iac_id%TYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_avaliabilitycalendar.NEXTVAL;

      INSERT INTO avaliabilitycalendar (iac_cvl_id_midatindice,
                                        iac_cvl_id_midatwindow,
                                        iac_elevationmin,
                                        iac_elevationmax,
                                        iac_startday,
                                        iac_endday,
                                        iac_startmonth,
                                        iac_endmonth,
                                        iac_id)
           VALUES (p_cvl_id_midatindice,
                   p_cvl_id_midatwindow,
                   p_elevationmin,
                   p_elevationmax,
                   p_startday,
                   p_endday,
                   p_startmonth,
                   p_endmonth,
                   p_id);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_returnlistjourmoisnormal (
      p_indicetype     IN     avaliabilitycalendar.iac_cvl_id_midatindice%TYPE,
      p_elevation      IN     avaliabilitycalendar.iac_elevationmin%TYPE,
      p_jourmoislist      OUT VARCHAR2)
   /*-----------------------------------------------------------------*/
   IS
      CURSOR l_cursor
      IS
         SELECT avaliabilitycalendar.*
           FROM avaliabilitycalendar
                INNER JOIN codevalue ON cvl_id = iac_cvl_id_midatwindow
          WHERE     cvl_code = pkg_codevalue.cst_midat_window_normal
                AND iac_cvl_id_midatindice = p_indicetype
                AND NVL (p_elevation, iac_elevationmin) >= iac_elevationmin
                AND NVL (p_elevation, iac_elevationmax) <= iac_elevationmax;

      l_reccursor   l_cursor%ROWTYPE;
   BEGIN
      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;

         IF p_jourmoislist IS NULL
         THEN
            p_jourmoislist :=
                  TO_CHAR (l_reccursor.iac_startday)
               || '/'
               || TO_CHAR (l_reccursor.iac_startmonth)
               || ' - '
               || TO_CHAR (l_reccursor.iac_endday)
               || '/'
               || TO_CHAR (l_reccursor.iac_endmonth);
         ELSE
            p_jourmoislist :=
                  p_jourmoislist
               || '; '
               || TO_CHAR (l_reccursor.iac_startday)
               || '/'
               || TO_CHAR (l_reccursor.iac_startmonth)
               || ' - '
               || TO_CHAR (l_reccursor.iac_endday)
               || '/'
               || TO_CHAR (l_reccursor.iac_endmonth);
         END IF;
      END LOOP;

      CLOSE l_cursor;
   END;



   /*----------------------------------------------------------------*/
   FUNCTION f_getrecordbyindicetypeanddate (
      p_indicetype   IN avaliabilitycalendar.iac_cvl_id_midatindice%TYPE,
      p_date         IN DATE,
      p_elevation    IN avaliabilitycalendar.iac_elevationmin%TYPE)
      RETURN avaliabilitycalendar%ROWTYPE
   /*-------------------------------------------------------------*/
   IS
      /*
       Si l'altitude est null
        Si La date donnée retourne un seul enregistrement qui couvre toute les altitudes  (min: -99999 max: 9999) alors on retourne l'enregistrement
        Sinom on retourne rien


      */



      l_recavaliabilitycalendar   avaliabilitycalendar%ROWTYPE;
      l_day                       NUMBER;
      l_month                     NUMBER;
      l_dateref                   DATE;
   BEGIN
      IF p_date IS NULL
      THEN
         RETURN NULL;
      END IF;

      IF p_elevation IS NULL
      THEN
         RETURN f_getrecordbyindicetypeanddate (p_indicetype, p_date);
      END IF;

      pkg_debug.p_write (
         'PKG_AVALIABILITYCALENDAR.f_getrecordbyindicetypeanddate',
         'Date=' || TO_CHAR (p_date, 'DD/MM/YYYY'));
      l_day := EXTRACT (DAY FROM p_date);
      l_month := EXTRACT (MONTH FROM p_date);

      pkg_debug.p_write (
         'PKG_AVALIABILITYCALENDAR.f_getrecordbyindicetypeanddate',
         'Day=' || TO_CHAR (l_day) || ' Month:' || TO_CHAR (l_month));
      l_dateref :=
         TO_DATE (TO_CHAR (l_day) || '/' || TO_CHAR (l_month) || '/2004',
                  'DD/MM/YYYY');                       -- 2004 année bisextile


      SELECT *
        INTO l_recavaliabilitycalendar
        FROM avaliabilitycalendar
       WHERE     TO_DATE (
                       TO_CHAR (iac_startday)
                    || '/'
                    || TO_CHAR (iac_startmonth)
                    || '/2004',
                    'DD/MM/YYYY') <= l_dateref
             AND TO_DATE (
                       TO_CHAR (iac_endday)
                    || '/'
                    || TO_CHAR (iac_endmonth)
                    || '/2004',
                    'DD/MM/YYYY') >= l_dateref
             AND iac_cvl_id_midatindice = p_indicetype
             AND p_elevation >= iac_elevationmin
             AND p_elevation <= iac_elevationmax;



      RETURN l_recavaliabilitycalendar;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_getrecordbyindicetypeanddate (
      p_indicetype   IN avaliabilitycalendar.iac_cvl_id_midatindice%TYPE,
      p_date         IN DATE)
      RETURN avaliabilitycalendar%ROWTYPE
   /*-------------------------------------------------------------*/
   IS
      /*
       Si l'altitude est null
        Si La date donnée retourne un seul enregistrement qui couvre toute les altitudes  (min: -99999 max: 9999) alors on retourne l'enregistrement
        Sinom on retourne rien

      */



      l_recavaliabilitycalendar   avaliabilitycalendar%ROWTYPE;
      l_day                       NUMBER;
      l_month                     NUMBER;
      l_dateref                   DATE;
   BEGIN
      IF p_date IS NULL
      THEN
         RETURN NULL;
      END IF;


      l_day := TO_NUMBER (TO_CHAR (p_date, 'DD'));
      l_month := TO_NUMBER (TO_CHAR (p_date, 'MM'));
      l_dateref :=
         TO_DATE (TO_CHAR (l_day) || '/' || TO_CHAR (l_month) || '/2004',
                  'DD/MM/YYYY');                       -- 2004 année bisextile


      SELECT *
        INTO l_recavaliabilitycalendar
        FROM avaliabilitycalendar
       WHERE     TO_DATE (
                       TO_CHAR (iac_startday)
                    || '/'
                    || TO_CHAR (iac_startmonth)
                    || '/2004',
                    'DD/MM/YYYY') <= l_dateref
             AND TO_DATE (
                       TO_CHAR (iac_endday)
                    || '/'
                    || TO_CHAR (iac_endmonth)
                    || '/2004',
                    'DD/MM/YYYY') >= l_dateref
             AND iac_cvl_id_midatindice = p_indicetype;

      IF     l_recavaliabilitycalendar.iac_elevationmin = cst_elevationmin
         AND l_recavaliabilitycalendar.iac_elevationmax = cst_elevationmax
      THEN
         RETURN l_recavaliabilitycalendar;
      ELSE
         RETURN NULL;
      END IF;
   EXCEPTION
      WHEN NO_DATA_FOUND OR TOO_MANY_ROWS
      THEN
         RETURN NULL;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_formatmessageibch (p_sph_id IN sampleheader.sph_id%TYPE)
      RETURN VARCHAR2
   /*--------------------------------------------------------------*/
   IS
      l_recsampleheader           sampleheader%ROWTYPE;
      l_recsamplestation          samplestation%ROWTYPE;
      l_recavaliabilitycalendar   avaliabilitycalendar%ROWTYPE;
      l_reccodevalue              codevalue%ROWTYPE;
   BEGIN
      l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);

      IF l_recsampleheader.sph_indexvalueibch IS NULL
      THEN
         RETURN NULL;
      END IF;

      l_recsamplestation :=
         pkg_samplestation.f_getrecord (l_recsampleheader.sph_sst_id);
      l_reccodevalue :=
         pkg_codevalue.f_getfromcode (pkg_codevalue.cst_midatindice_ibch,
                                      pkg_codereference.cst_crf_midatindice);
      l_recavaliabilitycalendar :=
         f_getrecordbyindicetypeanddate (
            l_reccodevalue.cvl_id,
            l_recsampleheader.sph_observationdate,
            l_recsamplestation.sst_z);
      RETURN NULL;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_countperiodetype (
      p_cvl_id_midatindice   IN avaliabilitycalendar.iac_cvl_id_midatindice%TYPE)
      RETURN NUMBER
   /*--------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM avaliabilitycalendar
       WHERE iac_cvl_id_midatindice = p_cvl_id_midatindice;

      RETURN l_count;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_computeperiodtype (
      p_indicetype   IN avaliabilitycalendar.iac_cvl_id_midatindice%TYPE,
      p_date         IN DATE,
      p_elevation    IN avaliabilitycalendar.iac_elevationmin%TYPE)
      RETURN codevalue.cvl_code%TYPE
   /*-------------------------------------------------------------*/
   IS
      l_day                       NUMBER;
      l_month                     NUMBER;
      l_recavaliabilitycalendar   avaliabilitycalendar%ROWTYPE;

      l_reccodevalue              codevalue%ROWTYPE;
   BEGIN
      IF f_countperiodetype (p_indicetype) = 0
      THEN
         RETURN NULL;
      END IF;

      l_recavaliabilitycalendar :=
         f_getrecordbyindicetypeanddate (p_indicetype, p_date, p_elevation);

      IF l_recavaliabilitycalendar.iac_id IS NULL
      THEN
         RETURN pkg_codevalue.cst_midat_window_outer;
      ELSE
         l_reccodevalue :=
            pkg_codevalue.f_getrecord (
               l_recavaliabilitycalendar.iac_cvl_id_midatwindow);
         RETURN l_reccodevalue.cvl_code;
      END IF;
   END;
END pkg_avaliabilitycalendar;
/

