create PACKAGE BODY       pkg_validatemassheaderfield
AS
   /******************************************************************************
      NAME:       pkg_validatemassheaderfield
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
      2.0         11.07.2017     burrif       2. Fonctionnalité version 2
      2.1        21.01.2018      burrif       3. Nouvelle version de gestion des droits
   ******************************************************************************/



   /* Colonne à valider:
    IMH_ABSOLUTENUMBERFLAG  CHAR(1 CHAR),
  IMH_SYSTEMPRECISION     VARCHAR2(60 CHAR),
  IMH_CODEPRECISION       VARCHAR2(60 CHAR),
  IMH_OID                 VARCHAR2(30 CHAR),
  IMH_WATERCOURSE         VARCHAR2(60 CHAR),
  IMH_DAY                 VARCHAR2(10 BYTE),
  IMH_MONTH               VARCHAR2(10 BYTE),
  IMH_YEAR                VARCHAR2(10 BYTE),
  IMH_STARTPOINT_X        VARCHAR2(128 CHAR),
  IMH_STARTPOINT_Y        VARCHAR2(128 CHAR),
  IMH_ELEVATION           VARCHAR2(128 CHAR),
  IMH_LOCALITY            VARCHAR2(60 CHAR),
  IMH_CALLEDPLACE         VARCHAR2(256 CHAR),

   IMD_INDICETYPE       VARCHAR2(39 BYTE),
   IMD_PERIOD           VARCHAR2(60 BYTE),

  IMH_OBSERVERS           VARCHAR2(120 CHAR),

  IMH_REMARKCODE1                 VARCHAR2(255 BYTE),
  IMH_REMARKCODE2                 VARCHAR2(255 BYTE),
  IMH_REMARKCODE3                 VARCHAR2(255 BYTE),
  IMH_REMARKCODE4                 VARCHAR2(255 BYTE),
  IMH_REMARKTEXT                  VARCHAR2(255 BYTE),
  IMH_OIDLINK                     VARCHAR2(255 BYTE),
  IMH_DETERMINATOR                VARCHAR2(255 BYTE)

  */



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 2.1, janvier 2019' ;

   gbl_coordinatesstatus         BOOLEAN := TRUE;

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_setcoordinatesstatus (p_status IN BOOLEAN)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      gbl_coordinatesstatus := p_status;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getcoordinatesstatus
      RETURN BOOLEAN
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_coordinatesstatus;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checkindicetype (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      l_codevalue                    codevalue%ROWTYPE;
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
      l_datetxt                      VARCHAR2 (256);
      l_swisscoord                   VARCHAR2 (256);
      l_excelfield                   VARCHAR2 (256);
      cst_exception         CONSTANT NUMBER
         := pkg_exception.cst_midatindiceinvalid ;

      l_error                        BOOLEAN := FALSE;
      l_module                       VARCHAR2 (256);
      l_listline                     VARCHAR2 (1024);
      l_listindice                   pkg_stringutil.t_listofvalue;
      l_indice                       PLS_INTEGER;
      l_spearindexcalculation        BOOLEAN;
      l_makroindexcalculation        BOOLEAN;
      l_ibchindexcalculation         BOOLEAN;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      IF p_recimportmassdataheader.imh_indicetype IS NULL
      THEN
         RETURN;
      END IF;

      l_listline :=
         pkg_importmassdatadetail.f_buildsourcelinefilled (
            p_recimportmassdataheader.imh_id,
            'IMD_INDICETYPE');
      l_datetxt :=
         pkg_importmassdataheader.f_builddatetxt (p_recimportmassdataheader);

      l_swisscoord :=
         pkg_importmassdataheader.f_buildswisscoord (
            p_recimportmassdataheader);
      l_recimportmassmappingheader :=
         pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
            p_recimportmassdataheader.imh_iph_id,
            pkg_codevalue.cst_midatfldcmt_indicetype);

      IF l_recimportmassmappingheader.ime_id IS NULL
      THEN
         l_module :=
               'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
            || TO_CHAR (p_recimportmassdataheader.imh_iph_id)
            || ','''
            || pkg_codevalue.cst_midatfldcmt_indicetype
            || ''')';
         pkg_importprotocollog.p_logunexpectederror (
            p_recimportmassdataheader.imh_iph_id,
            'IMH_INDICETYPE',
            l_module);
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;

      l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;

      l_listindice :=
         pkg_stringutil.f_splitstring (
            p_recimportmassdataheader.imh_indicetype,
            ';');
      l_indice := l_listindice.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         l_codevalue :=
            pkg_codevalue.f_getfromcode (
               UPPER (TRIM (l_listindice (l_indice))),
               pkg_codereference.cst_crf_midatindice);
         pkg_debug.p_write ('pkg_validatemassheaderfield.p_checkindicetype',
                            'cvl_id=' || l_codevalue.cvl_id);

         IF l_codevalue.cvl_id IS NULL
         THEN
            pkg_importprotocollog.p_writelog (
               p_recimportmassdataheader.imh_iph_id,
               NULL,
               cst_exception,
               'IMH_INDICETYPE',
               l_listindice (l_indice),
               l_listline,
               l_datetxt,
               l_swisscoord,
               l_excelfield);

            IF p_returnstatus = pkg_constante.cst_returnstatusok
            THEN
               p_returnstatus :=
                  pkg_message.f_convertseveritylevel2status (cst_exception);
            END IF;
         END IF;

         l_indice := l_listindice.NEXT (l_indice);
      END LOOP;

      -- L'indice IBCH et MAKROINDEX ne peuvent pas être slectionné en même temps

      IF p_returnstatus = pkg_constante.cst_returnstatusok
      THEN
         pkg_importmassdataheader.p_returnindexcalculation (
            p_recimportmassdataheader.imh_id,
            l_spearindexcalculation,
            l_makroindexcalculation,
            l_ibchindexcalculation);

         IF l_makroindexcalculation AND l_ibchindexcalculation
         THEN
            pkg_importprotocollog.p_writelog (
               p_recimportmassdataheader.imh_iph_id,
               NULL,
               pkg_exception.cst_mkiincompatibilityindex,
               'IMH_INDICETYPE',
               p_recimportmassdataheader.imh_indicetype,
               l_listline,
               l_datetxt,
               l_swisscoord,
               l_excelfield);
            p_returnstatus :=
               pkg_message.f_convertseveritylevel2status (
                  pkg_exception.cst_mkiincompatibilityindex);
         END IF;
      END IF;
   END;



   /*---------------------------------------------------------------*/
   PROCEDURE p_checklocality (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checkcalledplace (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checkobservers (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checkreporturl (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checkcomment (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checkcodeprecision (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_cvl_id_systlprec          IN     codevalue.cvl_id%TYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      l_codevalue                    codevalue%ROWTYPE;
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
      l_datetxt                      VARCHAR2 (256);
      l_swisscoord                   VARCHAR2 (256);
      l_excelfield                   VARCHAR2 (256);
      cst_exception1        CONSTANT NUMBER
                                        := pkg_exception.cst_codeprecinvalid ;
      cst_exception2        CONSTANT NUMBER
         := pkg_exception.cst_massfieldlinkrequired ;
      l_error                        BOOLEAN := FALSE;
      l_module                       VARCHAR2 (256);
      l_listline                     VARCHAR2 (1024);
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;


      l_datetxt :=
         pkg_importmassdataheader.f_builddatetxt (p_recimportmassdataheader);

      l_swisscoord :=
         pkg_importmassdataheader.f_buildswisscoord (
            p_recimportmassdataheader);
      l_recimportmassmappingheader :=
         pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
            p_recimportmassdataheader.imh_iph_id,
            pkg_codevalue.cst_midatfldcmt_systemprec);

      IF l_recimportmassmappingheader.ime_id IS NULL
      THEN
         l_module :=
               'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
            || TO_CHAR (p_recimportmassdataheader.imh_iph_id)
            || ','''
            || pkg_codevalue.cst_midatfldcmt_systemprec
            || ''')';
         pkg_importprotocollog.p_logunexpectederror (
            p_recimportmassdataheader.imh_iph_id,
            'IMH_CODEPRECISION',
            l_module);
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;

      l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;

      IF p_recimportmassdataheader.imh_codeprecision IS NULL
      THEN
         -- On ne vient pas là si SYSTEMPRECISION est null. Donc erreur
         l_listline :=
            pkg_importmassdatadetail.f_buildsourcelinefilled (
               p_recimportmassdataheader.imh_id,
               'IMD_CODEPRECISION');
         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            NULL,
            cst_exception2,
            'IMH_CODEPRECISION',
            'IMH_SYSTEMPRECISION',
            'IMH_CODEPRECISION',
            l_listline,
            l_datetxt,
            l_swisscoord,
            l_excelfield);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (cst_exception2);
         RETURN;
      END IF;

      l_codevalue :=
         pkg_codevalue.f_getfromcode (
            p_recimportmassdataheader.imh_codeprecision,
            pkg_codereference.cst_crf_systlprec);

      IF l_codevalue.cvl_id IS NULL
      THEN
         l_error := TRUE;
      ELSE
         IF l_codevalue.cvl_cvl_id != p_cvl_id_systlprec
         THEN
            l_error := TRUE;
         END IF;
      END IF;

      IF l_error
      THEN
         l_listline :=
            pkg_importmassdatadetail.f_buildsourcelinefilled (
               p_recimportmassdataheader.imh_id,
               'IMD_CODEPRECISION');
         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            NULL,
            cst_exception1,
            'IMH_CODEPRECISION',
            p_recimportmassdataheader.imh_codeprecision,
            p_recimportmassdataheader.imh_systemprecision,
            l_listline,
            l_datetxt,
            l_swisscoord,
            l_excelfield);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (cst_exception1);
         RETURN;
      END IF;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checksystemprecision (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      l_codevalue                    codevalue%ROWTYPE;
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
      l_datetxt                      VARCHAR2 (256);
      l_swisscoord                   VARCHAR2 (256);
      l_excelfield                   VARCHAR2 (256);
      l_listline                     VARCHAR2 (1024);

      cst_exception1        CONSTANT NUMBER
         := pkg_exception.cst_systemprecrefinvalid ;
      cst_exception2        CONSTANT NUMBER
         := pkg_exception.cst_massfieldlinkrequired ;
      l_module                       VARCHAR2 (256);
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;


      IF     p_recimportmassdataheader.imh_systemprecision IS NULL
         AND p_recimportmassdataheader.imh_codeprecision IS NULL
      THEN
         RETURN;
      END IF;

      l_datetxt :=
         pkg_importmassdataheader.f_builddatetxt (p_recimportmassdataheader);

      l_swisscoord :=
         pkg_importmassdataheader.f_buildswisscoord (
            p_recimportmassdataheader);
      l_recimportmassmappingheader :=
         pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
            p_recimportmassdataheader.imh_iph_id,
            pkg_codevalue.cst_midatfldcmt_systemprec);

      IF l_recimportmassmappingheader.ime_id IS NULL
      THEN
         l_module :=
               'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
            || TO_CHAR (p_recimportmassdataheader.imh_iph_id)
            || ','''
            || pkg_codevalue.cst_midatfldcmt_systemprec
            || ''')';
         pkg_importprotocollog.p_logunexpectederror (
            p_recimportmassdataheader.imh_iph_id,
            'IMH_SYSTEMPRECISION',
            l_module);
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;

      l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;



      IF     p_recimportmassdataheader.imh_systemprecision IS NULL
         AND NOT p_recimportmassdataheader.imh_codeprecision IS NULL
      THEN
         l_listline :=
            pkg_importmassdatadetail.f_buildsourcelinefilled (
               p_recimportmassdataheader.imh_id,
               'IMD_CODEPRECISION');
         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            NULL,
            cst_exception2,
            'IMH_SYSTEMPRECISION',
            'IMH_CODEPRECISION',
            'IMH_SYSTEMPRECISION',
            l_listline,
            l_datetxt,
            l_swisscoord,
            l_excelfield);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (cst_exception2);
         RETURN;
      END IF;


      l_codevalue :=
         pkg_codevalue.f_getfromcode (
            p_recimportmassdataheader.imh_systemprecision,
            pkg_codereference.cst_crf_systlref);

      IF l_codevalue.cvl_id IS NULL
      THEN
         l_listline :=
            pkg_importmassdatadetail.f_buildsourcelinefilled (
               p_recimportmassdataheader.imh_id,
               'IMD_SYSTEMPRECISION');

         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            NULL,
            cst_exception1,
            'IMH_SYSTEMPRECISION',
            p_recimportmassdataheader.imh_systemprecision,
            l_listline,
            l_datetxt,
            l_swisscoord,
            l_excelfield);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (cst_exception1);
         RETURN;
      ELSE
         p_checkcodeprecision (p_recimportmassdataheader,
                               l_codevalue.cvl_id,
                               p_returnstatus);
      END IF;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checkoid (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_checkwatercourse (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_checkremarkcode (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_remarknumber              IN     NUMBER,
      p_returnstatus                 OUT NUMBER)
   /*-------------------------------------------------------------------*/
   IS
      -- La remarque doit contenir un code connu dans le domaine MIDATLOADCMT
      l_reccodevalue                   codevalue%ROWTYPE;
      l_coderemark                     importmassdatadetail.imd_remarkcode1%TYPE;
      l_recimportprotocolheader        importprotocolheader%ROWTYPE;
      l_recimportmassdataheader        importmassdataheader%ROWTYPE;
      l_recimportmassmappingheader     importmassmappingheader%ROWTYPE;
      l_recprotocolmappingmassmap      protocolmappingmassmap%ROWTYPE;
      l_datetxt                        VARCHAR2 (256);
      l_swisscoord                     VARCHAR2 (256);
      l_excelfield                     VARCHAR2 (256);
      l_listline                       VARCHAR2 (1024);
      l_field                          VARCHAR2 (30);
      l_recprotocolmapppingmassfield   protocolmappingmassfield%ROWTYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_datetxt :=
         pkg_importmassdataheader.f_builddatetxt (l_recimportmassdataheader);

      l_swisscoord :=
         pkg_importmassdataheader.f_buildswisscoord (
            l_recimportmassdataheader);
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (
            p_recimportmassdataheader.imh_iph_id);

      CASE p_remarknumber
         WHEN 1
         THEN
            l_coderemark := p_recimportmassdataheader.imh_remarkcode1;
            l_recprotocolmapppingmassfield :=
               pkg_protocolmappingmassfield.f_getfromcode (
                  pkg_codevalue.cst_midatfldcmt_remarkcode1,
                  l_recimportprotocolheader.iph_ptv_id);

            l_recprotocolmappingmassmap :=
               pkg_protocolmappingmassmap.f_getrecordbymidatfldcmt (
                  l_recimportprotocolheader.iph_ptv_id,
                  l_recimportprotocolheader.iph_lan_id,
                  pkg_codevalue.cst_midatfldcmt_remarkcode1);
            l_recimportmassmappingheader :=
               pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                  l_recimportmassdataheader.imh_iph_id,
                  pkg_codevalue.cst_midatfldcmt_remarkcode1);
            l_field := l_recprotocolmapppingmassfield.pmm_columnname;
         WHEN 2
         THEN
            l_coderemark := p_recimportmassdataheader.imh_remarkcode2;
            l_recprotocolmapppingmassfield :=
               pkg_protocolmappingmassfield.f_getfromcode (
                  pkg_codevalue.cst_midatfldcmt_remarkcode2,
                  l_recimportprotocolheader.iph_ptv_id);
            l_recprotocolmappingmassmap :=
               pkg_protocolmappingmassmap.f_getrecordbymidatfldcmt (
                  l_recimportprotocolheader.iph_ptv_id,
                  l_recimportprotocolheader.iph_lan_id,
                  pkg_codevalue.cst_midatfldcmt_remarkcode1);
            l_recimportmassmappingheader :=
               pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                  l_recimportmassdataheader.imh_iph_id,
                  pkg_codevalue.cst_midatfldcmt_remarkcode2);
            l_field := l_recprotocolmapppingmassfield.pmm_columnname;
         WHEN 3
         THEN
            l_coderemark := p_recimportmassdataheader.imh_remarkcode3;
            l_recprotocolmapppingmassfield :=
               pkg_protocolmappingmassfield.f_getfromcode (
                  pkg_codevalue.cst_midatfldcmt_remarkcode3,
                  l_recimportprotocolheader.iph_ptv_id);
            l_recprotocolmappingmassmap :=
               pkg_protocolmappingmassmap.f_getrecordbymidatfldcmt (
                  l_recimportprotocolheader.iph_ptv_id,
                  l_recimportprotocolheader.iph_lan_id,
                  pkg_codevalue.cst_midatfldcmt_remarkcode1);
            l_recimportmassmappingheader :=
               pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                  l_recimportmassdataheader.imh_iph_id,
                  pkg_codevalue.cst_midatfldcmt_remarkcode3);
            l_field := l_recprotocolmapppingmassfield.pmm_columnname;
         WHEN 4
         THEN
            l_coderemark := p_recimportmassdataheader.imh_remarkcode4;
            l_recprotocolmapppingmassfield :=
               pkg_protocolmappingmassfield.f_getfromcode (
                  pkg_codevalue.cst_midatfldcmt_remarkcode4,
                  l_recimportprotocolheader.iph_ptv_id);
            l_recprotocolmappingmassmap :=
               pkg_protocolmappingmassmap.f_getrecordbymidatfldcmt (
                  l_recimportprotocolheader.iph_ptv_id,
                  l_recimportprotocolheader.iph_lan_id,
                  pkg_codevalue.cst_midatfldcmt_remarkcode1);
            l_recimportmassmappingheader :=
               pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                  p_recimportmassdataheader.imh_iph_id,
                  pkg_codevalue.cst_midatfldcmt_remarkcode4);
            l_field := l_recprotocolmapppingmassfield.pmm_columnname;
         ELSE
            l_coderemark := NULL;
      END CASE;

      IF l_coderemark IS NULL
      THEN
         RETURN;
      END IF;

      l_listline :=
         pkg_importmassdatadetail.f_buildsourcelinefilled (
            p_recimportmassdataheader.imh_id,
            l_field);

      l_reccodevalue :=
         pkg_codevalue.f_getfromcode (l_coderemark,
                                      pkg_codereference.cst_crf_midatloadcmt);

      IF l_reccodevalue.cvl_id IS NULL
      THEN
         -- Le code (%p1%) de la remarque fourni dans la colonne de remaruque N° %p2% est invalide


         l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
               p_recimportmassdataheader);

         l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
               p_recimportmassdataheader);

         l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;
         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            p_recimportmassdataheader.imh_id,
            pkg_exception.cst_remarkcodenotfound,
            'IMD_REMARKCODE' || TRIM (TO_CHAR (p_remarknumber)),
            l_coderemark,
            TRIM (TO_CHAR (p_remarknumber)),
            l_listline,
            l_datetxt,
            l_swisscoord,
            l_recprotocolmappingmassmap.pma_aliascolumnname);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_remarkcodenotfound);
      END IF;
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_checkremarktext (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_returnrecprojet (
      p_projet   IN importmassdataheader.imh_project%TYPE)
      RETURN project%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_recprojet   project%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recprojet
        FROM project
       WHERE     (   UPPER (TRIM (prj_codech)) = UPPER (TRIM (p_projet))
                  OR UPPER (TRIM (prj_designation)) = UPPER (TRIM (p_projet)))
             AND ROWNUM < 2;

      RETURN l_recprojet;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_checkproject (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      /* LE code du projet doit être saisi ou la désignation complète */
      l_recproject                     project%ROWTYPE;

      l_recimportprotocolheader        importprotocolheader%ROWTYPE;

      l_recimportmassmappingheader     importmassmappingheader%ROWTYPE;
      l_recprotocolmappingmassmap      protocolmappingmassmap%ROWTYPE;
      l_datetxt                        VARCHAR2 (256);
      l_swisscoord                     VARCHAR2 (256);
      l_excelfield                     VARCHAR2 (256);
      l_listline                       VARCHAR2 (1024);
      l_field                          VARCHAR2 (30);
      l_recprotocolmapppingmassfield   protocolmappingmassfield%ROWTYPE;
      l_recinstitution institution%rowtype;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      IF p_recimportmassdataheader.imh_project IS NULL
      THEN
         RETURN;
      END IF;

      l_datetxt :=
         pkg_importmassdataheader.f_builddatetxt (p_recimportmassdataheader);

      l_swisscoord :=
         pkg_importmassdataheader.f_buildswisscoord (
            p_recimportmassdataheader);
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (
            p_recimportmassdataheader.imh_iph_id);

      l_recprotocolmappingmassmap :=
         pkg_protocolmappingmassmap.f_getrecordbymidatfldcmt (
            l_recimportprotocolheader.iph_ptv_id,
            l_recimportprotocolheader.iph_lan_id,
            pkg_codevalue.cst_midatfldcmt_project);
      l_listline :=
         pkg_importmassdatadetail.f_buildsourcelinefilled (
            p_recimportmassdataheader.imh_id,
            'IMD_PROJECT');
      l_recproject :=
         pkg_project.f_getrecordbycode (
            l_recimportprotocolheader.iph_ins_id_principal,
            p_recimportmassdataheader.imh_project);

      IF l_recproject.prj_id IS NULL
      THEN
         -- On essaye avec le code CH
         l_recproject :=
            pkg_project.f_getrecordbycodech (
               l_recimportprotocolheader.iph_ins_id_principal,
               p_recimportmassdataheader.imh_project);

         IF l_recproject.prj_id IS NULL
         THEN
            -- On essaye avec le texte
            l_recproject :=
               pkg_project.f_getrecordbydesignation (
                  l_recimportprotocolheader.iph_ins_id_principal,
                  p_recimportmassdataheader.imh_project);
         END IF;
      END IF;

      IF l_recproject.prj_id IS NULL
      THEN
         --Le projet (%p1%) n'a pas pu être identifié.  Ligne Excel: %p2%; date -> %p3% ; [x, y, z] -> %p4% ; colonne source : %p5%
         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            p_recimportmassdataheader.imh_id,
            pkg_exception.cst_projectnotfound,
            'IMD_PROJECT',
            p_recimportmassdataheader.imh_project,
            l_listline,
            l_datetxt,
            l_swisscoord,
            l_recprotocolmappingmassmap.pma_aliascolumnname);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_projectnotfound);
         l_recproject :=
            f_returnrecprojet (p_recimportmassdataheader.imh_project);

         IF NOT l_recproject.prj_id IS NULL
         THEN
            l_recinstitution :=
               pkg_institution.f_getrecord (l_recproject.prj_ins_id_mandant);
            -- Ce nom de projet (%p1%) est défini pour une institution différente (%p2%).
            pkg_importprotocollog.p_writelog (
               p_recimportmassdataheader.imh_iph_id,
               p_recimportmassdataheader.imh_id,
               pkg_exception.cst_projetnamedefinedotherins,
               'IMD_PROJECT',
               p_recimportmassdataheader.imh_project,
               l_recinstitution.ins_name);
         END IF;

         RETURN;
      END IF;

      pkg_importmassdataheader.p_update_imh_prj_id (
         p_recimportmassdataheader.imh_id,
         l_recproject.prj_id,
         p_recimportmassdataheader.imh_usr_id_modify);
   END;



   /*-------------------------------------------------------------------*/
   PROCEDURE p_checkoidlink (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*-------------------------------------------------------------------*/
   IS
      /* Une station peut être en lien (OIDLINK) avec une autre station (OID)  de la même institution que si elle est dans un rayon
         de 350m.
         Une station déjà liée ne peut pas servir de lien (OIDLINK ne doit pas avoir de lien)
         La station  référencée (OID) doit exister
         La station référencée ne peut pas être la même que celle définie dans OID
         Si la station OID n'est pas renseigné, la colonne OIDLINK ne doit pas être renseigné
         Si la station (OID) existe déjà on ne peut la lier que si aucun lien autre ne la référencie

                     Cas: Station OID    Station OIDLINK          Note: Valable pour OID renseigné et OIDLINK renseigné
                        Existe   Lien      Existe Lien
                         0        0         0       0     -> OK: Erreur: La station OID doit exister
                         1        0         0       0     -> Créer la liaison
                         0        1         0       0     -> OK: Erreur: La station OID doit exister
                         1        1         0       0     -> OK: Si le lien OID est cible, créer la liaison. SI le lien est un renvoi ERREUR
                         0        0         1       0     -> OK: Erreur: La station OID doit exister
                         1        0         1       0     -> Créer le lien
                         0        1         1       0     -> OK: Erreur: La station OID doit exister
                         1        1         1       0     -> OK: Si le lien OID est cible, créer la liaison. SI le lien est un renvoi ERREUR
                         0        0         0       1     -> OK: Erreur: La station OID doit exister
                         1        0         0       1     -> Impossible, la station OIDLINK doit exister pour avoir un lien
                         0        1         0       1     -> OK: Erreur: La station OID doit exister
                         1        1         0       1     -> Impossible, la station OIDLINK doit exister pour avoir un lien
                         0        0         1       1     -> OK: Erreur: La station OID doit exister
                         1        0         1       1     -> Si le lien OIDLINK est cible, ERREUR. Si le lien OIDLINK est un renvoi ERREUR
                         0        1         1       1     -> OK: Erreur: La station OID doit exister
                         1        1         1       1     -- Si le lien OID est un renvoi, erreur. Si le lien OIDLINK est cible ERREUR, SI le lien OIDLINK existant n'est pas sur OID ERREUR
       */



      l_reccodevalue                   codevalue%ROWTYPE;
      l_recimportprotocolheader        importprotocolheader%ROWTYPE;


      l_recimportmassmappingheader     importmassmappingheader%ROWTYPE;
      l_datetxt                        VARCHAR2 (256);
      l_swisscoord                     VARCHAR2 (256);
      l_excelfield                     VARCHAR2 (256);
      l_recsamplestation               samplestation%ROWTYPE;
      l_recsamplestationoid            samplestation%ROWTYPE;
      l_recsamplestationref            samplestation%ROWTYPE;
      l_sdo_geometry1                  MDSYS.sdo_geometry;
      l_sdo_geometry2                  MDSYS.sdo_geometry;
      l_listline                       VARCHAR2 (1024);
      l_distance                       NUMBER;
      l_countreference                 NUMBER;
      l_recprotocolmappingmassmap      protocolmappingmassmap%ROWTYPE;
      l_recprotocolmappingmassmapoid   protocolmappingmassmap%ROWTYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;


      IF p_recimportmassdataheader.imh_oidlink IS NULL
      THEN
         RETURN;
      END IF;

      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (
            p_recimportmassdataheader.imh_iph_id);
      l_recprotocolmappingmassmap :=
         pkg_protocolmappingmassmap.f_getrecordbymidatfldcmt (
            l_recimportprotocolheader.iph_ptv_id,
            l_recimportprotocolheader.iph_lan_id,
            pkg_codevalue.cst_midatfldcmt_oidlink);

      l_recprotocolmappingmassmapoid :=
         pkg_protocolmappingmassmap.f_getrecordbymidatfldcmt (
            l_recimportprotocolheader.iph_ptv_id,
            l_recimportprotocolheader.iph_lan_id,
            pkg_codevalue.cst_midatfldcmt_oid);

      pkg_debug.p_write (
         'PKG_VALIDATEMASSHEADERFIELD.p_checkoidlink',
            'l_recprotocolmappingmassmap.pma_aliascolumnname='
         || l_recprotocolmappingmassmap.pma_aliascolumnname);


      l_datetxt :=
         pkg_importmassdataheader.f_builddatetxt (p_recimportmassdataheader);

      l_swisscoord :=
         pkg_importmassdataheader.f_buildswisscoord (
            p_recimportmassdataheader);
      l_recimportmassmappingheader :=
         pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
            p_recimportmassdataheader.imh_iph_id,
            pkg_codevalue.cst_midatfldcmt_oidlink);
      l_listline :=
         pkg_importmassdatadetail.f_buildsourcelinefilled (
            p_recimportmassdataheader.imh_id,
            'IMD_OIDLINK');

      IF p_recimportmassdataheader.imh_oid IS NULL
      THEN
         IF NOT p_recimportmassdataheader.imh_oidlink IS NULL
         THEN
            -- La valeur de la colonne %p1% doit être définie si un lien de station est défini dans la colonne %p2%. Référence de l'entrée:  Ligne Excel: %p2%; date -> %p3% ; [x, y, z] -> %p4% ; colonne source : %p5%
            pkg_importprotocollog.p_writelog (
               p_recimportmassdataheader.imh_iph_id,
               p_recimportmassdataheader.imh_id,
               pkg_exception.cst_oidmustbedefinewithoidlink,
               'IMD_OID',
               l_recprotocolmappingmassmapoid.pma_aliascolumnname,
               l_recprotocolmappingmassmap.pma_aliascolumnname,
               l_listline,
               l_datetxt,
               l_swisscoord,
               l_recprotocolmappingmassmap.pma_aliascolumnname);
            p_returnstatus :=
               pkg_message.f_convertseveritylevel2status (
                  pkg_exception.cst_oidmustbedefinewithoidlink);
            RETURN;
         END IF;
      END IF;


      IF NOT p_recimportmassdataheader.imh_oid IS NULL
      THEN
         IF UPPER (TRIM (p_recimportmassdataheader.imh_oid)) =
               UPPER (TRIM (p_recimportmassdataheader.imh_oidlink))
         THEN
            -- L'identifiant (%p1%) de la station liée ne peut pas être identique à l'identifiant de la station Référence de l'entrée:  Ligne Excel: %p2%; date -> %p3% ; [x, y, z] -> %p4% ; colonne source : %p5%
            pkg_importprotocollog.p_writelog (
               p_recimportmassdataheader.imh_iph_id,
               p_recimportmassdataheader.imh_id,
               pkg_exception.cst_oidlinknotautolink,
               'IMD_OIDLINK',
               p_recimportmassdataheader.imh_oidlink,
               l_listline,
               l_datetxt,
               l_swisscoord,
               l_recprotocolmappingmassmap.pma_aliascolumnname);
            p_returnstatus :=
               pkg_message.f_convertseveritylevel2status (
                  pkg_exception.cst_oidlinknotautolink);
            RETURN;
         END IF;
      END IF;


      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (
            p_recimportmassdataheader.imh_iph_id);
      l_recsamplestation :=
         pkg_samplestation.f_getrecordbyinsidandoid (
            l_recimportprotocolheader.iph_ins_id_principal,
            p_recimportmassdataheader.imh_oidlink);

      IF l_recsamplestation.sst_id IS NULL
      THEN
         -- La valeur (%p1%) contenue dans la colonne définissant la station liée n'existe pas dans la liste des stations existantes de l'institution mandante.
         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            p_recimportmassdataheader.imh_id,
            pkg_exception.cst_oidlinknotfound,
            'IMD_OIDLINK',
            p_recimportmassdataheader.imh_oidlink,
            l_listline,
            l_datetxt,
            l_swisscoord,
            l_recprotocolmappingmassmap.pma_aliascolumnname);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_oidlinknotfound);
         RETURN;
      END IF;

      pkg_importmassdataheader.p_update_imh_sst_id_oidlink (
         p_recimportmassdataheader.imh_id,
         l_recsamplestation.sst_id,
         p_recimportmassdataheader.imh_usr_id_modify);


      IF NOT l_recsamplestation.sst_sst_id IS NULL
      THEN
         --La liaison entre la station (%p1%) et la station (%p2%) sur laquelle elle doit  être liée est interdite car cette dernière station est déjà liée. Référence de l'entrée:  Ligne Excel: %p5%; date -> %p6% ; [x, y, z] -> %p7% ; colonne source : %p8%
         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            p_recimportmassdataheader.imh_id,
            pkg_exception.cst_oidlinkallreadylinked,
            'IMD_OIDLINK',
            p_recimportmassdataheader.imh_oid,
            p_recimportmassdataheader.imh_oidlink,
            l_listline,
            l_datetxt,
            l_swisscoord,
            l_recprotocolmappingmassmap.pma_aliascolumnname);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_oidlinkallreadylinked);
         RETURN;
      END IF;

      l_recsamplestationoid :=
         pkg_samplestation.f_getrecordbyinsidandoid (
            l_recimportprotocolheader.iph_ins_id_principal,
            p_recimportmassdataheader.imh_oid);

      IF NOT l_recsamplestationoid.sst_id IS NULL
      THEN
         -- La station OIDLINK existe
         -- SI elle est cible ERREUR
         l_countreference :=
            pkg_samplestation.f_returncounterreference (
               l_recsamplestationoid.sst_id);

         IF l_countreference > 0
         THEN
            -- La station (%p1%) existe déjà. Elle est déjà référencée en tant que station principale de (%p2%) station(s). La liaison souhaitée est interdite.Référence de l'entrée:  Ligne Excel: %p3%; date -> %p4% ; [x, y, z] -> %p5% ; colonne source : %p6%
            pkg_debug.p_setdebugmode (TRUE);
            pkg_debug.p_write ('PKG_VALIDATEMASSHEADERFIELD.p_checkoidlink',
                               'l_countreference=' || l_countreference);
            pkg_importprotocollog.p_writelog (
               p_recimportmassdataheader.imh_iph_id,
               p_recimportmassdataheader.imh_id,
               pkg_exception.cst_oidlinkismaster,
               'IMD_OIDLINK',
               p_recimportmassdataheader.imh_oid,
               TRIM (TO_CHAR (l_countreference)),
                  p_recimportmassdataheader.imh_oid
               || ' -> '
               || p_recimportmassdataheader.imh_oidlink,
               l_listline,
               l_datetxt,
               l_swisscoord,
               l_recprotocolmappingmassmap.pma_aliascolumnname);
            p_returnstatus :=
               pkg_message.f_convertseveritylevel2status (
                  pkg_exception.cst_oidlinkismaster);
            RETURN;
         END IF;

         -- Si la station OIDLINK dispose d'un renvoi vers une station autre que OID, ERRUR
         IF NOT l_recsamplestationoid.sst_sst_id IS NULL
         THEN
            IF l_recsamplestationoid.sst_sst_id != l_recsamplestation.sst_id
            THEN
               -- La station (%p1%) existe déjà et référencie une autre (%p2%) station principale. La liaison souhaitée est interdite.Référence de l'entrée:  Ligne Excel: %p3%; date -> %p4% ; [x, y, z] -> %p5% ; colonne source : %p6%
               l_recsamplestationref :=
                  pkg_samplestation.f_getrecord (
                     l_recsamplestationoid.sst_sst_id);
               pkg_importprotocollog.p_writelog (
                  p_recimportmassdataheader.imh_iph_id,
                  p_recimportmassdataheader.imh_id,
                  pkg_exception.cst_oidlinkhasanotherlink,
                  'IMD_OIDLINK',
                  p_recimportmassdataheader.imh_oid,
                  l_recsamplestationref.sst_oid,
                     p_recimportmassdataheader.imh_oid
                  || ' -> '
                  || p_recimportmassdataheader.imh_oidlink,
                  l_listline,
                  l_datetxt,
                  l_swisscoord,
                  l_recprotocolmappingmassmap.pma_aliascolumnname);
               p_returnstatus :=
                  pkg_message.f_convertseveritylevel2status (
                     pkg_exception.cst_oidlinkismaster);
               RETURN;
            END IF;
         END IF;
      END IF;

      l_sdo_geometry1 :=
         pkg_sdoutil.f_buildsdo_geometry (
            p_recimportmassdataheader.imh_startpoint_x,
            p_recimportmassdataheader.imh_startpoint_y,
            p_recimportmassdataheader.imh_elevation);
      l_distance :=
         pkg_sdoutil.f_computedistance (l_sdo_geometry1,
                                        l_recsamplestation.sst_coordinates);

      IF l_distance > pkg_codevalue.f_get_midatparam_stalinkbuf
      THEN
         --La station (%p1%)  avec laquelle la station (%p2%) doit être liée  se trouve à une distance de %p3% mètres ce qui est en dehors de la distance admise de %p4% mètres. Référence de l'entrée:  Ligne Excel: %p5%; date -> %p6% ; [x, y, z] -> %p7% ; colonne source : %p8%
         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            p_recimportmassdataheader.imh_id,
            pkg_exception.cst_oidlinkoutoftolerance,
            'IMD_OIDLINK',
            p_recimportmassdataheader.imh_oidlink,
            p_recimportmassdataheader.imh_oid,
            TRIM (TO_CHAR (l_distance, '99999999')),
            pkg_codevalue.f_get_midatparam_stalinkbuf,
            l_listline,
            l_datetxt,
            l_swisscoord,
            l_recprotocolmappingmassmap.pma_aliascolumnname);
         p_returnstatus :=
            pkg_message.f_convertseveritylevel2status (
               pkg_exception.cst_oidlinkoutoftolerance);
         RETURN;
      END IF;
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_checkdeterminator (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_checkcollecteddatesplit (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      l_year                         NUMBER;
      l_month                        NUMBER;
      l_day                          NUMBER;
      l_datetxt                      VARCHAR2 (256);
      l_swisscoord                   VARCHAR2 (256);
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
      l_exceldayfield                importmassmappingheader.ime_excelfieldname%TYPE;
      l_excelmonthfield              importmassmappingheader.ime_excelfieldname%TYPE;
      l_excelyearfield               importmassmappingheader.ime_excelfieldname%TYPE;
      l_excelfields                  VARCHAR2 (256);
      l_listline                     VARCHAR2 (1024);
      l_error                        BOOLEAN := FALSE;
   BEGIN
      IF    p_recimportmassdataheader.imh_day IS NULL
         OR p_recimportmassdataheader.imh_month IS NULL
         OR p_recimportmassdataheader.imh_year IS NULL
      THEN
         IF NOT p_recimportmassdataheader.imh_year IS NULL
         THEN
            l_year :=
               pkg_datatype.f_validateinteger (
                  p_recimportmassdataheader.imh_year);

            IF    l_year IS NULL
               OR l_year < 1900
               OR l_year > EXTRACT (YEAR FROM SYSDATE)
            THEN
               l_error := TRUE;
            END IF;
         END IF;

         IF NOT p_recimportmassdataheader.imh_month IS NULL
         THEN
            l_month :=
               pkg_datatype.f_validateinteger (
                  p_recimportmassdataheader.imh_month);

            IF l_month IS NULL OR l_month < 1 OR l_month > 12
            THEN
               l_error := TRUE;
            END IF;
         END IF;

         IF NOT p_recimportmassdataheader.imh_day IS NULL
         THEN
            l_day :=
               pkg_datatype.f_validateinteger (
                  p_recimportmassdataheader.imh_day);

            IF l_day IS NULL OR l_day < 1 OR l_day > 31
            THEN
               l_error := TRUE;
            END IF;
         END IF;

         IF NOT l_error AND l_month IS NULL AND NOT l_day IS NULL
         THEN
            l_error := TRUE;
         END IF;

         IF l_error
         THEN
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            l_recimportmassmappingheader :=
               pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                  p_recimportmassdataheader.imh_iph_id,
                  pkg_codevalue.cst_midatfldcmt_day);
            l_exceldayfield := l_recimportmassmappingheader.ime_excelfieldname;

            l_recimportmassmappingheader :=
               pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                  p_recimportmassdataheader.imh_iph_id,
                  pkg_codevalue.cst_midatfldcmt_month);
            l_excelmonthfield :=
               l_recimportmassmappingheader.ime_excelfieldname;
            l_recimportmassmappingheader :=
               pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                  p_recimportmassdataheader.imh_iph_id,
                  pkg_codevalue.cst_midatfldcmt_year);
            l_excelyearfield :=
               l_recimportmassmappingheader.ime_excelfieldname;
            l_excelfields :=
                  l_exceldayfield
               || '/'
               || l_excelmonthfield
               || '/'
               || l_excelyearfield;

            l_datetxt :=
               pkg_importmassdataheader.f_builddatetxt (
                  p_recimportmassdataheader);

            l_swisscoord :=
               pkg_importmassdataheader.f_buildswisscoord (
                  p_recimportmassdataheader);
            l_listline :=
               pkg_importmassdatadetail.f_buildsourceline (
                  p_recimportmassdataheader.imh_id);
            pkg_importprotocollog.p_writelog (
               p_recimportmassdataheader.imh_iph_id,
               NULL,
               pkg_exception.cst_collectdateinvalide,
               'IMH_DAY, IMH_MONTH, IMH_YEAR',
               l_datetxt,
               l_swisscoord,
               l_excelfields,
               l_listline);
         END IF;
      END IF;

      NULL;
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_checkcollecteddate (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      l_date                         DATE;
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
      l_recimportprotocolheader      importprotocolheader%ROWTYPE;
      l_datetxt                      VARCHAR2 (256);
      l_swisscoord                   VARCHAR2 (256);
      l_exceldayfield                importmassmappingheader.ime_excelfieldname%TYPE;
      l_excelmonthfield              importmassmappingheader.ime_excelfieldname%TYPE;
      l_excelyearfield               importmassmappingheader.ime_excelfieldname%TYPE;
      l_excelfields                  VARCHAR2 (256);
      cst_exception         CONSTANT NUMBER
         := pkg_exception.cst_collectdateinvalide ;
      l_listline                     VARCHAR2 (1024);
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      IF    p_recimportmassdataheader.imh_day IS NULL
         OR p_recimportmassdataheader.imh_month IS NULL
         OR p_recimportmassdataheader.imh_year IS NULL
      THEN
         RETURN;
      END IF;

      l_date :=
         pkg_datatype.f_validatedate (p_recimportmassdataheader.imh_day,
                                      p_recimportmassdataheader.imh_month,
                                      p_recimportmassdataheader.imh_year);

      IF l_date IS NULL
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_recimportmassdataheader.imh_iph_id,
               pkg_codevalue.cst_midatfldcmt_day);
         l_exceldayfield := l_recimportmassmappingheader.ime_excelfieldname;

         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_recimportmassdataheader.imh_iph_id,
               pkg_codevalue.cst_midatfldcmt_month);
         l_excelmonthfield := l_recimportmassmappingheader.ime_excelfieldname;
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_recimportmassdataheader.imh_iph_id,
               pkg_codevalue.cst_midatfldcmt_year);
         l_excelyearfield := l_recimportmassmappingheader.ime_excelfieldname;
         l_excelfields :=
               l_exceldayfield
            || '/'
            || l_excelmonthfield
            || '/'
            || l_excelyearfield;

         l_datetxt :=
            pkg_importmassdataheader.f_builddatetxt (
               p_recimportmassdataheader);

         l_swisscoord :=
            pkg_importmassdataheader.f_buildswisscoord (
               p_recimportmassdataheader);
         l_listline :=
            pkg_importmassdatadetail.f_buildsourceline (
               p_recimportmassdataheader.imh_id);



         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            NULL,
            pkg_exception.cst_collectdateinvalide,
            'IMH_DAY, IMH_MONTH, IMH_YEAR',
            l_datetxt,
            l_swisscoord,
            l_excelfields,
            l_listline);
      END IF;

      p_returnstatus := pkg_constante.cst_returnstatusok;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checkstartpoint_x (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      /* A ce niveau startpoint_x est renseigné car il fait partie de la clé.
         Pas besoin de contrôle à ce niveau */
      l_number                       NUMBER;
      l_datetxt                      VARCHAR2 (256);
      l_swisscoord                   VARCHAR2 (256);
      l_excelfield                   VARCHAR2 (256);
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
      l_module                       VARCHAR2 (256);
      l_listline                     VARCHAR2 (1024);
   BEGIN
      l_number :=
         pkg_datatype.f_validatedouble (
            p_recimportmassdataheader.imh_startpoint_x);

      IF NOT l_number IS NULL
      THEN
         l_number :=
            pkg_datatype.f_validateswisscoordx (
               p_recimportmassdataheader.imh_startpoint_x);

         IF NOT l_number IS NULL
         THEN
            RETURN;
         END IF;
      END IF;

      p_setcoordinatesstatus (FALSE);
      l_datetxt :=
         pkg_importmassdataheader.f_builddatetxt (p_recimportmassdataheader);

      l_swisscoord :=
         pkg_importmassdataheader.f_buildswisscoord (
            p_recimportmassdataheader);
      l_recimportmassmappingheader :=
         pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
            p_recimportmassdataheader.imh_iph_id,
            pkg_codevalue.cst_midatfldcmt_swiss_x);

      IF l_recimportmassmappingheader.ime_id IS NULL
      THEN
         l_module :=
               'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
            || TO_CHAR (p_recimportmassdataheader.imh_iph_id)
            || ','''
            || pkg_codevalue.cst_midatfldcmt_swiss_x
            || ''')';
         pkg_importprotocollog.p_logunexpectederror (
            p_recimportmassdataheader.imh_iph_id,
            'IMH_STARTPOINT_X',
            l_module);
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;

      l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;

      l_listline :=
         pkg_importmassdatadetail.f_buildsourceline (
            p_recimportmassdataheader.imh_id);

      pkg_importprotocollog.p_writelog (
         p_recimportmassdataheader.imh_iph_id,
         NULL,
         pkg_exception.cst_massnumvalueinvalid,
         pkg_codevalue.cst_midatfldcmt_swiss_x,
         pkg_codevalue.cst_midatfldcmt_swiss_x,                          -- P1
         pkg_datatype.cst_swisscoordinate_x_min,
         pkg_datatype.cst_swisscoordinate_x_max,
         p_recimportmassdataheader.imh_startpoint_x,
         l_listline,
         l_datetxt,
         l_swisscoord,
         l_excelfield);
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checkstartpoint_y (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      /* A ce niveau startpoint_y est renseigné car il fait partie de la clé.
         Pas besoin de contrôle à ce niveau */
      l_number                       NUMBER;
      l_datetxt                      VARCHAR2 (256);
      l_swisscoord                   VARCHAR2 (256);
      l_excelfield                   VARCHAR2 (256);
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
      l_module                       VARCHAR2 (256);
      l_listline                     VARCHAR2 (1024);
   BEGIN
      l_number :=
         pkg_datatype.f_validatedouble (
            p_recimportmassdataheader.imh_startpoint_y);

      IF NOT l_number IS NULL
      THEN
         l_number :=
            pkg_datatype.f_validateswisscoordy (
               p_recimportmassdataheader.imh_startpoint_y);

         IF NOT l_number IS NULL
         THEN
            RETURN;
         END IF;
      END IF;

      p_setcoordinatesstatus (FALSE);
      l_datetxt :=
         pkg_importmassdataheader.f_builddatetxt (p_recimportmassdataheader);

      l_swisscoord :=
         pkg_importmassdataheader.f_buildswisscoord (
            p_recimportmassdataheader);
      l_recimportmassmappingheader :=
         pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
            p_recimportmassdataheader.imh_iph_id,
            pkg_codevalue.cst_midatfldcmt_swiss_y);

      IF l_recimportmassmappingheader.ime_id IS NULL
      THEN
         l_module :=
               'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
            || TO_CHAR (p_recimportmassdataheader.imh_iph_id)
            || ','''
            || pkg_codevalue.cst_midatfldcmt_swiss_y
            || ''')';
         pkg_importprotocollog.p_logunexpectederror (
            p_recimportmassdataheader.imh_iph_id,
            'IMH_STARTPOINT_Y',
            l_module);
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;

      l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;
      l_listline :=
         pkg_importmassdatadetail.f_buildsourceline (
            p_recimportmassdataheader.imh_id);


      pkg_importprotocollog.p_writelog (
         p_recimportmassdataheader.imh_iph_id,
         NULL,
         pkg_exception.cst_massnumvalueinvalid,
         pkg_codevalue.cst_midatfldcmt_swiss_y,
         pkg_codevalue.cst_midatfldcmt_swiss_y,                          -- P1
         pkg_datatype.cst_swisscoordinate_y_min,
         pkg_datatype.cst_swisscoordinate_y_max,
         p_recimportmassdataheader.imh_startpoint_y,
         l_listline,
         l_datetxt,
         l_swisscoord,
         l_excelfield);
   END;

   /*-----------------------------------------------------------------------------*/
   PROCEDURE p_validatestationright (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_usr_id                    IN     importprotocolheader.iph_usr_id_create%TYPE,
      p_returnstatus                 OUT NUMBER)
   /*-------------------------------------------------------------------------------*/
   IS
      l_x                    NUMBER;
      l_y                    NUMBER;
      l_rightaccess          NUMBER;
      l_coordinates          SDO_GEOMETRY;
      l_recch_canton         ch_canton%ROWTYPE;
      l_reccodesesignation   codedesignation%ROWTYPE;
      l_reccodevalue         codevalue%ROWTYPE;
      l_cantonfound          BOOLEAN := TRUE;
      l_distance             NUMBER;
      l_outofborder          BOOLEAN := FALSE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      IF NOT f_getcoordinatesstatus
      THEN
         RETURN;
      END IF;

      l_x :=
         pkg_datatype.f_validatedouble (
            p_recimportmassdataheader.imh_startpoint_x);
      l_y :=
         pkg_datatype.f_validatedouble (
            p_recimportmassdataheader.imh_startpoint_y);
      l_coordinates := pkg_sdoutil.f_buildsdo_geometry (l_x, l_y);
      pkg_ch_canton.p_findcontaincanton (l_coordinates, l_recch_canton);

      IF l_recch_canton.code IS NULL
      THEN
         -- Les coordonnées fournies (%p1%) pour la station %p2% ne permettent pas d'identifier le canton
         l_outofborder := TRUE;
         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            p_recimportmassdataheader.imh_id,
            pkg_exception.cst_coordoutofswissboundary,
            NULL,
            TO_CHAR (l_x) || ';' || TO_CHAR (l_y),
            p_recimportmassdataheader.imh_oid);

         pkg_ch_canton.p_findnearcanton (l_coordinates,
                                         l_recch_canton,
                                         l_distance);
         l_distance:= ROUND(l_distance,2);
         IF l_distance > pkg_codevalue.f_get_midatparam_rayoncnt
         THEN
            -- La frontière cantonale la plus proche "f$returncanton#1(%p1%)" se trouve a une distance de %p2% mètres. Cette distance est plus grande que le rayon de tolérance de %p3% mètres.
            l_cantonfound := FALSE;
            pkg_importprotocollog.p_writelog (
               p_recimportmassdataheader.imh_iph_id,
               NULL,
               pkg_exception.cst_cantonoutoftoleranceradius,
               NULL,
               l_recch_canton.code,
               ROUND (l_distance, 2),
               pkg_codevalue.f_get_midatparam_rayoncnt);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
         ELSE
            -- Le canton "f$returncanton#1(%p1%)" est le plus proche de la coordonnées fournies (%p2%) pour la station %p3%. La frontière avec ce canton se situe à une distance de %p4% mètres. Cette distance se situe dans la tolérance admise de %p5% mètres
            pkg_importprotocollog.p_writelog (
               p_recimportmassdataheader.imh_iph_id,
               NULL,
               pkg_exception.cst_sampleassociatedtocanton,
               NULL,
               l_recch_canton.code,
               TO_CHAR (l_x) || ';' || TO_CHAR (l_y),
               p_recimportmassdataheader.imh_oid,
              TO_CHAR( l_distance,'999990.99'),
               pkg_codevalue.f_get_midatparam_rayoncnt);
            l_reccodevalue :=
               pkg_codevalue.f_getfromcode (
                  pkg_codevalue.cst_canton_outofborder,
                  pkg_codereference.cst_crf_canton);
            pkg_importmassdataheader.p_update_imh_cvl_id_canton (
               p_recimportmassdataheader.imh_id,
               l_reccodevalue.cvl_id,
               p_usr_id);
         END IF;
      ELSE
         l_reccodevalue :=
            pkg_codevalue.f_getfromcode (l_recch_canton.code,
                                         pkg_codereference.cst_crf_canton);
         pkg_importmassdataheader.p_update_imh_cvl_id_canton (
            p_recimportmassdataheader.imh_id,
            l_reccodevalue.cvl_id,
            p_usr_id);
      END IF;



      pkg_rightutility_v2.p_checkwriteright (l_x,
                                          l_y,
                                          p_usr_id,
                                          l_rightaccess);

      IF l_rightaccess = pkg_rightutility_v2.cst_rightaccessdenied
      THEN
         --La coordonnée géographique (%p1%) de la station %p2% se situe dans le canton de  f$returncanton#1(%p3%). Vous n'avez pas le droit d'enregistrer des données dans ce canton.

         l_coordinates := pkg_sdoutil.f_buildsdo_geometry (l_x, l_y);
         pkg_ch_canton.p_findcontaincanton (l_coordinates, l_recch_canton);
         pkg_importprotocollog.p_writelog (
            p_recimportmassdataheader.imh_iph_id,
            p_recimportmassdataheader.imh_id,
            pkg_exception.cst_noprivilegetoinsertstation,
            NULL,
            TRIM (TO_CHAR (l_x) || ', ' || TO_CHAR (l_y)),
            p_recimportmassdataheader.imh_oid,
            l_recch_canton.code);
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
      ELSE
         -- Les coordonnées géographiques (%p1%) de la station %p2% se trouvent dans le canton de f$returncanton#1(%p3%)
         IF NOT l_outofborder
         THEN
            pkg_importprotocollog.p_writelog (
               p_recimportmassdataheader.imh_iph_id,
               p_recimportmassdataheader.imh_id,
               pkg_exception.cst_infocanton,
               NULL,
               TRIM (TO_CHAR (l_x) || ', ' || TO_CHAR (l_y)),
               NVL (p_recimportmassdataheader.imh_oid, '***Auto def***'),
               l_recch_canton.code);
         END IF;
      END IF;
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_checkelevation (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      l_datetxt                      VARCHAR2 (256);
      l_swisscoord                   VARCHAR2 (256);
      l_excelfield                   VARCHAR2 (256);
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
      l_module                       VARCHAR2 (256);
      l_listline                     VARCHAR2 (1024);
      l_elevation                    NUMBER;
      l_returnstatus                 NUMBER;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;



      l_elevation :=
         pkg_datatype.f_validatedouble (
            p_recimportmassdataheader.imh_elevation);

      IF NOT l_elevation IS NULL
      THEN
         l_elevation :=
            pkg_datatype.f_validateswisselev (
               p_recimportmassdataheader.imh_elevation);

         IF l_elevation IS NULL
         THEN
            l_datetxt :=
               pkg_importmassdataheader.f_builddatetxt (
                  p_recimportmassdataheader);

            l_swisscoord :=
               pkg_importmassdataheader.f_buildswisscoord (
                  p_recimportmassdataheader);
            l_recimportmassmappingheader :=
               pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                  p_recimportmassdataheader.imh_iph_id,
                  pkg_codevalue.cst_midatfldcmt_swiss_z);

            IF l_recimportmassmappingheader.ime_id IS NULL
            THEN
               l_module :=
                     'pkg_importmassmappingheader.f_getrecordbymidatfldcnt ('
                  || TO_CHAR (p_recimportmassdataheader.imh_iph_id)
                  || ','''
                  || pkg_codevalue.cst_midatfldcmt_swiss_z
                  || ''')';
               pkg_importprotocollog.p_logunexpectederror (
                  p_recimportmassdataheader.imh_iph_id,
                  'IMH_ELEVATION',
                  l_module);
               p_returnstatus := pkg_constante.cst_returnstatusnotok;
               RETURN;
            END IF;

            l_excelfield := l_recimportmassmappingheader.ime_excelfieldname;
            l_listline :=
               pkg_importmassdatadetail.f_buildsourceline (
                  p_recimportmassdataheader.imh_id);


            pkg_importprotocollog.p_writelog (
               p_recimportmassdataheader.imh_iph_id,
               NULL,
               pkg_exception.cst_massnumvalueinvalid,
               pkg_codevalue.cst_midatfldcmt_swiss_z,
               pkg_codevalue.cst_midatfldcmt_swiss_z,                    -- P1
               pkg_datatype.cst_swisscoordinate_z_min,
               pkg_datatype.cst_swisscoordinate_z_max,
               p_recimportmassdataheader.imh_elevation,
               l_listline,
               l_datetxt,
               l_swisscoord,
               l_excelfield);
         END IF;
      END IF;
   END;



   /*----------------------------------------------------------------------*/
   PROCEDURE p_validateoneheader (
      p_recimportmassdataheader   IN     importmassdataheader%ROWTYPE,
      p_usr_id                    IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id                    IN     language.lan_id%TYPE,
      p_returnstatus                 OUT NUMBER)
   /*-----------------------------------------------------------------------*/
   IS
      l_returnstatus       NUMBER;
      l_returnstatussave   NUMBER;
      l_remarknumber       NUMBER := 0;
   BEGIN
      p_setcoordinatesstatus (TRUE);
      p_checkcollecteddate (p_recimportmassdataheader, l_returnstatus);
      p_checkcollecteddatesplit (p_recimportmassdataheader, l_returnstatus);
      l_returnstatussave := l_returnstatus;
      p_checkstartpoint_x (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checkindicetype (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;


      p_checkstartpoint_y (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_validatestationright (p_recimportmassdataheader,
                              p_usr_id,
                              l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checkelevation (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checklocality (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checkwatercourse (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checkcalledplace (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checkobservers (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checksystemprecision (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checkoid (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checkreporturl (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checkcomment (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      l_remarknumber := 1;

      WHILE l_remarknumber <= 4
      LOOP
         p_checkremarkcode (p_recimportmassdataheader,
                            l_remarknumber,
                            l_returnstatus);

         IF l_returnstatus != pkg_constante.cst_returnstatusok
         THEN
            l_returnstatussave := l_returnstatus;
         END IF;

         l_remarknumber := l_remarknumber + 1;
      END LOOP;

      p_checkremarktext (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checkoidlink (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checkdeterminator (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;

      p_checkproject (p_recimportmassdataheader, l_returnstatus);

      IF l_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         l_returnstatussave := l_returnstatus;
      END IF;


      p_returnstatus := l_returnstatussave;
   END;

   /*----------------------------------------------------------------------------------*/
   PROCEDURE p_valideallheader (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*----------------------------------------------------------------------------------*/
   IS
      CURSOR l_curimportmassdataheader
      IS
         SELECT *
           FROM importmassdataheader
          WHERE     imh_iph_id = p_iph_id
                AND imh_validstatus != pkg_constante.cst_validstatusnotok;

      l_recimportmassdataheader   l_curimportmassdataheader%ROWTYPE;
      l_returnstatus              NUMBER;
      l_returnstatussave          NUMBER;
      l_starttime                 TIMESTAMP;
      l_recordcount               NUMBER := 0;
      l_importprotocolheader      importprotocolheader%ROWTYPE;
      l_totalcount                NUMBER := 0;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      SELECT COUNT (*)
        INTO l_totalcount
        FROM importmassdataheader
       WHERE     imh_iph_id = p_iph_id
             AND imh_validstatus != pkg_constante.cst_validstatusnotok;

      l_importprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);

      l_starttime := SYSTIMESTAMP;
      pkg_importprotocollog.p_logstartsubprocess (
         p_iph_id,
         NULL,
         pkg_exception.cst_midatstartbuildheader);



      OPEN l_curimportmassdataheader;

      LOOP
         FETCH l_curimportmassdataheader INTO l_recimportmassdataheader;

         EXIT WHEN l_curimportmassdataheader%NOTFOUND;
         l_recordcount := l_recordcount + 1;

         pkg_processingstatus.p_setstatusbar (l_recordcount, l_totalcount);
         p_validateoneheader (l_recimportmassdataheader,
                              p_usr_id,
                              p_lan_id,
                              l_returnstatus);

         IF l_returnstatus != pkg_constante.cst_returnstatusok
         THEN
            pkg_importmassdataheader.p_setvalidstatus (
               l_recimportmassdataheader.imh_id,
               pkg_constante.cst_validstatusnotok);
            l_returnstatussave := l_returnstatus;
         END IF;
      END LOOP;

      CLOSE l_curimportmassdataheader;

      pkg_processingsteplog.p_setmeasuredata (
         l_recordcount,
         pkg_processingsteplog.cst_measureunitrowcount);
      pkg_importprotocollog.p_logendsubprocess (
         p_iph_id,
         NULL,
         pkg_exception.cst_midatendbuildheader,
         l_starttime,
         l_recordcount);



      l_recordcount :=
         pkg_importmassdataheader.f_countrowsstatuspending (p_iph_id);

      IF l_recordcount = 0
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
      END IF;

      NULL;
   END;
END pkg_validatemassheaderfield;
/

