create procedure ens(x number) as language java name 
'oracle.aurora.vm.OracleRuntime.enableNewspace(boolean)';
/

