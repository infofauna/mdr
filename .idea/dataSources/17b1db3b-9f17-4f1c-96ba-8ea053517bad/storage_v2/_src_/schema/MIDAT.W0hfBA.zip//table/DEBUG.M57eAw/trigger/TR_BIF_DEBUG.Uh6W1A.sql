create trigger TR_BIF_DEBUG
    before insert
    on DEBUG
    for each row
DECLARE
   l_newrec   debug%ROWTYPE;

BEGIN
  
   l_newrec.dbg_id := :new.dbg_id;
   l_newrec.dbg_module := :new.dbg_module;
   l_newrec.dbg_text := :new.dbg_text;
   l_newrec.dbg_credate := :new.dbg_credate;
   l_newrec.dbg_creuser := :new.dbg_creuser;
   l_newrec.dbg_moddate := :new.dbg_moddate;
   l_newrec.dbg_moduser := :new.dbg_moduser;

   pkg_debug.p_tr_bif_debug (l_newrec);

   :new.dbg_id := l_newrec.dbg_id;
   :new.dbg_module := l_newrec.dbg_module;
   :new.dbg_text := l_newrec.dbg_text;
   :new.dbg_credate := l_newrec.dbg_credate;
   :new.dbg_creuser := l_newrec.dbg_creuser;
   :new.dbg_moddate := l_newrec.dbg_moddate;
   :new.dbg_moduser := l_newrec.dbg_moduser;
END;

/

