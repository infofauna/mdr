create trigger TR_BUF_PROTOCOLMAPPINGGRID
    before update
    on PROTOCOLMAPPINGGRID
    for each row
DECLARE
BEGIN
 
   :new.PMG_moddate := SYSDATE;
   :new.PMG_moduser := USER;
END tr_buf_PROTOCOLMAPPINGGRID;

/

