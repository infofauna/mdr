create trigger TR_BIF_SAMPLESTATIONITEM
    before insert
    on SAMPLESTATIONITEM
    for each row
DECLARE
BEGIN
   IF :new.SSI_id IS NULL
   THEN
      :new.SSI_id := seq_SAMPLESTATIONITEM.NEXTVAL;
   END IF;

   :new.SSI_credate := SYSDATE;
   :new.SSI_creuser := USER;
END tr_bif_SAMPLESTATIONITEM;

/

