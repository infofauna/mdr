create PACKAGE BODY       pkg_protocolversion
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLVERSION
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;


   /*-------------------------------------------------------------*/
   FUNCTION f_returnlistversion (
      p_cvl_id_protocoltype   IN protocolversion.ptv_cvl_id_protocoltype%TYPE)
      /*-------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
      CURSOR l_listversion
      IS
         SELECT *
           FROM protocolversion
          WHERE ptv_cvl_id_protocoltype = p_cvl_id_protocoltype;

      l_reclistversion   l_listversion%ROWTYPE;
      l_list             VARCHAR2 (2048) := NULL;
   BEGIN
      OPEN l_listversion;

      LOOP
         FETCH l_listversion INTO l_reclistversion;

         EXIT WHEN l_listversion%NOTFOUND;

         IF l_list is null
         THEN
            l_list := l_reclistversion.ptv_version;
         ELSE
            l_list := l_list || '; ' || l_reclistversion.ptv_version;
         END IF;
      END LOOP;

      CLOSE l_listversion;
      return l_list;
   END;


   /*-------------------------------------------------------------*/
   FUNCTION f_countprotocoltype (
      p_cvl_id_protocoltype   IN protocolversion.ptv_cvl_id_protocoltype%TYPE)
      RETURN NUMBER
   /*--------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM protocolversion
       WHERE ptv_cvl_id_protocoltype = p_cvl_id_protocoltype;

      RETURN l_count;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_split_version (p_version      IN     VARCHAR2,
                              p_master          OUT NUMBER,
                              p_subversion      OUT NUMBER)
   /*-------------------------------------------------------------*/
   IS
      l_colon   PLS_INTEGER;
   BEGIN
      l_colon := INSTR (p_version, '.');
      p_master := TO_NUMBER (SUBSTR (p_version, 1, l_colon - 1));
      p_subversion := TO_NUMBER (SUBSTR (p_version, l_colon + 1));
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN;
   END;


   /*------------------------------------------------------------*/
   FUNCTION f_getrecord (p_ptv_id IN protocolversion.ptv_id%TYPE)
      RETURN protocolversion%ROWTYPE
   /*------------------------------------------------------------*/
   IS
      l_record   protocolversion%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM protocolversion
       WHERE ptv_id = p_ptv_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------------------------------------*/
   PROCEDURE p_updatefiletemplate (p_ptv_id         IN protocolversion.ptv_id%TYPE,
                                   p_directoryref   IN VARCHAR2,
                                   p_filename       IN VARCHAR2)
   /*---------------------------------------------------------------------------------------------*/
   IS
      l_blob      BLOB;

      l_fichier   BFILE := BFILENAME (p_directoryref, p_filename);
      l_lobd      INTEGER;
   BEGIN
      -- Obtain the size of the blob file
      DBMS_LOB.fileopen (l_fichier, DBMS_LOB.file_readonly);
      l_lobd := DBMS_LOB.getlength (l_fichier);
      DBMS_LOB.fileclose (l_fichier);

         -- Insert a new record into the table containing the
         -- filename you have specified and a LOB LOCATOR.
         -- Return the LOB LOCATOR and assign it to out_blob.
         UPDATE protocolversion
            SET ptv_filetemplate = EMPTY_BLOB ()
          WHERE ptv_id = p_ptv_id
      RETURNING ptv_filetemplate
           INTO l_blob;


      DBMS_LOB.open (l_fichier, DBMS_LOB.lob_readonly);
      DBMS_LOB.open (l_blob, DBMS_LOB.lob_readwrite);
      DBMS_LOB.loadfromfile (l_blob, l_fichier, l_lobd);

      -- Close handles to blob and file
      DBMS_LOB.close (l_blob);
      DBMS_LOB.close (l_fichier);
      COMMIT;
   END;



   /*-----------------------------------------------------------------------------------*/
   PROCEDURE p_updatepvtidlobofrommass (
      p_ptv_id                IN protocolversion.ptv_id%TYPE,
      p_ptv_id_labofrommass   IN protocolversion.ptv_ptv_id_labofrommass%TYPE)
   /*----------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE protocolversion
         SET ptv_ptv_id_labofrommass = p_ptv_id_labofrommass
       WHERE ptv_id = p_ptv_id;
   END;
END pkg_protocolversion;
/

