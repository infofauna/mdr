create PACKAGE       pkg_migr_v2
AS
   /******************************************************************************
      NAME:       PKG_MIGR_V2
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.07.2017      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_update_shf_iph_id;

   PROCEDURE p_update_sst_cvl_id_canton;

   PROCEDURE p_update_sph_prj_id;

   PROCEDURE p_updateelevation;

   PROCEDURE p_update_sph_indiceversion;
END pkg_migr_v2;
/

