create PACKAGE BODY       pkg_processingstatus
AS
   /******************************************************************************

      NAME:       PKG_PROCESSINGSTATUS

      PURPOSE:



      REVISIONS:

      Ver        Date        Author           Description

      ---------  ----------  ---------------  ------------------------------------

      1.0        11.10.2013      burrif       1. Created this package.

   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;
   gbl_currentstep               VARCHAR2 (12);
   gbl_currentmessage            processingstatus.pid_currentstep%TYPE;
   gbl_messagehasparameter       BOOLEAN := FALSE;
   gbl_statusbartotalrows        NUMBER;
   gbl_statusbarprocessedrows    NUMBER;
   gbl_lan_id                    language.lan_id%TYPE;
   gbl_usr_id                    processingstatus.pid_usr_id%TYPE;
   gbl_barstatusdisplaylimit     NUMBER
      := pkg_processingstatus.cst_statusbardisplaylimit;
   gbl_pid_id                    processingstatus.pid_id%TYPE;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/

      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_cleargbl
   /*-----------------------------------------------------------------*/
   IS
   BEGIN
      gbl_currentstep := NULL;
      gbl_currentmessage := NULL;
      gbl_messagehasparameter := FALSE;
      gbl_statusbartotalrows := NULL;
      gbl_statusbarprocessedrows := NULL;
      gbl_lan_id := NULL;
      gbl_usr_id := NULL;
      gbl_barstatusdisplaylimit :=
         pkg_processingstatus.cst_statusbardisplaylimit;
      gbl_pid_id := NULL;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_setbarstatusdisplaylimit (p_barstatusdisplaylimit IN NUMBER)
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      gbl_barstatusdisplaylimit := p_barstatusdisplaylimit;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_resetbarstatusdisplaylimit
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      gbl_barstatusdisplaylimit :=
         pkg_processingstatus.cst_statusbardisplaylimit;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_setstep (
      p_pid_id            IN processingstatus.pid_id%TYPE,
      p_currentstepcode   IN processingstep.psi_stepcode%TYPE,
      p_lan_id            IN language.lan_id%TYPE,
      p_usr_id            IN processingstatus.pid_usr_id_modify%TYPE)
   /*----------------------------------------------------------------*/
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
      l_recprocessingstep     processingstep%ROWTYPE;
      l_message               processingstatus.pid_currentstep%TYPE;
      l_fulltime              processingstatus.pid_secondstotal%TYPE;
      l_lefttime              processingstatus.pid_secondsleft%TYPE;
      l_percentdone           processingstatus.pid_percentprocessed%TYPE;
      l_recprocessingstatus   processingstatus%ROWTYPE;
   BEGIN
      l_recprocessingstatus := pkg_processingstatus.f_getrecord (gbl_pid_id);

      IF l_recprocessingstatus.pid_requestedabort = pkg_constante.cst_yes
      THEN
         raise_application_error (-20000, 'Process abort', TRUE);
      END IF;

      l_recprocessingstep :=
         pkg_processingstep.f_getrecordbystepcode (p_currentstepcode);

      l_message :=
         pkg_message.f_returnmessagetext (
            l_recprocessingstep.psi_errornumber,
            p_lan_id);
      gbl_currentmessage := l_message;
      -- On enlève le paramètre s'il y en a un. Le paramètre n'est utilisé que pas la procedure set status bar
      l_message := pkg_message.f_removeplaceholder (l_message, '%p1%');

      IF gbl_currentmessage != l_message
      THEN
         gbl_messagehasparameter := TRUE;
      ELSE
         gbl_messagehasparameter := FALSE;
      END IF;

      pkg_processingstep.p_computestatusbarmasterstep (p_currentstepcode,
                                                       l_fulltime,
                                                       l_lefttime,
                                                       l_percentdone);

      IF l_percentdone < 0 OR l_percentdone > 100
      THEN
         pkg_debug.p_write (
            'PKG_PROCESSINGSTATUS.p_setstep',
               'ERREUR: STEP='
            || gbl_currentstep
            || 'Fulltime='
            || l_fulltime
            || ' Lefttime='
            || l_lefttime
            || ' Percentdone='
            || l_percentdone);
         l_percentdone := 0;
      END IF;

      UPDATE processingstatus
         SET pid_currentstep = l_message,
             pid_secondstotal = l_fulltime,
             pid_secondsleft = l_lefttime,
             pid_percentprocessed = NVL (l_percentdone, 0),
             pid_usr_id_modify = p_usr_id,
             pid_usr_modify_date = SYSDATE
       WHERE pid_id = p_pid_id;


      gbl_lan_id := p_lan_id;
      gbl_usr_id := p_usr_id;


      COMMIT;
      pkg_processingsteplog.p_parsestep (l_recprocessingstep, p_pid_id);
   END;



   /*----------------------------------------------------------------*/
   PROCEDURE p_setstatusbar (p_rowsallreadyprocessed   IN NUMBER,
                             p_rowstotal               IN NUMBER)
   /*---------------------------------------------------------------*/
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
      l_message               processingstatus.pid_currentstep%TYPE;
      l_countertxt            VARCHAR2 (30);
      l_rowstotal             VARCHAR2 (20);
      l_fulltime              processingstatus.pid_secondstotal%TYPE;
      l_lefttime              processingstatus.pid_secondsleft%TYPE;
      l_percentdone           processingstatus.pid_percentprocessed%TYPE;
      l_recprocessingstatus   processingstatus%ROWTYPE;
   BEGIN
      l_recprocessingstatus := pkg_processingstatus.f_getrecord (gbl_pid_id);

      IF l_recprocessingstatus.pid_requestedabort = pkg_constante.cst_yes
      THEN
         raise_application_error (-20000, 'Process abort', TRUE);
      END IF;

      IF NOT gbl_messagehasparameter
      THEN
         RETURN;
      END IF;

      IF MOD (p_rowsallreadyprocessed, gbl_barstatusdisplaylimit) <> 0
      THEN
         RETURN;
      END IF;

      IF gbl_currentmessage IS NULL
      THEN
         RETURN;
      END IF;

      IF p_rowstotal IS NULL OR p_rowstotal = 0
      THEN
         l_rowstotal := '...';
      ELSE
         l_rowstotal := TO_CHAR (p_rowstotal);
      END IF;

      l_countertxt :=
            '('
         || TO_CHAR (p_rowsallreadyprocessed)
         || '/'
         || l_rowstotal
         || ')';
      pkg_message.p_setparameter (l_countertxt, 1);
      l_message := pkg_message.f_substituteparameter (gbl_currentmessage);

      pkg_processingstep.p_computestatusdetailstep (p_rowsallreadyprocessed,
                                                    p_rowstotal,
                                                    l_fulltime,
                                                    l_lefttime,
                                                    l_percentdone);

      IF l_percentdone < 0 OR l_percentdone > 100
      THEN
         pkg_debug.p_write (
            'PKG_PROCESSINGSTATUS.p_setstatusbar',
               'ERREUR: STEP='
            || gbl_currentstep
            || 'Fulltime='
            || l_fulltime
            || ' Lefttime='
            || l_lefttime
            || ' Percentdone='
            || l_percentdone);
         l_percentdone := 0;
      END IF;

      UPDATE processingstatus
         SET pid_currentstep = l_message,
             pid_secondstotal = l_fulltime,
             pid_secondsleft = l_lefttime,
             pid_percentprocessed = NVL (l_percentdone, 0),
             pid_usr_id_modify = gbl_usr_id,
             pid_usr_modify_date = SYSDATE
       WHERE pid_id = gbl_pid_id;

      COMMIT;
      NULL;
   END;



   /*---------------------------------------------------------------*/
   FUNCTION f_getrecord (p_pid_id IN processingstatus.pid_id%TYPE)
      RETURN processingstatus%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_record   processingstatus%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM processingstatus
       WHERE pid_id = p_pid_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_purgeby_iphheader (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE)
   /*------------------------------------------------------------------*/
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
      l_pid_id   processingstatus.pid_id%TYPE;
   BEGIN
      l_pid_id := p_recimportprotocolheader.iph_pid_id;

      IF l_pid_id IS NULL
      THEN
         RETURN;
      END IF;


      DELETE FROM processingstatus
            WHERE pid_id = l_pid_id;

      COMMIT;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_endprocessingstatus (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_usr_id                 IN processingstatus.pid_usr_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
      /* La valeur PID_EXTERNAL_ID fournie par l'interface WEB est déjà contenue dans IMPORTPROTOCOLHEADER */
      PRAGMA AUTONOMOUS_TRANSACTION;
      l_pid_id   processingstatus.pid_id%TYPE;
   BEGIN
      UPDATE processingstatus
         SET pid_endtimestamp = SYSTIMESTAMP,
             pid_elapsedtimetxt =
                pkg_stringutil.f_convertmilisecond (
                   pkg_stringutil.f_returnelapsedtime (SYSTIMESTAMP,
                                                       pid_starttimestamp)),
             pid_percentprocessed = 100,
             pid_secondsleft = 0,
             pid_usr_id_modify = p_usr_id,
             pid_usr_modify_date = SYSDATE
       WHERE pid_id = p_importprotocolheader.iph_pid_id;



      COMMIT;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_initprocessingstatus (
      p_external_id   IN processingstatus.pid_externalid%TYPE)
   /*-------------------------------------------------------------*/
   IS
      l_pid_id   processingstatus.pid_id%TYPE;
   BEGIN
      p_initprocessingstatus (p_external_id, l_pid_id);
   END;
   
      /*-------------------------------------------------------------*/
   PROCEDURE p_initprocessingstatus_v2 (
       p_pid_id           OUT processingstatus.pid_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
      l_pid_id   processingstatus.pid_id%TYPE;
   BEGIN
      p_initprocessingstatus (NULL, l_pid_id);
      p_pid_id:=l_pid_id;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_initprocessingstatus (
      p_external_id   IN     processingstatus.pid_externalid%TYPE,
      p_pid_id           OUT processingstatus.pid_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   -- permet d'initialiser ll'entrée pour le traitement asynchrone

   BEGIN
      pkg_processingstatus.p_cleargbl;
      pkg_processingstep.p_cleargbl;
      p_pid_id := seq_processingstatus.NEXTVAL;
      pkg_debug.p_write ('PKG_PROCESSINGSTATUS.p_initprocessingstatus',
                         'p_external_id=' || p_external_id);

      INSERT INTO processingstatus (pid_id,
                                    pid_externalid,
                                    pid_starttimestamp,
                                    pid_percentprocessed,
                                    pid_usr_create_date)
           VALUES (p_pid_id,
                   p_external_id,
                   SYSTIMESTAMP,
                   0,
                   SYSDATE);

      COMMIT;
      pkg_processingstep.p_clearlisttimestamp;

      gbl_currentstep := NULL;
      gbl_currentmessage := NULL;
      gbl_pid_id := p_pid_id;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getrecordbyexternalid (
      p_external_id   IN processingstatus.pid_externalid%TYPE)
      RETURN processingstatus%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_recprocessingstatus   processingstatus%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recprocessingstatus
        FROM processingstatus
       WHERE pid_externalid = p_external_id;

      RETURN l_recprocessingstatus;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*---------------------------------------------------------------*/
   PROCEDURE p_updateprocessingstatus (
      p_external_id   IN processingstatus.pid_externalid%TYPE,
      p_usr_id        IN processingstatus.pid_usr_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      UPDATE processingstatus
         SET pid_usr_id = p_usr_id, pid_usr_id_create = p_usr_id
       WHERE pid_externalid = p_external_id;

      COMMIT;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_updatenumberrecord (
      p_pid_id        IN processingstatus.pid_id%TYPE,
      p_recordcount   IN processingstatus.pid_numberrecord%TYPE,
      p_usr_id        IN processingstatus.pid_usr_id_modify%TYPE)
   /*----------------------------------------------------------------*/
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      UPDATE processingstatus
         SET pid_numberrecord = p_recordcount,
             pid_usr_id_modify = p_usr_id,
             pid_usr_modify_date = SYSDATE
       WHERE pid_id = p_pid_id;

      COMMIT;
   END;
END pkg_processingstatus;
/

