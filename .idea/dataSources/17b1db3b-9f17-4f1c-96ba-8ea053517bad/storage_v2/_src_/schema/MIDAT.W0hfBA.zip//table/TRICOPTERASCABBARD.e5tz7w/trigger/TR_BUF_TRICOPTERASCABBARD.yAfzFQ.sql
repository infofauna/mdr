create trigger TR_BUF_TRICOPTERASCABBARD
    before update
    on TRICOPTERASCABBARD
    for each row
DECLARE
BEGIN
 
   :new.TSD_moddate := SYSDATE;
   :new.TSD_moduser := USER;
END tr_buf_TRICOPTERASCABBARD;

/

