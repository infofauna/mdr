create PACKAGE BODY       pkg_rightutility_v2
AS
    /******************************************************************************
       NAME:       pkg_rightutility_v2
       PURPOSE:


       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        5.07.2018     burrif       1. Created this package.
    ******************************************************************************/



    cst_packageversion     CONSTANT VARCHAR2 (30)
                                        := 'Version 1.0, juillet 2018' ;
    cst_application_code   CONSTANT admin_application.apl_code%TYPE
        := pkg_admin_application.cst_application_midat ;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_displaylistgroup (
        p_listgroup   IN pkg_admin_user_role_group.t_listgroup)
    /*------------------------------------------------------------*/
    IS
        l_key   admin_group.agr_name%TYPE;
    BEGIN
        l_key := p_listgroup.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            DBMS_OUTPUT.put_line (
                   'L_KEY='
                || l_key
                || ' p_listgroup (l_key)='
                || p_listgroup (l_key));
            l_key := p_listgroup.NEXT (l_key);
        END LOOP;
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_displaylistcode (p_listcode IN pkg_ch_canton.t_listcode)
    /*------------------------------------------------------------*/
    IS
        l_key   VARCHAR2 (30);
    BEGIN
        l_key := p_listcode.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            DBMS_OUTPUT.put_line (
                   'l_key='
                || l_key
                || ' p_listcode (l_key)='
                || p_listcode (l_key));
            l_key := p_listcode.NEXT (l_key);
        END LOOP;
    END;

    /*------------------------------------------------------------*/
    FUNCTION f_buillistcodetxt (p_listcode IN pkg_ch_canton.t_listcode)
        RETURN VARCHAR2
    /*------------------------------------------------------------*/
    IS
        l_key    VARCHAR2 (30);
        l_text   VARCHAR2 (1024);
    BEGIN
        l_key := p_listcode.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            IF l_text IS NULL
            THEN
                l_text := l_key;
            ELSE
                l_text := l_text || ', ' || l_key;
            END IF;

            l_key := p_listcode.NEXT (l_key);
        END LOOP;

        RETURN l_text;
    END;

    /*------------------------------------------------------------*/
    FUNCTION f_buillistgroupwritetxt (
        p_listgroup   IN pkg_admin_user_role_group.t_listgroup)
        RETURN VARCHAR2
    /*------------------------------------------------------------*/
    IS
        l_key      admin_group.agr_name%TYPE;
        l_indice   PLS_INTEGER;
        l_text     VARCHAR2 (1024);
    BEGIN
        l_indice := p_listgroup.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            IF l_text IS NULL
            THEN
                l_text := p_listgroup (l_indice);
            ELSE
                l_text := l_text || ', ' || p_listgroup (l_indice);
            END IF;


            l_indice := p_listgroup.NEXT (l_indice);
        END LOOP;

        RETURN l_text;
    END;

    /*-------------------------------------------------------------*/
    FUNCTION f_checkinrolelist (
        p_rolelist   IN pkg_admin_user_role_group.t_listrole,
        p_role       IN VARCHAR2)
        RETURN BOOLEAN
    /*-------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_found    BOOLEAN := FALSE;
    BEGIN
        l_found := FALSE;
        l_indice := p_rolelist.FIRST;

        WHILE NOT l_indice IS NULL AND NOT l_found
        LOOP
            IF p_rolelist (l_indice) = p_role
            THEN
                l_found := TRUE;
            END IF;

            l_indice := p_rolelist.NEXT (l_indice);
        END LOOP;

        RETURN l_found;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_searchinlistgroup (
        p_listgroup   IN pkg_admin_user_role_group.t_listgroup,
        p_value       IN VARCHAR2)
        RETURN BOOLEAN
    /*---------------------------------------------------------------*/
    IS
        l_found    BOOLEAN := FALSE;
        l_indice   PLS_INTEGER;
    BEGIN
        l_indice := p_listgroup.FIRST;

        WHILE NOT l_indice IS NULL AND NOT l_found
        LOOP
            IF p_listgroup (l_indice) = p_value
            THEN
                l_found := TRUE;
            ELSE
                l_indice := p_listgroup.NEXT (l_indice);
            END IF;
        END LOOP;

        RETURN l_found;
    END;



    /*---------------------------------------------------------------*/
    FUNCTION f_checkmatchinggroup (
        p_listgroup   IN pkg_admin_user_role_group.t_listgroup,
        p_listcode    IN pkg_ch_canton.t_listcode)
        RETURN BOOLEAN
    /*---------------------------------------------------------------*/
    IS
        /* On compare la liste des GROUPES associées aux droits de l'utilisateur et celle des GROUP associé à la coordonnées */
        l_key      admin_group.agr_name%TYPE;
        l_found    BOOLEAN;
        l_return   VARCHAR2 (5);
    BEGIN
        l_found := FALSE;

        IF p_listgroup.COUNT = 0
        THEN
            RETURN false;
        END IF;

        DBMS_OUTPUT.put_line ('listgroup');
        p_displaylistgroup (p_listgroup);
        l_key := p_listcode.FIRST;

        WHILE NOT l_key IS NULL AND NOT l_found
        LOOP
            DBMS_OUTPUT.put_line ('L_KEY à trouver: ' || l_key);

            IF f_searchinlistgroup (p_listgroup, l_key)
            THEN
                l_found := TRUE;
                DBMS_OUTPUT.put_line ('FOUND IN listcode: ');
            ELSE
                l_key := p_listcode.NEXT (l_key);
            END IF;
        END LOOP;

        RETURN l_found;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_checkwriteright (
        p_x                  IN     NUMBER,
        p_y                  IN     NUMBER,
        p_usr_id             IN     sampleheader.sph_usr_id_create%TYPE,
        p_application_name   IN     admin_application.apl_code%TYPE,
        p_rightaccess           OUT NUMBER)
    /*---------------------------------------------------------------*/
    IS
        /*
        1) Le point est dans quel canton
        2) est ce que l'utilisateur est administateur de ce canton
        3) Est -ce que ce point est à moins de 3 km du canton ou la personne administre
       */
        l_coordinates          SDO_GEOMETRY;
        l_recch_canton         ch_canton%ROWTYPE;
        l_listcode             pkg_ch_canton.t_listcode;
        l_listrole             pkg_admin_user_role_group.t_listrole;
        l_listgroup            pkg_admin_user_role_group.t_listgroup;
        l_contributorfound     BOOLEAN;
        l_nationalwritefound   BOOLEAN;
        l_groupright           VARCHAR2 (5);
        l_apr_id               admin_role.apr_id%TYPE;
        l_rec_admin_role       admin_role%ROWTYPE;
        l_write BOOLEAN;
    BEGIN
        -- Est-ce que l'utilisateur dispose du droit USER
        IF NOT pkg_admin_user_role_group.f_hasrole (
                   p_usr_id,
                   pkg_admin_role.cst_admin_role_user,
                   p_application_name)
        THEN
            -- Pas de rôle USER, on sort
            p_rightaccess := pkg_rightutility_v2.cst_rightaccessdenied;
            RETURN;
        END IF;

        l_listrole :=
            pkg_admin_user_role_group.f_returnlistrole (p_usr_id,
                                                        p_application_name);


        l_rec_admin_role :=
            pkg_admin_role.f_getrecordbyname (
                pkg_admin_role.cst_admin_role_user,
                p_application_name);
        DBMS_OUTPUT.put_line (
            'l_rec_admin_role.apr_id=' || l_rec_admin_role.apr_id);

        -- Peut écrire mais dans quel canton
        l_listgroup :=
            pkg_admin_user_role_group.f_returnlistgroup (p_usr_id,
                                                         p_application_name,
                                                         TRUE);  -- p_writable
        p_displaylistgroup (l_listgroup);
        l_coordinates := pkg_sdoutil.f_buildsdo_geometry (p_x, p_y);
        l_listcode :=
            pkg_ch_canton.f_returncantonnearbuffer (
                l_coordinates,
                pkg_codevalue.f_get_midatparam_rayoncnt);
        p_displaylistcode (l_listcode);
        l_write := f_checkmatchinggroup (l_listgroup, l_listcode);

        IF l_write
        THEN
            p_rightaccess := pkg_rightutility_v2.cst_rightaccessok;
        ELSE
            p_rightaccess := pkg_rightutility_v2.cst_rightaccessdenied;
        END IF;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_checkcoordinateinlistgroup (
        p_x                  IN     NUMBER,
        p_y                  IN     NUMBER,
        p_usr_id             IN     sampleheader.sph_usr_id_create%TYPE,
        p_application_name   IN     admin_application.apl_code%TYPE,
        p_writable           IN     BOOLEAN,
        p_outoflist             OUT BOOLEAN)
    /*---------------------------------------------------------------*/
    IS
        l_listcode         pkg_ch_canton.t_listcode;
        l_listgroup        pkg_admin_user_role_group.t_listgroup;
        l_coordinates      SDO_GEOMETRY;
        l_reccanton        ch_canton%ROWTYPE;
        l_rec_admin_role   admin_role%ROWTYPE;
    BEGIN
        l_coordinates := pkg_sdoutil.f_buildsdo_geometry (p_x, p_y);
        l_rec_admin_role :=
            pkg_admin_role.f_getrecordbyname (
                pkg_admin_role.cst_admin_role_user,
                p_application_name);
        -- Le point se trouve dans quel canton
        pkg_ch_canton.p_findcontaincanton (l_coordinates, l_reccanton);
        -- Liste des canton concernées (y/c Buffer)
        l_listcode :=
            pkg_ch_canton.f_returncantonnearbuffer (
                l_coordinates,
                pkg_codevalue.f_get_midatparam_rayoncnt);
        -- Liste des groupes autorisés
        l_listgroup :=
            pkg_admin_user_role_group.f_returnlistgroup (p_usr_id,
                                                         p_application_name,
                                                         p_writable); -- p_writable

        IF NOT l_listgroup.EXISTS (l_reccanton.code)
        THEN
            p_outoflist := TRUE;
        ELSE
            p_outoflist := FALSE;
        END IF;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_checkcoordinateinlistgroup (
        p_x           IN     NUMBER,
        p_y           IN     NUMBER,
        p_usr_id      IN     sampleheader.sph_usr_id_create%TYPE,
        p_outoflist      OUT BOOLEAN)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        p_checkcoordinateinlistgroup (p_x,
                                      p_y,
                                      p_usr_id,
                                      cst_application_code,
                                      FALSE,                      --p_writable
                                      p_outoflist);
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_testcheckcoordinateinlistgrp
    /*---------------------------------------------------------------*/
    IS
        l_outoflist   BOOLEAN;
    BEGIN
        p_checkcoordinateinlistgroup (
            556160,                                                      --p_x
            224040,           --       224040,                          -- p_y
            1,                                                      --p_usr_id
            pkg_admin_application.cst_application_mds,
            TRUE,                                                -- p_writebla
            l_outoflist);

        IF l_outoflist
        THEN
            DBMS_OUTPUT.put_line ('Groupe  non défini');
        ELSE
            DBMS_OUTPUT.put_line ('Groupe défini');
        END IF;

        NULL;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_checkwriteright (
        p_x             IN     NUMBER,
        p_y             IN     NUMBER,
        p_usr_id        IN     sampleheader.sph_usr_id_create%TYPE,
        p_rightaccess      OUT NUMBER)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        p_checkwriteright (p_x,
                           p_y,
                           p_usr_id,
                           cst_application_code,
                           p_rightaccess);
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_testcheckwriteright
    /*------------------------------------------------------------*/
    IS
        l_x             NUMBER := 556160;                            --608200;
        l_y             NUMBER := 224040;                           -- 241000;
        l_usr_id        sampleheader.sph_usr_id_create%TYPE := 1;
        l_rightaccess   NUMBER;
    BEGIN
        p_checkwriteright (l_x,
                           l_y,
                           l_usr_id,
                           l_rightaccess);
        DBMS_OUTPUT.put_line ('l_rightaccess=' || l_rightaccess);
        NULL;
    END;

    /*------------------------------------------------------------*/
    FUNCTION f_returngrouprightlist (
        p_usr_id             IN sampleheader.sph_usr_id_create%TYPE,
        p_application_code   IN admin_application.apl_code%TYPE,
        p_writable           IN BOOLEAN)
        RETURN VARCHAR2
    /*-------------------------------------------------------------*/
    IS
        l_grouplist            VARCHAR2 (1024);
        l_listrole             pkg_admin_user_role_group.t_listrole;
        l_listgroup            pkg_admin_user_role_group.t_listgroup;
        l_listcode             pkg_ch_canton.t_listcode;
        l_userfound            BOOLEAN;
        l_nationalwritefound   BOOLEAN;
        l_groupfound           BOOLEAN;
        l_rec_admin_role       admin_role%ROWTYPE;
    BEGIN
        -- Est-ce que l'utilisateur dispose du droit


        l_listrole :=
            pkg_admin_user_role_group.f_returnlistrole (p_usr_id,
                                                        cst_application_code);



        l_userfound :=
            f_checkinrolelist (l_listrole,
                               pkg_admin_role.cst_admin_role_user);

        IF NOT l_userfound
        THEN         -- N'a pas le role user. N'a donc pas de droit d'écriture
            l_grouplist := '----------';
            RETURN l_grouplist;
        END IF;

        l_rec_admin_role :=
            pkg_admin_role.f_getrecordbyname (
                pkg_admin_role.cst_admin_role_user,
                cst_application_code);



        l_listgroup :=
            pkg_admin_user_role_group.f_returnlistgroup (p_usr_id,
                                                         p_application_code,
                                                         p_writable);
        l_grouplist := f_buillistgroupwritetxt (l_listgroup);

        IF l_grouplist IS NULL
        THEN
            l_grouplist := '----------';
        END IF;

        RETURN l_grouplist;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_testreturngrouprightlist
    /*---------------------------------------------------------------*/
    IS
        l_grouplist   VARCHAR2 (2024);
    BEGIN
        l_grouplist :=
            f_returngrouprightlist (
                1,
                pkg_admin_application.cst_application_midat,
                TRUE);
        DBMS_OUTPUT.put_line ('l_grouplist=' || l_grouplist);
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_test
    /*--------------------------------------------------------------*/
    IS
        l_reponse   NUMBER;
    BEGIN
        p_checkwriteright (600000,
                           200000,
                           1,
                           pkg_admin_application.cst_application_mds,
                           l_reponse);
        DBMS_OUTPUT.put_line ('L-reponse:=' || l_reponse);
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_testlist
    /*--------------------------------------------------------------*/
    IS
        l_text   VARCHAR2 (1024);
    BEGIN
        l_text :=
            f_returngrouprightlist (
                1,
                pkg_admin_application.cst_application_midat,
                TRUE);
        DBMS_OUTPUT.put_line ('l_text:=' || l_text);
    END;
END pkg_rightutility_v2;
/

