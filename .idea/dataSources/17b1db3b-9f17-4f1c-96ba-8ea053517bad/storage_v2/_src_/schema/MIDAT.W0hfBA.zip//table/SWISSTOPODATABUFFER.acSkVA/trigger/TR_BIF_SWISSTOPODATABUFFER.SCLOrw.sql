create trigger TR_BIF_SWISSTOPODATABUFFER
    before insert
    on SWISSTOPODATABUFFER
    for each row
DECLARE
BEGIN
   IF :new.SWB_id IS NULL
   THEN
      :new.SWB_id := seq_SWISSTOPODATABUFFER.NEXTVAL;
   END IF;

   :new.SWB_credate := SYSDATE;
   :new.SWB_creuser := USER;
END tr_bif_SWISSTOPODATABUFFER;

/

