create PACKAGE BODY       pkg_migr_protocolmappinggrnd
AS
   /******************************************************************************
      NAME:       pkg_migr_protocolmappinggrnd
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
      1.1        06.11.2013      burrif       2. Modification de la structure dans la rubrique végétation
   ******************************************************************************/


   cst_packageversion           CONSTANT VARCHAR2 (30)
                                            := 'Version 1.0, novembre  2013' ;


   cst_midatgrnd_ecomorph       CONSTANT codevalue.cvl_code%TYPE := 'ECOMORPH';
   cst_midatgrnd_algues         CONSTANT codevalue.cvl_code%TYPE := 'ALGUES';
   cst_midatgrnd_mousses        CONSTANT codevalue.cvl_code%TYPE := 'MOUSSES';
   cst_midatgrnd_macrophytes    CONSTANT codevalue.cvl_code%TYPE
                                            := 'MACROPHYTES' ;
   cst_midatgrnd_dechets        CONSTANT codevalue.cvl_code%TYPE := 'DECHETS';
   cst_midatgrnd_sacordure      CONSTANT codevalue.cvl_code%TYPE
                                            := 'SACORDURE' ;
   cst_midatgrnd_emballage      CONSTANT codevalue.cvl_code%TYPE
                                            := 'EMBALLAGE' ;
   cst_midatgrnd_largeurmoy     CONSTANT codevalue.cvl_code%TYPE
                                            := 'LARGEURMOY' ;
   cst_midatgrnd_aucun          CONSTANT codevalue.cvl_code%TYPE := 'AUCUN';
   cst_midatgrnd_enmetre        CONSTANT codevalue.cvl_code%TYPE := 'ENMETRE';
   cst_midatgrnd_misesousterr   CONSTANT codevalue.cvl_code%TYPE
                                            := 'MISESOUSTERR' ;
   cst_midatgrnd_nbreuxseuil    CONSTANT codevalue.cvl_code%TYPE
                                            := 'NBREUXSEUIL' ;
   cst_midatgrnd_varialit       CONSTANT codevalue.cvl_code%TYPE
                                            := 'VARIALIT' ;
   cst_midatgrnd_variaprof      CONSTANT codevalue.cvl_code%TYPE
                                            := 'VARIAPROF' ;
   cst_midatgrnd_amenfond       CONSTANT codevalue.cvl_code%TYPE
                                            := 'AMENFOND' ;
   cst_midatgrnd_matamenfond    CONSTANT codevalue.cvl_code%TYPE
                                            := 'MATAMENFOND' ;
   cst_midatgrnd_boismortfond   CONSTANT codevalue.cvl_code%TYPE
                                            := 'BOISMORTFOND' ;
   cst_midatgrnd_renforpied     CONSTANT codevalue.cvl_code%TYPE
                                            := 'RENFORPIED' ;
   cst_midatgrnd_permrenforg    CONSTANT codevalue.cvl_code%TYPE
                                            := 'PERMRENFORG' ;
   cst_midatgrnd_largeurrive    CONSTANT codevalue.cvl_code%TYPE
                                            := 'LARGEURRIVE' ;
   cst_midatgrnd_naturerive     CONSTANT codevalue.cvl_code%TYPE
                                            := 'NATURERIVE' ;
   cst_midatgrnd_aspectgen      CONSTANT codevalue.cvl_code%TYPE
                                            := 'ASPECTGEN' ;
   cst_midatgrnd_arthygieniq    CONSTANT codevalue.cvl_code%TYPE
                                            := 'ARTHYGIENIQ' ;

   cst_midatgrnd_papierwc       CONSTANT codevalue.cvl_code%TYPE
                                            := 'PAPIERWC' ;
   cst_midatgrnd_boue           CONSTANT codevalue.cvl_code%TYPE := 'BOUE';
   cst_midatgrnd_turbidite      CONSTANT codevalue.cvl_code%TYPE
                                            := 'TURBIDITE' ;
   cst_midatgrnd_coloration     CONSTANT codevalue.cvl_code%TYPE
                                            := 'COLORATION' ;
   cst_midatgrnd_mousse         CONSTANT codevalue.cvl_code%TYPE := 'MOUSSE';
   cst_midatgrnd_odeur          CONSTANT codevalue.cvl_code%TYPE := 'ODEUR';
   cst_midatgrnd_sulfurefer     CONSTANT codevalue.cvl_code%TYPE
                                            := 'SULFUREFER' ;
   cst_midatgrnd_colmatage      CONSTANT codevalue.cvl_code%TYPE
                                            := 'COLMATAGE' ;

   cst_midatgrnd_solide         CONSTANT codevalue.cvl_code%TYPE := 'SOLIDE';
   cst_midatgrnd_organisme      CONSTANT codevalue.cvl_code%TYPE
                                            := 'ORGANISME' ;
   cst_midatgrnd_vegetation     CONSTANT codevalue.cvl_code%TYPE
                                            := 'VEGETATION' ;
   cst_midatgrnd_infosup        CONSTANT codevalue.cvl_code%TYPE := 'INFOSUP';
   cst_midatgrnd_depechan       CONSTANT codevalue.cvl_code%TYPE
                                            := 'DEPECHAN' ;
   cst_midatgrnd_abansta        CONSTANT codevalue.cvl_code%TYPE := 'ABANSTA';
   cst_midatgrnd_adultcap       CONSTANT codevalue.cvl_code%TYPE
                                            := 'ADULTCAP' ;
   cst_midatgrnd_oui            CONSTANT codevalue.cvl_code%TYPE := 'OUI';
   cst_midatgrnd_non            CONSTANT codevalue.cvl_code%TYPE := 'NON';
   cst_midatgrnd_prononce       CONSTANT codevalue.cvl_code%TYPE
                                            := 'PRONONCE' ;
   cst_midatgrnd_limite         CONSTANT codevalue.cvl_code%TYPE := 'LIMITE';
   cst_midatgrnd_nulle          CONSTANT codevalue.cvl_code%TYPE := 'NULLE';
   cst_midatgrnd_nul            CONSTANT codevalue.cvl_code%TYPE := 'NUL';
   cst_midatgrnd_loc10          CONSTANT codevalue.cvl_code%TYPE := 'LOC10';
   cst_midatgrnd_peu            CONSTANT codevalue.cvl_code%TYPE := 'PEU';
   cst_midatgrnd_moy10_30       CONSTANT codevalue.cvl_code%TYPE
                                            := 'MOY10_30' ;
   cst_midatgrnd_imp30_60       CONSTANT codevalue.cvl_code%TYPE
                                            := 'IMP30_60' ;
   cst_midatgrnd_prepon60       CONSTANT codevalue.cvl_code%TYPE
                                            := 'PREPON60' ;
   cst_midatgrnd_total100       CONSTANT codevalue.cvl_code%TYPE
                                            := 'TOTAL100' ;
   cst_midatgrnd_empierenroch   CONSTANT codevalue.cvl_code%TYPE
                                            := 'EMPIERENROCH' ;
   cst_midatgrnd_autreimper     CONSTANT codevalue.cvl_code%TYPE
                                            := 'AUTREIMPER' ;
   cst_midatgrnd_amas           CONSTANT codevalue.cvl_code%TYPE := 'AMAS';
   cst_midatgrnd_dissemine      CONSTANT codevalue.cvl_code%TYPE
                                            := 'DISSEMINE' ;
   cst_midatgrnd_absentloc      CONSTANT codevalue.cvl_code%TYPE
                                            := 'ABSENTLOC' ;
   cst_midatgrnd_rivegauche     CONSTANT codevalue.cvl_code%TYPE
                                            := 'RIVEGAUCHE' ;
   cst_midatgrnd_rivedroite     CONSTANT codevalue.cvl_code%TYPE
                                            := 'RIVEDROITE' ;
   cst_midatgrnd_nolabel        CONSTANT codevalue.cvl_code%TYPE := 'NOLABEL';
   cst_midatgrnd_nodisplay      CONSTANT codevalue.cvl_code%TYPE
                                            := 'NODISPLAY' ;
   cst_midatgrnd_permeable      CONSTANT codevalue.cvl_code%TYPE
                                            := 'PERMEABLE' ;
   cst_midatgrnd_impermeable    CONSTANT codevalue.cvl_code%TYPE
                                            := 'IMPERMEABLE' ;
   cst_midatgrnd_typicours      CONSTANT codevalue.cvl_code%TYPE
                                            := 'TYPICOURS' ;
   cst_midatgrnd_atypicours     CONSTANT codevalue.cvl_code%TYPE
                                            := 'ATYPICOURS' ;
   cst_midatgrnd_artificiel     CONSTANT codevalue.cvl_code%TYPE
                                            := 'ARTIFICIEL' ;
   cst_midatgrnd_raison         CONSTANT codevalue.cvl_code%TYPE := 'RAISON';
   cst_midatgrnd_presence       CONSTANT codevalue.cvl_code%TYPE
                                            := 'PRESENCE' ;
   cst_midatgrnd_cause          CONSTANT codevalue.cvl_code%TYPE := 'CAUSE';
   cst_midatgrnd_remarque       CONSTANT codevalue.cvl_code%TYPE
                                            := 'REMARQUE' ;
   cst_midatgrnd_peumoyen       CONSTANT codevalue.cvl_code%TYPE
                                            := 'PEUMOYEN' ;
   cst_midatgrnd_beaucoup       CONSTANT codevalue.cvl_code%TYPE
                                            := 'BEAUCOUP' ;
   cst_midatgrnd_naturelle      CONSTANT codevalue.cvl_code%TYPE
                                            := 'NATURELLE' ;
   cst_midatgrnd_antropique     CONSTANT codevalue.cvl_code%TYPE
                                            := 'ANTROPIQUE' ;
   cst_midatgrnd_inconnue       CONSTANT codevalue.cvl_code%TYPE
                                            := 'INCONNUE' ;
   cst_midatgrnd_forchufeuil    CONSTANT codevalue.cvl_code%TYPE
                                            := 'FORCHUFEUIL' ;
   cst_midatgrnd_deversement    CONSTANT codevalue.cvl_code%TYPE
                                            := 'DEVERSEMENT' ;
   cst_midatgrnd_purin          CONSTANT codevalue.cvl_code%TYPE := 'PURIN';
   cst_midatgrnd_drainage       CONSTANT codevalue.cvl_code%TYPE
                                            := 'DRAINAGE' ;
   cst_midatgrnd_autre          CONSTANT codevalue.cvl_code%TYPE := 'AUTRE';
   cst_midatgrnd_chantier       CONSTANT codevalue.cvl_code%TYPE
                                            := 'CHANTIER' ;
   cst_midatgrnd_centhydro      CONSTANT codevalue.cvl_code%TYPE
                                            := 'CENTHYDRO' ;
   cst_midatgrnd_instablrive    CONSTANT codevalue.cvl_code%TYPE
                                            := 'INSTABLRIVE' ;
   cst_midatgrnd_marais         CONSTANT codevalue.cvl_code%TYPE := 'MARAIS';
   cst_midatgrnd_exutoirelac    CONSTANT codevalue.cvl_code%TYPE
                                            := 'EXUTOIRELAC' ;
   cst_midatgrnd_glacier        CONSTANT codevalue.cvl_code%TYPE := 'GLACIER';
   cst_midatgrnd_torrent        CONSTANT codevalue.cvl_code%TYPE := 'TORRENT';
   cst_midatgrnd_colordissou    CONSTANT codevalue.cvl_code%TYPE
                                            := 'COLORDISSOU' ;
   cst_midatgrnd_colorpart      CONSTANT codevalue.cvl_code%TYPE
                                            := 'COLORPART' ;
   cst_midatgrnd_ranunculus     CONSTANT codevalue.cvl_code%TYPE
                                            := 'RANUNCULUS' ;
   cst_midatgrnd_prodnett       CONSTANT codevalue.cvl_code%TYPE
                                            := 'PRODNETT' ;
   cst_midatgrnd_pourriture     CONSTANT codevalue.cvl_code%TYPE
                                            := 'POURRITURE' ;
   cst_midatgrnd_non0           CONSTANT codevalue.cvl_code%TYPE := 'NON0';
   cst_midatgrnd_moyen25        CONSTANT codevalue.cvl_code%TYPE := 'MOYEN25';
   cst_midatgrnd_beaucoup25     CONSTANT codevalue.cvl_code%TYPE
                                            := 'BEAUCOUP25' ;
   cst_midatgrnd_moyen          CONSTANT codevalue.cvl_code%TYPE := 'MOYEN';
   cst_midatgrnd_nombreux       CONSTANT codevalue.cvl_code%TYPE
                                            := 'NOMBREUX' ;
   cst_midatgrnd_isoles         CONSTANT codevalue.cvl_code%TYPE := 'ISOLES';
   cst_midatgrnd_isole          CONSTANT codevalue.cvl_code%TYPE := 'ISOLE';
   cst_midatgrnd_peu10          CONSTANT codevalue.cvl_code%TYPE := 'PEU10';
   cst_midatgrnd_beaucoup50     CONSTANT codevalue.cvl_code%TYPE
                                            := 'BEAUCOUP50' ;
   cst_midatgrnd_forte          CONSTANT codevalue.cvl_code%TYPE := 'FORTE';
   cst_midatgrnd_fort           CONSTANT codevalue.cvl_code%TYPE := 'FORT';
   cst_midatgrnd_ephemeropter   CONSTANT codevalue.cvl_code%TYPE
                                            := 'EPHEMEROPTER' ;
   cst_midatgrnd_plecoptera     CONSTANT codevalue.cvl_code%TYPE
                                            := 'PLECOPTERA' ;
   cst_midatgrnd_trichoptera    CONSTANT codevalue.cvl_code%TYPE
                                            := 'TRICHOPTERA' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_getcvlidbacode (p_cvl_code   IN codevalue.cvl_code%TYPE,
                              p_crf_code   IN codereference.crf_code%TYPE)
      RETURN codevalue.cvl_id%TYPE
   /*----------------------------------------------------------------*/
   IS
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue := pkg_codevalue.f_getfromcode (p_cvl_code, p_crf_code);

      IF l_reccodevalue.cvl_id IS NULL
      THEN
         raise_application_error (
            -20000,
               'pkg_codevalue.f_getfromcode('''
            || p_cvl_code
            || ''','''
            || p_crf_code
            || ''')',
            TRUE);
      END IF;

      RETURN l_reccodevalue.cvl_id;
   END;

   /*----------------------------------------------------------*/
   PROCEDURE p_build (p_ptv_id IN protocolmappinggrnd.pmr_ptv_id%TYPE)
   /*----------------------------------------------------------*/
   IS
      l_cvl_id                        codevalue.cvl_id%TYPE;
      l_cvl_id_save                   codevalue.cvl_id%TYPE;
      l_cvl_id_ecomorph               codevalue.cvl_id%TYPE;
      l_cvl_id_aspectgen              codevalue.cvl_id%TYPE;
      l_pmr_id_parent                 protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_master                 protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_parentsave             protocolmappinggrnd.pmr_id%TYPE;
      l_cvl_id_infosup                codevalue.cvl_id%TYPE;
      l_cvl_id_adultcap               codevalue.cvl_id%TYPE;
      l_sortorder                     NUMBER;
      l_prm_id                        protocolmappinggrnd.pmr_id%TYPE;
      l_cvl_id_datatype_double        codevalue.cvl_id%TYPE;
      l_cvl_id_datatype_posdoubleex   codevalue.cvl_id%TYPE;
      l_cvl_id_datatype_integer       codevalue.cvl_id%TYPE;
      l_cvl_id_datatype_string        codevalue.cvl_id%TYPE;
      l_cvl_id_datatype_caseacocher   codevalue.cvl_id%TYPE;
      l_cvl_id_datatype_posdouble     codevalue.cvl_id%TYPE;
      l_pmr_id                        protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_autre                  protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_depechan               protocolmappinggrnd.pmr_id%TYPE;
      l_pmr_id_abandon                protocolmappinggrnd.pmr_id%TYPE;
      l_sortordersave                 NUMBER;
   BEGIN
      pkg_migr_utility.p_recreatesequence ('PROTOCOLMAPPINGGRND',
                                           'SEQ_PROTOCOLMAPPINGGRND',
                                           'PMR_ID');
      l_cvl_id_datatype_caseacocher :=
         f_getcvlidbacode (pkg_codevalue.cst_datatype_checkbox,
                           pkg_codereference.cst_crf_datatype);
      l_cvl_id_datatype_double :=
         f_getcvlidbacode (pkg_codevalue.cst_datatype_double,
                           pkg_codereference.cst_crf_datatype);
      l_cvl_id_datatype_integer :=
         f_getcvlidbacode (pkg_codevalue.cst_datatype_integer,
                           pkg_codereference.cst_crf_datatype);
      l_cvl_id_datatype_string :=
         f_getcvlidbacode (pkg_codevalue.cst_datatype_string,
                           pkg_codereference.cst_crf_datatype);
      l_cvl_id_datatype_posdouble :=
         f_getcvlidbacode (pkg_codevalue.cst_datatype_posdouble,
                           pkg_codereference.cst_crf_datatype);
      l_cvl_id_datatype_posdoubleex :=
         f_getcvlidbacode (pkg_codevalue.cst_datatype_posdoubleex,
                           pkg_codereference.cst_crf_datatype);
      pkg_protocolmappinggrnd.p_deleteversion (p_ptv_id);
      pkg_migr_utility.p_recreatesequence ('PROTOCOLMAPPINGGRND',
                                           'SEQ_PROTOCOLMAPPINGGRND',
                                           'PMR_ID');
      l_sortorder := 0;
      l_sortorder := l_sortorder + 1;
      l_pmr_id_parent := NULL;
      l_cvl_id_ecomorph :=
         f_getcvlidbacode (cst_midatgrnd_ecomorph,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id_ecomorph, -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);

      l_pmr_id_master := l_pmr_id;


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_largeurmoy,
                           pkg_codereference.cst_crf_midatgrnd);

      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       l_cvl_id_datatype_posdoubleex, --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning, --p_isnotnull
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;
      l_sortorder := l_sortorder + 1;

      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);

      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       10,                   -- p_cellrowvalue
                                       'G',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_posdoubleex, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       pkg_constante.cst_warning, --p_isnotnull
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_misesousterr,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning, --p_isnotnull
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;

      l_pmr_id_parent := l_pmr_id;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_non,
                           pkg_codereference.cst_crf_midatgrnd);
      -- Mise sous terre NON
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       14,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);

      -- Mise sous terre OUI
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       14,                   -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nbreuxseuil,
                           pkg_codereference.cst_crf_midatgrnd);
      l_pmr_id_parent := l_pmr_id;
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning, --p_isnotnull
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;
      l_sortorder := l_sortorder + 1;

      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_non,
                           pkg_codereference.cst_crf_midatgrnd);
      -- Nombreux seuils NON
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       17,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);

      -- Nombreux seuils OUI
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       17,                   -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      -- Variabilté du lit
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_varialit,
                           pkg_codereference.cst_crf_midatgrnd);


      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning, --p_isnotnull
                                       l_pmr_id);
      -- Variabilté du lit prononce
      l_pmr_id_parent := l_pmr_id;
      l_sortorder := l_sortorder + 1;

      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_prononce,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       21,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      -- Variabilté du lit limite
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_limite,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       23,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      -- Variabilté du lit nulle
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nulle,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       25,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      -- Variabilté de la profondeur
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_variaprof,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning, --p_isnotnull
                                       l_pmr_id);
      -- Variabilté de la profondeur prononce
      l_pmr_id_parent := l_pmr_id;
      l_sortorder := l_sortorder + 1;

      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_prononce,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       30,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      -- Variabilté de la profondeur limite
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_limite,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       32,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      -- Variabilté de la profondeur nulle
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nulle,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       34,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      -- Aménagement du fond du lit
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_amenfond,
                           pkg_codereference.cst_crf_midatgrnd);

      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning, --p_isnotnull
                                       l_pmr_id);

      l_pmr_id_parent := l_pmr_id;
      -- Aménagement du fond du lit nul
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nul,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       39,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      -- Aménagement du fond du lit localisé < 10%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_loc10,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       41,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      -- Aménagement du fond du lit moyen 10-30%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_moy10_30,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       43,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      -- Aménagement du fond du lit important 30-60%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_imp30_60,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       45,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);

      -- Aménagement du fond du lit prépondérant > 60%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_prepon60,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       47,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      -- Aménagement du fond du lit total 100%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_total100,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       49,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      -- Matériaux de l'aménagement du fond du lit
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_matamenfond,
                           pkg_codereference.cst_crf_midatgrnd);
      l_pmr_id_parent := l_cvl_id;
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_warning,   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      --        Matériaux de l'aménagement du fond du lit    empierrement
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_empierenroch,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       53,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      --        Matériaux de l'aménagement du fond du lit  autre

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_autreimper,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       55,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      -- Bois mort au fond du lit
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_boismortfond,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning, --p_isnotnull
                                       l_pmr_id);

      --  Bois mort au fond du lit amas
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_amas,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       61,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_dissemine,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       63,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_absentloc,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       65,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      -- Renforcement du pied de la berge
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_renforpied,
                           pkg_codereference.cst_crf_midatgrnd);
      l_pmr_id_parent := l_cvl_id;
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);

      l_cvl_id_save := l_cvl_id;
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;
      -- Renforcement du pied de la berge gauche

      l_sortorder := l_sortorder + 1;
      l_sortordersave := l_sortorder;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_rivegauche,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning, --p_isnotnull
                                       l_pmr_id);


      -- Renforcement du pied de la berge gauche null
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nul,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       70,                   -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                     --p_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      -- Renforcement du pied de la berge gauche localisé < 10%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_loc10,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       72,                   -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Renforcement du pied de la berge gauche moyen 10-30%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_moy10_30,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       74,                   -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Renforcement du pied de la berge gauche important 30 - 60%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_imp30_60,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       76,                   -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Renforcement du pied de la berge gauche prépondérant > 60%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_prepon60,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       78,                   -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Renforcement du pied de la berge gauche total100
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_total100,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       80,                   -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      -- Renforcement du pied de la berge droite

      l_sortorder := l_sortordersave;

      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_rivedroite,
                           pkg_codereference.cst_crf_midatgrnd);

      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);


      -- Renforcement du pied de la berge droite null
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nul,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       70,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Renforcement du pied de la berge droite localisé < 10%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_loc10,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       72,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Renforcement du pied de la berge droite moyen 10-30%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_moy10_30,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       74,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Renforcement du pied de la berge droite important 30 - 60%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_imp30_60,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       76,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Renforcement du pied de la berge droite prépondérant > 60%
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_prepon60,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       78,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Renforcement du pied de la berge droite total100
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_total100,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       80,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      -- Perméabilité du renforcement du pied de la berge
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_permrenforg,
                           pkg_codereference.cst_crf_midatgrnd);
      l_pmr_id_parent := l_cvl_id;
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;
      l_cvl_id_save := l_cvl_id;
      -- Perméabilité du renforcement du pied de la berge gauche

      l_sortorder := l_sortorder + 1;
      l_sortordersave := l_sortorder;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_rivegauche,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;

      -- Perméabilité du renforcement du pied de la berge permeable

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_permeable,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       89,                   -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Perméabilité du renforcement du pied de la berge impermeable
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_impermeable,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       91,                   -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Perméabilité du renforcement du pied de la berge droite

      l_sortorder := l_sortordersave;

      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_rivedroite,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;
      l_sortorder := l_sortorder + 1;

      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_permeable,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       89,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Perméabilité du renforcement du pied de la berge impermeable
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_impermeable,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       91,                   -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      -- Largeur des rives
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_largeurrive,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id;
      l_cvl_id_save := l_cvl_id;
      l_sortordersave := l_sortorder;

      -- largeur rive gauche

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_rivegauche,
                           pkg_codereference.cst_crf_midatgrnd);

      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);
      -- Largeur rive gauche value
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);

      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       99,                   -- p_cellrowvalue
                                       'E',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_posdoubleex, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- largeur rive droite

      l_sortorder := l_sortordersave;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_rivedroite,
                           pkg_codereference.cst_crf_midatgrnd);

      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);
      -- Largeur rive droite value

      l_pmr_id_parent := l_pmr_id;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);


      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       99,                   -- p_cellrowvalue
                                       'G',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_posdoubleex, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      -- Nature des rives
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_naturerive,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_cvl_id_save := l_cvl_id;
      -- Nature rive gauche

      l_sortorder := l_sortorder + 1;
      l_sortordersave := l_sortorder;
      l_pmr_id_parentsave := l_pmr_id;
      l_pmr_id_parent := l_pmr_id;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_rivegauche,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_warning,  --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);

      l_pmr_id_parent := l_pmr_id;
      -- Nature rive gauche typique d'un cours d'eau

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_typicours,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       103,                  -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Nature rive gauche atypique d'un cours d'eau
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_atypicours,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       105,                  -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Nature rive gauche artificiele
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_artificiel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       107,                  -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      -- Nature rive droite

      l_sortorder := l_sortordersave;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_rivedroite,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_warning,  --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);


      -- Nature rive droite typique d'un cours d'eau

      l_pmr_id_parent := l_pmr_id;
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_typicours,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       103,                  -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Nature rive droite atypique d'un cours d'eau
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_atypicours,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       105,                  -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Nature rive droite artificiele
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_artificiel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       107,                  -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_pmr_id_parent := NULL;
      l_cvl_id_aspectgen :=
         f_getcvlidbacode (cst_midatgrnd_aspectgen,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id_aspectgen, -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_master := l_pmr_id;


      --- Boue
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_boue,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_cvl_id_save := l_cvl_id;
      l_sortordersave := l_sortorder;
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;

      --- Présence

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_presence,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);
      -- Boue présence non

      l_sortorder := l_sortorder + 1;
      l_pmr_id_parent := l_pmr_id;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_non,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       10,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Boue présence peu/moyen

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_peumoyen,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       12,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_beaucoup,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       14,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      --- Cause                                --Boue
      l_sortorder := l_sortorder + 1;

      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_cause,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);
      -- Boue cause naturelle
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_naturelle,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       10,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Boue cause artificielle

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_artificiel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       12,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Boue cause inconnue

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_inconnue,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       14,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      --- Remarque
      --Boue
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_remarque,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);
      -- Boue remarque forte chute de feuille
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_forchufeuil,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       10,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Boue remarque déversement
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_deversement,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       12,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Boue remarque purin
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_purin,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       10,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Boue remarque drainage
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_drainage,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       12,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Boue remarque autre
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_autre,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_autre := l_pmr_id;
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       16,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       16,                   -- p_cellrowvalue
                                       'K',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_string, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      --- Turbidité
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_turbidite,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_cvl_id_save := l_cvl_id;
      l_sortordersave := l_sortorder;
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;

      --- Présence

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_presence,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);
      -- Turbidité présence non
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_non,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       19,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Turbidité présence peu/moyen

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_peumoyen,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       21,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_forte,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       23,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      --- Turbidité Cause

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_cause,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);
      -- Turbidité cause naturelle
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_naturelle,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       19,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Turbidité cause artificielle

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_artificiel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       21,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Turbidité cause inconnue

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_inconnue,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       23,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_remarque,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);

      -- Turbidité remarque déversement
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_deversement,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       19,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_chantier,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       21,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_centhydro,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       23,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_instablrive,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       25,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_marais,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       19,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_exutoirelac,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       21,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_glacier,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       23,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_torrent,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       25,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Turbidité remarque autre
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_autre,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_autre := l_pmr_id;
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       27,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       27,                   -- p_cellrowvalue
                                       'K',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_string, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      --- Coloration

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_coloration,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_cvl_id_save := l_cvl_id;
      l_sortordersave := l_sortorder;
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;
      --- Présence

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_presence,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);

      -- Coloration présence non
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_non,
                           pkg_codereference.cst_crf_midatgrnd);

      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       30,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Coloration présence peu/moyen

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_peumoyen,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       32,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_forte,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       34,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      --- Coloration Cause

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_cause,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);
      -- Coloration cause naturelle
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_naturelle,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       30,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Coloration cause artificielle

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_artificiel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       32,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Coloration cause inconnue

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_inconnue,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       34,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_remarque,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);

      -- Coloration remarque colorant dissous
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_colordissou,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       30,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_colorpart,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       32,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_chantier,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       30,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_marais,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       32,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_exutoirelac,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       34,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Coloration remarque autre
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_autre,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_autre := l_pmr_id;
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       36,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       36,                   -- p_cellrowvalue
                                       'K',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_string, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      --- Mousse
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_mousse,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_cvl_id_save := l_cvl_id;
      l_sortordersave := l_sortorder;
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;

      --- Présence

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_presence,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);
      -- Mousse présence non
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_non,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       39,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Mousse présence peu/moyen

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_peumoyen,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       41,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_beaucoup,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       43,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      --- Mousse Cause

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_cause,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);
      -- Mousse cause naturelle
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_naturelle,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       39,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Mousse cause artificielle

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_artificiel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       41,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Mousse cause inconnue

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_inconnue,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       43,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_remarque,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);

      -- Mousse remarque forte chute de feuilles
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_forchufeuil,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       39,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_deversement,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       41,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_purin,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       43,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_drainage,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       39,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_marais,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       41,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_exutoirelac,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       43,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_ranunculus,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       45,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Mousse remarque autre
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_autre,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_autre := l_pmr_id;
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       45,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       45,                   -- p_cellrowvalue
                                       'K',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_string, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      --- Odeur
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_odeur,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_cvl_id_save := l_cvl_id;
      l_sortordersave := l_sortorder;

      --- Présence
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_presence,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);
      -- Odeur présence non
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_non,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       49,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Odeur présence peu/moyen

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_peumoyen,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       51,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_forte,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       53,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      --- Odeur Cause

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_cause,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);
      -- Odeur cause naturelle
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_naturelle,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       49,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Odeur cause artificielle

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_artificiel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       51,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Odeur cause inconnue

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_inconnue,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       53,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_remarque,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);

      -- Odeur remarque déversement
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_deversement,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       49,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_prodnett,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       51,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_purin,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       49,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_pourriture,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       51,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Odeur remarque autre
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_autre,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_pmr_id_autre := l_pmr_id;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       55,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       55,                   -- p_cellrowvalue
                                       'K',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_string, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      --- Sulfure de fer
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_sulfurefer,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;
      l_cvl_id_save := l_cvl_id;
      l_sortordersave := l_sortorder;

      --- Présence

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_presence,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);
      -- Sulfure de fer présence non 0%
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_non0,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       61,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Sulfure de fer présence moyen25

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_moyen25,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       63,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_beaucoup25,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       65,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      --- Sulfure de fer  Cause

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_cause,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);
      -- Sulfure de fer cause naturelle
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_naturelle,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       61,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Sulfure de fer cause artificielle

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_artificiel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       63,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Sulfure de fer  cause inconnue

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_inconnue,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       65,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_remarque,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);

      -- Sulfure de fer  remarque forte chute de feuilles
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_forchufeuil,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       61,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_deversement,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       63,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_purin,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       61,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_drainage,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       63,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Sulfure de fer remarque autre

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_autre,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_autre := l_pmr_id;
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       67,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       67,                   -- p_cellrowvalue
                                       'K',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_string, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      --- Colmatage
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_colmatage,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;
      l_cvl_id_save := l_cvl_id;
      l_sortordersave := l_sortorder;

      --- Présence

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_presence,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);
      -- Sulfure de fer présence non
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_non,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       70,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Sulfure de fer présence moyen

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_peumoyen,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       72,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_fort,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       74,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      --- Colmatage Cause

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_cause,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);
      -- Colmatagecause naturelle
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_naturelle,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       70,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Colmatage cause artificielle

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_artificiel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       72,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Colmatage cause inconnue

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_inconnue,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       74,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_remarque,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_autre,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       70,                   -- p_cellrowvalue
                                       'R',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_string, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      --- Solide
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_solide,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,
                                       pkg_constante.cst_warning,
                                       l_pmr_id);
      l_cvl_id_save := l_cvl_id;
      l_sortordersave := l_sortorder;

      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;

      -- Solide aucun
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_aucun,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       78,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Solide  isolé

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_isole,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       80,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nombreux,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       82,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      --- Solide  Déchets

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_dechets,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning,
                                       l_pmr_id);
      -- déchets aucun
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_aucun,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       78,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Solide déchets isolés

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_isole,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       80,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- Solide  déchets nombreux

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nombreux,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       82,                   -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_remarque,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);

      -- Solide  remarque articles higiéniques

      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_arthygieniq,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       78,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_papierwc,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       80,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_sacordure,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       82,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_emballage,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       84,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Solide remarque autre
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_autre,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_autre := l_pmr_id;
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       86,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       86,                   -- p_cellrowvalue
                                       'K',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_string, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      --- organisme hétérotrophe
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_organisme,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_cvl_id_save := l_cvl_id;
      l_sortordersave := l_sortorder;
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;

      --- Présence

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_presence,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_warning, --p_isnotnull
                                       l_pmr_id);
      -- organisme hétérotrophe présence non
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_non,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       89,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- organisme hétérotrophe présence isole

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_isole,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       91,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_peu,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       93,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_moyen,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       95,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_beaucoup,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       97,                   -- p_cellrowvalue
                                       'N',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      --- organisme hétérotrophe Cause

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_cause,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,   --pmr_morevalue
                                       pkg_constante.cst_no, --p_isnotnull
                                       l_pmr_id);
      -- organisme hétérotrophecause naturelle
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_naturelle,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       89,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- organisme hétérotrophe cause artificielle

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_artificiel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       91,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      -- organisme hétérotrophe cause inconnue

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_inconnue,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       93,                   -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_remarque,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,     --p_isnotnull
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_purin,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       89,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_drainage,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       91,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_forchufeuil,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       93,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);


      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_deversement,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       95,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      -- Organisme hétérotrophe remarque autre
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_autre,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);
      l_pmr_id_autre := l_pmr_id;
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       99,                   -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_autre,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       99,                   -- p_cellrowvalue
                                       'K',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_string, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      --- Végétation
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_vegetation,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;
      l_pmr_id_parentsave := l_pmr_id_parent;
      l_cvl_id_save := l_cvl_id;
      l_sortordersave := l_sortorder;


      -- algues

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_algues,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,  --pmr_morevalue,
                                       pkg_constante.cst_warning, --p_isnotnull,
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;
      --- Peu 10%

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_peu10,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       103,                  -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);


      --- Moyen

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_moyen,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       103,                  -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);


      --- Beaucoup > 50%

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_beaucoup50,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       103,                  -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);


      ---  Mousse
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_mousses,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,  --pmr_morevalue,
                                       pkg_constante.cst_warning, --p_isnotnull,
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;

      --- Peu 10%

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_peu10,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       105,                  -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);


      --- Moyen

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_moyen,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       105,                  -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);


      --- Beaucoup > 50%

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_beaucoup50,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       105,                  -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_macrophytes,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parentsave,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_no,  --pmr_morevalue,
                                       pkg_constante.cst_warning, --p_isnotnull,
                                       l_pmr_id);

      l_pmr_id_parent := l_pmr_id;

      --- Peu 10%

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_peu10,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       107,                  -- p_cellrowvalue
                                       'P',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);


      --- Moyen

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_moyen,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       107,                  -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);


      --- Beaucoup > 50%

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_beaucoup50,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       107,                  -- p_cellrowvalue
                                       'U',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,                   --pmr_morevalue
                                       NULL,                     --p_isnotnull
                                       l_pmr_id);



      l_cvl_id_infosup :=
         f_getcvlidbacode (cst_midatgrnd_infosup,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       NULL,
                                       l_cvl_id_infosup, -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,     --p_isnotnull
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_depechan,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_depechan := l_pmr_id;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_depechan,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       112,                  -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_raison,
                           pkg_codereference.cst_crf_midatgrnd);

      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_depechan,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);



      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       112,                  -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_string, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);



      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_abansta,
                           pkg_codereference.cst_crf_midatgrnd);

      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_pmr_id_abandon := l_pmr_id;
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_oui,
                           pkg_codereference.cst_crf_midatgrnd);


      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_abandon,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       114,                  -- p_cellrowvalue
                                       'F',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;



      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_raison,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_abandon,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_sortorder := l_sortorder + 1;
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_nolabel,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       114,                  -- p_cellrowvalue
                                       'H',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_string, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);

      l_sortorder := l_sortorder + 1;
      l_cvl_id_adultcap :=
         f_getcvlidbacode (cst_midatgrnd_adultcap,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_master,
                                       l_cvl_id_adultcap, -- p_cvl_id_midatgrnd
                                       NULL,                 -- p_cellrowvalue
                                       NULL,             --  p_cellcolumnvalue
                                       NULL,               --p_cvl_id_datatype
                                       pkg_constante.cst_yes,  --pmr_morevalue
                                       pkg_constante.cst_no,
                                       l_pmr_id);
      l_pmr_id_parent := l_pmr_id;
      l_sortorder := l_sortorder + 1;

      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_ephemeropter,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       110,                  -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_plecoptera,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       112,                  -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
      l_cvl_id :=
         f_getcvlidbacode (cst_midatgrnd_trichoptera,
                           pkg_codereference.cst_crf_midatgrnd);
      pkg_protocolmappinggrnd.p_write (p_ptv_id,
                                       l_sortorder,
                                       l_pmr_id_parent,
                                       l_cvl_id,         -- p_cvl_id_midatgrnd
                                       114,                  -- p_cellrowvalue
                                       'S',              --  p_cellcolumnvalue
                                       l_cvl_id_datatype_caseacocher, --p_cvl_id_datatype
                                       NULL,
                                       NULL,
                                       l_pmr_id);
   /*



     cst_midatgrnd_amenfond       CONSTANT codevalue.cvl_code%TYPE
                                              := 'AMENFOND' ;
     cst_midatgrnd_matamenfond    CONSTANT codevalue.cvl_code%TYPE
                                              := 'MATAMENFOND' ;
     cst_midatgrnd_boismortfond   CONSTANT codevalue.cvl_code%TYPE
                                              := 'BOISMORTFOND' ;
     cst_midatgrnd_renforpied     CONSTANT codevalue.cvl_code%TYPE
                                              := 'RENFORPIED' ;
     cst_midatgrnd_permrenforg    CONSTANT codevalue.cvl_code%TYPE
                                              := 'PERMRENFORG' ;
     cst_midatgrnd_largeurrive    CONSTANT codevalue.cvl_code%TYPE
                                              := 'LARGEURRIVE' ;
     cst_midatgrnd_naturerive     CONSTANT codevalue.cvl_code%TYPE
                                              := 'NATURERIVE' ;
     cst_midatgrnd_aspectgen      CONSTANT codevalue.cvl_code%TYPE
                                              := 'ASPECTGEN' ;
     cst_midatgrnd_boue           CONSTANT codevalue.cvl_code%TYPE := 'BOUE';
     cst_midatgrnd_turbidite      CONSTANT codevalue.cvl_code%TYPE
                                              := 'TURBIDITE' ;
     cst_midatgrnd_coloration     CONSTANT codevalue.cvl_code%TYPE
                                              := 'COLORATION' ;
     cst_midatgrnd_mousse         CONSTANT codevalue.cvl_code%TYPE := 'MOUSSE';
     cst_midatgrnd_odeur          CONSTANT codevalue.cvl_code%TYPE := 'ODEUR';
     cst_midatgrnd_sulfurefer     CONSTANT codevalue.cvl_code%TYPE
                                              := 'SULFUREFER' ;
     cst_midatgrnd_colmatage      CONSTANT codevalue.cvl_code%TYPE
                                              := 'COLMATAGE' ;
     cst_midatgrnd_colmatage      CONSTANT codevalue.cvl_code%TYPE
                                              := 'COLMATAGE' ;
     cst_midatgrnd_solide         CONSTANT codevalue.cvl_code%TYPE := 'SOLIDE';
     cst_midatgrnd_organisme      CONSTANT codevalue.cvl_code%TYPE
                                              := 'ORGANISME' ;
     cst_midatgrnd_vegetation     CONSTANT codevalue.cvl_code%TYPE
                                              := 'VEGETATION' ;
     cst_midatgrnd_infosup        CONSTANT codevalue.cvl_code%TYPE := 'INFOSUP';
     cst_midatgrnd_depechan       CONSTANT codevalue.cvl_code%TYPE
                                              := 'DEPECHAN' ;
     cst_midatgrnd_abansta        CONSTANT codevalue.cvl_code%TYPE := 'ABANSTA';
     cst_midatgrnd_adultcap       CONSTANT codevalue.cvl_code%TYPE
                                              := 'ADULTCAP' ;
     cst_midatgrnd_oui            CONSTANT codevalue.cvl_code%TYPE := 'OUI';
     cst_midatgrnd_non            CONSTANT codevalue.cvl_code%TYPE := 'NON';
     cst_midatgrnd_prononce       CONSTANT codevalue.cvl_code%TYPE
                                              := 'PRONONCE' ;
     cst_midatgrnd_limite         CONSTANT codevalue.cvl_code%TYPE := 'LIMITE';
     cst_midatgrnd_nulle          CONSTANT codevalue.cvl_code%TYPE := 'NULLE';
     cst_midatgrnd_nul            CONSTANT codevalue.cvl_code%TYPE := 'NUL';
     cst_midatgrnd_loc10          CONSTANT codevalue.cvl_code%TYPE := 'LOC10';
     cst_midatgrnd_moy10_30       CONSTANT codevalue.cvl_code%TYPE
                                              := 'MOY10_30' ;
     cst_midatgrnd_imp30_60       CONSTANT codevalue.cvl_code%TYPE
                                              := 'IMP30_60' ;
     cst_midatgrnd_prepon60       CONSTANT codevalue.cvl_code%TYPE
                                              := 'PREPON60' ;
     cst_midatgrnd_total100       CONSTANT codevalue.cvl_code%TYPE
                                              := 'TOTAL100' ;
     cst_midatgrnd_empierenroch   CONSTANT codevalue.cvl_code%TYPE
                                              := 'EMPIERENROCH' ;
     cst_midatgrnd_autreimper     CONSTANT codevalue.cvl_code%TYPE
                                              := 'AUTREIMPER' ;
     cst_midatgrnd_amas           CONSTANT codevalue.cvl_code%TYPE := 'AMAS';
     cst_midatgrnd_absentloc      CONSTANT codevalue.cvl_code%TYPE
                                              := 'ABSENTLOC' ;
     cst_midatgrnd_rivegauche     CONSTANT codevalue.cvl_code%TYPE
                                              := 'RIVEGAUCHE' ;
     cst_midatgrnd_rivedroite     CONSTANT codevalue.cvl_code%TYPE
                                              := 'RIVEDROITE' ;
     cst_midatgrnd_permeable      CONSTANT codevalue.cvl_code%TYPE
                                              := 'PERMEABLE' ;
     cst_midatgrnd_impermeable    CONSTANT codevalue.cvl_code%TYPE
                                              := 'IMPERMEABLE' ;
     cst_midatgrnd_typicours      CONSTANT codevalue.cvl_code%TYPE
                                              := 'TYPICOURS' ;
     cst_midatgrnd_atypicours     CONSTANT codevalue.cvl_code%TYPE
                                              := 'ATYPICOURS' ;
     cst_midatgrnd_artificiel     CONSTANT codevalue.cvl_code%TYPE
                                              := 'ARTIFICIEL' ;
     cst_midatgrnd_raison         CONSTANT codevalue.cvl_code%TYPE := 'RAISON';
     cst_midatgrnd_presence       CONSTANT codevalue.cvl_code%TYPE
                                              := 'PRESENCE' ;
     cst_midatgrnd_cause          CONSTANT codevalue.cvl_code%TYPE := 'CAUSE';
     cst_midatgrnd_remarque       CONSTANT codevalue.cvl_code%TYPE
                                              := 'REMARQUE' ;
     cst_midatgrnd_peumoyen       CONSTANT codevalue.cvl_code%TYPE
                                              := 'PEUMOYEN' ;
     cst_midatgrnd_beaucoup       CONSTANT codevalue.cvl_code%TYPE
                                              := 'BEAUCOUP' ;
     cst_midatgrnd_naturelle      CONSTANT codevalue.cvl_code%TYPE
                                              := 'NATURELLE' ;
     cst_midatgrnd_antropique     CONSTANT codevalue.cvl_code%TYPE
                                              := 'ANTROPIQUE' ;
     cst_midatgrnd_inconnue       CONSTANT codevalue.cvl_code%TYPE
                                              := 'INCONNUE' ;
     cst_midatgrnd_forchufeuil    CONSTANT codevalue.cvl_code%TYPE
                                              := 'FORCHUFEUIL' ;
     cst_midatgrnd_deversement    CONSTANT codevalue.cvl_code%TYPE
                                              := 'DEVERSEMENT' ;
     cst_midatgrnd_purin          CONSTANT codevalue.cvl_code%TYPE := 'PURIN';
     cst_midatgrnd_drainage       CONSTANT codevalue.cvl_code%TYPE
                                              := 'DRAINAGE' ;
     cst_midatgrnd_autre          CONSTANT codevalue.cvl_code%TYPE := 'AUTRE';
     cst_midatgrnd_chantier       CONSTANT codevalue.cvl_code%TYPE
                                              := 'CHANTIER' ;
     cst_midatgrnd_centhydro      CONSTANT codevalue.cvl_code%TYPE
                                              := 'CENTHYDRO' ;
     cst_midatgrnd_instablrive    CONSTANT codevalue.cvl_code%TYPE
                                              := 'INSTABLRIVE' ;
     cst_midatgrnd_marais         CONSTANT codevalue.cvl_code%TYPE := 'MARAIS';
     cst_midatgrnd_exutoirelac    CONSTANT codevalue.cvl_code%TYPE
                                              := 'EXUTOIRELAC' ;
     cst_midatgrnd_glacier        CONSTANT codevalue.cvl_code%TYPE := 'GLACIER';
     cst_midatgrnd_torrent        CONSTANT codevalue.cvl_code%TYPE := 'TORRENT';
     cst_midatgrnd_colordissou    CONSTANT codevalue.cvl_code%TYPE
                                              := 'COLORDISSOU' ;
     cst_midatgrnd_colorpart      CONSTANT codevalue.cvl_code%TYPE
                                              := 'COLORPART' ;
     cst_midatgrnd_ranunculus     CONSTANT codevalue.cvl_code%TYPE
                                              := 'RANUNCULUS' ;
     cst_midatgrnd_prodnett       CONSTANT codevalue.cvl_code%TYPE
                                              := 'PRODNETT' ;
     cst_midatgrnd_pourriture     CONSTANT codevalue.cvl_code%TYPE
                                              := 'POURRITURE' ;
     cst_midatgrnd_non0           CONSTANT codevalue.cvl_code%TYPE := 'NON0';
     cst_midatgrnd_moyen25        CONSTANT codevalue.cvl_code%TYPE := 'MOYEN25';
     cst_midatgrnd_beaucoup25     CONSTANT codevalue.cvl_code%TYPE
                                              := 'BEAUCOUP25' ;
     cst_midatgrnd_peumoyen       CONSTANT codevalue.cvl_code%TYPE
                                              := 'PEUMOYEN' ;
     cst_midatgrnd_nombreux       CONSTANT codevalue.cvl_code%TYPE
                                              := 'NOMBREUX' ;
     cst_midatgrnd_isoles         CONSTANT codevalue.cvl_code%TYPE := 'ISOLES';
     cst_midatgrnd_isole          CONSTANT codevalue.cvl_code%TYPE := 'ISOLE';
     cst_midatgrnd_peu10          CONSTANT codevalue.cvl_code%TYPE := 'PEU10';
     cst_midatgrnd_beaucoup50     CONSTANT codevalue.cvl_code%TYPE
                                              := 'BEAUCOUP50' ;
     cst_midatgrnd_ephemeropter   CONSTANT codevalue.cvl_code%TYPE
                                              := 'EPHEMEROPTER' ;
     cst_midatgrnd_plecoptera     CONSTANT codevalue.cvl_code%TYPE
                                              := 'PLECOPTERA' ;
     cst_midatgrnd_trichoptera    CONSTANT codevalue.cvl_code%TYPE
                                              := 'TRICHOPTERA' ;
                                              */

   END;
END pkg_migr_protocolmappinggrnd;
/

