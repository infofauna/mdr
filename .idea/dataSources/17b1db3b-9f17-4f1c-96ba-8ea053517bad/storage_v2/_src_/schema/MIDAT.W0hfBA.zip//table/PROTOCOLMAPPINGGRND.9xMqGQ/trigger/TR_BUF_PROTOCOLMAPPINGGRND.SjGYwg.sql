create trigger TR_BUF_PROTOCOLMAPPINGGRND
    before update
    on PROTOCOLMAPPINGGRND
    for each row
DECLARE
BEGIN
 
   :new.PMR_moddate := SYSDATE;
   :new.PMR_moduser := USER;
END tr_buf_PROTOCOLMAPPINGGRND;

/

