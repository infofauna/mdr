create PACKAGE       pkg_protocolmappinglabo
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLMAPPINGLABO
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_spearindexfactor_noset   CONSTANT NUMBER := -999;


   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_findtaxa (p_taxon    IN protocolmappinglabo.ptl_taxa%TYPE,
                        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
      RETURN protocolmappinglabo%ROWTYPE;

   PROCEDURE p_test;

   FUNCTION f_identifyentrybyhierarchy (
      p_syv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
      p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
      RETURN protocolmappinglabo%ROWTYPE;

   FUNCTION f_getrecordfromsyv_id (
      p_syv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
      p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
      RETURN protocolmappinglabo%ROWTYPE;

   FUNCTION f_getrecordbytaxa (
      p_ptv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
      p_taxa     IN protocolmappinglabo.ptl_taxa%TYPE)
      RETURN protocolmappinglabo%ROWTYPE;

   FUNCTION f_getrecord (p_ptl_id IN protocolmappinglabo.ptl_id%TYPE)
      RETURN protocolmappinglabo%ROWTYPE;

   PROCEDURE p_write (
      p_ptl_id              IN     protocolmappinglabo.ptl_ptl_id%TYPE,
      p_ptv_id              IN     protocolmappinglabo.ptl_ptv_id%TYPE,
      p_syv_id              IN     protocolmappinglabo.ptl_syv_id%TYPE,
      p_cellrowvalue        IN     protocolmappinglabo.ptl_cellrowvalue%TYPE,
      p_cellcolumnvalue     IN     protocolmappinglabo.ptl_cellcolumnvalue%TYPE,
      p_taxa                IN     protocolmappinglabo.ptl_taxa%TYPE,
      p_taxacscf            IN     protocolmappinglabo.ptl_taxacscf%TYPE,
      p_crf_id_level        IN     protocolmappinglabo.ptl_crf_id_level%TYPE,
      p_ibchfaunagroup_gi   IN     protocolmappinglabo.ptl_ibchfaunagroup_gi%TYPE,
      p_ibchindividumin     IN     protocolmappinglabo.ptl_ibchindividumin%TYPE,
      p_spearindexfactor    IN     protocolmappinglabo.ptl_spearindexfactor%TYPE,
      p_isnotnull           IN     protocolmappinglabo.ptl_isnotnull%TYPE,
      p_isnotnullgroup      IN     protocolmappinglabo.ptl_isnotnullgroup%TYPE,
      p_id                     OUT protocolmappinglabo.ptl_id%TYPE);
END pkg_protocolmappinglabo;
/

