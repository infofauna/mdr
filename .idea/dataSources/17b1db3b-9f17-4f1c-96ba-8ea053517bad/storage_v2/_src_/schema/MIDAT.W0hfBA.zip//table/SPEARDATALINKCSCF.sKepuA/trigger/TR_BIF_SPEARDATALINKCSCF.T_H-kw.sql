create trigger TR_BIF_SPEARDATALINKCSCF
    before insert
    on SPEARDATALINKCSCF
    for each row
DECLARE
BEGIN
   IF :new.SDF_ID IS NULL
   THEN
      :new.SDF_ID := seq_SPEARDATALINKCSCF.NEXTVAL;
   END IF;

   :new.SDF_credate := SYSDATE;
   :new.SDF_creuser := USER;
END TR_BIF_SPEARDATALINKCSCF;

/

