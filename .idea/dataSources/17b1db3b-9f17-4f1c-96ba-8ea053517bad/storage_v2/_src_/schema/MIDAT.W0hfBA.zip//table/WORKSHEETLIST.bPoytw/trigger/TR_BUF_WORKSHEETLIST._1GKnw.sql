create trigger TR_BUF_WORKSHEETLIST
    before update
    on WORKSHEETLIST
    for each row
DECLARE
BEGIN
 
   :new.WSL_moddate := SYSDATE;
   :new.WSL_moduser := USER;
END tr_buf_WORKSHEETLIST;

/

