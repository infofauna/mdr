create PACKAGE       pkg_importprotocolgrnd
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLMAPPINGGRND
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_setvalue (p_ipn_id   IN importprotocolgrnd.ipn_id%TYPE,
                         p_value    IN importprotocolgrnd.ipn_value%TYPE);

   FUNCTION f_getrecordbykeys (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_key1     IN VARCHAR2)
      RETURN importprotocolgrnd%ROWTYPE;

   FUNCTION f_getrecordbykeys (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2)
      RETURN importprotocolgrnd%ROWTYPE;

   FUNCTION f_getrecordbykeys (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2)
      RETURN importprotocolgrnd%ROWTYPE;

   FUNCTION f_getrecordbykeys (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2,
      p_key4     IN VARCHAR2)
      RETURN importprotocolgrnd%ROWTYPE;

   FUNCTION f_getrecordbykeys (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2,
      p_key4     IN VARCHAR2,
      p_key5     IN VARCHAR2)
      RETURN importprotocolgrnd%ROWTYPE;

   FUNCTION f_getrecordbyiphidandpmrid (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_pmr_id   IN importprotocolgrnd.ipn_pmr_id%TYPE)
      RETURN importprotocolgrnd%ROWTYPE;

   FUNCTION f_countmember (p_pmr_id IN importprotocolgrnd.ipn_pmr_id%TYPE)
      RETURN NUMBER;

   PROCEDURE p_insert (p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
                       p_pmr_id   IN importprotocolgrnd.ipn_pmr_id%TYPE,
                       p_value    IN importprotocolgrnd.ipn_value%TYPE);

   PROCEDURE p_deletebyiphid (p_iph_id IN importprotocolgrnd.ipn_iph_id%TYPE);

   PROCEDURE p_deletebyiphidmaster (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE);

   FUNCTION f_getrecord (p_ipn_id IN importprotocolgrnd.ipn_id%TYPE)
      RETURN importprotocolgrnd%ROWTYPE;
END pkg_importprotocolgrnd;
/

