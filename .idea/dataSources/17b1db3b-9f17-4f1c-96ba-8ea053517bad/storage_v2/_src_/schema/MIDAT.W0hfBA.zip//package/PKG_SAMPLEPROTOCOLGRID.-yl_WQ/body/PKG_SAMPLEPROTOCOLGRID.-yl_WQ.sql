create PACKAGE BODY       pkg_sampleprotocolgrid
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEPROTOCOLGRID
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       25.07.2013  F.Burri           1. Created this package body.
   ******************************************************************************/


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_deleteby_sph_id (
      p_sph_id   IN sampleprotocolgrid.spg_sph_id%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleprotocolgrid
            WHERE spg_sph_id = p_sph_id;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecord (p_spg_id IN sampleprotocolgrid.spg_id%TYPE)
      RETURN sampleprotocolgrid%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record   sampleprotocolgrid%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM sampleprotocolgrid
       WHERE spg_id = p_spg_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*---------------------------------------------------------------*/
   PROCEDURE p_check (p_command   IN     VARCHAR2,
                      p_oldrec    IN     sampleprotocolgrid%ROWTYPE,
                      p_newrec    IN OUT sampleprotocolgrid%ROWTYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      NULL;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_tr_bif_sampleprotocolgrid (
      p_newrec   IN OUT sampleprotocolgrid%ROWTYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      p_newrec.spg_credate := SYSDATE;
      p_newrec.spg_creuser := USER;

      IF p_newrec.spg_id IS NULL
      THEN
         p_newrec.spg_id := seq_sampleprotocolgrid.NEXTVAL;
      END IF;

      p_check (pkg_constante.cst_dml_command_insert, NULL, p_newrec);
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_tr_buf_sampleprotocolgrid (
      p_oldrec   IN     sampleprotocolgrid%ROWTYPE,
      p_newrec   IN OUT sampleprotocolgrid%ROWTYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      p_newrec.spg_moddate := SYSDATE;
      p_newrec.spg_moduser := USER;
      p_check (pkg_constante.cst_dml_command_update, p_oldrec, p_newrec);
   END;


   /*----------------------------------------------------------------------------------*/
   PROCEDURE p_write (p_sph_id   IN     sampleprotocolgrid.spg_sph_id%TYPE,
                      p_pmg_id   IN     sampleprotocolgrid.spg_pmg_id%TYPE,
                      p_value    IN     sampleprotocolgrid.spg_value%TYPE,
                      p_usr_id   IN     sampleprotocolgrid.spg_usr_id_create%TYPE,
                      p_spg_id      OUT sampleprotocolgrid.spg_id%TYPE)
   /*---------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_spg_id := seq_sampleprotocolgrid.NEXTVAL;

      INSERT INTO sampleprotocolgrid (spg_id,
                                      spg_sph_id,
                                      spg_pmg_id,
                                      spg_value,
                                      spg_usr_id_create,
                                      spg_usr_create_date)
           VALUES (p_spg_id,
                   p_sph_id,
                   p_pmg_id,
                   p_value,
                   p_usr_id,
                   sysdate);
   END;
END pkg_sampleprotocolgrid;
/

