create view V_USEROBSERVATIONSTAT as
SELECT COUNT (*) "USERSAMPLECOUNT",
            MIN (sph_credate) "USERFIRSTINPUTDATE",
            MAX (sph_credate) "USERLASTINPUTDATE",
            MIN (sph_observationdate) "FIRSTOBSERVATIONDATE",
            MAX (sph_observationdate) "LASTOBSERVATIONDATE",
            COUNT (sph_indexvalueibch) "IBCHCOUNTOBSERVATION",
            COUNT (sph_spearindexvalue) "SPEARCOUNTOBSERVATION",
            COUNT (sph_makroindexvalue) "MAKROINDEXCOUNTOBSERVATION",
            SUBSTR (
               REGEXP_REPLACE (
                     ','
                  || LISTAGG (
                        pkg_gis.f_returncanton (sst_coordinates),
                        ',')
                     WITHIN GROUP (ORDER BY
                                      pkg_gis.f_returncanton (sst_coordinates)),
                  '(,[^,]+)(\1)+',
                  '\1'),
               2)
               "GROUPLIST",
            sph_usr_id_create
       FROM sampleheader
            INNER JOIN samplestation ON sst_id = sph_sst_id
       
   GROUP BY sph_usr_id_create
/

