create trigger TR_BIF_WK_LOADSPEARDATACSCF
    before insert
    on WK_LOADSPEARDATACSCF
    for each row
DECLARE
BEGIN
   IF :new.wlf_id IS NULL
   THEN
      :new.wlf_id := seq_wk_loadspeardatacscf.NEXTVAL;
   END IF;

   :new.wlf_credate := SYSDATE;
   :new.wlf_creuser := USER;
END tr_bif_wk_loadspeardatacscf;

/

