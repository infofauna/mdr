create PACKAGE BODY       pkg_migr_v2
AS
   /******************************************************************************
      NAME:       PKG_MIGR_V2
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.07.2017      burrif       1. Created this package.
   ******************************************************************************/



   /*
    Mise à jour des identifiants du canton dans la table SAMPLESTATION
    Mise à jour des identifiants des projets dans la table SAMPLEHEADER


      /*--------------------------------------------------------------*/



   TYPE t_recproject IS RECORD
   (
      p_texte          sampleheader.sph_project%TYPE,
      p_project_code   project.prj_code%TYPE
   );

   TYPE t_listrecprojet IS TABLE OF t_recproject;

   gbl_tableproject     t_listrecprojet := t_listrecprojet ();

   cst_packageversion   VARCHAR2 (30) := 'Version 2.0, juillet 2017';

   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-------------------------------------------------------------------*/
   FUNCTION f_identifie_iph_id_complement (
      p_sph_id      IN sampleheaderfile.shf_sph_id%TYPE,
      p_ptv_id      IN sampleheaderfile.shf_ptv_id%TYPE,
      p_filename    IN sampleheaderfile.shf_filename%TYPE,
      p_sheetname   IN sampleheaderfile.shf_sheetname%TYPE)
      RETURN sampleheaderfile.shf_iph_id%TYPE
   /*--------------------------------------------------------------------*/
   IS
      l_recsampleheader           sampleheader%ROWTYPE;
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
   BEGIN
      l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);

      SELECT *
        INTO l_recimportprotocolheader
        FROM importprotocolheader
       WHERE     iph_ptv_id = p_ptv_id
             AND iph_iph_id = l_recsampleheader.sph_iph_id
             AND iph_inputfilename = p_filename
             AND iph_sheetname = p_sheetname
             AND iph_credate =
                    (SELECT MAX (iph_credate)
                       FROM importprotocolheader
                      WHERE     iph_ptv_id = p_ptv_id
                            AND iph_iph_id = l_recsampleheader.sph_iph_id
                            AND iph_inputfilename = p_filename
                            AND iph_sheetname = p_sheetname);

      RETURN l_recimportprotocolheader.iph_id;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
         NULL;
   END;

   /*--------------------------------------------------------------------*/
   FUNCTION f_identifie_iph_id (
      p_sph_id      IN sampleheaderfile.shf_sph_id%TYPE,
      p_ptv_id      IN sampleheaderfile.shf_ptv_id%TYPE,
      p_filename    IN sampleheaderfile.shf_filename%TYPE,
      p_sheetname   IN sampleheaderfile.shf_sheetname%TYPE)
      RETURN sampleheaderfile.shf_iph_id%TYPE
   /*--------------------------------------------------------------------*/
   IS
      l_recprotocolversion   protocolversion%ROWTYPE;
      l_reccodevalue         codevalue%ROWTYPE;
      l_recsampleheader      sampleheader%ROWTYPE;
      l_iph_id               sampleheaderfile.shf_iph_id%TYPE;
   BEGIN
      l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);
      l_reccodevalue :=
         pkg_codevalue.f_getrecord (
            l_recprotocolversion.ptv_cvl_id_protocoltype);

      IF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_laboratory
      THEN
         l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
         l_iph_id := l_recsampleheader.sph_iph_id;
      ELSE
         l_iph_id :=
            f_identifie_iph_id_complement (p_sph_id,
                                           p_ptv_id,
                                           p_filename,
                                           p_sheetname);
      END IF;

      RETURN l_iph_id;
   END;

   /*--------------------------------------------------------------------*/
   PROCEDURE p_update_shf_iph_id
   /*--------------------------------------------------------------------*/
   IS
      CURSOR l_listfile
      IS
         SELECT * FROM sampleheaderfile;

      l_reclistfile   l_listfile%ROWTYPE;
      l_iph_id        sampleheaderfile.shf_iph_id%TYPE;
   BEGIN
      OPEN l_listfile;

      LOOP
         FETCH l_listfile INTO l_reclistfile;

         EXIT WHEN l_listfile%NOTFOUND;

         l_iph_id :=
            f_identifie_iph_id (l_reclistfile.shf_sph_id,
                                l_reclistfile.shf_ptv_id,
                                l_reclistfile.shf_filename,
                                l_reclistfile.shf_sheetname);
         DBMS_OUTPUT.put_line (
               'l_reclistfile.shf_filename='
            || l_reclistfile.shf_filename
            || ' l_reclistfile.shf_sheetname='
            || l_reclistfile.shf_sheetname
            || ' -> iph_id='
            || l_iph_id);

         UPDATE sampleheaderfile
            SET shf_iph_id = l_iph_id
          WHERE shf_id = l_reclistfile.shf_id;
      END LOOP;

      CLOSE l_listfile;

      NULL;
   END;

   /*--------------------------------------------------------------------*/
   PROCEDURE p_updateelevation
   /*-------------------------------------------------------------------*/
   IS
      CURSOR l_listsamplestation
      IS
         SELECT *
           FROM samplestation sst
          WHERE sst.sst_coordinates.sdo_point.z IS NULL
         --     AND ROWNUM < 2
         FOR UPDATE;

      l_reclistsamplestation   l_listsamplestation%ROWTYPE;
      l_elevation              NUMBER;
      l_cvl_code_origin        codevalue.cvl_code%TYPE;
      l_returnstatus           NUMBER;
      l_reccodevalue           codevalue%ROWTYPE;
   BEGIN
      OPEN l_listsamplestation;

      LOOP
         FETCH l_listsamplestation INTO l_reclistsamplestation;

         EXIT WHEN l_listsamplestation%NOTFOUND;
         pkg_gis.p_returnelevation (
            l_reclistsamplestation.sst_coordinates.sdo_point.x,
            l_reclistsamplestation.sst_coordinates.sdo_point.y,
            l_elevation,
            l_cvl_code_origin,
            l_returnstatus);
         DBMS_OUTPUT.put_line (
               'l_X='
            || l_reclistsamplestation.sst_coordinates.sdo_point.x
            || ' l_y='
            || l_reclistsamplestation.sst_coordinates.sdo_point.y
            || ' Elevation='
            || l_elevation
            || ' cvl_code_origin='
            || l_cvl_code_origin
            || ' returnstatus='
            || l_returnstatus);

         IF l_returnstatus = pkg_constante.cst_returnstatusok
         THEN
            l_reccodevalue :=
               pkg_codevalue.f_getfromcode (
                  l_cvl_code_origin,
                  pkg_codereference.cst_crf_elevorigin);


            UPDATE samplestation sst
               SET sst.sst_coordinates =
                      sdo_geometry (
                         sst.sst_coordinates.sdo_gtype,
                         sst.sst_coordinates.sdo_srid,
                         sdo_point_type (sst.sst_coordinates.sdo_point.x,
                                         sst.sst_coordinates.sdo_point.y,
                                         l_elevation),
                         NULL,
                         NULL),
                   sst_cvl_id_elevationorigin = l_reccodevalue.cvl_id
             WHERE CURRENT OF l_listsamplestation;

            NULL;
         END IF;
      END LOOP;

      CLOSE l_listsamplestation;
   END;

   /*--------------------------------------------------------------------*/
   PROCEDURE p_inittableproject
   /*--------------------------------------------------------------------*/
   IS
   BEGIN
      gbl_tableproject.delete;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Mandat Bureau Limnex';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Suivi STEP';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;

      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Renaturation';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Observation qualité des eaux';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'STEP extension';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         '3ème correction du Rhône';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2006';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'KW Dala';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Drosera aménagement Dranse Sembrancher';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2012';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Assainissement des prises d''eau art. 80 LEaux';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2003';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'NAWA';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Pollution';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Octroi de nouvelles concessions';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Réseau cours d''eau';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'STEP Val d''Anniviers';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Renouvellement concession Ackersand I';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2015';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Pesticide 62A';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Gewässermonitoring Kanton ZH';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Gewässermonitoring Kanton SG';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'CFF Salquenen-Loèche';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'CIMO';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2010';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2002';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Vidange barrage';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Travail Master - UNIGE';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Projet hydroélectrique';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Agri-Fish';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Carte des dangers, aménagement';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'ITE Gravières Pradayens et Trappistes';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2001';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2000';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2005';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Revitalisation';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Assainissement éclusées';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Postulat Bonny';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Gestion des eaux';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2009';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Rhowag';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2011';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Assainissement BV';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'STEP';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2016';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Renouvellement concession';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Impact des rejets de DO ou BEP';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2004';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Réseau d''observation';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Travail Ecofoc';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Gewässermonitoring';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'Octroi de nouvelles concessions Usine Vièze';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Martigny-Bourg';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'EIE suivi environnement';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2008';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2013';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte := 'Düfur 2014';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
      gbl_tableproject.EXTEND (1);
      gbl_tableproject (gbl_tableproject.LAST).p_texte :=
         'STEP Sion-Châteauneuf';
      gbl_tableproject (gbl_tableproject.LAST).p_project_code := NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbycode (p_code IN project.prj_code%TYPE)
      RETURN project%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_recproject   project%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recproject
        FROM project
       WHERE prj_code = p_code OR prj_codech = p_code;

      RETURN l_recproject;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------------*/
   PROCEDURE p_update_sph_prj_id
   /*--------------------------------------------------------------------*/
   IS
      l_indice       PLS_INTEGER;
      l_recproject   project%ROWTYPE;
   BEGIN
      p_inittableproject;
      l_indice := gbl_tableproject.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         l_recproject :=
            f_getrecordbycode (gbl_tableproject (l_indice).p_project_code);

         IF l_recproject.prj_id IS NULL
         THEN
            pkg_debug.p_write (
               'PKG_MIGR_V2.P_UPDATE_SPH_PRJ_ID',
                  'Code project='
               || gbl_tableproject (l_indice).p_project_code
               || ' non trouvé');
         ELSE
            UPDATE sampleheader
               SET sph_prj_id = l_recproject.prj_id
             WHERE sph_project = gbl_tableproject (l_indice).p_texte;

            pkg_debug.p_write (
               'PKG_MIGR_V2.P_UPDATE_SPH_PRJ_ID',
                  'Project='
               || gbl_tableproject (l_indice).p_texte
               || ' mis à jour. Nombre d''enregistrement trouvé: '
               || SQL%ROWCOUNT);
         END IF;

         l_indice := gbl_tableproject.NEXT (l_indice);
      END LOOP;
   END;


   /*--------------------------------------------------------------------*/
   PROCEDURE p_update_sst_cvl_id_canton
   /*--------------------------------------------------------------------*/
   IS
      CURSOR l_samplestation
      IS
         SELECT *
           FROM samplestation
          WHERE sst_cvl_id_canton IS NULL
         FOR UPDATE;

      l_reccodevalue       codevalue%ROWTYPE;
      l_recsamplestation   l_samplestation%ROWTYPE;

      l_recch_canton       ch_canton%ROWTYPE;
   BEGIN
      OPEN l_samplestation;

      LOOP
         FETCH l_samplestation INTO l_recsamplestation;

         EXIT WHEN l_samplestation%NOTFOUND;



         pkg_ch_canton.p_findcontaincanton (
            l_recsamplestation.sst_coordinates,
            l_recch_canton);

         IF NOT l_recch_canton.code IS NULL
         THEN
            l_reccodevalue :=
               pkg_codevalue.f_getfromcode (l_recch_canton.code,
                                            pkg_codereference.cst_crf_canton);

            UPDATE samplestation
               SET sst_cvl_id_canton = l_reccodevalue.cvl_id
             WHERE CURRENT OF l_samplestation;
         END IF;
      END LOOP;

      CLOSE l_samplestation;
   END;

   /*------------------------------------------------------------------------*/
   PROCEDURE p_update_sph_indiceversion
   /*------------------------------------------------------------------------*/
   IS
      CURSOR l_sampleheader
      IS
         SELECT *
           FROM sampleheader
         FOR UPDATE;

      l_recsampleheader     l_sampleheader%ROWTYPE;

      l_ivr_id_spear        indiceversion.ivr_id%TYPE;
      l_ivr_id_ibch         indiceversion.ivr_id%TYPE;
      l_ivr_id_makroindex   indiceversion.ivr_id%TYPE;
   BEGIN
      OPEN l_sampleheader;

      LOOP
         FETCH l_sampleheader INTO l_recsampleheader;

         EXIT WHEN l_sampleheader%NOTFOUND;
         l_ivr_id_spear := NULL;
         l_ivr_id_ibch := NULL;
         l_ivr_id_makroindex := NULL;
         pkg_sampleheader.p_setiffilledivr_id (
            l_recsampleheader.sph_spearindexvalue,
            l_recsampleheader.sph_indexvalueibch,
            l_recsampleheader.sph_makroindexvalue,
            l_ivr_id_spear,
            l_ivr_id_ibch,
            l_ivr_id_makroindex);


         UPDATE sampleheader
            SET sph_ivr_id_spear = l_ivr_id_spear,
                sph_ivr_id_ibch = l_ivr_id_ibch,
                sph_ivr_id_makroindex = l_ivr_id_makroindex
          WHERE CURRENT OF l_sampleheader;
      END LOOP;

      CLOSE l_sampleheader;
   END;
END pkg_migr_v2;
/

