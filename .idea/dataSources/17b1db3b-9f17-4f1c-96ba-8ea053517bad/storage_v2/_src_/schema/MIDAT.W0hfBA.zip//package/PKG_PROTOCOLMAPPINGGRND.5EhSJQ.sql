create PACKAGE       pkg_protocolmappinggrnd
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLMAPPINGGRND
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_test;

   FUNCTION f_countchildren (p_pmr_id IN protocolmappinggrnd.pmr_id%TYPE)
      RETURN NUMBER;

   FUNCTION f_countsettedchildren (
      p_iph_id   IN importprotocolheader.iph_id%TYPE,
      p_pmr_id   IN protocolmappinggrnd.pmr_id%TYPE)
      RETURN NUMBER;

   FUNCTION f_getpmridbykeys (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_key1     IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE;

   FUNCTION f_getpmridbykeys (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE;

   FUNCTION f_getpmridbykeys (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE;

   FUNCTION f_getpmridbykeys (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2,
      p_key4     IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE;

   FUNCTION f_getpmridbykeys (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2,
      p_key4     IN VARCHAR2,
      p_key5     IN VARCHAR2)
      RETURN protocolmappinggrnd.pmr_id%TYPE;

   FUNCTION f_likeinstring (p_string IN VARCHAR2, p_keys IN VARCHAR2)
      RETURN NUMBER;

   FUNCTION f_returnfullpath (p_pmr_id IN protocolmappinggrnd.pmr_id%TYPE)
      RETURN VARCHAR2;

   PROCEDURE p_getattr (
      p_pmr_id      IN     protocolmappinggrnd.pmr_id%TYPE,
      p_morevalue      OUT protocolmappinggrnd.pmr_morevalue%TYPE,
      p_isnotnull      OUT protocolmappinggrnd.pmr_isnotnull%TYPE);

   PROCEDURE p_deleteversion (
      p_ptv_id   IN protocolmappinggrnd.pmr_ptv_id%TYPE);

   FUNCTION f_getrecord (p_pmr_id IN protocolmappinggrnd.pmr_id%TYPE)
      RETURN protocolmappinggrnd%ROWTYPE;



   FUNCTION f_getrecordparent (p_pmr_id IN protocolmappinggrnd.pmr_id%TYPE)
      RETURN protocolmappinggrnd%ROWTYPE;

   FUNCTION f_returndatalabel (p_pmr_id   IN protocolmappinggrnd.pmr_id%TYPE,
                               p_lan_id   IN language.lan_id%TYPE)
      RETURN codedesignation.cdn_designation%TYPE;

   PROCEDURE p_write (
      p_ptv_id             IN     protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_sortorder          IN     protocolmappinggrnd.pmr_sortorder%TYPE,
      p_pmr_id_parent      IN     protocolmappinggrnd.pmr_pmr_id%TYPE,
      p_cvl_id_midatgrnd   IN     protocolmappinggrnd.pmr_cvl_id_midatgrnd%TYPE,
      p_cellrowvalue       IN     protocolmappinggrnd.pmr_cellrowvalue%TYPE,
      p_cellcolumnvalue    IN     protocolmappinggrnd.pmr_cellcolumnvalue%TYPE,
      p_cvl_id_datatype    IN     protocolmappinggrnd.pmr_cvl_id_datatype%TYPE,
      p_morevalue          IN     protocolmappinggrnd.pmr_morevalue%TYPE,
      p_isnotnull          IN     protocolmappinggrnd.pmr_isnotnull%TYPE,
      p_id                    OUT protocolmappinggrnd.pmr_id%TYPE);

   PROCEDURE p_update (
      p_id                    OUT protocolmappinggrnd.pmr_id%TYPE,
      p_ptv_id             IN     protocolmappinggrnd.pmr_ptv_id%TYPE,
      p_sortorder          IN     protocolmappinggrnd.pmr_sortorder%TYPE,
      p_pmr_id_parent      IN     protocolmappinggrnd.pmr_pmr_id%TYPE,
      p_cvl_id_midatgrnd   IN     protocolmappinggrnd.pmr_cvl_id_midatgrnd%TYPE,
      p_cellrowvalue       IN     protocolmappinggrnd.pmr_cellrowvalue%TYPE,
      p_cellcolumnvalue    IN     protocolmappinggrnd.pmr_cellcolumnvalue%TYPE,
      p_cvl_id_datatype    IN     protocolmappinggrnd.pmr_cvl_id_datatype%TYPE,
      pmr_morevalue        IN     protocolmappinggrnd.pmr_morevalue%TYPE);
END pkg_protocolmappinggrnd;
/

