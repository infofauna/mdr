create PACKAGE BODY       pkg_importprotocolgrnd
AS
   /******************************************************************************
      NAME:       PKG_IMPORTPROTOCOLGRND
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_setvalue (p_ipn_id   IN importprotocolgrnd.ipn_id%TYPE,
                         p_value    IN importprotocolgrnd.ipn_value%TYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE importprotocolgrnd
         SET ipn_value = p_value
       WHERE ipn_id = p_ipn_id;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbyiphidandpmrid (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_pmr_id   IN importprotocolgrnd.ipn_pmr_id%TYPE)
      RETURN importprotocolgrnd%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_recimportprotocolgrnd   importprotocolgrnd%ROWTYPE;
   BEGIN
      pkg_debug.p_write ('PKG_IMPORTPROTOCOLGRND.f_getrecordbyiphidandpmrid',
                         'p_iph_id=' || p_iph_id || ' p_pmr_id=' || p_pmr_id);

      SELECT *
        INTO l_recimportprotocolgrnd
        FROM importprotocolgrnd
       WHERE ipn_iph_id = p_iph_id AND ipn_pmr_id = p_pmr_id;

      RETURN l_recimportprotocolgrnd;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;


   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbykeys (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_key1     IN VARCHAR2)
      RETURN importprotocolgrnd%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
      l_pmr_id                    protocolmappinggrnd.pmr_id%TYPE;
      l_recimportprotocolgrnd     importprotocolgrnd%ROWTYPE;
   BEGIN
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);

      IF NOT l_recimportprotocolheader.iph_id IS NULL
      THEN
         l_pmr_id :=
            pkg_protocolmappinggrnd.f_getpmridbykeys (
               l_recimportprotocolheader.iph_ptv_id,
               p_key1);

         IF NOT l_pmr_id IS NULL
         THEN
            l_recimportprotocolgrnd :=
               f_getrecordbyiphidandpmrid (p_iph_id, l_pmr_id);
            RETURN l_recimportprotocolgrnd;
         END IF;
      END IF;

      RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbykeys (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2)
      RETURN importprotocolgrnd%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
      l_pmr_id                    protocolmappinggrnd.pmr_id%TYPE;
      l_recimportprotocolgrnd     importprotocolgrnd%ROWTYPE;
   BEGIN
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);

      IF NOT l_recimportprotocolheader.iph_id IS NULL
      THEN
         l_pmr_id :=
            pkg_protocolmappinggrnd.f_getpmridbykeys (
               l_recimportprotocolheader.iph_ptv_id,
               p_key1,
               p_key2);

         IF NOT l_pmr_id IS NULL
         THEN
            l_recimportprotocolgrnd :=
               f_getrecordbyiphidandpmrid (p_iph_id, l_pmr_id);
            RETURN l_recimportprotocolgrnd;
         END IF;
      END IF;

      RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbykeys (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2)
      RETURN importprotocolgrnd%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
      l_pmr_id                    protocolmappinggrnd.pmr_id%TYPE;
      l_recimportprotocolgrnd     importprotocolgrnd%ROWTYPE;
   BEGIN
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);

      IF NOT l_recimportprotocolheader.iph_id IS NULL
      THEN
         l_pmr_id :=
            pkg_protocolmappinggrnd.f_getpmridbykeys (
               l_recimportprotocolheader.iph_ptv_id,
               p_key1,
               p_key2,
               p_key3);
         pkg_debug.p_write ('PKG_IMPORTPROTOCOLGRND.f_getrecordbykeys',
                            'l_pmr_id=' || l_pmr_id);

         IF NOT l_pmr_id IS NULL
         THEN
            l_recimportprotocolgrnd :=
               f_getrecordbyiphidandpmrid (p_iph_id, l_pmr_id);
            RETURN l_recimportprotocolgrnd;
         END IF;
      END IF;

      RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbykeys (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2,
      p_key4     IN VARCHAR2)
      RETURN importprotocolgrnd%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
      l_pmr_id                    protocolmappinggrnd.pmr_id%TYPE;
      l_recimportprotocolgrnd     importprotocolgrnd%ROWTYPE;
   BEGIN
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);

      IF NOT l_recimportprotocolheader.iph_id IS NULL
      THEN
         l_pmr_id :=
            pkg_protocolmappinggrnd.f_getpmridbykeys (
               l_recimportprotocolheader.iph_ptv_id,
               p_key1,
               p_key2,
               p_key3,
               p_key4);

         IF NOT l_pmr_id IS NULL
         THEN
            l_recimportprotocolgrnd :=
               f_getrecordbyiphidandpmrid (p_iph_id, l_pmr_id);
            RETURN l_recimportprotocolgrnd;
         END IF;
      END IF;

      RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbykeys (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
      p_key1     IN VARCHAR2,
      p_key2     IN VARCHAR2,
      p_key3     IN VARCHAR2,
      p_key4     IN VARCHAR2,
      p_key5     IN VARCHAR2)
      RETURN importprotocolgrnd%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
      l_pmr_id                    protocolmappinggrnd.pmr_id%TYPE;
      l_recimportprotocolgrnd     importprotocolgrnd%ROWTYPE;
   BEGIN
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);

      IF NOT l_recimportprotocolheader.iph_id IS NULL
      THEN
         l_pmr_id :=
            pkg_protocolmappinggrnd.f_getpmridbykeys (
               l_recimportprotocolheader.iph_ptv_id,
               p_key1,
               p_key2,
               p_key3,
               p_key4,
               p_key5);

         IF NOT l_pmr_id IS NULL
         THEN
            l_recimportprotocolgrnd :=
               f_getrecordbyiphidandpmrid (p_iph_id, l_pmr_id);
            RETURN l_recimportprotocolgrnd;
         END IF;
      END IF;

      RETURN NULL;
   END;

   /*------------------------------------------------------------*/

   FUNCTION f_countmember (p_pmr_id IN importprotocolgrnd.ipn_pmr_id%TYPE)
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM importprotocolgrnd
       WHERE ipn_pmr_id = p_pmr_id;

      RETURN l_count;
   END;

   /*-------------------------------------------------------------*/

   PROCEDURE p_insert (p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE,
                       p_pmr_id   IN importprotocolgrnd.ipn_pmr_id%TYPE,
                       p_value    IN importprotocolgrnd.ipn_value%TYPE)
   /*---------------------------------------------------------------*/
   IS
      l_id   importprotocolgrnd.ipn_id%TYPE;
   BEGIN
      l_id := seq_importprotocolgrnd.NEXTVAL;

      INSERT INTO importprotocolgrnd (ipn_id,
                                      ipn_iph_id,
                                      ipn_pmr_id,
                                      ipn_value)
           VALUES (l_id,
                   p_iph_id,
                   p_pmr_id,
                   p_value);

      COMMIT;
   END;


   /*-------------------------------------------------------------*/

   PROCEDURE p_deletebyiphidmaster (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importprotocolgrnd
            WHERE ipn_iph_id IN (SELECT iph_id
                                   FROM importprotocolheader
                                  WHERE iph_iph_id = p_iph_id);
   END;

   /*-------------------------------------------------------------*/

   PROCEDURE p_deletebyiphidatlevel (
      p_iph_id   IN importprotocolgrnd.ipn_iph_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importprotocolgrnd
            WHERE ipn_iph_id = p_iph_id;
   END;

   /*-----------------------------------------------------------------------*/
   PROCEDURE p_deletebyiphid (p_iph_id IN importprotocolgrnd.ipn_iph_id%TYPE)
   /*-----------------------------------------------------------------------------*/
   IS
      CURSOR l_cursorfils                                   -- Fils de l'iphid
      IS
         SELECT iph_id
           FROM importprotocolheader
          WHERE iph_iph_id = p_iph_id;

      l_reccursorfils   l_cursorfils%ROWTYPE;
   BEGIN
      OPEN l_cursorfils;

      LOOP
         FETCH l_cursorfils INTO l_reccursorfils;

         EXIT WHEN l_cursorfils%NOTFOUND;
         p_deletebyiphidatlevel (l_reccursorfils.iph_id);
      END LOOP;

      CLOSE l_cursorfils;

      p_deletebyiphidatlevel (p_iph_id);
   END;



   /*-------------------------------------------------------------*/

   FUNCTION f_getrecord (p_ipn_id IN importprotocolgrnd.ipn_id%TYPE)
      RETURN importprotocolgrnd%ROWTYPE
   /*-------------------------------------------------------------*/
   IS
      l_record   importprotocolgrnd%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM importprotocolgrnd
       WHERE ipn_id = p_ipn_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
END;
/

