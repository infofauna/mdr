create trigger TR_BIF_IMPORTMASSDATADETAIL
    before insert
    on IMPORTMASSDATADETAIL
    for each row
DECLARE
BEGIN
   IF :new.IMD_id IS NULL
   THEN
      :new.IMD_id := seq_IMPORTMASSDATADETAIL.NEXTVAL;
   END IF;

   :new.IMD_credate := SYSDATE;
   :new.IMD_creuser := USER;
END tr_bif_IMPORTMASSDATADETAIL;

/

