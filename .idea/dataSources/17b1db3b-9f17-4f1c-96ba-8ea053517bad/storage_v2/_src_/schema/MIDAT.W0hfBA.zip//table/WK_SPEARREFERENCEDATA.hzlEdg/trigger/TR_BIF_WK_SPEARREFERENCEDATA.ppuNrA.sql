create trigger TR_BIF_WK_SPEARREFERENCEDATA
    before insert
    on WK_SPEARREFERENCEDATA
    for each row
BEGIN
   IF :new.wrd_id IS NULL
   THEN
      SELECT seq_WK_spearreferencedata.NEXTVAL INTO :new.wrd_id  FROM DUAL;
END IF;
:NEW.WRD_CREDATE:=SYSDATE;
:NEW.WRD_CREUSER:=USER; 



END TR_BIF_WK_SPEARREFERENCEDATA;

/

