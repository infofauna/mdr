create PACKAGE       pkg_protocolmappingmassfield
AS
   /******************************************************************************
      NAME:       pkg_protocolmappingmassfieldfield
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
      2.0        21.09.2017      burrif       2. Version 2
   */



   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecord (p_pmm_id IN protocolmappingmassfield.pmm_id%TYPE)
      RETURN protocolmappingmassfield%ROWTYPE;

   FUNCTION f_countgrouprequired (
      p_ptv_id   IN protocolmappingmassfield.pmm_ptv_id%TYPE)
      RETURN NUMBER;

   FUNCTION f_countrequired (
      p_ptv_id   IN protocolmappingmassfield.pmm_ptv_id%TYPE)
      RETURN NUMBER;

   FUNCTION f_getfromcode (
      p_code     IN protocolmappingmassfield.pmm_code_midatfldcmt%TYPE,
      p_ptv_id   IN protocolmappingmassfield.pmm_ptv_id%TYPE)
      RETURN protocolmappingmassfield%ROWTYPE;

   FUNCTION f_getfromaliascolumnname (
      p_aliascolumnname   IN protocolmappingmassmap.pma_aliascolumnname%TYPE,
      p_ptv_id            IN protocolmappingmassfield.pmm_ptv_id%TYPE,
      p_lan_id            IN protocolmappingmassmap.pma_lan_id%TYPE)
      RETURN protocolmappingmassfield%ROWTYPE;

   FUNCTION f_getfromcolumnname (
      p_columnname   IN protocolmappingmassfield.pmm_columnname%TYPE,
      p_ptv_id       IN protocolmappingmassfield.pmm_ptv_id%TYPE)
      RETURN protocolmappingmassfield%ROWTYPE;



   PROCEDURE p_write (
      p_ptv_id           IN protocolmappingmassfield.pmm_ptv_id%TYPE,
      p_columncode       IN protocolmappingmassfield.pmm_code_midatfldcmt%TYPE,
      p_columnname       IN protocolmappingmassfield.pmm_columnname%TYPE,
      p_isnotnull        IN protocolmappingmassfield.pmm_isnotnull%TYPE,
      p_isnotnullgroup   IN protocolmappingmassfield.pmm_isnotnullgroup%TYPE);
END pkg_protocolmappingmassfield;
/

