create trigger TR_BUF_PROTOCOLMAPPINGMASSMAP
    before update
    on PROTOCOLMAPPINGMASSMAP
    for each row
DECLARE
BEGIN
 

   :new.PMA_moddate := SYSDATE;
   :new.PMA_moduser := USER;
END TR_BUF_PROTOCOLMAPPINGMASSMAP;

/

