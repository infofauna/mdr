create PACKAGE BODY       pkg_sampleheaderfile
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEHEADERFILE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
      1.1        24.10.2017      burrif       2. Version 2 de MIDAT
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.1, octobre  2017' ;


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_delete (p_shf_id IN sampleheaderfile.shf_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleheaderfile
            WHERE shf_id = p_shf_id;
   END;


   /*-------------------------------------------------------------*/
   PROCEDURE p_delete_by_iph_id (
      p_iph_id   IN sampleheaderfile.shf_iph_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleheaderfile
            WHERE shf_iph_id = p_iph_id;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecord (p_shf_id IN sampleheaderfile.shf_id%TYPE)
      RETURN sampleheaderfile%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record   sampleheaderfile%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM sampleheaderfile
       WHERE shf_id = p_shf_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-----------------------------------------------------------------------*/
   PROCEDURE p_deleteby_sph_id (p_sph_id IN sampleheaderfile.shf_sph_id%TYPE)
   /*----------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleheaderfile
            WHERE shf_sph_id = p_sph_id;
   END;

   /*----------------------------------------------------------------------*/
   PROCEDURE p_deleteby_ptv_id (
      p_sph_id   IN sampleheaderfile.shf_sph_id%TYPE,
      p_ptv_id   IN sampleheaderfile.shf_ptv_id%TYPE)
   /*----------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleheaderfile
            WHERE shf_ptv_id = p_ptv_id AND shf_sph_id = p_sph_id;
   END;

   /*---------------------------------------------------------------------*/
   PROCEDURE p_write (p_ptv_id      IN sampleheaderfile.shf_ptv_id%TYPE,
                      p_sph_id      IN sampleheaderfile.shf_sph_id%TYPE,
                      p_lan_id      IN sampleheaderfile.shf_lan_id%TYPE,
                      p_usr_id      IN sampleheaderfile.shf_usr_id_create%TYPE,
                      p_file        IN sampleheaderfile.shf_file%TYPE,
                      p_filename    IN sampleheaderfile.shf_filename%TYPE,
                      p_sheetname   IN sampleheaderfile.shf_sheetname%TYPE,
                      p_iph_id      IN sampleheaderfile.shf_iph_id%TYPE)
   /*---------------------------------------------------------------------*/
   IS
   BEGIN
      INSERT INTO sampleheaderfile (shf_ptv_id,
                                    shf_sph_id,
                                    shf_lan_id,
                                    shf_file,
                                    shf_filename,
                                    shf_sheetname,
                                    shf_usr_id_create,
                                    shf_usr_create_date,
                                    shf_iph_id)
           VALUES (p_ptv_id,
                   p_sph_id,
                   p_lan_id,
                   p_file,
                   p_filename,
                   p_sheetname,
                   p_usr_id,
                   SYSDATE,
                   p_iph_id);
   END;

   /*-------------------------------------------------------------------------*/
   PROCEDURE p_test
   /*-------------------------------------------------------------------------*/
   IS
      l_sampleheaderfile   sampleheaderfile%ROWTYPE;
   BEGIN
      l_sampleheaderfile :=
         f_getbysphidandprotocoltype (580,
                                      pkg_codevalue.cst_protocoltype_grdeval);
      DBMS_OUTPUT.put_line ('Grille=' || l_sampleheaderfile.shf_id);
      l_sampleheaderfile :=
         f_getbysphidandprotocoltype (580,
                                      pkg_codevalue.cst_protocoltype_ground);
      DBMS_OUTPUT.put_line ('Ground=' || l_sampleheaderfile.shf_id);
      l_sampleheaderfile :=
         f_getbysphidandprotocoltype (
            580,
            pkg_codevalue.cst_protocoltype_laboratory);
      DBMS_OUTPUT.put_line ('labo=' || l_sampleheaderfile.shf_id);
   END;

   /*-------------------------------------------------------------------------*/
   FUNCTION f_getbysphidandprotocoltype (
      p_sph_id         IN sampleheaderfile.shf_sph_id%TYPE,
      p_protocoltype   IN codevalue.cvl_code%TYPE)
      RETURN sampleheaderfile%ROWTYPE
   /*--------------------------------------------------------------------------*/
   IS
      l_recsampleheaderfile   sampleheaderfile%ROWTYPE;
      l_reccodevalue          codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getfromcode (p_protocoltype,
                                      pkg_codereference.cst_crf_midatproto);

      IF l_reccodevalue.cvl_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      l_recsampleheaderfile :=
         f_getbysphidandprotocoltypeid (p_sph_id, l_reccodevalue.cvl_id);
      RETURN l_recsampleheaderfile;
   END;

   /*-------------------------------------------------------------------------*/
   FUNCTION f_getbysphidandprotocoltypeid (
      p_sph_id   IN sampleheaderfile.shf_sph_id%TYPE,
      p_cvl_id   IN protocolversion.ptv_cvl_id_protocoltype%TYPE)
      RETURN sampleheaderfile%ROWTYPE
   /*--------------------------------------------------------------------------*/
   IS
      l_sampleheaderfile   sampleheaderfile%ROWTYPE;
   BEGIN
      SELECT sampleheaderfile.*
        INTO l_sampleheaderfile
        FROM sampleheaderfile
             INNER JOIN protocolversion ON shf_ptv_id = ptv_id
       WHERE shf_sph_id = p_sph_id AND ptv_cvl_id_protocoltype = p_cvl_id;

      RETURN l_sampleheaderfile;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------------------*/
   FUNCTION f_getbysphidandptvid (
      p_sph_id   IN sampleheaderfile.shf_sph_id%TYPE,
      p_ptv_id   IN sampleheaderfile.shf_ptv_id%TYPE)
      RETURN sampleheaderfile%ROWTYPE
   /*--------------------------------------------------------------------------*/
   IS
      l_sampleheaderfile   sampleheaderfile%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_sampleheaderfile
        FROM sampleheaderfile
       WHERE shf_sph_id = p_sph_id AND shf_ptv_id = p_ptv_id;

      RETURN l_sampleheaderfile;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_deleteby_cvl_id_protocoltype (
      p_sph_id                IN sampleheaderitem.shm_sph_id%TYPE,
      p_cvl_id_protocoltype   IN sampleheaderitem.shm_cvl_id_midatproto%TYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleheaderfile
            WHERE     shf_ptv_id IN
                         (SELECT ptv_id
                            FROM protocolversion
                           WHERE ptv_cvl_id_protocoltype =
                                    p_cvl_id_protocoltype)
                  AND shf_sph_id = p_sph_id;
   END;

   /*--------------------------------------------------------------------------*/
   FUNCTION f_getlaboprotocolfile (
      p_sph_id   IN sampleheaderfile.shf_sph_id%TYPE)
      RETURN sampleheaderfile%ROWTYPE
   /*--------------------------------------------------------------------------*/
   IS
      l_sampleheaderfile   sampleheaderfile%ROWTYPE;
   BEGIN
      SELECT sampleheaderfile.*
        INTO l_sampleheaderfile
        FROM sampleheaderfile
             INNER JOIN protocolversion ON ptv_id = shf_ptv_id
             INNER JOIN codevalue ON ptv_cvl_id_protocoltype = cvl_id
       WHERE     shf_sph_id = p_sph_id
             AND cvl_code = pkg_codevalue.cst_protocoltype_laboratory;

      RETURN l_sampleheaderfile;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
END pkg_sampleheaderfile;
/

