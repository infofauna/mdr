create PACKAGE BODY       pkg_lob
AS
   /******************************************************************************
      NAME:       PKG_LOB
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        27.09.2013      burrif       1. Created this package.
   ******************************************************************************/
   /*-----------------------------------------------------------------------*/
   PROCEDURE p_insertdatatest
   /*-----------------------------------------------------------------------*/
   IS
   BEGIN
      /*
         p_insertprotocol (1,
                           NULL,
                           1,                                   -- Mandant = CSCF
                           2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                           1,                            -- Version 1 du prococol
                           14001,                   -- Type de statistique IBGNCH
                           1,                       -- Validateur: Paul de Blasio
                           13001,                          -- Systlprec (<  100m)
                           12000,                            -- systlref --> CSCF
                           '19950711_Wolserbach_ZH.xlsx',
                           'IBCH_Liste_labo_F',
                           'DIR_IMPORT');

           p_insertprotocol (2,
                           NULL,
                           1,                                   -- Mandant = CSCF
                           2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                           1,                            -- Version 1 du prococol
                           14001,                   -- Type de statistique IBGNCH
                           1,                       -- Validateur: Paul de Blasio
                           13001,                          -- Systlprec (<  100m)
                           12000,                            -- systlref --> CSCF
                           'IBCH_Labo_DF_20130923.xls',
                           'MZB_IBCH (D)',
                           'DIR_IMPORT');
             p_insertprotocol (3,
                           NULL,
                           1,                                   -- Mandant = CSCF
                           2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                           1,                            -- Version 1 du prococol
                           14001,                   -- Type de statistique IBGNCH
                           1,                       -- Validateur: Paul de Blasio
                           13001,                          -- Systlprec (<  100m)
                           12000,                            -- systlref --> CSCF
                           'Cahier_des_charges_MIDAT_20130305.docx',
                           'INVALIDE',
                           'DIR_IMPORT');

             p_insertprotocol (4,
                           NULL,
                           1,                                   -- Mandant = CSCF
                           2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                           1,                            -- Version 1 du prococol
                           14001,                   -- Type de statistique IBGNCH
                           1,                       -- Validateur: Paul de Blasio
                           13001,                          -- Systlprec (<  100m)
                           12000,                            -- systlref --> CSCF
                           'IBCH_Labo_test1.xlsx',
                           'MZB_IBCH (F)',
                           'DIR_IMPORT');

               p_insertprotocol (NULL,
                           NULL,
                           1,                                   -- Mandant = CSCF
                           2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                           1,                            -- Version 1 du prococol
                           14001,                   -- Type de statistique IBGNCH
                           1,                       -- Validateur: Paul de Blasio
                           13001,                          -- Systlprec (<  100m)
                           12000,                            -- systlref --> CSCF
                           'ibCH_LABO_COORDONATEERROR.xls',
                           'MZB_IBCH (D)',
                           'DIR_IMPORT');
                              p_insertprotocol (NULL,
                           NULL,
                           1,                                   -- Mandant = CSCF
                           2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                           1,                            -- Version 1 du prococol
                           14001,                   -- Type de statistique IBGNCH
                           1,                       -- Validateur: Paul de Blasio
                           13001,                          -- Systlprec (<  100m)
                           12000,                            -- systlref --> CSCF
                           'ibCH_LABO_manquant.xls',
                           'MZB_IBCH (F)',
                           'DIR_IMPORT');


                   p_insertprotocol (NULL,
                           NULL,
                           1,                                   -- Mandant = CSCF
                           2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                           1,                            -- Version 1 du prococol
                           14001,                   -- Type de statistique IBGNCH
                           1,                       -- Validateur: Paul de Blasio
                           13001,                          -- Systlprec (<  100m)
                           12000,                            -- systlref --> CSCF
                           'ibCH_LABO_COORDONATEERROR.xls',
                           'MZB_IBCH (D)',
                           'DIR_IMPORT');

                              p_insertprotocol (NULL,
                           NULL,
                           1,                                   -- Mandant = CSCF
                           2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                           1,                            -- Version 1 du prococol
                           14001,                   -- Type de statistique IBGNCH
                           1,                       -- Validateur: Paul de Blasio
                           13001,                          -- Systlprec (<  100m)
                           12000,                            -- systlref --> CSCF
                           'IBCH_Labo_test2.xlsx',
                           'MZB_IBCH (F)',
                           'DIR_IMPORT');

                                   p_insertprotocol (NULL,
                           NULL,
                           1,                                   -- Mandant = CSCF
                           2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                           2,                            -- Version 1 du prococol
                           14001,                   -- Type de statistique IBGNCH
                           1,                       -- Validateur: Paul de Blasio
                           13001,                          -- Systlprec (<  100m)
                           12000,                            -- systlref --> CSCF
                           'IBCH_Raster_DF_test2.xls',
                           'MZB_TAB_IBCH (D)',
                           'DIR_IMPORT');
                          


      p_insertprotocol (NULL,
                        NULL,
                        1,                                   -- Mandant = CSCF
                        2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                        1,                            -- Version 1 du prococol
                        14001,                   -- Type de statistique IBGNCH
                        1,                       -- Validateur: Paul de Blasio
                        13001,                          -- Systlprec (<  100m)
                        12000,                            -- systlref --> CSCF
                        'IBCH_Labo_DF_Correct.xls',
                        'MZB_IBCH (D)',
                        'DIR_IMPORT');



      p_insertprotocol (NULL,
                        NULL,
                        1,                                   -- Mandant = CSCF
                        2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                        3,                            -- Version 3 du prococol
                        14001,                   -- Type de statistique IBGNCH
                        1,                       -- Validateur: Paul de Blasio
                        13001,                          -- Systlprec (<  100m)
                        12000,                            -- systlref --> CSCF
                        'IBCH_Kopfdaten_DF_correct.xls',
                        'MZB_INFO_IBCH (F)',
                        'DIR_IMPORT');
                         
*/

      p_insertprotocol (NULL,
                        NULL,
                        1,                                   -- Mandant = CSCF
                        2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                        4,                            -- Version 3 du prococol
                        14000,              -- Type de statistique IMOKROINDEX
                        1,                       -- Validateur: Paul de Blasio
                        13001,                          -- Systlprec (<  100m)
                        12000,                            -- systlref --> CSCF
                        'MZB_AG_tout_traite_bereinigt.xls',
                        'Tout',
                        'DIR_IMPORT');
   /*
         p_insertmassprotocol (NULL,
                               NULL,
                               pkg_constante.cst_no,              -- ValideStatus
                               1,                               -- Mandant = CSCF
                               2, -- Mandatare = Bureau d'analyse de la qualité des eaux Bernard Robert
                               3,                        -- Version 3 du prococol
                               14000,          -- Type de statistique IMOKROINDEX
                               1,                   -- Validateur: Paul de Blasio
                               pkg_constante.cst_yes,          -- Aboslute number
                               SYSDATE,
                               12000,                        -- systlref --> CSCF
                               13001,                      -- Systlprec (<  100m)
                               'MAKROINDEX_mass.xls',
                               'Sheet 1',
                               'DIR_IMPORT');
                               */
                               NULL;
   END;

   /*-----------------------------------------------------------------------*/
   PROCEDURE p_insertprotocol (
      p_iph_id                       importprotocolheader.iph_id%TYPE,
      p_iph_iph_id                   importprotocolheader.iph_iph_id%TYPE,
      p_iph_ins_id_principal         importprotocolheader.iph_ins_id_principal%TYPE,
      p_iph_ins_id_mandatary         importprotocolheader.iph_ins_id_mandatary%TYPE,
      p_iph_ptv_id                   importprotocolheader.iph_ptv_id%TYPE,
      p_iph_cvl_id_midatstat         importprotocolheader.iph_cvl_id_midatstat%TYPE,
      p_iph_per_id_determinator      importprotocolheader.iph_per_id_determinator%TYPE,
      p_iph_cvl_id_systlprec         importprotocolheader.iph_cvl_id_systlprec%TYPE,
      p_iph_cvl_id_systlref          importprotocolheader.iph_cvl_id_systlref%TYPE,
      p_iph_inputfilename            importprotocolheader.iph_inputfilename%TYPE,
      p_iph_sheetname                importprotocolheader.iph_sheetname%TYPE,
      p_directoryref              IN VARCHAR2)
   IS
      l_lobd      BLOB;
      l_fichier   BFILE := BFILENAME (p_directoryref, p_iph_inputfilename);


      l_blob      INTEGER;
   BEGIN
      -- Obtain the size of the blob file

      DBMS_LOB.fileopen (l_fichier, DBMS_LOB.file_readonly);
      l_blob := DBMS_LOB.getlength (l_fichier);
      DBMS_LOB.fileclose (l_fichier);

      -- Insert a new record into the table containing the
      -- filename you have specified and a LOB LOCATOR.
      -- Return the LOB LOCATOR and assign it to out_blob.
      INSERT INTO importprotocolheader (iph_id,
                                        iph_iph_id,
                                        iph_ins_id_principal,
                                        iph_ins_id_mandatary,
                                        iph_ptv_id,
                                        iph_cvl_id_midatstat,
                                        iph_per_id_determinator,
                                        iph_cvl_id_systlprec,
                                        iph_cvl_id_systlref,
                                        iph_inputfilename,
                                        iph_sheetname,
                                        iph_file)
           VALUES (p_iph_id,
                   p_iph_iph_id,
                   p_iph_ins_id_principal,
                   p_iph_ins_id_mandatary,
                   p_iph_ptv_id,
                   p_iph_cvl_id_midatstat,
                   p_iph_per_id_determinator,
                   p_iph_cvl_id_systlprec,
                   p_iph_cvl_id_systlref,
                   p_iph_inputfilename,
                   p_iph_sheetname,
                   EMPTY_BLOB ())
        RETURNING iph_file
             INTO l_lobd;



      -- Load the image into the database as a BLOB
      DBMS_LOB.open (l_fichier, DBMS_LOB.lob_readonly);
      DBMS_LOB.open (l_lobd, DBMS_LOB.lob_readwrite);
      DBMS_LOB.loadfromfile (l_lobd, l_fichier, l_blob);

      -- Close handles to blob and file
      DBMS_LOB.close (l_lobd);
      DBMS_LOB.close (l_fichier);
      COMMIT;



      RETURN;
   END;

  
END pkg_lob;
/

