create PROCEDURE       BuildListSheet(P_BLOB IN BLOB)
   AS LANGUAGE JAVA NAME 'com.unine.sitel.ProcessProtocol.buildListSheet(oracle.sql.BLOB)';
/

