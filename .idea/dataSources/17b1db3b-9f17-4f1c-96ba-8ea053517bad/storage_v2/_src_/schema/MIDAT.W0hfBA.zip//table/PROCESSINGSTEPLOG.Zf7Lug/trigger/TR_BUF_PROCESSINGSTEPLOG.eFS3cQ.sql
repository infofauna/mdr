create trigger TR_BUF_PROCESSINGSTEPLOG
    before update
    on PROCESSINGSTEPLOG
    for each row
DECLARE
BEGIN
   :new.psl_moddate := SYSDATE;
   :new.psl_moduser := USER;
END;

/

