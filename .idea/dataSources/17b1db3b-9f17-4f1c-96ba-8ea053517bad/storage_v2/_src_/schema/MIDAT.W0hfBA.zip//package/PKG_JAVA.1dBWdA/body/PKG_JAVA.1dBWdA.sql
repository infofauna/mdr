create PACKAGE BODY       pkg_java
AS
   /******************************************************************************
      NAME:       PKG_JAVA
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, octobre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   FUNCTION f_getmaxmemorysize
      RETURN NUMBER
   IS
      LANGUAGE JAVA
      NAME 'oracle.aurora.vm.OracleRuntime.getMaxMemorySize() returns long' ;

   FUNCTION f_setmaxmemorysize (num NUMBER)
      RETURN NUMBER
   /* Pour définir la taille de la mémoire. f_setmaxmemorysize(1024*1204*1024) --> 1Gb */
   IS
      LANGUAGE JAVA
      NAME 'oracle.aurora.vm.OracleRuntime.setMaxMemorySize(long) returns long' ;

   PROCEDURE p_enablenewspace (x NUMBER)
   /* Pour améliorer les performances    p_enablenewspace(0) */
   AS
      LANGUAGE JAVA
      NAME 'oracle.aurora.vm.OracleRuntime.enableNewspace(boolean)' ;

   /*------------------------------------------------------------*/
   FUNCTION f_returncell (p_column IN PLS_INTEGER, p_row IN PLS_INTEGER)
      RETURN VARCHAR2 /*------------------------------------------------------------*/
   AS
      LANGUAGE JAVA
      NAME 'com.unine.sitel.ProcessProtocol.returnCellText(int,int) return java.lang.String' ;


   /*------------------------------------------------------------*/
   FUNCTION f_buildlistsheet (p_blob IN BLOB)
      RETURN NUMBER /*--------------------------------------------------------------*/
   AS
      LANGUAGE JAVA
      NAME 'com.unine.sitel.ProcessProtocol.buildListSheet(oracle.sql.BLOB) return java.lang.Long' ;

   /*-----------------------------------------------------------------*/
   FUNCTION f_deleteotherssheet (p_blob IN BLOB, p_name IN VARCHAR2)
      RETURN BLOB
   /*------------------------------------------------------------------*/
   AS
      LANGUAGE JAVA
      NAME 'com.unine.sitel.ProcessProtocol.deleteOthersSheet(oracle.sql.BLOB, java.lang.String) return oracle.sql.BLOB' ;



   /*------------------------------------------------------------*/
   PROCEDURE p_processinit (p_iph_id NUMBER, p_protocoltype VARCHAR2) /*------------------------------------------------------------*/
   AS
      LANGUAGE JAVA
      NAME 'com.unine.sitel.ProcessProtocol.processInit(long, java.lang.String)' ;

   /*------------------------------------------------------------*/
   PROCEDURE p_processmassdetail (p_iph_id NUMBER)
   /*------------------------------------------------------------*/
   AS
      LANGUAGE JAVA
      NAME 'com.unine.sitel.ProcessProtocol.processMassDetail(long)' ;

   /*------------------------------------------------------------*/
   PROCEDURE p_processprotocollaboratory (p_iph_id NUMBER)
   /*------------------------------------------------------------*/
   AS
      LANGUAGE JAVA
      NAME 'com.unine.sitel.ProcessProtocol.processLaboratory(long)' ;

   /*------------------------------------------------------------*/
   PROCEDURE p_processprotocolgrdval (p_iph_id NUMBER)
   /*------------------------------------------------------------*/
   AS
      LANGUAGE JAVA
      NAME 'com.unine.sitel.ProcessProtocol.processGrdval(long)' ;



   PROCEDURE p_test
   IS
   BEGIN
      DBMS_JAVA.set_output (50);
      p_processinit (593, pkg_codevalue.cst_protocoltype_laboratory);
   --   p_processprotocollaboratory (593);
   END;

   /*------------------------------------------------------------*/
   PROCEDURE p_testdeletesheet
   /*------------------------------------------------------------*/
   IS
      l_blob        importprotocolheader.iph_file%TYPE;
      l_sheetname   importprotocolheader.iph_sheetname%TYPE;
      l_count       NUMBER;
   BEGIN
      SELECT iph_file, iph_sheetname
        INTO l_blob, l_sheetname
        FROM importprotocolheader
       WHERE iph_id = 11 FOR UPDATE;

      DBMS_JAVA.set_output (50);

      l_blob := f_deleteotherssheet (l_blob, l_sheetname);
      l_count := f_buildlistsheet (l_blob);
   END;
END pkg_java;
/

