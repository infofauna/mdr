create PACKAGE       pkg_indice_utility
AS
   /******************************************************************************
      NAME:       PKG_INDICE_UTILITY
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        07/04/2014      burrif       1. Created this package.
   ******************************************************************************/

   TYPE t_mkistartsyvidsublist IS TABLE OF PLS_INTEGER;

   TYPE t_recmkisublist IS RECORD
   (
      sub_mkistartsyvidsublist   t_mkistartsyvidsublist, -- Element de syv_id qui permet de commencer la hiérarchie
      sub_counter                PLS_INTEGER
   );

   -- Table contenant le nombre d'occurence de l'entrée indexé par SYV_ID de l'entrée
   TYPE t_mkisublist IS TABLE OF t_recmkisublist
      INDEX BY PLS_INTEGER;

   -- Table contenant chaque la lsite d'entrée indexé par SYV_ID de l'entrée du niveau de regroupement (exeemple Gastropoda)
   TYPE t_mkidispatchlist IS TABLE OF t_mkisublist
      INDEX BY PLS_INTEGER;


   TYPE t_mkireference IS RECORD
   (
      mki_crf_code              codereference.crf_code%TYPE,
      mki_counter               NUMBER,
      mki_normalizedcounter     NUMBER,
      mki_normalizedcountflag   CHAR (1)
   );

   TYPE t_ibchvalue IS RECORD
   (
      ibc_ptl_id    protocolmappinglabo.ptl_id%TYPE,
      ibc_counter   NUMBER
   );

   TYPE t_ibchvaluemass IS RECORD
   (
      ibm_syv_id    systvalue.syv_id%TYPE,
      ibm_counter   NUMBER
   );

   TYPE t_spearvalue IS RECORD
   (
      spr_syv_id             speardatalinkcscf.sdf_syv_id%TYPE,
      spr_spearindexfactor   NUMBER,
      spr_counter            NUMBER
   );



   TYPE t_listibchvalue IS TABLE OF t_ibchvalue;

   TYPE t_listibchvaluemass IS TABLE OF t_ibchvaluemass;

   TYPE t_listspearvalue IS TABLE OF t_spearvalue;

   TYPE t_listmkireference IS TABLE OF t_mkireference
      INDEX BY systdesignation.syd_designation%TYPE;

   cst_abondanceflag_class          CONSTANT VARCHAR2 (10) := 'CLASS';
   cst_abondanceflag_absolu         CONSTANT VARCHAR2 (10) := 'ABS';
   cst_mki_plecoptera               CONSTANT systdesignation.syd_designation%TYPE
                                                := 'Plecoptera' ;
   cst_mki_plecoptera_crf_code      CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_order ;

   cst_mki_trichoptera              CONSTANT systdesignation.syd_designation%TYPE
      := 'Trichoptera' ;
   cst_mki_trichoptera_crf_code     CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_order ;

   cst_mki_ephemeroptera            CONSTANT systdesignation.syd_designation%TYPE
      := 'Ephemeroptera' ;
   cst_mki_ephemeroptera_crf_code   CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_order ;

   cst_mki_baetidae                 CONSTANT systdesignation.syd_designation%TYPE
      := 'Baetidae' ;
   cst_mki_baetidae_crf_code        CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_family ;

   cst_mki_gammarus                 CONSTANT systdesignation.syd_designation%TYPE
      := 'Gammarus' ;
   cst_mki_gammarus_crf_code        CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_genus ;

   cst_mki_hydropsyche              CONSTANT systdesignation.syd_designation%TYPE
      := 'Hydropsyche' ;
   cst_mki_hydropsyche_crf_code     CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_genus ;

   cst_mki_asellus                  CONSTANT systdesignation.syd_designation%TYPE
      := 'Asellus' ;
   cst_mki_asellus_crf_code         CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_genus ;

   cst_mki_hirudinea                CONSTANT systdesignation.syd_designation%TYPE
      := 'Hirudinea' ;
   cst_mki_hirudinea_crf_code       CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_class ;

   cst_mki_tubificidae              CONSTANT systdesignation.syd_designation%TYPE
      := 'Tubificidae' ;
   cst_mki_tubificidae_crf_code     CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_family ;

   cst_mki_insecta                  CONSTANT systdesignation.syd_designation%TYPE
      := 'Insecta' ;
   cst_mki_insecta_crf_code         CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_class ;
   cst_insectaratio_zerodivide      CONSTANT NUMBER := 9999;
   cst_mkinotset                    CONSTANT NUMBER := -1;

   cst_species_code                 CONSTANT VARCHAR2 (3) := 'sp.';
   cst_species_syv_id_addoperator   CONSTANT NUMBER := -1;

   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_mkiisinsecta (p_syv_id IN systvalue.syv_id%TYPE)
      RETURN CHAR;

   FUNCTION f_mkibuilddesignationstart (p_recmkisublist IN t_recmkisublist)
      RETURN VARCHAR2;

   PROCEDURE p_mkicomputemormalizedvalue;

   FUNCTION f_gblmkiexculetricoptera
      RETURN NUMBER;

   FUNCTION f_getgblmkidispatchlist
      RETURN t_mkidispatchlist;

   PROCEDURE p_displaymkidispatch;

   PROCEDURE p_mkicomputeinsectaratio;


   FUNCTION f_getgblinsectacount
      RETURN NUMBER;

   FUNCTION f_getgblnormalizedcount
      RETURN NUMBER;

   FUNCTION f_getgblibchidentifiedtaxoncou
      RETURN NUMBER;

   FUNCTION f_getgblibchgi
      RETURN NUMBER;

   FUNCTION f_getgblibchvt
      RETURN NUMBER;

   FUNCTION f_getgblrangecount
      RETURN NUMBER;

   FUNCTION f_getmkierror
      RETURN NUMBER;

   FUNCTION f_getmkicvlcodecase
      RETURN codevalue.cvl_code%TYPE;

   FUNCTION f_getgblmkiinsectaratio
      RETURN NUMBER;

   FUNCTION f_getgblmkitotalcounter
      RETURN NUMBER;

   FUNCTION f_getgblmkireference
      RETURN t_listmkireference;

   FUNCTION f_getmkinoninsectacount
      RETURN NUMBER;

   FUNCTION f_getgblmkirangeselected
      RETURN VARCHAR2;

   FUNCTION f_computeibchfromsample (p_sph_id          IN sampleheader.sph_id%TYPE, -- A partir des données enregistrée dans SAMPLEPROTOCOLLABO
                                     p_abondanceflag   IN VARCHAR2)
      RETURN NUMBER;

   FUNCTION f_computeibchfromimport (
      p_ipl_iph_id      IN importprotocollabo.ipl_iph_id%TYPE,
      p_abondanceflag   IN VARCHAR2)
      RETURN NUMBER;

   PROCEDURE p_ibchinit;

   PROCEDURE p_test;

   PROCEDURE p_ibchadddataclass (
      p_ptl_id   IN sampleprotocollabo.spl_ptl_id%TYPE,
      p_count    IN sampleprotocollabo.spl_frequency%TYPE);

   PROCEDURE p_ibchadddata (
      p_ptl_id   IN sampleprotocollabo.spl_ptl_id%TYPE,
      p_count    IN sampleprotocollabo.spl_frequency%TYPE);

   FUNCTION f_computeibchfrommemory (p_abondanceflag IN VARCHAR2)
      RETURN NUMBER;

   PROCEDURE p_spearvalueinit;


   PROCEDURE p_convertmass2ibch (
      p_ptv_id   IN protocolversion.ptv_id%TYPE,
      p_iph_id   IN importprotocolheader.iph_id%TYPE,
      p_imh_id   IN importmassdataheader.imh_id%TYPE);

   PROCEDURE p_loadspearlistfromibchlist (
      p_iph_id IN importprotocolheader.iph_id%TYPE);

   PROCEDURE p_spearadddataclass (
      p_syv_id    IN     speardatalinkcscf.sdf_syv_id%TYPE,
      p_counter   IN     NUMBER,
      p_status       OUT NUMBER);

   PROCEDURE p_spearadddata (
      p_syv_id    IN     speardatalinkcscf.sdf_syv_id%TYPE,
      p_counter   IN     NUMBER,
      p_status       OUT NUMBER);

   FUNCTION f_spearreturnlistvalue
      RETURN t_listspearvalue;

   FUNCTION f_computespearfrommemory (p_abondanceflag IN VARCHAR2)
      RETURN NUMBER;

   PROCEDURE p_checkifspearcanbecomputed (
      p_iph_id   IN     importprotocolheader.iph_id%TYPE,
      p_status      OUT NUMBER);


   PROCEDURE p_mkiinit;

   FUNCTION f_computemakroindex
      RETURN NUMBER;

   PROCEDURE p_mkiadddata (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_syv_id                    IN sampleprotocollabo.spl_syv_id%TYPE,
      p_count                     IN sampleprotocollabo.spl_frequency%TYPE,
      p_species                   IN importmassdatadetail.imd_species%TYPE);


   PROCEDURE p_mkicheckthesaurusoneentry (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id                 IN     language.lan_id%TYPE,
      p_mkidesignation         IN     systdesignation.syd_designation%TYPE,
      p_mkicrfcode             IN     codereference.crf_code%TYPE,
      p_returnstatus              OUT NUMBER);

   PROCEDURE p_mkicheckthesaurus (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id                 IN     language.lan_id%TYPE,
      p_returnstatus              OUT NUMBER);

   PROCEDURE p_checkmkiidentifylist (
      p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                    IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id                    IN     language.lan_id%TYPE,
      p_returnstatus                 OUT NUMBER);

   PROCEDURE p_initlistibchvaluemass;

   PROCEDURE p_addlistibchvaluemass (p_syv_id   IN systvalue.syv_id%TYPE,
                                     p_count       NUMBER);
END pkg_indice_utility;
/

