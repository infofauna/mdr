create PACKAGE       pkg_sampleheadermassfile
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEHEADERMASSFILE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
      1.1        24.10.2017      burrif       2. Version 2 de MIDAT
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_delete (p_smf_id IN sampleheadermassfile.smf_id%TYPE);

   PROCEDURE p_deleteconditional (
      p_smf_id   IN sampleheadermassfile.smf_id%TYPE);

   PROCEDURE p_write (
      p_ptv_id      IN     sampleheadermassfile.smf_ptv_id%TYPE,
      p_lan_id      IN     sampleheadermassfile.smf_lan_id%TYPE,
      p_file        IN     sampleheadermassfile.smf_file%TYPE,
      p_filename    IN     sampleheadermassfile.smf_filename%TYPE,
      p_sheetname   IN     sampleheadermassfile.smf_sheetname%TYPE,
      p_usr_id      IN     sampleheadermassfile.smf_usr_id_create%TYPE,
      p_smf_id         OUT sampleheadermassfile.smf_id%TYPE);

   FUNCTION f_getrecord (p_smf_id IN sampleheadermassfile.smf_id%TYPE)
      RETURN sampleheadermassfile%ROWTYPE;
END pkg_sampleheadermassfile;
/

