create PACKAGE       pkg_spear2019
AS
    /******************************************************************************
      NAME:       PKG_MIGR_SPEAR2019
      PURPOSE:     Calcul de l'indice SPEAR2019

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
   ******************************************************************************/

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2020';
    cst_startprotversion_spear2019   CONSTANT NUMBER := 3;

    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_addfrequence (
        p_ptl_id      IN protocolmappinglabo.ptl_id%TYPE,
        p_frequence   IN importprotocollabo.ipl_value%TYPE);

    FUNCTION f_getspear
        RETURN NUMBER;

    PROCEDURE p_init;

    PROCEDURE p_computespear;

    PROCEDURE p_maincompute (
        p_recprotocolheader   IN importprotocolheader%ROWTYPE,
        p_recmassdataheader   IN importmassdataheader%ROWTYPE);
END;
/

