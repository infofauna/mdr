create PACKAGE BODY       pkg_migr_tricopterascabbard
AS
   /******************************************************************************
      NAME:       .pkg_MIGR_tricopterascabbard
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        13.03.2015     burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, mars  2015';

   TYPE t_listtrichoptera IS TABLE OF CHAR (1)
      INDEX BY tricopterascabbard.tsd_text%TYPE;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_load
   /*---------------------------------------------------------------*/
   IS
      l_sql                  VARCHAR2 (1024);
      l_syv_id               tricopterascabbard.tsd_syv_id%TYPE;
      l_text                 tricopterascabbard.tsd_text%TYPE;
      l_hasscabbard          tricopterascabbard.tsd_hasscabbard%TYPE;
      l_recsystdesignation   systdesignation%ROWTYPE;
      l_tsd_id               tricopterascabbard.tsd_id%TYPE;
      l_listtrichoptera      t_listtrichoptera;
      l_key                  tricopterascabbard.tsd_text%TYPE;
   BEGIN
      DELETE FROM tricopterascabbard;

      l_sql := 'DROP SEQUENCE SEQ_tricopterascabbard';

      EXECUTE IMMEDIATE l_sql;

      l_sql := 'CREATE SEQUENCE SEQ_tricopterascabbard';

      EXECUTE IMMEDIATE l_sql;


      l_text := 'Apataniidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;
      l_text := 'Beraeidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;
      l_text := 'Brachycentridae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Ecnomidae';
      l_hasscabbard := pkg_constante.cst_no;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Glossosomatidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Goeridae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Helicopsychidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;


      l_text := 'Hydropsychidae';
      l_hasscabbard := pkg_constante.cst_no;
      l_listtrichoptera (l_text) := l_hasscabbard;


      l_text := 'Hydroptilidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Lepidostomatidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;


      l_text := 'Leptoceridae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;


      l_text := 'Limnephilidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Molannidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Odontoceridae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Philopotamidae';
      l_hasscabbard := pkg_constante.cst_no;
      l_listtrichoptera (l_text) := l_hasscabbard;


      l_text := 'Phryganeidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;


      l_text := 'Polycentropodidae';
      l_hasscabbard := pkg_constante.cst_no;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Psychomyiidae';
      l_hasscabbard := pkg_constante.cst_no;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Ptilocolepidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;


      l_text := 'Rhyacophilidae';
      l_hasscabbard := pkg_constante.cst_no;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Sericostomatidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Arctopsychidae';
      l_hasscabbard := pkg_constante.cst_no;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Calamoceratidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;

      l_text := 'Uenoidae';
      l_hasscabbard := pkg_constante.cst_yes;
      l_listtrichoptera (l_text) := l_hasscabbard;


      l_key := l_listtrichoptera.FIRST;

      WHILE NOT l_key IS NULL
      LOOP
         l_text := l_key;
         l_hasscabbard := l_listtrichoptera (l_key);
         l_recsystdesignation :=
            pkg_systdesignation.f_getrecordbyleveldesignation (
               l_text,
               pkg_codereference.cst_crf_family);

         IF l_recsystdesignation.syd_id IS NULL
         THEN
            raise_application_error (-20000,
                                     'Taxon ' || l_text || ' non trouvé',
                                     TRUE);
         END IF;


         pkg_tricopterascabbard.p_write (l_recsystdesignation.syd_syv_id,
                                         l_text,
                                         l_hasscabbard,
                                         l_tsd_id);
         l_key := l_listtrichoptera.NEXT (l_key);
      END LOOP;
   END;
END pkg_migr_tricopterascabbard;
/

