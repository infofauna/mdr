create PACKAGE BODY       pkg_sampleheaderitem
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEHEADERITEM
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       25.07.2013  F.Burri           1. Created this package body.
   ******************************************************************************/
   gbl_debugflag        BOOLEAN;
   cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2013';

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-----------------------------------------------------------------------*/
   FUNCTION f_getrecordfromlaboratory (
      p_sph_id         IN sampleheader.sph_id%TYPE,
      p_midathditmty   IN codevalue.cvl_code%TYPE)
      RETURN sampleheaderitem%ROWTYPE
   /*-----------------------------------------------------------------------*/
   IS
      /* En interrogant comme ceci, il n'a a qu'un laboratory par langue */
      l_recsampleheaderitem   sampleheaderitem%ROWTYPE;
      l_reccodevalue          codevalue%ROWTYPE;
      l_reccodevaluetype      codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getfromcode (p_midathditmty,
                                      pkg_codereference.cst_crf_midathditmty);

      IF l_reccodevalue.cvl_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      l_reccodevaluetype :=
         pkg_codevalue.f_getfromcode (
            pkg_codevalue.cst_protocoltype_laboratory,
            pkg_codereference.cst_crf_midatproto);

      IF l_reccodevaluetype.cvl_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      SELECT *
        INTO l_recsampleheaderitem
        FROM sampleheaderitem
       WHERE     shm_sph_id = p_sph_id
             AND shm_cvl_id_midathditmty = l_reccodevalue.cvl_id
             AND shm_cvl_id_midatproto = l_reccodevaluetype.cvl_id;

      RETURN l_recsampleheaderitem;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-----------------------------------------------------------------------*/
   FUNCTION f_getrecordwithtypeandlanid (
      p_sph_id         IN sampleheaderitem.shm_sph_id%TYPE,
      p_midathditmty   IN codevalue.cvl_code%TYPE,
      p_lan_id         IN sampleheaderitem.shm_lan_id%TYPE)
      RETURN sampleheaderitem%ROWTYPE
   /*-----------------------------------------------------------------------*/
   IS
      l_recsampleheaderitem        sampleheaderitem%ROWTYPE;
      l_reccodevalue               codevalue%ROWTYPE;
      l_reccodevalueprotocollabo   codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getfromcode (p_midathditmty,
                                      pkg_codereference.cst_crf_midathditmty);

      IF l_reccodevalue.cvl_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      l_reccodevalueprotocollabo :=
         pkg_codevalue.f_getfromcode (
            pkg_codevalue.cst_protocoltype_laboratory,
            pkg_codereference.cst_crf_midatproto);

      IF l_reccodevalue.cvl_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      SELECT *
        INTO l_recsampleheaderitem
        FROM sampleheaderitem
       WHERE     shm_sph_id = p_sph_id
             AND shm_cvl_id_midathditmty = l_reccodevalue.cvl_id
             AND shm_lan_id = p_lan_id
             AND shm_cvl_id_midatproto = l_reccodevalueprotocollabo.cvl_id;

      RETURN l_recsampleheaderitem;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-----------------------------------------------------------------------*/
   PROCEDURE p_deleteby_sph_id (p_sph_id IN sampleheaderitem.shm_sph_id%TYPE)
   /*----------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleheaderitem
            WHERE shm_sph_id = p_sph_id;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_deleteby_ptv_id (
      p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE,
      p_ptv_id   IN sampleheader.sph_ptv_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
      l_recprotocolversion   protocolversion%ROWTYPE;
   BEGIN
      l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);

      IF l_recprotocolversion.ptv_id IS NULL
      THEN
         RETURN;
      END IF;

      DELETE FROM sampleheaderitem
            WHERE     shm_cvl_id_midatproto =
                         l_recprotocolversion.ptv_cvl_id_protocoltype
                  AND shm_sph_id = p_sph_id;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_deleteby_cvl_id_protocoltype (
      p_sph_id                IN sampleheaderitem.shm_sph_id%TYPE,
      p_cvl_id_protocoltype   IN sampleheaderitem.shm_cvl_id_midatproto%TYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleheaderitem
            WHERE     shm_cvl_id_midatproto = p_cvl_id_protocoltype
                  AND shm_sph_id = p_sph_id;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_get_typecodefromtableperson
      RETURN VARCHAR2
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      RETURN cst_typecodefromtableperson;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_get_typecodefromexcelform
      RETURN VARCHAR2
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      RETURN cst_typecodefromexcelform;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecord (p_shm_id IN sampleheaderitem.shm_id%TYPE)
      RETURN sampleheaderitem%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record   sampleheaderitem%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM sampleheaderitem
       WHERE shm_id = p_shm_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_check (p_command   IN     VARCHAR2,
                      p_oldrec    IN     sampleheaderitem%ROWTYPE,
                      p_newrec    IN OUT sampleheaderitem%ROWTYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      NULL;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_tr_bif_sampleheaderitem (
      p_newrec   IN OUT sampleheaderitem%ROWTYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      p_newrec.shm_credate := SYSDATE;
      p_newrec.shm_creuser := USER;

      IF p_newrec.shm_id IS NULL
      THEN
         p_newrec.shm_id := seq_sampleheaderitem.NEXTVAL;
      END IF;

      p_check (pkg_constante.cst_dml_command_insert, NULL, p_newrec);
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_tr_buf_sampleheaderitem (
      p_oldrec   IN     sampleheaderitem%ROWTYPE,
      p_newrec   IN OUT sampleheaderitem%ROWTYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      p_newrec.shm_moddate := SYSDATE;
      p_newrec.shm_moduser := USER;
      p_check (pkg_constante.cst_dml_command_update, p_oldrec, p_newrec);
   END;


   /*----------------------------------------------------------------------------------*/
   PROCEDURE p_write (
      p_sph_id                IN     sampleheaderitem.shm_sph_id%TYPE,
      p_lan_id                IN     sampleheaderitem.shm_lan_id%TYPE,
      p_cvl_id_midathditmty   IN     sampleheaderitem.shm_cvl_id_midathditmty%TYPE,
      p_ptv_id                IN     sampleheaderitem.shm_ptv_id%TYPE,
      p_typecode              IN     sampleheaderitem.shm_typecode%TYPE,
      p_item                  IN     sampleheaderitem.shm_item%TYPE,
      p_per_id                IN     sampleheaderitem.shm_per_id%TYPE,
      p_usr_id                IN     sampleheaderitem.shm_usr_id_create%TYPE,
      p_id                       OUT sampleheaderitem.shm_id%TYPE)
   /*---------------------------------------------------------------------------------*/
   IS
      l_recprotocolversion   protocolversion%ROWTYPE;
   BEGIN
      l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);
      p_id := seq_sampleheaderitem.NEXTVAL;

      INSERT INTO sampleheaderitem (shm_id,
                                    shm_lan_id,
                                    shm_sph_id,
                                    shm_ptv_id,
                                    shm_cvl_id_midathditmty,
                                    shm_cvl_id_midatproto,
                                    shm_typecode,
                                    shm_item,
                                    shm_per_id,
                                    shm_usr_id_create,
                                    shm_usr_create_date)
           VALUES (p_id,
                   p_lan_id,
                   p_sph_id,
                   p_ptv_id,
                   p_cvl_id_midathditmty,
                   l_recprotocolversion.ptv_cvl_id_protocoltype, -- Cette table est dénormalisé pour simplifier l'interface WEB
                   p_typecode,
                   p_item,
                   p_per_id,
                   p_usr_id,
                   SYSDATE);

      NULL;
   END;

   /*----------------------------------------------------------------------------------*/
   PROCEDURE p_writeconditionnaly (
      p_sph_id                IN     sampleheaderitem.shm_sph_id%TYPE,
      p_lan_id                IN     sampleheaderitem.shm_lan_id%TYPE,
      p_cvl_id_midathditmty   IN     sampleheaderitem.shm_cvl_id_midathditmty%TYPE,
      p_ptv_id                IN     sampleheaderitem.shm_ptv_id%TYPE,
      p_typecode              IN     sampleheaderitem.shm_typecode%TYPE,
      p_item                  IN     sampleheaderitem.shm_item%TYPE,
      p_per_id                IN     sampleheaderitem.shm_per_id%TYPE,
      p_usr_id                IN     sampleheaderitem.shm_usr_id_create%TYPE,
      p_id                       OUT sampleheaderitem.shm_id%TYPE)
   /*---------------------------------------------------------------------------------*/
   IS
      l_recprotocolversion    protocolversion%ROWTYPE;
      l_recsampleheaderitem   sampleheaderitem%ROWTYPE;
   BEGIN
      l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);

      -- Si la valeur existe déjà dans la langue on ne la sauve pas

      l_recsampleheaderitem :=
         pkg_sampleheaderitem.f_getrecordwithtypeandlanid (
            p_sph_id,
            p_cvl_id_midathditmty,
            p_lan_id);
      DBMS_OUTPUT.put_line (
         'l_recsampleheaderitem.shm_id=' || l_recsampleheaderitem.shm_id);

      IF NOT l_recsampleheaderitem.shm_id IS NULL
      THEN
         --  Le contrôle que la valeur p_item est identique à la valeur sauvée est réalisé dans la validation
         -- on sort simplement
         RETURN;
      END IF;

      p_id := seq_sampleheaderitem.NEXTVAL;

      INSERT INTO sampleheaderitem (shm_id,
                                    shm_lan_id,
                                    shm_sph_id,
                                    shm_cvl_id_midathditmty,
                                    shm_ptv_id,
                                    shm_cvl_id_midatproto,
                                    shm_typecode,
                                    shm_item,
                                    shm_per_id,
                                    shm_usr_id_create,
                                    shm_usr_create_date)
           VALUES (p_id,
                   p_lan_id,
                   p_sph_id,
                   p_cvl_id_midathditmty,
                   p_ptv_id,
                   l_recprotocolversion.ptv_cvl_id_protocoltype, -- Cette table est dénormalisé pour simplifier l'interface WEB
                   p_typecode,
                   p_item,
                   p_per_id,
                   p_usr_id,
                   SYSDATE);

      NULL;
   END;
END pkg_sampleheaderitem;
/

