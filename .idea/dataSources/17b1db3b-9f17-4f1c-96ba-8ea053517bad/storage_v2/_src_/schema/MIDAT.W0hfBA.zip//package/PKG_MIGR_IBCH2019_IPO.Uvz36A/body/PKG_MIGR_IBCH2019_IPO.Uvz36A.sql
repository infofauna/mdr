create PACKAGE BODY       pkg_migr_ibch2019_ipo
AS
    /******************************************************************************
       NAME:       PKG_MIGR_IBCH2019_iph
       PURPOSE:    Modification dans la table IMPORTPROTOCOLLOG

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       15.05.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-------------------------------------------------------------------*/
    PROCEDURE p_deletebyptv_id (
        p_ptv_id   IN importprotocolheader.iph_ptv_id%TYPE)
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM importprotocollogparam
              WHERE ipr_ipo_id IN
                        (SELECT ipo_id
                           FROM importprotocollog
                          WHERE ipo_iph_id IN (SELECT iph_id
                                                 FROM importprotocolheader
                                                WHERE iph_ptv_id = p_ptv_id));

        DELETE FROM importprotocollog
              WHERE ipo_iph_id IN (SELECT iph_id
                                     FROM importprotocolheader
                                    WHERE iph_ptv_id = p_ptv_id);
    END;
END pkg_migr_ibch2019_ipo;
/

