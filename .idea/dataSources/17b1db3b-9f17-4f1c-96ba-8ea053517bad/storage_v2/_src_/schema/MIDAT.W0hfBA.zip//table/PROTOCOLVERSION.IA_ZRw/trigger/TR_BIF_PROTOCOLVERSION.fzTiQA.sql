create trigger TR_BIF_PROTOCOLVERSION
    before insert
    on PROTOCOLVERSION
    for each row
DECLARE
BEGIN
   IF :new.PTV_id IS NULL
   THEN
      :new.PTV_id := seq_PROTOCOLVERSION.NEXTVAL;
   END IF;

   :new.PTV_credate := SYSDATE;
   :new.PTV_creuser := USER;
END tr_bif_PROTOCOLVERSION;

/

