create PACKAGE BODY pkg_migr_importmassstation
AS
   /******************************************************************************
      NAME:       PKG_MIGR_IMPORTMASSSTATION
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        07.06.2018      burrif       1. Created this package.
   ******************************************************************************/



   cst_srid_ch_lv03     CONSTANT NUMBER := 21781;              -- CH1903 /LV03
   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, juin  2018';

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_externalise_z
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE importmassstation ip1
         SET ims_z =
                (SELECT ip.ims_coordinates.sdo_point.z
                   FROM importmassstation ip
                  WHERE ip.ims_id = ip1.ims_id);
   END;

   /*-------------------------------------------------------------------------*/
   FUNCTION f_buildsdo_geometry (p_x IN NUMBER, p_y IN NUMBER)
      RETURN MDSYS.sdo_geometry
   /*-------------------------------------------------------------------------*/
   IS
      l_sdo_geometry   MDSYS.sdo_geometry;
   BEGIN
      l_sdo_geometry :=
         mdsys.sdo_geometry (2001,                              -- Point en 2d
                             cst_srid_ch_lv03,                 -- CH1903 /LV03
                             mdsys.sdo_point_type (p_x, p_y, NULL),
                             NULL,
                             NULL);
      RETURN l_sdo_geometry;
   END;

   /*---------------------------------------------------------------------------*/
   FUNCTION f_convert3dto2d (p_coordinates IN MDSYS.sdo_geometry)
      RETURN MDSYS.sdo_geometry
   /*---------------------------------------------------------------------------*/
   IS
      l_reccoordinates   MDSYS.sdo_geometry;
   BEGIN
      IF p_coordinates.sdo_gtype = 2001
      THEN                                                      -- Déjà en 2 d
         RETURN p_coordinates;
      END IF;

      l_reccoordinates :=
         f_buildsdo_geometry (p_coordinates.sdo_point.x,
                              p_coordinates.sdo_point.y);
      RETURN l_reccoordinates;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_delete_sdo_geom_metadata (p_status OUT BOOLEAN)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM user_sdo_geom_metadata
            WHERE     table_name = 'IMPORTMASSSTATION'
                  AND column_name = 'IMS_COORDINATES';

      IF SQL%ROWCOUNT > 0
      THEN
         p_status := TRUE;
      ELSE
         p_status := FALSE;
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_status := FALSE;
         NULL;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_insert_geom_metadata
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      INSERT INTO user_sdo_geom_metadata
           VALUES ('IMPORTMASSSTATION',
                   'IMS_COORDINATES',
                   mdsys.sdo_dim_array (mdsys.sdo_dim_element ('X',
                                                               480000,
                                                               837000,
                                                               1),
                                        mdsys.sdo_dim_element ('Y',
                                                               75000,
                                                               300000,
                                                               1)),
                   21781);
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_insert_geom_metadata_3d
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      INSERT INTO user_sdo_geom_metadata
           VALUES ('IMPORTMASSSTATION',
                   'IMS_COORDINATES',
                   mdsys.sdo_dim_array (mdsys.sdo_dim_element ('X',
                                                               480000,
                                                               837000,
                                                               1),
                                        mdsys.sdo_dim_element ('Y',
                                                               75000,
                                                               300000,
                                                               1),
                                        mdsys.sdo_dim_element ('Z',
                                                               0,
                                                               5000,
                                                               1)),
                   21781);
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_drop_index (p_status OUT BOOLEAN)
   /*---------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (256) := 'DROP INDEX IDX_IMPORTMASSSTATION';
   BEGIN
      p_status := TRUE;

      EXECUTE IMMEDIATE l_sql;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_status := FALSE;
         NULL;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_create_index
   /*---------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (256)
         := 'create  INDEX IDX_IMPORTMASSSTATION ON importmassstation (ims_coordinates)
   INDEXTYPE IS mdsys.spatial_index';
   BEGIN
      EXECUTE IMMEDIATE l_sql;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_restore_sdo_point_z
   /*----------------------------------------------------------------*/
   IS
      l_status_sdo_geom_metadata   BOOLEAN;
      l_status_index               BOOLEAN;
   BEGIN
      p_delete_sdo_geom_metadata (l_status_sdo_geom_metadata);
      p_drop_index (l_status_index);

      UPDATE importmassstation
         SET ims_coordinates = ims_coordinates_save;

      IF l_status_sdo_geom_metadata
      THEN
         p_insert_geom_metadata_3d;
      END IF;

      IF l_status_index
      THEN
         p_create_index;
      END IF;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_save_sdo_point_z
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE importmassstation
         SET ims_coordinates_save = ims_coordinates;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_clear_sdo_point_z
   /*----------------------------------------------------------------*/
   IS
      l_coordinates                MDSYS.sdo_geometry;

      CURSOR l_cursor
      IS
         SELECT *
           FROM importmassstation
         FOR UPDATE;

      l_reccursor                  l_cursor%ROWTYPE;
      l_status_sdo_geom_metadata   BOOLEAN;
      l_status_index               BOOLEAN;
   BEGIN
      p_delete_sdo_geom_metadata (l_status_sdo_geom_metadata);
      p_drop_index (l_status_index);


      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         l_coordinates := f_convert3dto2d (l_reccursor.ims_coordinates);

         UPDATE importmassstation
            SET ims_coordinates = l_coordinates
          WHERE CURRENT OF l_cursor;
      END LOOP;

      CLOSE l_cursor;

      IF l_status_sdo_geom_metadata
      THEN
         p_insert_geom_metadata;
      END IF;

      IF l_status_index
      THEN
         p_create_index;
      END IF;
   END;
END pkg_migr_importmassstation;
/

