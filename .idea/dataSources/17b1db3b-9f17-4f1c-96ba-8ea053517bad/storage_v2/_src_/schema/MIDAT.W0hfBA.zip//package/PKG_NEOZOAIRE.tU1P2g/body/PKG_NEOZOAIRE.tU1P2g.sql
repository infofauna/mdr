create PACKAGE BODY       pkg_neozoaire
AS
    /******************************************************************************
       NAME:       PKG_NEOZOAIRE
       PURPOSE:    NEOZOAIRE

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
    ******************************************************************************/



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getrecord (p_id IN neozoaire.neo_id%TYPE)
        RETURN neozoaire%ROWTYPE
    /*---------------------------------------------------------------*/
    IS
        l_recneozoaire   neozoaire%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recneozoaire
          FROM neozoaire
         WHERE neo_id = p_id;

        RETURN l_recneozoaire;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getrecordbydesignation (
        p_designation   IN neozoaire.neo_designation%TYPE)
        RETURN neozoaire%ROWTYPE
    /*---------------------------------------------------------------*/
    IS
        l_recneozoaire   neozoaire%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recneozoaire
          FROM neozoaire
         WHERE TRIM (UPPER (neo_designation)) = UPPER (TRIM (p_designation));

        RETURN l_recneozoaire;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_insert (
        p_code          IN     neozoaire.neo_code%TYPE,
        p_order         IN     neozoaire.neo_order%TYPE,
        p_syv_id        IN     neozoaire.neo_syv_id%TYPE,
        p_designation   IN     neozoaire.neo_designation%TYPE,
        p_id               OUT neozoaire.neo_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        p_id := seq_neozoaire.NEXTVAL;

        INSERT INTO neozoaire (neo_id,
                               neo_code,
                               neo_order,
                               neo_syv_id,
                               neo_designation)
             VALUES (p_id,
                     p_code,
                     p_order,
                     p_syv_id,
                     p_designation);

        NULL;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_updatesyv_id (p_id       IN neozoaire.neo_id%TYPE,
                              p_syv_id   IN neozoaire.neo_syv_id%TYPE)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE neozoaire
           SET neo_syv_id = p_syv_id
         WHERE neo_id = p_id;
    END;
END;
/

