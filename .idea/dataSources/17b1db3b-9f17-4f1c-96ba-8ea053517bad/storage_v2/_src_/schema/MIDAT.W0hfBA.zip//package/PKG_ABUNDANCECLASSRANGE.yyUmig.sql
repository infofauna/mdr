create PACKAGE       pkg_abundanceclassrange
AS
   /******************************************************************************
      NAME:       PKG_ABUNDANCECLASSRANGE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.02.2015      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_test1;

   PROCEDURE p_test;

   FUNCTION f_getrecordbyclass (
      p_code_midatindice   IN codevalue.cvl_code%TYPE,
      p_class              IN abundanceclassrange.acr_classe%TYPE)
      RETURN abundanceclassrange%ROWTYPE;

   FUNCTION f_getrecordbyindiceandvalue (
      p_code_midatindice   IN codevalue.cvl_code%TYPE,
      p_value              IN abundanceclassrange.acr_minvalue%TYPE)
      RETURN abundanceclassrange%ROWTYPE;

   PROCEDURE p_write (
      p_cvl_id_midatindice   IN     abundanceclassrange.acr_cvl_id_midatindice%TYPE,
      p_minvalue             IN     abundanceclassrange.acr_minvalue%TYPE,
      p_maxvalue             IN     abundanceclassrange.acr_maxvalue%TYPE,
      p_classe               IN     abundanceclassrange.acr_classe%TYPE,
      p_substitutevalue      IN     abundanceclassrange.acr_substitutevalue%TYPE,
      p_id                      OUT abundanceclassrange.acr_id%TYPE);
END pkg_abundanceclassrange;
/

