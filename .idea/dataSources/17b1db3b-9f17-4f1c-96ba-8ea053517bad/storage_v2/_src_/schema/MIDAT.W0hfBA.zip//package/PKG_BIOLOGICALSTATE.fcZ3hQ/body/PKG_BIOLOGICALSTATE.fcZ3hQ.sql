create PACKAGE BODY       pkg_biologicalstate
AS
    /******************************************************************************
       NAME:       pkg_biologicalstate
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        25.09.2013      burrif       1. Created this package.
       1.1        08.10.2020      burrif       1 IBCH 2019
    ******************************************************************************/


    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.1, octobre  2019' ;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_write (
        p_order                 IN     biologicalstate.bls_order%TYPE,
        p_cvl_id_midatindice    IN     biologicalstate.bls_cvl_id_midatindice%TYPE,
        p_cvl_id_biolstatetxt   IN     biologicalstate.bls_cvl_id_biolstatetxt%TYPE,
        p_cvl_id_colorindex     IN     biologicalstate.bls_cvl_id_colorindex%TYPE,
        p_cvl_id_colorindext    IN     biologicalstate.bls_cvl_id_colorindextext%TYPE,
        p_fromvalue             IN     biologicalstate.bls_fromvalue%TYPE,
        p_tovalue               IN     biologicalstate.bls_tovalue%TYPE,
        p_literalrange          IN     biologicalstate.bls_literalrange%TYPE,
        p_ivr_id                IN     biologicalstate.bls_ivr_id%TYPE,
        p_id                       OUT biologicalstate.bls_id%TYPE)
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        p_id := seq_biologicalstate.NEXTVAL;

        INSERT INTO biologicalstate (bls_id,
                                     bls_order,
                                     bls_cvl_id_midatindice,
                                     bls_cvl_id_biolstatetxt,
                                     bls_cvl_id_colorindex,
                                     bls_cvl_id_colorindextext,
                                     bls_fromvalue,
                                     bls_tovalue,
                                     bls_literalrange,
                                     bls_ivr_id)
             VALUES (p_id,
                     p_order,
                     p_cvl_id_midatindice,
                     p_cvl_id_biolstatetxt,
                     p_cvl_id_colorindex,
                     p_cvl_id_colorindext,
                     p_fromvalue,
                     p_tovalue,
                     p_literalrange,
                     p_ivr_id);
    END;

    /*------------------------------------------------------------------------------------*/
    FUNCTION f_returnlistcategory (
        p_cvl_id_midatindice   IN biologicalstate.bls_cvl_id_midatindice%TYPE,
        p_lan_id               IN codedesignation.cdn_lan_id%TYPE)
        RETURN VARCHAR2
    /*------------------------------------------------------------------------------------*/
    IS
        cst_formatibch       CONSTANT VARCHAR2 (30) := '999';
        cst_formatibch2019   CONSTANT VARCHAR2 (30) := '990.99';

        CURSOR l_listcategory IS
              SELECT bls_id,
                     bls_fromvalue,
                     bls_tovalue,
                     c1.cdn_designation biolstatxt
                FROM biologicalstate
                     INNER JOIN codedesignation c1
                         ON c1.cdn_cvl_id = bls_cvl_id_biolstatetxt
                     INNER JOIN codevalue v1 ON v1.cvl_id = c1.cdn_cvl_id
                     INNER JOIN codereference r1 ON v1.cvl_crf_id = r1.crf_id
               WHERE     bls_cvl_id_midatindice = p_cvl_id_midatindice
                     AND r1.crf_code = pkg_codereference.cst_crf_biolstatetxt
                     AND c1.cdn_lan_id = 1
            ORDER BY bls_order;



        l_reclistcategory             l_listcategory%ROWTYPE;
        l_liststring                  VARCHAR2 (2048);
        l_indice                      PLS_INTEGER := 0;
        l_reccodevalue                codevalue%ROWTYPE;
        l_format                      VARCHAR2 (30);
    BEGIN
        l_reccodevalue := pkg_codevalue.f_getrecord (p_cvl_id_midatindice);

        IF l_reccodevalue.cvl_code = pkg_codevalue.cst_midatindice_ibch2019
        THEN
            l_format := cst_formatibch2019;
        ELSE
            l_format := cst_formatibch;
        END IF;

        OPEN l_listcategory;

        LOOP
            FETCH l_listcategory INTO l_reclistcategory;

            EXIT WHEN l_listcategory%NOTFOUND;
            l_indice := l_indice + 1;

            IF l_liststring IS NULL
            THEN
                l_liststring :=
                    TO_CHAR (l_reclistcategory.bls_fromvalue, l_format);

                IF l_reclistcategory.bls_fromvalue !=
                   l_reclistcategory.bls_tovalue
                THEN
                    l_liststring :=
                           l_liststring
                        || ' - '
                        || TO_CHAR (l_reclistcategory.bls_tovalue, l_format);
                END IF;

                l_liststring :=
                    l_liststring || ' ' || l_reclistcategory.biolstatxt;
            ELSE
                l_liststring :=
                       l_liststring
                    || '; '
                    || TO_CHAR (l_reclistcategory.bls_fromvalue, l_format);

                IF l_reclistcategory.bls_fromvalue !=
                   l_reclistcategory.bls_tovalue
                THEN
                    l_liststring :=
                           l_liststring
                        || ' - '
                        || TO_CHAR (l_reclistcategory.bls_tovalue, l_format);
                END IF;

                l_liststring :=
                    l_liststring || ' ' || l_reclistcategory.biolstatxt;
            END IF;
        END LOOP;

        CLOSE l_listcategory;

        RETURN l_liststring;
    END;

    /*------------------------------------------------------------------------------------*/
    FUNCTION f_getrecordbyvalue (
        p_cvl_id_midatindice   IN biologicalstate.bls_cvl_id_midatindice%TYPE,
        p_value                IN biologicalstate.bls_fromvalue%TYPE)
        RETURN biologicalstate%ROWTYPE
    /*------------------------------------------------------------------------------------*/
    IS
        l_recbiologicalliststate   biologicalstate%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recbiologicalliststate
          FROM biologicalstate
         WHERE     bls_cvl_id_midatindice = p_cvl_id_midatindice
               AND p_value >= bls_fromvalue
               AND p_value <= bls_tovalue;

        RETURN l_recbiologicalliststate;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_test
    /*---------------------------------------------------------------*/
    IS
        l_recordvalueibch      codevalue%ROWTYPE;
        l_recbiologicalstate   biologicalstate%ROWTYPE;
        l_list                 VARCHAR2 (1024);
    BEGIN
        l_recordvalueibch :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_ibch);

        l_recbiologicalstate :=
            f_getrecordbyvalue (l_recordvalueibch.cvl_id, 0);
        DBMS_OUTPUT.put_line (l_recordvalueibch.cvl_id);
        DBMS_OUTPUT.put_line (
               'bls_cvl_id_biologicaltxt='
            || l_recbiologicalstate.bls_cvl_id_biolstatetxt);
        l_list := f_returnlistcategory (l_recordvalueibch.cvl_id, 1);
        DBMS_OUTPUT.put_line (l_list);
    END;
END pkg_biologicalstate;
/

