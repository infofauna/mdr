create trigger TR_BUF_IMPORTPROTOCOLHEADER
    before update
    on IMPORTPROTOCOLHEADER
    for each row
DECLARE
BEGIN
 
   :new.iph_moddate := SYSDATE;
   :new.iph_moduser := USER;
END tr_buf_importprotocolheader;

/

