create trigger TR_BUF_PROCESSINGSTEP
    before update
    on PROCESSINGSTEP
    for each row
DECLARE
BEGIN
   :new.psi_moddate := SYSDATE;
   :new.psi_moduser := USER;
END;

/

