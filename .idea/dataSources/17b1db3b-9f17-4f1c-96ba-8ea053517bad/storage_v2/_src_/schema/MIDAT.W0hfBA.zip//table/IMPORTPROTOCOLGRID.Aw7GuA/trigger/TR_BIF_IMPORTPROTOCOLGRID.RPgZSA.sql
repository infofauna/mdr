create trigger TR_BIF_IMPORTPROTOCOLGRID
    before insert
    on IMPORTPROTOCOLGRID
    for each row
DECLARE
BEGIN
   IF :new.ipg_id IS NULL
   THEN
      :new.ipg_id := seq_IMPORTPROTOCOLGRID.NEXTVAL;
   END IF;

   :new.ipg_credate := SYSDATE;
   :new.ipg_creuser := USER;
END tr_bif_IMPORTPROTOCOLGRID;

/

