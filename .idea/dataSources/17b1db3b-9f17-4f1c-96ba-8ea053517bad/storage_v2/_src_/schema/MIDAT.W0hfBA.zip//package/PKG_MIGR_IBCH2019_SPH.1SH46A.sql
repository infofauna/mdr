create PACKAGE       pkg_migr_ibch2019_sph
AS
    /******************************************************************************
      NAME:       PKG_MIGR_IBCH2019_PMH
      PURPOSE:    Modification dans la table SAMPLEHEADER

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       15.05.2020  F.Burri           1. Created this package
   ******************************************************************************/

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, mai 2020';

    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_add_sph_columns;
END pkg_migr_ibch2019_sph;
/

