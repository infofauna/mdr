create PACKAGE BODY       pkg_processingsteplog
AS
   /******************************************************************************
      NAME:       pkg_processingsteplog
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;

   gbl_starttime                 TIMESTAMP;
   gbl_starttimestep             TIMESTAMP;
   gbl_measurevalue              processingsteplog.psl_measurevalue%TYPE;
   gbl_measureunit               processingsteplog.psl_measureunit%TYPE;
   gbl_currrentpsl_id            processingsteplog.psl_id%TYPE;
   gbl_enableprocessingsteplog   BOOLEAN := TRUE;


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_setprocessingsteplog (p_flag IN BOOLEAN)
   /*-----------------------------------------------------------------*/
   IS
   BEGIN
      gbl_enableprocessingsteplog := p_flag;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_clearmeasuredata
   /*-----------------------------------------------------------------*/
   IS
   BEGIN
      gbl_measurevalue := NULL;
      gbl_measureunit := NULL;
      NULL;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_setmeasuredata (
      p_measurevalue   IN processingsteplog.psl_measurevalue%TYPE,
      p_measureunit    IN processingsteplog.psl_measureunit%TYPE)
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      gbl_measurevalue := p_measurevalue;
      gbl_measureunit := p_measureunit;
      NULL;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_computeelapsedtime (p_starttime         IN     TIMESTAMP,
                                   p_endtime           IN     TIMESTAMP,
                                   p_elapsedtime          OUT NUMBER,
                                   p_elapsedtimetext      OUT VARCHAR2)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      IF p_starttime IS NULL OR p_endtime IS NULL
      THEN
         RETURN;
      END IF;

      p_elapsedtime :=
         pkg_stringutil.f_returnelapsedtime (p_endtime, p_starttime);
      p_elapsedtimetext := pkg_stringutil.f_convertmilisecond (p_elapsedtime);
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_update (
      p_psl_id           IN processingsteplog.psl_id%TYPE,
      p_endtime IN processingsteplog.psl_endtime%type,
      p_elapsedtime      IN processingsteplog.psl_elapsedtime%TYPE,
      p_elapsedtimetxt   IN processingsteplog.psl_elapsedtimetxt%TYPE,
      p_measurevalue     IN processingsteplog.psl_measurevalue%TYPE,
      p_measureunit      IN processingsteplog.psl_measureunit%TYPE)
   /*-----------------------------------------------------------------*/
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      UPDATE processingsteplog
         SET psl_elapsedtime = p_elapsedtime,
             psl_elapsedtimetxt = p_elapsedtimetxt,
             psl_measurevalue = p_measurevalue,
             psl_measureunit = p_measureunit
       WHERE psl_id = p_psl_id;

      COMMIT;
      NULL;
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_write (
      p_psi_id           IN     processingsteplog.psl_psi_id%TYPE,
      p_pid_id           IN     processingsteplog.psl_pid_id%TYPE,
      p_starttime        IN     processingsteplog.psl_starttime%TYPE,
      p_endtime          IN     processingsteplog.psl_endtime%TYPE,
      p_elapsedtime      IN     processingsteplog.psl_elapsedtime%TYPE,
      p_elapsedtimetxt   IN     processingsteplog.psl_elapsedtimetxt%TYPE,
      p_measurevalue     IN     processingsteplog.psl_measurevalue%TYPE,
      p_measureunit      IN     processingsteplog.psl_measureunit%TYPE,
      p_psl_id              OUT processingsteplog.psl_id%TYPE)
   /*-----------------------------------------------------------------*/
   IS
      PRAGMA AUTONOMOUS_TRANSACTION;
   BEGIN
      p_psl_id := seq_processingsteplog.NEXTVAL;

      INSERT INTO processingsteplog (psl_id,
                                     psl_psi_id,
                                     psl_pid_id,
                                     psl_starttime,
                                     psl_endtime,
                                     psl_elapsedtime,
                                     psl_elapsedtimetxt,
                                     psl_measurevalue,
                                     psl_measureunit)
           VALUES (p_psl_id,
                   p_psi_id,
                   p_pid_id,
                   p_starttime,
                   p_endtime,
                   p_elapsedtime,
                   p_elapsedtimetxt,
                   p_measurevalue,
                   p_measureunit);

      COMMIT;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_parsestep (
      p_recprocessingstep      processingstep%ROWTYPE,
      p_pid_id              IN processingsteplog.psl_pid_id%TYPE)
   /*----------------------------------------------------------------*/
   IS
      l_elapsedtime           processingsteplog.psl_elapsedtime%TYPE;
      l_elapsedtimetxt        processingsteplog.psl_elapsedtimetxt%TYPE;
      l_measurevalue          processingsteplog.psl_measurevalue%TYPE;
      l_measureunit           processingsteplog.psl_measureunit%TYPE;
      l_updatedata            BOOLEAN := FALSE;
      l_psl_id                processingsteplog.psl_id%TYPE;
      l_writestarttime        processingsteplog.psl_starttime%TYPE;
      l_writeendtime          processingsteplog.psl_endtime%TYPE;
      l_writeelapsedtime      processingsteplog.psl_elapsedtime%TYPE;
      l_writeelapsedtimetxt   processingsteplog.psl_elapsedtimetxt%TYPE;
      l_writemeasurevalue     processingsteplog.psl_measurevalue%TYPE;
      p_writemeasureunit      processingsteplog.psl_measureunit%TYPE;
   BEGIN
      IF NOT gbl_enableprocessingsteplog
      THEN
         RETURN;
      END IF;

      l_writestarttime := NULL;
      l_writeendtime := NULL;
      l_writeelapsedtime := NULL;
      l_writeelapsedtimetxt := NULL;
      l_writemeasurevalue := NULL;
      p_writemeasureunit := NULL;

      CASE p_recprocessingstep.psi_stepcode
         WHEN pkg_processingstep.cst_stepcodereadvalidateheader
         -- Step 1
         THEN
            gbl_starttime := SYSTIMESTAMP;
            gbl_starttimestep := gbl_starttime;
            l_writestarttime := gbl_starttime;
            l_updatedata := FALSE;
            NULL;
         WHEN pkg_processingstep.cst_stepcodeloaddata
         THEN
            --Step 2, la taille du blob est passée dans la mesure
            l_updatedata := TRUE;

            p_computeelapsedtime (gbl_starttimestep,
                                  SYSTIMESTAMP,
                                  l_elapsedtime,
                                  l_elapsedtimetxt);

            gbl_starttimestep := SYSTIMESTAMP;
            l_writestarttime := gbl_starttimestep;
            NULL;
         WHEN pkg_processingstep.cst_checkrequiredfield
         THEN
            -- Step 3

            p_computeelapsedtime (gbl_starttimestep,
                                  SYSTIMESTAMP,
                                  l_elapsedtime,
                                  l_elapsedtimetxt);

            gbl_starttimestep := SYSTIMESTAMP;
             l_writestarttime := gbl_starttimestep;
            l_updatedata := TRUE;
            NULL;
         WHEN pkg_processingstep.cst_checkrequiredgrpfield
         THEN
            -- Step 4
                        l_writestarttime := gbl_starttime;
            p_computeelapsedtime (gbl_starttimestep,
                                  SYSTIMESTAMP,
                                  l_elapsedtime,
                                  l_elapsedtimetxt);

            gbl_starttimestep := SYSTIMESTAMP;
             l_writestarttime := gbl_starttimestep;
            l_updatedata := TRUE;
            NULL;
         WHEN pkg_processingstep.cst_buildheader
         THEN
            -- Step 5
            p_computeelapsedtime (gbl_starttimestep,
                                  SYSTIMESTAMP,
                                  l_elapsedtime,
                                  l_elapsedtimetxt);

            gbl_starttimestep := SYSTIMESTAMP;
             l_writestarttime := gbl_starttimestep;
            l_updatedata := TRUE;
            NULL;
         WHEN pkg_processingstep.cst_consolidateheader
         THEN
            -- Step 6
            p_computeelapsedtime (gbl_starttimestep,
                                  SYSTIMESTAMP,
                                  l_elapsedtime,
                                  l_elapsedtimetxt);

            gbl_starttimestep := SYSTIMESTAMP;
             l_writestarttime := gbl_starttimestep;
            l_updatedata := TRUE;
            NULL;
         WHEN pkg_processingstep.cst_validateheader
         THEN
            -- Step 7
            p_computeelapsedtime (gbl_starttimestep,
                                  SYSTIMESTAMP,
                                  l_elapsedtime,
                                  l_elapsedtimetxt);

            gbl_starttimestep := SYSTIMESTAMP;
            l_writestarttime := gbl_starttimestep;
            l_updatedata := TRUE;
            NULL;
         WHEN pkg_processingstep.cst_validatedetail
         THEN
            -- Step 8
            p_computeelapsedtime (gbl_starttimestep,
                                  SYSTIMESTAMP,
                                  l_elapsedtime,
                                  l_elapsedtimetxt);

            gbl_starttimestep := SYSTIMESTAMP;
             l_writestarttime := gbl_starttimestep;
            l_updatedata := TRUE;
            NULL;
         WHEN pkg_processingstep.cst_buildvalidatestation
         THEN
            -- Step 9
            p_computeelapsedtime (gbl_starttimestep,
                                  SYSTIMESTAMP,
                                  l_elapsedtime,
                                  l_elapsedtimetxt);

            gbl_starttimestep := SYSTIMESTAMP;
            l_writestarttime := gbl_starttimestep;
          
            l_updatedata := TRUE;
            NULL;
             WHEN pkg_processingstep.cst_computeindice
         THEN
            -- Step 10
     
            p_computeelapsedtime (gbl_starttimestep,
                                  SYSTIMESTAMP,
                                  l_elapsedtime,
                                  l_elapsedtimetxt);
            gbl_starttimestep := SYSTIMESTAMP;
            l_updatedata := TRUE;
            l_writestarttime := gbl_starttimestep;

         
         WHEN pkg_processingstep.cst_loadingdone
         THEN
            -- Step 11
            l_writeendtime := SYSTIMESTAMP;
            p_computeelapsedtime (gbl_starttimestep,
                                  l_writeendtime,
                                  l_elapsedtime,
                                  l_elapsedtimetxt);
            gbl_starttimestep := SYSTIMESTAMP;
            l_updatedata := TRUE;
            l_writestarttime := gbl_starttime;

            p_computeelapsedtime (l_writestarttime,
                                  l_writeendtime,
                                  l_writeelapsedtime,
                                  l_writeelapsedtimetxt);
            NULL;
      END CASE;

      IF l_updatedata
      THEN
         p_update (gbl_currrentpsl_id,
                   l_writestarttime,
                   l_elapsedtime,
                   l_elapsedtimetxt,
                   gbl_measurevalue,
                   gbl_measureunit);
      END IF;


      p_write (p_recprocessingstep.psi_id,
               p_pid_id,
               l_writestarttime,
               l_writeendtime,                                     -- end time
               l_writeelapsedtime,                               --elapsedtime
               l_writeelapsedtimetxt,                        -- elapsedtimetxt
               l_writemeasurevalue,                            -- measurevalue
               p_writemeasureunit,                               --measureunit
               l_psl_id);
      gbl_currrentpsl_id := l_psl_id;
   END;
END pkg_processingsteplog;
/

