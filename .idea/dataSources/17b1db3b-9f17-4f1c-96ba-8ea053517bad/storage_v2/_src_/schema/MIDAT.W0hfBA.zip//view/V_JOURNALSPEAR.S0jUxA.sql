create view V_JOURNALSPEAR as
SELECT wrd_group,
       wrd_family,
       wrd_genus,
       wrd_taxa,
       wrd_level,
       slg_match,
       slg_group,
       slg_family,
       slg_genus,
       slg_species,
       slg_subspecies,
       slg_comment
  FROM spearreferencelogload
       INNER JOIN wk_spearreferencedata ON slg_wrd_id = wrd_id
/

