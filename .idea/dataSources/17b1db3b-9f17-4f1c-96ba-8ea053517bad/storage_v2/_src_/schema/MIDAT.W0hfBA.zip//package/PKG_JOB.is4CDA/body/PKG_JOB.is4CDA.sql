create PACKAGE BODY pkg_job
AS
   /******************************************************************************
      NAME:       PKG_JOB
      PURPOSE:    Gestion des JOBS

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.10.2009  F.Burri          1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (40)
                                    := 'Version 1.0., octobre 2009' ;



   PROCEDURE p_dropalljob;

   PROCEDURE p_dropallschedule;

   PROCEDURE p_dropallprogram;


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------------------------------------*/
   FUNCTION f_chainexist (
      p_chainname IN user_scheduler_chains.chain_name%TYPE)
      RETURN BOOLEAN
   /*---------------------------------------------------------------------------------------------*/
   IS
      l_chainname   user_scheduler_chains.chain_name%TYPE;
   BEGIN
      SELECT chain_name
        INTO l_chainname
        FROM user_scheduler_chains
       WHERE chain_name = UPPER (p_chainname);

      RETURN TRUE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN FALSE;
   END;

   /*--------------------------------------------------------------------------------------------*/
   FUNCTION f_jobexist (p_jobname IN user_scheduler_jobs.job_name%TYPE)
      RETURN BOOLEAN
   /*---------------------------------------------------------------------------------------------*/
   IS
      l_jobname   user_scheduler_jobs.job_name%TYPE;
   BEGIN
      SELECT job_name
        INTO l_jobname
        FROM user_scheduler_jobs
       WHERE job_name = UPPER (p_jobname);

      RETURN TRUE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN FALSE;
   END;

   /*--------------------------------------------------------------------------------------------*/
   FUNCTION f_programexist (
      p_programname IN user_scheduler_programs.program_name%TYPE)
      RETURN BOOLEAN
   /*---------------------------------------------------------------------------------------------*/
   IS
      l_programname   user_scheduler_programs.program_name%TYPE;
   BEGIN
      SELECT program_name
        INTO l_programname
        FROM user_scheduler_programs
       WHERE program_name = UPPER (p_programname);

      RETURN TRUE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN FALSE;
   END;

   /*--------------------------------------------------------------------------------------------*/
   FUNCTION f_scheduleexist (
      p_schedulename IN user_scheduler_schedules.schedule_name%TYPE)
      RETURN BOOLEAN
   /*---------------------------------------------------------------------------------------------*/
   IS
      l_schedulename   user_scheduler_schedules.schedule_name%TYPE;
   BEGIN
      SELECT schedule_name
        INTO l_schedulename
        FROM user_scheduler_schedules
       WHERE schedule_name = UPPER (p_schedulename);

      RETURN TRUE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN FALSE;
   END;


   /*--------------------------------------------------------------------------------------------*/
   PROCEDURE p_createchainwith2job (p_chain_name       IN VARCHAR2,
                                    p_program_name_1   IN VARCHAR2,
                                    p_program_name_2   IN VARCHAR2)
   /*-------------------------------------------------------------------------------------------*/
   IS
   /* Pour que l'utilisateur puisse utiliser ce programme, il faut depuis SYS executer le code suivant
   BEGIN
DBMS_RULE_ADM.GRANT_SYSTEM_PRIVILEGE(DBMS_RULE_ADM.CREATE_ANY_RULE, 'username'),
DBMS_RULE_ADM.GRANT_SYSTEM_PRIVILEGE (
   DBMS_RULE_ADM.CREATE_ANY_RULE_SET, 'username'),
DBMS_RULE_ADM.GRANT_SYSTEM_PRIVILEGE (
   DBMS_RULE_ADM.CREATE_ANY_EVALUATION_CONTEXT, 'username')
END;
*/
   BEGIN
      DBMS_SCHEDULER.create_chain (chain_name            => p_chain_name,
                                   rule_set_name         => NULL,
                                   evaluation_interval   => NULL,
                                   comments              => NULL);
      DBMS_SCHEDULER.define_chain_step (p_chain_name,
                                        'step1',
                                        p_program_name_1);

      DBMS_SCHEDULER.define_chain_step (p_chain_name,
                                        'step2',
                                        p_program_name_2);

      DBMS_SCHEDULER.define_chain_rule (p_chain_name, 'TRUE', 'START step1');
      DBMS_SCHEDULER.define_chain_rule (p_chain_name,
                                        'step1 SUCCEEDED',
                                        'START step2');

      DBMS_SCHEDULER.define_chain_rule (
         p_chain_name,
         '(step1 COMPLETED AND step1 NOT SUCCEEDED) OR step2 COMPLETED',
         'END');
      DBMS_SCHEDULER.enable (p_chain_name);
   END;

   /*-------------------------------------------------------------------------------------------*/
   PROCEDURE p_returnlastjobinfo (
      p_date             IN     DATE,
      p_jobname          IN     VARCHAR2,
      p_status              OUT user_scheduler_job_run_details.status%TYPE,
      p_runduration         OUT user_scheduler_job_run_details.run_duration%TYPE,
      p_additionalinfo      OUT user_scheduler_job_run_details.additional_info%TYPE,
      p_startdate           OUT user_scheduler_job_run_details.actual_start_date%TYPE,
      p_returnstatus        OUT NUMBER)
   /*----------------------------------------------------------------------------------------*/
   IS
   BEGIN
      SELECT status,
             run_duration,
             additional_info,
             actual_start_date
        INTO p_status,
             p_runduration,
             p_additionalinfo,
             p_startdate
        FROM user_scheduler_job_run_details
       WHERE     job_name = p_jobname
             AND TRUNC (log_date) = TRUNC (p_date)
             AND log_date = (SELECT MAX (log_date)
                               FROM user_scheduler_job_run_details
                              WHERE job_name = p_jobname);

      p_returnstatus := pkg_constante.cst_returnstatusok;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_returnstatus := SQLCODE;
   END;

   /*-------------------------------------------------------------------------------------------*/
   PROCEDURE p_returnlastjobinfo (
      p_date             IN     DATE,
      p_jobname          IN     VARCHAR2,
      p_jobsubname       IN     VARCHAR2,
      p_status              OUT user_scheduler_job_run_details.status%TYPE,
      p_runduration         OUT user_scheduler_job_run_details.run_duration%TYPE,
      p_additionalinfo      OUT user_scheduler_job_run_details.additional_info%TYPE,
      p_startdate           OUT user_scheduler_job_run_details.actual_start_date%TYPE,
      p_returnstatus        OUT NUMBER)
   /*----------------------------------------------------------------------------------------*/
   IS
   BEGIN
      SELECT status,
             run_duration,
             additional_info,
             actual_start_date
        INTO p_status,
             p_runduration,
             p_additionalinfo,
             p_startdate
        FROM user_scheduler_job_run_details
       WHERE     job_name = UPPER (p_jobname)
             AND job_subname = UPPER (p_jobsubname)
             AND TRUNC (log_date) = TRUNC (p_date)
             AND log_date =
                    (SELECT MAX (log_date)
                       FROM user_scheduler_job_run_details
                      WHERE     job_name = UPPER (p_jobname)
                            AND job_subname = UPPER (p_jobsubname));

      p_returnstatus := pkg_constante.cst_returnstatusok;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_returnstatus := SQLCODE;
   END;

   /*--------------------------------------------------------------------------------*/
   PROCEDURE p_stopalljob
   /*--------------------------------------------------------------------------------*/
   IS
      CURSOR l_cursor
      IS
         SELECT job_name, state
           FROM user_scheduler_jobs
          WHERE state != 'DISABLED';

      l_reccursor      l_cursor%ROWTYPE;
      l_returnstatus   NUMBER;
   BEGIN
      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         p_stopjob (l_reccursor.job_name, l_returnstatus);
         p_disablejob (l_reccursor.job_name, l_returnstatus);
      END LOOP;

      CLOSE l_cursor;
   END;

   /*--------------------------------------------------------------------------------*/
   PROCEDURE p_enablealljob
   /*--------------------------------------------------------------------------------*/
   IS
      CURSOR l_cursor
      IS
         SELECT job_name, state
           FROM user_scheduler_jobs
          WHERE state = 'DISABLED';

      l_reccursor      l_cursor%ROWTYPE;
      l_returnstatus   NUMBER;
   BEGIN
      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         p_enablejob (l_reccursor.job_name, l_returnstatus);
      END LOOP;

      CLOSE l_cursor;
   END;

   /*--------------------------------------------------------------------------------*/
   PROCEDURE p_stopjob (p_job_name IN VARCHAR2, p_returnstatus OUT NUMBER)
   /*--------------------------------------------------------------------------------*/
   IS
   BEGIN
      IF f_jobexist (p_job_name)
      THEN
         DBMS_SCHEDULER.stop_job (p_job_name, TRUE);
      END IF;

      p_returnstatus := pkg_constante.cst_returnstatusok;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_returnstatus := SQLCODE;
   END;

   /*--------------------------------------------------------------------------------*/
   PROCEDURE p_disablejob (p_job_name IN VARCHAR2, p_returnstatus OUT NUMBER)
   /*--------------------------------------------------------------------------------*/
   IS
   BEGIN
      IF f_jobexist (p_job_name)
      THEN
         DBMS_SCHEDULER.disable (p_job_name, TRUE);
      END IF;

      p_returnstatus := pkg_constante.cst_returnstatusok;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_returnstatus := SQLCODE;
   END;

   /*--------------------------------------------------------------------------------*/
   PROCEDURE p_enablejob (p_job_name IN VARCHAR2, p_returnstatus OUT NUMBER)
   /*--------------------------------------------------------------------------------*/
   IS
   BEGIN
      IF f_jobexist (p_job_name)
      THEN
         DBMS_SCHEDULER.enable (p_job_name);
      END IF;

      p_returnstatus := pkg_constante.cst_returnstatusok;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_returnstatus := SQLCODE;
   END;

   /*------------------------------------------------------------------------------*/
   PROCEDURE p_dropall
   /*------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_stopalljob;
      p_dropalljob;
      p_dropallschedule;
      p_dropallprogram;
   END;



   /*------------------------------------------------------------------------------*/
   PROCEDURE p_dropalljob
   /*------------------------------------------------------------------------------*/
   IS
      CURSOR l_cursor
      IS
         SELECT job_name
           FROM user_scheduler_jobs
          WHERE job_creator = USER;

      l_reccursor   l_cursor%ROWTYPE;
   BEGIN
      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         p_dropjob (l_reccursor.job_name);
      END LOOP;

      CLOSE l_cursor;
   END;

   /*------------------------------------------------------------------------------*/
   PROCEDURE p_dropallprogram
   /*------------------------------------------------------------------------------*/
   IS
      CURSOR l_cursor
      IS
         SELECT program_name FROM user_scheduler_programs;

      l_reccursor   l_cursor%ROWTYPE;
   BEGIN
      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         p_dropprogram (l_reccursor.program_name);
      END LOOP;

      CLOSE l_cursor;
   END;

   /*------------------------------------------------------------------------------*/
   PROCEDURE p_dropallschedule
   /*------------------------------------------------------------------------------*/
   IS
      CURSOR l_cursor
      IS
         SELECT schedule_name FROM user_scheduler_schedules;

      l_reccursor   l_cursor%ROWTYPE;
   BEGIN
      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         p_dropschedule (l_reccursor.schedule_name);
      END LOOP;

      CLOSE l_cursor;
   END;



   /*------------------------------------------------------------------------------*/
   PROCEDURE p_createprogram (p_name         IN VARCHAR2,
                              p_actionname   IN VARCHAR2,
                              p_comment      IN VARCHAR2)
   /*------------------------------------------------------------------------------*/
   IS
   BEGIN
      DBMS_SCHEDULER.create_program (program_name          => p_name,
                                     program_type          => 'STORED_PROCEDURE',
                                     program_action        => p_actionname,
                                     number_of_arguments   => 0,
                                     enabled               => FALSE,
                                     comments              => p_comment);

      DBMS_SCHEDULER.enable (name => p_name);
   END;

   /*------------------------------------------------------------------------------*/
   PROCEDURE p_createscriptprogram (p_name         IN VARCHAR2,
                                    p_actionname   IN VARCHAR2,
                                    p_comment      IN VARCHAR2)
   /*------------------------------------------------------------------------------*/
   IS
   BEGIN
      DBMS_SCHEDULER.create_program (program_name          => p_name,
                                     program_type          => 'EXECUTABLE',
                                     program_action        => p_actionname,
                                     number_of_arguments   => 0,
                                     enabled               => FALSE,
                                     comments              => p_comment);

      DBMS_SCHEDULER.enable (name => p_name);
   END;

   /*----------------------------------------------------------------------------------*/
   PROCEDURE p_createschedule (p_name      IN VARCHAR2,
                               p_repeat    IN VARCHAR2,
                               p_comment   IN VARCHAR2)
   /*----------------------------------------------------------------------------------*/
   IS
   BEGIN
      DBMS_SCHEDULER.create_schedule (schedule_name     => p_name,
                                      start_date        => NULL,
                                      repeat_interval   => p_repeat,
                                      end_date          => NULL,
                                      comments          => p_comment);
   END;



   /*--------------------------------------------------------------------------------*/
   PROCEDURE p_schedulejob (p_jobname        IN VARCHAR2,
                            p_schedulename   IN VARCHAR2,
                            p_programname    IN VARCHAR2,
                            p_comment        IN VARCHAR2)
   /*--------------------------------------------------------------------------------*/
   IS
   BEGIN
      DBMS_SCHEDULER.create_job (job_name        => p_jobname,
                                 schedule_name   => p_schedulename,
                                 program_name    => p_programname,
                                 comments        => p_comment);
      DBMS_SCHEDULER.set_attribute (name        => p_jobname,
                                    attribute   => 'RESTARTABLE',
                                    VALUE       => FALSE);
      DBMS_SCHEDULER.set_attribute (
         name        => p_jobname,
         attribute   => 'LOGGING_LEVEL',
         VALUE       => sys.DBMS_SCHEDULER.logging_runs);
      DBMS_SCHEDULER.set_attribute_null (name        => p_jobname,
                                         attribute   => 'MAX_FAILURES');
      DBMS_SCHEDULER.set_attribute_null (name        => p_jobname,
                                         attribute   => 'MAX_RUNS');
      DBMS_SCHEDULER.set_attribute (name        => p_jobname,
                                    attribute   => 'STOP_ON_WINDOW_CLOSE',
                                    VALUE       => FALSE);
      sys.DBMS_SCHEDULER.set_attribute (name        => p_jobname,
                                        attribute   => 'JOB_PRIORITY',
                                        VALUE       => 3);
      sys.DBMS_SCHEDULER.set_attribute_null (name        => p_jobname,
                                             attribute   => 'SCHEDULE_LIMIT');
      sys.DBMS_SCHEDULER.set_attribute (name        => p_jobname,
                                        attribute   => 'AUTO_DROP',
                                        VALUE       => FALSE);

      sys.DBMS_SCHEDULER.enable (name => p_jobname);
   END;

   /*---------------------------------------------------------------------------*/
   FUNCTION f_getjobstatus (p_jobname IN VARCHAR2)
      RETURN VARCHAR2
   /*---------------------------------------------------------------------------*/
   IS
      l_status   VARCHAR2 (30);
   BEGIN
      SELECT state
        INTO l_status
        FROM user_scheduler_jobs
       WHERE job_name = p_jobname;

      RETURN l_status;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   /*----------------------------------------------------------------------------*/
   PROCEDURE p_sendjob (p_jobname        IN     VARCHAR2,
                        p_command        IN     VARCHAR2,
                        p_comment        IN     VARCHAR2)
   /*----------------------------------------------------------------------------*/
   IS
   BEGIN
      pkg_debug.p_write ('PKG_JOBUTIL.P_SendJob', p_command);
      DBMS_SCHEDULER.create_job (job_name     => p_jobname,
                                 job_type     => 'PLSQL_BLOCK',
                                 job_action   => p_command,
                                 start_date   => SYSDATE,
                                 enabled      => TRUE,
                                 comments     => p_comment);
 
   END;

   /*--------------------------------------------------------------------------------*/
   PROCEDURE p_schedulechainjob (p_jobname        IN VARCHAR2,
                                 p_schedulename   IN VARCHAR2,
                                 p_chainname      IN VARCHAR2,
                                 p_comment        IN VARCHAR2)
   /*--------------------------------------------------------------------------------*/
   IS
   BEGIN
      DBMS_SCHEDULER.create_job (job_name        => p_jobname,
                                 schedule_name   => p_schedulename,
                                 job_type        => 'CHAIN',
                                 job_action      => p_chainname,
                                 comments        => p_comment,
                                 enabled         => TRUE);
   END;

   /*---------------------------------------------------------------------------*/
   PROCEDURE p_dropjob (p_jobname IN VARCHAR2)
   /*---------------------------------------------------------------------------*/
   IS
   BEGIN
      IF f_jobexist (p_jobname)
      THEN
         DBMS_SCHEDULER.drop_job (p_jobname, TRUE);
      END IF;
   END;

   /*---------------------------------------------------------------------------*/
   PROCEDURE p_dropschedule (p_name IN VARCHAR2)
   /*---------------------------------------------------------------------------*/
   IS
   BEGIN
      IF f_scheduleexist (p_name)
      THEN
         DBMS_SCHEDULER.drop_schedule (p_name, TRUE);
      END IF;
   END;

   /*---------------------------------------------------------------------------*/
   PROCEDURE p_dropchain (p_name IN VARCHAR2)
   /*---------------------------------------------------------------------------*/
   IS
   BEGIN
      IF f_chainexist (p_name)
      THEN
         DBMS_SCHEDULER.drop_chain (p_name, TRUE);
      END IF;
   END;


   /*---------------------------------------------------------------------------*/
   PROCEDURE p_dropprogram (p_programname IN VARCHAR2)
   /*---------------------------------------------------------------------------*/
   IS
   BEGIN
      IF f_programexist (p_programname)
      THEN
         DBMS_SCHEDULER.drop_program (p_programname, TRUE);
      END IF;
   END;

   /*------------------------------------------------------------------------*/
   PROCEDURE p_dropjobbychainname (p_chainname IN VARCHAR2)
   /*------------------------------------------------------------------------*/
   IS
      -- Supprime la chain, le job associé, les programmes associés et le schedule associé
      l_job_name        user_scheduler_jobs.job_name%TYPE;
      l_schedule_name   user_scheduler_jobs.schedule_name%TYPE;

      CURSOR l_cursorstep
      IS
         SELECT *
           FROM user_scheduler_chain_steps
          WHERE chain_name = p_chainname;

      l_reccursorstep   l_cursorstep%ROWTYPE;
   BEGIN
      IF NOT f_chainexist (p_chainname)
      THEN
         RETURN;
      END IF;

      OPEN l_cursorstep;

      LOOP
         FETCH l_cursorstep INTO l_reccursorstep;

         EXIT WHEN l_cursorstep%NOTFOUND;
         p_dropprogram (l_reccursorstep.program_name);
      END LOOP;

      CLOSE l_cursorstep;


      SELECT job_name, schedule_name
        INTO l_job_name, l_schedule_name
        FROM user_scheduler_jobs
       WHERE job_type = 'CHAIN' AND job_action = p_chainname;

      p_dropjob (l_job_name);
      p_dropschedule (l_schedule_name);
      p_dropchain (p_chainname);
   END;
END pkg_job;
/

