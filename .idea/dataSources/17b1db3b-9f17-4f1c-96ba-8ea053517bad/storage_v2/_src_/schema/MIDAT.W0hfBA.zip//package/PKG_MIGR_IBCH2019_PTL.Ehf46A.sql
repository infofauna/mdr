create PACKAGE       pkg_migr_ibch2019_ptl
AS
    /******************************************************************************
      NAME:       PKG_MIGR_IBCH2019_PTL
      PURPOSE:    Modification dans la table PROTOCOLMAPPINGLABO

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       15.05.2020  F.Burri           1. Created this package
   ******************************************************************************/

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, mai 2020';

    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_deleteversion (p_ptv_id IN protocolversion.ptv_id%TYPE);


    PROCEDURE p_checkibchentry (
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE);

    PROCEDURE p_checkspearentry (
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE);

    PROCEDURE p_checktaxonreplaceentry (
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE);

    PROCEDURE p_returntaxonparameter (
        p_taxa         IN     protocolmappinglabo.ptl_taxa%TYPE,
        p_taxon_2019      OUT protocolmappinglabo.ptl_taxa%TYPE,
        p_taxon_cscf      OUT protocolmappinglabo.ptl_taxacscf%TYPE,
        p_syv_id          OUT protocolmappinglabo.ptl_syv_id%TYPE);

    FUNCTION f_getspearvalue (p_taxa IN protocolmappinglabo.ptl_taxa%TYPE)
        RETURN protocolmappinglabo.ptl_spearindexfactor%TYPE;

    PROCEDURE p_returnibchparameter (
        p_taxa        IN     protocolmappinglabo.ptl_taxa%TYPE,
        p_nombremin      OUT protocolmappinglabo.ptl_ibchindividumin%TYPE,
        p_valeur_gi      OUT protocolmappinglabo.ptl_ibchfaunagroup_gi%TYPE);

    PROCEDURE p_copyversion (p_ptv_id       IN protocolversion.ptv_id%TYPE,
                             p_ptv_id_new   IN protocolversion.ptv_id%TYPE);

    PROCEDURE p_completaxonreplace (
        p_ptv_id_base   IN protocolmappinglabo.ptl_ptv_id%TYPE);

    PROCEDURE p_checkalllabo (p_ptv_id   IN     protocolversion.ptv_id%TYPE,
                              p_ok          OUT BOOLEAN);

    PROCEDURE p_clearexcluderow;

    PROCEDURE p_addexcluderow (p_row IN NUMBER, p_column IN VARCHAR2);

    PROCEDURE p_initnewtaxon;

    PROCEDURE p_appendnewtaxon (p_ptv_id_new IN protocolversion.ptv_id%TYPE);

    PROCEDURE p_updatenewtaxonptl_ptl_id (
        p_ptv_id_new   IN protocolversion.ptv_id%TYPE);

    PROCEDURE p_updateptl_ptl_id (
        p_ptv_id       IN protocolversion.ptv_id%TYPE,
        p_ptv_id_new   IN protocolversion.ptv_id%TYPE);

    PROCEDURE p_updatetaxonname (
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE);

    PROCEDURE p_changegi (p_ptv_id IN protocolversion.ptv_id%TYPE);

    PROCEDURE p_updatespear (p_ptv_id IN protocolmappinglabo.ptl_ptv_id%TYPE);
END pkg_migr_ibch2019_ptl;
/

