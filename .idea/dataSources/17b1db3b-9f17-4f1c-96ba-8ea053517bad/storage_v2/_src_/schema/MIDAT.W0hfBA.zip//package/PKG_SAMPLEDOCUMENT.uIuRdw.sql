create PACKAGE       pkg_sampledocument
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEHEADERITEM
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.10.2013   F.Burri          1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_write (
      p_sph_id     IN     sampledocument.spt_sph_id%TYPE,
      p_ptv_id     IN     sampledocument.spt_ptv_id%TYPE,
      p_filename   IN     sampledocument.spt_filename%TYPE,
      p_title      IN     sampledocument.spt_title%TYPE,
      p_usr_id     IN     sampledocument.spt_usr_id_create%TYPE,
      p_spt_id        OUT sampledocument.spt_id%TYPE);

   PROCEDURE p_deleteby_sph_id (p_sph_id IN sampledocument.spt_sph_id%TYPE);

   PROCEDURE p_deleteby_ptv_id (p_sph_id   IN sampledocument.spt_sph_id%TYPE,
                                p_ptv_id   IN sampledocument.spt_ptv_id%TYPE);

   FUNCTION f_getrecord (p_spt_id IN sampledocument.spt_id%TYPE)
      RETURN sampledocument%ROWTYPE;
END pkg_sampledocument;
/

