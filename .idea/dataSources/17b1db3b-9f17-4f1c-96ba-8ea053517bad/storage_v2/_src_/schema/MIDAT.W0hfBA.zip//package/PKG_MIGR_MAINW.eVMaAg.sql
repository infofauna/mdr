create PACKAGE       PKG_MIGR_MAINW AS
/******************************************************************************
   NAME:       PKG_MIGR_MAINW
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        11.08.2015      burrif       1. Created this package.
******************************************************************************/
  FUNCTION f_getversion
      RETURN VARCHAR2;


   PROCEDURE p_clearalldata;



END PKG_MIGR_MAINW;
/

