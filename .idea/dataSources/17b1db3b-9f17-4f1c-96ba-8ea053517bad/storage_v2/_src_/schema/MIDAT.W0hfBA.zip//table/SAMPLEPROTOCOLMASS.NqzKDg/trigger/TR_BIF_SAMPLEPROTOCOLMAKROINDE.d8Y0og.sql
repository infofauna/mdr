create trigger TR_BIF_SAMPLEPROTOCOLMAKROINDE
    before insert
    on SAMPLEPROTOCOLMASS
    for each row
DECLARE
BEGIN
   IF :new.smx_id IS NULL
   THEN
      :new.smx_id := seq_SAMPLEPROTOCOLMASS.NEXTVAL;
   END IF;

   :new.smx_credate := SYSDATE;
   :new.smx_creuser := USER;
END tr_bif_sampleprotocolmakroinde;

/

