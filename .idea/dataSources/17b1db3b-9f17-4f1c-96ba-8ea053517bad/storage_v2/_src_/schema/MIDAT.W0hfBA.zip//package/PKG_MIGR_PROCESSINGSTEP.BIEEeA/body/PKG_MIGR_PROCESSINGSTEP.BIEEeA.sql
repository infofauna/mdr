create PACKAGE BODY       pkg_migr_processingstep
AS
   /******************************************************************************
      NAME:       PKG_MIGR_PROCESSINGSTEP
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10/11/2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, novembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_loadstep
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM processingstep;

      COMMIT;
      pkg_migr_utility.p_recreatesequence ('PROCESSINGSTEP',
                                           'SEQ_PROCESSINGSTEP',
                                           'PSI_ID');
      pkg_processingstep.p_write (
         1,                                                     --p_sequence ,
         pkg_processingstep.cst_stepcodereadvalidateheader,    -- p_stepcode ,
         'Lecture et validation des colonnes de l''entête',     --p_comment ,
         pkg_exception.cst_readandvalidateheader,           -- p_errornumber ,
         0                                                    -- p_percentdone
          );
      pkg_processingstep.p_write (
         2,                                                     --p_sequence ,
         pkg_processingstep.cst_stepcodeloaddata,              -- p_stepcode ,
         'Chargement des données depuis la feuille',            --p_comment ,
         pkg_exception.cst_loaddata,                        -- p_errornumber ,
         0                                                    -- p_percentdone
          );
      pkg_processingstep.p_write (3,                            --p_sequence ,
                                  pkg_processingstep.cst_checkrequiredfield, -- p_stepcode ,
                                  'Contrôle des champs obligatoires', --p_comment ,
                                  pkg_exception.cst_checkrequiredfield, -- p_errornumber ,
                                  0                           -- p_percentdone
                                   );
      pkg_processingstep.p_write (
         4,                                                     --p_sequence ,
         pkg_processingstep.cst_checkrequiredgrpfield,         -- p_stepcode ,
         'Contrôle des regroupements de champs obligatoires',   --p_comment ,
         pkg_exception.cst_checkrequiredgrpfield,           -- p_errornumber ,
         0                                                    -- p_percentdone
          );
      pkg_processingstep.p_write (5,                            --p_sequence ,
                                  pkg_processingstep.cst_buildheader, -- p_stepcode ,
                                  'Construction des entêtes',   --p_comment ,
                                  pkg_exception.cst_buildheader, -- p_errornumber ,
                                  0                           -- p_percentdone
                                   );

      pkg_processingstep.p_write (6,                            --p_sequence ,
                                  pkg_processingstep.cst_consolidateheader, -- p_stepcode ,
                                  'Consolidation des entêtes',  --p_comment ,
                                  pkg_exception.cst_consolidateheader, -- p_errornumber ,
                                  0                           -- p_percentdone
                                   );
      pkg_processingstep.p_write (7,                            --p_sequence ,
                                  pkg_processingstep.cst_validateheader, -- p_stepcode ,
                                  'Validation du contenu des entêtes %p1%', --p_comment ,
                                  pkg_exception.cst_validateheader, -- p_errornumber ,
                                  0                           -- p_percentdone
                                   );

      pkg_processingstep.p_write (8,                            --p_sequence ,
                                  pkg_processingstep.cst_validatedetail, -- p_stepcode ,
                                  'Validation du contenu des détails %p1%', --p_comment ,
                                  pkg_exception.cst_validatedetail, -- p_errornumber ,
                                  0                           -- p_percentdone
                                   );
      pkg_processingstep.p_write (
         9,                                                     --p_sequence ,
         pkg_processingstep.cst_buildvalidatestation,          -- p_stepcode ,
         'Structuration et validation des stations',             --p_comment ,
         pkg_exception.cst_buildandvalidatestation,         -- p_errornumber ,
         0                                                    -- p_percentdone
          );
            pkg_processingstep.p_write (10,                           --p_sequence ,
                                  pkg_processingstep.cst_computeindice, -- p_stepcode ,
                                  'Calcul des indices',         --p_comment ,
                                  pkg_exception.cst_computeindice, -- p_errornumber ,
                                  0                           -- p_percentdone
                                   );
 
      pkg_processingstep.p_write (11,                           --p_sequence ,
                                  pkg_processingstep.cst_loadingdone, -- p_stepcode ,
                                  'Chargement terminé',         --p_comment ,
                                  pkg_exception.cst_loadingdone, -- p_errornumber ,
                                  0                           -- p_percentdone
                                   );

      NULL;
   END;
END pkg_migr_processingstep;
/

