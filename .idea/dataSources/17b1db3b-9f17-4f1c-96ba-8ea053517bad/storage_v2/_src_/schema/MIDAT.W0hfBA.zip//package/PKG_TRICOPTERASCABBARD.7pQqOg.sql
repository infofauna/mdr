create PACKAGE       pkg_tricopterascabbard
AS
   /******************************************************************************
      NAME:       pkg_tricopterascabbard
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        13.03.2015     burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecord (p_tsd_id IN tricopterascabbard.tsd_id%TYPE)
      RETURN tricopterascabbard%ROWTYPE;

   FUNCTION f_getrecordbysyvid (
      p_syv_id   IN tricopterascabbard.tsd_syv_id%TYPE)
      RETURN tricopterascabbard%ROWTYPE;

   PROCEDURE p_write (
      p_syv_id        IN     tricopterascabbard.tsd_syv_id%TYPE,
      p_text          IN     tricopterascabbard.tsd_text%TYPE,
      p_hasscabbard   IN     tricopterascabbard.tsd_hasscabbard%TYPE,
      p_id               OUT tricopterascabbard.tsd_id%TYPE);
END pkg_tricopterascabbard;
/

