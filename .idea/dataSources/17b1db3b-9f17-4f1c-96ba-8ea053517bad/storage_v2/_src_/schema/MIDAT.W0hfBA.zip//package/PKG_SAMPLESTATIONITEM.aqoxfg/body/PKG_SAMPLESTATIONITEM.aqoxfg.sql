create PACKAGE BODY       pkg_samplestationitem
AS
   /******************************************************************************
      NAME:       PKG_SAMPLESTATIONITEM
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       25.07.2013  F.Burri           1. Created this package body.
      1.1       04.08.2019   F.Burri          2. f_getleastoneitem
   ******************************************************************************/



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;



   /*----------------------------------------------------------------*/
   PROCEDURE p_deletebysstid (p_sst_id IN samplestationitem.ssi_sst_id%TYPE)
   /*-----------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM samplestationitem
            WHERE ssi_sst_id = p_sst_id;
   END;


   /*--------------------------------------------------------------*/
   FUNCTION f_getrecord (p_ssi_id IN samplestationitem.ssi_id%TYPE)
      RETURN samplestationitem%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record   samplestationitem%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM samplestationitem
       WHERE ssi_id = p_ssi_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbyitem (
      p_sst_id     IN samplestationitem.ssi_sst_id%TYPE,
      p_ssi_item   IN samplestationitem.ssi_item%TYPE,
      p_cvl_code   IN codevalue.cvl_code%TYPE)
      RETURN samplestationitem%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record      samplestationitem%ROWTYPE;
      l_codevalue   codevalue%ROWTYPE;
   BEGIN
      l_codevalue :=
         pkg_codevalue.f_getfromcode (p_cvl_code,
                                      pkg_codereference.cst_crf_midatstitmty);

      IF l_codevalue.cvl_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      SELECT *
        INTO l_record
        FROM samplestationitem
       WHERE     ssi_sst_id = p_sst_id
             AND ssi_cvl_id_midatstitmty = l_codevalue.cvl_id
             AND TRIM (UPPER (p_ssi_item)) = TRIM (UPPER (ssi_item))
             AND ROWNUM < 2;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbyitem (
      p_sst_id     IN samplestationitem.ssi_sst_id%TYPE,
      p_ssi_item   IN samplestationitem.ssi_item%TYPE,
      p_lan_id     IN samplestationitem.ssi_lan_id%TYPE,
      p_cvl_code   IN codevalue.cvl_code%TYPE)
      RETURN samplestationitem%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record      samplestationitem%ROWTYPE;
      l_codevalue   codevalue%ROWTYPE;
   BEGIN
      l_codevalue :=
         pkg_codevalue.f_getfromcode (p_cvl_code,
                                      pkg_codereference.cst_crf_midatstitmty);

      IF l_codevalue.cvl_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      SELECT *
        INTO l_record
        FROM samplestationitem
       WHERE     ssi_sst_id = p_sst_id
             AND ssi_cvl_id_midatstitmty = l_codevalue.cvl_id
             AND TRIM (UPPER (p_ssi_item)) = TRIM (UPPER (ssi_item))
             AND ssi_lan_id = p_lan_id
             AND ROWNUM < 2;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbyitemandcvl_id (
      p_sst_id     IN samplestationitem.ssi_sst_id%TYPE,
      p_ssi_item   IN samplestationitem.ssi_item%TYPE,
      p_lan_id     IN samplestationitem.ssi_lan_id%TYPE,
      p_cvl_id     IN codevalue.cvl_id%TYPE)
      RETURN samplestationitem%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record   samplestationitem%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM samplestationitem
       WHERE     ssi_sst_id = p_sst_id
             AND ssi_cvl_id_midatstitmty = p_cvl_id
             AND TRIM (UPPER (p_ssi_item)) = TRIM (UPPER (ssi_item))
             AND ssi_lan_id = p_lan_id
             AND ROWNUM < 2;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getleastoneitem (
      p_sst_id              IN samplestationitem.ssi_sst_id%TYPE,
      p_lan_id              IN samplestationitem.ssi_lan_id%TYPE,
      p_smpstaitmtyp_code   IN codevalue.cvl_code%TYPE)
      RETURN samplestationitem.ssi_item%TYPE
   /*--------------------------------------------------------------*/
   IS
      l_record   samplestationitem%ROWTYPE;
   BEGIN
      l_record :=
         f_getatleastonerecord (p_sst_id, p_lan_id, p_smpstaitmtyp_code);
      RETURN l_record.ssi_item;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getatleastonerecord (
      p_sst_id              IN samplestationitem.ssi_sst_id%TYPE,
      p_lan_id              IN samplestationitem.ssi_lan_id%TYPE,
      p_smpstaitmtyp_code   IN codevalue.cvl_code%TYPE)
      RETURN samplestationitem%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_record         samplestationitem%ROWTYPE;
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
      l_record :=
         f_getrecordwithtypeandlanid (p_sst_id,
                                      p_smpstaitmtyp_code,
                                      p_lan_id);

      IF l_record.ssi_id IS NULL
      THEN
         l_record := f_getatleastonerecord (p_sst_id, p_smpstaitmtyp_code);

         IF l_record.ssi_id IS NULL
         THEN
            RETURN NULL;
         END IF;
      END IF;



      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*--------------------------------------------------------------*/
   FUNCTION f_getatleastonerecord (
      p_sst_id              IN samplestationitem.ssi_sst_id%TYPE,
      p_smpstaitmtyp_code   IN codevalue.cvl_code%TYPE)
      RETURN samplestationitem%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_record         samplestationitem%ROWTYPE;
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getfromcode (p_smpstaitmtyp_code,
                                      pkg_codereference.cst_crf_midatstitmty);

      IF l_reccodevalue.cvl_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      SELECT *
        INTO l_record
        FROM samplestationitem
       WHERE     l_reccodevalue.cvl_id = ssi_cvl_id_midatstitmty
             AND ROWNUM < 2
             AND ssi_sst_id = p_sst_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordwithtypeandlanid (
      p_sst_id              IN samplestationitem.ssi_sst_id%TYPE,
      p_smpstaitmtyp_code   IN codevalue.cvl_code%TYPE,
      p_lan_id              IN samplestationitem.ssi_lan_id%TYPE)
      RETURN samplestationitem%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record         samplestationitem%ROWTYPE;
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getfromcode (p_smpstaitmtyp_code,
                                      pkg_codereference.cst_crf_midatstitmty);

      IF l_reccodevalue.cvl_id IS NULL
      THEN
         RETURN NULL;
      END IF;

      SELECT *
        INTO l_record
        FROM samplestationitem
       WHERE     l_reccodevalue.cvl_id = ssi_cvl_id_midatstitmty
             AND ssi_lan_id = p_lan_id
             AND ssi_sst_id = p_sst_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_check (p_command   IN     VARCHAR2,
                      p_oldrec    IN     samplestationitem%ROWTYPE,
                      p_newrec    IN OUT samplestationitem%ROWTYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      NULL;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_tr_bif_samplestationitem (
      p_newrec   IN OUT samplestationitem%ROWTYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      p_newrec.ssi_credate := SYSDATE;
      p_newrec.ssi_creuser := USER;

      IF p_newrec.ssi_id IS NULL
      THEN
         p_newrec.ssi_id := seq_samplestationitem.NEXTVAL;
      END IF;

      p_check (pkg_constante.cst_dml_command_insert, NULL, p_newrec);
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_tr_buf_samplestationitem (
      p_oldrec   IN     samplestationitem%ROWTYPE,
      p_newrec   IN OUT samplestationitem%ROWTYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      p_newrec.ssi_moddate := SYSDATE;
      p_newrec.ssi_moduser := USER;
      p_check (pkg_constante.cst_dml_command_update, p_oldrec, p_newrec);
   END;

   /*----------------------------------------------------------------------------------*/
   PROCEDURE p_writeifnotexist (
      p_sst_id                IN     samplestationitem.ssi_sst_id%TYPE,
      p_lan_id                IN     samplestationitem.ssi_lan_id%TYPE,
      p_cvl_id_midatstitmty   IN     samplestationitem.ssi_cvl_id_midatstitmty%TYPE,
      p_item                  IN     samplestationitem.ssi_item%TYPE,
      p_usr_id                IN     samplestationitem.ssi_usr_id_create%TYPE,
      p_id                       OUT samplestationitem.ssi_id%TYPE)
   /*-----------------------------------------------------------------------------------*/
   IS
      l_recsamplestationitem   samplestationitem%ROWTYPE;
      l_id                     samplestationitem.ssi_id%TYPE;
   BEGIN
      l_recsamplestationitem :=
         f_getrecordbyitemandcvl_id (p_sst_id,
                                     p_item,
                                     p_lan_id,
                                     p_cvl_id_midatstitmty);

      IF l_recsamplestationitem.ssi_id IS NULL
      THEN
         p_write (p_sst_id,
                  p_lan_id,
                  p_cvl_id_midatstitmty,
                  p_item,
                  p_usr_id,
                  l_id);
      END IF;

      NULL;
   END;

   /*----------------------------------------------------------------------------------*/

   PROCEDURE p_write (
      p_sst_id                IN     samplestationitem.ssi_sst_id%TYPE,
      p_lan_id                IN     samplestationitem.ssi_lan_id%TYPE,
      p_cvl_id_midatstitmty   IN     samplestationitem.ssi_cvl_id_midatstitmty%TYPE,
      p_item                  IN     samplestationitem.ssi_item%TYPE,
      p_usr_id                IN     samplestationitem.ssi_usr_id_create%TYPE,
      p_id                       OUT samplestationitem.ssi_id%TYPE)
   /*---------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_samplestationitem.NEXTVAL;

      INSERT INTO samplestationitem (ssi_id,
                                     ssi_sst_id,
                                     ssi_lan_id,
                                     ssi_cvl_id_midatstitmty,
                                     ssi_item,
                                     ssi_usr_id_create,
                                     ssi_usr_create_date)
           VALUES (p_id,
                   p_sst_id,
                   p_lan_id,
                   p_cvl_id_midatstitmty,
                   p_item,
                   p_usr_id,
                   SYSDATE);
   END;
END pkg_samplestationitem;
/

