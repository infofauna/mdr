create PACKAGE       pkg_processingstatus
AS
   /******************************************************************************
      NAME:       PKG_PROCESSINGSTATUS
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_statusbardisplaylimit   CONSTANT NUMBER := 100; -- Nombre de pas pour l'affichage de la barre de status

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_cleargbl;

   PROCEDURE p_resetbarstatusdisplaylimit;

   PROCEDURE p_setbarstatusdisplaylimit (p_barstatusdisplaylimit IN NUMBER);

   PROCEDURE p_setstep (
      p_pid_id            IN processingstatus.pid_id%TYPE,
      p_currentstepcode   IN processingstep.psi_stepcode%TYPE,
      p_lan_id            IN language.lan_id%TYPE,
      p_usr_id            IN processingstatus.pid_usr_id_modify%TYPE);

   PROCEDURE p_setstatusbar (p_rowsallreadyprocessed   IN NUMBER,
                             p_rowstotal               IN NUMBER);


   FUNCTION f_getrecord (p_pid_id IN processingstatus.pid_id%TYPE)
      RETURN processingstatus%ROWTYPE;

   PROCEDURE p_purgeby_iphheader (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE);

   PROCEDURE p_updateprocessingstatus (
      p_external_id   IN processingstatus.pid_externalid%TYPE,
      p_usr_id        IN processingstatus.pid_usr_id%TYPE);

   PROCEDURE p_initprocessingstatus (
      p_external_id   IN processingstatus.pid_externalid%TYPE);

   PROCEDURE p_initprocessingstatus (
      p_external_id   IN     processingstatus.pid_externalid%TYPE,
      p_pid_id           OUT processingstatus.pid_id%TYPE);
      
        PROCEDURE p_initprocessingstatus_v2 (
      p_pid_id           OUT processingstatus.pid_id%TYPE);

   PROCEDURE p_updatenumberrecord (
      p_pid_id        IN processingstatus.pid_id%TYPE,
      p_recordcount   IN processingstatus.pid_numberrecord%TYPE,
      p_usr_id        IN processingstatus.pid_usr_id_modify%TYPE);

   PROCEDURE p_endprocessingstatus (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_usr_id                 IN processingstatus.pid_usr_id%TYPE);

   FUNCTION f_getrecordbyexternalid (
      p_external_id   IN processingstatus.pid_externalid%TYPE)
      RETURN processingstatus%ROWTYPE;
END pkg_processingstatus;
/

