create trigger TR_BUF_SAMPLEMKIDETAILGROUP
    before update
    on SAMPLEMKIDETAILGROUP
    for each row
DECLARE
BEGIN
 
   :new.MKD_moddate := SYSDATE;
   :new.MKD_moduser := USER;
END tr_buf_SAMPLEMKIDETAILGROUP;

/

