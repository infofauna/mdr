create PACKAGE       pkg_java
AS
   /******************************************************************************
      NAME:       PKG_JAVA
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.10.2013      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getmaxmemorysize
      RETURN NUMBER;

   FUNCTION f_setmaxmemorysize (num NUMBER)
      RETURN NUMBER;

   PROCEDURE p_enablenewspace (x NUMBER);

   FUNCTION f_returncell (p_column IN PLS_INTEGER, p_row IN PLS_INTEGER)
      RETURN VARCHAR2;

   PROCEDURE p_test;
      PROCEDURE p_testdeletesheet;

   FUNCTION f_buildlistsheet (p_blob IN BLOB)
      RETURN NUMBER;

   FUNCTION f_deleteotherssheet (p_blob IN BLOB, p_name IN VARCHAR2)
      RETURN BLOB;

   PROCEDURE p_processprotocollaboratory (p_iph_id NUMBER);

   PROCEDURE p_processprotocolgrdval (p_iph_id NUMBER);

   PROCEDURE p_processinit (p_iph_id NUMBER, p_protocoltype VARCHAR2);

   PROCEDURE p_processmassdetail (p_iph_id NUMBER);
END pkg_java;
/

