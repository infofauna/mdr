create PACKAGE BODY       pkg_excelw
AS
   /******************************************************************************
      NAME:       PKG_EXCELW
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.10.2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, octobre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_buildsheetlist (
      p_blob         IN     BLOB,
      p_sheetlist       OUT pkg_worksheetlist.t_cursor,
      p_sheetcount      OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      pkg_excel.p_buildsheetlist (p_blob, p_sheetlist, p_sheetcount);
   END;
END pkg_excelw;
/

