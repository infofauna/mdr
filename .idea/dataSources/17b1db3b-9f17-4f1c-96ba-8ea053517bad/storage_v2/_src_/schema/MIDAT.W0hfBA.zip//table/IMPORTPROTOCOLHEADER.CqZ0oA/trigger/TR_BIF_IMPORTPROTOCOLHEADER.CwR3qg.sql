create trigger TR_BIF_IMPORTPROTOCOLHEADER
    before insert
    on IMPORTPROTOCOLHEADER
    for each row
DECLARE
BEGIN
   IF :new.iph_id IS NULL
   THEN
      :new.iph_id := seq_importprotocolheader.NEXTVAL;
   END IF;

   :new.iph_credate := SYSDATE;
   :new.iph_creuser := USER;
END tr_bif_importprotocolheader;

/

