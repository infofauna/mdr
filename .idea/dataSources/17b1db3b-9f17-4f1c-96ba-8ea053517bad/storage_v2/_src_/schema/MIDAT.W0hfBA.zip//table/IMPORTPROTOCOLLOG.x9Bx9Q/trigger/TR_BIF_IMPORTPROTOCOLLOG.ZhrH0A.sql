create trigger TR_BIF_IMPORTPROTOCOLLOG
    before insert
    on IMPORTPROTOCOLLOG
    for each row
DECLARE
BEGIN
   IF :new.IPO_id IS NULL
   THEN
      :new.IPO_id := seq_IMPORTPROTOCOLLOG.NEXTVAL;
   END IF;

   :new.IPO_credate := SYSDATE;
   :new.IPO_creuser := USER;
END tr_bif_IMPORTPROTOCOLLOG;

/

