create trigger TR_BUF_SAMPLESTATION
    before update
    on SAMPLESTATION
    for each row
DECLARE
   l_newrec   samplestation%ROWTYPE;
   l_oldrec   samplestation%ROWTYPE;
BEGIN
   l_oldrec.sst_id := :old.sst_id;
   l_oldrec.sst_status := :old.sst_status;

   l_oldrec.sst_oid := :old.sst_oid;
   l_oldrec.sst_coordinates := :old.sst_coordinates;
   l_oldrec.sst_gewissnr := :old.sst_gewissnr;
   l_oldrec.sst_gemeindenr := :old.sst_gemeindenr;
   l_oldrec.sst_credate := :old.sst_credate;
   l_oldrec.sst_creuser := :old.sst_creuser;
   l_oldrec.sst_moddate := :old.sst_moddate;
   l_oldrec.sst_moduser := :old.sst_moduser;


   l_newrec.sst_id := :new.sst_id;
   l_newrec.sst_status := :new.sst_status;
   l_newrec.sst_oid := :new.sst_oid;
   l_newrec.sst_coordinates := :new.sst_coordinates;
   l_newrec.sst_gewissnr := :new.sst_gewissnr;
   l_newrec.sst_gemeindenr := :new.sst_gemeindenr;
   l_newrec.sst_credate := :new.sst_credate;
   l_newrec.sst_creuser := :new.sst_creuser;
   l_newrec.sst_moddate := :new.sst_moddate;
   l_newrec.sst_moduser := :new.sst_moduser;

   --   pkg_SAMPLESTATION.p_tr_buf_SAMPLESTATION (l_oldrec, l_newrec);

   :new.sst_id := l_newrec.sst_id;

   :new.sst_oid := l_newrec.sst_oid;
   :new.sst_coordinates := l_newrec.sst_coordinates;
   :new.sst_gewissnr := l_newrec.sst_gewissnr;
   :new.sst_gemeindenr := l_newrec.sst_gemeindenr;

   :new.sst_credate := l_newrec.sst_credate;
   :new.sst_creuser := l_newrec.sst_creuser;
   :new.sst_moddate := l_newrec.sst_moddate;
   :new.sst_moduser := l_newrec.sst_moduser;
END;

/

