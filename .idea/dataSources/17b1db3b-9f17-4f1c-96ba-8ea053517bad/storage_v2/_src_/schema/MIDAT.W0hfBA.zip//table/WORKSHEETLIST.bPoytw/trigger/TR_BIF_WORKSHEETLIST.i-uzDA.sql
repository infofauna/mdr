create trigger TR_BIF_WORKSHEETLIST
    before insert
    on WORKSHEETLIST
    for each row
DECLARE
BEGIN
   IF :new.WSL_id IS NULL
   THEN
      :new.WSL_id := seq_WORKSHEETLIST.NEXTVAL;
   END IF;

   :new.WSL_credate := SYSDATE;
   :new.WSL_creuser := USER;
END tr_bif_WORKSHEETLIST;

/

