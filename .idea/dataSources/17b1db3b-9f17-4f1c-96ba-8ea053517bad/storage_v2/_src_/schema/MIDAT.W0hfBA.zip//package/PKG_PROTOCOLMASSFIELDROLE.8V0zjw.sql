create PACKAGE       pkg_protocolmassfieldrole
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLMASSFIELDROLE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        16.10.2017      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecord (p_pfr_id IN protocolmassfieldrole.pfr_id%TYPE)
      RETURN protocolmassfieldrole%ROWTYPE;

   FUNCTION f_userhasright (
      p_usr_id   IN admin_user_role.aur_usr_id%TYPE,
      p_pmm_id   IN protocolmassfieldrole.pfr_pmm_id%TYPE)
      RETURN VARCHAR2;

   PROCEDURE p_write (
      p_apr_id   IN     protocolmassfieldrole.pfr_apr_id%TYPE,
      p_pmm_id   IN     protocolmassfieldrole.pfr_pmm_id%TYPE,
      p_pfr_id      OUT protocolmassfieldrole.pfr_id%TYPE);
END pkg_protocolmassfieldrole;
/

