create PACKAGE       pkg_importprotocolheader
AS
    /******************************************************************************
       NAME:       PKG_IMPORTPROTOCOLHEADER
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        02.10.2013      burrif       1. Created this package.
       2.0         11.07.2017     burrif       2. Fonctionnalité version 2
    ******************************************************************************/



    cst_validstatusok        CONSTANT CHAR (1) := 'V';
    cst_validstatuspending   CONSTANT CHAR (1) := 'P';
    cst_validstatusnotok     CONSTANT CHAR (1) := 'N';
    cst_validstatusmerged    CONSTANT CHAR (1) := 'M';    -- Station fusionnée

    cst_purgeperiod          CONSTANT NUMBER := 10;                  -- Heures

    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_delete (p_iph_id IN importprotocolheader.iph_id%TYPE);

    PROCEDURE p_deleteallchildren (
        p_iph_id   IN importprotocolheader.iph_id%TYPE);

    FUNCTION f_findprotocolheader (
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_code     IN codevalue.cvl_code%TYPE)
        RETURN importprotocolheader%ROWTYPE;

    PROCEDURE p_purgeinvalidmassdata;

    PROCEDURE p_clear_iph_sst_id_existing (
        p_sst_id   IN importprotocolheader.iph_sst_id_existing%TYPE);

    PROCEDURE p_clear_iph_sph_id_parent (
        p_sph_id_parent   IN importprotocolheader.iph_sph_id_parent%TYPE);

    PROCEDURE p_deleteconditionnal (
        p_iph_id   IN importprotocolheader.iph_id%TYPE);

    PROCEDURE p_deletebyiphidmaster (
        p_iph_id   IN importprotocolheader.iph_id%TYPE);

    PROCEDURE p_update_makroindexnewvalue (
        p_iph_id               IN importprotocolheader.iph_id%TYPE,
        p_makroindexnewvalue   IN importprotocolheader.iph_makroindexnewvalue%TYPE,
        p_windowmakroindex     IN importprotocolheader.iph_cvl_id_windowmakroindex%TYPE);

    PROCEDURE p_update_ibchnewvalue (
        p_iph_id         IN importprotocolheader.iph_id%TYPE,
        p_ibchnewvalue   IN importprotocolheader.iph_ibchnewvalue%TYPE,
        p_windowibch     IN importprotocolheader.iph_cvl_id_windowibch%TYPE);

    PROCEDURE p_update_computed_data (
        p_iph_id                      IN importprotocolheader.iph_id%TYPE,
        p_ibchnewvalue                IN importprotocolheader.iph_ibchnewvalue%TYPE,
        p_windowibch                  IN importprotocolheader.iph_cvl_id_windowibch%TYPE,
        p_taxonindicateur             IN importprotocolheader.iph_taxonindicateur%TYPE,
        p_ibchrobust                  IN importprotocolheader.iph_ibchrobust%TYPE,
        p_classevariete               IN importprotocolheader.iph_classevariete%TYPE,
        p_classevariete_corr          IN importprotocolheader.iph_classevariete_corr%TYPE,
        p_classevarieterobust         IN importprotocolheader.iph_classevarieterobust%TYPE,
        p_classevarieterobust_corr    IN importprotocolheader.iph_classevarieterobust_corr%TYPE,
        p_classevariete_final         IN importprotocolheader.iph_classevariete_final%TYPE,
        p_classevarieterobust_final   IN importprotocolheader.iph_classevarieterobust_final%TYPE,
        p_taxonfrequencesum           IN importprotocolheader.iph_taxonfrequencesum%TYPE,
        p_gimax                       IN importprotocolheader.iph_gimax%TYPE,
        p_gimaxrobust                 IN importprotocolheader.iph_gimaxrobust%TYPE,
        p_gi_final                    IN importprotocolheader.iph_gi_final%TYPE,
        p_girobust_final              IN importprotocolheader.iph_girobust_final%TYPE,
        p_sumfamily                   IN importprotocolheader.iph_sumfamily%TYPE,
        p_sumfamilycorrected          IN importprotocolheader.iph_sumfamilycorrected%TYPE,
        p_sumfamilyrobust             IN importprotocolheader.iph_sumfamilyrobust%TYPE,
        p_sumfamilyrobustcorrected    IN importprotocolheader.iph_sumfamilyrobustcorrected%TYPE,
        p_ephemeropteracounter        IN importprotocolheader.iph_ephemeropteracounter%TYPE,
        p_plecopteracounter           IN importprotocolheader.iph_plecopteracounter%TYPE,
        p_tricopteracounter           IN importprotocolheader.iph_tricopteracounter%TYPE);

    PROCEDURE p_update_spearindexnewvalue (
        p_iph_id               IN importprotocolheader.iph_id%TYPE,
        p_spearindexnewvalue   IN importprotocolheader.iph_spearindexnewvalue%TYPE,
        p_windowspear          IN importprotocolheader.iph_cvl_id_windowspear%TYPE);

    PROCEDURE p_updatepid_id (
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_pid_id   IN importprotocolheader.iph_pid_id%TYPE);

    PROCEDURE p_updateexternal_id (
        p_iph_id        IN importprotocolheader.iph_id%TYPE,
        p_external_id   IN importprotocolheader.iph_external_id%TYPE);

    PROCEDURE p_updateprocessingdata (
        p_iph_id        IN importprotocolheader.iph_id%TYPE,
        p_external_id   IN importprotocolheader.iph_external_id%TYPE,
        p_pid_id        IN importprotocolheader.iph_pid_id%TYPE);

    FUNCTION f_getvirtimportheaderprotocol (
        p_iph_id   IN importprotocolheader.iph_id%TYPE)
        RETURN importprotocolheader%ROWTYPE;

    PROCEDURE p_updateiph_iph_id (
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_sph_id   IN sampleheader.sph_id%TYPE);



    FUNCTION f_getrecord (p_iph_id IN importprotocolheader.iph_id%TYPE)
        RETURN importprotocolheader%ROWTYPE;

    PROCEDURE p_updateusrid (
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_usr_id   IN importprotocolheader.iph_usr_id_modify%TYPE);

    PROCEDURE p_updateexistingstation (
        p_iph_id            IN importprotocolheader.iph_id%TYPE,
        p_sst_id_existing   IN importprotocolheader.iph_sst_id_existing%TYPE,
        p_usr_id            IN importprotocolheader.iph_usr_id_modify%TYPE);

    PROCEDURE p_updatevalidatestatus (
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_status   IN importprotocolheader.iph_validstatus%TYPE,
        p_usr_id   IN importprotocolheader.iph_usr_id_modify%TYPE);

    PROCEDURE p_insertlabodata (
        p_ins_id_principal      IN     importprotocolheader.iph_ins_id_principal%TYPE,
        p_ins_id_mandatary      IN     importprotocolheader.iph_ins_id_mandatary%TYPE,
        p_ptv_id                IN     importprotocolheader.iph_ptv_id%TYPE,
        p_per_id_determinator   IN     importprotocolheader.iph_per_id_determinator%TYPE,
        p_determinateddate      IN     importprotocolheader.iph_determinateddate%TYPE,
        p_per_id_operator       IN     importprotocolheader.iph_per_id_operator%TYPE,
        p_observationdate       IN     importprotocolheader.iph_observationdate%TYPE,
        p_cvl_id_midatstat      IN     importprotocolheader.iph_cvl_id_midatstat%TYPE,
        p_reporturl             IN     importprotocolheader.iph_reporturl%TYPE,
        p_lan_id                IN     importprotocolheader.iph_lan_id%TYPE,
        p_cvl_id_systlref       IN     importprotocolheader.iph_cvl_id_systlref%TYPE,
        p_cvl_id_systlprec      IN     importprotocolheader.iph_cvl_id_systlprec%TYPE,
        p_inputfilename         IN     importprotocolheader.iph_inputfilename%TYPE,
        p_file                  IN     importprotocolheader.iph_file%TYPE,
        p_sheetname             IN     importprotocolheader.iph_sheetname%TYPE,
        p_usr_id_create         IN     importprotocolheader.iph_usr_id_create%TYPE,
        p_sph_id_parent         IN     importprotocolheader.iph_sph_id_parent%TYPE,
        p_iph_prj_id            IN     importprotocolheader.iph_prj_id%TYPE,
        p_id                       OUT importprotocolheader.iph_id%TYPE);

    PROCEDURE p_purge;

    PROCEDURE p_deletegrid (p_iph_id IN importprotocolheader.iph_id%TYPE);

    PROCEDURE p_deletegrnd (p_iph_id IN importprotocolheader.iph_id%TYPE);

    PROCEDURE p_deletelabo (p_iph_id IN importprotocolheader.iph_id%TYPE);

    PROCEDURE p_update_iph_cvl_id_canton (
        p_iph_id              IN importprotocolheader.iph_id%TYPE,
        p_iph_cvl_id_canton   IN importprotocolheader.iph_cvl_id_canton%TYPE);
END pkg_importprotocolheader;
/

