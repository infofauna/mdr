create PACKAGE BODY       pkg_validate_2020
AS
    /******************************************************************************
       NAME:       PKG_VALIDATE_2020
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        05.08.2020      burrif       1. Created this package.

    ******************************************************************************/

    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.3, janvier  2020' ;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*----------------------------------------------------------------------*/
    PROCEDURE p_validateprocess_v2 (
        p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
        p_lan_id        IN     language.lan_id%TYPE,
        p_usr_id        IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_pid_id        IN     importprotocolheader.iph_pid_id%TYPE,
        p_cursorerror      OUT pkg_importprotocollog.t_cursor,
        p_errorlevel       OUT VARCHAR2)
    /*----------------------------------------------------------------------*/
    IS
    BEGIN
        NULL;
    END;
END pkg_validate_2020;
/

