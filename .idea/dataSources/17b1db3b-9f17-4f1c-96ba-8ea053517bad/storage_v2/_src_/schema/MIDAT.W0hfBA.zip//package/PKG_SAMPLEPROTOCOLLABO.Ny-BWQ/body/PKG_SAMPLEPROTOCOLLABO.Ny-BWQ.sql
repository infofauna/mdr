create PACKAGE BODY       pkg_sampleprotocollabo
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEPROTOCOLLABO
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       25.07.2013  F.Burri           1. Created this package body.
      1.1       12.10.2017  F. Burri          2. Version 2 MIDAT
   ******************************************************************************/



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------------------------*/
   PROCEDURE p_recomputeonespearindice (
      p_recsampleprotocolheader   IN sampleheader%ROWTYPE)
   /*---------------------------------------------------------------------------------*/
   IS
      CURSOR l_sampleprotocollabo (
         p_sph_id   IN sampleprotocollabo.spl_sph_id%TYPE)
      IS
         SELECT *
           FROM sampleprotocollabo
          WHERE spl_sph_id = p_sph_id;

      l_recsampleprotocollabo   l_sampleprotocollabo%ROWTYPE;
      l_status                  NUMBER;
   BEGIN
      OPEN l_sampleprotocollabo (p_recsampleprotocolheader.sph_id);

      LOOP
         FETCH l_sampleprotocollabo INTO l_recsampleprotocollabo;

         EXIT WHEN l_sampleprotocollabo%NOTFOUND;
         pkg_spear.p_spearadddata (l_recsampleprotocollabo.spl_syv_id,
                                   l_recsampleprotocollabo.spl_frequency,
                                   p_recsampleprotocolheader.sph_ptv_id,
                                   l_status); --pkg_constante.cst_returnstatusnotok -> pas dans la liste
      END LOOP;

      CLOSE l_sampleprotocollabo;
   END;


   /*-----------------------------------------------------------------------------------*/
   PROCEDURE p_recomputespearindex (p_flag IN VARCHAR2)
   /*-----------------------------------------------------------------------------------*/
   IS
      CURSOR l_sampleheader
      IS
           SELECT *
             FROM sampleheader
            WHERE NOT sph_spearindexvalue IS NULL
         ORDER BY sph_credate;

      l_recsampleheader     sampleheader%ROWTYPE;
      l_spearindice         sampleheader.sph_spearindexvalue%TYPE;
      l_abondanceflag       VARCHAR2 (10);
      l_recindeiceversion   indiceversion%ROWTYPE;
   BEGIN
      l_recindeiceversion :=
         pkg_indiceversion.f_getcurrentversion (
            pkg_codevalue.cst_midatindice_spear);

      OPEN l_sampleheader;

      LOOP
         FETCH l_sampleheader INTO l_recsampleheader;

         EXIT WHEN l_sampleheader%NOTFOUND;
         pkg_spear.p_spearinit;
         p_recomputeonespearindice (l_recsampleheader);

         IF l_recsampleheader.sph_absolutenumberflag = pkg_constante.cst_yes
         THEN
            l_abondanceflag := pkg_ibch.cst_abondanceflag_absolu;
         ELSE
            l_abondanceflag := pkg_ibch.cst_abondanceflag_class;
         END IF;

         l_spearindice := pkg_spear.f_computespearfrommemory (l_abondanceflag);
         DBMS_OUTPUT.put_line (
               ' Créé: '
            || l_recsampleheader.sph_credate
            || ' OLD SPEAR VALUE='
            || l_recsampleheader.sph_spearindexvalue
            || ' New: '
            || l_spearindice);

         IF p_flag = pkg_constante.cst_yes
         THEN
            UPDATE sampleheader
               SET sph_spearindexvalue = l_spearindice,
                   sph_ivr_id_spear = l_recindeiceversion.ivr_id
             WHERE sph_id = l_recsampleheader.sph_id;
         END IF;
      END LOOP;

      CLOSE l_sampleheader;
   END;



   /*---------------------------------------------------------------------------------*/
   PROCEDURE p_recomputeoneibchindice (
      p_recsampleprotocolheader   IN sampleheader%ROWTYPE)
   /*---------------------------------------------------------------------------------*/
   IS
      /* Pour le recalcule:
      1) on va regarder la version courante à appliquer dans la table INDICEVERSION
      2) Si la colonne IVR_PTV_ID est NULL, on utilise le PTV_ID de la table sampleheader (celui déjà utilisé)
         Si la colonne IVR_PTV_ID n'est pas null on utilise le PTV_ID défini
      */
      CURSOR l_sampleprotocollabo (
         p_sph_id   IN sampleprotocollabo.spl_sph_id%TYPE)
      IS
         SELECT *
           FROM sampleprotocollabo
          WHERE spl_sph_id = p_sph_id;

      l_recsampleprotocollabo    l_sampleprotocollabo%ROWTYPE;
      l_status                   NUMBER;
      l_ptl_id                   protocolmappinglabo.ptl_id%TYPE;
      l_recindiceversion         indiceversion%ROWTYPE;
      l_recprotocolversion       protocolversion%ROWTYPE;
      l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
      l_reccodevalueorig         codevalue%ROWTYPE;
      l_reccodevalue             codevalue%ROWTYPE;
      l_ptv_id                   protocolversion.ptv_id%TYPE;
   BEGIN
      l_recindiceversion :=
         pkg_indiceversion.f_getcurrentversion (
            pkg_codevalue.cst_midatindice_ibch);

      IF NOT l_recindiceversion.ivr_ptv_id IS NULL
      THEN
         l_ptv_id := l_recindiceversion.ivr_ptv_id;
      ELSE
         l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
               p_recsampleprotocolheader.sph_ptv_id);

         l_reccodevalueorig :=
            pkg_codevalue.f_getrecord (
               l_recprotocolversion.ptv_cvl_id_protocoltype);

         IF l_reccodevalueorig.cvl_code = pkg_codevalue.cst_protocoltype_mass
         THEN
            l_ptv_id := l_recprotocolversion.ptv_ptv_id_labofrommass;
         ELSE
            l_ptv_id := l_recprotocolversion.ptv_id;
         END IF;
      END IF;

      l_recprotocolversion := pkg_protocolversion.f_getrecord (l_ptv_id);

      l_reccodevalue :=
         pkg_codevalue.f_getrecord (
            l_recprotocolversion.ptv_cvl_id_protocoltype);

      IF l_reccodevalue.cvl_code != pkg_codevalue.cst_protocoltype_laboratory
      THEN
         raise_application_error (
            -20000,
            ' Le recalcule de l''iBCH doit s''appuyer sur un protocole de tyype laboratoire. Vérifier la cohérence des données dans la table INDICEVERSION',
            TRUE);
      END IF;



      OPEN l_sampleprotocollabo (p_recsampleprotocolheader.sph_id);

      LOOP
         FETCH l_sampleprotocollabo INTO l_recsampleprotocollabo;

         EXIT WHEN l_sampleprotocollabo%NOTFOUND;

         IF l_reccodevalueorig.cvl_code = pkg_codevalue.cst_protocoltype_mass
         THEN
            l_recprotocolmappinglabo :=
               pkg_protocolmappinglabo.f_identifyentrybyhierarchy (
                  l_recsampleprotocollabo.spl_syv_id,
                  l_ptv_id);
         ELSE
            l_recprotocolmappinglabo :=
               pkg_protocolmappinglabo.f_getrecordfromsyv_id (
                  l_recsampleprotocollabo.spl_syv_id,
                  l_ptv_id);
         END IF;

         pkg_ibch.p_ibchadddata (l_recprotocolmappinglabo.ptl_id,
                                 l_recsampleprotocollabo.spl_frequency);
      END LOOP;

      CLOSE l_sampleprotocollabo;
   END;

   /*-----------------------------------------------------------------------------------*/
   PROCEDURE p_recomputeibchindex (p_flag IN VARCHAR2)
   /*-----------------------------------------------------------------------------------*/
   IS
      CURSOR l_sampleheader
      IS
           SELECT *
             FROM sampleheader
            WHERE NOT sph_indexvalueibch IS NULL
         ORDER BY sph_credate;

      l_recsampleheader   sampleheader%ROWTYPE;
      l_ibchindice        sampleheader.sph_indexvalueibch%TYPE;
      l_abondanceflag     VARCHAR2 (10);
   BEGIN
      OPEN l_sampleheader;

      LOOP
         FETCH l_sampleheader INTO l_recsampleheader;

         EXIT WHEN l_sampleheader%NOTFOUND;
         pkg_ibch.p_ibchinit;


         p_recomputeoneibchindice (l_recsampleheader);

         IF l_recsampleheader.sph_absolutenumberflag = pkg_constante.cst_yes
         THEN
            l_abondanceflag := pkg_ibch.cst_abondanceflag_absolu;
         ELSE
            l_abondanceflag := pkg_ibch.cst_abondanceflag_class;
         END IF;

         l_ibchindice := pkg_ibch.f_computeibchfrommemory (l_abondanceflag);

         IF l_recsampleheader.sph_indexvalueibch != l_ibchindice
         THEN
            DBMS_OUTPUT.put_line (
                  'sph_id='
               || l_recsampleheader.sph_id
               || ' Créé: '
               || l_recsampleheader.sph_credate
               || ' OLD IBCH VALUE='
               || l_recsampleheader.sph_indexvalueibch
               || ' New: '
               || l_ibchindice
               || ' l_recsampleheader.sph_absolutenumberflag='
               || l_recsampleheader.sph_absolutenumberflag
               || ' l_recsampleheader.sph_ptv_id='
               || l_recsampleheader.sph_ptv_id);
         END IF;

         IF p_flag = pkg_constante.cst_yes
         THEN
            UPDATE sampleheader
               SET sph_indexvalueibch = l_ibchindice
             WHERE sph_id = l_recsampleheader.sph_id;
         END IF;
      END LOOP;

      CLOSE l_sampleheader;
   END;

   /*---------------------------------------------------------------------------------*/
   PROCEDURE p_recomputeonemakroindex (
      p_recsampleprotocolheader   IN sampleheader%ROWTYPE)
   /*---------------------------------------------------------------------------------*/
   IS
      CURSOR l_sampleprotocollabo (
         p_sph_id   IN sampleprotocollabo.spl_sph_id%TYPE)
      IS
         SELECT *
           FROM sampleprotocollabo
          WHERE spl_sph_id = p_sph_id;

      l_recsampleprotocollabo   l_sampleprotocollabo%ROWTYPE;
      l_status                  NUMBER;
   BEGIN
      OPEN l_sampleprotocollabo (p_recsampleprotocolheader.sph_id);

      LOOP
         FETCH l_sampleprotocollabo INTO l_recsampleprotocollabo;

         EXIT WHEN l_sampleprotocollabo%NOTFOUND;
         pkg_makroindex.p_mkiadddata (NULL, -- p_recimportprotocolheader --> Pas d'écriture dans le log
                                      l_recsampleprotocollabo.spl_syv_id);
      END LOOP;

      CLOSE l_sampleprotocollabo;
   END;



   /*-----------------------------------------------------------------------------------*/
   PROCEDURE p_recomputemakroindex (p_flag IN VARCHAR2)
   /*-----------------------------------------------------------------------------------*/
   IS
      CURSOR l_sampleheader
      IS
           SELECT *
             FROM sampleheader
            WHERE NOT sph_makroindexvalue IS NULL
         ORDER BY sph_credate;

      l_recsampleheader   sampleheader%ROWTYPE;
      l_makroindex        sampleheader.sph_makroindexvalue%TYPE;
      l_abondanceflag     VARCHAR2 (10);
   BEGIN
      OPEN l_sampleheader;

      LOOP
         FETCH l_sampleheader INTO l_recsampleheader;

         EXIT WHEN l_sampleheader%NOTFOUND;
         pkg_makroindex.p_mkiinit;


         p_recomputeonemakroindex (l_recsampleheader);



         l_makroindex := pkg_makroindex.f_computemakroindex;

         IF l_recsampleheader.sph_makroindexvalue != l_makroindex
         THEN
            DBMS_OUTPUT.put_line (
                  'sph_id='
               || l_recsampleheader.sph_id
               || ' Créé: '
               || l_recsampleheader.sph_credate
               || ' OLD makroindex VALUE='
               || l_recsampleheader.sph_makroindexvalue
               || ' New: '
               || l_makroindex
               || ' l_recsampleheader.sph_ptv_id='
               || l_recsampleheader.sph_ptv_id);
         END IF;

         IF p_flag = pkg_constante.cst_yes
         THEN
            UPDATE sampleheader
               SET sph_makroindexvalue = l_makroindex
             WHERE sph_id = l_recsampleheader.sph_id;
         END IF;
      END LOOP;

      CLOSE l_sampleheader;
   END;


   /*------------------------------------------------------------------------------*/
   PROCEDURE p_updatesortorder (
      p_spl_id   IN sampleprotocollabo.spl_id%TYPE,
      p_order    IN sampleprotocollabo.spl_sortorder%TYPE)
   /*------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE sampleprotocollabo
         SET spl_sortorder = p_order
       WHERE spl_id = p_spl_id;
   END;

   /*------------------------------------------------------------------------------*/
   PROCEDURE p_updatemasssortorder (
      p_sph_id   IN sampleprotocollabo.spl_sph_id%TYPE)
   /*-----------------------------------------------------------------------------*/
   IS
      CURSOR l_cursor
      IS
         SELECT ROWNUM,
                code_phylum,
                code_classe,
                code_order,
                family,
                genus,
                species,
                spl_syv_id,
                spl_id
           FROM (  SELECT TO_NUMBER (
                             pkg_systexternalcode.f_getexternalcodeatlevel (
                                spl_syv_id,
                                pkg_codesource.cst_csc_cscf_phylum,
                                pkg_codereference.cst_crf_phylum))
                             code_phylum,
                          TO_NUMBER (
                             pkg_systexternalcode.f_getexternalcodeatlevel (
                                spl_syv_id,
                                pkg_codesource.cst_csc_cscf_class,
                                pkg_codereference.cst_crf_class))
                             code_classe,
                          TO_NUMBER (
                             pkg_systexternalcode.f_getexternalcodeatlevel (
                                spl_syv_id,
                                pkg_codesource.cst_csc_cscf_order,
                                pkg_codereference.cst_crf_order))
                             code_order,
                          pkg_systdesignation.f_getdesignationatlevel (
                             spl_syv_id,
                             pkg_codereference.cst_crf_family,
                             pkg_language.cst_lan_cde_latin)
                             family,
                          pkg_systdesignation.f_getdesignationatlevel (
                             spl_syv_id,
                             pkg_codereference.cst_crf_genus,
                             pkg_language.cst_lan_cde_latin)
                             genus,
                          pkg_systdesignation.f_getdesignationatlevel (
                             spl_syv_id,
                             pkg_codereference.cst_crf_species,
                             pkg_language.cst_lan_cde_latin)
                             species,
                          spl_id,
                          spl_syv_id
                     FROM sampleheader
                          INNER JOIN sampleprotocollabo ON spl_sph_id = sph_id
                          INNER JOIN systvalue ON syv_id = spl_syv_id
                    WHERE NOT sph_imh_id IS NULL AND sph_id = p_sph_id
                 ORDER BY 1,
                          2,
                          3,
                          4,
                          5,
                          6);

      l_reccursor             l_cursor%ROWTYPE;
      l_recsystdesitgnation   systdesignation%ROWTYPE;
   BEGIN
      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         /*
         DBMS_OUTPUT.put_line (
               'Code phylum: '
            || l_reccursor.code_phylum
            || ' Code classe '
            || l_reccursor.code_classe
            || ' Code order '
            || l_reccursor.code_order
            || ' Famille '
            || l_reccursor.family
            || ' Genus '
            || l_reccursor.genus
            || ' Species '
            || l_reccursor.species
            || ' syv_id_base: '
            || l_reccursor.spl_syv_id);
            */
         p_updatesortorder (l_reccursor.spl_id, l_reccursor.ROWNUM);
      END LOOP;

      CLOSE l_cursor;
   END;

   /*------------------------------------------------------------------------------*/
   PROCEDURE p_updatelabosortorder (
      p_sph_id   IN sampleprotocollabo.spl_sph_id%TYPE)
   /*-----------------------------------------------------------------------------*/
   IS
      CURSOR l_cursor
      IS
         SELECT ROWNUM,
                code_phylum,
                code_classe,
                code_order,
                family,
                genus,
                species,
                spl_syv_id,
                spl_id
           FROM (  SELECT TO_NUMBER (
                             pkg_systexternalcode.f_getexternalcodeatlevel (
                                spl_syv_id,
                                pkg_codesource.cst_csc_cscf_phylum,
                                pkg_codereference.cst_crf_phylum))
                             code_phylum,
                          TO_NUMBER (
                             pkg_systexternalcode.f_getexternalcodeatlevel (
                                spl_syv_id,
                                pkg_codesource.cst_csc_cscf_class,
                                pkg_codereference.cst_crf_class))
                             code_classe,
                          TO_NUMBER (
                             pkg_systexternalcode.f_getexternalcodeatlevel (
                                spl_syv_id,
                                pkg_codesource.cst_csc_cscf_order,
                                pkg_codereference.cst_crf_order))
                             code_order,
                          pkg_systdesignation.f_getdesignationatlevel (
                             spl_syv_id,
                             pkg_codereference.cst_crf_family,
                             pkg_language.cst_lan_cde_latin)
                             family,
                          pkg_systdesignation.f_getdesignationatlevel (
                             spl_syv_id,
                             pkg_codereference.cst_crf_genus,
                             pkg_language.cst_lan_cde_latin)
                             genus,
                          pkg_systdesignation.f_getdesignationatlevel (
                             spl_syv_id,
                             pkg_codereference.cst_crf_species,
                             pkg_language.cst_lan_cde_latin)
                             species,
                          spl_id,
                          spl_syv_id
                     FROM sampleheader
                          INNER JOIN sampleprotocollabo ON spl_sph_id = sph_id
                          INNER JOIN systvalue ON syv_id = spl_syv_id
                    WHERE sph_imh_id IS NULL AND sph_id = p_sph_id
                 ORDER BY 1,
                          2,
                          3,
                          4,
                          5,
                          6);

      l_reccursor             l_cursor%ROWTYPE;
      l_recsystdesitgnation   systdesignation%ROWTYPE;
   BEGIN
      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         /*
         DBMS_OUTPUT.put_line (
               'Code phylum: '
            || l_reccursor.code_phylum
            || ' Code classe '
            || l_reccursor.code_classe
            || ' Code order '
            || l_reccursor.code_order
            || ' Famille '
            || l_reccursor.family
            || ' Genus '
            || l_reccursor.genus
            || ' Species '
            || l_reccursor.species
            || ' syv_id_base: '
            || l_reccursor.spl_syv_id);
            */
         p_updatesortorder (l_reccursor.spl_id, l_reccursor.ROWNUM);
      END LOOP;

      CLOSE l_cursor;
   END;


   /*-----------------------------------------------------------------*/
   PROCEDURE p_routeupdatesortorder (
      p_sph_id   IN sampleprotocollabo.spl_sph_id%TYPE)
   /*-----------------------------------------------------------------*/
   IS
      l_recsampleheader   sampleheader%ROWTYPE;
   BEGIN
      -- Il faut déterminer le type  (mass ou protocol labo) du fichier
      -- Si il y a une valeur SPH_IMH_ID défini, on a a faire à un ficheir de masse
      l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);

      IF l_recsampleheader.sph_id IS NULL
      THEN
         RETURN;
      END IF;

      IF NOT l_recsampleheader.sph_imh_id IS NULL
      THEN
         -- Fichier de masse
         p_updatemasssortorder (p_sph_id);
      ELSE
         p_updatelabosortorder (p_sph_id);
         NULL;
      END IF;
   END;


   /*--------------------------------------------------------------*/

   PROCEDURE p_deleteby_sph_id (p_sph_id IN sampleheader.sph_id%TYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleprotocollabo
            WHERE spl_sph_id = p_sph_id;
   END;

   /*--------------------------------------------------------------*/

   FUNCTION f_getrecord (p_spl_id IN sampleprotocollabo.spl_id%TYPE)
      RETURN sampleprotocollabo%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record   sampleprotocollabo%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM sampleprotocollabo
       WHERE spl_id = p_spl_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*---------------------------------------------------------------*/

   PROCEDURE p_check (p_command   IN     VARCHAR2,
                      p_oldrec    IN     sampleprotocollabo%ROWTYPE,
                      p_newrec    IN OUT sampleprotocollabo%ROWTYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      NULL;
   END;

   /*--------------------------------------------------------------*/

   PROCEDURE p_tr_bif_sampleprotocollabo (
      p_newrec   IN OUT sampleprotocollabo%ROWTYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      p_newrec.spl_credate := SYSDATE;
      p_newrec.spl_creuser := USER;

      IF p_newrec.spl_id IS NULL
      THEN
         p_newrec.spl_id := seq_sampleprotocollabo.NEXTVAL;
      END IF;

      p_check (pkg_constante.cst_dml_command_insert, NULL, p_newrec);
   END;

   /*--------------------------------------------------------------*/

   PROCEDURE p_tr_buf_sampleprotocollabo (
      p_oldrec   IN     sampleprotocollabo%ROWTYPE,
      p_newrec   IN OUT sampleprotocollabo%ROWTYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      p_newrec.spl_moddate := SYSDATE;
      p_newrec.spl_moduser := USER;
      p_check (pkg_constante.cst_dml_command_update, p_oldrec, p_newrec);
   END;

   /*--------------------------------------------------------------------------------*/
   FUNCTION f_getbycriterion (
      p_sph_id                IN sampleprotocollabo.spl_sph_id%TYPE,
      p_ptl_id                IN sampleprotocollabo.spl_ptl_id%TYPE,
      p_syv_id                IN sampleprotocollabo.spl_syv_id%TYPE,
      p_cvl_id_zoostadium     IN sampleprotocollabo.spl_cvl_id_zoostadium%TYPE,
      p_frequency             IN sampleprotocollabo.spl_frequency%TYPE,
      p_frequencymodified     IN sampleprotocollabo.spl_frequencymodified%TYPE,
      p_freqlum               IN sampleprotocollabo.spl_freqlum%TYPE,
      p_stadium               IN sampleprotocollabo.spl_stadium%TYPE,
      p_sampleno              IN sampleprotocollabo.spl_sampleno%TYPE,
      p_comment               IN sampleprotocollabo.spl_comment%TYPE,
      p_unidentifiedspecies   IN sampleprotocollabo.spl_unidentifiedspecies%TYPE)
      RETURN sampleprotocollabo%ROWTYPE
   /*--------------------------------------------------------------------------------*/
   IS
      cst_null         CONSTANT VARCHAR (10) := 'XYXXXYX';
      l_recsampleprotocollabo   sampleprotocollabo%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recsampleprotocollabo
        FROM sampleprotocollabo
       WHERE     spl_sph_id = p_sph_id
             AND NVL (spl_ptl_id, 0) = NVL (p_ptl_id, 0)
             AND spl_syv_id = p_syv_id
             AND NVL (spl_cvl_id_zoostadium, -1) =
                    NVL (p_cvl_id_zoostadium, -1)
             AND NVL (spl_frequencymodified, -1) =
                    NVL (p_frequencymodified, -1)
             AND NVL (spl_stadium, cst_null) = NVL (p_stadium, cst_null)
             AND NVL (spl_sampleno, cst_null) = NVL (p_sampleno, cst_null)
             AND NVL (spl_comment, cst_null) = NVL (p_comment, cst_null)
             AND NVL (spl_unidentifiedspecies, cst_null) =
                    NVL (p_unidentifiedspecies, cst_null);

      RETURN l_recsampleprotocollabo;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*----------------------------------------------------------------------------------*/
   PROCEDURE p_updatefreq (
      p_spl_id    IN sampleprotocollabo.spl_id%TYPE,
      p_addfreq   IN sampleprotocollabo.spl_frequency%TYPE)
   /*----------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE sampleprotocollabo
         SET spl_frequency = NVL (spl_frequency, 0) + NVL (p_addfreq, 0)
       WHERE spl_id = p_spl_id;
   END;

   PROCEDURE p_write (
      p_sph_id                IN     sampleprotocollabo.spl_sph_id%TYPE,
      p_ptl_id                IN     sampleprotocollabo.spl_ptl_id%TYPE,
      p_syv_id                IN     sampleprotocollabo.spl_syv_id%TYPE,
      p_cvl_id_zoostadium     IN     sampleprotocollabo.spl_cvl_id_zoostadium%TYPE,
      p_frequency             IN     sampleprotocollabo.spl_frequency%TYPE,
      p_frequencymodified     IN     sampleprotocollabo.spl_frequencymodified%TYPE,
      p_freqlum               IN     sampleprotocollabo.spl_freqlum%TYPE,
      p_stadium               IN     sampleprotocollabo.spl_stadium%TYPE,
      p_sampleno              IN     sampleprotocollabo.spl_sampleno%TYPE,
      p_comment               IN     sampleprotocollabo.spl_comment%TYPE,
      p_unidentifiedspecies   IN     sampleprotocollabo.spl_unidentifiedspecies%TYPE,
      p_usr_id                IN     sampleprotocollabo.spl_usr_id_create%TYPE,
      p_spl_id                   OUT sampleprotocollabo.spl_id%TYPE)
   /*---------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_spl_id := seq_sampleprotocollabo.NEXTVAL;

      INSERT INTO sampleprotocollabo (spl_id,
                                      spl_sph_id,
                                      spl_ptl_id,
                                      spl_syv_id,
                                      spl_cvl_id_zoostadium,
                                      spl_frequency,
                                      spl_frequencymodified,
                                      spl_freqlum,
                                      spl_stadium,
                                      spl_sampleno,
                                      spl_comment,
                                      spl_unidentifiedspecies,
                                      spl_usr_id_create,
                                      spl_usr_create_date)
           VALUES (p_spl_id,
                   p_sph_id,
                   p_ptl_id,
                   p_syv_id,
                   p_cvl_id_zoostadium,
                   p_frequency,
                   p_frequencymodified,
                   p_freqlum,
                   p_stadium,
                   p_sampleno,
                   p_comment,
                   p_unidentifiedspecies,
                   p_usr_id,
                   SYSDATE);
   END;

   /*----------------------------------------------------------------------------------*/

   PROCEDURE p_writeorupdate (
      p_sph_id                IN     sampleprotocollabo.spl_sph_id%TYPE,
      p_ptl_id                IN     sampleprotocollabo.spl_ptl_id%TYPE,
      p_syv_id                IN     sampleprotocollabo.spl_syv_id%TYPE,
      p_cvl_id_zoostadium     IN     sampleprotocollabo.spl_cvl_id_zoostadium%TYPE,
      p_frequency             IN     sampleprotocollabo.spl_frequency%TYPE,
      p_frequencymodified     IN     sampleprotocollabo.spl_frequencymodified%TYPE,
      p_freqlum               IN     sampleprotocollabo.spl_freqlum%TYPE,
      p_stadium               IN     sampleprotocollabo.spl_stadium%TYPE,
      p_sampleno              IN     sampleprotocollabo.spl_sampleno%TYPE,
      p_comment               IN     sampleprotocollabo.spl_comment%TYPE,
      p_unidentifiedspecies   IN     sampleprotocollabo.spl_unidentifiedspecies%TYPE,
      p_usr_id                IN     sampleprotocollabo.spl_usr_id_create%TYPE,
      p_spl_id                   OUT sampleprotocollabo.spl_id%TYPE)
   /*---------------------------------------------------------------------------------*/
   IS
      -- Permet de cumuler si des données identiques existe déjà (sauf FREQ1)
      l_recsampleprotocollabo   sampleprotocollabo%ROWTYPE;
      l_spl_id                  sampleprotocollabo.spl_id%TYPE;
   BEGIN
      NULL;


      l_recsampleprotocollabo :=
         f_getbycriterion (p_sph_id,
                           p_ptl_id,
                           p_syv_id,
                           p_cvl_id_zoostadium,
                           p_frequency,
                           p_frequencymodified,
                           p_freqlum,
                           p_stadium,
                           p_sampleno,
                           p_comment,
                           p_unidentifiedspecies);

      IF NOT l_recsampleprotocollabo.spl_id IS NULL
      THEN
         p_updatefreq (l_recsampleprotocollabo.spl_id, p_frequency);
         p_spl_id := l_recsampleprotocollabo.spl_id;
      ELSE
         p_write (p_sph_id,
                  p_ptl_id,
                  p_syv_id,
                  p_cvl_id_zoostadium,
                  p_frequency,
                  p_frequencymodified,
                  p_freqlum,
                  p_stadium,
                  p_sampleno,
                  p_comment,
                  p_unidentifiedspecies,
                  p_usr_id,
                  l_spl_id);
         p_spl_id := l_spl_id;
         NULL;
      END IF;
   END;
END pkg_sampleprotocollabo;
/

