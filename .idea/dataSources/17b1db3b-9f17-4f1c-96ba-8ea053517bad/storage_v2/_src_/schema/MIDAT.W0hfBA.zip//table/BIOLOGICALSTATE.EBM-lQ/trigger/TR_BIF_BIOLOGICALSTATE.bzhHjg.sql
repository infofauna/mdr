create trigger TR_BIF_BIOLOGICALSTATE
    before insert
    on BIOLOGICALSTATE
    for each row
DECLARE
BEGIN
   IF :new.bls_id IS NULL
   THEN
      :new.bls_id := seq_BIOLOGICALSTATE.NEXTVAL;
   END IF;

   :new.bls_credate := SYSDATE;
   :new.bls_creuser := USER;
END tr_bif_BIOLOGICALSTATE;

/

