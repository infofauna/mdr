create PACKAGE       pkg_excel
AS
   /******************************************************************************
      NAME:       PKG_EXCEL
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.10.2013      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_buildsheetlist (
      p_blob         IN     BLOB,
      p_sheetlist       OUT pkg_worksheetlist.t_cursor,
      p_sheetcount      OUT NUMBER);


   PROCEDURE p_testbuildlistsheet (
      p_iph_id IN importprotocolheader.iph_id%TYPE);
END pkg_excel;
/

