create trigger TR_BIF_PROCESSINGSTEPLOG
    before insert
    on PROCESSINGSTEPLOG
    for each row
DECLARE
BEGIN
   IF :new.psl_id IS NULL
   THEN
      :new.psl_id := seq_processingsteplog.NEXTVAL;
   END IF;

   :new.psl_credate := SYSDATE;
   :new.psl_creuser := USER;
END tr_bif_PROCESSINGSTEPLOG;

/

