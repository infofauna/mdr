create PACKAGE pkg_debug
AS
   /******************************************************************************
      NAME:       PKG_DEBUG
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.07.2013   F.Burri          1. Created this package.
   ******************************************************************************/

   cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2013';

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_truncate;

   FUNCTION f_getrecord (p_dbg_id IN debug.dbg_id%TYPE)
      RETURN debug%ROWTYPE;

   PROCEDURE p_tr_bif_debug (p_newrec IN OUT debug%ROWTYPE);

   PROCEDURE p_tr_buf_debug (p_oldrec   IN     debug%ROWTYPE,
                             p_newrec   IN OUT debug%ROWTYPE);

   PROCEDURE p_write (p_module   IN debug.dbg_module%TYPE,
                      p_text     IN debug.dbg_text%TYPE);

   PROCEDURE p_setdebugmode (p_flag BOOLEAN);
END pkg_debug;
/

