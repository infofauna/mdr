create PACKAGE BODY       pkg_migr_ibch2019_ptl
AS
    /******************************************************************************
       NAME:       PKG_MIGR_IBCH2019
       PURPOSE:    Modification dans la table PROTOCOLMAPPINGLABO

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       15.05.2020  F.Burri           1. Created this package body.
    ******************************************************************************/
    TYPE r_excluderow IS RECORD
    (
        l_row       NUMBER,
        l_column    VARCHAR2 (10)
    );

    TYPE t_excluderow IS TABLE OF r_excluderow;

    gbl_excluderow        t_excluderow := t_excluderow ();

    TYPE r_taxonindicateur IS RECORD
    (
        l_nombremin    NUMBER,
        l_valeur_gi    NUMBER
    );

    TYPE t_taxonindicateur IS TABLE OF r_taxonindicateur
        INDEX BY protocolmappinglabo.ptl_taxacscf%TYPE;

    gbl_taxonindicateur   t_taxonindicateur;

    TYPE t_spear IS TABLE OF PLS_INTEGER
        INDEX BY protocolmappinglabo.ptl_taxa%TYPE;

    gbl_spear             t_spear;

    TYPE r_taxonreplace IS RECORD
    (
        l_taxon_2019    protocolmappinglabo.ptl_taxa%TYPE,
        l_taxon_cscf    protocolmappinglabo.ptl_taxacscf%TYPE,
        l_syv_id        protocolmappinglabo.ptl_syv_id%TYPE,
        l_syv_id2       protocolmappinglabo.ptl_syv_id2%TYPE
    );

    TYPE t_taxonreplace IS TABLE OF r_taxonreplace
        INDEX BY protocolmappinglabo.ptl_taxa%TYPE;

    gbl_taxonreplace      t_taxonreplace;

    TYPE r_newtaxon IS RECORD
    (
        l_row             protocolmappinglabo.ptl_cellrowvalue%TYPE,
        l_column          protocolmappinglabo.ptl_cellcolumnvalue%TYPE,
        l_syv_id          protocolmappinglabo.ptl_syv_id%TYPE,
        l_taxacscf        protocolmappinglabo.ptl_taxacscf%TYPE,
        l_crf_id_level    protocolmappinglabo.ptl_crf_id_level%TYPE,
        l_taxaparent      protocolmappinglabo.ptl_taxacscf%TYPE,
        l_ptl_id          protocolmappinglabo.ptl_id%TYPE
    );

    TYPE t_listnewtaxon IS TABLE OF r_newtaxon
        INDEX BY systdesignation.syd_designation%TYPE;

    gbl_listnewtaxon      t_listnewtaxon;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_findtaxa (p_taxon    IN protocolmappinglabo.ptl_taxa%TYPE,
                         p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
        RETURN protocolmappinglabo%ROWTYPE
    /*-----------------------------------------------------------*/
    IS
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recprotocolmappinglabo
          FROM protocolmappinglabo
         WHERE     ptl_ptv_id = p_ptv_id
               AND TRIM (UPPER (ptl_taxa)) = TRIM (UPPER (p_taxon));

        RETURN l_recprotocolmappinglabo;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_updatetaxonname (
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
        l_key                      protocolmappinglabo.ptl_taxa%TYPE;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_taxonreplace             r_taxonreplace;
    BEGIN
        l_key := gbl_taxonreplace.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            DBMS_OUTPUT.put_line ('L_KEY=' || l_key);
            l_taxonreplace := gbl_taxonreplace (l_key);
            l_recprotocolmappinglabo :=
                f_findtaxa (
                    l_taxonreplace.l_taxon_2019,
                    p_ptv_id);

            IF l_recprotocolmappinglabo.ptl_id IS NULL
            THEN
                DBMS_OUTPUT.put_line (
                       'l_taxonreplace.l_taxon_2019='
                    || l_taxonreplace.l_taxon_2019
                    || ' not found');


                l_recprotocolmappinglabo :=
                    f_findtaxa (l_key, p_ptv_id);

                IF l_recprotocolmappinglabo.ptl_id IS NULL
                THEN
                    raise_application_error (
                        -20000,
                        'Taxon: ' || l_key || ' non trouvé',
                        TRUE);
                END IF;

                UPDATE protocolmappinglabo
                   SET ptl_taxa = l_taxonreplace.l_taxon_2019,
                       ptl_taxacscf = l_taxonreplace.l_taxon_cscf,
                       ptl_syv_id = l_taxonreplace.l_syv_id,
                       ptl_syv_id2 = l_taxonreplace.l_syv_id2
                 WHERE ptl_id = l_recprotocolmappinglabo.ptl_id;

                DBMS_OUTPUT.put_line ('Updated');
            ELSE
                DBMS_OUTPUT.put_line (
                       'l_taxonreplace.l_taxon_2019='
                    || l_taxonreplace.l_taxon_2019
                    || ' found');
            END IF;

            l_key := gbl_taxonreplace.NEXT (l_key);
        END LOOP;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_updatespear (p_ptv_id IN protocolmappinglabo.ptl_ptv_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
        l_key                      protocolmappinglabo.ptl_taxa%TYPE;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        l_key := gbl_spear.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            DBMS_OUTPUT.put_line ('L_KEY=' || l_key);

            l_recprotocolmappinglabo :=
                f_findtaxa (l_key, p_ptv_id);

            IF l_recprotocolmappinglabo.ptl_id IS NULL
            THEN
                raise_application_error (-20000,
                                         'Taxon ' || l_key || ' non trouvé',
                                         TRUE);
            END IF;

            UPDATE protocolmappinglabo
               SET ptl_spearindexfactor = gbl_spear (l_key)
             WHERE ptl_id = l_recprotocolmappinglabo.ptl_id;

            l_key := gbl_spear.NEXT (l_key);
        END LOOP;
    END;



    /*------------------------------------------------------------------*/
    PROCEDURE p_buildrecordtaxadata (
        p_taxa         IN     protocolmappinglabo.ptl_taxa%TYPE,
        p_row          IN     protocolmappinglabo.ptl_cellrowvalue%TYPE,
        p_column       IN     protocolmappinglabo.ptl_cellcolumnvalue%TYPE,
        p_syv_id       IN     protocolmappinglabo.ptl_syv_id%TYPE,
        p_taxaparent   IN     protocolmappinglabo.ptl_taxa%TYPE,
        p_newtaxon        OUT r_newtaxon)
    /*-----------------------------------------------------------------*/
    IS
        l_recsystdesignation   systdesignation%ROWTYPE;
        l_recsystvalue         systvalue%ROWTYPE;
    BEGIN
        p_newtaxon.l_taxacscf := p_taxa;
        p_newtaxon.l_row := p_row;
        p_newtaxon.l_column := p_column;
        p_newtaxon.l_taxaparent := p_taxaparent;
        l_recsystdesignation :=
            pkg_systdesignation.f_getrecdesignationbylancode (
                p_syv_id,
                pkg_language.cst_lan_cde_latin);

        IF    l_recsystdesignation.syd_id IS NULL
           OR l_recsystdesignation.syd_designation != p_taxa
        THEN
            pkg_debug.p_write (
                'pkg_migr_ibch2019.P_BUILDrecordtaxadata',
                   'ERROR*** Taxon :'
                || p_taxa
                || ' non trouvé dans le thésaurus');
            p_newtaxon.l_syv_id := NULL;
        ELSE
            p_newtaxon.l_syv_id := l_recsystdesignation.syd_syv_id;
            l_recsystvalue := pkg_systvalue.f_getrecord (p_newtaxon.l_syv_id);
            p_newtaxon.l_crf_id_level := l_recsystvalue.syv_crf_id;
            pkg_debug.p_write (
                'pkg_migr_ibch2019.P_BUILDrecordtaxadata',
                'INFO***Taxon :' || p_taxa || ' trouvé dans le thésaurus');
        END IF;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_updateongi (
        p_taxa     IN protocolmappinglabo.ptl_taxa%TYPE,
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE,
        p_gi       IN protocolmappinglabo.ptl_ibchfaunagroup_gi%TYPE)
    /*-----------------------------------------------------------------*/
    IS
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecordbytaxa (p_ptv_id, p_taxa);

        IF l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            raise_application_error (
                -20000,
                'Erreur*** TAXA: ' || p_taxa || ' non trouvé',
                TRUE);
        END IF;

        UPDATE protocolmappinglabo
           SET ptl_ibchfaunagroup_gi = p_gi
         WHERE ptl_id = l_recprotocolmappinglabo.ptl_id;
    END;



    /*-----------------------------------------------------------------*/
    PROCEDURE p_changegi (p_ptv_id IN protocolversion.ptv_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        p_updateongi ('Taeniopterygidae', p_ptv_id, 7);

        p_updateongi ('Leuctridae', p_ptv_id, 6);
        p_updateongi ('Leptophlebiidae', p_ptv_id, 6);
        p_updateongi ('Odontoceridae', p_ptv_id, 7);
        p_updateongi ('Nemouridae', p_ptv_id, 5);
        p_updateongi ('Beraeidae', p_ptv_id, 8);
    END;



    /*-----------------------------------------------------------------*/
    PROCEDURE p_initnewtaxon
    /*-----------------------------------------------------------------*/
    IS
        l_newtaxon             r_newtaxon;
        l_recsystdesignation   systdesignation%ROWTYPE;
        l_taxa                 systdesignation.syd_designation%TYPE;
        l_taxacscf             systdesignation.syd_designation%TYPE;
        l_ok                   BOOLEAN := TRUE;
    BEGIN
        gbl_listnewtaxon.delete;
        l_taxacscf := 'sowerbii';
        l_taxa := 'C. sowerbii*';
        p_buildrecordtaxadata (l_taxacscf,
                               10,
                               'M',
                               1003418,
                               'CNIDARIA',
                               l_newtaxon);

        IF l_newtaxon.l_syv_id IS NULL
        THEN
            l_ok := FALSE;
        END IF;

        gbl_listnewtaxon (l_taxa) := l_newtaxon;


        l_taxacscf := 'tigrina';
        l_taxa := 'D. tigrina*';
        p_buildrecordtaxadata (l_taxacscf,
                               15,
                               'M',
                               1003501,                          -- Dugesiidae
                               'Dugesiidae',
                               l_newtaxon);

        IF l_newtaxon.l_syv_id IS NULL
        THEN
            l_ok := FALSE;
        END IF;

        gbl_listnewtaxon (l_taxa) := l_newtaxon;


        l_taxacscf := 'Polychaeta';
        l_taxa := 'Polychaeta*';
        p_buildrecordtaxadata (l_taxacscf,
                               27,
                               'M',
                               30007,
                               'ANNELIDA',
                               l_newtaxon);

        IF l_newtaxon.l_syv_id IS NULL
        THEN
            l_ok := FALSE;
        END IF;

        gbl_listnewtaxon (l_taxa) := l_newtaxon;


        l_taxacscf := 'antipodarum';
        l_taxa := 'P. antipodarum*';
        p_buildrecordtaxadata (l_taxacscf,
                               34,
                               'M',
                               1003560,
                               'Hydrobiidae',
                               l_newtaxon);

        IF l_newtaxon.l_syv_id IS NULL
        THEN
            l_ok := FALSE;
        END IF;

        gbl_listnewtaxon (l_taxa) := l_newtaxon;

        l_taxacscf := 'acuta';
        l_taxa := 'H. acuta*';
        p_buildrecordtaxadata (l_taxacscf,
                               37,
                               'M',
                               1003636,
                               'Physidae',
                               l_newtaxon);

        IF l_newtaxon.l_syv_id IS NULL
        THEN
            l_ok := FALSE;
        END IF;

        gbl_listnewtaxon (l_taxa) := l_newtaxon;


        l_taxacscf := 'Crangonyctidae';
        l_taxa := 'Crangonyctidae*';
        p_buildrecordtaxadata (l_taxacscf,
                               52,
                               'M',
                               111405,
                               'Amphipoda',
                               l_newtaxon);

        IF l_newtaxon.l_syv_id IS NULL
        THEN
            l_ok := FALSE;
        END IF;

        gbl_listnewtaxon (l_taxa) := l_newtaxon;


        l_taxacscf := 'Dikerogammarus';
        l_taxa := 'Dikerogammarus sp.*';
        p_buildrecordtaxadata (l_taxacscf,
                               54,
                               'M',
                               201871,
                               'Gammaridae',
                               l_newtaxon);

        IF l_newtaxon.l_syv_id IS NULL
        THEN
            l_ok := FALSE;
        END IF;

        gbl_listnewtaxon (l_taxa) := l_newtaxon;

        IF NOT l_ok
        THEN
            raise_application_error (-20000, 'New taxon not found', TRUE);
        END IF;
    END;



    /*----------------------------------------------------------------*/
    FUNCTION f_checksyv_id (
        p_taxa     IN protocolmappinglabo.ptl_taxa%TYPE,
        p_syv_id   IN protocolmappinglabo.ptl_syv_id%TYPE)
        RETURN BOOLEAN
    /*----------------------------------------------------------------*/
    IS
        l_recsystdesignation   systdesignation%ROWTYPE;
        l_indice               PLS_INTEGER;
    BEGIN
        l_recsystdesignation :=
            pkg_systdesignation.f_getrecdesignationbylancode (
                p_syv_id,
                pkg_language.cst_lan_cde_latin);

        IF l_recsystdesignation.syd_id IS NULL
        THEN
            pkg_debug.p_write (
                'pkg_migr_ibch2019_ptl.F_CHECKSYV_ID',
                   'ERROR*** SYV_ID du taxa non trouvé p_syv_id='
                || p_syv_id
                || ' p_taxa='
                || p_taxa);

            RETURN FALSE;
        ELSE
            pkg_debug.p_write (
                'pkg_migr_ibch2019_ptl.F_CHECKSYV_ID',
                   'INFO*** syv_id du taxa trouvé p_syv_id='
                || p_syv_id
                || ' p_taxa='
                || p_taxa);
        END IF;

        IF UPPER (l_recsystdesignation.syd_designation) != UPPER (p_taxa)
        THEN
            pkg_debug.p_write (
                'pkg_migr_ibch2019_ptl.F_CHECKSYV_ID',
                   'ERROR*** Nom du taxa non concordant p_syv_id='
                || p_syv_id
                || ' l_recsystdesignation.syd_designation='
                || l_recsystdesignation.syd_designation
                || ' p_taxa='
                || p_taxa);

            RETURN FALSE;
        ELSE
            pkg_debug.p_write (
                'pkg_migr_ibch2019_ptl.F_CHECKSYV_ID',
                   'INFO*** Nom du taxa concordant p_syv_id='
                || p_syv_id
                || ' p_taxa='
                || p_taxa);
        END IF;

        RETURN TRUE;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_checkrecordlabo (
        p_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE)
        RETURN BOOLEAN
    /*----------------------------------------------------------------*/
    IS
        l_recsystdesignation   systdesignation%ROWTYPE;
        l_listofvalue          pkg_stringutil.t_listofvalue;
        l_indice               PLS_INTEGER;
        l_ok                   BOOLEAN;
    BEGIN
        l_listofvalue :=
            pkg_stringutil.f_splitstring (
                NVL (p_recprotocolmappinglabo.ptl_taxacscf,
                     p_recprotocolmappinglabo.ptl_taxa),
                '/');
        l_indice := l_listofvalue.FIRST;
        l_ok :=
            f_checksyv_id (l_listofvalue (l_indice),
                           p_recprotocolmappinglabo.ptl_syv_id);

        IF NOT l_ok
        THEN
            RETURN l_ok;
        END IF;


        IF l_listofvalue.COUNT = 2
        THEN
            l_indice := l_listofvalue.NEXT (l_indice);
            l_ok :=
                f_checksyv_id (l_listofvalue (l_indice),
                               p_recprotocolmappinglabo.ptl_syv_id2);
        END IF;


        RETURN l_ok;
    END;

    /*--------------------------------------------------------------------*/
    PROCEDURE p_checkalllabo (p_ptv_id   IN     protocolversion.ptv_id%TYPE,
                              p_ok          OUT BOOLEAN)
    /*--------------------------------------------------------------------*/
    IS
        CURSOR l_listmappinglabo IS
            SELECT *
              FROM protocolmappinglabo
             WHERE ptl_ptv_id = p_ptv_id;

        l_reclistmappinglabo   l_listmappinglabo%ROWTYPE;
        l_ok                   BOOLEAN;
    BEGIN
        p_ok := TRUE;

        OPEN l_listmappinglabo;

        LOOP
            FETCH l_listmappinglabo INTO l_reclistmappinglabo;

            EXIT WHEN l_listmappinglabo%NOTFOUND;
            pkg_debug.p_write (
                'pkg_migr_ibch2019_ptl.p_checkalllabo',
                   ' INFO*** Traitement de l''entrée (taxon cscf): '
                || l_reclistmappinglabo.ptl_taxa);

            l_ok := f_checkrecordlabo (l_reclistmappinglabo);

            IF NOT l_ok
            THEN
                p_ok := l_ok;
            END IF;
        END LOOP;

        CLOSE l_listmappinglabo;
    END;


    /*----------------------------------------------------------------*/
    PROCEDURE p_completaxonreplace (
        p_ptv_id_base   IN protocolmappinglabo.ptl_ptv_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
        l_key                      protocolmappinglabo.ptl_taxa%TYPE;
        l_taxonreplace             r_taxonreplace;
        l_listofvalue              pkg_stringutil.t_listofvalue;
        l_indice                   PLS_INTEGER;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_reclanguage              language%ROWTYPE;
    BEGIN
        l_reclanguage :=
            pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);
        l_key := gbl_taxonreplace.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            l_taxonreplace := gbl_taxonreplace (l_key);
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecordbytaxa (p_ptv_id_base,
                                                           l_key);

            IF l_recprotocolmappinglabo.ptl_id IS NULL
            THEN
                raise_application_error (-20000,
                                         'Taxa=' || l_key || ' non trouvé',
                                         TRUE);
            END IF;

            l_taxonreplace.l_syv_id := l_recprotocolmappinglabo.ptl_syv_id;
            l_taxonreplace.l_syv_id2 := l_recprotocolmappinglabo.ptl_syv_id2;
            pkg_debug.p_write (
                'pkg_migr_ibch2019_ptl.p_completetaxonreplace',
                   ' INFO*** Traitement de l''entrée (taxon cscf): '
                || l_taxonreplace.l_taxon_cscf
                || ' Taxon: '
                || l_taxonreplace.l_taxon_cscf
                || ' syv_id='
                || l_taxonreplace.l_syv_id
                || ' syv_id2='
                || l_taxonreplace.l_syv_id2);

            gbl_taxonreplace (l_key) := l_taxonreplace;
            l_key := gbl_taxonreplace.NEXT (l_key);
        END LOOP;

        NULL;
    END;


    /*----------------------------------------------------------------*/

    PROCEDURE p_completetaxonreplace_old
    /*---------------------------------------------------------------*/
    IS
        l_key                  protocolmappinglabo.ptl_taxa%TYPE;
        l_taxonreplace         r_taxonreplace;
        l_listofvalue          pkg_stringutil.t_listofvalue;
        l_indice               PLS_INTEGER;
        l_recsystdesignation   systdesignation%ROWTYPE;
        l_reclanguage          language%ROWTYPE;
        l_abort                BOOLEAN := FALSE;
    BEGIN
        l_reclanguage :=
            pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);
        l_key := gbl_taxonreplace.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            l_taxonreplace := gbl_taxonreplace (l_key);
            pkg_debug.p_write (
                'pkg_migr_ibch2019_ptl.p_completetaxonreplace',
                   ' INFO*** Traitement de l''entrée (taxon cscf): '
                || l_taxonreplace.l_taxon_cscf);
            l_listofvalue :=
                pkg_stringutil.f_splitstring (l_taxonreplace.l_taxon_cscf,
                                              '/');


            IF l_listofvalue.COUNT = 2
            THEN
                l_indice := l_listofvalue.FIRST;
                l_recsystdesignation :=
                    pkg_systdesignation.f_getrecordbydesignationcode (
                        l_listofvalue (l_indice),
                        pkg_language.cst_lan_cde_latin);

                IF l_recsystdesignation.syd_id IS NULL
                THEN
                    pkg_debug.p_write (
                        'pkg_migr_ibch2019_ptl.p_completetaxonreplace',
                           ' ERROR*** Entrée : '
                        || l_listofvalue (l_indice)
                        || ' non trouvée');
                    l_abort := TRUE;
                ELSE
                    l_taxonreplace.l_syv_id :=
                        l_recsystdesignation.syd_syv_id;
                    pkg_debug.p_write (
                        'pkg_migr_ibch2019_ptl.p_completetaxonreplace',
                           ' INFO*** Désignation: '
                        || l_listofvalue (l_indice)
                        || '  '
                        || pkg_systdesignation.f_returnpathdesignation (
                               l_taxonreplace.l_syv_id,
                               l_reclanguage.lan_id,
                               '->'));
                END IF;

                l_indice := l_listofvalue.NEXT (l_indice);
                l_recsystdesignation :=
                    pkg_systdesignation.f_getrecordbydesignationcode (
                        l_listofvalue (l_indice),
                        pkg_language.cst_lan_cde_latin);

                IF l_recsystdesignation.syd_id IS NULL
                THEN
                    pkg_debug.p_write (
                        'pkg_migr_ibch2019_ptl.p_completetaxonreplace',
                           ' ERROR*** Entrée : '
                        || l_listofvalue (l_indice)
                        || ' non trouvée');
                    l_abort := TRUE;
                ELSE
                    l_taxonreplace.l_syv_id2 :=
                        l_recsystdesignation.syd_syv_id;
                    pkg_debug.p_write (
                        'pkg_migr_ibch2019_ptl.p_completetaxonreplace',
                           ' INFO*** Désignation 2: '
                        || l_listofvalue (l_indice)
                        || '  '
                        || pkg_systdesignation.f_returnpathdesignation (
                               l_taxonreplace.l_syv_id2,
                               l_reclanguage.lan_id,
                               '->'));
                END IF;
            ELSE
                l_indice := l_listofvalue.FIRST;
                l_recsystdesignation :=
                    pkg_systdesignation.f_getrecordbydesignationcode (
                        l_listofvalue (l_indice),
                        pkg_language.cst_lan_cde_latin);

                IF l_recsystdesignation.syd_id IS NULL
                THEN
                    pkg_debug.p_write (
                        'pkg_migr_ibch2019_ptl.p_completetaxonreplace',
                           ' ERROR*** Entrée : '
                        || l_listofvalue (l_indice)
                        || ' non trouvée');
                    l_abort := TRUE;
                ELSE
                    l_taxonreplace.l_syv_id :=
                        l_recsystdesignation.syd_syv_id;
                    pkg_debug.p_write (
                        'pkg_migr_ibch2019_ptl.p_completetaxonreplace',
                           ' INFO*** Désignation : '
                        || l_listofvalue (l_indice)
                        || '  '
                        || pkg_systdesignation.f_returnpathdesignation (
                               l_taxonreplace.l_syv_id,
                               l_reclanguage.lan_id,
                               '->'));
                END IF;
            END IF;

            gbl_taxonreplace (l_key) := l_taxonreplace;
            l_key := gbl_taxonreplace.NEXT (l_key);
        END LOOP;

        IF l_abort
        THEN
            raise_application_error (
                -20000,
                ' FATAL **** Traitement interrompu par l''absence d''un taxon',
                TRUE);
        END IF;
    END;



    /*----------------------------------------------------------------*/

    PROCEDURE p_returnibchparameter (
        p_taxa        IN     protocolmappinglabo.ptl_taxa%TYPE,
        p_nombremin      OUT protocolmappinglabo.ptl_ibchindividumin%TYPE,
        p_valeur_gi      OUT protocolmappinglabo.ptl_ibchfaunagroup_gi%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        IF gbl_taxonindicateur.EXISTS (p_taxa)
        THEN
            p_nombremin := gbl_taxonindicateur (p_taxa).l_nombremin;
            p_valeur_gi := gbl_taxonindicateur (p_taxa).l_valeur_gi;
        ELSE
            p_nombremin := NULL;
            p_valeur_gi := NULL;
        END IF;
    END;

    /*----------------------------------------------------------------*/

    FUNCTION f_getspearvalue (p_taxa IN protocolmappinglabo.ptl_taxa%TYPE)
        RETURN protocolmappinglabo.ptl_spearindexfactor%TYPE
    IS
    BEGIN
        IF gbl_spear.EXISTS (p_taxa)
        THEN
            RETURN gbl_spear (p_taxa);
        ELSE
            RETURN NULL;
        END IF;
    END;

    /*----------------------------------------------------------------*/

    PROCEDURE p_returntaxonparameter (
        p_taxa         IN     protocolmappinglabo.ptl_taxa%TYPE,
        p_taxon_2019      OUT protocolmappinglabo.ptl_taxa%TYPE,
        p_taxon_cscf      OUT protocolmappinglabo.ptl_taxacscf%TYPE,
        p_syv_id          OUT protocolmappinglabo.ptl_syv_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        IF gbl_taxonreplace.EXISTS (p_taxa)
        THEN
            p_taxon_2019 := gbl_taxonreplace (p_taxa).l_taxon_2019;
            p_taxon_cscf := gbl_taxonreplace (p_taxa).l_taxon_cscf;
        ELSE
            p_taxon_2019 := NULL;
            p_taxon_cscf := NULL;
        END IF;
    END;

    /*----------------------------------------------------------------*/

    FUNCTION f_findexcluderow (p_row IN NUMBER, p_column IN VARCHAR2)
        RETURN BOOLEAN
    /*----------------------------------------------------------------*/
    IS
        l_excluderow   r_excluderow;
        l_indice       PLS_INTEGER;
        l_found        BOOLEAN := FALSE;
    BEGIN
        l_indice := gbl_excluderow.FIRST;

        WHILE NOT l_indice IS NULL AND NOT l_found
        LOOP
            l_excluderow := gbl_excluderow (l_indice);

            IF     l_excluderow.l_row = p_row
               AND l_excluderow.l_column = p_column
            THEN
                l_found := TRUE;
            END IF;

            l_indice := gbl_excluderow.NEXT (l_indice);
        END LOOP;

        RETURN l_found;
    END;

    /*----------------------------------------------------------------*/

    PROCEDURE p_clearexcluderow
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        gbl_excluderow.delete;
    END;


    /*----------------------------------------------------------------*/

    PROCEDURE p_addexcluderow (p_row IN NUMBER, p_column IN VARCHAR2) /*----------------------------------------------------------------*/
    IS
        l_excluderow   r_excluderow;
    BEGIN
        l_excluderow.l_row := p_row;
        l_excluderow.l_column := p_column;
        gbl_excluderow.EXTEND;
        gbl_excluderow (gbl_excluderow.LAST) := l_excluderow;
    END;

    /*-----------------------------------------------------------------*/

    PROCEDURE p_deleteversion (p_ptv_id IN protocolversion.ptv_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM protocolmappinglabo
              WHERE ptl_ptv_id = p_ptv_id;

        pkg_debug.p_write (
            'pkg_migr_ibch2019_ptl.P_DELETEVERSION',
               'INFO*** Données sur le contenu de détail de la version ptv_id='
            || p_ptv_id
            || ' supprimées. Nombre d''enregitrements effacés: '
            || SQL%ROWCOUNT);
    END;


    /*------------------------------------------------------------------*/
    PROCEDURE p_appendnewtaxon (p_ptv_id_new IN protocolversion.ptv_id%TYPE)
    /*------------------------------------------------------------------*/
    IS
        l_newtaxon   r_newtaxon;
        l_key        protocolmappinglabo.ptl_taxa%TYPE;
        l_ptl_id     protocolmappinglabo.ptl_id%TYPE;
    BEGIN
        l_key := gbl_listnewtaxon.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            l_newtaxon := gbl_listnewtaxon (l_key);
            pkg_protocolmappinglabo.p_write (NULL,              -- ptl_ptl_id,
                                             p_ptv_id_new,
                                             l_newtaxon.l_syv_id,
                                             l_newtaxon.l_row,
                                             l_newtaxon.l_column,
                                             l_key,                    -- Taxa
                                             l_newtaxon.l_taxacscf,
                                             NULL, -- l_newtaxon.l_crf_id_level,
                                             NULL,   -- ptl_ibchfaunagroup_gi,
                                             NULL,     -- ptl_ibchindividumin,
                                             NULL,    -- ptl_spearindexfactor,
                                             NULL,           -- ptl_isnotnull,
                                             NULL,      -- ptl_isnotnullgroup,
                                             l_ptl_id);

            l_newtaxon.l_ptl_id := l_ptl_id;
            gbl_listnewtaxon (l_key) := l_newtaxon;
            l_key := gbl_listnewtaxon.NEXT (l_key);
        END LOOP;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_updatenewtaxonptl_ptl_id (
        p_ptv_id_new   IN protocolversion.ptv_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
        l_newtaxon                 r_newtaxon;
        l_key                      protocolmappinglabo.ptl_taxa%TYPE;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        l_key := gbl_listnewtaxon.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            l_newtaxon := gbl_listnewtaxon (l_key);

            IF NOT l_newtaxon.l_taxaparent IS NULL
            THEN
                l_recprotocolmappinglabo :=
                    pkg_protocolmappinglabo.f_getrecordbytaxa (
                        p_ptv_id_new,
                        l_newtaxon.l_taxaparent);

                IF l_recprotocolmappinglabo.ptl_id IS NULL
                THEN
                    raise_application_error (
                        -20000,
                           'FATAL*** Le taxon :'
                        || l_newtaxon.l_taxaparent
                        || ' n''existe pas',
                        TRUE);
                END IF;

                UPDATE protocolmappinglabo
                   SET ptl_ptl_id = l_recprotocolmappinglabo.ptl_id
                 WHERE     ptl_id = l_newtaxon.l_ptl_id
                       AND ptl_ptv_id = p_ptv_id_new;
            END IF;

            l_key := gbl_listnewtaxon.NEXT (l_key);
        END LOOP;
    END;



    /*-----------------------------------------------------------------*/
    PROCEDURE p_copyversion (p_ptv_id       IN protocolversion.ptv_id%TYPE,
                             p_ptv_id_new   IN protocolversion.ptv_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
        CURSOR l_protocolmappinglabo IS
            SELECT *
              FROM protocolmappinglabo
             WHERE ptl_ptv_id = p_ptv_id;

        l_recprotocolmappinglabo   l_protocolmappinglabo%ROWTYPE;
        l_ptl_id                   protocolmappinglabo.ptl_id%TYPE;
        l_recprotocolversion       protocolversion%ROWTYPE;
        l_group_gi                 protocolmappinglabo.ptl_ibchfaunagroup_gi%TYPE;
        l_individumin              protocolmappinglabo.ptl_ibchindividumin%TYPE;
        l_spearindex               protocolmappinglabo.ptl_spearindexfactor%TYPE;
    BEGIN
        l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);

        OPEN l_protocolmappinglabo;

        LOOP
            FETCH l_protocolmappinglabo INTO l_recprotocolmappinglabo;

            EXIT WHEN l_protocolmappinglabo%NOTFOUND;

            IF NOT f_findexcluderow (
                       l_recprotocolmappinglabo.ptl_cellrowvalue,
                       l_recprotocolmappinglabo.ptl_cellcolumnvalue)
            THEN
                pkg_migr_ibch2019_ptl.p_returnibchparameter (
                    l_recprotocolmappinglabo.ptl_taxa,
                    l_individumin,
                    l_group_gi);
                l_spearindex :=
                    pkg_migr_ibch2019_ptl.f_getspearvalue (
                        l_recprotocolmappinglabo.ptl_taxa);
                pkg_protocolmappinglabo.p_write (
                    l_recprotocolmappinglabo.ptl_ptl_id,
                    p_ptv_id_new,
                    l_recprotocolmappinglabo.ptl_syv_id,
                    l_recprotocolmappinglabo.ptl_cellrowvalue,
                    l_recprotocolmappinglabo.ptl_cellcolumnvalue,
                    l_recprotocolmappinglabo.ptl_taxa,
                    l_recprotocolmappinglabo.ptl_taxacscf,
                    NULL,         --l_recprotocolmappinglabo.ptl_crf_id_level,
                    l_group_gi, -- l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi,
                    l_individumin, -- l_recprotocolmappinglabo.ptl_ibchindividumin,
                    l_spearindex, --- l_recprotocolmappinglabo.ptl_spearindexfactor,
                    l_recprotocolmappinglabo.ptl_isnotnull,
                    l_recprotocolmappinglabo.ptl_isnotnullgroup,
                    l_ptl_id);

                UPDATE protocolmappinglabo
                   SET ptl_syv_id2 = l_recprotocolmappinglabo.ptl_syv_id2
                 WHERE ptl_id = l_ptl_id;

                pkg_debug.p_write (
                    'pkg_migr_ibch2019_ptl.p_copyversion',
                       'Cellule : '
                    || l_recprotocolmappinglabo.ptl_cellcolumnvalue
                    || ':'
                    || TRIM (
                           TO_CHAR (
                               l_recprotocolmappinglabo.ptl_cellcolumnvalue))
                    || ' copié...');
            ELSE
                pkg_debug.p_write (
                    'pkg_migr_ibch2019_ptl.p_copyversion',
                       'Cellule : '
                    || l_recprotocolmappinglabo.ptl_cellcolumnvalue
                    || ':'
                    || TRIM (
                           TO_CHAR (
                               l_recprotocolmappinglabo.ptl_cellcolumnvalue))
                    || ' non copié (est dans la liste des exclusions)');
            END IF;
        END LOOP;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_updateptl_ptl_id (
        p_ptv_id       IN protocolversion.ptv_id%TYPE,
        p_ptv_id_new   IN protocolversion.ptv_id%TYPE)
    /*-------------------------------------------------------------*/
    IS
        CURSOR l_cursor IS
            SELECT *
              FROM protocolmappinglabo
             WHERE ptl_ptv_id = p_ptv_id_new
            FOR UPDATE;

        l_reccursor                      l_cursor%ROWTYPE;
        l_recprotocolmappinglabo         protocolmappinglabo%ROWTYPE;
        l_recprotocolmappinglaboparent   protocolmappinglabo%ROWTYPE;
        l_recprotocolmappinglanew        protocolmappinglabo%ROWTYPE;
    BEGIN
        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND;
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecordfromsyv_id (
                    l_reccursor.ptl_syv_id,
                    p_ptv_id);

            IF NOT l_recprotocolmappinglabo.ptl_id IS NULL
            THEN
                IF NOT l_recprotocolmappinglabo.ptl_ptl_id IS NULL
                THEN
                    l_recprotocolmappinglaboparent :=
                        pkg_protocolmappinglabo.f_getrecord (
                            l_recprotocolmappinglabo.ptl_ptl_id);

                    -- Le parent a le SYV_ID attendu
                    IF l_recprotocolmappinglaboparent.ptl_id IS NULL
                    THEN
                        raise_application_error (
                            -20000,
                               'l_recprotocolmappinglabo.ptl_ptl_id '
                            || l_recprotocolmappinglabo.ptl_ptl_id
                            || ' non trouvé',
                            TRUE);
                    END IF;

                    l_recprotocolmappinglanew :=
                        pkg_protocolmappinglabo.f_getrecordfromsyv_id (
                            l_recprotocolmappinglaboparent.ptl_syv_id,
                            p_ptv_id_new);

                    IF l_recprotocolmappinglaboparent.ptl_id IS NULL
                    THEN
                        raise_application_error (
                            -20000,
                               'l_recprotocolmappinglaboparent.ptl_syv_id '
                            || l_recprotocolmappinglaboparent.ptl_syv_id
                            || ' non trouvé',
                            TRUE);
                    END IF;

                    UPDATE protocolmappinglabo
                       SET ptl_ptl_id = l_recprotocolmappinglanew.ptl_id
                     WHERE CURRENT OF l_cursor;
                END IF;
            END IF;
        END LOOP;
    END;

    /*-------------------------------------------------------------*/

    PROCEDURE p_checkibchentry (
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
    /*-------------------------------------------------------------*/
    IS
        l_key                      protocolmappinglabo.ptl_taxa%TYPE;
        l_rectaxonindicateur       r_taxonindicateur;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_count                    NUMBER := 0;
        l_countfound               NUMBER := 0;
    BEGIN
        l_key := gbl_taxonindicateur.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            l_count := l_count + 1;
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecordbytaxa (p_ptv_id, l_key);

            IF l_recprotocolmappinglabo.ptl_id IS NULL
            THEN
                DBMS_OUTPUT.put_line (
                    TO_CHAR (l_count) || ' Entry ' || l_key || ' not found');
            ELSE
                l_countfound := l_countfound + 1;
                DBMS_OUTPUT.put_line (
                    TO_CHAR (l_count) || ' Entry ' || l_key || ' found');
            END IF;

            l_key := gbl_taxonindicateur.NEXT (l_key);
        END LOOP;

        DBMS_OUTPUT.put_line ('l_countfound=' || TO_CHAR (l_countfound));
    END;

    /*-------------------------------------------------------------*/

    PROCEDURE p_checkspearentry (
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
    /*-------------------------------------------------------------*/
    IS
        l_key                      protocolmappinglabo.ptl_taxa%TYPE;

        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_count                    NUMBER := 0;
        l_countfound               NUMBER := 0;
    BEGIN
        l_key := gbl_spear.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            l_count := l_count + 1;
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecordbytaxa (p_ptv_id, l_key);

            IF l_recprotocolmappinglabo.ptl_id IS NULL
            THEN
                DBMS_OUTPUT.put_line (
                    TO_CHAR (l_count) || ' Entry ' || l_key || ' not found');
            ELSE
                l_countfound := l_countfound + 1;
                DBMS_OUTPUT.put_line (
                    TO_CHAR (l_count) || ' Entry ' || l_key || ' found');
            END IF;

            l_key := gbl_spear.NEXT (l_key);
        END LOOP;

        DBMS_OUTPUT.put_line ('l_countfound=' || TO_CHAR (l_countfound));
    END;

    /*-------------------------------------------------------------*/

    PROCEDURE p_checktaxonreplaceentry (
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
    /*-------------------------------------------------------------*/
    IS
        l_key                      protocolmappinglabo.ptl_taxa%TYPE;

        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_count                    NUMBER := 0;
        l_countfound               NUMBER := 0;
    BEGIN
        l_key := gbl_taxonreplace.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            l_count := l_count + 1;
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecordbytaxa (p_ptv_id, l_key);

            IF l_recprotocolmappinglabo.ptl_id IS NULL
            THEN
                DBMS_OUTPUT.put_line (
                    TO_CHAR (l_count) || ' Entry ' || l_key || ' not found');
            ELSE
                l_countfound := l_countfound + 1;
                DBMS_OUTPUT.put_line (
                    TO_CHAR (l_count) || ' Entry ' || l_key || ' found');
            END IF;

            l_key := gbl_taxonreplace.NEXT (l_key);
        END LOOP;

        DBMS_OUTPUT.put_line ('l_countfound=' || TO_CHAR (l_countfound));
    END;

    /*-------------------------------------------------------------*/

    PROCEDURE p_initspear
    /*-------------------------------------------------------------*/
    IS
    -- Attention: Les noms de taxon sont ceux de la version 2019
    BEGIN
        gbl_spear ('NEMATHELMINTHES') := NULL;
        gbl_spear ('Acroloxidae') := 0;
        gbl_spear ('Aeshnidae') := 0;
        gbl_spear ('Ameletidae') := 1;
        gbl_spear ('Ancylidae (Tachet)') := 0;
        gbl_spear ('Anthomyiidae/Muscidae') := NULL;
        gbl_spear ('Apataniidae') := 1;
        gbl_spear ('Aphelocheiridae') := 0;
        gbl_spear ('Asellidae') := 0;
        gbl_spear ('Astacidae') := NULL;
        gbl_spear ('Athericidae') := 1;
        gbl_spear ('Baetidae') := 1;
        gbl_spear ('Beraeidae') := 1;
        gbl_spear ('Bithyniidae') := 0;
        gbl_spear ('Blephariceridae') := NULL;
        gbl_spear ('Brachycentridae') := 1;
        gbl_spear ('Branchiopoda') := NULL;
        gbl_spear ('BRYOZOA') := NULL;
        gbl_spear ('Caenidae') := 1;
        gbl_spear ('Calopterygidae') := 1;
        gbl_spear ('Cambaridae*') := NULL;
        gbl_spear ('Capniidae') := 1;
        gbl_spear ('Ceratopogonidae') := 0;
        gbl_spear ('Chaoboridae') := 1;
        gbl_spear ('Chironomidae') := 0;
        gbl_spear ('Chloroperlidae') := 1;
        gbl_spear ('Chrysomelidae') := 0;
        gbl_spear ('CNIDARIA') := NULL;
        gbl_spear ('Coenagrionidae') := 1;
        gbl_spear ('Corbiculidae*') := 0;
        gbl_spear ('Cordulegastridae') := 0;
        gbl_spear ('Corduliidae') := 0;
        gbl_spear ('Corixidae') := 0;
        gbl_spear ('Corophiidae*') := NULL;
        gbl_spear ('Culicidae') := NULL;
        gbl_spear ('Curculionidae') := 0;
        gbl_spear ('Cylindrotomidae') := NULL;
        gbl_spear ('Dendrocoelidae') := 0;
        gbl_spear ('Dixidae') := 1;
        gbl_spear ('Dolichopodidae') := 0;
        gbl_spear ('Dreissenidae*') := 0;
        gbl_spear ('Dryopidae') := 0;
        gbl_spear ('Dugesiidae') := 0;
        gbl_spear ('Dytiscidae') := 0;
        gbl_spear ('Ecnomidae') := 1;
        gbl_spear ('Elmidae') := 0;
        gbl_spear ('Empididae') := 0;
        gbl_spear ('Ephemerellidae') := 0;
        gbl_spear ('Ephemeridae') := 0;
        gbl_spear ('Ephydridae') := NULL;
        gbl_spear ('Erpobdellidae') := 0;
        gbl_spear ('Ferrissiidae (Tachet)') := NULL;
        gbl_spear ('Gammaridae') := 0;
        gbl_spear ('Gerridae') := 0;
        gbl_spear ('Glossiphoniidae') := 0;
        gbl_spear ('Glossosomatidae') := 1;
        gbl_spear ('Goeridae') := 1;
        gbl_spear ('Gomphidae') := 0;
        gbl_spear ('Gyrinidae') := 0;
        gbl_spear ('Haliplidae') := 0;
        gbl_spear ('Hebridae') := 0;
        gbl_spear ('Helicopsychidae') := 1;
        gbl_spear ('Helophoridae (Tachet)') := 0;
        gbl_spear ('Heptageniidae') := 1;
        gbl_spear ('Hirudidae (Tachet)') := 0;
        gbl_spear ('Hydracarina') := 0;
        gbl_spear ('Hydraenidae') := 0;
        gbl_spear ('Hydrobiidae') := 0;
        gbl_spear ('Hydrochidae (Tachet)') := 0;
        gbl_spear ('Hydrometridae') := 0;
        gbl_spear ('Hydrophilidae') := 0;
        gbl_spear ('Hydropsychidae') := 0;
        gbl_spear ('Hydroptilidae') := 1;
        gbl_spear ('Hydroscaphidae') := 0;
        gbl_spear ('Hygrobiidae') := 0;
        gbl_spear ('Hymenoptera') := NULL;
        gbl_spear ('Janiridae*') := NULL;
        gbl_spear ('Lepidoptera') := NULL;
        gbl_spear ('Lepidostomatidae') := 1;
        gbl_spear ('Leptoceridae') := 0;
        gbl_spear ('Leptophlebiidae') := 0;
        gbl_spear ('Lestidae') := 0;
        gbl_spear ('Leuctridae') := 1;
        gbl_spear ('Libellulidae') := 0;
        gbl_spear ('Limnephilidae') := 1;
        gbl_spear ('Limoniidae/Pediciidae') := 0;
        gbl_spear ('Lymnaeidae') := 0;
        gbl_spear ('Mesoveliidae') := 0;
        gbl_spear ('Molannidae') := 1;
        gbl_spear ('Mysidae*') := NULL;
        gbl_spear ('Naucoridae') := 0;
        gbl_spear ('Nemouridae') := 0;
        gbl_spear ('Nepidae') := 0;
        gbl_spear ('Neritidae') := 0;
        gbl_spear ('Niphargidae') := NULL;
        gbl_spear ('Noteridae') := 0;
        gbl_spear ('Notonectidae') := 0;
        gbl_spear ('Odontoceridae') := 1;
        gbl_spear ('Oligochaeta') := 0;
        gbl_spear ('Oligoneuriidae') := 1;
        gbl_spear ('Osmylidae') := NULL;
        gbl_spear ('Perlidae') := 1;
        gbl_spear ('Perlodidae') := 1;
        gbl_spear ('Philopotamidae') := 1;
        gbl_spear ('Phryganeidae') := 1;
        gbl_spear ('Physidae') := 0;
        gbl_spear ('Piscicolidae') := 0;
        gbl_spear ('Planariidae') := 0;
        gbl_spear ('Planorbidae') := 0;
        gbl_spear ('Platycnemididae') := 0;
        gbl_spear ('Pleidae') := 0;
        gbl_spear ('Polycentropodidae') := 1;
        gbl_spear ('Polymitarcyidae') := 1;
        gbl_spear ('PORIFERA') := NULL;
        gbl_spear ('Potamanthidae') := 1;
        gbl_spear ('Psephenidae') := 0;
        gbl_spear ('Psychodidae') := 0;
        gbl_spear ('Psychomyiidae') := 1;
        gbl_spear ('Ptilocolepidae') := 1;
        gbl_spear ('Ptychopteridae') := 0;
        gbl_spear ('Rhagionidae') := 0;
        gbl_spear ('Rhyacophilidae') := 1;
        gbl_spear ('Scathophagidae') := NULL;
        gbl_spear ('Sciomyzidae') := NULL;
        gbl_spear ('Scirtidae') := 0;
        gbl_spear ('Sericostomatidae') := 0;
        gbl_spear ('Sialidae') := 1;
        gbl_spear ('Simuliidae') := 0;
        gbl_spear ('Siphlonuridae') := 1;
        gbl_spear ('Sisyridae') := NULL;
        gbl_spear ('Spercheidae (Tachet)') := 0;
        gbl_spear ('Sphaeriidae') := 0;
        gbl_spear ('Stratiomyidae') := 0;
        gbl_spear ('Syrphidae') := 0;
        gbl_spear ('Tabanidae') := 0;
        gbl_spear ('Taeniopterygidae') := 1;
        gbl_spear ('Thaumaleidae') := NULL;
        gbl_spear ('Tipulidae') := 0;
        gbl_spear ('Unionidae') := 0;
        gbl_spear ('Valvatidae') := 0;
        gbl_spear ('Veliidae') := NULL;
        gbl_spear ('Viviparidae') := 0;
    END;

    /*--------------------------------------------------------------*/

    PROCEDURE p_inittaxonindicateur
    /*--------------------------------------------------------------*/
    IS
        -- Attention: Les noms de taxon sont ceux de la version 2013
        l_rectaxonindicateur   r_taxonindicateur;
    BEGIN
        gbl_taxonindicateur.delete;
        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 1;
        gbl_taxonindicateur ('Hirudinea') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 1;
        gbl_taxonindicateur ('Erpobdellidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 1;
        gbl_taxonindicateur ('Glossiphoniidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 1;
        gbl_taxonindicateur ('Hirudidae (Tachet)') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 1;
        gbl_taxonindicateur ('Piscicolidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 10;
        l_rectaxonindicateur.l_valeur_gi := 1;
        gbl_taxonindicateur ('Oligochaeta') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('MOLLUSCA') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Acroloxidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Ancylidae (Tachet)') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Bithyniidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Ferrissiidae (Tachet)') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Hydrobiidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Lymnaeidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Neritidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Physidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Planorbidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Valvatidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Viviparidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Corbiculidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Dreissenidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Sphaeriidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Unionidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 10;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Gammaridae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 10;
        l_rectaxonindicateur.l_valeur_gi := 1;
        gbl_taxonindicateur ('Asellidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 10;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Baetidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 10;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Caenidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 10;
        l_rectaxonindicateur.l_valeur_gi := 3;
        gbl_taxonindicateur ('Ephemerellidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 6;
        gbl_taxonindicateur ('Ephemeridae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 5;
        gbl_taxonindicateur ('Heptageniidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 6;
        gbl_taxonindicateur ('Leptophlebiidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 5;
        gbl_taxonindicateur ('Polymitarcyidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 5;
        gbl_taxonindicateur ('Potamanthidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 8;
        gbl_taxonindicateur ('Capniidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 9;
        gbl_taxonindicateur ('Chloroperlidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 6;
        gbl_taxonindicateur ('Leuctridae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 5;
        gbl_taxonindicateur ('Nemouridae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 9;
        gbl_taxonindicateur ('Perlidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 9;
        gbl_taxonindicateur ('Perlodidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 7;
        gbl_taxonindicateur ('Taeniopterygidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 3;
        gbl_taxonindicateur ('Aphelocheiridae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 10;
        l_rectaxonindicateur.l_valeur_gi := 2;
        gbl_taxonindicateur ('Elmidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 8;
        gbl_taxonindicateur ('Beraeidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 8;
        gbl_taxonindicateur ('Brachycentridae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 7;
        gbl_taxonindicateur ('Glossosomatidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 7;
        gbl_taxonindicateur ('Goeridae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 3;
        gbl_taxonindicateur ('Hydropsychidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 5;
        gbl_taxonindicateur ('Hydroptilidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 6;
        gbl_taxonindicateur ('Lepidostomatidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 4;
        gbl_taxonindicateur ('Leptoceridae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 10;
        l_rectaxonindicateur.l_valeur_gi := 3;
        gbl_taxonindicateur ('Limnephilidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 7;
        gbl_taxonindicateur ('Odontoceridae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 8;
        gbl_taxonindicateur ('Philopotamidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 4;
        gbl_taxonindicateur ('Polycentropodidae') := l_rectaxonindicateur;

        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 4;
        gbl_taxonindicateur ('Psychomyiidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 4;
        gbl_taxonindicateur ('Rhyacophilidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 3;
        l_rectaxonindicateur.l_valeur_gi := 6;
        gbl_taxonindicateur ('Sericostomatidae') := l_rectaxonindicateur;


        l_rectaxonindicateur.l_nombremin := 10;
        l_rectaxonindicateur.l_valeur_gi := 1;
        gbl_taxonindicateur ('Chironomidae') := l_rectaxonindicateur;
        DBMS_OUTPUT.put_line ('Nombre: ' || gbl_taxonindicateur.COUNT);
    END;

    /*--------------------------------------------------------------*/

    PROCEDURE p_inittaxonreplace
    /*--------------------------------------------------------------*/
    IS
        l_taxonreplace   r_taxonreplace;
    BEGIN
        gbl_taxonreplace.delete;
        l_taxonreplace.l_taxon_2019 := 'Cambaridae*';
        l_taxonreplace.l_taxon_cscf := 'Cambaridae';
        gbl_taxonreplace ('Cambaridae') := l_taxonreplace;

        l_taxonreplace.l_taxon_2019 := 'Corbiculidae*';
        l_taxonreplace.l_taxon_cscf := 'Corbiculidae';
        gbl_taxonreplace ('Corbiculidae') := l_taxonreplace;

        l_taxonreplace.l_taxon_2019 := 'Cordulegastridae';
        l_taxonreplace.l_taxon_cscf := 'Cordulegastridae';
        gbl_taxonreplace ('Cordulegasteridae') := l_taxonreplace;

        l_taxonreplace.l_taxon_2019 := 'Corophiidae*';
        l_taxonreplace.l_taxon_cscf := 'Corophiidae';
        gbl_taxonreplace ('Corophiidae') := l_taxonreplace;

        l_taxonreplace.l_taxon_2019 := 'Dreissenidae*';
        l_taxonreplace.l_taxon_cscf := 'Dreissenidae';
        gbl_taxonreplace ('Dreissenidae') := l_taxonreplace;

        l_taxonreplace.l_taxon_2019 := 'Helophoridae (Tachet)';
        l_taxonreplace.l_taxon_cscf := 'Helophorinae';
        gbl_taxonreplace ('Helophoridae') := l_taxonreplace;



        l_taxonreplace.l_taxon_2019 := 'Hydrochidae (Tachet)';
        l_taxonreplace.l_taxon_cscf := 'Hydrochinae';
        gbl_taxonreplace ('Hydrochidae') := l_taxonreplace;

        l_taxonreplace.l_taxon_2019 := 'Janiridae*';
        l_taxonreplace.l_taxon_cscf := 'Janiridae';
        gbl_taxonreplace ('Janiridae') := l_taxonreplace;

        l_taxonreplace.l_taxon_2019 := 'Limoniidae/Pediciidae';
        l_taxonreplace.l_taxon_cscf := 'Limoniidae/Pediciidae';
        gbl_taxonreplace ('Limoniidae/Pedicidae') := l_taxonreplace;

        l_taxonreplace.l_taxon_2019 := 'Mysidae*';
        l_taxonreplace.l_taxon_cscf := 'Mysidae';
        gbl_taxonreplace ('Mysidae') := l_taxonreplace;

        l_taxonreplace.l_taxon_2019 := 'Scathophagidae';
        l_taxonreplace.l_taxon_cscf := 'Scathophagidae';
        gbl_taxonreplace ('Scatophagidae') := l_taxonreplace;


        l_taxonreplace.l_taxon_2019 := 'Scirtidae';
        l_taxonreplace.l_taxon_cscf := 'Scirtidae';
        gbl_taxonreplace ('Scirtidae (=Helodidae)') := l_taxonreplace;

        l_taxonreplace.l_taxon_2019 := 'Spercheidae (Tachet)';
        l_taxonreplace.l_taxon_cscf := 'Spercheinae';
        gbl_taxonreplace ('Spercheidae') := l_taxonreplace;
    END;
BEGIN
    p_inittaxonindicateur;
    p_initspear;
    p_inittaxonreplace;
END pkg_migr_ibch2019_ptl;
/

