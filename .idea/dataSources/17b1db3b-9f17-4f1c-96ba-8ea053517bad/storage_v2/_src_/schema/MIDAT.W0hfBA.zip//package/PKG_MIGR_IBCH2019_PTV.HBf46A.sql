create PACKAGE       pkg_migr_ibch2019_ptv
AS
    /******************************************************************************
      NAME:       PKG_MIGR_IBCH2019_PTV
      PURPOSE:    Modification dans la table PROTOCOLVERSION

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       15.05.2020  F.Burri           1. Created this package
   ******************************************************************************/

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, mai 2020';

    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_addversion (p_text     IN     protocolversion.ptv_text%TYPE,
                            p_ptv_id      OUT protocolversion.ptv_id%TYPE,
                            p_exist       OUT BOOLEAN);

    FUNCTION f_returnversionbytext (p_text IN protocolversion.ptv_text%TYPE)
        RETURN protocolversion%ROWTYPE;

    PROCEDURE p_deleteversionbytext (p_text IN protocolversion.ptv_text%TYPE);

    PROCEDURE p_deleteversion (p_ptv_id IN protocolversion.ptv_id%TYPE);
END pkg_migr_ibch2019_ptv;
/

