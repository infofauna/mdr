create PACKAGE BODY       pkg_validatemassheader
AS
    /******************************************************************************
       NAME:       pkg_validatemassheader
       PURPOSE: Valide la structure de la feuille excel, pas le contenu

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        25.09.2013      burrif       1. Created this package.
       1.1        26.09.2017      burrif       2. MIDAT Version 1
    ******************************************************************************/



    TYPE t_recmassfield IS RECORD
    (
        l_count            PLS_INTEGER,
        l_databasefield    protocolmappingmassfield.pmm_columnname%TYPE
    );



    TYPE t_listmassfield IS TABLE OF t_recmassfield
        INDEX BY VARCHAR2 (256);

    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.0, septembre  2017' ;
    gbl_massfield                 t_listmassfield;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_returncounterdistinctoidlink (
        p_iph_id    IN importprotocolheader.iph_id%TYPE,
        p_oidlink   IN importmassdataheader.imh_oidlink%TYPE)
        RETURN NUMBER
    /*----------------------------------------------------------------*/
    IS
        l_nombre   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_nombre
          FROM importmassdataheader
         WHERE     imh_iph_id = p_iph_id
               AND NOT imh_oid IS NULL
               AND NOT imh_oidlink IS NULL
               AND imh_oidlink = p_oidlink;

        RETURN l_nombre;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_invalidatebyoidlink (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE,
        p_oidlink                IN importmassdataheader.imh_oidlink%TYPE,
        p_usr_id                 IN importprotocolheader.iph_usr_id_modify%TYPE)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importmassdataheader
           SET imh_validstatus =
                   pkg_importprotocolheader.cst_validstatusnotok,
               imh_usr_id_modify = p_usr_id,
               imh_usr_modify_date = SYSDATE
         WHERE     imh_iph_id = p_importprotocolheader.iph_id
               AND imh_oidlink = p_oidlink;
    END;


    /*--------------------------------------------------------------*/
    PROCEDURE p_validateoidlink (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE)
    /*--------------------------------------------------------------*/
    /*
     Permet de vérifier que la colonne OIDLINK de manière global référencie toujours la même station

     */



    IS
        CURSOR l_importmassdataheader
        IS
            SELECT DISTINCT imh_oidlink
              FROM importmassdataheader
             WHERE     imh_iph_id = p_importprotocolheader.iph_id
                   AND NOT imh_oid IS NULL
                   AND NOT imh_oidlink IS NULL
                   AND imh_validstatus =
                       pkg_importprotocolheader.cst_validstatusok;

        CURSOR l_importmassdataheaderoid (
            p_oidlink   IN importmassdataheader.imh_oidlink%TYPE)
        IS
            SELECT *
              FROM importmassdataheader
             WHERE     imh_iph_id = p_importprotocolheader.iph_id
                   AND NOT imh_oid IS NULL
                   AND NOT imh_oidlink IS NULL
                   AND imh_oidlink = p_oidlink
                   AND imh_validstatus =
                       pkg_importprotocolheader.cst_validstatusok;


        l_recimportmassdataheaderoid     l_importmassdataheaderoid%ROWTYPE;
        l_recimportmassdataheader        l_importmassdataheader%ROWTYPE;
        l_recsamplestation               samplestation%ROWTYPE;
        l_recsamplestationitem           samplestationitem%ROWTYPE;

        l_recprotocolmappingmassmapoid   protocolmappingmassmap%ROWTYPE;
        l_recprotocolmappingmassmap      protocolmappingmassmap%ROWTYPE;
        l_countmaster                    NUMBER := 0;
        l_countdetail                    NUMBER := 0;
        l_countoidlink                   NUMBER := 0;
        l_swisscoordtext                 VARCHAR2 (1024);
        l_usr_id                         importprotocolheader.iph_usr_id_modify%TYPE;
    BEGIN
        l_recprotocolmappingmassmap :=
            pkg_protocolmappingmassmap.f_getrecordbymidatfldcmt (
                p_importprotocolheader.iph_ptv_id,
                p_importprotocolheader.iph_lan_id,
                pkg_codevalue.cst_midatfldcmt_oidlink);
        l_recprotocolmappingmassmapoid :=
            pkg_protocolmappingmassmap.f_getrecordbymidatfldcmt (
                p_importprotocolheader.iph_ptv_id,
                p_importprotocolheader.iph_lan_id,
                pkg_codevalue.cst_midatfldcmt_oid);
        l_usr_id := p_importprotocolheader.iph_usr_id_create;

        OPEN l_importmassdataheader;

        LOOP
            FETCH l_importmassdataheader INTO l_recimportmassdataheader;

            EXIT WHEN l_importmassdataheader%NOTFOUND;
            l_countdetail := 0;
            l_countoidlink :=
                f_returncounterdistinctoidlink (
                    p_importprotocolheader.iph_id,
                    l_recimportmassdataheader.imh_oidlink);

            IF l_countoidlink > 1
            THEN
                OPEN l_importmassdataheaderoid (l_recimportmassdataheader.imh_oidlink);

                LOOP
                    -- Liste des OID sur lequel le même OIDLINK pointe
                    FETCH l_importmassdataheaderoid
                        INTO l_recimportmassdataheaderoid;

                    EXIT WHEN l_importmassdataheaderoid%NOTFOUND;

                    IF l_countdetail = 0
                    THEN
                        -- Les entrées suivantes sont invalidées car le même lien de station (%p1%) référencie plusieurs stations principales différentes(voir liste ci-dessous)
                        pkg_importprotocollog.p_writelog (
                            p_importprotocolheader.iph_id,
                            NULL, --p_imh_id,                                       -- IMH_ID
                            pkg_exception.cst_oidlinkrefmoreoid,
                            'IMH_OIDLINK',                       -- Field name
                            l_recimportmassdataheader.imh_oidlink);

                        NULL;
                    END IF;

                    l_countdetail := l_countdetail + 1;
                    l_recsamplestation :=
                        pkg_samplestation.f_getrecordbyinsidandoid (
                            p_importprotocolheader.iph_ins_id_principal,
                            l_recimportmassdataheader.imh_oidlink);
                    l_swisscoordtext :=
                        pkg_samplestation.f_buildswisscoord (
                            l_recsamplestation);
                    l_recsamplestationitem :=
                        pkg_samplestationitem.f_getatleastonerecord (
                            l_recsamplestation.sst_id,
                            pkg_codevalue.cst_midatstitmty_locality);

                    -- %p1%: Date: %p2%, station OID: %p3%, localité: %p4%, coordonnées (x;y;z): %p5%
                    pkg_importprotocollog.p_writelog (
                        p_importprotocolheader.iph_id,
                        NULL, --p_imh_id,                                          -- IMH_ID
                        pkg_exception.cst_infomorelink,
                        'IMH_OIDLINK',                           -- Field name
                        TRIM (TO_CHAR (l_countdetail)),
                           NVL (l_recimportmassdataheaderoid.imh_day, '..')
                        || '/'
                        || NVL (l_recimportmassdataheaderoid.imh_month, '..')
                        || '/'
                        || NVL (l_recimportmassdataheaderoid.imh_year,
                                '....'),
                        l_recimportmassdataheaderoid.imh_oid,
                        l_recimportmassdataheaderoid.imh_locality,
                           '('
                        || TRIM (
                               TO_CHAR (
                                   l_recimportmassdataheaderoid.imh_startpoint_x))
                        || '; '
                        || TRIM (
                               TO_CHAR (
                                   l_recimportmassdataheaderoid.imh_startpoint_y))
                        || '; '
                        || TRIM (
                               TO_CHAR (
                                   l_recimportmassdataheaderoid.imh_elevation)));
                END LOOP;

                CLOSE l_importmassdataheaderoid;

                -- Invalidation des entrées en erreur
                p_invalidatebyoidlink (p_importprotocolheader,
                                       l_recimportmassdataheader.imh_oidlink,
                                       l_usr_id);
            END IF;
        END LOOP;

        CLOSE l_importmassdataheader;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_displayonemkitaxoninfo_o (
        p_iph_id             IN     importprotocolheader.iph_id%TYPE,
        p_imh_id             IN     importmassdataheader.imh_id%TYPE,
        p_listmkireference   IN     pkg_indice_utility.t_listmkireference,
        p_key                IN     VARCHAR2,
        p_indice             IN OUT NUMBER)
    /*---------------------------------------------------------------*/
    IS
    -- Pas utilisé
    BEGIN
        -- 1. %p1%:  Nombre d'individu par mètre carrée (fourni dans la formulaire) =%p2% . Facteur d'abondance calculé =%p3%
        IF p_listmkireference (p_key).mki_normalizedcounter > 0
        THEN
            p_indice := p_indice + 1;

            IF p_key = pkg_indice_utility.cst_mki_trichoptera
            THEN
                pkg_importprotocollog.p_writelog (
                    p_iph_id,
                    p_imh_id,                                        -- IMH_ID
                    pkg_exception.cst_mkitricopteracount,
                    NULL,                                        -- Field name
                    TRIM (TO_CHAR (p_indice)),
                    p_key,
                    TO_CHAR (
                        p_listmkireference (p_key).mki_normalizedcounter,
                        '9999'),
                    TO_CHAR (pkg_indice_utility.f_gblmkiexculetricoptera,
                             '9999'));
            ELSE
                pkg_importprotocollog.p_writelog (
                    p_iph_id,
                    p_imh_id,                                        -- IMH_ID
                    pkg_exception.cst_info,
                    NULL,                                        -- Field name
                       TRIM (TO_CHAR (p_indice))
                    || '. '
                    || p_key
                    || ' '
                    || TO_CHAR (
                           p_listmkireference (p_key).mki_normalizedcounter,
                           '9999'));
            END IF;
        END IF;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_displaymkicomputedetailinfoo (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_imh_id                    IN importmassdataheader.imh_id%TYPE,
        p_listmkireference             pkg_indice_utility.t_listmkireference)
    /*---------------------------------------------------------------*/
    IS
        -- Pas utilisé
        l_cvl_code          codevalue.cvl_code%TYPE;
        l_normalizedvalue   NUMBER;
        l_indice            NUMBER := 0;
        l_skip              BOOLEAN := FALSE;
    BEGIN
        l_cvl_code := pkg_indice_utility.f_getmkicvlcodecase;

        IF l_cvl_code = pkg_codevalue.cst_mkicase_plecotricho
        THEN
            -- On est dans le cas ou le pleco et troco s'ajoute
            l_indice := l_indice + 1;
            l_normalizedvalue :=
                pkg_abundanceclassrange.f_getrecordbyindiceandvalue (
                    pkg_codevalue.cst_midatindice_makroindex,
                      p_listmkireference (
                          pkg_indice_utility.cst_mki_plecoptera).mki_counter
                    + p_listmkireference (
                          pkg_indice_utility.cst_mki_trichoptera).mki_counter).acr_substitutevalue;
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                p_imh_id,                                            -- IMH_ID
                pkg_exception.cst_mkidisplaydetail,
                NULL,                                            -- Field name
                TRIM (TO_CHAR (l_indice)),
                   pkg_indice_utility.cst_mki_plecoptera
                || ' +'
                || pkg_indice_utility.cst_mki_trichoptera,
                TO_CHAR (
                    p_listmkireference (
                        pkg_indice_utility.cst_mki_trichoptera).mki_counter,
                    '9999'),
                TO_CHAR (l_normalizedvalue, '9999'));
            l_skip := TRUE;
        END IF;

        IF NOT l_skip
        THEN
            IF p_listmkireference (pkg_indice_utility.cst_mki_plecoptera).mki_counter >
               0
            THEN
                l_normalizedvalue :=
                    pkg_abundanceclassrange.f_getrecordbyindiceandvalue (
                        pkg_codevalue.cst_midatindice_makroindex,
                        p_listmkireference (
                            pkg_indice_utility.cst_mki_plecoptera).mki_counter).acr_substitutevalue;
                -- %p1%:  Nombre d'individus total comptabilisés dans le formulaire =%p2% . Equivalent abondance selon tabelle: %p3%
                l_indice := l_indice + 1;
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    p_imh_id,                                        -- IMH_ID
                    pkg_exception.cst_mkidisplaydetail,
                    NULL,                                        -- Field name
                    TRIM (TO_CHAR (l_indice)),
                    pkg_indice_utility.cst_mki_plecoptera,
                    TO_CHAR (
                        p_listmkireference (
                            pkg_indice_utility.cst_mki_plecoptera).mki_counter,
                        '9999'),
                    TO_CHAR (l_normalizedvalue, '9999'));
            END IF;

            IF p_listmkireference (pkg_indice_utility.cst_mki_trichoptera).mki_counter >
               0
            THEN
                l_normalizedvalue :=
                    pkg_abundanceclassrange.f_getrecordbyindiceandvalue (
                        pkg_codevalue.cst_midatindice_makroindex,
                        p_listmkireference (
                            pkg_indice_utility.cst_mki_trichoptera).mki_counter).acr_substitutevalue;
                -- %p1%:  Nombre d'individus total comptabilisés dans le formulaire =%p2% . Equivalent abondance selon tabelle: %p3%
                l_indice := l_indice + 1;
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    p_imh_id,                                        -- IMH_ID
                    pkg_exception.cst_mkidisplaydetail,
                    NULL,                                        -- Field name
                    TRIM (TO_CHAR (l_indice)),
                    pkg_indice_utility.cst_mki_plecoptera,
                    TO_CHAR (
                        p_listmkireference (
                            pkg_indice_utility.cst_mki_trichoptera).mki_counter,
                        '9999'),
                    TO_CHAR (l_normalizedvalue, '9999'));
            END IF;
        END IF;

        IF p_listmkireference (pkg_indice_utility.cst_mki_ephemeroptera).mki_counter >
           0
        THEN
            l_normalizedvalue :=
                pkg_abundanceclassrange.f_getrecordbyindiceandvalue (
                    pkg_codevalue.cst_midatindice_makroindex,
                    p_listmkireference (
                        pkg_indice_utility.cst_mki_ephemeroptera).mki_counter).acr_substitutevalue;
            -- %p1%:  Nombre d'individus total comptabilisés dans le formulaire =%p2% . Equivalent abondance selon tabelle: %p3%
            l_indice := l_indice + 1;
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                p_imh_id,                                            -- IMH_ID
                pkg_exception.cst_mkidisplaydetail,
                NULL,                                            -- Field name
                TRIM (TO_CHAR (l_indice)),
                pkg_indice_utility.cst_mki_ephemeroptera,
                TO_CHAR (
                    p_listmkireference (
                        pkg_indice_utility.cst_mki_ephemeroptera).mki_counter,
                    '9999'),
                TO_CHAR (l_normalizedvalue, '9999'));
        END IF;

        IF p_listmkireference (pkg_indice_utility.cst_mki_baetidae).mki_counter >
           0
        THEN
            l_normalizedvalue :=
                pkg_abundanceclassrange.f_getrecordbyindiceandvalue (
                    pkg_codevalue.cst_midatindice_makroindex,
                    p_listmkireference (
                        pkg_indice_utility.cst_mki_ephemeroptera).mki_counter).acr_substitutevalue;
            -- %p1%:  Nombre d'individus total comptabilisés dans le formulaire =%p2% . Equivalent abondance selon tabelle: %p3%
            l_indice := l_indice + 1;
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                p_imh_id,                                            -- IMH_ID
                pkg_exception.cst_mkidisplaydetail,
                NULL,                                            -- Field name
                TRIM (TO_CHAR (l_indice)),
                pkg_indice_utility.cst_mki_ephemeroptera,
                TO_CHAR (
                    p_listmkireference (
                        pkg_indice_utility.cst_mki_ephemeroptera).mki_counter,
                    '9999'),
                TO_CHAR (l_normalizedvalue, '9999'));
        END IF;
    END;



    /*--------------------------------------------------------------*/
    PROCEDURE p_calculatemkidisplayinfo_o (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_imh_id                    IN importmassdataheader.imh_id%TYPE,
        p_valueindicemki            IN NUMBER)
    /*---------------------------------------------------------------*/
    -- Pas utilisé
    IS
        l_mki_insectanoninsectaratio   NUMBER;
        l_key                          systdesignation.syd_designation%TYPE;
        l_countinsecta                 NUMBER;
        l_mki_error                    NUMBER;
        l_listmkireference             pkg_indice_utility.t_listmkireference;
        l_mkicounter                   NUMBER;
        l_indice                       PLS_INTEGER := 0;
        l_mki_cvl_code_case            codevalue.cvl_code%TYPE;
        l_reccodedesignation           codedesignation%ROWTYPE;
        l_mki_non_insecta_count        NUMBER;
        l_rapportstring                VARCHAR2 (20);
        l_list                         VARCHAR2 (512);
        l_textratioinsecta             VARCHAR2 (512);
        l_normalizedcount              NUMBER;
        l_recabundanceclassrange       abundanceclassrange%ROWTYPE;
        l_total                        NUMBER;
        l_valuenormalized              NUMBER;
        l_plecoandtrico                NUMBER;

        l_normilizedplecoandtricho     NUMBER;
    BEGIN
        l_mki_insectanoninsectaratio :=
            pkg_indice_utility.f_getgblmkiinsectaratio;
        l_normalizedcount := pkg_indice_utility.f_getgblnormalizedcount;

        IF     l_listmkireference.EXISTS (
                   pkg_indice_utility.cst_mki_plecoptera)
           AND l_listmkireference.EXISTS (
                   pkg_indice_utility.cst_mki_trichoptera)
        THEN
            l_plecoandtrico :=
                  l_listmkireference (pkg_indice_utility.cst_mki_plecoptera).mki_counter
                + l_listmkireference (pkg_indice_utility.cst_mki_trichoptera).mki_counter;
            l_recabundanceclassrange :=
                pkg_abundanceclassrange.f_getrecordbyclass (
                    pkg_codevalue.cst_midatfldcmt_makroindex,
                    l_plecoandtrico);
            l_normilizedplecoandtricho :=
                l_recabundanceclassrange.acr_substitutevalue;
        END IF;

        l_mkicounter := pkg_indice_utility.f_getgblmkitotalcounter;
        l_listmkireference := pkg_indice_utility.f_getgblmkireference;
        l_countinsecta := pkg_indice_utility.f_getgblinsectacount;
        l_mki_non_insecta_count := pkg_indice_utility.f_getmkinoninsectacount;
        pkg_debug.p_write (
            'PKG_VALIDATEMASSHEADER.p_calculatemkidisplayinfo',
               'l_mki_insectanoninsectaratio='
            || l_mki_insectanoninsectaratio
            || ' l_mkicounter='
            || l_mkicounter
            || 'l_countinsecta='
            || l_countinsecta);

        IF l_mki_insectanoninsectaratio =
           pkg_indice_utility.cst_insectaratio_zerodivide
        THEN
            l_textratioinsecta := '∞';
        ELSE
            l_textratioinsecta :=
                '=' || TO_CHAR (l_mki_insectanoninsectaratio, '999.99');
        END IF;


        IF    p_valueindicemki IS NULL
           OR p_valueindicemki = pkg_indice_utility.cst_mkinotset
        THEN
            l_mki_error := pkg_indice_utility.f_getmkierror;
            l_listmkireference := pkg_indice_utility.f_getgblmkireference;
            l_mkicounter := pkg_indice_utility.f_getgblmkitotalcounter;

            CASE l_mki_error
                WHEN pkg_exception.cst_mkiasselushirudinaeturbifi
                -- %p1% Asselus, %p2% Hirudinae et %p3% Turbificidae avec un rapport insectes/non insectes de %p4%
                THEN
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        p_imh_id,                                    -- IMH_ID
                        pkg_exception.cst_mkiasselushirudinaeturbifi,
                        NULL,                                    -- Field name
                        TO_CHAR (
                            l_listmkireference (
                                pkg_indice_utility.cst_mki_asellus).mki_normalizedcounter,
                            '99999'),
                        TO_CHAR (
                            l_listmkireference (
                                pkg_indice_utility.cst_mki_hirudinea).mki_normalizedcounter,
                            '99999'),
                        TO_CHAR (
                            l_listmkireference (
                                pkg_indice_utility.cst_mki_tubificidae).mki_normalizedcounter,
                            '99999'),
                        l_textratioinsecta);
                WHEN pkg_exception.cst_mkigammarushydropsyche
                -- %p1% Gammarus, %p2% Hydropsyche avec un rapport insectes/non insectes de %p3%
                THEN
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        p_imh_id,                                    -- IMH_ID
                        pkg_exception.cst_mkigammarushydropsyche,
                        NULL,                                    -- Field name
                        TO_CHAR (
                            l_listmkireference (
                                pkg_indice_utility.cst_mki_gammarus).mki_normalizedcounter,
                            '99999'),
                        TO_CHAR (
                            l_listmkireference (
                                pkg_indice_utility.cst_mki_hydropsyche).mki_normalizedcounter,
                            '99999'),
                        l_textratioinsecta);
                WHEN pkg_exception.cst_mkiephemeropterawithoutbae
                -- %p1% Ephemeroptera sans Baetidae avec un rapport insectes/non insectes de %p2%
                THEN
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        p_imh_id,                                    -- IMH_ID
                        pkg_exception.cst_mkiephemeropterawithoutbae,
                        NULL,                                    -- Field name
                        pkg_indice_utility.f_getgblmkirangeselected,
                        l_textratioinsecta,
                        TO_CHAR (
                            l_listmkireference (
                                pkg_indice_utility.cst_mki_ephemeroptera).mki_normalizedcounter,
                            '99999'));
                WHEN pkg_exception.cst_mkiplecopteratrichoptera
                -- %p1% Plecoptera, %p2% Trichoptera avec un rapport insectes/non insectes de %p3%
                THEN
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        p_imh_id,                                    -- IMH_ID
                        pkg_exception.cst_mkiplecopteratrichoptera,
                        NULL,                                    -- Field name
                        TO_CHAR (l_normilizedplecoandtricho),
                        l_textratioinsecta,
                        TO_CHAR (
                            l_listmkireference (
                                pkg_indice_utility.cst_mki_plecoptera).mki_normalizedcounter,
                            '99999'),
                        TO_CHAR (
                            l_listmkireference (
                                pkg_indice_utility.cst_mki_trichoptera).mki_normalizedcounter,
                            '99999'));
                WHEN pkg_exception.cst_mkiplecoptera
                --  %p1% Plecoptera a avec un rapport insectes/non insectes de %p2%
                THEN
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        p_imh_id,                                    -- IMH_ID
                        pkg_exception.cst_mkiplecoptera,
                        NULL,                                    -- Field name
                        pkg_indice_utility.f_getgblmkirangeselected,
                        l_textratioinsecta,
                        TO_CHAR (
                            l_listmkireference (
                                pkg_indice_utility.cst_mki_plecoptera).mki_normalizedcounter,
                            '99999'));
                WHEN pkg_exception.cst_mkiunabletocompute
                --Les donnees fournies ne permettent pas le calcul du makroindex: %p1%
                THEN
                    l_total :=
                          l_listmkireference (
                              pkg_indice_utility.cst_mki_trichoptera).mki_counter
                        + l_listmkireference (
                              pkg_indice_utility.cst_mki_plecoptera).mki_counter;
                    l_recabundanceclassrange :=
                        pkg_abundanceclassrange.f_getrecordbyindiceandvalue (
                            pkg_codevalue.cst_midatfldcmt_makroindex,
                            l_total);
                    l_total := l_recabundanceclassrange.acr_substitutevalue;
                    l_list :=
                           'Plecoptera='
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_plecoptera).mki_counter,
                               '99999')
                        || ' ( '
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_plecoptera).mki_normalizedcounter,
                               '99999')
                        || ' )'
                        || ' Trichopretra='
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_trichoptera).mki_counter,
                               '99999')
                        || ' ( '
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_trichoptera).mki_normalizedcounter,
                               '99999')
                        || ' ) '
                        || 'Plecoptera+Trichoptera='
                        || TO_CHAR (
                                 l_listmkireference (
                                     pkg_indice_utility.cst_mki_trichoptera).mki_counter
                               + l_listmkireference (
                                     pkg_indice_utility.cst_mki_plecoptera).mki_counter,
                               '99999')
                        || ' ( '
                        || TO_CHAR (l_total)
                        || ')'
                        || ' Ephemeroptera='
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_ephemeroptera).mki_counter,
                               '99999')
                        || ' ( '
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_ephemeroptera).mki_normalizedcounter,
                               '99999')
                        || ' )'
                        || ' Baetidae='
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_baetidae).mki_counter,
                               '99999')
                        || ' ( '
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_baetidae).mki_normalizedcounter,
                               '99999')
                        || ' )'
                        || ' Gammarus='
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_gammarus).mki_counter,
                               '99999')
                        || ' Hydropsyche='
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_hydropsyche).mki_counter,
                               '99999')
                        || ' Asellus='
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_asellus).mki_counter,
                               '99999')
                        || ' Hirudinea='
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_hirudinea).mki_counter,
                               '99999')
                        || ' Tubificidae='
                        || TO_CHAR (
                               l_listmkireference (
                                   pkg_indice_utility.cst_mki_tubificidae).mki_counter,
                               '99999')
                        || ' Insecta/NonInsecta='
                        || TO_CHAR (l_countinsecta, '9999')
                        || '/'
                        || TO_CHAR (l_mki_non_insecta_count, '9999')
                        || '='
                        || l_textratioinsecta;
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        p_imh_id,                                    -- IMH_ID
                        pkg_exception.cst_mkiunabletocompute,
                        NULL,
                        l_list);


                    NULL;
                ELSE
                    RETURN;
            END CASE;
        ELSE                                     -- l'indice à pu être calculé
            --Cas retenu dans la tabelle de référence: "f$returnusecase(%p1%)". Rapport insecte/non insecte = %p2%, nombre total d'individu=%p3%.
            l_mki_non_insecta_count :=
                pkg_indice_utility.f_getmkinoninsectacount;
            pkg_debug.p_write (
                'pkg_validatemassheader.p_calculatemkidisplayinfo',
                'l_mki_non_insecta_count=' || l_mki_non_insecta_count);

            IF l_mki_non_insecta_count = 0
            THEN
                --L'échantillon comporte uniquement des insectes (pas de  non insecte détecté). Le rapport insecte/non insecte est considéré comme plus grand que 6

                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    p_imh_id,                                        -- IMH_ID
                    pkg_exception.cst_mkihasonlyinsecta,
                    NULL                                         -- Field name
                        );
            END IF;

            l_mki_cvl_code_case := pkg_indice_utility.f_getmkicvlcodecase;
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                p_imh_id,                                            -- IMH_ID
                pkg_exception.cst_mkiusecase,
                NULL,                                            -- Field name
                l_mki_cvl_code_case,
                   TRIM (TO_CHAR (l_countinsecta))
                || '/'
                || TRIM (TO_CHAR (l_mki_non_insecta_count)),
                l_textratioinsecta);


            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                p_imh_id,                                            -- IMH_ID
                pkg_exception.cst_mkiresume,
                NULL);                                           -- Field name
            p_displayonemkitaxoninfo_o (
                p_recimportprotocolheader.iph_id,
                p_imh_id,
                l_listmkireference,
                pkg_indice_utility.cst_mki_trichoptera,
                l_indice);
            p_displayonemkitaxoninfo_o (
                p_recimportprotocolheader.iph_id,
                p_imh_id,
                l_listmkireference,
                pkg_indice_utility.cst_mki_plecoptera,
                l_indice);

            p_displayonemkitaxoninfo_o (
                p_recimportprotocolheader.iph_id,
                p_imh_id,
                l_listmkireference,
                pkg_indice_utility.cst_mki_ephemeroptera,
                l_indice);

            p_displayonemkitaxoninfo_o (p_recimportprotocolheader.iph_id,
                                        p_imh_id,
                                        l_listmkireference,
                                        pkg_indice_utility.cst_mki_baetidae,
                                        l_indice);

            p_displayonemkitaxoninfo_o (
                p_recimportprotocolheader.iph_id,
                p_imh_id,
                l_listmkireference,
                pkg_indice_utility.cst_mki_hydropsyche,
                l_indice);
            p_displayonemkitaxoninfo_o (p_recimportprotocolheader.iph_id,
                                        p_imh_id,
                                        l_listmkireference,
                                        pkg_indice_utility.cst_mki_gammarus,
                                        l_indice);

            p_displayonemkitaxoninfo_o (p_recimportprotocolheader.iph_id,
                                        p_imh_id,
                                        l_listmkireference,
                                        pkg_indice_utility.cst_mki_asellus,
                                        l_indice);
            p_displayonemkitaxoninfo_o (p_recimportprotocolheader.iph_id,
                                        p_imh_id,
                                        l_listmkireference,
                                        pkg_indice_utility.cst_mki_hirudinea,
                                        l_indice);
            p_displayonemkitaxoninfo_o (
                p_recimportprotocolheader.iph_id,
                p_imh_id,
                l_listmkireference,
                pkg_indice_utility.cst_mki_tubificidae,
                l_indice);



            l_mki_cvl_code_case := pkg_indice_utility.f_getmkicvlcodecase;

            IF l_mki_cvl_code_case IS NULL
            THEN
                RETURN;
            END IF;
        END IF;
    END;

    /*-----------------------------------------------------------------------*/
    PROCEDURE p_updatemkiinfo (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN importmassdataheader%ROWTYPE)
    /*-----------------------------------------------------------------------*/
    IS
        l_listmkireference        pkg_indice_utility.t_listmkireference;
        l_cvl_code_mkicase        codevalue.cvl_code%TYPE;
        l_cvl_id_mkicase          codevalue.cvl_id%TYPE;
        l_reccodevalue            codevalue%ROWTYPE;
        l_mkiinsectacount         importmassdataheader.imh_mkiinsectacount%TYPE;
        l_mkinonisectacount       importmassdataheader.imh_mkinonisectacount%TYPE;
        l_mkirangecount           importmassdataheader.imh_mkirangecount%TYPE;
        l_mkiplecopteracount      importmassdataheader.imh_mkiplecopteracount%TYPE;
        l_mkitricopteracount      importmassdataheader.imh_mkitricopteracount%TYPE;
        l_mkiephemeropteracount   importmassdataheader.imh_mkiephemeropteracount%TYPE;
        l_mkibaetidaecount        importmassdataheader.imh_mkibaetidaecount%TYPE;
        l_mkigammaruscount        importmassdataheader.imh_mkigammaruscount%TYPE;
        l_mkihydropsychecount     importmassdataheader.imh_mkihydropsychecount%TYPE;
        l_mkiaselluscount         importmassdataheader.imh_mkiaselluscount%TYPE;
        l_mkihirudinaecount       importmassdataheader.imh_mkihirudinaecount%TYPE;
        l_mkitubificidaecount     importmassdataheader.imh_mkitubificidaecount%TYPE;
        l_mkierrornumber          importmassdataheader.imh_mkierrornumber%TYPE;
        l_mkitotalcounter         NUMBER;
    BEGIN
        l_cvl_code_mkicase := pkg_indice_utility.f_getmkicvlcodecase;
        l_mkinonisectacount := pkg_indice_utility.f_getmkinoninsectacount;
        l_listmkireference := pkg_indice_utility.f_getgblmkireference;
        l_mkiplecopteracount :=
            l_listmkireference (pkg_indice_utility.cst_mki_plecoptera).mki_counter;
        l_mkitricopteracount :=
            l_listmkireference (pkg_indice_utility.cst_mki_trichoptera).mki_counter;
        l_mkiephemeropteracount :=
            l_listmkireference (pkg_indice_utility.cst_mki_ephemeroptera).mki_counter;
        l_mkibaetidaecount :=
            l_listmkireference (pkg_indice_utility.cst_mki_baetidae).mki_counter;
        l_mkigammaruscount :=
            l_listmkireference (pkg_indice_utility.cst_mki_gammarus).mki_counter;
        l_mkihydropsychecount :=
            l_listmkireference (pkg_indice_utility.cst_mki_hydropsyche).mki_counter;
        l_mkiaselluscount :=
            l_listmkireference (pkg_indice_utility.cst_mki_asellus).mki_counter;
        l_mkihirudinaecount :=
            l_listmkireference (pkg_indice_utility.cst_mki_hirudinea).mki_counter;
        l_mkitubificidaecount :=
            l_listmkireference (pkg_indice_utility.cst_mki_tubificidae).mki_counter;
        l_mkiinsectacount := pkg_indice_utility.f_getgblinsectacount;



        l_mkierrornumber := pkg_indice_utility.f_getmkierror;
        l_mkitotalcounter := pkg_indice_utility.f_getgblmkitotalcounter;

        l_reccodevalue :=
            pkg_codevalue.f_getfromcode (l_cvl_code_mkicase,
                                         pkg_codereference.cst_crf_mkicase);
        l_mkirangecount := pkg_indice_utility.f_getgblrangecount;
        l_cvl_id_mkicase := l_reccodevalue.cvl_id;

        pkg_importmassdataheader.p_updatemkiinfodata (
            p_recmassdataheader.imh_id,
            l_cvl_id_mkicase,
            l_mkiinsectacount,
            l_mkinonisectacount,
            l_mkirangecount,
            l_mkiplecopteracount,
            l_mkitricopteracount,
            l_mkiephemeropteracount,
            l_mkibaetidaecount,
            l_mkigammaruscount,
            l_mkihydropsychecount,
            l_mkiaselluscount,
            l_mkihirudinaecount,
            l_mkitubificidaecount,
            l_mkierrornumber);
    END;

    /*-------------------------------------------------------------------------------*/
    FUNCTION f_formatdetailcounter (p_paragraphelevel1   IN PLS_INTEGER,
                                    p_paragraphelevel2   IN PLS_INTEGER,
                                    p_paragraphelevel3   IN PLS_INTEGER)
        RETURN VARCHAR2
    /*--------------------------------------------------------------------------------*/
    IS
    BEGIN
        IF p_paragraphelevel3 IS NULL AND p_paragraphelevel2 IS NULL
        THEN
            RETURN TRIM (TO_CHAR (p_paragraphelevel1));
        ELSIF p_paragraphelevel3 IS NULL
        THEN
            RETURN    TRIM (TO_CHAR (p_paragraphelevel1))
                   || '.'
                   || TRIM (TO_CHAR (p_paragraphelevel2));
        ELSE
            RETURN    TRIM (TO_CHAR (p_paragraphelevel1))
                   || '.'
                   || TRIM (TO_CHAR (p_paragraphelevel2))
                   || '.'
                   || TRIM (TO_CHAR (p_paragraphelevel3));
        END IF;
    END;



    /*-------------------------------------------------------------------------------*/
    PROCEDURE p_mkidisplayonecategory (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN importmassdataheader%ROWTYPE,
        p_crf_code                  IN codereference.crf_code%TYPE)
    /*--------------------------------------------------------------------------------*/
    IS
        cst_crf_code_null      CONSTANT VARCHAR2 (10) := 'ZZZZZZZZZ';
        l_mkidispatchlist               pkg_indice_utility.t_mkidispatchlist;
        l_mkisublist                    pkg_indice_utility.t_mkisublist;
        l_reccodereference              codereference%ROWTYPE;
        l_reccodereferencemaster        codereference%ROWTYPE;
        l_master_indice                 PLS_INTEGER;
        l_sub_indice                    PLS_INTEGER;
        l_recsystvalue                  systvalue%ROWTYPE;
        l_recsystdesignation            systdesignation%ROWTYPE;
        l_recmkiidentifygroupcounter    mkiidentifygroupcounter%ROWTYPE;
        l_systdesignationmaster         systdesignation%ROWTYPE;
        l_first_indice                  PLS_INTEGER;
        l_list_infere                   VARCHAR2 (4096);
        l_paragraphe1                   PLS_INTEGER;
        l_paragraphe2                   PLS_INTEGER;
        l_paragraphe3                   PLS_INTEGER;
        l_paragraphetxt                 VARCHAR2 (256);
        l_insectacount                  PLS_INTEGER;
        l_noninsectacount               PLS_INTEGER;
        l_isinsecta                     CHAR (1);
        l_mkigroupinhierarcyexception   NUMBER;
    BEGIN
        l_mkidispatchlist := pkg_indice_utility.f_getgblmkidispatchlist;

        CASE UPPER (NVL (p_crf_code, cst_crf_code_null))
            WHEN pkg_codereference.cst_crf_species
            THEN
                l_paragraphe1 := 1;
                l_paragraphe2 := 1;
                l_paragraphe3 := 1;
                l_paragraphetxt :=
                    f_formatdetailcounter (l_paragraphe1, NULL, NULL);
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    p_recmassdataheader.imh_id,                      -- IMH_ID
                    pkg_exception.cst_mkiunitdetailspecies,
                    NULL,
                    l_paragraphetxt);
            WHEN pkg_codereference.cst_crf_genus
            THEN
                l_paragraphe1 := 2;
                l_paragraphe2 := 0;
                l_paragraphe3 := 0;
                l_paragraphetxt :=
                    f_formatdetailcounter (l_paragraphe1, NULL, NULL);
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    p_recmassdataheader.imh_id,                      -- IMH_ID
                    pkg_exception.cst_mkiunitdetailgenus,
                    NULL,
                    l_paragraphetxt);
            WHEN pkg_codereference.cst_crf_family
            THEN
                l_paragraphe1 := 3;
                l_paragraphe2 := 0;
                l_paragraphe3 := 0;
                l_paragraphetxt :=
                    f_formatdetailcounter (l_paragraphe1, NULL, NULL);
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    p_recmassdataheader.imh_id,                      -- IMH_ID
                    pkg_exception.cst_mkiunitdetailfamily,
                    NULL,
                    l_paragraphetxt);
            WHEN pkg_codereference.cst_crf_phylum -- Le niveau phylum est chois comme taxon sup
            THEN
                l_paragraphe1 := 4;
                l_paragraphe2 := 0;
                l_paragraphe3 := 0;
                l_paragraphetxt :=
                    f_formatdetailcounter (l_paragraphe1, NULL, NULL);
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    p_recmassdataheader.imh_id,                      -- IMH_ID
                    pkg_exception.cst_mkiunitdetailtaxonsup,
                    NULL,
                    l_paragraphetxt);
            ELSE
                NULL;
        END CASE;



        l_master_indice := l_mkidispatchlist.FIRST;

        IF NOT p_crf_code IS NULL
        THEN
            l_reccodereference :=
                pkg_codereference.f_getrecordbycode (p_crf_code);
        END IF;

        l_insectacount := 0;
        l_noninsectacount := 0;

        WHILE NOT l_master_indice IS NULL
        LOOP
            l_recmkiidentifygroupcounter :=
                pkg_mkiidentifygroupcounter.f_getrecordbysyvid (
                    l_master_indice);
            l_systdesignationmaster :=
                pkg_systdesignation.f_getrecdesignationbylancode (
                    l_master_indice,
                    pkg_language.cst_lan_cde_latin);


            IF l_recmkiidentifygroupcounter.mig_crf_id_level_trap =
               NVL (l_reccodereference.crf_id,
                    l_recmkiidentifygroupcounter.mig_crf_id_level_trap)
            THEN
                -- On est au niveau d'affichage souhaité
                l_isinsecta :=
                    pkg_indice_utility.f_mkiisinsecta (l_master_indice);
                l_paragraphe2 := l_paragraphe2 + 1;
                l_paragraphetxt :=
                    f_formatdetailcounter (l_paragraphe1,
                                           l_paragraphe2,
                                           NULL);
                l_reccodereferencemaster :=
                    pkg_codereference.f_getrecord (
                        l_recmkiidentifygroupcounter.mig_crf_id);

                IF l_isinsecta = pkg_constante.cst_yes
                THEN
                    l_mkigroupinhierarcyexception :=
                        pkg_exception.cst_mkigroupinhierarcyinsecta;
                ELSE
                    l_mkigroupinhierarcyexception :=
                        pkg_exception.cst_mkigrouphierachynoinsecta;
                END IF;

                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    p_recmassdataheader.imh_id,                      -- IMH_ID
                    l_mkigroupinhierarcyexception,
                    NULL,
                    l_paragraphetxt,
                    l_systdesignationmaster.syd_designation,
                    l_reccodereferencemaster.crf_code);

                l_mkisublist := l_mkidispatchlist (l_master_indice);
                l_sub_indice := l_mkisublist.FIRST;
                l_paragraphe3 := 0;

                IF l_isinsecta = pkg_constante.cst_yes
                THEN
                    l_insectacount := l_insectacount + l_mkisublist.COUNT;
                ELSE
                    l_noninsectacount :=
                        l_noninsectacount + l_mkisublist.COUNT;
                END IF;

                WHILE NOT l_sub_indice IS NULL
                LOOP
                    l_paragraphe3 := l_paragraphe3 + 1;
                    l_paragraphetxt :=
                        f_formatdetailcounter (l_paragraphe1,
                                               l_paragraphe2,
                                               l_paragraphe3);

                    IF l_sub_indice < 0
                    THEN
                        l_first_indice :=
                            l_mkisublist (l_sub_indice).sub_mkistartsyvidsublist.FIRST;
                        l_recsystdesignation :=
                            pkg_systdesignation.f_getrecdesignationbylancode (
                                l_mkisublist (l_sub_indice).sub_mkistartsyvidsublist (
                                    l_first_indice),
                                pkg_language.cst_lan_cde_latin);
                        pkg_importprotocollog.p_writelog (
                            p_recimportprotocolheader.iph_id,
                            p_recmassdataheader.imh_id,              -- IMH_ID
                            pkg_exception.cst_mkispinferedby,
                            NULL,
                            l_paragraphetxt,
                            pkg_indice_utility.cst_species_code,
                            l_recsystdesignation.syd_designation);
                    ELSE
                        --  %p1%. %p2% (%p3% %p4% inféré depuis %p5%)
                        -- 1.1 Habroleptoides (GENUS Habroleptoides  inféré depuis balbla.
                        l_list_infere :=
                            pkg_indice_utility.f_mkibuilddesignationstart (
                                l_mkisublist (l_sub_indice));
                        l_recsystdesignation :=
                            pkg_systdesignation.f_getrecdesignationbylancode (
                                l_sub_indice,
                                pkg_language.cst_lan_cde_latin);
                        pkg_importprotocollog.p_writelog (
                            p_recimportprotocolheader.iph_id,
                            p_recmassdataheader.imh_id,              -- IMH_ID
                            pkg_exception.cst_mkispinferedby,
                            NULL,
                            l_paragraphetxt,
                            l_recsystdesignation.syd_designation,
                            l_list_infere);
                    END IF;


                    l_sub_indice := l_mkisublist.NEXT (l_sub_indice);
                END LOOP;


                NULL;
            END IF;

            l_master_indice := l_mkidispatchlist.NEXT (l_master_indice);
        END LOOP;

        pkg_importprotocollog.p_writelog (
            p_recimportprotocolheader.iph_id,
            p_recmassdataheader.imh_id,                              -- IMH_ID
            pkg_exception.cst_mkisubtotalinsecta,
            NULL,
            TO_CHAR (l_insectacount),
            TO_CHAR (l_noninsectacount));
    END;

    /*-------------------------------------------------------------------------------*/
    PROCEDURE p_mkidisplaycategory (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN importmassdataheader%ROWTYPE)
    /*--------------------------------------------------------------------------------*/
    IS
    -- Affiche dans le journal la liste des regroupements

    BEGIN
        pkg_importprotocollog.p_writelog (p_recimportprotocolheader.iph_id,
                                          p_recmassdataheader.imh_id, -- IMH_ID
                                          pkg_exception.cst_mkiunitdetail,
                                          NULL);
        p_mkidisplayonecategory (p_recimportprotocolheader,
                                 p_recmassdataheader,
                                 pkg_codereference.cst_crf_species);
        p_mkidisplayonecategory (p_recimportprotocolheader,
                                 p_recmassdataheader,
                                 pkg_codereference.cst_crf_genus);
        p_mkidisplayonecategory (p_recimportprotocolheader,
                                 p_recmassdataheader,
                                 pkg_codereference.cst_crf_family);
        p_mkidisplayonecategory (p_recimportprotocolheader,
                                 p_recmassdataheader,
                                 pkg_codereference.cst_crf_phylum);
    END;

    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_calculatemakroindex (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN     importmassdataheader%ROWTYPE,
        p_canbecomputemki           IN     BOOLEAN, -- Les donnéee nécessaire sont disponibles dans le thésaurus
        p_mkiindice                    OUT NUMBER)
    /*----------------------------------------------------------------------------*/
    IS
        l_valueindicemki               NUMBER;
        l_recavaliabilitycalendarmki   avaliabilitycalendar%ROWTYPE;
        l_reccodevaluemakroindex       codevalue%ROWTYPE;
        l_date                         DATE;
        l_elevation                    NUMBER;
        l_makroindexvalueprovided      NUMBER := 0;
        l_reccodevaluemkicase          codevalue%ROWTYPE;
        l_listmkireference             pkg_makroindex.t_listmkireference;
    BEGIN
        p_mkiindice := NULL;

        IF p_recmassdataheader.imh_mkicanbecalculated = pkg_constante.cst_no
        THEN
            RETURN;
        END IF;

        IF NOT p_canbecomputemki
        THEN
            RETURN;
        END IF;

        l_reccodevaluemakroindex :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_makroindex);



        l_date := NULL;

        IF     NOT p_recmassdataheader.imh_day IS NULL
           AND NOT p_recmassdataheader.imh_month IS NULL
        THEN
            IF NOT p_recmassdataheader.imh_year IS NULL
            THEN
                l_date :=
                    pkg_datatype.f_validatedate (
                           p_recmassdataheader.imh_day
                        || '/'
                        || p_recmassdataheader.imh_month
                        || '/'
                        || p_recmassdataheader.imh_year);
            ELSE
                l_date :=
                    pkg_datatype.f_validatedate (
                           p_recmassdataheader.imh_day
                        || '/'
                        || p_recmassdataheader.imh_month
                        || '/2004');
            END IF;
        END IF;

        l_elevation := NULL;

        IF NOT p_recmassdataheader.imh_elevation IS NULL
        THEN
            l_elevation :=
                pkg_datatype.f_validateswisselev (
                    p_recmassdataheader.imh_elevation);
        END IF;

        IF NOT l_date IS NULL
        THEN
            l_recavaliabilitycalendarmki :=
                pkg_avaliabilitycalendar.f_getrecordbyindicetypeanddate (
                    l_reccodevaluemakroindex.cvl_id,
                    l_date,
                    l_elevation);
        END IF;

        pkg_makroindex.p_maincompute (p_recimportprotocolheader,
                                      p_recmassdataheader,
                                      l_valueindicemki);


        IF     NOT l_valueindicemki IS NULL
           AND l_valueindicemki != pkg_makroindex.cst_mkinotset
        THEN
            p_mkiindice := l_valueindicemki;
            pkg_importmassdataheader.p_updatemakroindex (
                p_recmassdataheader.imh_id,
                l_valueindicemki,
                l_recavaliabilitycalendarmki.iac_cvl_id_midatwindow);
            l_reccodevaluemkicase :=
                pkg_codevalue.f_getrecordbycode (
                    pkg_codereference.cst_crf_mkicase,
                    pkg_makroindex.f_getmkicvlcodecase);
            l_listmkireference := pkg_makroindex.f_getgblmkireference;
            pkg_importmassdataheader.p_updatemkiinfodata (
                p_recmassdataheader.imh_id,                        -- p_imh_id
                l_reccodevaluemkicase.cvl_id,              -- p_cvl_id_mkicase
                pkg_makroindex.f_getmkinoninsectacount,   -- p_mkiinsectacount
                pkg_makroindex.f_getmkinoninsectacount, -- p_mkinonisectacount       I
                NULL,                                       -- p_mkirangecount
                l_listmkireference (pkg_makroindex.cst_mki_plecoptera).mki_counter, --p_mkiplecopteracount
                l_listmkireference (pkg_makroindex.cst_mki_trichoptera).mki_counter, --p_mkitricopteracount
                l_listmkireference (pkg_makroindex.cst_mki_ephemeroptera).mki_counter, --p_mkiephemeropteracount
                l_listmkireference (pkg_makroindex.cst_mki_baetidae).mki_counter, --p_mkigaetidaecount
                l_listmkireference (pkg_makroindex.cst_mki_gammarus).mki_counter, --p_mkigammaruscount
                l_listmkireference (pkg_makroindex.cst_mki_hydropsyche).mki_counter, --p_mkihydropsychecount
                l_listmkireference (pkg_makroindex.cst_mki_asellus).mki_counter, --p_mkiaselluscount
                l_listmkireference (pkg_makroindex.cst_mki_hirudinea).mki_counter, -- p_mkihirudinaecount
                l_listmkireference (pkg_makroindex.cst_mki_tubificidae).mki_counter, -- p_mkitubificidaecount
                pkg_makroindex.f_getmkierror               -- p_mkierrornumber
                                            );



            --La valeur %p1% de l'indice %p2% calculé se situe dans la catégorie f$returncategory#1(%p3%,%p4%). Liste des catégories existantes: f$returnlistcategory#1(%p5%)
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                p_recmassdataheader.imh_id,                          -- IMH_ID
                pkg_exception.cst_displayindexcategory,
                NULL,                                            -- Field name
                TO_CHAR (l_valueindicemki, '9999'),
                pkg_codevalue.cst_midatindice_makroindex,
                pkg_codevalue.cst_midatindice_makroindex,
                TO_CHAR (l_valueindicemki, '9999'),
                pkg_codevalue.cst_midatindice_makroindex);
            l_makroindexvalueprovided :=
                pkg_datatype.f_validatedouble (
                    p_recmassdataheader.imh_makroindexprovide);

            IF NOT l_makroindexvalueprovided IS NULL
            THEN
                IF l_makroindexvalueprovided != l_valueindicemki
                THEN
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        NULL,
                        pkg_exception.cst_indicevaluemissmatch,
                        NULL,                                    -- Filed name
                        TO_CHAR (l_makroindexvalueprovided),
                        pkg_codevalue.cst_midatindice_makroindex,
                        TO_CHAR (l_valueindicemki));
                ELSE
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        NULL,
                        pkg_exception.cst_indicevaluematch,
                        NULL,                                    -- Filed name
                        TO_CHAR (l_makroindexvalueprovided),
                        pkg_codevalue.cst_midatindice_makroindex);
                END IF;
            END IF;
        ELSE                       -- l_valueindicemki est  null ou est  NOSET
            pkg_importmassdataheader.p_updatemkierrornumber (
                p_recmassdataheader.imh_id,
                pkg_makroindex.f_getmkierror);
        END IF;
    END;

    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_calculateibchindex (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN     importmassdataheader%ROWTYPE,
        p_ibchindice                   OUT NUMBER)
    /*----------------------------------------------------------------------------*/
    IS
        l_valueindiceibch               NUMBER;
        l_recavaliabilitycalendaribch   avaliabilitycalendar%ROWTYPE;
        l_reccodevalueibch              codevalue%ROWTYPE;
        l_date                          DATE;
        l_elevation                     NUMBER;
        l_ibchindexprovided             NUMBER := 0;
        l_ibchidentifiedtaxoncounter    NUMBER := 0;
        l_ibchvt                        NUMBER := 0;
        l_ibchgi                        NUMBER := 0;
    BEGIN
        p_ibchindice := NULL;
        l_date := NULL;
        l_reccodevalueibch :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_ibch);



        IF     NOT p_recmassdataheader.imh_day IS NULL
           AND NOT p_recmassdataheader.imh_month IS NULL
        THEN
            IF NOT p_recmassdataheader.imh_year IS NULL
            THEN
                l_date :=
                    pkg_datatype.f_validatedate (
                           p_recmassdataheader.imh_day
                        || '/'
                        || p_recmassdataheader.imh_month
                        || '/'
                        || p_recmassdataheader.imh_year);
            ELSE
                l_date :=
                    pkg_datatype.f_validatedate (
                           p_recmassdataheader.imh_day
                        || '/'
                        || p_recmassdataheader.imh_month
                        || '/2004');
            END IF;
        END IF;

        l_elevation := NULL;

        IF NOT p_recmassdataheader.imh_elevation IS NULL
        THEN
            l_elevation :=
                pkg_datatype.f_validateswisselev (
                    p_recmassdataheader.imh_elevation);
        END IF;

        IF NOT l_date IS NULL
        THEN
            l_recavaliabilitycalendaribch :=
                pkg_avaliabilitycalendar.f_getrecordbyindicetypeanddate (
                    l_reccodevalueibch.cvl_id,
                    l_date,
                    l_elevation);
        END IF;

        pkg_importprotocollog.p_writelog (p_recimportprotocolheader.iph_id,
                                          p_recmassdataheader.imh_id, -- IMH_ID
                                          pkg_exception.cst_computeoneindice,
                                          NULL,                  -- Field name
                                          pkg_codevalue.cst_midatindice_ibch);


        /* Le calcul de l'IBCH est réalisable de deux manières.
         1) Si l'utilisateur a fourni un protocol avec la colonne IBCHTAXON alors la valeur
                       l_recmassdataheader.imh_ibchcanbecalculated = pkg_constante.cst_yes
              et on calcul comme l'IBCH du protocole de laboratoire
          2) Si la colonne n'est pas renseigné on utilise le SYV_ID pour trouver le PLT_ID

        */



        pkg_ibch.p_maincompute (p_recimportprotocolheader,
                                p_recmassdataheader,
                                l_valueindiceibch);


        l_ibchidentifiedtaxoncounter :=
            pkg_indice_utility.f_getgblibchidentifiedtaxoncou;

        IF l_valueindiceibch = 0
        THEN
            -- L'indice IBCH est défini avec la valeur 0 en raison de l'absence significative de taxons indicateurs
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                NULL,                                                -- IMH_ID
                pkg_exception.cst_midatnotaxonindicator,
                NULL);
            RETURN;
        END IF;

        IF NOT l_valueindiceibch IS NULL
        THEN
            p_ibchindice := l_valueindiceibch;
            pkg_importmassdataheader.p_updateibchindex (
                p_recmassdataheader.imh_id,
                l_valueindiceibch,
                l_recavaliabilitycalendaribch.iac_cvl_id_midatwindow);
            l_ibchvt := pkg_ibch.f_getgblibchvt;
            l_ibchgi := pkg_ibch.f_getgblibchgi;
            pkg_importmassdataheader.p_updateibchinfodata (
                p_recmassdataheader.imh_id,
                l_ibchidentifiedtaxoncounter,
                l_ibchgi,
                l_ibchvt);

            IF l_valueindiceibch = 0
            THEN
                -- L'indice IBCH est défini avec la valeur 0 en raison de l'absence significative de taxons indicateurs
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    NULL,                                            -- IMH_ID
                    pkg_exception.cst_midatnotaxonindicator,
                    NULL);
            END IF;

            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                p_recmassdataheader.imh_id,                          -- IMH_ID
                pkg_exception.cst_displayindexcategory,
                NULL,                                            -- Field name
                TO_CHAR (l_valueindiceibch, '9999'),
                pkg_codevalue.cst_midatindice_ibch,
                pkg_codevalue.cst_midatindice_ibch,
                TO_CHAR (l_valueindiceibch, '9999'),
                pkg_codevalue.cst_midatindice_ibch);

            l_ibchindexprovided :=
                pkg_datatype.f_validatedouble (
                    p_recmassdataheader.imh_ibchindexprovide);

            IF NOT l_ibchindexprovided IS NULL
            THEN
                IF l_ibchindexprovided != l_valueindiceibch
                THEN
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        NULL,
                        pkg_exception.cst_indicevaluemissmatch,
                        NULL,                                    -- Filed name
                        TO_CHAR (l_ibchindexprovided),
                        pkg_codevalue.cst_midatindice_ibch,
                        TO_CHAR (l_valueindiceibch));
                ELSE
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        NULL,
                        pkg_exception.cst_indicevaluematch,
                        NULL,                                    -- Filed name
                        TO_CHAR (l_ibchindexprovided),
                        pkg_codevalue.cst_midatindice_ibch);
                END IF;
            END IF;
        END IF;

        NULL;
    END;

    /*-----------------------------------------------------------------------------*/
    PROCEDURE p_calculatespearindex (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN     importmassdataheader%ROWTYPE,
        p_indicespear                  OUT NUMBER)
    /*----------------------------------------------------------------------------*/
    IS
        l_valueindicespear               NUMBER;
        l_recavaliabilitycalendarspear   avaliabilitycalendar%ROWTYPE;
        l_reccodevaluespear              codevalue%ROWTYPE;
        l_date                           DATE;
        l_elevation                      NUMBER;
        l_spearindexprovided             NUMBER := 0;
        l_spearidentifiedtaxoncount      NUMBER := 0;
    BEGIN
        p_indicespear := NULL;
        l_date := NULL;


        l_reccodevaluespear :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                pkg_codevalue.cst_midatindice_spear);


        IF     NOT p_recmassdataheader.imh_day IS NULL
           AND NOT p_recmassdataheader.imh_month IS NULL
        THEN
            IF NOT p_recmassdataheader.imh_year IS NULL
            THEN
                l_date :=
                    pkg_datatype.f_validatedate (
                           p_recmassdataheader.imh_day
                        || '/'
                        || p_recmassdataheader.imh_month
                        || '/'
                        || p_recmassdataheader.imh_year);
            ELSE
                l_date :=
                    pkg_datatype.f_validatedate (
                           p_recmassdataheader.imh_day
                        || '/'
                        || p_recmassdataheader.imh_month
                        || '/2004');
            END IF;
        END IF;

        l_elevation := NULL;

        IF NOT p_recmassdataheader.imh_elevation IS NULL
        THEN
            l_elevation :=
                pkg_datatype.f_validateswisselev (
                    p_recmassdataheader.imh_elevation);
        END IF;

        IF NOT l_date IS NULL
        THEN
            l_recavaliabilitycalendarspear :=
                pkg_avaliabilitycalendar.f_getrecordbyindicetypeanddate (
                    l_reccodevaluespear.cvl_id,
                    l_date,
                    l_elevation);
        END IF;

        pkg_importprotocollog.p_writelog (
            p_recimportprotocolheader.iph_id,
            p_recmassdataheader.imh_id,                              -- IMH_ID
            pkg_exception.cst_computeoneindice,
            NULL,                                                -- Field name
            pkg_codevalue.cst_midatindice_spear);

        pkg_spear.p_maincompute (p_recimportprotocolheader,
                                 p_recmassdataheader,
                                 l_valueindicespear);

        IF NOT l_valueindicespear IS NULL
        THEN
            p_indicespear := l_valueindicespear;
            l_spearidentifiedtaxoncount :=
                pkg_spear.f_getgblidentifiedtaxoncount;
            pkg_importmassdataheader.p_updatespearindex (
                p_recmassdataheader.imh_id,
                l_valueindicespear,
                l_recavaliabilitycalendarspear.iac_cvl_id_midatwindow);
            pkg_importmassdataheader.p_updatespearinfodata (
                p_recmassdataheader.imh_id,
                l_spearidentifiedtaxoncount);
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                p_recmassdataheader.imh_id,                          -- IMH_ID
                pkg_exception.cst_displayindexcategory,
                NULL,                                            -- Field name
                TO_CHAR (l_valueindicespear, '9999'),
                pkg_codevalue.cst_midatindice_spear,
                pkg_codevalue.cst_midatindice_spear,
                TO_CHAR (l_valueindicespear, '9999'),
                pkg_codevalue.cst_midatindice_spear);


            l_spearindexprovided :=
                pkg_datatype.f_validatedouble (
                    p_recmassdataheader.imh_spearindexprovide);

            IF NOT l_spearindexprovided IS NULL
            THEN
                IF l_spearindexprovided != l_valueindicespear
                THEN
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        NULL,
                        pkg_exception.cst_indicevaluemissmatch,
                        NULL,                                    -- Filed name
                        TO_CHAR (l_spearindexprovided),
                        pkg_codevalue.cst_midatindice_spear,
                        TO_CHAR (l_valueindicespear));
                ELSE
                    pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        NULL,
                        pkg_exception.cst_indicevaluematch,
                        NULL,                                    -- Filed name
                        TO_CHAR (l_spearindexprovided),
                        pkg_codevalue.cst_midatindice_spear);
                END IF;
            END IF;
        END IF;
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_addstring (p_string IN VARCHAR2, p_addon IN VARCHAR2)
        RETURN VARCHAR2
    /*--------------------------------------------------------------*/
    IS
        l_string   VARCHAR2 (1024);
    BEGIN
        IF p_string IS NULL
        THEN
            RETURN p_addon;
        ELSE
            RETURN p_string || ', ' || p_addon;
        END IF;
    END;



    /*----------------------------------------------------------------------------*/
    PROCEDURE p_calculateindiceoneheader (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN importmassdataheader%ROWTYPE,
        p_canbecomputemki           IN BOOLEAN) -- Les donnéee nécessaire sont disponibles dans le thésaurus
    /*----------------------------------------------------------------------------*/
    IS
        l_recprotocolmappingmassmap   protocolmappingmassmap%ROWTYPE;
        l_spearindexcalculation       BOOLEAN;
        l_makroindexcalculation       BOOLEAN;
        l_ibchindexcalculation        BOOLEAN;
        l_reclanguage                 language%ROWTYPE;
        l_reccodevalueibch            codevalue%ROWTYPE;
        l_reccodevaluemakroindex      codevalue%ROWTYPE;
        l_reccodevaluespear           codevalue%ROWTYPE;
        l_date                        DATE;
        l_elevation                   NUMBER;
        l_valueindicemki              NUMBER := NULL;
        l_valueindiceibch             NUMBER := NULL;
        l_valueindicespear            NUMBER := NULL;
        l_calculateindicemkierror     BOOLEAN := FALSE;
        l_calculateindiceibcherror    BOOLEAN := FALSE;
        l_calculateindicespearerror   BOOLEAN := FALSE;
        l_indiceerrorlist             VARCHAR2 (256);
        l_valid                       BOOLEAN := TRUE;
        l_listindiceacalculer         VARCHAR2 (1024);
    BEGIN
        pkg_importmassdataheader.p_returnindexcalculation (
            p_recmassdataheader.imh_id,
            l_spearindexcalculation,
            l_makroindexcalculation,
            l_ibchindexcalculation);

        IF l_ibchindexcalculation
        THEN
            l_spearindexcalculation := TRUE; -- Le spearindex doit toujours être calculé avec l'IBCH
        END IF;

        IF l_makroindexcalculation
        THEN
            l_spearindexcalculation := TRUE; -- Le spearindex doit toujours être calculé avec le makroindex
        END IF;

        IF l_spearindexcalculation
        THEN
            l_listindiceacalculer :=
                f_addstring (l_listindiceacalculer,
                             pkg_codevalue.cst_midatindice_spear);
        END IF;

        IF l_ibchindexcalculation
        THEN
            l_listindiceacalculer :=
                f_addstring (l_listindiceacalculer,
                             pkg_codevalue.cst_midatindice_ibch);
        END IF;

        IF l_makroindexcalculation
        THEN
            l_listindiceacalculer :=
                f_addstring (l_listindiceacalculer,
                             pkg_codevalue.cst_midatindice_makroindex);
        END IF;


        l_recprotocolmappingmassmap :=
            pkg_protocolmappingmassmap.f_getrecordbymidatfldcmt (
                p_recimportprotocolheader.iph_ptv_id,
                p_recimportprotocolheader.iph_lan_id,
                pkg_codevalue.cst_midatfldcmt_indicetype);

        IF p_recmassdataheader.imh_indicetype IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                p_recmassdataheader.imh_id,                          -- IMH_ID
                pkg_exception.cst_indexcalculationnotrestric,
                NULL,                                            -- Field name
                l_recprotocolmappingmassmap.pma_aliascolumnname);
        ELSE
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                p_recmassdataheader.imh_id,                          -- IMH_ID
                pkg_exception.cst_indexcalculationrectricted,
                NULL,                                            -- Field name
                l_recprotocolmappingmassmap.pma_aliascolumnname,
                l_listindiceacalculer);
        END IF;

        l_reclanguage :=
            pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);

        IF l_makroindexcalculation AND p_canbecomputemki
        THEN
            p_calculatemakroindex (p_recimportprotocolheader,
                                   p_recmassdataheader,
                                   p_canbecomputemki,
                                   l_valueindicemki);

            IF (   l_valueindicemki IS NULL
                OR l_valueindicemki = pkg_indice_utility.cst_mkinotset)
            THEN
                l_calculateindicemkierror := TRUE;

                IF l_indiceerrorlist IS NULL
                THEN
                    l_indiceerrorlist :=
                        pkg_codevalue.cst_midatindice_makroindex;
                ELSE
                    l_indiceerrorlist :=
                        pkg_codevalue.cst_midatindice_makroindex;
                END IF;
            END IF;
        END IF;

        IF l_ibchindexcalculation
        THEN
            p_calculateibchindex (p_recimportprotocolheader,
                                  p_recmassdataheader,
                                  l_valueindiceibch);

            IF NVL (l_valueindiceibch, 0) = 0
            THEN
                l_calculateindiceibcherror := TRUE;

                IF l_indiceerrorlist IS NULL
                THEN
                    l_indiceerrorlist := pkg_codevalue.cst_midatindice_ibch;
                ELSE
                    l_indiceerrorlist := pkg_codevalue.cst_midatindice_ibch;
                END IF;
            END IF;
        END IF;

        IF l_spearindexcalculation
        THEN
            p_calculatespearindex (p_recimportprotocolheader,
                                   p_recmassdataheader,
                                   l_valueindicespear);

            IF l_valueindicespear IS NULL
            THEN
                l_calculateindicespearerror := TRUE;

                IF l_indiceerrorlist IS NULL
                THEN
                    l_indiceerrorlist := pkg_codevalue.cst_midatindice_spear;
                ELSE
                    l_indiceerrorlist := pkg_codevalue.cst_midatindice_spear;
                END IF;
            END IF;
        END IF;

        l_valid := FALSE;

        IF l_makroindexcalculation AND NOT l_calculateindicemkierror
        THEN
            l_valid := TRUE;
        END IF;

        IF l_ibchindexcalculation AND NOT l_calculateindiceibcherror
        THEN
            l_valid := TRUE;
        END IF;

        IF l_spearindexcalculation AND NOT l_calculateindicespearerror
        THEN
            l_valid := TRUE;
        END IF;

        IF NOT l_valid
        THEN
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                p_recmassdataheader.imh_id,                          -- IMH_ID
                pkg_exception.cst_indexuncalculated,
                NULL,                                            -- Field name
                l_indiceerrorlist);
            pkg_importmassdataheader.p_setvalidstatus (
                p_recmassdataheader.imh_id,
                pkg_constante.cst_validstatusnotok);
        END IF;
    END;


    /*----------------------------------------------------------*/
    PROCEDURE p_test
    /*-----------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_returnstatus              NUMBER;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (12);
        p_calculateindiceforallheader (l_recimportprotocolheader,
                                       2,
                                       1,
                                       l_returnstatus);
    END;


    /*--------------------------------------------------------------*/

    PROCEDURE p_calculateindiceforallheader (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_usr_id                    IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_lan_id                    IN     language.lan_id%TYPE,
        p_returnstatus                 OUT NUMBER)
    /*---------------------------------------------------------------*/

    IS
        /* Calcul les indices MAKROINDEX et IBCH  */
        CURSOR l_massdataheader
        IS
            SELECT *
              FROM importmassdataheader
             WHERE     imh_iph_id = p_recimportprotocolheader.iph_id
                   AND imh_validstatus = pkg_constante.cst_validstatusok; -- A ce stade, tout doit être contrôler et le status doit être valide



        l_recmassdataheader            l_massdataheader%ROWTYPE;



        l_returnstatus                 NUMBER;
        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_canbecomputemki              BOOLEAN := TRUE;
        l_valueindicemki               NUMBER;
        l_valueindiceibch              NUMBER;
        l_valueindicespear             NUMBER;
        l_countheader                  NUMBER;
        l_currentindice                NUMBER := 0;
        l_returnstatusmki1             NUMBER;
        l_returnstatusmki2             NUMBER;
        l_datahasmkicomputed           CHAR (1);
        l_spearindexcalculation        BOOLEAN;
        l_makroindexcalculation        BOOLEAN;
        l_ibchindexcalculation         BOOLEAN;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        pkg_importmassdataheader.p_returnindexcalculationforall (
            p_recimportprotocolheader.iph_id,
            l_spearindexcalculation,
            l_makroindexcalculation,
            l_ibchindexcalculation);
        l_countheader :=
            pkg_importmassdataheader.f_countrowsstatusvalid (
                p_recimportprotocolheader.iph_id);
        pkg_processingstatus.p_setbarstatusdisplaylimit (1);
        pkg_processingstatus.p_setstep (p_recimportprotocolheader.iph_pid_id,
                                        pkg_processingstep.cst_computeindice,
                                        p_lan_id,
                                        p_usr_id);                  -- Step 10
        pkg_importprotocollog.p_writelog (
            p_recimportprotocolheader.iph_id,
            NULL,                                                    -- IMH_ID
            pkg_exception.cst_computedmassindice,
            NULL);                                               -- Field name



        IF l_makroindexcalculation
        THEN
            pkg_indice_utility.p_mkicheckthesaurus (
                p_recimportprotocolheader,
                p_usr_id,
                p_lan_id,
                l_returnstatusmki1);
            pkg_indice_utility.p_checkmkiidentifylist (
                p_recimportprotocolheader,
                p_usr_id,
                p_lan_id,
                l_returnstatusmki2);
        ELSE
            l_returnstatusmki1 := pkg_constante.cst_returnstatusok;
            l_returnstatusmki2 := pkg_constante.cst_returnstatusok;
        END IF;

        IF    l_returnstatusmki1 != pkg_constante.cst_returnstatusok
           OR l_returnstatusmki2 != pkg_constante.cst_returnstatusok
        THEN
            l_canbecomputemki := FALSE;
        END IF;

        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                p_recimportprotocolheader.iph_id,
                pkg_codevalue.cst_midatfldcmt_taxonibch);

        IF l_ibchindexcalculation
        THEN
            IF NOT l_recimportmassmappingheader.ime_id IS NULL
            THEN
                -- La colonne IBCHTAXON a été fournie

                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    NULL,                                            -- IMH_ID
                    pkg_exception.cst_taxonibchcolumnexist,
                    NULL,                                        -- Field name
                    l_recimportmassmappingheader.ime_excelfieldname);
            ELSE
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    NULL,                                            -- IMH_ID
                    pkg_exception.cst_taxonibchcolumnnotexist,
                    NULL);
            END IF;                                              -- Field name
        END IF;

        OPEN l_massdataheader;

        LOOP
            FETCH l_massdataheader INTO l_recmassdataheader;

            EXIT WHEN l_massdataheader%NOTFOUND;
            l_currentindice := l_currentindice + 1;


            -- Traitement du protocole: Cours d'eau %p1%, localité: %p2%, date du prélèvement: %p3%, coordonnée: %p4%, altitude %p5%


            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                l_recmassdataheader.imh_id,                          -- IMH_ID
                pkg_exception.cst_displayprocessheaderinfo,
                NULL,                                            -- Field name
                l_recmassdataheader.imh_watercourse,
                l_recmassdataheader.imh_locality,
                pkg_stringutil.f_formatdate (l_recmassdataheader.imh_day,
                                             l_recmassdataheader.imh_month,
                                             l_recmassdataheader.imh_year),
                   '('
                || pkg_stringutil.f_formatnumber (
                       l_recmassdataheader.imh_startpoint_x)
                || '; '
                || pkg_stringutil.f_formatnumber (
                       l_recmassdataheader.imh_startpoint_y)
                || ')',
                pkg_stringutil.f_formatnumber (
                    l_recmassdataheader.imh_elevation));

            p_calculateindiceoneheader (p_recimportprotocolheader,
                                        l_recmassdataheader,
                                        l_canbecomputemki);
            pkg_processingstatus.p_setstatusbar (l_currentindice,
                                                 l_countheader);
        END LOOP;

        CLOSE l_massdataheader;
    END;

    /*--------------------------------------------------------------*/

    PROCEDURE p_updatevalidstatus (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        -- On met à jour le status de l'entête si un détail en invalide
        UPDATE importmassdataheader
           SET imh_validstatus = pkg_constante.cst_validstatusnotok
         WHERE     imh_id IN
                       (SELECT DISTINCT imd_imh_id
                          FROM importmassdatadetail
                         WHERE imd_validstatus =
                               pkg_constante.cst_validstatusnotok)
               AND imh_iph_id = p_recimportprotocolheader.iph_id
               AND imh_validstatus != pkg_constante.cst_validstatusnotok;

        -- On met à jour les status provisoires
        UPDATE importmassdatadetail
           SET imd_validstatus = pkg_constante.cst_validstatusok
         WHERE     imd_validstatus = pkg_constante.cst_validstatuspending
               AND imd_imh_id IN
                       (SELECT imh_id
                          FROM importmassdataheader
                         WHERE     imh_iph_id =
                                   p_recimportprotocolheader.iph_id
                               AND imh_validstatus =
                                   pkg_constante.cst_validstatusok);
    END;

    /*---------------------------------------------------------------*/

    PROCEDURE p_clearlistmassfield
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        gbl_massfield.delete;
    END;

    /*----------------------------------------------------------------*/

    PROCEDURE p_addmassfield (p_field IN VARCHAR2)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        pkg_debug.p_write ('pkg_validatemassheaderp_addmassfield', p_field);

        IF NOT gbl_massfield.EXISTS (p_field)
        THEN
            gbl_massfield (p_field).l_count := 1;
        ELSE
            gbl_massfield (p_field).l_count :=
                gbl_massfield (p_field).l_count + 1;
        END IF;
    END;

    /*------------------------------------------------------------------*/

    FUNCTION f_findbydatabasefield (
        p_databasefield   IN protocolmappingmassfield.pmm_columnname%TYPE)
        RETURN VARCHAR2
    /*------------------------------------------------------------------*/
    IS
        l_field   VARCHAR2 (256);
        l_found   BOOLEAN := FALSE;
    BEGIN
        l_field := gbl_massfield.FIRST;

        WHILE NOT l_field IS NULL AND NOT l_found
        LOOP
            IF gbl_massfield (l_field).l_count > 0
            THEN
                IF gbl_massfield (l_field).l_databasefield = p_databasefield
                THEN
                    l_found := TRUE;
                END IF;
            END IF;

            l_field := gbl_massfield.NEXT (l_field);
        END LOOP;

        RETURN l_field;
    END;

    /*------------------------------------------------------------------*/

    PROCEDURE p_checkrequiredgroupfield (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_returnstatus                 OUT NUMBER)
    /*------------------------------------------------------------------*/
    IS
        CURSOR l_listgroup
        IS
            SELECT DISTINCT pmm_isnotnullgroup
              FROM protocolmappingmassfield
             WHERE     NOT pmm_isnotnullgroup IS NULL
                   AND pmm_ptv_id = p_recimportprotocolheader.iph_ptv_id;

        l_reclistgroup   l_listgroup%ROWTYPE;

        CURSOR l_listfield (
            p_group   IN protocolmappingmassfield.pmm_isnotnullgroup%TYPE)
        IS
            SELECT pmm_columnname
              FROM protocolmappingmassfield
             WHERE     pmm_isnotnullgroup = p_group
                   AND pmm_ptv_id = p_recimportprotocolheader.iph_ptv_id;

        l_reclistfield   l_listfield%ROWTYPE;
        l_field          VARCHAR2 (256);
        l_textfield      VARCHAR2 (512);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        OPEN l_listgroup;

        LOOP
            FETCH l_listgroup INTO l_reclistgroup;

            EXIT WHEN l_listgroup%NOTFOUND;
            l_textfield := NULL;

            OPEN l_listfield (l_reclistgroup.pmm_isnotnullgroup);

            l_field := NULL;

            LOOP
                FETCH l_listfield INTO l_reclistfield;

                EXIT WHEN l_listfield%NOTFOUND OR NOT l_field IS NULL;

                IF l_textfield IS NULL
                THEN
                    l_textfield := l_reclistfield.pmm_columnname;
                ELSE
                    l_textfield :=
                        l_textfield || ',' || l_reclistfield.pmm_columnname;
                END IF;

                l_field :=
                    f_findbydatabasefield (l_reclistfield.pmm_columnname);
            END LOOP;

            IF l_field IS NULL
            THEN
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    NULL,
                    pkg_exception.cst_requiredgrpfieldmissing,
                    NULL,
                    l_textfield);                                        -- p1
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
            END IF;

            CLOSE l_listfield;
        END LOOP;

        CLOSE l_listgroup;
    END;

    /*------------------------------------------------------------------*/

    PROCEDURE p_validatemapping (
        p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_lan_id                 IN     protocolmappingmassmap.pma_lan_id%TYPE, -- Langue de l'interface
        p_returnstatus              OUT NUMBER)
    /*------------------------------------------------------------------*/
    IS
        l_reccodelanguage      language%ROWTYPE;

        l_reccodedesignation   codedesignation%ROWTYPE;
    BEGIN
        pkg_protocolmappingmassmap.p_checkexistmapping (
            p_importprotocolheader.iph_lan_id,
            p_importprotocolheader.iph_ptv_id,
            p_returnstatus);

        IF p_returnstatus != pkg_constante.cst_returnstatusok
        THEN
            -- Invalide. On va cherche le nom de la langue dans la langue de l'interface
            l_reccodelanguage :=
                pkg_language.f_getrecord (p_importprotocolheader.iph_lan_id);
            l_reccodedesignation :=
                pkg_codedesignation.f_getrecordbycode (
                    l_reccodelanguage.lan_code,
                    pkg_codereference.cst_crf_lantranslate,
                    p_lan_id);
            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_massmappingnotexist,
                NULL,
                l_reccodedesignation.cdn_designation);                   -- p1
        END IF;
    END;

    /*------------------------------------------------------------------*/

    PROCEDURE p_checkextendedfield (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_returnstatus                 OUT NUMBER)
    /*------------------------------------------------------------------*/
    IS
        /* Règle: Si la colonne PR est définie, la colonne SYSTEM_PRECISION doit aussi l'être et vis et versa */
        l_recprotocolmappingsystemprec   protocolmappingmassfield%ROWTYPE;
        l_recprotocolmappingprec         protocolmappingmassfield%ROWTYPE;
        l_fieldaliassystemprec           VARCHAR2 (256);
        l_fieldaliasprec                 VARCHAR2 (256);
        l_recprotocolmappingmassmap1     protocolmappingmassmap%ROWTYPE;
        l_recprotocolmappingmassmap2     protocolmappingmassmap%ROWTYPE;
        l_reccorddesignation1            codedesignation%ROWTYPE;
        l_reccorddesignation2            codedesignation%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_recprotocolmappingsystemprec :=
            pkg_protocolmappingmassfield.f_getfromcode (
                pkg_codevalue.cst_midatfldcmt_systemprec,
                p_recimportprotocolheader.iph_ptv_id);

        l_recprotocolmappingprec :=
            pkg_protocolmappingmassfield.f_getfromcode (
                pkg_codevalue.cst_midatfldcmt_prec,
                p_recimportprotocolheader.iph_ptv_id);
        l_fieldaliassystemprec :=
            f_findbydatabasefield (
                l_recprotocolmappingsystemprec.pmm_columnname);
        l_fieldaliasprec :=
            f_findbydatabasefield (l_recprotocolmappingprec.pmm_columnname);

        IF l_fieldaliassystemprec IS NULL AND l_fieldaliasprec IS NULL
        THEN
            -- Aucun des deux champs n'est définis. Pas de problème
            RETURN;
        END IF;

        IF     NOT l_fieldaliassystemprec IS NULL
           AND NOT l_fieldaliasprec IS NULL
        THEN
            -- Les deux champs  sont définis. Pas de problème
            RETURN;
        END IF;

        p_returnstatus := pkg_constante.cst_returnstatusnotok;
        pkg_debug.p_write ('pkg_validatemassheader.p_checkextendedfield',
                           'eRROR');

        -- On affiche le message d'erreur
        l_recprotocolmappingmassmap1 :=
            pkg_protocolmappingmassmap.f_getrecordbypmm_id (
                p_recimportprotocolheader.iph_lan_id,
                l_recprotocolmappingsystemprec.pmm_id);
        l_recprotocolmappingmassmap2 :=
            pkg_protocolmappingmassmap.f_getrecordbypmm_id (
                p_recimportprotocolheader.iph_lan_id,
                l_recprotocolmappingprec.pmm_id);
        --  l_recprotocolmappingmassmap(n).PMA_ALIASCOLUMNNAME on a la valeur de l'entête de la colonne
        l_reccorddesignation1 :=
            pkg_codedesignation.f_getrecordbycode (
                l_recprotocolmappingsystemprec.pmm_code_midatfldcmt,
                pkg_codereference.cst_crf_midatfldcmt,
                p_recimportprotocolheader.iph_lan_id);

        l_reccorddesignation2 :=
            pkg_codedesignation.f_getrecordbycode (
                l_recprotocolmappingprec.pmm_code_midatfldcmt,
                pkg_codereference.cst_crf_midatfldcmt,
                p_recimportprotocolheader.iph_lan_id);

        --    l_reccorddesignation(n).cdn_designation contient le texte associé à la colonne
        pkg_debug.p_write ('pkg_validatemassheader.p_checkextendedfield',
                           'l_fieldaliassystemprec EST null');

        IF l_fieldaliassystemprec IS NULL
        THEN
            --Si la colonne "%p1%" (%p2%)  est définei dans la feuille Excel alors la colonne "%p3%" (%p4%) doit aussi être définie
            pkg_debug.p_write (
                'pkg_validatemassheader.p_checkextendedfield',
                   ' l_recprotocolmappingmassmap2.pma_aliascolumnname='
                || l_recprotocolmappingmassmap2.pma_aliascolumnname);
            pkg_debug.p_write (
                'pkg_validatemassheader.p_checkextendedfield',
                   ' l_recprotocolmappingmassmap2.pma_aliascolumnname='
                || l_recprotocolmappingmassmap1.pma_aliascolumnname);

            pkg_debug.p_write (
                'pkg_validatemassheader.p_checkextendedfield',
                   '  l_reccorddesignation2.cdn_designation='
                || l_reccorddesignation2.cdn_designation);
            pkg_debug.p_write (
                'pkg_validatemassheader.p_checkextendedfield',
                   '  l_reccorddesignation1.cdn_designation='
                || l_reccorddesignation1.cdn_designation);
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                NULL,                                                -- IMH_ID
                pkg_exception.cst_invalidcombination,
                   l_recprotocolmappingprec.pmm_columnname
                || ', '
                || l_recprotocolmappingsystemprec.pmm_columnname, -- Field name
                l_recprotocolmappingmassmap2.pma_aliascolumnname,      -- prec
                l_reccorddesignation2.cdn_designation,
                l_recprotocolmappingmassmap1.pma_aliascolumnname, -- systemprec
                l_reccorddesignation1.cdn_designation);
        ELSE
            pkg_debug.p_write ('pkg_validatemassheader.p_checkextendedfield',
                               'l_fieldaliasprec EST null');
            pkg_importprotocollog.p_writelog (
                p_recimportprotocolheader.iph_id,
                NULL,                                                -- IMH_ID
                pkg_exception.cst_invalidcombination,
                   l_recprotocolmappingprec.pmm_columnname
                || ', '
                || l_recprotocolmappingsystemprec.pmm_columnname, -- Field name
                l_recprotocolmappingmassmap1.pma_aliascolumnname, -- systemprec
                l_reccorddesignation1.cdn_designation,
                l_recprotocolmappingmassmap2.pma_aliascolumnname,      -- prec
                l_reccorddesignation2.cdn_designation);
        END IF;

        --


        NULL;
    END;


    /*------------------------------------------------------------------*/

    PROCEDURE p_checkrequiredfield (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_returnstatus                 OUT NUMBER)
    /*------------------------------------------------------------------*/
    IS
        CURSOR l_protocolmappingmassfield
        IS
            SELECT *
              FROM protocolmappingmassfield
             WHERE     pmm_ptv_id = p_recimportprotocolheader.iph_ptv_id
                   AND pmm_isnotnull = pkg_constante.cst_yes;

        l_recprotocolmappingmassfield   l_protocolmappingmassfield%ROWTYPE;
        l_field                         VARCHAR2 (256);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        OPEN l_protocolmappingmassfield;

        LOOP
            FETCH l_protocolmappingmassfield
                INTO l_recprotocolmappingmassfield;

            EXIT WHEN l_protocolmappingmassfield%NOTFOUND;
            l_field :=
                f_findbydatabasefield (
                    l_recprotocolmappingmassfield.pmm_columnname);


            IF l_field IS NULL
            THEN
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    NULL,
                    pkg_exception.cst_requiredfieldmissing,
                    NULL,
                    l_recprotocolmappingmassfield.pmm_columnname);       -- p1
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
            END IF;
        END LOOP;

        CLOSE l_protocolmappingmassfield;

        NULL;
    END;

    /*------------------------------------------------------------------*/

    PROCEDURE p_checkautorizedfield (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_returnstatus                 OUT NUMBER)
    /*------------------------------------------------------------------*/
    IS
        CURSOR l_protocolmappingmassfield
        IS
            SELECT *
              FROM protocolmappingmassfield
             WHERE     pmm_ptv_id = p_recimportprotocolheader.iph_ptv_id
                   AND pmm_isnotnull = pkg_constante.cst_yes;

        l_recprotocolmappingmassfield   l_protocolmappingmassfield%ROWTYPE;

        l_autorized                     VARCHAR2 (10);
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        OPEN l_protocolmappingmassfield;

        LOOP
            FETCH l_protocolmappingmassfield
                INTO l_recprotocolmappingmassfield;

            EXIT WHEN l_protocolmappingmassfield%NOTFOUND;
            l_autorized :=
                pkg_protocolmassfieldrole.f_userhasright (
                    p_recimportprotocolheader.iph_usr_id_create,
                    l_recprotocolmappingmassfield.pmm_id);



            IF l_autorized = pkg_constante.cst_no
            THEN
                -- Vous ne disposez pas des droits nécessaires pour charger la colonne %p1%.
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    NULL,
                    pkg_exception.cst_norightforloadcolumn,
                    NULL,
                    l_recprotocolmappingmassfield.pmm_columnname);       -- p1
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
            END IF;
        END LOOP;

        CLOSE l_protocolmappingmassfield;

        NULL;
    END;


    /*------------------------------------------------------------------*/

    PROCEDURE p_checkexistingfield (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_returnstatus                 OUT NUMBER)
    /*------------------------------------------------------------------*/
    IS
        l_field                         VARCHAR2 (256);
        l_recprotocolmappingmassfield   protocolmappingmassfield%ROWTYPE;
    BEGIN
        pkg_debug.p_setdebugmode (TRUE);
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_field := gbl_massfield.FIRST;

        WHILE NOT l_field IS NULL
        LOOP
            pkg_debug.p_write (
                'PKG_VALIDATEMASSHEADER.p_checkexistingfield',
                   'l_field='
                || l_field
                || 'p_recimportprotocolheader.iph_ptv_id='
                || p_recimportprotocolheader.iph_ptv_id
                || ' p_recimportprotocolheader.iph_lan_id='
                || p_recimportprotocolheader.iph_lan_id);


            l_recprotocolmappingmassfield :=
                pkg_protocolmappingmassfield.f_getfromaliascolumnname (
                    l_field,
                    p_recimportprotocolheader.iph_ptv_id,
                    p_recimportprotocolheader.iph_lan_id);

            IF l_recprotocolmappingmassfield.pmm_id IS NULL
            THEN
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    NULL,
                    pkg_exception.cst_unknownheaderfield,
                    NULL,
                    l_field);                                            -- p1
                gbl_massfield (l_field).l_count := -1;
            ELSE
                gbl_massfield (l_field).l_databasefield :=
                    l_recprotocolmappingmassfield.pmm_columnname;
            END IF;

            l_field := gbl_massfield.NEXT (l_field);
        END LOOP;
    END;

    /*------------------------------------------------------------------*/

    PROCEDURE p_checkfieldduplicated (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_returnstatus                 OUT NUMBER)
    /*------------------------------------------------------------------*/
    IS
        l_field   VARCHAR2 (256);
        l_count   PLS_INTEGER;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;
        l_field := gbl_massfield.FIRST;

        WHILE NOT l_field IS NULL
        LOOP
            l_count := gbl_massfield (l_field).l_count;

            IF l_count > 1
            THEN
                pkg_importprotocollog.p_writelog (
                    p_recimportprotocolheader.iph_id,
                    NULL,
                    pkg_exception.cst_duplicateheaderfield,
                    NULL,
                    l_field,                                             -- p1
                    TO_CHAR (l_count));
                gbl_massfield (l_field).l_count := -1;
                p_returnstatus := pkg_constante.cst_returnstatusnotok;
            END IF;

            l_field := gbl_massfield.NEXT (l_field);
        END LOOP;
    END;


    /*------------------------------------------------------------------*/

    PROCEDURE p_mastervalidate (p_iph_id IN importprotocolheader.iph_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
        l_returnstatus              NUMBER;
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        pkg_debug.p_write ('pkg_validatemassheader.p_mastervalidate',
                           'p_iph_id=' || p_iph_id);
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);
        p_checkfieldduplicated (l_recimportprotocolheader, l_returnstatus);
        p_checkexistingfield (l_recimportprotocolheader, l_returnstatus);
        p_checkrequiredfield (l_recimportprotocolheader, l_returnstatus);
        p_checkrequiredgroupfield (l_recimportprotocolheader, l_returnstatus);
        p_checkextendedfield (l_recimportprotocolheader, l_returnstatus);
        p_checkautorizedfield (l_recimportprotocolheader, l_returnstatus);
        pkg_debug.p_write ('pkg_validatemassheader.p_mastervalidate',
                           'l_returnstatus=' || l_returnstatus);
    END;



    /*-----------------------------------------------------------------*/

    PROCEDURE p_listmassfield
    /*------------------------------------------------------------------*/
    IS
        l_key   VARCHAR2 (256);
    BEGIN
        l_key := gbl_massfield.FIRST;

        WHILE NOT l_key IS NULL
        LOOP
            DBMS_OUTPUT.put_line (
                'L_KEY:=' || l_key || '-> ' || gbl_massfield (l_key).l_count);
            l_key := gbl_massfield.NEXT (l_key);
        END LOOP;
    END;

    /*----------------------------------------------------------------*/

    PROCEDURE p_checkheaderallreadyexist (
        p_iph_id         IN     importprotocolheader.iph_id%TYPE,
        p_returnstatus      OUT NUMBER)
    /*----------------------------------------------------------------*/
    IS
        /* Doit être appelé en dernier après les validations de détail */
        l_xyz               VARCHAR2 (256);
        l_date              VARCHAR2 (100);
        l_listexcelline     VARCHAR2 (2048);

        CURSOR l_listheader
        IS
            SELECT *
              FROM importmassdataheader
             WHERE     imh_iph_id = p_iph_id
                   AND imh_validstatus = pkg_constante.cst_validstatusok;

        l_reclistheader     l_listheader%ROWTYPE;
        l_recsampleheader   sampleheader%ROWTYPE;
    BEGIN
        p_returnstatus := pkg_constante.cst_returnstatusok;

        OPEN l_listheader;

        LOOP
            FETCH l_listheader INTO l_reclistheader;

            EXIT WHEN l_listheader%NOTFOUND;
            l_recsampleheader :=
                pkg_sampleheader.f_findheaderbyimportmassheader (
                    l_reclistheader);

            IF NOT l_recsampleheader.sph_id IS NULL
            THEN
                IF l_reclistheader.imh_elevation IS NULL
                THEN
                    l_xyz :=
                           l_reclistheader.imh_startpoint_x
                        || '; '
                        || l_reclistheader.imh_startpoint_y
                        || '; <null>';
                ELSE
                    l_xyz :=
                           l_reclistheader.imh_startpoint_x
                        || '; '
                        || l_reclistheader.imh_startpoint_y
                        || '; '
                        || l_reclistheader.imh_elevation;
                END IF;

                l_date :=
                       NVL (l_reclistheader.imh_day, '<null>')
                    || '/'
                    || NVL (l_reclistheader.imh_month, '<null>')
                    || '/'
                    || l_reclistheader.imh_year;
                l_listexcelline :=
                    pkg_importmassdatadetail.f_buildsourceline (
                        l_reclistheader.imh_id);
                pkg_importprotocollog.p_writelog (
                    l_reclistheader.imh_iph_id,
                    NULL,
                    pkg_exception.cst_massdataheaderallreadyexis,
                    NULL,
                    l_xyz,
                    l_date,
                    l_listexcelline);
                pkg_importmassdataheader.p_setvalidstatuscascade (
                    l_reclistheader.imh_id,
                    pkg_constante.cst_validstatusallreadyexist);
            END IF;
        END LOOP;

        CLOSE l_listheader;
    END;

    /*----------------------------------------------------------------*/

    PROCEDURE p_test2
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        p_clearlistmassfield;
        p_addmassfield ('TEST');
        p_addmassfield ('TEST');
        p_addmassfield ('TOTO');
        p_listmassfield;
    END;
END pkg_validatemassheader;
/

