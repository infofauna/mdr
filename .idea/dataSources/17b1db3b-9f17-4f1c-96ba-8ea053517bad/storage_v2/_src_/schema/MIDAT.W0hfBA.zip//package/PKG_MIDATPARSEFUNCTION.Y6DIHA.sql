create PACKAGE       pkg_midatparsefunction
AS
   /******************************************************************************
      NAME:       PKG_MIDATPARSEFUNCTION
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.07.2013   F.Burri          1. Created this package.
   ******************************************************************************/
   TYPE t_listfunction IS TABLE OF VARCHAR2 (30);

   cst_parse_returnlistcategory   CONSTANT VARCHAR2 (30)
                                              := 'f$returnlistcategory' ;
   cst_parse_returncategory       CONSTANT VARCHAR2 (30)
                                              := 'f$returncategory' ;

   cst_parse_returnusecase        CONSTANT VARCHAR2 (30) := 'f$returnusecase';

   cst_parse_returncanton         CONSTANT VARCHAR2 (30) := 'f$returncanton';

   cst_parse_returnlanguage       CONSTANT VARCHAR2 (30)
                                              := 'f$returnlanguage' ;

   cst_parse_validstatus          CONSTANT VARCHAR2 (30)
                                              := 'f$returnvalidstatus' ;

   cst_parse_returnlistsyst       CONSTANT VARCHAR2 (30)
                                              := 'f$returnlistsyst' ;

   cst_parse_returndatatype       CONSTANT VARCHAR2 (30)
                                              := 'f$returndatatype' ;

   cst_parse_returnmidatgrnd      CONSTANT VARCHAR2 (30)
                                              := 'f$returnmidatgrnd' ;

   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_parseallfunction (p_line     IN VARCHAR2,
                                p_lan_id   IN language.lan_id%TYPE)
      RETURN VARCHAR2;



   PROCEDURE p_test;

   PROCEDURE p_test1;
END pkg_midatparsefunction;
/

