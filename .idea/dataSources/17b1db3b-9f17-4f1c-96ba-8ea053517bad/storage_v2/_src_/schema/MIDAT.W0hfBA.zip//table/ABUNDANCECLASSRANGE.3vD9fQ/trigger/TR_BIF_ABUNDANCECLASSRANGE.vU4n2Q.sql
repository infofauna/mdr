create trigger TR_BIF_ABUNDANCECLASSRANGE
    before insert
    on ABUNDANCECLASSRANGE
    for each row
DECLARE
BEGIN
   IF :new.ACR_id IS NULL
   THEN
      :new.ACR_id := seq_ABUNDANCECLASSRANGE.NEXTVAL;
   END IF;

   :new.ACR_credate := SYSDATE;
   :new.ACR_creuser := USER;
END tr_bif_ABUNDANCECLASSRANGE;

/

