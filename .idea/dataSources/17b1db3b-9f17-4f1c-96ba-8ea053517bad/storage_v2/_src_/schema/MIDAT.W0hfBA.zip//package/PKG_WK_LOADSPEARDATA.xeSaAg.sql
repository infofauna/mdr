create PACKAGE       PKG_WK_LOADSPEARDATA AS
/******************************************************************************
   NAME:       PKG_WK_LOADSPEARDATA
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        25/07/2014      burrif       1. Created this package.
******************************************************************************/
   FUNCTION f_getversion
      RETURN VARCHAR2;


END PKG_WK_LOADSPEARDATA;
/

