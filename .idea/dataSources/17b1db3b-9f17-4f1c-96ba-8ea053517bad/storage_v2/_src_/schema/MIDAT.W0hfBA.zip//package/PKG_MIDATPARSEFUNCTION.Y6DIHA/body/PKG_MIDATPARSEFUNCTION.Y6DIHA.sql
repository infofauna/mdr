create PACKAGE BODY       pkg_midatparsefunction
AS
    /******************************************************************************
       NAME:       PKG_MIDATPARSEFUNCTION
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       25.07.2013  F.Burri           1. Created this package body.
    ******************************************************************************/

    /* Utilisation:
     Les messages doivvent être formatté comme suit: "Les catégorie existantes sont returnlistcategory#1(%p1%)"
     Le paramètre doit d'abord être remplace comme pour un message normal.
     Puis la fonction f_parseallfunction doit être appelé
     */

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2014';
    gbl_listfunction     t_listfunction := t_listfunction ();

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_initlistfunction
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        gbl_listfunction.EXTEND (1);
        gbl_listfunction (gbl_listfunction.LAST) :=
            pkg_midatparsefunction.cst_parse_returnlistcategory;
        gbl_listfunction.EXTEND (1);
        gbl_listfunction (gbl_listfunction.LAST) :=
            pkg_midatparsefunction.cst_parse_returncategory;
        gbl_listfunction.EXTEND (1);
        gbl_listfunction (gbl_listfunction.LAST) :=
            pkg_midatparsefunction.cst_parse_returnusecase;
        gbl_listfunction.EXTEND (1);
        gbl_listfunction (gbl_listfunction.LAST) :=
            pkg_midatparsefunction.cst_parse_returncanton;
        gbl_listfunction.EXTEND (1);
        gbl_listfunction (gbl_listfunction.LAST) :=
            pkg_midatparsefunction.cst_parse_returnlanguage;
        gbl_listfunction.EXTEND (1);
        gbl_listfunction (gbl_listfunction.LAST) :=
            pkg_midatparsefunction.cst_parse_validstatus;

        gbl_listfunction.EXTEND (1);
        gbl_listfunction (gbl_listfunction.LAST) :=
            pkg_midatparsefunction.cst_parse_returnlistsyst;

        gbl_listfunction.EXTEND (1);
        gbl_listfunction (gbl_listfunction.LAST) :=
            pkg_midatparsefunction.cst_parse_returndatatype;

        gbl_listfunction.EXTEND (1);
        gbl_listfunction (gbl_listfunction.LAST) :=
            pkg_midatparsefunction.cst_parse_returnmidatgrnd;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_parse_f$returndatatype (
        p_parameters   IN pkg_utility.t_listofvalue,
        p_lan_id       IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*------------------------------------------------------------*/
    IS
        l_indice               PLS_INTEGER;
        l_code_datatype        codevalue.cvl_code%TYPE;
        l_reccodedesignation   codedesignation%ROWTYPE;
    BEGIN
        DBMS_OUTPUT.put_line ('returndatatype');
        l_indice := p_parameters.FIRST;


        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        DBMS_OUTPUT.put_line ('l_indice ' || l_indice);
        l_code_datatype := UPPER (TRIM (p_parameters (l_indice)));

        IF l_code_datatype IS NULL
        THEN
            RETURN NULL;
        END IF;

        DBMS_OUTPUT.put_line (
            'l_code_datatype=' || l_code_datatype || ' p_lan_id=' || p_lan_id);
        pkg_debug.p_write (
            'PKG_MIDATPARSEFUNCTION. f_parse_f$returndatatype',
            'l_code_datatype=' || l_code_datatype || ' p_lan_id=' || p_lan_id);
        l_reccodedesignation :=
            pkg_codedesignation.f_getrecordbycode (
                l_code_datatype,
                pkg_codereference.cst_crf_datatype,
                p_lan_id);
        RETURN l_reccodedesignation.cdn_designation;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_parse_f$returnlanguage (
        p_parameters   IN pkg_utility.t_listofvalue,
        p_lan_id       IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*------------------------------------------------------------*/
    IS
        l_indice               PLS_INTEGER;
        l_lan_id_display       NUMBER;
        l_reccodedesignation   codedesignation%ROWTYPE;
    BEGIN
        l_indice := p_parameters.FIRST;


        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_lan_id_display :=
            pkg_datatype.f_validatedouble (p_parameters (l_indice));

        IF l_lan_id_display IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_reccodedesignation :=
            pkg_language.f_getlangdesignationby_lan_id (l_lan_id_display,
                                                        p_lan_id);
        RETURN l_reccodedesignation.cdn_designation;
    END;


    /*-----------------------------------------------------------*/
    FUNCTION f_parse_f$returnusecase (
        p_parameters   IN pkg_utility.t_listofvalue,
        p_lan_id       IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*------------------------------------------------------------*/
    IS
        l_cvl_code             codevalue.cvl_code%TYPE;
        l_indice               PLS_INTEGER;
        l_reccodevalue         codevalue%ROWTYPE;
        l_reccodedesignation   codedesignation%ROWTYPE;
    BEGIN
        l_indice := p_parameters.FIRST;


        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_cvl_code := p_parameters (l_indice);

        DBMS_OUTPUT.put_line ('l_cvl_code=' || l_cvl_code);
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_mkicase,
                l_cvl_code);

        DBMS_OUTPUT.put_line (
            'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_reccodevalue.cvl_id IS NULL
        THEN
            RETURN NULL;
        END IF;


        l_reccodedesignation :=
            pkg_codedesignation.f_returnrecmaintypeatleastone (
                l_reccodevalue.cvl_id,
                p_lan_id);
        RETURN l_reccodedesignation.cdn_designation;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_parse_f$returnmidatgrnd (
        p_parameters   IN pkg_utility.t_listofvalue,
        p_lan_id       IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*------------------------------------------------------------*/
    IS
        l_cvl_code             codevalue.cvl_code%TYPE;
        l_indice               PLS_INTEGER;
        l_reccodevalue         codevalue%ROWTYPE;
        l_reccodedesignation   codedesignation%ROWTYPE;
    BEGIN
        l_indice := p_parameters.FIRST;


        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_cvl_code := p_parameters (l_indice);

        DBMS_OUTPUT.put_line ('l_cvl_code=' || l_cvl_code);
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatgrnd,
                l_cvl_code);

        DBMS_OUTPUT.put_line (
            'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_reccodevalue.cvl_id IS NULL
        THEN
            RETURN NULL;
        END IF;


        l_reccodedesignation :=
            pkg_codedesignation.f_returnrecmaintypeatleastone (
                l_reccodevalue.cvl_id,
                p_lan_id);
        RETURN l_reccodedesignation.cdn_designation;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_parse_f$returncanton (
        p_parameters   IN pkg_utility.t_listofvalue,
        p_lan_id       IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*------------------------------------------------------------*/
    IS
        l_cvl_code             codevalue.cvl_code%TYPE;
        l_indice               PLS_INTEGER;
        l_reccodevalue         codevalue%ROWTYPE;
        l_reccodedesignation   codedesignation%ROWTYPE;
    BEGIN
        pkg_debug.p_write ('PKG_MIDATPARSEFUNCTION. f_parse_f$returncanton',
                           'Start');
        l_indice := p_parameters.FIRST;


        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        pkg_debug.p_write (
            'PKG_MIDATPARSEFUNCTION. f_parse_f$returncanton',
            'p_parameters (l_indice)=' || p_parameters (l_indice));
        l_cvl_code := p_parameters (l_indice);

        DBMS_OUTPUT.put_line ('l_cvl_code=' || l_cvl_code);
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_canton,
                l_cvl_code);

        DBMS_OUTPUT.put_line (
            'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_reccodevalue.cvl_id IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_reccodedesignation :=
            pkg_codedesignation.f_returnrecmaintypeatleastone (
                l_reccodevalue.cvl_id,
                p_lan_id);
        RETURN l_reccodedesignation.cdn_designation;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_parse_f$returnlistcategory (
        p_parameters   IN pkg_utility.t_listofvalue,
        p_lan_id       IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*----------------------------------------------------------------*/
    IS
        l_listcategory   VARCHAR2 (1024);
        l_reccodevalue   codevalue%ROWTYPE;
        l_cvl_code       codevalue.cvl_code%TYPE;
        l_indice         PLS_INTEGER;
    BEGIN
        l_indice := p_parameters.FIRST;
        DBMS_OUTPUT.put_line ('Start');

        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_cvl_code := p_parameters (l_indice);
        pkg_debug.p_write (
            'PKG_MIDATPARSEFUNCTION.f_parse_f$returnlistcategory',
            l_cvl_code);
        DBMS_OUTPUT.put_line ('L_CVL_CODE=' || l_cvl_code);
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                l_cvl_code);
        DBMS_OUTPUT.put_line (
            'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);

        IF l_reccodevalue.cvl_id IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_listcategory :=
            pkg_biologicalstate.f_returnlistcategory (l_reccodevalue.cvl_id,
                                                      p_lan_id);
        RETURN l_listcategory;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_parse_f$returncategory (
        p_parameters   IN pkg_utility.t_listofvalue,
        p_lan_id       IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*----------------------------------------------------------------*/
    IS
        l_recbiologicalstate   biologicalstate%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
        l_reccodedesignation   codedesignation%ROWTYPE;
        l_cvl_code             codevalue.cvl_code%TYPE;
        l_indice               PLS_INTEGER;
        l_value                NUMBER;
    BEGIN
        l_indice := p_parameters.FIRST;


        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        -- Le paramètre est le code MIDATINDICE

        l_cvl_code := p_parameters (l_indice);
        pkg_debug.p_write ('PKG_MIDATPARSEFUNCTION.f_parse_f$returncategory',
                           'l_cvl_code=' || l_cvl_code);

        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                l_cvl_code);

        IF l_reccodevalue.cvl_id IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_indice := p_parameters.NEXT (l_indice);
        l_value := pkg_datatype.f_validatedouble (p_parameters (l_indice));

        IF l_value IS NULL
        THEN
            RETURN NULL;
        END IF;


        l_recbiologicalstate :=
            pkg_biologicalstate.f_getrecordbyvalue (l_reccodevalue.cvl_id,
                                                    l_value);

        IF l_recbiologicalstate.bls_id IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_reccodedesignation :=
            pkg_codedesignation.f_returnrecmaintypeatleastone (
                l_recbiologicalstate.bls_cvl_id_biolstatetxt,
                p_lan_id);
        RETURN l_reccodedesignation.cdn_designation;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_parse_f$returnvalidstatus (
        p_parameters   IN pkg_utility.t_listofvalue,
        p_lan_id       IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*------------------------------------------------------------*/
    IS
        l_indice               PLS_INTEGER;
        l_code_status          codevalue.cvl_code%TYPE;
        l_reccodedesignation   codedesignation%ROWTYPE;
    BEGIN
        l_indice := p_parameters.FIRST;


        IF l_indice IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_code_status := UPPER (TRIM (p_parameters (l_indice)));

        IF l_code_status IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_reccodedesignation :=
            pkg_codedesignation.f_getrecordbycode (
                l_code_status,
                pkg_codereference.cst_crf_validstatus,
                p_lan_id);
        RETURN l_reccodedesignation.cdn_designation;
    END;

    /*-----------------------------------------------------------*/
    FUNCTION f_parse_f$returnlistsyst (
        p_parameters   IN pkg_utility.t_listofvalue,
        p_lan_id       IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*------------------------------------------------------------*/
    IS
        l_indice               PLS_INTEGER;
        l_code_listsyst        codevalue.cvl_code%TYPE;
        l_reccodedesignation   codedesignation%ROWTYPE;
        l_listsyst             VARCHAR2 (1024);
    BEGIN
        l_listsyst := NULL;
        l_indice := p_parameters.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            l_code_listsyst := UPPER (TRIM (p_parameters (l_indice)));
            DBMS_OUTPUT.put_line (p_parameters (l_indice));
            l_reccodedesignation :=
                pkg_codedesignation.f_getrecordbycode (
                    l_code_listsyst,
                    pkg_codereference.cst_crf_listsyst,
                    p_lan_id);

            IF l_listsyst IS NULL
            THEN
                l_listsyst := l_reccodedesignation.cdn_designation;
            ELSE
                l_listsyst :=
                       l_listsyst
                    || ', '
                    || l_reccodedesignation.cdn_designation;
            END IF;

            l_indice := p_parameters.NEXT (l_indice);
        END LOOP;

        RETURN l_listsyst;
    END;


    /*--------------------------------------------------------------*/
    FUNCTION f_parse (p_function     IN VARCHAR2,
                      p_parameters   IN pkg_utility.t_listofvalue,
                      p_lan_id       IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        IF p_function = pkg_midatparsefunction.cst_parse_returnlistcategory
        THEN
            RETURN f_parse_f$returnlistcategory (p_parameters, p_lan_id);
        END IF;

        IF p_function = pkg_midatparsefunction.cst_parse_returncategory
        THEN
            RETURN f_parse_f$returncategory (p_parameters, p_lan_id);
        END IF;

        IF p_function = pkg_midatparsefunction.cst_parse_returnusecase
        THEN
            RETURN f_parse_f$returnusecase (p_parameters, p_lan_id);
        END IF;

        IF p_function = pkg_midatparsefunction.cst_parse_returncanton
        THEN
            RETURN f_parse_f$returncanton (p_parameters, p_lan_id);
        END IF;

        IF p_function = pkg_midatparsefunction.cst_parse_returnlanguage
        THEN
            RETURN f_parse_f$returnlanguage (p_parameters, p_lan_id);
        END IF;

        IF p_function = pkg_midatparsefunction.cst_parse_validstatus
        THEN
            RETURN f_parse_f$returnvalidstatus (p_parameters, p_lan_id);
        END IF;

        IF p_function = pkg_midatparsefunction.cst_parse_returnlistsyst
        THEN
            RETURN f_parse_f$returnlistsyst (p_parameters, p_lan_id);
        END IF;

        IF p_function = pkg_midatparsefunction.cst_parse_returndatatype
        THEN
            RETURN f_parse_f$returndatatype (p_parameters, p_lan_id);
        END IF;

        IF p_function = pkg_midatparsefunction.cst_parse_returnmidatgrnd
        THEN
            RETURN f_parse_f$returnmidatgrnd (p_parameters, p_lan_id);
        END IF;

        RETURN NULL;
        NULL;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_test
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        pkg_importprotocollog.p_writelog (
            2,
            NULL,
            pkg_exception.cst_taxonlevelmissmatch,
            NULL,
            'Acari',
            'TAXON_DEF',
            'PHYLUM,SUBCLASS');
    END;



    /*----------------------------------------------------------------*/
    FUNCTION f_substitutefunctionstring (
        p_line       IN VARCHAR2,
        p_function   IN VARCHAR2,
        p_lan_id     IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*----------------------------------------------------------------*/
    IS
        l_occurence        PLS_INTEGER; -- Occurence de la fonction à recherche
        l_foundposition    PLS_INTEGER;             -- Position de l'occurence
        l_length           PLS_INTEGER; -- Longeur total de la chaîne à remplacer en prenant en compte les paramètres
        l_listparameters   pkg_utility.t_listofvalue
                               := pkg_utility.t_listofvalue ();
        l_indice           PLS_INTEGER;
        l_line             VARCHAR2 (5012);
        l_value            VARCHAR2 (1024);
    BEGIN
        l_occurence := 0;
        l_foundposition := 9999;
        l_line := p_line;

        WHILE NOT l_foundposition = 0
        LOOP
            l_occurence := l_occurence + 1;
            pkg_utility.p_findfunction (l_line,
                                        p_function,
                                        l_occurence,
                                        l_foundposition,
                                        l_length,
                                        l_listparameters);

            IF l_foundposition > 0
            THEN
                l_value := f_parse (p_function, l_listparameters, p_lan_id);

                l_line :=
                       SUBSTR (l_line, 1, l_foundposition - 1)
                    || l_value
                    || SUBSTR (l_line, l_foundposition + l_length);
            END IF;
        END LOOP;

        RETURN l_line;

        NULL;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_test1
    /*-----------------------------------------------------------------*/
    IS
        l_line    VARCHAR2 (2048);
        l_line1   VARCHAR2 (2048);
    BEGIN
        l_line :=
            'Cas retenu dans la tabelle de référence: f$returnmidatgrnd#1(DEPECHAN) et f$returnmidatgrnd#2(RAISON).';
        l_line1 :=
            f_substitutefunctionstring (l_line, 'f$returnmidatgrnd', 1);
        DBMS_OUTPUT.put_line (l_line1);
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_parseallfunction (p_line     IN VARCHAR2,
                                 p_lan_id   IN language.lan_id%TYPE)
        RETURN VARCHAR2
    /*---------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
        l_line     VARCHAR2 (5012);
    BEGIN
        DBMS_OUTPUT.put_line ('Start parse all');
        l_line := p_line;
        l_indice := gbl_listfunction.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            DBMS_OUTPUT.put_line (
                'Search' || gbl_listfunction (l_indice) || ' Line' || l_line);

            l_line :=
                f_substitutefunctionstring (l_line,
                                            gbl_listfunction (l_indice),
                                            p_lan_id);
            l_indice := gbl_listfunction.NEXT (l_indice);
        END LOOP;

        RETURN l_line;
    END;
BEGIN
    p_initlistfunction;
END pkg_midatparsefunction;
/

