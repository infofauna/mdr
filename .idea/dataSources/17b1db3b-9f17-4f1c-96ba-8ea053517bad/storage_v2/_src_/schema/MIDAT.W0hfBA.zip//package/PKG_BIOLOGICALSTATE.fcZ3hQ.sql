create PACKAGE       pkg_biologicalstate
AS
    /******************************************************************************
       NAME:       pkg_biologicalstate
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        25.09.2013      burrif       1. Created this package.
    ******************************************************************************/


    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_getrecordbyvalue (
        p_cvl_id_midatindice   IN biologicalstate.bls_cvl_id_midatindice%TYPE,
        p_value                IN biologicalstate.bls_fromvalue%TYPE)
        RETURN biologicalstate%ROWTYPE;

    PROCEDURE p_write (
        p_order                 IN     biologicalstate.bls_order%TYPE,
        p_cvl_id_midatindice    IN     biologicalstate.bls_cvl_id_midatindice%TYPE,
        p_cvl_id_biolstatetxt   IN     biologicalstate.bls_cvl_id_biolstatetxt%TYPE,
        p_cvl_id_colorindex     IN     biologicalstate.bls_cvl_id_colorindex%TYPE,
        p_cvl_id_colorindext    IN     biologicalstate.bls_cvl_id_colorindextext%TYPE,
        p_fromvalue             IN     biologicalstate.bls_fromvalue%TYPE,
        p_tovalue               IN     biologicalstate.bls_tovalue%TYPE,
        p_literalrange          IN     biologicalstate.bls_literalrange%TYPE,
        p_ivr_id                IN     biologicalstate.bls_ivr_id%TYPE,
        p_id                       OUT biologicalstate.bls_id%TYPE);

    PROCEDURE p_test;

    FUNCTION f_returnlistcategory (
        p_cvl_id_midatindice   IN biologicalstate.bls_cvl_id_midatindice%TYPE,
        p_lan_id               IN codedesignation.cdn_lan_id%TYPE)
        RETURN VARCHAR2;
END pkg_biologicalstate;
/

