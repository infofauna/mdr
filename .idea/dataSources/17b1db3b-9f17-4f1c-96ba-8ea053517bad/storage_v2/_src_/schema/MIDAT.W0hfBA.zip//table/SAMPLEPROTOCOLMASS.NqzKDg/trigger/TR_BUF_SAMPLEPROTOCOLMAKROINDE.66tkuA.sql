create trigger TR_BUF_SAMPLEPROTOCOLMAKROINDE
    before update
    on SAMPLEPROTOCOLMASS
    for each row
DECLARE
BEGIN


   :new.smx_moddate := SYSDATE;
   :new.smx_moduser := USER;
END tr_buf_sampleprotocolmakroinde;

/

