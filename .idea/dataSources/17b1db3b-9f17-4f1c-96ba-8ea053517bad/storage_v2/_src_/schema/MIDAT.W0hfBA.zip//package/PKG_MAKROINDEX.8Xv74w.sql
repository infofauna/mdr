create PACKAGE       pkg_makroindex
AS
   /******************************************************************************
      NAME:       pkg_MAKROINDEX
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        07/07/2015      burrif       1. Created this package.
   ******************************************************************************/
   cst_abondanceflag_class          CONSTANT VARCHAR2 (10) := 'CLASS';
   cst_abondanceflag_absolu         CONSTANT VARCHAR2 (10) := 'ABS';
   cst_mki_plecoptera               CONSTANT systdesignation.syd_designation%TYPE
                                                := 'Plecoptera' ;
   cst_mki_plecoptera_crf_code      CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_order ;

   cst_mki_trichoptera              CONSTANT systdesignation.syd_designation%TYPE
      := 'Trichoptera' ;
   cst_mki_trichoptera_crf_code     CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_order ;

   cst_mki_ephemeroptera            CONSTANT systdesignation.syd_designation%TYPE
      := 'Ephemeroptera' ;
   cst_mki_ephemeroptera_crf_code   CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_order ;

   cst_mki_baetidae                 CONSTANT systdesignation.syd_designation%TYPE
      := 'Baetidae' ;
   cst_mki_baetidae_crf_code        CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_family ;

   cst_mki_gammarus                 CONSTANT systdesignation.syd_designation%TYPE
      := 'Gammarus' ;
   cst_mki_gammarus_crf_code        CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_genus ;

   cst_mki_hydropsyche              CONSTANT systdesignation.syd_designation%TYPE
      := 'Hydropsyche' ;
   cst_mki_hydropsyche_crf_code     CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_genus ;

   cst_mki_asellus                  CONSTANT systdesignation.syd_designation%TYPE
      := 'Asellus' ;
   cst_mki_asellus_crf_code         CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_genus ;

   cst_mki_hirudinea                CONSTANT systdesignation.syd_designation%TYPE
      := 'Hirudinea' ;
   cst_mki_hirudinea_crf_code       CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_class ;

   cst_mki_tubificidae              CONSTANT systdesignation.syd_designation%TYPE
      := 'Tubificidae' ;
   cst_mki_tubificidae_crf_code     CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_family ;

   cst_mki_insecta                  CONSTANT systdesignation.syd_designation%TYPE
      := 'Insecta' ;
   cst_mki_insecta_crf_code         CONSTANT codereference.crf_code%TYPE
      := pkg_codereference.cst_crf_class ;
   cst_insectaratio_zerodivide      CONSTANT NUMBER := -9999;
   cst_mkinotset                    CONSTANT NUMBER := -1;
   cst_species_code                 CONSTANT VARCHAR2 (3) := 'sp.';
   cst_species_syv_id_addoperator   CONSTANT NUMBER := -1;


   TYPE t_mkireference IS RECORD
   (
      mki_crf_code   codereference.crf_code%TYPE,
      mki_counter    NUMBER
   );

   TYPE t_listmkireference IS TABLE OF t_mkireference
      INDEX BY systdesignation.syd_designation%TYPE;

   TYPE t_mkistartsyvidsublist IS TABLE OF PLS_INTEGER;

   TYPE t_recmkisublist IS RECORD
   (
      sub_mkistartsyvidsublist   t_mkistartsyvidsublist, -- Element de syv_id qui permet de commencer la hiérarchie
      sub_counter                PLS_INTEGER
   );

   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_mkibuilddesignationstart (p_recmkisublist IN t_recmkisublist)
      RETURN VARCHAR2;

   PROCEDURE p_maincompute (
      p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_recmassdataheader         IN     importmassdataheader%ROWTYPE,
      p_mkiindice                    OUT NUMBER);

   PROCEDURE p_test;

   PROCEDURE p_mkiinit;

   PROCEDURE p_mkiadddata (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_syv_id                    IN sampleprotocollabo.spl_syv_id%TYPE);

   FUNCTION f_computemakroindex
      RETURN NUMBER;

   FUNCTION f_getmkinoninsectacount
      RETURN NUMBER;

   FUNCTION f_getmkicvlcodecase
      RETURN codevalue.cvl_code%TYPE;

   FUNCTION f_getmkierror
      RETURN NUMBER;

   FUNCTION f_getgblmkireference
      RETURN t_listmkireference;

   FUNCTION f_getgblmkitotalcounter
      RETURN NUMBER;

   FUNCTION f_getgblmkiinsectaratio
      RETURN NUMBER;

   FUNCTION f_getgblmkiinsectacount
      RETURN NUMBER;

   FUNCTION f_getgblmkirangeselected
      RETURN VARCHAR2;
END pkg_makroindex;
/

