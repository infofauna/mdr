create view V_SPEAR as
SELECT pkg_systdesignation.f_returnpathdesignation (ptl_syv_id, 10, '/') Taxon,
       pkg_speardatalinkcscf.f_routereturnspearindex (ptl_syv_id) SPEARINDEX,
       ipl_value "Abondance",
       ipl_value+1 "x+1",
       log(10, ipl_value+1) "log(x+1)",
       log(10, ipl_value+1)* pkg_speardatalinkcscf.f_routereturnspearindex (ptl_syv_id) "log(x+1)*SPEARINDEX"
       
  FROM importprotocollabo
       INNER JOIN protocolmappinglabo ON ptl_id = ipl_ptl_id
 WHERE ipl_iph_id = 400 AND NVL (ipl_value, 0) > 0
 ORDER BY PTL_ID
/

