create trigger TR_BUF_INDICEHISTORY
    before update
    on INDICEHISTORY
    for each row
DECLARE
BEGIN
 
   :new.IHY_moddate := SYSDATE;
   :new.IHY_moduser := USER;
END tr_buf_INDICEHISTORY;
/

