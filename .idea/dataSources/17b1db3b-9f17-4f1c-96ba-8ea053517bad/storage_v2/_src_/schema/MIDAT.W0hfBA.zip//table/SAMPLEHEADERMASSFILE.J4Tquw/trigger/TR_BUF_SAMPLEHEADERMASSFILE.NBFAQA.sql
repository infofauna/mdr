create trigger TR_BUF_SAMPLEHEADERMASSFILE
    before update
    on SAMPLEHEADERMASSFILE
    for each row
DECLARE
   l_newrec   sampleheadermassfile%ROWTYPE;
   l_oldrec   sampleheadermassfile%ROWTYPE;
BEGIN
   l_oldrec.smf_id := :old.smf_id;
   l_oldrec.smf_status := :old.smf_status;
   l_oldrec.smf_ptv_id := :old.smf_ptv_id;

   l_oldrec.smf_file := :old.smf_file;
   l_oldrec.smf_credate := :old.smf_credate;
   l_oldrec.smf_creuser := :old.smf_creuser;
   l_oldrec.smf_moddate := :old.smf_moddate;
   l_oldrec.smf_moduser := :old.smf_moduser;


   l_newrec.smf_id := :new.smf_id;
   l_newrec.smf_status := :new.smf_status;
   l_newrec.smf_ptv_id := :new.smf_ptv_id;
   l_newrec.smf_file := :new.smf_file;

   l_newrec.smf_credate := :new.smf_credate;
   l_newrec.smf_creuser := :new.smf_creuser;
   l_newrec.smf_moddate := :new.smf_moddate;
   l_newrec.smf_moduser := :new.smf_moduser;

   --   pkg_SAMPLESTATION.p_tr_buf_SAMPLESTATION (l_oldrec, l_newrec);

   :new.smf_id := l_newrec.smf_id;


   :new.smf_ptv_id := l_newrec.smf_ptv_id;
   :new.smf_file := l_newrec.smf_file;

   :new.smf_credate := l_newrec.smf_credate;
   :new.smf_creuser := l_newrec.smf_creuser;
   :new.smf_moddate := l_newrec.smf_moddate;
   :new.smf_moduser := l_newrec.smf_moduser;
END;

/

