create trigger TR_BUF_AVALIABILITYCALENDAR
    before update
    on AVALIABILITYCALENDAR
    for each row
DECLARE
BEGIN
 
   :new.iac_moddate := SYSDATE;
   :new.iac_moduser := USER;
END tr_buf_AVALIABILITYCALENDAR;

/

