create PACKAGE BODY       pkg_processingstep
AS
   /******************************************************************************

      NAME:       PKG_PROCESSINGSTEP

      PURPOSE:



      REVISIONS:

      Ver        Date        Author           Description

      ---------  ----------  ---------------  ------------------------------------

      1.0        11.10.2013      burrif       1. Created this package.

   ******************************************************************************/
   TYPE t_timestampstep IS RECORD
   (
      tim_step                processingstep.psi_stepcode%TYPE,
      tim_systimestampstart   TIMESTAMP,
      tim_systimestampend     TIMESTAMP,
      tim_millisecond         NUMBER
   );

   TYPE t_listtimestampstep IS TABLE OF t_timestampstep;



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;

   gbl_blobsize                  NUMBER := NULL;
   gbl_recordcount               NUMBER := NULL;
   gbl_estimaterecordcount       NUMBER := NULL;
   gbl_fulltime                  NUMBER := NULL;
   gbl_fulltimestatusbarstart    NUMBER := 0;
   gbl_letfttimestatusbarstart   NUMBER := 0;
   gbl_listtimestamp             t_listtimestampstep
                                    := t_listtimestampstep ();
   gbl_lefttime                  NUMBER := NULL;
   gbl_percentdone               NUMBER := 0;
   gbl_currentstep               processingstep.psi_stepcode%TYPE;
   gbl_currentponderation        NUMBER := 0;
   gbl_recprocessingstep         processingstep%ROWTYPE;
   gbl_adjusttime                NUMBER := 0;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/

      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-----------------------------------------------------------*/
   PROCEDURE p_cleargbl
   /*-----------------------------------------------------------*/
   IS
   BEGIN
      gbl_blobsize := NULL;
      gbl_recordcount := NULL;
      gbl_estimaterecordcount := NULL;
      gbl_fulltime := NULL;
      gbl_fulltimestatusbarstart := 0;
      gbl_letfttimestatusbarstart := 0;
      gbl_listtimestamp.delete ();
      gbl_lefttime := NULL;
      gbl_percentdone := 0;
      gbl_currentstep := NULL;
      gbl_currentponderation := 0;

      gbl_adjusttime := 0;
   END;


   /*-----------------------------------------------------------------*/
   FUNCTION f_percentnotcutback (p_percent IN NUMBER)
      RETURN NUMBER
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      IF gbl_percentdone < p_percent
      THEN
         -- Cas normal, le préédent contenu dans gbl_percentdone est plus petit
         gbl_percentdone := p_percent;
         RETURN p_percent;
      ELSE                        --gbl_percentdone est plus grand on retourne
         -- On retourne  le retourne pour pas revenir en arriere
         RETURN gbl_percentdone;
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_listtimestamp
   /*----------------------------------------------------------------*/
   IS
      l_key   PLS_INTEGER;
   BEGIN
      l_key := gbl_listtimestamp.FIRST;

      WHILE NOT l_key IS NULL
      LOOP
         pkg_debug.p_write (
            'PKG_PROCESSINGSTEP.P_LISTTIMESTAMP',
               'Key='
            || l_key
            || ' Delta time='
            || TO_CHAR (gbl_listtimestamp (l_key).tim_millisecond));

         l_key := gbl_listtimestamp.NEXT (l_key);
      END LOOP;
   END;

   /*------------------------------------------------------------------*/
   PROCEDURE p_clearlisttimestamp
   /*-----------------------------------------------------------------*/
   IS
   BEGIN
      gbl_listtimestamp.delete ();
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_setblobsize (p_size IN NUMBER)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      gbl_blobsize := p_size;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_setrecordcount (p_count IN NUMBER)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      gbl_recordcount := p_count;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_saveendtimestamptolist (p_previousstep IN PLS_INTEGER)
   /*-----------------------------------------------------------------*/
   IS
   BEGIN
      gbl_listtimestamp (p_previousstep).tim_systimestampend := SYSTIMESTAMP;
      gbl_listtimestamp (p_previousstep).tim_millisecond :=
         pkg_stringutil.f_returnelapsedtime (
            gbl_listtimestamp (p_previousstep).tim_systimestampend,
            gbl_listtimestamp (p_previousstep).tim_systimestampstart);
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_updatefulltimedetailstep (p_currentstatusbarvalue   IN NUMBER,
                                         p_rowstotal               IN NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_steptimepondere        NUMBER := 0;
      l_nombrerecordpondere    NUMBER := 0;
      l_estimatetime           NUMBER;
      l_deltatime              NUMBER;
      l_adjusttime             NUMBER;
      l_estimatefullsteptime   NUMBER := 0;
   BEGIN
      /* Le processus a déjà réalisé p_currentstatusbarvalue en un delata time défini pas systimestamp - starttimestampstep
        Il était prévu qu'il réalise dans le temp PSI_ELAPSEDTIME un nombre d'enregistrement de PSI_MEASUREVALUE
       */
      -- Le processus devrait mettre ce temp la pour
      IF gbl_recprocessingstep.psi_measurevalue IS NULL
      THEN
         RETURN;                                -- Pas de moyen de comparaison
      END IF;


      l_steptimepondere :=
         gbl_recprocessingstep.psi_elapsedtime * gbl_currentponderation;

      l_nombrerecordpondere :=
         gbl_recprocessingstep.psi_measurevalue * gbl_currentponderation;



      -- Combien de temps a t'il mis
      l_deltatime :=
           pkg_stringutil.f_returnelapsedtime (
              SYSTIMESTAMP,
              gbl_listtimestamp (gbl_listtimestamp.LAST).tim_systimestampstart)
         / 1000;
      -- Conbine de temps mettra t'il au même rithme
      -- l_deltatime - p_currentstatusbarvalue
      -- x -   p_rowstotal
      l_estimatefullsteptime :=
         l_deltatime * p_rowstotal / p_currentstatusbarvalue;

      -- La différence entre temps réelle  et l'estimation  est donc :
      -- Si le l_estimatefullsteptime est plus grand que l'estimation il faut ajouter du temp donc signe +
      -- Si ll'estimation (l_steptimepondere) est plus grande que le temp réele il faut enlever du temps donc signe -
      l_adjusttime := l_estimatefullsteptime - l_steptimepondere;



      gbl_fulltime := gbl_fulltimestatusbarstart + l_adjusttime;

      gbl_lefttime := gbl_letfttimestatusbarstart + l_adjusttime - l_deltatime;
   END;


   /*-----------------------------------------------------------------*/
   PROCEDURE p_computestatusdetailstep (
      p_currentstatusbarvalue   IN     NUMBER, -- Nombre d'enregistrement traité
      p_rowstotal               IN     NUMBER, -- Nombre d'enregistrement total
      p_fulltime                   OUT NUMBER,
      p_lefttime                   OUT NUMBER,
      p_percentdone                OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_deltatime   NUMBER;
   BEGIN
      -- On enleve le temps ecoulé
      p_updatefulltimedetailstep (p_currentstatusbarvalue, p_rowstotal);
      l_deltatime :=
         pkg_stringutil.f_returnelapsedtime (
            SYSTIMESTAMP,
            gbl_listtimestamp (gbl_listtimestamp.LAST).tim_systimestampstart);
      p_lefttime := gbl_lefttime;
      p_fulltime := gbl_fulltime;
      p_percentdone := (p_fulltime - p_lefttime) * 100 / p_fulltime;
      p_percentdone := f_percentnotcutback (p_percentdone);
   END;



   /*-----------------------------------------------------------------*/
   PROCEDURE p_computestatusdetailstep (p_fulltime      OUT NUMBER,
                                        p_lefttime      OUT NUMBER,
                                        p_percentdone   OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_deltatime   NUMBER;
   BEGIN
      -- On enleve le temps ecoulé


      l_deltatime :=
         pkg_stringutil.f_returnelapsedtime (
            SYSTIMESTAMP,
            gbl_listtimestamp (gbl_listtimestamp.LAST).tim_systimestampstart);
      p_lefttime := gbl_lefttime - l_deltatime / 1000;
      p_fulltime := gbl_fulltime;
      p_percentdone := (gbl_fulltime - p_lefttime) * 100 / gbl_fulltime;
      p_percentdone := f_percentnotcutback (p_percentdone);
   END;


   /*----------------------------------------------------------------*/
   PROCEDURE p_returnestimateleftstep (
      p_step                 IN     processingstep.psi_stepcode%TYPE, -- p_step est le step courrant,
      p_effectivevalue       IN     processingstep.psi_measurevalue%TYPE, -- Dernière valeur de référence (Blobsize ou recorcount
      p_totaleffectivetime      OUT NUMBER,
      p_estimatedlefttime       OUT NUMBER)
   /*----------------------------------------------------------------*/
   IS
      CURSOR l_processingstep
      IS
           SELECT *
             FROM processingstep
            WHERE psi_sequence >= (SELECT psi_sequence
                                     FROM processingstep
                                    WHERE psi_stepcode = p_step)
         ORDER BY psi_sequence;

      CURSOR l_processingstepreverse
      IS
           SELECT *
             FROM processingstep
            WHERE psi_sequence < (SELECT psi_sequence
                                    FROM processingstep
                                   WHERE psi_stepcode = p_step)
         ORDER BY psi_sequence DESC;

      l_curprocessingstep    processingstep%ROWTYPE;

      l_key                  PLS_INTEGER;
      l_totaleffectivetime   NUMBER := 0;
      l_measurevalue         processingstep.psi_measurevalue%TYPE;

      l_ponderation          NUMBER := 0;
      l_lefttime             NUMBER := 0;
   BEGIN
      gbl_recprocessingstep :=
         pkg_processingstep.f_getrecordbystepcode (p_step);

      l_key := gbl_listtimestamp.FIRST;



      WHILE     NOT l_key IS NULL
            AND gbl_listtimestamp (l_key).tim_step != p_step --- P_step est le step courrant, il n'est pas fini
      LOOP
         l_totaleffectivetime :=
              l_totaleffectivetime
            + gbl_listtimestamp (l_key).tim_millisecond / 1000;



         l_key := gbl_listtimestamp.NEXT (l_key);
      END LOOP;

      -- Les valeurs contenues dans l_recprocessingstepref.psi_measurevalue et  l_recprocessingstepref.psi_elapsedtime permette de calculer le facteur de
      -- pondération à appliquer aux enregistrements qui ont une valeur dans psi_measurevalue
      -- Sinon, on doit podéré la durée contenu dans PSI_ELAPSEDTIME en fonction du paramètre P_effectivevalue
       /*PSI_ELAPSEDTIME    -    PSI_MEASUREVALUE
                  X                     -   p_effectivevalue
*/


      l_lefttime := 0;

      IF p_effectivevalue IS NULL
      THEN
         l_ponderation := 1;
      ELSE
         l_ponderation := 0;

         OPEN l_processingstepreverse; -- On cherche le précédent paramètre psi_measurevalue pour calculer la pondération

         LOOP
            FETCH l_processingstepreverse INTO l_curprocessingstep;


            EXIT WHEN l_processingstepreverse%NOTFOUND OR l_ponderation != 0;

            IF NOT l_curprocessingstep.psi_measurevalue IS NULL
            THEN
               l_ponderation :=
                  p_effectivevalue / l_curprocessingstep.psi_measurevalue;
            END IF;
         END LOOP;

         CLOSE l_processingstepreverse;

         IF l_ponderation = 0
         THEN                                                  -- Premier step
            l_ponderation := 1;
         END IF;
      END IF;



      OPEN l_processingstep;

      LOOP
         FETCH l_processingstep INTO l_curprocessingstep;

         EXIT WHEN l_processingstep%NOTFOUND;

         IF NOT l_curprocessingstep.psi_measurevalue IS NULL
         THEN
            l_lefttime :=
                 l_lefttime
               + l_curprocessingstep.psi_elapsedtime * l_ponderation;
         ELSE
            l_lefttime := l_lefttime + l_curprocessingstep.psi_elapsedtime;
         END IF;
      END LOOP;

      CLOSE l_processingstep;


      p_totaleffectivetime := l_totaleffectivetime;
      p_estimatedlefttime := l_lefttime;
      gbl_fulltime := l_totaleffectivetime + l_lefttime;
      gbl_fulltimestatusbarstart := gbl_fulltime;
      gbl_lefttime := l_lefttime;
      gbl_currentstep := p_step;
      gbl_currentponderation := l_ponderation;
      gbl_letfttimestatusbarstart := gbl_lefttime;
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_test2
   /*------------------------------------------------------------------*/
   IS
      l_step       processingstep.psi_stepcode%TYPE; -- p_step est le step courrant,
      l_fulltime   NUMBER;
      l_lefttime   NUMBER;
      l_percent    NUMBER;
   BEGIN
      l_step := 'READANDVALID';

      p_computestatusbarmasterstep (l_step,
                                    l_fulltime,
                                    l_lefttime,
                                    l_percent);
      DBMS_OUTPUT.put_line ('l_fulltime=' || l_fulltime);
      DBMS_OUTPUT.put_line ('l_lefttime=' || l_lefttime);
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_test1
   /*------------------------------------------------------------------*/
   IS
      l_step                 processingstep.psi_stepcode%TYPE; -- p_step est le step courrant,
      l_effectivevalue       processingstep.psi_measurevalue%TYPE; -- Dernière valeur de référence (Blobsize ou recorcount
      l_totaleffectivetime   NUMBER;
      l_estimatedlefttime    NUMBER;
   BEGIN
      l_step := 'READANDVALID';
      l_effectivevalue := 1290240;
      p_returnestimateleftstep (l_step,
                                l_effectivevalue,
                                l_totaleffectivetime,
                                l_estimatedlefttime);
      DBMS_OUTPUT.put_line ('l_totaleffectivetime=' || l_totaleffectivetime);
      DBMS_OUTPUT.put_line ('l_estimatedlefttime=' || l_estimatedlefttime);
   END;

   /*------------------------------------------------------------------*/
   PROCEDURE p_test
   /*-------------------------------------------------------------------*/
   IS
      l_step                 processingstep.psi_stepcode%TYPE; -- p_step est le step courrant,
      l_effectivevalue       processingstep.psi_measurevalue%TYPE; -- Dernière valeur de référence (Blobsize ou recorcount
      l_totaleffectivetime   NUMBER;
      l_estimatedlefttime    NUMBER;
   BEGIN
      gbl_listtimestamp.delete ();
      l_step := pkg_processingstep.cst_stepcodereadvalidateheader;
      gbl_listtimestamp (l_step).tim_systimestampstart := SYSTIMESTAMP;
      gbl_listtimestamp (l_step).tim_systimestampend :=
         SYSTIMESTAMP + 2 / (24 * 3600);
      gbl_listtimestamp (l_step).tim_millisecond :=
         pkg_stringutil.f_returnelapsedtime (
            gbl_listtimestamp (l_step).tim_systimestampend,
            gbl_listtimestamp (l_step).tim_systimestampstart);
      l_step := pkg_processingstep.cst_stepcodeloaddata;

      l_effectivevalue := 1290240;
      l_effectivevalue := 5216;
      p_returnestimateleftstep (l_step,
                                l_effectivevalue,
                                l_totaleffectivetime,
                                l_estimatedlefttime);
      DBMS_OUTPUT.put_line (
            'l_totaleeffectivetime='
         || l_totaleffectivetime
         || ' l_estimatelefttime='
         || l_estimatedlefttime);
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_returnestimatestep (
      p_step             IN processingstep.psi_stepcode%TYPE,
      p_effectivevalue   IN NUMBER)
      RETURN NUMBER
   /*-----------------------------------------------------------------*/
   IS
      l_recprocessingstep   processingstep%ROWTYPE;
      l_estimatevalue       NUMBER;
   BEGIN
      l_recprocessingstep := pkg_processingstep.f_getrecordbystepcode (p_step);

      -- Si PSI _MEASUREVALUE est null, la durée estimé est la constante contenu dans  PSI_ELAPSEDTIME
      IF l_recprocessingstep.psi_measurevalue IS NULL
      THEN
         l_estimatevalue := l_recprocessingstep.psi_elapsedtime;
      ELSE
         -- Sinon, on doit podéré la durée contenu dans PSI_ELAPSEDTIME en fonction du paramètre P_effectivevalue
         /*PSI_ELAPSEDTIME    -    PSI_MEASUREVALUE
                    X                     -   p_effectivevalue
         */
         l_estimatevalue :=
              l_recprocessingstep.psi_elapsedtime
            * p_effectivevalue
            / l_recprocessingstep.psi_measurevalue;
      END IF;

      RETURN l_estimatevalue;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_returnrealvaluestep (
      p_step   IN processingstep.psi_stepcode%TYPE)
      RETURN NUMBER
   /*----------------------------------------------------------------*/
   IS
      l_previousstep        processingstep.psi_stepcode%TYPE;
      l_recprocessingstep   processingstep%ROWTYPE;
      l_realtime            NUMBER;
   BEGIN
      l_previousstep := gbl_listtimestamp.PRIOR (p_step);

      IF l_previousstep IS NULL
      THEN
         RETURN NULL;
      END IF;

      l_realtime :=
           gbl_listtimestamp (
              pkg_processingstep.cst_stepcodereadvalidateheader).tim_millisecond
         / 1000;                                                -- En secondes
      RETURN l_realtime;
   END;


   /*................................................................................*/
   PROCEDURE p_computestatusbarmasterstep (
      p_step          IN     processingstep.psi_stepcode%TYPE,
      p_fulltime         OUT NUMBER,
      p_lefttime         OUT NUMBER,
      p_percentdone      OUT NUMBER)
   /*................................................................................*/
   IS
      l_key                  PLS_INTEGER;
      l_effectivevalue       NUMBER;
      l_totaleffectivetime   NUMBER;
      l_estimatedlefttime    NUMBER;
   BEGIN
      gbl_listtimestamp.EXTEND (1);
      gbl_listtimestamp (gbl_listtimestamp.LAST).tim_step := p_step;
      gbl_listtimestamp (gbl_listtimestamp.LAST).tim_systimestampstart :=
         SYSTIMESTAMP;
      l_key := gbl_listtimestamp.PRIOR (gbl_listtimestamp.LAST);

      IF NOT l_key IS NULL
      THEN
         -- On complète le step précédent
         p_saveendtimestamptolist (l_key);
      END IF;

      l_effectivevalue := NVL (gbl_recordcount, gbl_blobsize); -- le blobsize apparaît avant

      p_returnestimateleftstep (p_step,
                                l_effectivevalue,
                                l_totaleffectivetime,
                                l_estimatedlefttime);
      p_fulltime := l_totaleffectivetime + l_estimatedlefttime;
      p_lefttime := l_estimatedlefttime;
      p_percentdone := 100 * (p_fulltime - p_lefttime) / p_fulltime;
      p_percentdone := f_percentnotcutback (p_percentdone);
      pkg_debug.p_write (
         'PKG_PROCESSINGSTEP.p_computestatusbarmasterstep',
            'p_Step='
         || p_step
         || ' p_fulltime='
         || p_fulltime
         || ' p_lefttime='
         || p_lefttime
         || 'p_percentdone='
         || p_percentdone);
   END;


   /*---------------------------------------------------------------*/

   PROCEDURE p_write (p_sequence      IN processingstep.psi_sequence%TYPE,
                      p_stepcode      IN processingstep.psi_stepcode%TYPE,
                      p_comment       IN processingstep.psi_comment%TYPE,
                      p_errornumber   IN processingstep.psi_errornumber%TYPE,
                      p_percentdone   IN processingstep.psi_percentdone%TYPE)
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
      INSERT INTO processingstep (psi_sequence,
                                  psi_stepcode,
                                  psi_comment,
                                  psi_errornumber,
                                  psi_percentdone)
           VALUES (p_sequence,
                   p_stepcode,
                   p_comment,
                   p_errornumber,
                   p_percentdone);

      NULL;
   END;


   /*--------------------------------------------------------------*/

   FUNCTION f_getrecord (p_psi_id IN processingstep.psi_id%TYPE)
      RETURN processingstep%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_processingstep   processingstep%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_processingstep
        FROM processingstep
       WHERE psi_id = p_psi_id;

      RETURN l_processingstep;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/

   FUNCTION f_getrecordbystepcode (
      p_psi_stepcode   IN processingstep.psi_stepcode%TYPE)
      RETURN processingstep%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_processingstep   processingstep%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_processingstep
        FROM processingstep
       WHERE psi_stepcode = p_psi_stepcode;

      RETURN l_processingstep;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
BEGIN
   gbl_listtimestamp.delete ();
END pkg_processingstep;
/

