create PACKAGE       pkg_indicehistory
AS
    /******************************************************************************
       NAME:       PKG_INDICEHISTORY
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        06.10.2017      burrif       1. Created this package.
    ******************************************************************************/



    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_deleteby_ihy_sph_id (p_sph_id indicehistory.ihy_sph_id%TYPE);

    FUNCTION f_getrecord (p_ihy_id IN indicehistory.ihy_id%TYPE)
        RETURN indicehistory%ROWTYPE;

    FUNCTION f_getrecordby_ivr_ibch (
        p_sph_id     IN indicehistory.ihy_sph_id%TYPE,
        p_ivr_ibch   IN indicehistory.ihy_ivr_id_ibch%TYPE)
        RETURN indicehistory%ROWTYPE;

    FUNCTION f_getrecordby_ivr_spear (
        p_sph_id      IN indicehistory.ihy_sph_id%TYPE,
        p_ivr_spear   IN indicehistory.ihy_ivr_id_spear%TYPE)
        RETURN indicehistory%ROWTYPE;

    FUNCTION f_getrecordbykeys (
        p_sph_id         IN indicehistory.ihy_sph_id%TYPE,
        p_ivr_id_ibch    IN indicehistory.ihy_ivr_id_ibch%TYPE,
        p_ivr_id_spear   IN indicehistory.ihy_ivr_id_spear%TYPE)
        RETURN indicehistory%ROWTYPE;

    PROCEDURE p_append (
        p_sph_id                      IN     indicehistory.ihy_sph_id%TYPE,
        p_ivr_id_ibch                 IN     indicehistory.ihy_ivr_id_ibch%TYPE,
        p_ivr_id_spear                IN     indicehistory.ihy_ivr_id_spear%TYPE,
        p_sequence                    IN     indicehistory.ihy_sequence%TYPE,
        p_taxonindicateur             IN     indicehistory.ihy_taxonindicateur%TYPE,
        p_ibchrobust                  IN     indicehistory.ihy_ibchrobust%TYPE,
        p_indexvalueibch              IN     indicehistory.ihy_indexvalueibch%TYPE,
        p_classevariete               IN     indicehistory.ihy_classevariete%TYPE,
        p_classevariete_corr          IN     indicehistory.ihy_classevariete_corr%TYPE,
        p_classevarieterobust         IN     indicehistory.ihy_classevarieterobust%TYPE,
        p_classevarieterobust_corr    IN     indicehistory.ihy_classevarieterobust_corr%TYPE,
        p_classevariete_final         IN     indicehistory.ihy_classevariete_final%TYPE,
        p_classevarieterobust_final   IN     indicehistory.ihy_classevarieterobust_final%TYPE,
        p_gimax                       IN     indicehistory.ihy_gimax%TYPE,
        p_gimaxrobust                 IN     indicehistory.ihy_gimaxrobust%TYPE,
        p_gi_final                    IN     indicehistory.ihy_gi_final%TYPE,
        p_girobust_final              IN     indicehistory.ihy_girobust_final%TYPE,
        p_sumfamily                   IN     indicehistory.ihy_sumfamily%TYPE,
        p_sumfamilycorrected          IN     indicehistory.ihy_sumfamilycorrected%TYPE,
        p_sumfamilyrobust             IN     indicehistory.ihy_sumfamilyrobust%TYPE,
        p_sumfamilyrobustcorrected    IN     indicehistory.ihy_sumfamilyrobustcorrected%TYPE,
        p_ephemeropteracounter        IN     indicehistory.ihy_ephemeropteracounter%TYPE,
        p_plecopteracounter           IN     indicehistory.ihy_plecopteracounter%TYPE,
        p_tricopteracounter           IN     indicehistory.ihy_tricopteracounter%TYPE,
        p_spearvalue                  IN     indicehistory.ihy_spearvalue%TYPE,
        p_ihy_id                         OUT indicehistory.ihy_id%TYPE);
END pkg_indicehistory;
/

