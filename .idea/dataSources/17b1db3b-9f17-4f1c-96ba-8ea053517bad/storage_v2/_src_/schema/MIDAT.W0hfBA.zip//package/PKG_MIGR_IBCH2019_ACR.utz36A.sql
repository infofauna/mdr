create PACKAGE       pkg_migr_ibch2019_acr
AS
    /******************************************************************************
       NAME:       pkg_migr_ibch2019_acr
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        3.07.2020      burrif       1. Created this package.
    ******************************************************************************/


    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_insertall;

    PROCEDURE p_delete;
END pkg_migr_ibch2019_acr;
/

