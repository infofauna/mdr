create PACKAGE       pkg_validatemassheaderfield
AS
   /******************************************************************************
      NAME:       pkg_validatemassheaderfield
      PURPOSE: Valide le contenu des colonnes du header contenu dans la table importmassdataheader

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
      2.0         11.07.2017     burrif       2. Fonctionnalité version 2
      2.1        21.01.2018      burrif       3. Nouvelle version de gestion des droits
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_valideallheader (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER);
END pkg_validatemassheaderfield;
/

