create trigger TR_BUF_SAMPLESTATIONITEM
    before update of SSI_SST_ID,SSI_SST_ID,SSI_LAN_ID,SSI_LAN_ID
    on SAMPLESTATIONITEM
    for each row
BEGIN
   :new.ssi_moddate := SYSDATE;
   :new.ssi_moduser := USER;
END;

/

