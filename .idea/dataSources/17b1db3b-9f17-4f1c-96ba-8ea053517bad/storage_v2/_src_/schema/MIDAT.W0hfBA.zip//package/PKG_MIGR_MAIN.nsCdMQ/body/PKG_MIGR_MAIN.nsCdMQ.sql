create PACKAGE BODY       pkg_migr_main
AS
   /******************************************************************************
      NAME:       PKG_MIGR_MAIN
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_schema           CONSTANT VARCHAR2 (30) := 'MIDAT';

   TYPE rec_fk_definition IS RECORD
   (
      p_shema_name        VARCHAR2 (30),
      p_table_name        VARCHAR2 (30),
      p_column_name       VARCHAR2 (30),
      p_ref_schema_name   VARCHAR2 (30),
      p_ref_table_name    VARCHAR2 (30),
      p_ref_column_name   VARCHAR2 (30)
   );

   TYPE rec_idx_definition IS RECORD
   (
      p_column_name   VARCHAR2 (30),
      p_table_name    VARCHAR2 (30),
      p_bitmap        BOOLEAN
   );



   TYPE t_list_fk_definition IS TABLE OF rec_fk_definition;

   TYPE t_list_idx_definition IS TABLE OF rec_idx_definition;


   gbl_list_fk_definition        t_list_fk_definition := t_list_fk_definition ();

   gbl_list_idx_definition       t_list_idx_definition
                                    := t_list_idx_definition ();

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-----------------------------------------------------------------*/
   FUNCTION f_indexnameexist (p_indexname IN VARCHAR2)
      RETURN BOOLEAN
   /*-----------------------------------------------------------------*/
   IS
      l_indexname   user_indexes.index_name%TYPE;
   BEGIN
      SELECT index_name
        INTO l_indexname
        FROM user_indexes
       WHERE index_name = p_indexname;

      RETURN TRUE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN FALSE;
   END;

   /*-------------------------------------------------------------------*/
   FUNCTION f_fkexist (p_constraint IN user_constraints.constraint_name%TYPE)
      RETURN BOOLEAN
   /*-------------------------------------------------------------------*/
   IS
      l_constraint   user_constraints.constraint_name%TYPE;
   BEGIN
      SELECT constraint_name
        INTO l_constraint
        FROM user_constraints
       WHERE constraint_name = p_constraint;

      RETURN TRUE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN FALSE;
   END;

   /*-------------------------------------------------------------------*/
   FUNCTION f_columnexist (
      p_table_name    IN user_tab_columns.table_name%TYPE,
      p_column_name   IN user_tab_columns.column_name%TYPE)
      RETURN BOOLEAN
   /*-------------------------------------------------------------------*/
   IS
      l_column_name   user_tab_columns.column_name%TYPE;
   BEGIN
      DBMS_OUTPUT.put_line ('l_column_name ' || p_column_name);

      SELECT column_name
        INTO l_column_name
        FROM user_tab_columns
       WHERE column_name = p_column_name AND table_name = p_table_name;

      RETURN TRUE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN FALSE;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_createfk (p_tablename IN VARCHAR2, p_columnname IN VARCHAR2)
   /*----------------------------------------------------------------*/
   IS
      l_sql      VARCHAR2 (1024);
      l_fkname   user_constraints.constraint_name%TYPE;
   BEGIN
      IF NOT f_columnexist (p_tablename, p_columnname)
      THEN
         RETURN;
      END IF;

      l_fkname := 'FK_' || p_columnname;

      IF f_fkexist (l_fkname)
      THEN
         RETURN;
      END IF;

      l_sql :=
            'ALTER TABLE '
         || p_tablename
         || '  ADD 
                     CONSTRAINT '
         || l_fkname
         || '
                     FOREIGN KEY ('
         || p_columnname
         || ' )
                     REFERENCES APPMANAGER.ADMIN_USER (USR_ID)
                     ENABLE
                     VALIDATE';
      DBMS_OUTPUT.put_line ('A créer ' || l_sql);

      EXECUTE IMMEDIATE l_sql;

      NULL;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_createindex (p_tablename    IN VARCHAR2,
                            p_columnname   IN VARCHAR2)
   /*----------------------------------------------------------------*/
   IS
      l_sql         VARCHAR2 (1024);
      l_indexname   user_indexes.index_name%TYPE;
   BEGIN
      IF NOT f_columnexist (p_tablename, p_columnname)
      THEN
         RETURN;
      END IF;

      l_indexname := 'IDX_' || p_columnname;

      IF f_indexnameexist (l_indexname)
      THEN
         RETURN;
      END IF;

      l_sql :=
            'CREATE INDEX '
         || l_indexname
         || ' ON '
         || p_tablename
         || '   ('
         || p_columnname
         || ')
                  LOGGING
                  TABLESPACE '
         || cst_schema
         || '_INDEX
                  STORAGE    (
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
             NOPARALLEL';
      DBMS_OUTPUT.put_line ('A créer ' || l_sql);

      EXECUTE IMMEDIATE l_sql;
   END;


   /*-----------------------------------------------------------------*/
   PROCEDURE p_buildfkuser
   /*-----------------------------------------------------------------*/
   IS
      CURSOR l_listtable
      IS
         SELECT * FROM user_tables;



      l_reclisttable              l_listtable%ROWTYPE;
      l_column_name               user_tab_columns.column_name%TYPE;
      l_indexname                 user_indexes.index_name%TYPE;
      l_sql                       VARCHAR2 (1024);
      l_column_name_user_create   user_tab_columns.column_name%TYPE;
      l_column_name_user_modify   user_tab_columns.column_name%TYPE;
      l_fkname                    user_constraints.constraint_name%TYPE;
   BEGIN
      OPEN l_listtable;

      LOOP
         FETCH l_listtable INTO l_reclisttable;

         EXIT WHEN l_listtable%NOTFOUND;

         SELECT column_name
           INTO l_column_name
           FROM user_tab_columns
          WHERE table_name = l_reclisttable.table_name AND ROWNUM <= 1;

         l_column_name_user_create :=
            SUBSTR (l_column_name, 1, 3) || '_USR_ID_CREATE';
         l_column_name_user_modify :=
            SUBSTR (l_column_name, 1, 3) || '_USR_ID_MODIFY';
         p_createindex (l_reclisttable.table_name, l_column_name_user_create);
         p_createfk (l_reclisttable.table_name, l_column_name_user_create);
         p_createindex (l_reclisttable.table_name, l_column_name_user_modify);
         p_createfk (l_reclisttable.table_name, l_column_name_user_modify);
      END LOOP;


      CLOSE l_listtable;

      NULL;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_removestationdoublon
   /*-----------------------------------------------------------------*/
   IS
      CURSOR l_cursor
      IS
           SELECT DISTINCT sst_oid, sst_ins_id
             FROM samplestation
            WHERE (sst_oid, sst_ins_id) IN (  SELECT sst_oid, sst_ins_id
                                                FROM samplestation
                                            GROUP BY sst_oid, sst_ins_id
                                              HAVING COUNT (*) > 1)
         ORDER BY sst_oid, sst_ins_id;

      l_reccursor   l_cursor%ROWTYPE;
      l_sst_id      samplestation.sst_id%TYPE;
   BEGIN
      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;

         SELECT sst_id
           INTO l_sst_id
           FROM samplestation
          WHERE     sst_oid = l_reccursor.sst_oid
                AND sst_ins_id = l_reccursor.sst_ins_id
                AND ROWNUM < 2;

         DBMS_OUTPUT.put_line ('l_SST_ID=' || l_sst_id);


         UPDATE sampleheader
            SET sph_sst_id = l_sst_id
          WHERE sph_sst_id IN (SELECT sst_id
                                 FROM samplestation
                                WHERE     sst_oid = l_reccursor.sst_oid
                                      AND sst_ins_id = l_reccursor.sst_ins_id);

         UPDATE importmassdataheader
            SET imh_sst_id = l_sst_id
          WHERE imh_sst_id IN (SELECT sst_id
                                 FROM samplestation
                                WHERE     sst_oid = l_reccursor.sst_oid
                                      AND sst_ins_id = l_reccursor.sst_ins_id);
      END LOOP;

      CLOSE l_cursor;
   /*
         DELETE FROM samplestationitem
               WHERE ssi_sst_id NOT IN (SELECT sph_sst_id FROM sampleheader);



         DELETE FROM samplestation
              WHERE sst_id NOT IN (SELECT sph_sst_id FROM sampleheader);
   */
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_clearsyv_id
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE protocolmappinglabo
         SET ptl_syv_id = NULL;

      DELETE FROM mkiidentifygroupcounter;

      DELETE FROM tricopterascabbard;

      DELETE FROM speardatalinkcscf;
   END;


   /*----------------------------------------------------------------*/
   PROCEDURE p_synchronizesyv_id
   /*----------------------------------------------------------------*/
   IS
   /* A utiliser après avoir rechargée les données de systématique */
   BEGIN
      pkg_migr_protocolmappinglabo.p_build_syv_id_v1;
      pkg_migr_protocolmappinglabo.p_build_syv_id_v2;
      pkg_migr_mkiidentifygroupcount.p_load;
      pkg_migr_tricopterascabbard.p_load;
      pkg_speardatalinkcscf.p_build;
   END;


   /*----------------------------------------------------------------*/
   PROCEDURE p_clearalldata
   /*-----------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importprotocollogparam;

      pkg_migr_utility.p_recreatesequence ('IMPORTPROTOCOLLOGPARAM',
                                           'SEQ_IMPORTPROTOCOLLOGPARAM',
                                           'IPR_ID');

      DELETE FROM importprotocollog;

      pkg_migr_utility.p_recreatesequence ('IMPORTPROTOCOLLOG',
                                           'SEQ_IMPORTPROTOCOLLOG',
                                           'IPO_ID');

      DELETE FROM sampleprotocollabo;

      pkg_migr_utility.p_recreatesequence ('SAMPLEPROTOCOLLABO',
                                           'SEQ_SAMPLEPROTOCOLLABO',
                                           'SPL_ID');

      DELETE FROM sampleprotocolgrid;

      pkg_migr_utility.p_recreatesequence ('SAMPLEPROTOCOLGRID',
                                           'SEQ_SAMPLEPROTOCOLGRID',
                                           'SPG_ID');

      DELETE FROM sampleprotocolgrnd;

      pkg_migr_utility.p_recreatesequence ('SAMPLEPROTOCOLGRND',
                                           'SEQ_SAMPLEPROTOCOLGRND',
                                           'SPD_ID');

      DELETE FROM sampleheaderitem;

      pkg_migr_utility.p_recreatesequence ('SAMPLEHEADERITEM',
                                           'SEQ_SAMPLEHEADERITEM',
                                           'SHM_ID');

      DELETE FROM sampledocument;

      pkg_migr_utility.p_recreatesequence ('SAMPLEDOCUMENT',
                                           'SEQ_DOCUMENT',
                                           'SPT_ID');

      DELETE FROM sampleheaderfile;

      pkg_migr_utility.p_recreatesequence ('SAMPLEHEADERFILE',
                                           'SEQ_SAMPLEHEADERFILE',
                                           'SHF_ID');



      DELETE FROM samplestationitem;

      pkg_migr_utility.p_recreatesequence ('SAMPLESTATIONITEM',
                                           'SEQ_SAMPLESTATIONITEM',
                                           'SSI_ID');



      DELETE FROM importprotocollabo;

      pkg_migr_utility.p_recreatesequence ('IMPORTPROTOCOLLABO',
                                           'SEQ_IMPORTPROTOCOLLABO',
                                           'IPL_ID');

      DELETE FROM importprotocolgrnd;

      pkg_migr_utility.p_recreatesequence ('IMPORTPROTOCOLGRND',
                                           'SEQ_IMPORTPROTOCOLGRND',
                                           'IPN_ID');

      DELETE FROM importprotocolgrid;


      pkg_migr_utility.p_recreatesequence ('IMPORTPROTOCOLGRID',
                                           'SEQ_IMPORTPROTOCOLGRID',
                                           'IPG_ID');

      DELETE FROM importmassdatadetail;

      pkg_migr_utility.p_recreatesequence ('IMPORTMASSDATADETAIL',
                                           'SEQ_IMPORTMASSDATADETAIL',
                                           'IMD_ID');


      DELETE FROM samplemkidetailgroup;

      pkg_migr_utility.p_recreatesequence ('samplemkidetailgroup',
                                           'SEQ_samplemkidetailgroupL',
                                           'MKD_ID');

      DELETE FROM importmassdataheader;

      pkg_migr_utility.p_recreatesequence ('IMPORTMASSDATAHEADER',
                                           'SEQ_IMPORTMASSDATAHEADER',
                                           'IMH_ID');

      DELETE FROM importmassstation;

      pkg_migr_utility.p_recreatesequence ('IMPORTMASSSTATION',
                                           'SEQ_IMPORTMASSSTATION',
                                           'IMS_ID');

      DELETE FROM importmassmappingheader;

      pkg_migr_utility.p_recreatesequence ('IMPORTMASSMAPPINGHEADER',
                                           'SEQ_IMPORTMASSMAPPINGHEADER',
                                           'IME_ID');

      UPDATE importprotocolheader
         SET iph_sph_id_parent = NULL;

      DELETE FROM sampleheaderadmingroup;

      pkg_migr_utility.p_recreatesequence ('SAMPLEHEADERADMINGROUP',
                                           'SEQ_SAMPLEHEADERADMINGROUP',
                                           'SHG_ID');

      DELETE FROM sampleprotocolmass;

      pkg_migr_utility.p_recreatesequence ('sampleprotocolmass',
                                           'SEQ_sampleprotocolmass',
                                           'SMX_ID');

      DELETE FROM sampleheader;

      pkg_migr_utility.p_recreatesequence ('SAMPLEHEADER',
                                           'SEQ_SAMPLEHEADER',
                                           'SPH_ID');


      DELETE FROM importprotocolheader;

      pkg_migr_utility.p_recreatesequence ('IMPORTPROTOCOLHEADER',
                                           'SEQ_IMPORTPROTOCOLHEADER',
                                           'IPH_ID');


      DELETE FROM processingsteplog;

      pkg_migr_utility.p_recreatesequence ('PROCESSINGSTEPLOG',
                                           'SEQ_PROCESSINGSTEPLOG',
                                           'PSL_ID');

      DELETE FROM processingstatus;

      pkg_migr_utility.p_recreatesequence ('PROCESSINGSTATUS',
                                           'SEQ_PROCESSINGSTATUS',
                                           'PID_ID');


      DELETE FROM sampleheadermassfile;

      pkg_migr_utility.p_recreatesequence ('SAMPLEHEADERMASSFILE',
                                           'SEQ_SAMPLEHEADERMASSFILE',
                                           'SMF_ID');

      DELETE FROM samplestation;

      pkg_migr_utility.p_recreatesequence ('SAMPLESTATION',
                                           'SEQ_SAMPLESTATION',
                                           'SST_ID');


      DELETE FROM debug;

      pkg_migr_utility.p_recreatesequence ('DEBUG', 'SEQ_DEBUG', 'DBG_ID');

      DELETE FROM processingsteplog;

      pkg_migr_utility.p_recreatesequence ('PROCESSINGSTEPLOG',
                                           'SEQ_PROCESSINGSTEPLOG',
                                           'PSL_ID');

      DELETE FROM processingstatus;

      pkg_migr_utility.p_recreatesequence ('PROCESSINGSTATUS',
                                           'SEQ_PROCESSINGSTATUS',
                                           'PID_ID');
   END;


   /*----------------------------------------------------------------*/
   PROCEDURE p_clearmassdata
   /*---------------------------------------------------------------*/
   IS
      CURSOR l_massfile
      IS
         SELECT * FROM sampleheadermassfile;

      l_recmassfile       l_massfile%ROWTYPE;

      CURSOR l_sampleheader (p_smf_id IN sampleheader.sph_smf_id%TYPE)
      IS
         SELECT *
           FROM sampleheader
          WHERE sph_smf_id = p_smf_id;

      l_recsampleheader   l_sampleheader%ROWTYPE;
   BEGIN
      OPEN l_massfile;

      LOOP
         FETCH l_massfile INTO l_recmassfile;

         EXIT WHEN l_massfile%NOTFOUND;

         OPEN l_sampleheader (l_recmassfile.smf_id);

         LOOP
            FETCH l_sampleheader INTO l_recsampleheader;

            EXIT WHEN l_sampleheader%NOTFOUND;
            pkg_sampleheader.p_deleteprotocolentry (l_recsampleheader.sph_id,
                                                    l_recmassfile.smf_ptv_id);
         END LOOP;

         CLOSE l_sampleheader;
      END LOOP;

      CLOSE l_massfile;

      NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_build_fk_definition (p_shema_name        IN VARCHAR2,
                                   p_table_name        IN VARCHAR2,
                                   p_column_name       IN VARCHAR2,
                                   p_ref_schema_name   IN VARCHAR2,
                                   p_ref_table_name    IN VARCHAR2,
                                   p_ref_column_name   IN VARCHAR2)
      RETURN rec_fk_definition
   /*------------------------------------------------------------*/
   IS
      l_rec_fk_definition   rec_fk_definition;
   BEGIN
      l_rec_fk_definition.p_shema_name := p_shema_name;
      l_rec_fk_definition.p_table_name := p_table_name;
      l_rec_fk_definition.p_column_name := p_column_name;
      l_rec_fk_definition.p_ref_schema_name := p_ref_schema_name;
      l_rec_fk_definition.p_ref_table_name := p_ref_table_name;
      l_rec_fk_definition.p_ref_column_name := p_ref_column_name;
      RETURN l_rec_fk_definition;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_define_all_fk
   /*--------------------------------------------------------------*/
   IS
      l_rec_fk_definition   rec_fk_definition;
   BEGIN
      --AVALIABILITYCALENDAR
      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'AVALIABILITYCALENDAR',
                                'IAC_CVL_ID_MIDATINDICE',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'AVALIABILITYCALENDAR',
                                'IAC_CVL_ID_MIDATWINDOW',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- BIOLOGICALSTATE

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'BIOLOGICALSTATE',
                                'BLS_CVL_ID_MIDATINDICE',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'BIOLOGICALSTATE',
                                'BLS_CVL_ID_BIOLSTATETXT',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'BIOLOGICALSTATE',
                                'BLS_CVL_ID_COLORINDEX',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- IMPORTMASSDATADETAIL

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSDATADETAIL',
                                'IMD_IMH_ID',
                                'MIDAT',
                                'IMPORTMASSDATAHEADER',
                                'IMH_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSDATADETAIL',
                                'IMD_IPH_ID',
                                'MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSDATADETAIL',
                                'IMD_SYV_ID',
                                'INFOFAUNA',
                                'SYSTVALUE',
                                'SYV_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSDATADETAIL',
                                'IMD_PTL_ID',
                                'MIDAT',
                                'IMPORTPROTOCOLMAPPINGLABO',
                                'PTL_ID');

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSDATADETAIL',
                                'IMD_CVL_ID_ZOOSTADIUM',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- IMPORTMASSDATAHEADER

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSDATAHEADER',
                                'IMH_IPH_ID',
                                'MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSDATAHEADER',
                                'IMH_IMS_ID',
                                'MIDAT',
                                'IMPORTMASSSTATION',
                                'IMS_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSDATAHEADER',
                                'IMH_SST_ID',
                                'MIDAT',
                                'SAMPLESTATION',
                                'SST_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSDATAHEADER',
                                'IMH_CVL_ID_WINDOWIBCH',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSDATAHEADER',
                                'IMH_CVL_ID_WINDOWMAKROINDEX',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSDATAHEADER',
                                'IMH_CVL_ID_WINDOWSPEAR',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');



      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;
      --IMPORTMASSMAPPINGHEADER
      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSMAPPINGHEADER',
                                'IME_IPH_ID',
                                'MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSMAPPINGHEADER',
                                'IME_PMM_ID',
                                'MIDAT',
                                'PROTOCOLMAPPINGMASSFIELD',
                                'PMM_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- IMPORTMASSSTATION

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSSTATION',
                                'IMS_IMH_ID',
                                'MIDAT',
                                'IMPORTMASSDATAHEADER',
                                'IMH_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTMASSSTATION',
                                'IMS_CVL_ID_ELEVATIONORIGIN',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- IMPORTPROTOCOLGRID
      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLGRID',
                                'IPG_IPH_ID',
                                'MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLGRID',
                                'IPG_PMG_ID',
                                'MIDAT',
                                'PROTOCOLMAPPINGGRID',
                                'PMG_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- IMPORTPROTOCOLGRND

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLGRND',
                                'IPN_IPH_ID',
                                'MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLGRND',
                                'IPN_PMR_ID',
                                'MIDAT',
                                'PROTOCOLMAPPINGGRND',
                                'PMR_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      --IMPORTPROTOCOLHEADER

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_IPH_ID',
                                'MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_PTV_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_SST_ID_EXISTING',
                                'MIDAT',
                                'SAMPLESTATION',
                                'SST_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_SPH_ID_PARENT',
                                'MIDAT',
                                'SAMPLEHEADER',
                                'SPH_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_PID_ID',
                                'MIDAT',
                                'PROCESSINGSTATUS',
                                'PID_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_LAN_ID',
                                'INFOFAUNA',
                                'LANGUAGE',
                                'LAN_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_INS_ID_PRINCIPAL',
                                'INFOFAUNA',
                                'INSTITUTION',
                                'INS_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_INS_ID_MANDATARY',
                                'INFOFAUNA',
                                'INSTITUTION',
                                'INS_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_CVL_ID_WINDOWIBCH',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_CVL_ID_WINDOWMAKROINDEX',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_CVL_ID_WINDOWSPEAR',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_CVL_ID_MIDATSTAT',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_PER_ID_DETERMINATOR',
                                'INFOFAUNA',
                                'PERSON',
                                'PER_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_PER_ID_OPERATOR',
                                'INFOFAUNA',
                                'PERSON',
                                'PER_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_CVL_ID_SYSTLPREC',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_CVL_ID_SYSTLREF',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_CVL_ID_ELEVATIONORIGIN',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- IMPORTPROTOCOLLABO


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLLABO',
                                'IPL_IPH_ID',
                                'MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLLABO',
                                'IPL_PTL_ID',
                                'MIDAT',
                                'PROTOCOLMAPPINGLABO',
                                'PTL_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- IMPORTPROTOCOLLOG

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLLOG',
                                'IPO_IPH_ID',
                                'MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;



      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLLOG',
                                'IPO_IMH_ID',
                                'MIDAT',
                                'IMPORTMASSDATAHEADER',
                                'IMH_ID');


      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;
      -- IMPORTPROTOCOLLOGPARAM
      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'IMPORTPROTOCOLLOGPARAM',
                                'IPR_IPO_ID',
                                'MIDAT',
                                'IMPORTPROTOCOLLOG',
                                'IPO_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;
      -- PROCESSINGSTATUS

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROCESSINGSTATUS',
                                'PID_USR_ID',
                                'APPMANAGER',
                                'ADMIN_USER',
                                'USR_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- PROCESSINGSTEPLOG

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROCESSINGSTEPLOG',
                                'PSL_PSI_ID',
                                'MIDAT',
                                'PROCESSINGSTEP',
                                'PSI_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROCESSINGSTEPLOG',
                                'PSL_PID_ID',
                                'MIDAT',
                                'PROCESSINGSTATUS',
                                'PID_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- PROTOCOLMAPPINGGRID

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGGRID',
                                'PMG_CVL_ID_MIDATITGRDRO',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGGRID',
                                'PMG_CVL_ID_MIDATITGRDCL',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGGRID',
                                'PMG_CVL_ID_MIDATITGRDCE',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGGRID',
                                'PMG_CVL_ID_DATATYPE',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGGRID',
                                'PMG_PTV_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- PROTOCOLMAPPINGGRND

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGGRND',
                                'PMR_PTV_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGGRND',
                                'PMR_CVL_ID_DATATYPE',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGGRND',
                                'PMR_CVL_ID_MIDATGRND',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- PROTOCOLMAPPINGHEADER

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGHEADER',
                                'PMH_PTV_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGHEADER',
                                'PMH_CVL_ID_DATATYPE',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;



      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGHEADER',
                                'PMH_CVL_ID_MIDATHDITEM',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- PROTOCOLMAPPINGLABO
      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGLABO',
                                'PTL_PTV_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGLABO',
                                'PTL_PTL_ID',
                                'MIDAT',
                                'PROTOCOLMAPPINGLABO',
                                'PTL_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGLABO',
                                'PTL_SYV_ID',
                                'INFOFAUNA',
                                'SYSTVALUE',
                                'SYV_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGLABO',
                                'PTL_CRF_ID_LEVEL',
                                'INFOFAUNA',
                                'CODEREFERENCE',
                                'CRF_ID');

      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- PROTOCOLMAPPINGMASSFIELD
      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGMASSFIELD',
                                'PMM_PTV_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- PROTOCOLMAPPINGMASSMAP

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGMASSMAP',
                                'PMA_PMM_ID',
                                'MIDAT',
                                'PROTOCOLMAPPINGMASSFIELD',
                                'PMM_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLMAPPINGMASSMAP',
                                'PMA_LAN_ID',
                                'INFOFAUNA',
                                'LANGUAGE',
                                'LAN_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- PROTOCOLVERSION

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_CVL_ID_PROTOCOLTYPE',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_PTV_ID_LABOFROMMASS',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- SAMPLEDOCUMENT

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEDOCUMENT',
                                'SPT_SPH_ID',
                                'MIDAT',
                                'SAMPLEHEADER',
                                'SPH_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEDOCUMENT',
                                'SPT_PTV_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- SAMPLEHEADER

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_SMF_ID',
                                'MIDAT',
                                'SAMPLEHEADERMASSFILE',
                                'SMF_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_SST_ID',
                                'MIDAT',
                                'SAMPLESTATION',
                                'SST_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_IPH_ID',
                                'MIDAT',
                                'IMPORTPROTOCOLHEADER',
                                'IPH_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_INS_ID_PRINCIPAL',
                                'INFOFAUNA',
                                'INSTITUTION',
                                'INS_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_INS_ID_MANDATARY',
                                'INFOFAUNA',
                                'INSTITUTION',
                                'INS_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_CVL_ID_SYSPRECISIONREF',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_CVL_ID_SYSPRECISION',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_PTV_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_CVL_ID_WINDOWMAKROINDEX',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_CVL_ID_WINDOWSPEAR',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;
      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_CVL_ID_WINDOWIBCH',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADER',
                                'SPH_CVL_ID_MIDATSTAT',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- SAMPLEHEADERFILE
      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADERFILE',
                                'SHF_PTV_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADERFILE',
                                'SHF_SPH_ID',
                                'MIDAT',
                                'SAMPLEHEADER',
                                'SPH_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADERFILE',
                                'SHF_LAN_ID',
                                'INFOFAUNA',
                                'LANGUAGE',
                                'LAN_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- SAMPLEHEADERITEM


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADERITEM',
                                'SHM_LAN_ID',
                                'INFOFAUNA',
                                'LANGUAGE',
                                'LAN_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADERITEM',
                                'SHM_PTV_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADERITEM',
                                'SHM_CVL_ID_MIDATPROTO',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADERITEM',
                                'SHM_SPH_ID',
                                'MIDAT',
                                'SAMPLEHEADER',
                                'SPH_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADERITEM',
                                'SHM_CVL_ID_MIDATHDITMTY',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADERITEM',
                                'SHM_PER_ID',
                                'INFOFAUNA',
                                'PERSON',
                                'PER_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- SAMPLEHEADERMASSFILE

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADERMASSFILE',
                                'SMF_PTV_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEHEADERMASSFILE',
                                'SMF_LAN_ID',
                                'INFOFAUNA',
                                'LANGUAGE',
                                'LAN_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      -- SAMPLEPROTOCOLGRID

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEPROTOCOLGRID',
                                'SPG_SPH_ID',
                                'MIDAT',
                                'PROTOCOLVERSION',
                                'PTV_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEPROTOCOLGRID',
                                'SPG_PMG_ID',
                                'MIDAT',
                                'PROTOCOLMAPPINGGRID',
                                'PMG_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- SAMPLEPROTOCOLGRND


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEPROTOCOLGRND',
                                'SPD_SPH_ID',
                                'MIDAT',
                                'SAMPLEHEADER',
                                'SPH_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEPROTOCOLGRND',
                                'SPD_PMR_ID',
                                'MIDAT',
                                'PROTOCOLMAPPINGGRND',
                                'PMR_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- SAMPLEPROTOCOLLABO
      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEPROTOCOLLABO',
                                'SPL_SPH_ID',
                                'MIDAT',
                                'SAMPLEHEADER',
                                'SPH_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEPROTOCOLLABO',
                                'SPL_PTL_ID',
                                'MIDAT',
                                'PROTOCOLMAPPINGLABO',
                                'PTL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLEPROTOCOLLABO',
                                'SPL_SYV_ID',
                                'INFOFAUNA',
                                'SYSTVALUE',
                                'SYV_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      --SAMPLESTATION
      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLESTATION',
                                'SST_INS_ID',
                                'INFOFAUNA',
                                'INSTITUTION',
                                'INS_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLESTATION',
                                'SST_CVL_ID_ELEVATIONORIGIN',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;


      -- SAMPLESTATIONITEM


      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLESTATIONITEM',
                                'SSI_SST_ID',
                                'MIDAT',
                                'SAMPLESTATION',
                                'SST_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLESTATIONITEM',
                                'SSI_LAN_ID',
                                'INFOFAUNA',
                                'LANGUAGE',
                                'LAN_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SAMPLESTATIONITEM',
                                'SSI_CVL_ID_MIDATSTITMTY',
                                'INFOFAUNA',
                                'CODEVALUE',
                                'CVL_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;

      -- SPEARDATA

      l_rec_fk_definition :=
         f_build_fk_definition ('MIDAT',
                                'SPEARDATA',
                                'SRA_SRA_ID',
                                'MIDAT',
                                'SPEARDATA',
                                'SRA_ID');
      gbl_list_fk_definition.EXTEND (1);
      gbl_list_fk_definition (gbl_list_fk_definition.LAST) :=
         l_rec_fk_definition;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_build_fk
   /*---------------------------------------------------------------*/
   IS
      l_indice   PLS_INTEGER;
   BEGIN
      p_define_all_fk;
      l_indice := gbl_list_fk_definition.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         pkg_migr_utility.p_drop_constraint (
            gbl_list_fk_definition (l_indice).p_table_name,
            'FK_' || gbl_list_fk_definition (l_indice).p_column_name);
         pkg_migr_utility.p_create_fk (
               gbl_list_fk_definition (l_indice).p_shema_name
            || '.'
            || gbl_list_fk_definition (l_indice).p_table_name,
            gbl_list_fk_definition (l_indice).p_column_name,
               gbl_list_fk_definition (l_indice).p_ref_schema_name
            || '.'
            || gbl_list_fk_definition (l_indice).p_ref_table_name,
            gbl_list_fk_definition (l_indice).p_ref_column_name);
         l_indice := gbl_list_fk_definition.NEXT (l_indice);
      END LOOP;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_build_idx_definition
   /*--------------------------------------------------------------*/
   IS
      l_indice   PLS_INTEGER;
   BEGIN
      p_define_all_fk;
      l_indice := gbl_list_fk_definition.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         -- Les indexe de langue sont des BITMAP
         gbl_list_idx_definition.EXTEND (1);

         IF UPPER (gbl_list_fk_definition (l_indice).p_ref_column_name) =
               'LAN_ID'
         THEN
            gbl_list_idx_definition (gbl_list_idx_definition.LAST).p_table_name :=
               gbl_list_fk_definition (l_indice).p_table_name;
            gbl_list_idx_definition (gbl_list_idx_definition.LAST).p_column_name :=
               gbl_list_fk_definition (l_indice).p_column_name;
            gbl_list_idx_definition (gbl_list_idx_definition.LAST).p_bitmap :=
               TRUE;
         ELSE
            gbl_list_idx_definition (gbl_list_idx_definition.LAST).p_table_name :=
               gbl_list_fk_definition (l_indice).p_table_name;
            gbl_list_idx_definition (gbl_list_idx_definition.LAST).p_column_name :=
               gbl_list_fk_definition (l_indice).p_column_name;
            gbl_list_idx_definition (gbl_list_idx_definition.LAST).p_bitmap :=
               FALSE;
         END IF;

         l_indice := gbl_list_fk_definition.NEXT (l_indice);
      END LOOP;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_build_idx
   /*----------------------------------------------------------------*/
   IS
      l_indice   PLS_INTEGER;
      l_sql      VARCHAR2 (4096);
   BEGIN
      p_build_idx_definition;
      l_indice := gbl_list_idx_definition.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         pkg_migr_utility.p_drop_index (
            'IDX_' || gbl_list_idx_definition (l_indice).p_column_name);
         pkg_migr_utility.p_create_index (
            gbl_list_idx_definition (l_indice).p_column_name,
            gbl_list_idx_definition (l_indice).p_table_name,
            gbl_list_idx_definition (l_indice).p_bitmap);
         l_indice := gbl_list_idx_definition.NEXT (l_indice);
      END LOOP;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_purgeall
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleheaderfile;

      DELETE FROM sampleheaderitem;

      DELETE FROM samplestationitem;

      DELETE FROM samplestation;

      DELETE FROM sampleprotocollabo;

      DELETE FROM sampleprotocolgrid;

      DELETE FROM sampleheader;

      DELETE FROM importprotocollabo;

      DELETE FROM importprotocolgrid;

      DELETE FROM importprotocolheader;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_define_synonym
   /*----------------------------------------------------------------*/
   IS
      TYPE t_sql IS TABLE OF VARCHAR2 (4096);

      l_sql      t_sql := t_sql ();
      l_indice   PLS_INTEGER;
   BEGIN
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM pkg_codevalue FOR INFOFAUNA.pkg_codevalue ';
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM pkg_codedesignation FOR INFOFAUNA.pkg_codedesignation ';
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM pkg_constante FOR INFOFAUNA.pkg_constante ';
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM pkg_language FOR INFOFAUNA.pkg_language ';
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM pkg_codereference FOR INFOFAUNA.pkg_codereference ';
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM CODEVALUE FOR INFOFAUNA.CODEVALUE';
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM CODEDESIGNATION FOR INFOFAUNA.CODEDESIGNATION';
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM CODEREFERENCE FOR INFOFAUNA.CODEREFERENCE';
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM SYSTDESIGNATION FOR INFOFAUNA.SYSTDESIGNATION';
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM PKG_SYSTDESIGNATION FOR INFOFAUNA.PKG_SYSTDESIGNATION';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM SYSTVALUE FOR INFOFAUNA.SYSTVALUE';
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM LANGUAGE FOR INFOFAUNA.LANGUAGE';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM PKG_SYSTVALUE FOR INFOFAUNA.PKG_SYSTVALUE';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM PKG_MESSAGE FOR APPMANAGER.PKG_MESSAGE';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM PKG_EXCEPTION FOR APPMANAGER.PKG_EXCEPTION';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM MESSAGE FOR APPMANAGER.MESSAGE';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM LOGMESSAGEHEADER FOR APPMANAGER.LOGMESSAGEHEADER';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM LOGMESSAGEPARAMETER FOR APPMANAGER.LOGMESSAGEPARAMETER';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM PKGLOGMESSAGEPARAMETER FOR APPMANAGER.PKG_LOGMESSAGEPARAMETER';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM PKG_LOGMESSAGEHEADER FOR APPMANAGER.PKG_LOGMESSAGEHEADER';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM PKG_PERSON FOR INFOFAUNA.PKG_PERSON';
      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM PERSON FOR INFOFAUNA.pERSON';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM PKG_DATATYPE FOR INFOFAUNA.PKG_DATATYPE';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM ADMIN_USER FOR APPMANAGER.ADMIN_USER';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM PKG_CH_GWN25 FOR GISMANAGER.PKG_CH_GWN25';

      l_sql.EXTEND (1);
      l_sql (l_sql.LAST) :=
         'CREATE OR REPLACE SYNONYM CH_GWN25 FOR GISMANAGER.CH_GWN25';



      l_indice := l_sql.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         EXECUTE IMMEDIATE l_sql (l_indice);

         l_indice := l_sql.NEXT (l_indice);
      END LOOP;
   END;
END pkg_migr_main;
/

