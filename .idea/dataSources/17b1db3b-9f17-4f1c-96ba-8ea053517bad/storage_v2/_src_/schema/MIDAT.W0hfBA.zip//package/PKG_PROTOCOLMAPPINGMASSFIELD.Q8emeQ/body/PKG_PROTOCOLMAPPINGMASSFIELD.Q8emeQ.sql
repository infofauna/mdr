create PACKAGE BODY       pkg_protocolmappingmassfield
AS
   /******************************************************************************
      NAME:       pkg_protocolmappingmassfield
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
        2.0        21.09.2017      burrif       2. Version 2
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 2.0, septembre  2017' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-----------------------------------------------------------------*/

   FUNCTION f_getrecord (p_pmm_id IN protocolmappingmassfield.pmm_id%TYPE)
      RETURN protocolmappingmassfield%ROWTYPE
   /*------------------------------------------------------------------*/
   IS
      l_recprotocolmappingmassfield   protocolmappingmassfield%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recprotocolmappingmassfield
        FROM protocolmappingmassfield
       WHERE pmm_id = p_pmm_id;

      RETURN l_recprotocolmappingmassfield;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*-----------------------------------------------------------------*/
   FUNCTION f_countrequired (
      p_ptv_id   IN protocolmappingmassfield.pmm_ptv_id%TYPE)
      RETURN NUMBER
   /*-----------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM protocolmappingmassfield
       WHERE pmm_ptv_id = p_ptv_id AND pmm_isnotnull = pkg_constante.cst_yes;

      RETURN l_count;
   END;

   /*-----------------------------------------------------------------*/
   FUNCTION f_countgrouprequired (
      p_ptv_id   IN protocolmappingmassfield.pmm_ptv_id%TYPE)
      RETURN NUMBER
   /*-----------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM protocolmappingmassfield
       WHERE pmm_ptv_id = p_ptv_id AND NOT pmm_isnotnullgroup IS NULL;

      RETURN l_count;
   END;

   /*----------------------------------------------------------------*/

   FUNCTION f_getfromaliascolumnname (
      p_aliascolumnname   IN protocolmappingmassmap.pma_aliascolumnname%TYPE,
      p_ptv_id            IN protocolmappingmassfield.pmm_ptv_id%TYPE,
      p_lan_id            IN protocolmappingmassmap.pma_lan_id%TYPE)
      RETURN protocolmappingmassfield%ROWTYPE
   /*------------------------------------------------------------------*/
   IS
      l_recprotocolmappingmassfield   protocolmappingmassfield%ROWTYPE;
   BEGIN
      SELECT protocolmappingmassfield.*
        INTO l_recprotocolmappingmassfield
        FROM protocolmappingmassfield
             INNER JOIN protocolmappingmassmap ON pma_pmm_id = pmm_id
       WHERE     UPPER (TRIM (p_aliascolumnname)) =
                    UPPER (TRIM (pma_aliascolumnname))
             AND pmm_ptv_id = p_ptv_id
             AND pma_lan_id = p_lan_id;

      RETURN l_recprotocolmappingmassfield;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*----------------------------------------------------------------*/

   FUNCTION f_getfromcolumnname (
      p_columnname   IN protocolmappingmassfield.pmm_columnname%TYPE,
      p_ptv_id       IN protocolmappingmassfield.pmm_ptv_id%TYPE)
      RETURN protocolmappingmassfield%ROWTYPE
   /*------------------------------------------------------------------*/
   IS
      l_recprotocolmappingmassfield   protocolmappingmassfield%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recprotocolmappingmassfield
        FROM protocolmappingmassfield
       WHERE p_columnname = pmm_columnname AND pmm_ptv_id = p_ptv_id;

      RETURN l_recprotocolmappingmassfield;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-----------------------------------------------------------------*/

   FUNCTION f_getfromcode (
      p_code     IN protocolmappingmassfield.pmm_code_midatfldcmt%TYPE,
      p_ptv_id   IN protocolmappingmassfield.pmm_ptv_id%TYPE)
      RETURN protocolmappingmassfield%ROWTYPE
   /*------------------------------------------------------------------*/
   IS
      l_recprotocolmappingmassfield   protocolmappingmassfield%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recprotocolmappingmassfield
        FROM protocolmappingmassfield
       WHERE p_code = pmm_code_midatfldcmt AND pmm_ptv_id = p_ptv_id;

      RETURN l_recprotocolmappingmassfield;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*----------------------------------------------------------------*/

   PROCEDURE p_write (
      p_ptv_id           IN protocolmappingmassfield.pmm_ptv_id%TYPE,
      p_columncode       IN protocolmappingmassfield.pmm_code_midatfldcmt%TYPE,
      p_columnname       IN protocolmappingmassfield.pmm_columnname%TYPE,
      p_isnotnull        IN protocolmappingmassfield.pmm_isnotnull%TYPE,
      p_isnotnullgroup   IN protocolmappingmassfield.pmm_isnotnullgroup%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      INSERT INTO protocolmappingmassfield (pmm_ptv_id,
                                            pmm_code_midatfldcmt,
                                            pmm_columnname,
                                            pmm_isnotnull,
                                            pmm_isnotnullgroup)
           VALUES (p_ptv_id,
                   p_columncode,
                   p_columnname,
                   p_isnotnull,
                   p_isnotnullgroup);
   END;
END pkg_protocolmappingmassfield;
/

