create PACKAGE BODY       pkg_speardata
AS
   /******************************************************************************
      NAME:       PKG_SPEARDATA
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25/07/2014      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, juillet  2014' ;

   TYPE t_recdesignation IS RECORD
   (
      rds_sra_id        speardata.sra_id%TYPE,
      rds_designation   systdesignation.syd_designation%TYPE
   );

   TYPE t_listofdesignation IS TABLE OF t_recdesignation
      INDEX BY VARCHAR2 (30);

   gbl_listofdesignation         t_listofdesignation;
   cst_column_group     CONSTANT VARCHAR2 (30) := 'WLS_GROUP';
   cst_column_family    CONSTANT VARCHAR2 (30) := ' WLS_FAMILY';
   cst_column_genus     CONSTANT VARCHAR2 (30) := ' WLS_GENUS';
   cst_column_taxa      CONSTANT VARCHAR2 (30) := 'WLS_TAXA';



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_clearalldata
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM speardata;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_write (p_sra_sra_id           speardata.sra_sra_id%TYPE,
                      p_wls_id        IN     speardata.sra_wls_id%TYPE,
                      p_aqem_id       IN     speardata.sra_aqem_id%TYPE,
                      p_level         IN     speardata.sra_level%TYPE,
                      p_designation   IN     speardata.sra_designation%TYPE,
                      p_spearvalue    IN     speardata.sra_spearvalue%TYPE,
                      p_gt_source     IN     speardata.sra_gt_source%TYPE,
                      p_sens          IN     speardata.sra_sens%TYPE,
                      p_senssource    IN     speardata.sra_senssource%TYPE,
                      p_mig           IN     speardata.sra_mig%TYPE,
                      p_migsource     IN     speardata.sra_migsource%TYPE,
                      p_out           IN     speardata.sra_out%TYPE,
                      p_outsource     IN     speardata.sra_outsource%TYPE,
                      p_gtcode        IN     speardata.sra_gtcode%TYPE,
                      p_senscode      IN     speardata.sra_senscode%TYPE,
                      p_migcode       IN     speardata.sra_migcode%TYPE,
                      p_expcode       IN     speardata.sra_expcode%TYPE,
                      p_id               OUT speardata.sra_id%TYPE)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_speardata.NEXTVAL;

      INSERT INTO speardata (sra_sra_id,
                             sra_wls_id,
                             sra_aqem_id,
                             sra_level,
                             sra_designation,
                             sra_spearvalue,
                             sra_gt_source,
                             sra_sens,
                             sra_senssource,
                             sra_mig,
                             sra_migsource,
                             sra_out,
                             sra_outsource,
                             sra_gtcode,
                             sra_senscode,
                             sra_migcode,
                             sra_expcode,
                             sra_id)
           VALUES (p_sra_sra_id,
                   p_wls_id,
                   p_aqem_id,
                   p_level,
                   p_designation,
                   p_spearvalue,
                   p_gt_source,
                   p_sens,
                   p_senssource,
                   p_mig,
                   p_migsource,
                   p_out,
                   p_outsource,
                   p_gtcode,
                   p_senscode,
                   p_migcode,
                   p_expcode,
                   p_id);
   END;


   /*----------------------------------------------------------------*/
   FUNCTION f_comparedesignation (
      p_designation   IN systdesignation.syd_designation%TYPE,
      p_column        IN VARCHAR2)
      RETURN systdesignation.syd_designation%TYPE
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      IF gbl_listofdesignation (p_column).rds_designation IS NULL
      THEN
         RETURN NULL;
      ELSE
         IF UPPER (gbl_listofdesignation (p_column).rds_designation) =
               UPPER (p_designation)
         THEN
            RETURN gbl_listofdesignation (p_column).rds_designation;
         ELSE
            RETURN NULL;
         END IF;
      END IF;
   END;


   /*---------------------------------------------------------------*/
   FUNCTION f_returnsyvrecordbydesignation (
      p_designation IN systdesignation.syd_designation%TYPE)
      RETURN systvalue%ROWTYPE
   /*----------------------------------------------------------------*/
   IS
      l_recsystvalue         systvalue%ROWTYPE;
      l_recsystdesignation   systdesignation%ROWTYPE;

      CURSOR l_listcodereference
      IS
             SELECT codereference.*
               FROM codereference
                    INNER JOIN codereferencecategory ON crf_crc_id = crc_id
              WHERE crc_code = pkg_codereferencecategory.cst_crc_syst
         CONNECT BY PRIOR crf_id = crf_crf_id
         START WITH crf_crf_id IS NULL;

      l_reccodereference     l_listcodereference%ROWTYPE;
      l_found                BOOLEAN := FALSE;
   BEGIN
      OPEN l_listcodereference;

      LOOP
         FETCH l_listcodereference INTO l_reccodereference;

         EXIT WHEN l_listcodereference%NOTFOUND;

         l_recsystdesignation :=
            pkg_systdesignation.f_getrecordbyleveldesignation (
               p_designation,
               l_reccodereference.crf_code);

         EXIT WHEN NOT l_recsystdesignation.syd_id IS NULL;
      END LOOP;

      CLOSE l_listcodereference;

      IF NOT l_recsystdesignation.syd_id IS NULL
      THEN
         l_recsystvalue :=
            pkg_systvalue.f_getrecord (l_recsystdesignation.syd_syv_id);
         RETURN l_recsystvalue;
      ELSE
         RETURN NULL;
      END IF;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_test
   /*----------------------------------------------------------------*/
   IS
      l_recsystvalue   systvalue%ROWTYPE;
      l_designation    systdesignation.syd_designation%TYPE;
   BEGIN
      l_designation := 'Bivalvia';
      l_recsystvalue := f_returnsyvrecordbydesignation (l_designation);
      DBMS_OUTPUT.put_line ('systvalue: ' || l_recsystvalue.syv_id);
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_initgbl_listofdesignation
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      gbl_listofdesignation (cst_column_group).rds_designation :=
         'ZZZZZZZZZZZZ';
      gbl_listofdesignation (cst_column_family).rds_designation :=
         'ZZZZZZZZZZZZ';
      gbl_listofdesignation (cst_column_genus).rds_designation :=
         'ZZZZZZZZZZZZ';
      gbl_listofdesignation (cst_column_taxa).rds_designation :=
         'ZZZZZZZZZZZZ';
   END;


   /*---------------------------------------------------------------*/

   PROCEDURE p_flushdata (p_wk_loadspeardata   IN wk_loadspeardata%ROWTYPE,
                          p_column             IN VARCHAR2)
   /*---------------------------------------------------------------*/
   IS
      l_recspeardata   speardata%ROWTYPE;
      l_id             speardata.sra_id%TYPE;
   BEGIN
      l_recspeardata.sra_wls_id := p_wk_loadspeardata.wls_id;

      pkg_debug.p_write ('PKG_SPEARDATA.p_flushdata',
                         'p_column=' || p_column);

      IF p_column = cst_column_group
      THEN
         -- Les données aditionelles sont associées au groupe
         l_recspeardata.sra_sra_id := NULL;                   -- Pas de parent

         l_recspeardata.sra_designation := p_wk_loadspeardata.wls_group;
      END IF;

      IF p_column = cst_column_family
      THEN
         -- Les données aditionelles sont associées au groupe
         l_recspeardata.sra_sra_id :=
            gbl_listofdesignation (cst_column_group).rds_sra_id;

         l_recspeardata.sra_designation := p_wk_loadspeardata.wls_family;
      END IF;

      IF p_column = cst_column_genus
      THEN
         -- Les données aditionelles sont associées  au genus
         l_recspeardata.sra_sra_id :=
            gbl_listofdesignation (cst_column_family).rds_sra_id;

         l_recspeardata.sra_designation := p_wk_loadspeardata.wls_genus;
      END IF;

      IF p_column = cst_column_taxa
      THEN
         -- Les données aditionelles sont associées  au genus
         l_recspeardata.sra_sra_id :=
            gbl_listofdesignation (cst_column_genus).rds_sra_id;

         l_recspeardata.sra_designation := p_wk_loadspeardata.wls_taxa;



         -- Les données aditionelles sont associées a la familly
         l_recspeardata.sra_spearvalue := p_wk_loadspeardata.wls_spear;
         l_recspeardata.sra_gt := p_wk_loadspeardata.wls_gt;
         l_recspeardata.sra_gt_source := p_wk_loadspeardata.wls_gt_source;
         l_recspeardata.sra_sens := p_wk_loadspeardata.wls_sens;
         l_recspeardata.sra_senssource := p_wk_loadspeardata.wls_senssource;
         l_recspeardata.sra_mig := p_wk_loadspeardata.wls_mig;
         l_recspeardata.sra_migsource := p_wk_loadspeardata.wls_migsource;
         l_recspeardata.sra_out := p_wk_loadspeardata.wls_out;
         l_recspeardata.sra_outsource := p_wk_loadspeardata.wls_outsource;
         l_recspeardata.sra_gtcode := p_wk_loadspeardata.wls_gtcode;
         l_recspeardata.sra_senscode := p_wk_loadspeardata.wls_senscode;
         l_recspeardata.sra_migcode := p_wk_loadspeardata.wls_migcode;
         l_recspeardata.sra_expcode := p_wk_loadspeardata.wls_expcode;
         l_recspeardata.sra_uncertainty := p_wk_loadspeardata.wls_uncertainty;
         l_recspeardata.sra_aqem_id := p_wk_loadspeardata.wls_aqem_id;
         l_recspeardata.sra_level := p_wk_loadspeardata.wls_level;
      END IF;


      p_write (l_recspeardata.sra_sra_id,
               l_recspeardata.sra_wls_id,
               l_recspeardata.sra_aqem_id,
               l_recspeardata.sra_level,
               l_recspeardata.sra_designation,
               l_recspeardata.sra_spearvalue,
               l_recspeardata.sra_gt_source,
               l_recspeardata.sra_sens,
               l_recspeardata.sra_senssource,
               l_recspeardata.sra_mig,
               l_recspeardata.sra_migsource,
               l_recspeardata.sra_out,
               l_recspeardata.sra_outsource,
               l_recspeardata.sra_gtcode,
               l_recspeardata.sra_senscode,
               l_recspeardata.sra_migcode,
               l_recspeardata.sra_expcode,
               l_id);
      gbl_listofdesignation (p_column).rds_sra_id := l_id;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getrecordbyaqem_id (p_aqem_id IN speardata.sra_aqem_id%TYPE)
      RETURN speardata%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_recspeardata   speardata%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recspeardata
        FROM speardata
       WHERE sra_aqem_id = p_aqem_id;

      RETURN l_recspeardata;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*---------------------------------------------------------------*/

   PROCEDURE p_build
   /*--------------------------------------------------------------*/
   IS
      CURSOR l_wk_loadspeardata
      IS
           SELECT *
             FROM wk_loadspeardata
         ORDER BY wls_group,
                  wls_family,
                  wls_genus,
                  wls_taxa;

      l_recwk_loadspeardata   l_wk_loadspeardata%ROWTYPE;
      l_recsystexternalcode   systexternalcode%ROWTYPE;
      l_sra_parent            speardata.sra_sra_id%TYPE;
      l_recsystvalue          systvalue%ROWTYPE;
      l_designation           systdesignation.syd_designation%TYPE;
   BEGIN
      p_clearalldata;
      pkg_debug.p_truncate;
      COMMIT;
      pkg_migr_utility.p_recreatesequence ('SPEARDATA',
                                           'SEQ_SPEARDATA',
                                           'SRA_ID');
      p_initgbl_listofdesignation;
      l_sra_parent := NULL;

      OPEN l_wk_loadspeardata;

      LOOP
         FETCH l_wk_loadspeardata INTO l_recwk_loadspeardata;

         EXIT WHEN l_wk_loadspeardata%NOTFOUND;

         l_designation :=
            f_comparedesignation (l_recwk_loadspeardata.wls_group,
                                  cst_column_group);

         IF l_designation IS NULL
         THEN
            -- Le group change

            gbl_listofdesignation (cst_column_group).rds_designation :=
               l_recwk_loadspeardata.wls_group;
            p_flushdata (l_recwk_loadspeardata, cst_column_group);
         END IF;



         l_designation :=
            f_comparedesignation (l_recwk_loadspeardata.wls_family,
                                  cst_column_family);

         IF l_designation IS NULL
         THEN
            -- La familly change

            gbl_listofdesignation (cst_column_family).rds_designation :=
               l_recwk_loadspeardata.wls_family;
            p_flushdata (l_recwk_loadspeardata, cst_column_family);
         END IF;



         l_designation :=
            f_comparedesignation (l_recwk_loadspeardata.wls_genus,
                                  cst_column_genus);

         IF l_designation IS NULL
         THEN
            -- Le genus change

            gbl_listofdesignation (cst_column_genus).rds_designation :=
               l_recwk_loadspeardata.wls_genus;
            p_flushdata (l_recwk_loadspeardata, cst_column_genus);
         END IF;


         l_designation :=
            f_comparedesignation (l_recwk_loadspeardata.wls_taxa,
                                  cst_column_taxa);

         IF l_designation IS NULL
         THEN
            -- Le TAXA Change

            gbl_listofdesignation (cst_column_taxa).rds_designation :=
               l_recwk_loadspeardata.wls_taxa;
            p_flushdata (l_recwk_loadspeardata, cst_column_taxa);
         END IF;
      /*
               l_recsystexternalcode :=
                  pkg_systexternalcode.f_getrecordbyexternalcode (
                     l_recwk_loadspeardata.wls_cscf_id,
                     pkg_codesource.cst_csc_cscf_nuesp);
                     */
      END LOOP;

      CLOSE l_wk_loadspeardata;
   --    p_identifycscfespece;
   END;
END pkg_speardata;
/

