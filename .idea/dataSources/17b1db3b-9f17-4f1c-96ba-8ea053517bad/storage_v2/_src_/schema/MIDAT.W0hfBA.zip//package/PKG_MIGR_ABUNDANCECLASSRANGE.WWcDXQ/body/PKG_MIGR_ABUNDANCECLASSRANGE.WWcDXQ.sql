create PACKAGE BODY       pkg_migr_abundanceclassrange
AS
   /******************************************************************************
      NAME:       PKG_MIGR_ABUNDANCECLASSRANGE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.02.2015      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, février 2015' ;
   cst_maxvalue         CONSTANT NUMBER := 999999999999;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_loadinchvarietyclass
   /*----------------------------------------------------------------*/
   IS
      l_reccodevalue   codevalue%ROWTYPE;
      l_id             abundanceclassrange.acr_id%TYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_ibch);

      IF l_reccodevalue.cvl_id IS NULL
      THEN
         raise_application_error (-20000, 'Codevalue non trouvé', TRUE);
      END IF;

      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       1,
                                       3,
                                       1,
                                       NULL,
                                       l_id);
      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       4,
                                       6,
                                       2,
                                       NULL,
                                       l_id);
      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       7,
                                       9,
                                       3,
                                       NULL,
                                       l_id);
      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       10,
                                       12,
                                       4,
                                       NULL,
                                       l_id);
      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       13,
                                       16,
                                       5,
                                       NULL,
                                       l_id);

      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       17,
                                       20,
                                       6,
                                       NULL,
                                       l_id);
      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       21,
                                       24,
                                       7,
                                       NULL,
                                       l_id);
      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       25,
                                       28,
                                       8,
                                       NULL,
                                       l_id);

      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       29,
                                       32,
                                       9,
                                       NULL,
                                       l_id);
      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       33,
                                       36,
                                       10,
                                       NULL,
                                       l_id);

      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       37,
                                       40,
                                       11,
                                       NULL,
                                       l_id);

      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       41,
                                       44,
                                       12,
                                       NULL,
                                       l_id);
      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       45,
                                       49,
                                       13,
                                       NULL,
                                       l_id);

      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       50,
                                       cst_maxvalue,
                                       14,
                                       NULL,
                                       l_id);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_loadmakroindexabundanceclass
   /*----------------------------------------------------------------*/
   IS
      l_reccodevalue   codevalue%ROWTYPE;
      l_id             abundanceclassrange.acr_id%TYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_makroindex);

      IF l_reccodevalue.cvl_id IS NULL
      THEN
         raise_application_error (-20000, 'Codevalue non trouvé', TRUE);
      END IF;

      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       1,
                                       10,
                                       1,
                                       6,
                                       l_id);
      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       11,
                                       30,
                                       2,
                                       20,
                                       l_id);

      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       31,
                                       70,
                                       3,
                                       50,
                                       l_id);

      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       71,
                                       110,
                                       4,
                                       110,
                                       l_id);
      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       151,
                                       300,
                                       5,
                                       225,
                                       l_id);
      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       301,
                                       700,
                                       6,
                                       500,
                                       l_id);

      pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                       701,
                                       cst_maxvalue,
                                       7,
                                       700,
                                       l_id);
   END;
END pkg_migr_abundanceclassrange;
/

