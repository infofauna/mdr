create PACKAGE BODY       pkg_sampleprotocolmass
AS
   /******************************************************************************
      NAME:       pkg_SAMPLEPROTOCOLMASS
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, mars  2015';



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_getrecord (p_id IN sampleprotocolmass.smx_id%TYPE)
      RETURN sampleprotocolmass%ROWTYPE
   /*-----------------------------------------------------------------*/
   IS
      l_recsampleprotocolmass   sampleprotocolmass%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recsampleprotocolmass
        FROM sampleprotocolmass
       WHERE smx_id = p_id;

      RETURN l_recsampleprotocolmass;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_deleteby_sph_id (
      p_sph_id   IN sampleprotocolmass.smx_sph_id%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleprotocolmass
            WHERE smx_sph_id = p_sph_id;
   END;

   /*----------------------------------------------------------------------------------*/
   PROCEDURE p_write (
      p_syy_id              IN     sampleprotocolmass.smx_syy_id%TYPE,
      p_sph_id              IN     sampleprotocolmass.smx_sph_id%TYPE,
      p_cvl_id_zoostadium   IN     sampleprotocolmass.smx_cvl_id_zoostadium%TYPE,
      p_highertaxon         IN     sampleprotocolmass.smx_highertaxon%TYPE,
      p_family              IN     sampleprotocolmass.smx_family%TYPE,
      p_genus               IN     sampleprotocolmass.smx_genus%TYPE,
      p_species             IN     sampleprotocolmass.smx_species%TYPE,
      p_subspecies          IN     sampleprotocolmass.smx_subspecies%TYPE,
      p_freq1               IN     sampleprotocolmass.smx_freq1%TYPE,
      p_freq2               IN     sampleprotocolmass.smx_freq2%TYPE,
      p_freqlum             IN     sampleprotocolmass.smx_freqlum%TYPE,
      p_stadium             IN     sampleprotocolmass.smx_stadium%TYPE,
      p_comment             IN     sampleprotocolmass.smx_comment%TYPE,
      p_taxonibch           IN     sampleprotocolmass.smx_taxonibch%TYPE,
      p_usr_id_create       IN     sampleprotocolmass.smx_usr_id_create%TYPE,
      p_id                     OUT sampleprotocolmass.smx_id%TYPE)
   /*----------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_sampleprotocolmass.NEXTVAL;

      INSERT INTO sampleprotocolmass (smx_id,
                                      smx_sph_id,
                                      smx_syy_id,
                                      smx_cvl_id_zoostadium,
                                      smx_highertaxon,
                                      smx_family,
                                      smx_genus,
                                      smx_species,
                                      smx_subspecies,
                                      smx_freq1,
                                      smx_freq2,
                                      smx_freqlum,
                                      smx_stadium,
                                      smx_comment,
                                      smx_taxonibch,
                                      smx_usr_id_create,
                                      smx_usr_create_date)
           VALUES (p_id,
                   p_sph_id,
                   p_syy_id,
                   p_cvl_id_zoostadium,
                   p_highertaxon,
                   p_family,
                   p_genus,
                   p_species,
                   p_subspecies,
                   p_freq1,
                   p_freq2,
                   p_freqlum,
                   p_stadium,
                   p_comment,
                   p_taxonibch,
                   p_usr_id_create,
                   SYSDATE);
   END;

   /*----------------------------------------------------------------------------------*/
   PROCEDURE p_write (
      p_syy_id              IN     sampleprotocolmass.smx_syy_id%TYPE,
      p_sph_id              IN     sampleprotocolmass.smx_sph_id%TYPE,
      p_cvl_id_zoostadium   IN     sampleprotocolmass.smx_cvl_id_zoostadium%TYPE,
      p_highertaxon         IN     sampleprotocolmass.smx_highertaxon%TYPE,
      p_family              IN     sampleprotocolmass.smx_family%TYPE,
      p_genus               IN     sampleprotocolmass.smx_genus%TYPE,
      p_species             IN     sampleprotocolmass.smx_species%TYPE,
      p_subspecies          IN     sampleprotocolmass.smx_subspecies%TYPE,
      p_freq1               IN     sampleprotocolmass.smx_freq1%TYPE,
      p_freq2               IN     sampleprotocolmass.smx_freq2%TYPE,
      p_freqlum             IN     sampleprotocolmass.smx_freqlum%TYPE,
      p_stadium             IN     sampleprotocolmass.smx_stadium%TYPE,
      p_comment             IN     sampleprotocolmass.smx_comment%TYPE,
      p_taxonibch           IN     sampleprotocolmass.smx_taxonibch%TYPE,
      p_usr_id_create       IN     sampleprotocolmass.smx_usr_id_create%TYPE,
      p_spl_id              IN     sampleprotocolmass.smx_spl_id%TYPE,
      p_id                     OUT sampleprotocolmass.smx_id%TYPE)
   /*----------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_sampleprotocolmass.NEXTVAL;

      INSERT INTO sampleprotocolmass (smx_id,
                                      smx_sph_id,
                                      smx_syy_id,
                                      smx_cvl_id_zoostadium,
                                      smx_highertaxon,
                                      smx_family,
                                      smx_genus,
                                      smx_species,
                                      smx_subspecies,
                                      smx_freq1,
                                      smx_freq2,
                                      smx_freqlum,
                                      smx_stadium,
                                      smx_comment,
                                      smx_spl_id,
                                      smx_taxonibch,
                                      smx_usr_id_create,
                                      smx_usr_create_date)
           VALUES (p_id,
                   p_sph_id,
                   p_syy_id,
                   p_cvl_id_zoostadium,
                   p_highertaxon,
                   p_family,
                   p_genus,
                   p_species,
                   p_subspecies,
                   p_freq1,
                   p_freq2,
                   p_freqlum,
                   p_stadium,
                   p_comment,
                   p_spl_id,
                   p_taxonibch,
                   p_usr_id_create,
                   SYSDATE);
   END;

   /*----------------------------------------------------------------------------------*/
   PROCEDURE p_write (
      p_syy_id              IN     sampleprotocolmass.smx_syy_id%TYPE,
      p_sph_id              IN     sampleprotocolmass.smx_sph_id%TYPE,
      p_cvl_id_zoostadium   IN     sampleprotocolmass.smx_cvl_id_zoostadium%TYPE,
      p_highertaxon         IN     sampleprotocolmass.smx_highertaxon%TYPE,
      p_family              IN     sampleprotocolmass.smx_family%TYPE,
      p_genus               IN     sampleprotocolmass.smx_genus%TYPE,
      p_species             IN     sampleprotocolmass.smx_species%TYPE,
      p_subspecies          IN     sampleprotocolmass.smx_subspecies%TYPE,
      p_freq1               IN     sampleprotocolmass.smx_freq1%TYPE,
      p_freq2               IN     sampleprotocolmass.smx_freq2%TYPE,
      p_freqlum             IN     sampleprotocolmass.smx_freqlum%TYPE,
      p_stadium             IN     sampleprotocolmass.smx_stadium%TYPE,
      p_comment             IN     sampleprotocolmass.smx_comment%TYPE,
      p_taxonibch           IN     sampleprotocolmass.smx_taxonibch%TYPE,
      p_usr_id_create       IN     sampleprotocolmass.smx_usr_id_create%TYPE,
      p_spl_id              IN     sampleprotocolmass.smx_spl_id%TYPE,
      p_imd_id              IN     sampleprotocolmass.smx_imd_id%TYPE,
      p_id                     OUT sampleprotocolmass.smx_id%TYPE)
   /*----------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_sampleprotocolmass.NEXTVAL;

      INSERT INTO sampleprotocolmass (smx_id,
                                      smx_sph_id,
                                      smx_syy_id,
                                      smx_cvl_id_zoostadium,
                                      smx_highertaxon,
                                      smx_family,
                                      smx_genus,
                                      smx_species,
                                      smx_subspecies,
                                      smx_freq1,
                                      smx_freq2,
                                      smx_freqlum,
                                      smx_stadium,
                                      smx_comment,
                                      smx_spl_id,
                                      smx_taxonibch,
                                      smx_imd_id,
                                      smx_usr_id_create,
                                      smx_usr_create_date)
           VALUES (p_id,
                   p_sph_id,
                   p_syy_id,
                   p_cvl_id_zoostadium,
                   p_highertaxon,
                   p_family,
                   p_genus,
                   p_species,
                   p_subspecies,
                   p_freq1,
                   p_freq2,
                   p_freqlum,
                   p_stadium,
                   p_comment,
                   p_spl_id,
                   p_taxonibch,
                   p_imd_id,
                   p_usr_id_create,
                   SYSDATE);
   END;

   /*----------------------------------------------------------------------------------*/
   PROCEDURE p_write (
      p_syy_id              IN     sampleprotocolmass.smx_syy_id%TYPE,
      p_sph_id              IN     sampleprotocolmass.smx_sph_id%TYPE,
      p_cvl_id_zoostadium   IN     sampleprotocolmass.smx_cvl_id_zoostadium%TYPE,
      p_highertaxon         IN     sampleprotocolmass.smx_highertaxon%TYPE,
      p_family              IN     sampleprotocolmass.smx_family%TYPE,
      p_genus               IN     sampleprotocolmass.smx_genus%TYPE,
      p_species             IN     sampleprotocolmass.smx_species%TYPE,
      p_subspecies          IN     sampleprotocolmass.smx_subspecies%TYPE,
      p_freq1               IN     sampleprotocolmass.smx_freq1%TYPE,
      p_freq2               IN     sampleprotocolmass.smx_freq2%TYPE,
      p_freqlum             IN     sampleprotocolmass.smx_freqlum%TYPE,
      p_stadium             IN     sampleprotocolmass.smx_stadium%TYPE,
      p_comment             IN     sampleprotocolmass.smx_comment%TYPE,
      p_taxonibch           IN     sampleprotocolmass.smx_taxonibch%TYPE,
      p_usr_id_create       IN     sampleprotocolmass.smx_usr_id_create%TYPE,
      p_spl_id              IN     sampleprotocolmass.smx_spl_id%TYPE,
      p_imd_id              IN     sampleprotocolmass.smx_imd_id%TYPE,
      p_sampleno            IN     sampleprotocolmass.smx_sampleno%TYPE,
      p_id                     OUT sampleprotocolmass.smx_id%TYPE)
   /*----------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_sampleprotocolmass.NEXTVAL;

      INSERT INTO sampleprotocolmass (smx_id,
                                      smx_sph_id,
                                      smx_syy_id,
                                      smx_cvl_id_zoostadium,
                                      smx_highertaxon,
                                      smx_family,
                                      smx_genus,
                                      smx_species,
                                      smx_subspecies,
                                      smx_freq1,
                                      smx_freq2,
                                      smx_freqlum,
                                      smx_stadium,
                                      smx_comment,
                                      smx_spl_id,
                                      smx_taxonibch,
                                      smx_imd_id,
                                      smx_sampleno,
                                      smx_usr_id_create,
                                      smx_usr_create_date)
           VALUES (p_id,
                   p_sph_id,
                   p_syy_id,
                   p_cvl_id_zoostadium,
                   p_highertaxon,
                   p_family,
                   p_genus,
                   p_species,
                   p_subspecies,
                   p_freq1,
                   p_freq2,
                   p_freqlum,
                   p_stadium,
                   p_comment,
                   p_spl_id,
                   p_taxonibch,
                   p_imd_id,
                   p_sampleno,
                   p_usr_id_create,
                   SYSDATE);
   END;
END pkg_sampleprotocolmass;
/

