create trigger TR_BUF_SAMPLEPROTOCOLLABO
    before update
    on SAMPLEPROTOCOLLABO
    for each row
DECLARE
BEGIN
 
   :new.SPL_moddate := SYSDATE;
   :new.SPL_moduser := USER;
END tr_buf_SAMPLEPROTOCOLLABO;

/

