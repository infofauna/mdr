create PACKAGE BODY       pkg_migr_protocolmappingmassfi
AS
   /******************************************************************************
      NAME:       pkg_migr_protocolmappingmassfi
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
      1.1        13.09.2017      burrif       2. MIDAT Version 2
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.1, septembre  2017' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;


   /*-------------------------------------------------------------*/
   PROCEDURE p_addv2 (ptv_id IN protocolmappingmassfield.pmm_ptv_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_remarkcode1,
         'IMD_REMARKCODE1',
         pkg_constante.cst_no,
         NULL);
      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_remarkcode2,
         'IMD_REMARKCODE2',
         pkg_constante.cst_no,
         NULL);
      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_remarkcode3,
         'IMD_REMARKCODE3',
         pkg_constante.cst_no,
         NULL);
      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_remarkcode4,
         'IMD_REMARKCODE4',
         pkg_constante.cst_no,
         NULL);
      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_remarktext,
         'IMD_REMARKTEXT',
         pkg_constante.cst_no,
         NULL);
      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_oidlink,
         'IMD_OIDLINK',
         pkg_constante.cst_no,
         NULL);
      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_determinator,
         'IMD_DETERMINATOR',
         pkg_constante.cst_no,
         NULL);
   END;

   /*-------------------------------------------------*/
   PROCEDURE p_updateversion_2
   /*-------------------------------------------------*/
   IS
   BEGIN
      p_addv2 (4);
   END;


   /*-------------------------------------------------------------*/
   PROCEDURE p_build (ptv_id IN protocolmappingmassfield.pmm_ptv_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (1024);
   BEGIN
      DELETE FROM protocolmappingmassfield;

      l_sql := 'DROP SEQUENCE SEQ_protocolmappingmassfield';

      EXECUTE IMMEDIATE l_sql;

      l_sql := 'CREATE SEQUENCE SEQ_protocolmappingmassfield';

      EXECUTE IMMEDIATE l_sql;



      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_higher,
         'IMD_HIGHERTAXON',
         pkg_constante.cst_no,
         'SYST');

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_family,
         'IMD_FAMILY',
         pkg_constante.cst_no,
         'SYST');

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_genus,
         'IMD_GENUS',
         pkg_constante.cst_no,
         'SYST');


      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_species,
         'IMD_SPECIES',
         pkg_constante.cst_no,
         'SYST');

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_subspe,
         'IMD_SUBSPECIES',
         pkg_constante.cst_no,
         'SYST');

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_freq1,
         'IMD_FREQ1',
         pkg_constante.cst_yes,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_freq2,
         'IMD_FREQ2',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_freqlum,
         'IMD_FREQLUM',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_stadium,
         'IMD_STADIUM',
         pkg_constante.cst_no,
         NULL);


      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_sampmeth,
         'IMD_SAMPLINGMETHOD',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_indicetype,
         'IMD_INDICETYPE',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_period,
         'IMD_PERIOD',
         pkg_constante.cst_no,
         NULL);


      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_day,
         'IMD_DAY',
         pkg_constante.cst_no,
         NULL);


      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_month,
         'IMD_MONTH',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_year,
         'IMD_YEAR',
         pkg_constante.cst_yes,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_water,
         'IMD_WATERCOURSE',
         pkg_constante.cst_yes,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_locality,
         'IMD_LOCALITY',
         pkg_constante.cst_yes,
         NULL);
      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_calledplace,
         'IMD_CALLEDPLACE',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_swiss_x,
         'IMD_SWISSCOORD_X',
         pkg_constante.cst_yes,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_swiss_y,
         'IMD_SWISSCOORD_Y',
         pkg_constante.cst_yes,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_swiss_z,
         'IMD_SWISSCOORD_Z',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_observer,
         'IMD_OBSERVERS',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_project,
         'IMD_PROJECT',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_taxondef,
         'IMD_TAXON_DEF',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_prec,
         'IMD_CODEPRECISION',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_systemprec,
         'IMD_SYSTEMPRECISION',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_samplnum,
         'IMD_SAMPLENUMBER',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_canton,
         'IMD_CANTON',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_oid,
         'IMD_OID',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_comment,
         'IMD_COMMENT',
         pkg_constante.cst_no,
         NULL);
      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_repurl,
         'IMD_REPORTURL',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_taxonibch,
         'IMD_TAXONIBCH',
         pkg_constante.cst_no,
         NULL);
      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_makroindex,
         'IMD_MAKROINDEXPROVIDE',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_spearindex,
         'IMD_SPEARINDEXPROVIDE',
         pkg_constante.cst_no,
         NULL);

      pkg_protocolmappingmassfield.p_write (
         ptv_id,
         pkg_codevalue.cst_midatfldcmt_ibchindex,
         'IMD_IBCHINDEXPROVIDE',
         pkg_constante.cst_no,
         NULL);
   END;
END pkg_migr_protocolmappingmassfi;
/

