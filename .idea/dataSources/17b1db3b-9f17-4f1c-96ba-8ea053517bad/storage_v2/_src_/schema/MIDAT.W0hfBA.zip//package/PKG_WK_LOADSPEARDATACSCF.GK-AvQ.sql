create PACKAGE       pkg_wk_loadspeardatacscf
AS
   /******************************************************************************
      NAME:       PKG_WK_LOADSPEARDATACSCF
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25/07/2014      burrif       1. Created this package.
   ******************************************************************************/



   cst_level_species       CONSTANT wk_loadspeardatacscf.wlf_level%TYPE
                                       := 'species' ;
   cst_level_genus         CONSTANT wk_loadspeardatacscf.wlf_level%TYPE
                                       := 'genus' ;
   cst_level_family        CONSTANT wk_loadspeardatacscf.wlf_level%TYPE
                                       := 'family' ;
   cst_level_order         CONSTANT wk_loadspeardatacscf.wlf_level%TYPE
                                       := 'order' ;
   cst_level_underorder    CONSTANT wk_loadspeardatacscf.wlf_level%TYPE
                                       := 'underorder' ;
   cst_level_underclass    CONSTANT wk_loadspeardatacscf.wlf_level%TYPE
                                       := 'underclass' ;
   cst_level_class         CONSTANT wk_loadspeardatacscf.wlf_level%TYPE
                                       := 'class' ;
   cst_level_underphylum   CONSTANT wk_loadspeardatacscf.wlf_level%TYPE
                                       := 'underphylum' ;
   cst_level_undergenus    CONSTANT wk_loadspeardatacscf.wlf_level%TYPE
                                       := 'undergenus' ;


   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecordby_aqem_id (
      wlf_aqem_id IN wk_loadspeardatacscf.wlf_aqem_id%TYPE)
      RETURN wk_loadspeardatacscf%ROWTYPE;

   FUNCTION f_getrecord (p_id IN wk_loadspeardatacscf.wlf_id%TYPE)
      RETURN wk_loadspeardatacscf%ROWTYPE;
END pkg_wk_loadspeardatacscf;
/

