create PACKAGE       pkg_validatemassheader
AS
   /******************************************************************************
      NAME:       pkg_validatemassheader
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
      1.1        26.09.2017      burrif       2. MIDAT Version 1
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_test;

   PROCEDURE p_validatemapping (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_lan_id                 IN     protocolmappingmassmap.pma_lan_id%TYPE, -- Langue de l'interface
      p_returnstatus              OUT NUMBER);

   PROCEDURE p_mastervalidate (p_iph_id IN importprotocolheader.iph_id%TYPE);

   PROCEDURE p_addmassfield (p_field IN VARCHAR2);

   PROCEDURE p_clearlistmassfield;

   PROCEDURE p_checkheaderallreadyexist (
      p_iph_id         IN     importprotocolheader.iph_id%TYPE,
      p_returnstatus      OUT NUMBER);

   PROCEDURE p_calculateindiceforallheader (
      p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                    IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id                    IN     language.lan_id%TYPE,
      p_returnstatus                 OUT NUMBER);

   PROCEDURE p_validateoidlink (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE);
END pkg_validatemassheader;
/

