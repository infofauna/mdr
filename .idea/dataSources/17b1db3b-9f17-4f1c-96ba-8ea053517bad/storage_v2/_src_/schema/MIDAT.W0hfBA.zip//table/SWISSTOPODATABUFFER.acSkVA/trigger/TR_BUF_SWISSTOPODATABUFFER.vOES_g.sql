create trigger TR_BUF_SWISSTOPODATABUFFER
    before update
    on SWISSTOPODATABUFFER
    for each row
DECLARE
BEGIN
  

   :new.SWB_moddate := SYSDATE;
   :new.SWB_moduser := USER;
END tr_buf_SWISSTOPODATABUFFER;

/

