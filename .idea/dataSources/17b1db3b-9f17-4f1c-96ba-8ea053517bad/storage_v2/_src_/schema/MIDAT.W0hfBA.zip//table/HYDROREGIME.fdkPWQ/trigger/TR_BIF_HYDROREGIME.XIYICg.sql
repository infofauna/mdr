create trigger TR_BIF_HYDROREGIME
    before insert
    on HYDROREGIME
    for each row
DECLARE
BEGIN
    IF :new.hdr_id IS NULL
    THEN
        :new.hdr_id := seq_hydroregime.NEXTVAL;
    END IF;

    :new.hdr_credate := SYSDATE;
    :new.hdr_creuser := USER;
END tr_bif_hydroregime;
/

