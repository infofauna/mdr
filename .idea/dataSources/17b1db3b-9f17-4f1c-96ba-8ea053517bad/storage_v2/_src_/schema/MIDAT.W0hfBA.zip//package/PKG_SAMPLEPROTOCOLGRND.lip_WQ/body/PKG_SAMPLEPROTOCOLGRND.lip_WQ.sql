create PACKAGE BODY       pkg_sampleprotocolgrnd
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEPROTOCOLGRND
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       25.07.2013  F.Burri           1. Created this package body.
   ******************************************************************************/


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_write (
      p_sph_id          IN     sampleprotocolgrnd.spd_sph_id%TYPE,
      p_pmr_id          IN     sampleprotocolgrnd.spd_pmr_id%TYPE,
      p_value           IN     sampleprotocolgrnd.spd_value%TYPE,
      p_usr_id_create   IN     sampleprotocolgrnd.spd_usr_id_create%TYPE,
      p_spd_id             OUT sampleprotocolgrnd.spd_id%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_spd_id := seq_sampleprotocolgrnd.NEXTVAL;

      INSERT INTO sampleprotocolgrnd (spd_id,
                                      spd_sph_id,
                                      spd_pmr_id,
                                      spd_value,
                                      spd_usr_id_create,
                                      spd_usr_create_date)
           VALUES (p_spd_id,
                   p_sph_id,
                   p_pmr_id,
                   p_value,
                   p_usr_id_create,
                   SYSDATE);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_deleteby_sph_id (
      p_sph_id IN sampleprotocolgrnd.spd_sph_id%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleprotocolgrnd
            WHERE spd_sph_id = p_sph_id;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecord (p_spd_id IN sampleprotocolgrnd.spd_id%TYPE)
      RETURN sampleprotocolgrnd%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record   sampleprotocolgrnd%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM sampleprotocolgrnd
       WHERE spd_id = p_spd_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
END pkg_sampleprotocolgrnd;
/

