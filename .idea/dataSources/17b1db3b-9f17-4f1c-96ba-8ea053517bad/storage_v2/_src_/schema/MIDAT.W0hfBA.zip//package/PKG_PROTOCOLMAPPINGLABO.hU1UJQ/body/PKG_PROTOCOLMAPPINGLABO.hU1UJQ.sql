create PACKAGE BODY       pkg_protocolmappinglabo
AS
    /******************************************************************************
       NAME:       PKG_PROTOCOLMAPPINGLABO
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        02.10.2013      burrif       1. Created this package.
    ******************************************************************************/



    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.0, septembre  2013' ;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-------------------------------------------------------------*/
   FUNCTION f_getrecordbyfieldtaxa (
      p_ptv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
      p_taxa     IN protocolmappinglabo.ptl_taxa%TYPE,
      p_indice   IN NUMBER)
      RETURN protocolmappinglabo%ROWTYPE
   /*------------------------------------------------------------*/
   IS
      l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
   BEGIN
      pkg_debug.p_write (
         'PKG_PROTOCOLMAPPINGLABO.f_getrecordbyfieldtaxa',
         'ptv_id=' || TO_CHAR (p_ptv_id) || ' p_taxa=' || p_taxa);


      CASE
         WHEN p_indice = 0
         THEN
            SELECT *
              INTO l_recprotocolmappinglabo
              FROM protocolmappinglabo
             WHERE     ptl_ptv_id = p_ptv_id
                   AND pkg_stringutil.f_normalisestring (ptl_taxa) =
                          pkg_stringutil.f_normalisestring (p_taxa);
         WHEN p_indice = 1 OR p_indice = 2
         THEN
            SELECT *
              INTO l_recprotocolmappinglabo
              FROM protocolmappinglabo
             WHERE     (    ptl_ptv_id = p_ptv_id
                        AND pkg_stringutil.f_normalisestring (
                               pkg_stringutil.f_extractsubstring (ptl_taxa,
                                                                  '/',
                                                                  p_indice)) =
                               pkg_stringutil.f_normalisestring (p_taxa))
                   AND ptl_ptv_id = p_ptv_id;
         ELSE
            RETURN NULL;
      END CASE;



      RETURN l_recprotocolmappinglabo;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_getrecordbyfieldtaxacscf (
      p_ptv_id     IN protocolmappinglabo.ptl_syv_id%TYPE,
      p_taxacscf   IN protocolmappinglabo.ptl_taxacscf%TYPE,
      p_indice     IN NUMBER)
      RETURN protocolmappinglabo%ROWTYPE
   /*------------------------------------------------------------*/
   IS
      l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
   BEGIN
      pkg_debug.p_write (
         'PKG_PROTOCOLMAPPINGLABO.f_getrecordbyfieldtaxacscf',
         'ptv_id=' || TO_CHAR (p_ptv_id) || ' p_taxacscf=' || p_taxacscf);

      CASE
         WHEN p_indice = 0
         THEN
            SELECT *
              INTO l_recprotocolmappinglabo
              FROM protocolmappinglabo
             WHERE     ptl_ptv_id = p_ptv_id
                   AND pkg_stringutil.f_normalisestring (ptl_taxacscf) =
                          pkg_stringutil.f_normalisestring (p_taxacscf);
         WHEN p_indice = 1 OR p_indice = 2
         THEN
            SELECT *
              INTO l_recprotocolmappinglabo
              FROM protocolmappinglabo
             WHERE     (    ptl_ptv_id = p_ptv_id
                        AND pkg_stringutil.f_normalisestring (
                               pkg_stringutil.f_extractsubstring (
                                  ptl_taxacscf,
                                  '/',
                                  p_indice)) =
                               pkg_stringutil.f_normalisestring (p_taxacscf))
                   AND ptl_ptv_id = p_ptv_id;
         ELSE
            RETURN NULL;
      END CASE;

      RETURN l_recprotocolmappinglabo;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
    /*-----------------------------------------------------------*/
    FUNCTION f_getrecordbytaxa (
        p_ptv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
        p_taxa     IN protocolmappinglabo.ptl_taxa%TYPE)
        RETURN protocolmappinglabo%ROWTYPE
    /*------------------------------------------------------------*/
    IS
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_indice                   NUMBER;
    BEGIN
        l_indice := 0;

        WHILE l_indice < 3 AND l_recprotocolmappinglabo.ptl_id IS NULL
        LOOP
            l_recprotocolmappinglabo :=
                f_getrecordbyfieldtaxa (p_ptv_id, p_taxa, l_indice);
            l_indice := l_indice + 1;
        END LOOP;

        IF NOT l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            RETURN l_recprotocolmappinglabo;
        END IF;

        l_indice := 0;

        WHILE l_indice < 3 AND l_recprotocolmappinglabo.ptl_id IS NULL
        LOOP
            l_recprotocolmappinglabo :=
                f_getrecordbyfieldtaxacscf (p_ptv_id, p_taxa, l_indice);
            l_indice := l_indice + 1;
        END LOOP;

        IF NOT l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            RETURN l_recprotocolmappinglabo;
        END IF;

        RETURN NULL;
    END;



   /*-----------------------------------------------------------*/
   FUNCTION f_findtaxa (p_taxon    IN protocolmappinglabo.ptl_taxa%TYPE,
                        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
      RETURN protocolmappinglabo%ROWTYPE
   /*-----------------------------------------------------------*/
   IS
      l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recprotocolmappinglabo
        FROM protocolmappinglabo
       WHERE     ptl_ptv_id = p_ptv_id
             AND pkg_stringutil.f_normalisestring (
                    pkg_stringutil.f_removedatainparenthesis (ptl_taxa)) =
                    pkg_stringutil.f_normalisestring (p_taxon);

      RETURN l_recprotocolmappinglabo;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

    /*-----------------------------------------------------------*/
    PROCEDURE p_test
    /*-----------------------------------------------------------*/
    IS
        CURSOR l_cursor IS
            SELECT syv_id
              FROM systvalue
             WHERE syv_syv_id IN
                       (SELECT ptl_syv_id
                          FROM protocolmappinglabo
                         WHERE     NOT ptl_syv_id IS NULL
                               AND ptl_ptv_id = 1
                               AND ptl_cellrowvalue IS NOT NULL);

        l_reccursor                l_cursor%ROWTYPE;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND;
            DBMS_OUTPUT.put_line ('Enfant SYV_ID=' || l_reccursor.syv_id);
            l_recprotocolmappinglabo :=
                f_identifyentrybyhierarchy (l_reccursor.syv_id, 1);
            DBMS_OUTPUT.put_line (
                   ' --> Parent SYV_ID='
                || l_recprotocolmappinglabo.ptl_syv_id
                || '  ('
                || l_recprotocolmappinglabo.ptl_taxa
                || ')');
        END LOOP;

        CLOSE l_cursor;
    END;

    /*------------------------------------------------------------*/
    FUNCTION f_identifyentrybyhierarchy1 (
        p_syv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
        RETURN protocolmappinglabo%ROWTYPE
    /*------------------------------------------------------------*/
    IS
        /* Si on dispose d'un identifiant de niveau inférieur à la famille,
             cette fonction permet de retourner le niveau inclu dan sle protocol de laboratoire */
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_syv_id                   systvalue.syv_id%TYPE;
        l_level                    NUMBER;
    BEGIN
        pkg_debug.p_write (
            'PKG_PROTOCOLMAPPINGLABIO.f_identifyentrybyhierarchy1',
            'p_syv_id=' || p_syv_id || 'p_ptv_id=' || p_ptv_id);

        SELECT syv_id, lev
          INTO l_syv_id, l_level
          FROM (    SELECT syv_id, LEVEL lev
                      FROM systvalue
                     WHERE syv_id IN (SELECT ptl_syv_id
                                        FROM protocolmappinglabo
                                       WHERE ptl_ptv_id = p_ptv_id
                                      INTERSECT
                                          SELECT syv_id
                                            FROM systvalue
                                      CONNECT BY PRIOR syv_syv_id = syv_id
                                      START WITH syv_id = p_syv_id)
                CONNECT BY PRIOR syv_syv_id = syv_id
                START WITH syv_id = p_syv_id)
         WHERE lev = (    SELECT MIN (LEVEL)
                            FROM systvalue
                           WHERE syv_id IN (SELECT ptl_syv_id
                                              FROM protocolmappinglabo
                                             WHERE ptl_ptv_id = p_ptv_id
                                            INTERSECT
                                                SELECT syv_id
                                                  FROM systvalue
                                            CONNECT BY PRIOR syv_syv_id = syv_id
                                            START WITH syv_id = p_syv_id)
                      CONNECT BY PRIOR syv_syv_id = syv_id
                      START WITH syv_id = p_syv_id);

        SELECT *
          INTO l_recprotocolmappinglabo
          FROM protocolmappinglabo
         WHERE ptl_syv_id = l_syv_id AND ptl_ptv_id = p_ptv_id AND ROWNUM < 2;

        RETURN l_recprotocolmappinglabo;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL; -- En priciape cette condition est remplie lorsque ptl_cellrowvalue est null ( exemple Diptera)
    END;

    /*------------------------------------------------------------*/
    FUNCTION f_identifyentrybyhierarchy2 (
        p_syv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
        RETURN protocolmappinglabo%ROWTYPE
    /*------------------------------------------------------------*/
    IS
        /* Si on dispose d'un identifiant de niveau inférieur à la famille,
             cette fonction permet de retourner le niveau inclu dan sle protocol de laboratoire */
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_syv_id                   systvalue.syv_id%TYPE;
        l_level                    NUMBER;
    BEGIN
        pkg_debug.p_write (
            'PKG_PROTOCOLMAPPINGLABIO.f_identifyentrybyhierarchy2',
            'p_syv_id=' || p_syv_id || 'p_ptv_id=' || p_ptv_id);

        SELECT syv_id, lev
          INTO l_syv_id, l_level
          FROM (    SELECT syv_id, LEVEL lev
                      FROM systvalue
                     WHERE syv_id IN (SELECT NVL (ptl_syv_id2, -1)
                                        FROM protocolmappinglabo
                                       WHERE ptl_ptv_id = p_ptv_id
                                      INTERSECT
                                          SELECT syv_id
                                            FROM systvalue
                                      CONNECT BY PRIOR syv_syv_id = syv_id
                                      START WITH syv_id = p_syv_id)
                CONNECT BY PRIOR syv_syv_id = syv_id
                START WITH syv_id = p_syv_id)
         WHERE lev = (    SELECT MIN (LEVEL)
                            FROM systvalue
                           WHERE syv_id IN (SELECT NVL (ptl_syv_id2, -1)
                                              FROM protocolmappinglabo
                                             WHERE ptl_ptv_id = p_ptv_id
                                            INTERSECT
                                                SELECT syv_id
                                                  FROM systvalue
                                            CONNECT BY PRIOR syv_syv_id = syv_id
                                            START WITH syv_id = p_syv_id)
                      CONNECT BY PRIOR syv_syv_id = syv_id
                      START WITH syv_id = p_syv_id);

        SELECT *
          INTO l_recprotocolmappinglabo
          FROM protocolmappinglabo
         WHERE     ptl_syv_id2 = l_syv_id
               AND ptl_ptv_id = p_ptv_id
               AND ROWNUM < 2;

        RETURN l_recprotocolmappinglabo;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL; -- En priciape cette condition est remplie lorsque ptl_cellrowvalue est null ( exemple Diptera)
    END;

    /*------------------------------------------------------------*/
    FUNCTION f_identifyentrybyhierarchy (
        p_syv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
        RETURN protocolmappinglabo%ROWTYPE
    /*------------------------------------------------------------*/
    IS
        /* Si on dispose d'un identifiant de niveau inférieur à la famille,
             cette fonction permet de retourner le niveau inclu dan sle protocol de laboratoire */
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        l_recprotocolmappinglabo :=
            f_identifyentrybyhierarchy1 (p_syv_id, p_ptv_id);

        IF l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            l_recprotocolmappinglabo :=
                f_identifyentrybyhierarchy2 (p_syv_id, p_ptv_id);
        END IF;

        RETURN l_recprotocolmappinglabo;
    END;


    /*------------------------------------------------------------*/
    FUNCTION f_identifyentrybyhierarchy_old (
        p_syv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
        RETURN protocolmappinglabo%ROWTYPE
    /*------------------------------------------------------------*/
    IS
        /* Si on dispose d'un identifiant de niveau inférieur à la famille,
             cette fonction permet de retourner le niveau inclu dan sle protocol de laboratoire */
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_syv_id                   systvalue.syv_id%TYPE;
        l_level                    NUMBER;
    BEGIN
        pkg_debug.p_write (
            'PKG_PROTOCOLMAPPINGLABIO.f_identifyentrybyhierarchy',
            'p_syv_id=' || p_syv_id || 'p_ptv_id=' || p_ptv_id);

        SELECT syv_id, lev
          INTO l_syv_id, l_level
          FROM (    SELECT syv_id, LEVEL lev
                      FROM systvalue
                     WHERE syv_id IN (SELECT ptl_syv_id
                                        FROM protocolmappinglabo
                                       WHERE ptl_ptv_id = p_ptv_id
                                      INTERSECT
                                          SELECT syv_id
                                            FROM systvalue
                                      CONNECT BY PRIOR syv_syv_id = syv_id
                                      START WITH syv_id = p_syv_id)
                CONNECT BY PRIOR syv_syv_id = syv_id
                START WITH syv_id = p_syv_id)
         WHERE lev = (    SELECT MIN (LEVEL)
                            FROM systvalue
                           WHERE syv_id IN (SELECT ptl_syv_id
                                              FROM protocolmappinglabo
                                             WHERE ptl_ptv_id = p_ptv_id
                                            INTERSECT
                                                SELECT syv_id
                                                  FROM systvalue
                                            CONNECT BY PRIOR syv_syv_id = syv_id
                                            START WITH syv_id = p_syv_id)
                      CONNECT BY PRIOR syv_syv_id = syv_id
                      START WITH syv_id = p_syv_id);

        SELECT *
          INTO l_recprotocolmappinglabo
          FROM protocolmappinglabo
         WHERE ptl_syv_id = l_syv_id AND ptl_ptv_id = p_ptv_id;

        RETURN l_recprotocolmappinglabo;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL; -- En priciape cette condition est remplie lorsque ptl_cellrowvalue est null ( exemple Diptera)
    END;

    /*------------------------------------------------------------*/
    FUNCTION f_getrecordfromsyv_id1 (
        p_syv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
        RETURN protocolmappinglabo%ROWTYPE
    /*-------------------------------------------------------------*/
    IS
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        SELECT protocolmappinglabo.*
          INTO l_recprotocolmappinglabo
          FROM protocolmappinglabo
         WHERE ptl_ptv_id = p_ptv_id AND ptl_syv_id = p_syv_id AND ROWNUM < 2;

        RETURN l_recprotocolmappinglabo;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*------------------------------------------------------------*/
    FUNCTION f_getrecordfromsyv_id2 (
        p_syv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
        RETURN protocolmappinglabo%ROWTYPE
    /*-------------------------------------------------------------*/
    IS
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        SELECT protocolmappinglabo.*
          INTO l_recprotocolmappinglabo
          FROM protocolmappinglabo
         WHERE     ptl_ptv_id = p_ptv_id
               AND ptl_syv_id2 = p_syv_id
               AND ROWNUM < 2;

        RETURN l_recprotocolmappinglabo;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*------------------------------------------------------------*/
    FUNCTION f_getrecordfromsyv_id (
        p_syv_id   IN protocolmappinglabo.ptl_syv_id%TYPE,
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
        RETURN protocolmappinglabo%ROWTYPE
    /*-------------------------------------------------------------*/
    IS
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        l_recprotocolmappinglabo :=
            f_getrecordfromsyv_id1 (p_syv_id, p_ptv_id);

        IF l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            l_recprotocolmappinglabo :=
                f_getrecordfromsyv_id2 (p_syv_id, p_ptv_id);
        END IF;

        RETURN l_recprotocolmappinglabo;
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_write (
        p_ptl_id              IN     protocolmappinglabo.ptl_ptl_id%TYPE,
        p_ptv_id              IN     protocolmappinglabo.ptl_ptv_id%TYPE,
        p_syv_id              IN     protocolmappinglabo.ptl_syv_id%TYPE,
        p_cellrowvalue        IN     protocolmappinglabo.ptl_cellrowvalue%TYPE,
        p_cellcolumnvalue     IN     protocolmappinglabo.ptl_cellcolumnvalue%TYPE,
        p_taxa                IN     protocolmappinglabo.ptl_taxa%TYPE,
        p_taxacscf            IN     protocolmappinglabo.ptl_taxacscf%TYPE,
        p_crf_id_level        IN     protocolmappinglabo.ptl_crf_id_level%TYPE,
        p_ibchfaunagroup_gi   IN     protocolmappinglabo.ptl_ibchfaunagroup_gi%TYPE,
        p_ibchindividumin     IN     protocolmappinglabo.ptl_ibchindividumin%TYPE,
        p_spearindexfactor    IN     protocolmappinglabo.ptl_spearindexfactor%TYPE,
        p_isnotnull           IN     protocolmappinglabo.ptl_isnotnull%TYPE,
        p_isnotnullgroup      IN     protocolmappinglabo.ptl_isnotnullgroup%TYPE,
        p_id                     OUT protocolmappinglabo.ptl_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        p_id := seq_protocolmappinglabo.NEXTVAL;

        INSERT INTO protocolmappinglabo (ptl_ptl_id,
                                         ptl_ptv_id,
                                         ptl_syv_id,
                                         ptl_cellrowvalue,
                                         ptl_cellcolumnvalue,
                                         ptl_taxa,
                                         ptl_taxacscf,
                                         ptl_crf_id_level,
                                         ptl_ibchfaunagroup_gi,
                                         ptl_ibchindividumin,
                                         ptl_spearindexfactor,
                                         ptl_isnotnull,
                                         ptl_isnotnullgroup,
                                         ptl_id)
             VALUES (p_ptl_id,
                     p_ptv_id,
                     p_syv_id,
                     p_cellrowvalue,
                     p_cellcolumnvalue,
                     p_taxa,
                     p_taxacscf,
                     p_crf_id_level,
                     p_ibchfaunagroup_gi,
                     p_ibchindividumin,
                     p_spearindexfactor,
                     p_isnotnull,
                     p_isnotnullgroup,
                     p_id);

        NULL;
    END;

    /*-------------------------------------------------------------*/
    FUNCTION f_getrecord (p_ptl_id IN protocolmappinglabo.ptl_id%TYPE)
        RETURN protocolmappinglabo%ROWTYPE
    /*-------------------------------------------------------------*/
    IS
        l_record   protocolmappinglabo%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_record
          FROM protocolmappinglabo
         WHERE ptl_id = p_ptl_id;

        RETURN l_record;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;
END;
/

