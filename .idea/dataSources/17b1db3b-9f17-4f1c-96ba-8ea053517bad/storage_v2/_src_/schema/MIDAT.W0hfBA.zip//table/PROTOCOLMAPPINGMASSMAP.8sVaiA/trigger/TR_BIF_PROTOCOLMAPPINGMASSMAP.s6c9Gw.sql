create trigger TR_BIF_PROTOCOLMAPPINGMASSMAP
    before insert
    on PROTOCOLMAPPINGMASSMAP
    for each row
DECLARE
BEGIN
   IF :new.PMA_id IS NULL
   THEN
      :new.PMA_id := seq_PROTOCOLMAPPINGMASSMAP.NEXTVAL;
   END IF;

   :new.PMA_credate := SYSDATE;
   :new.PMA_creuser := USER;
END TR_BIF_PROTOCOLMAPPINGMASSMAP;

/

