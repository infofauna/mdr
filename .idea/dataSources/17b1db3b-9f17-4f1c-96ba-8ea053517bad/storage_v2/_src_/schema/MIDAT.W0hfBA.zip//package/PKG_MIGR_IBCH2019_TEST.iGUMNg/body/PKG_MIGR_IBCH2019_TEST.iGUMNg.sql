create PACKAGE BODY       pkg_migr_ibch2019_test
AS
    /******************************************************************************
      NAME:       PKG_MIGR_IBCH2019_TEST
      PURPOSE:     Test

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
   ******************************************************************************/



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*------------------------------------------------------------------------*/
    PROCEDURE p_testspear
    /*------------------------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (611);
        pkg_spear2019.p_maincompute (l_recimportprotocolheader, NULL);
        DBMS_OUTPUT.put_line ('Spear=' || pkg_spear2019.f_getspear);
    END;


    /*-----------------------------------------------------------------*/
    PROCEDURE p_test_protocole
    /*-----------------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (611);
        pkg_ibch2019.p_maincompute (l_recimportprotocolheader, NULL);
        DBMS_OUTPUT.put_line (' -------------Display frequence -----------');
        pkg_ibch2019.p_displayfrequence;

        DBMS_OUTPUT.put_line (
            ' -------------Display frequence sort -----------');
        pkg_ibch2019.p_displayfrequencesort;

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_gettaxonfrequencesum='
            || pkg_ibch2019.f_gettaxonfrequencesum);
        pkg_ibch2019.p_compute_ibch2019;
        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getgimax=' || pkg_ibch2019.f_getgimax);

        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getsumfamily=' || pkg_ibch2019.f_getsumfamily);



        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getsumfamilycorrected='
            || pkg_ibch2019.f_getsumfamilycorrected);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getclassevariete_corr='
            || pkg_ibch2019.f_getclassevariete_corr);



        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getgimaxrobust=' || pkg_ibch2019.f_getgimaxrobust);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getsumfamilyrobust='
            || pkg_ibch2019.f_getsumfamilyrobust);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getsumfamilyrobustcorrected='
            || pkg_ibch2019.f_getsumfamilyrobustcorrected);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getclassevariete_robust_corr='
            || pkg_ibch2019.f_getclassevarieterobust_corr);



        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getgi_final=' || pkg_ibch2019.f_getgi_final);



        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getclassevariete_final='
            || pkg_ibch2019.f_getclassevariete_final);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getgirobust_final='
            || pkg_ibch2019.f_getgirobust_final);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getclassevarieterobust_final='
            || pkg_ibch2019.f_getclassevarieterobust_final);

        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getibch=' || pkg_ibch2019.f_getibch);

        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getibchrobust=' || pkg_ibch2019.f_getibchrobust);

        DBMS_OUTPUT.put_line (' -------------Display group gi -----------');
        pkg_ibch2019.p_displaygroup_gi;



        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_gettaxonindicateur='
            || pkg_ibch2019.f_gettaxonindicateur);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getplecopteracounter='
            || pkg_ibch2019.f_getplecopteracounter);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getephemeropteracounter='
            || pkg_ibch2019.f_getephemeropteracounter);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_gettrichopteracounter='
            || pkg_ibch2019.f_gettrichopteracounter);



        DBMS_OUTPUT.put_line (
               ' Mollusca counter:='
            || pkg_ibch2019.f_getcounterbytaxa (6, 'Mollusca'));
    END;


    /*-----------------------------------------------------------------*/
    PROCEDURE p_test
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        pkg_ibch2019.p_init;
        pkg_ibch2019.p_cascadefrequence (332, 1);
        pkg_ibch2019.p_cascadefrequence (333, 1);
        pkg_ibch2019.p_cascadefrequence (335, 2);
        pkg_ibch2019.p_cascadefrequence (375, 3);
        pkg_ibch2019.p_cascadefrequence (385, 11);
        pkg_ibch2019.p_cascadefrequence (407, 1);
        pkg_ibch2019.p_cascadefrequence (484, 12);
        pkg_ibch2019.p_setibch_q (6);
        pkg_ibch2019.p_compute_ibch2019;
        DBMS_OUTPUT.put_line (' -------------Display frequence -----------');
        pkg_ibch2019.p_displayfrequence;

        DBMS_OUTPUT.put_line (
            ' -------------Display frequence sort -----------');
        pkg_ibch2019.p_displayfrequencesort;

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_gettaxonfrequencesum='
            || pkg_ibch2019.f_gettaxonfrequencesum);
        pkg_ibch2019.p_compute_ibch2019;
        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getgimax=' || pkg_ibch2019.f_getgimax);

        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getsumfamily=' || pkg_ibch2019.f_getsumfamily);



        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getsumfamilycorrected='
            || pkg_ibch2019.f_getsumfamilycorrected);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getclassevariete_corr='
            || pkg_ibch2019.f_getclassevariete_corr);



        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getgimaxrobust=' || pkg_ibch2019.f_getgimaxrobust);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getsumfamilyrobust='
            || pkg_ibch2019.f_getsumfamilyrobust);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getsumfamilyrobustcorrected='
            || pkg_ibch2019.f_getsumfamilyrobustcorrected);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getclassevariete_robust_corr='
            || pkg_ibch2019.f_getclassevarieterobust_corr);



        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getgi_final=' || pkg_ibch2019.f_getgi_final);



        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getclassevariete_final='
            || pkg_ibch2019.f_getclassevariete_final);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getgirobust_final='
            || pkg_ibch2019.f_getgirobust_final);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getclassevarieterobust_final='
            || pkg_ibch2019.f_getclassevarieterobust_final);

        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getibch=' || pkg_ibch2019.f_getibch);

        DBMS_OUTPUT.put_line (
            'pkg_ibch2019.f_getibchrobust=' || pkg_ibch2019.f_getibchrobust);

        DBMS_OUTPUT.put_line (' -------------Display group gi -----------');
        pkg_ibch2019.p_displaygroup_gi;



        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_gettaxonindicateur='
            || pkg_ibch2019.f_gettaxonindicateur);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getplecopteracounter='
            || pkg_ibch2019.f_getplecopteracounter);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_getephemeropteracounter='
            || pkg_ibch2019.f_getephemeropteracounter);

        DBMS_OUTPUT.put_line (
               'pkg_ibch2019.f_gettrichopteracounter='
            || pkg_ibch2019.f_gettrichopteracounter);



        DBMS_OUTPUT.put_line (
               ' Mollusca counter:='
            || pkg_ibch2019.f_getcounterbytaxa (6, 'Mollusca'));
    END;
END pkg_migr_ibch2019_test;
/

