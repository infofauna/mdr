create PACKAGE BODY       pkg_migr_ibch2019_pmh
AS
    /******************************************************************************
       NAME:       PKG_MIGR_IBCH2019_pmh
       PURPOSE:    Modification dans la table PROTOCOLMAPPINGHEADER

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       15.05.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_deletedata (
        p_ptv_id_dest   IN protocolmappingheader.pmh_ptv_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM protocolmappingheader
              WHERE pmh_ptv_id = p_ptv_id_dest;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_copydata (
        p_ptv_id_src    IN protocolmappingheader.pmh_ptv_id%TYPE,
        p_ptv_id_dest   IN protocolmappingheader.pmh_ptv_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
    
    BEGIN
        INSERT INTO protocolmappingheader (pmh_ptv_id,
                                           pmh_cvl_id_midathditem,
                                           pmh_cellrowvalue,
                                           pmh_cellcolumnvalue,
                                           pmh_fieldnameto,
                                           pmh_cvl_code_midathditem,
                                           pmh_cvl_id_datatype,
                                           pmh_isnotnull)
            SELECT p_ptv_id_dest,
                   pmh_cvl_id_midathditem,
                   pmh_cellrowvalue,
                   pmh_cellcolumnvalue,
                   pmh_fieldnameto,
                   pmh_cvl_code_midathditem,
                   pmh_cvl_id_datatype,
                   pmh_isnotnull
              FROM protocolmappingheader
             WHERE     pmh_ptv_id = p_ptv_id_src
                   AND pmh_cvl_code_midathditem !=
                       pkg_codevalue.cst_midathditem_absoluteflag;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_updatechangemapping (
        p_ptv_id_dest   IN protocolmappingheader.pmh_ptv_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        -- OID
        UPDATE protocolmappingheader
           SET pmh_cellrowvalue = 1, pmh_cellcolumnvalue = 'Z'
         WHERE     pmh_ptv_id = p_ptv_id_dest
               AND pmh_cvl_code_midathditem =
                   pkg_codevalue.cst_midathditem_id;

        -- IBCHVALUE
        UPDATE protocolmappingheader
           SET pmh_cellrowvalue = 99, pmh_cellcolumnvalue = 'AD'
         WHERE     pmh_ptv_id = p_ptv_id_dest
               AND pmh_cvl_code_midathditem =
                   pkg_codevalue.cst_midathditem_ibchvalue;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_writeoneentry (
        p_ptv_id            IN protocolmappingheader.pmh_ptv_id%TYPE,
        p_midathditem       IN codevalue.cvl_code%TYPE,
        p_cvl_id_datatype   IN codevalue.cvl_id%TYPE,
        p_row               IN protocolmappingheader.pmh_cellrowvalue%TYPE,
        p_column            IN protocolmappingheader.pmh_cellcolumnvalue%TYPE,
        p_notnull           IN protocolmappingheader.pmh_isnotnull%TYPE)
    /*----------------------------------------------------------------*/
    IS
        l_reccodevalue   codevalue%ROWTYPE;
        l_pmh_id         protocolmappingheader.pmh_id%TYPE;
    BEGIN
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midathditem,
                p_midathditem);
        pkg_protocolmappingheader.p_write (p_ptv_id,
                                           l_reccodevalue.cvl_id,
                                           p_row,
                                           p_column,
                                           'IPH_' || p_midathditem,
                                           p_midathditem,
                                           p_cvl_id_datatype,
                                           p_notnull,
                                           NULL,
                                           l_pmh_id);
        pkg_debug.p_write ('pkg_migr_ibch2019_pmh.p_writeoneentry',
                           'INFO*** Ajout de l''entrée: ' || p_midathditem);
    END;


    /*----------------------------------------------------------------*/
    PROCEDURE p_addnewdata (
        p_ptv_id   IN protocolmappingheader.pmh_ptv_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
        l_reccodevaluedatatype_str    codevalue%ROWTYPE;
        l_reccodevaluedatatype_pint   codevalue%ROWTYPE;
        l_reccodevaluedatatype_num    codevalue%ROWTYPE;
        l_pmh_id                      protocolmappingheader.pmh_id%TYPE;
    BEGIN
        l_reccodevaluedatatype_str :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_datatype,
                pkg_codevalue.cst_datatype_string);
        l_reccodevaluedatatype_pint :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_datatype,
                pkg_codevalue.cst_datatype_posinteger);

        l_reccodevaluedatatype_num :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_datatype,
                pkg_codevalue.cst_datatype_double);

        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_autreneoz_1, ---p_midathditem
                         l_reccodevaluedatatype_str.cvl_id, -- p_cvl_id_datatype
                         96,                                          -- p_row
                         'E',                                --p_column      ,
                         pkg_constante.cst_no);                    --p_notnull


        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_autreneoz_2, ---p_midathditem
                         l_reccodevaluedatatype_str.cvl_id, -- p_cvl_id_datatype
                         96,                                          -- p_row
                         'V',                                --p_column      ,
                         pkg_constante.cst_no);                    --p_notnull

        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_sommeept, ---p_midathditem
                         l_reccodevaluedatatype_num.cvl_id, -- p_cvl_id_datatype
                         97,                                          -- p_row
                         'M',                                --p_column      ,
                         pkg_constante.cst_yes);                   --p_notnull


        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_sommeneoz, ---p_midathditem
                         l_reccodevaluedatatype_num.cvl_id, -- p_cvl_id_datatype
                         98,                                          -- p_row
                         'M',                                --p_column      ,
                         pkg_constante.cst_yes);                   --p_notnull

        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_sommeabon, ---p_midathditem
                         l_reccodevaluedatatype_num.cvl_id, -- p_cvl_id_datatype
                         99,                                          -- p_row
                         'M',                                --p_column      ,
                         pkg_constante.cst_yes);                   --p_notnull



        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_sommetxobs, ---p_midathditem
                         l_reccodevaluedatatype_num.cvl_id, -- p_cvl_id_datatype
                         97,                                          -- p_row
                         'V',                                --p_column      ,
                         pkg_constante.cst_yes);                   --p_notnull


        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_sommetxcor, ---p_midathditem
                         l_reccodevaluedatatype_num.cvl_id, -- p_cvl_id_datatype
                         98,                                          -- p_row
                         'V',                                --p_column      ,
                         pkg_constante.cst_no);                   --p_notnull


        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_valeurvt, ---p_midathditem
                         l_reccodevaluedatatype_num.cvl_id, -- p_cvl_id_datatype
                         97,                                          -- p_row
                         'AD',                               --p_column      ,
                         pkg_constante.cst_yes);                   --p_notnull


        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_valeurgi, ---p_midathditem
                         l_reccodevaluedatatype_num.cvl_id, -- p_cvl_id_datatype
                         98,                                          -- p_row
                         'AD',                               --p_column      ,
                         pkg_constante.cst_yes);                   --p_notnull

        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_ibchq, ---p_midathditem
                         l_reccodevaluedatatype_pint.cvl_id, -- p_cvl_id_datatype
                         7,                                           -- p_row
                         'Z',                                --p_column      ,
                         pkg_constante.cst_yes);                   --p_notnull


        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_vc,    ---p_midathditem
                         l_reccodevaluedatatype_num.cvl_id, -- p_cvl_id_datatype
                         7,                                           -- p_row
                         'AD',                               --p_column      ,
                         pkg_constante.cst_yes);                   --p_notnull
        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_ibchvalue_r, ---p_midathditem
                         l_reccodevaluedatatype_num.cvl_id, -- p_cvl_id_datatype
                         100,                                         -- p_row
                         'AD',                               --p_column      ,
                         pkg_constante.cst_yes);                   --p_notnull
        p_writeoneentry (p_ptv_id,
                         pkg_codevalue.cst_midathditem_spearvalue, ---p_midathditem
                         l_reccodevaluedatatype_num.cvl_id, -- p_cvl_id_datatype
                         100,                                         -- p_row
                         'V',                                --p_column      ,
                         pkg_constante.cst_yes);                   --p_notnull
    END;
END pkg_migr_ibch2019_pmh;
/

