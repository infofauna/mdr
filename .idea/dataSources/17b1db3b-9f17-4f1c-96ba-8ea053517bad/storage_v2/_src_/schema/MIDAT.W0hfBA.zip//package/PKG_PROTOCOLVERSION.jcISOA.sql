create PACKAGE       pkg_protocolversion
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLVERSION
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   cst_version_1_0   CONSTANT protocolversion.ptv_version%TYPE := '1.0';

   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_returnlistversion (
      p_cvl_id_protocoltype   IN protocolversion.ptv_cvl_id_protocoltype%TYPE)
      RETURN VARCHAR2;

   FUNCTION f_countprotocoltype (
      p_cvl_id_protocoltype   IN protocolversion.ptv_cvl_id_protocoltype%TYPE)
      RETURN NUMBER;

   PROCEDURE p_split_version (p_version      IN     VARCHAR2,
                              p_master          OUT NUMBER,
                              p_subversion      OUT NUMBER);

   PROCEDURE p_updatepvtidlobofrommass (
      p_ptv_id                IN protocolversion.ptv_id%TYPE,
      p_ptv_id_labofrommass   IN protocolversion.ptv_ptv_id_labofrommass%TYPE);

   FUNCTION f_getrecord (p_ptv_id IN protocolversion.ptv_id%TYPE)
      RETURN protocolversion%ROWTYPE;

   PROCEDURE p_updatefiletemplate (p_ptv_id         IN protocolversion.ptv_id%TYPE,
                                   p_directoryref   IN VARCHAR2,
                                   p_filename       IN VARCHAR2);
END pkg_protocolversion;
/

