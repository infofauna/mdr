create function getMaxMemorySize return number
is language java name
'oracle.aurora.vm.OracleRuntime.getMaxMemorySize() returns long';
/

