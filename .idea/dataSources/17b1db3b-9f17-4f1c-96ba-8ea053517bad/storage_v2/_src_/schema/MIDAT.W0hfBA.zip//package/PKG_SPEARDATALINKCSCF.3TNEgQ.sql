create PACKAGE       pkg_speardatalinkcscf
AS
   /******************************************************************************
      NAME:       PKG_SPEARDATALINKCSCF
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25/07/2014      burrif       1. Created this package.
      2.0        05.102017       burrif       2. Nouveau calcul de spear avec version
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_loadfromloadtable (
      p_spv_id   IN speardatalinkcscf.sdf_ivr_id%TYPE);

   FUNCTION f_returnspearindex (
      p_spv_id   IN speardatalinkcscf.sdf_ivr_id%TYPE,
      p_syv_id   IN speardatalinkcscf.sdf_syv_id%TYPE)
      RETURN speardatalinkcscf.sdf_spearindex%TYPE;

   FUNCTION f_returnspearindex (
      p_syv_id   IN speardatalinkcscf.sdf_syv_id%TYPE)
      RETURN speardatalinkcscf.sdf_spearindex%TYPE;

   PROCEDURE p_write (
      p_aqem_id      IN     speardatalinkcscf.sdf_aqem_id%TYPE,
      p_syv_id       IN     speardatalinkcscf.sdf_syv_id%TYPE,
      p_spearindex   IN     speardatalinkcscf.sdf_spearindex%TYPE,
      p_id              OUT speardatalinkcscf.sdf_id%TYPE);

   PROCEDURE p_build;
/*
   FUNCTION f_getspearindexbysyvid (
      p_syv_id   IN speardatalinkcscf.sdf_syv_id%TYPE)
      RETURN speardatalinkcscf.sdf_spearindex%TYPE;
      

   FUNCTION f_getspearindexbyaqem_id (
      p_aqem_id   IN speardatalinkcscf.sdf_aqem_id%TYPE)
      RETURN speardatalinkcscf.sdf_spearindex%TYPE;
      
   */   
       FUNCTION f_routereturnspearindex (
      p_syv_id   IN speardatalinkcscf.sdf_syv_id%TYPE)
      RETURN speardatalinkcscf.sdf_spearindex%TYPE;  
END pkg_speardatalinkcscf;
/

