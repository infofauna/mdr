create PACKAGE BODY       pkg_wk_loadspeardatacscf
AS
   /******************************************************************************
      NAME:       PKG_WK_LOADSPEARDATACSCF
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25/07/2014      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, juillet  2014' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_clearalldata
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM wk_loadspeardatacscf;
   END;

   /*-----------------------------------------------------------------*/
   FUNCTION f_getrecord (p_id IN wk_loadspeardatacscf.wlf_id%TYPE)
      RETURN wk_loadspeardatacscf%ROWTYPE
   /*------------------------------------------------------------------*/
   IS
      l_recwk_loadspeardatacscf   wk_loadspeardatacscf%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recwk_loadspeardatacscf
        FROM wk_loadspeardatacscf
       WHERE wlf_id = p_id;

      RETURN l_recwk_loadspeardatacscf;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-----------------------------------------------------------------*/
   FUNCTION f_getrecordby_aqem_id (
      wlf_aqem_id IN wk_loadspeardatacscf.wlf_aqem_id%TYPE)
      RETURN wk_loadspeardatacscf%ROWTYPE
   /*------------------------------------------------------------------*/
   IS
      l_recwk_loadspeardatacscf   wk_loadspeardatacscf%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recwk_loadspeardatacscf
        FROM wk_loadspeardatacscf
       WHERE TRIM(wlf_aqem_id) = TRIM(wlf_aqem_id);

      RETURN l_recwk_loadspeardatacscf;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
END pkg_wk_loadspeardatacscf;
/

