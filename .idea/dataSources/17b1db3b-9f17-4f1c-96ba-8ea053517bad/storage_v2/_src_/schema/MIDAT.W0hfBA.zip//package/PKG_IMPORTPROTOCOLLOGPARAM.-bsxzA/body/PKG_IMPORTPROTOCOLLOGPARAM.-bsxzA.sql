create PACKAGE BODY       pkg_importprotocollogparam
AS
   /******************************************************************************
      NAME:       PKG_IMPORTPROTOCOLLOGPARAM
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        01.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, octobre 2013';
   gbl_usr_id_create             importprotocollogparam.ipr_usr_id_create%TYPE
      := NULL;


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_setwebuserinfo (
      p_usr_id_create importprotocollogparam.ipr_usr_id_create%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      gbl_usr_id_create := p_usr_id_create;
   END;


   /*-----------------------------------------------------------------*/
   PROCEDURE p_insert (
      p_ipr_ipo_id       importprotocollogparam.ipr_ipo_id%TYPE,
      p_ipr_sequence     importprotocollogparam.ipr_sequence%TYPE,
      p_ipr_parameter    importprotocollogparam.ipr_parameter%TYPE)
   /*-------------------------------------------------------------------*/
   IS

   BEGIN
      IF gbl_usr_id_create IS NULL
      THEN
         INSERT
           INTO importprotocollogparam (ipr_ipo_id,
                                        ipr_sequence,
                                        ipr_parameter)
         VALUES (p_ipr_ipo_id, p_ipr_sequence, p_ipr_parameter);
      ELSE
         INSERT INTO importprotocollogparam (ipr_ipo_id,
                                             ipr_sequence,
                                             ipr_parameter,
                                             ipr_usr_id_create,
                                             ipr_usr_create_date)
              VALUES (p_ipr_ipo_id,
                      p_ipr_sequence,
                      p_ipr_parameter,
                      gbl_usr_id_create,
                      SYSDATE);
      END IF;
      
   END;

   /*-------------------------------------------------------------------------------------*/
   FUNCTION f_getparameter (
      p_ipo_id     IN importprotocollogparam.ipr_ipo_id%TYPE,
      p_sequence   IN importprotocollogparam.ipr_sequence%TYPE)
      RETURN importprotocollogparam.ipr_parameter%TYPE
   /*--------------------------------------------------------------------------------------*/
   IS
      l_parameter   importprotocollogparam.ipr_parameter%TYPE;
   BEGIN
      SELECT ipr_parameter
        INTO l_parameter
        FROM importprotocollogparam
       WHERE ipr_ipo_id = p_ipo_id AND ipr_sequence = p_sequence;

      RETURN l_parameter;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
END pkg_importprotocollogparam;
/

