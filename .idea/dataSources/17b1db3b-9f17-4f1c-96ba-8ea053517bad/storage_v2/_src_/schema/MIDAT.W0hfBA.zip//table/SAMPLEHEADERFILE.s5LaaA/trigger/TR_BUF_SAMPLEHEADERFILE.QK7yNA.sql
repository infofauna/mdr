create trigger TR_BUF_SAMPLEHEADERFILE
    before update
    on SAMPLEHEADERFILE
    for each row
DECLARE
   l_newrec   SAMPLEHEADERFILE%ROWTYPE;
   l_oldrec   SAMPLEHEADERFILE%ROWTYPE;
BEGIN
   l_oldrec.SHF_id := :old.SHF_id;
   l_oldrec.SHF_status := :old.SHF_status;
   l_oldrec.SHF_sph_id := :old.SHF_sph_id;
    l_oldrec.SHF_ptv_id := :old.SHF_ptv_id;
 
    l_oldrec.SHF_FILE := :old.SHF_FILE;
   l_oldrec.SHF_credate := :old.SHF_credate;
   l_oldrec.SHF_creuser := :old.SHF_creuser;
   l_oldrec.SHF_moddate := :old.SHF_moddate;
   l_oldrec.SHF_moduser := :old.SHF_moduser;


   l_newrec.SHF_id := :new.SHF_id;
   l_newrec.SHF_status := :new.SHF_status;
   l_newrec.SHF_sph_id := :new.SHF_sph_id;
   l_newrec.SHF_ptv_id := :new.SHF_ptv_id;
   l_newrec.SHF_file := :new.SHF_file;

   l_newrec.SHF_credate := :new.SHF_credate;
   l_newrec.SHF_creuser := :new.SHF_creuser;
   l_newrec.SHF_moddate := :new.SHF_moddate;
   l_newrec.SHF_moduser := :new.SHF_moduser;

   --   pkg_SAMPLESTATION.p_tr_buf_SAMPLESTATION (l_oldrec, l_newrec);

   :new.SHF_id := l_newrec.SHF_id;

   :new.SHF_sph_id := l_newrec.SHF_sph_id;
   :new.SHF_ptv_id := l_newrec.SHF_ptv_id;
   :new.SHF_file := l_newrec.SHF_file;

   :new.SHF_credate := l_newrec.SHF_credate;
   :new.SHF_creuser := l_newrec.SHF_creuser;
   :new.SHF_moddate := l_newrec.SHF_moddate;
   :new.SHF_moduser := l_newrec.SHF_moduser;
END;

/

