create PACKAGE BODY       pkg_sampleheaderadmingroup
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEHEADERADMINGROUP
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       24.02.2015 F.Burri           1. Created this package body.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, février 2015' ;


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_deleteby_sph_id (
      p_sph_id   IN sampleheaderadmingroup.shg_sph_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleheaderadmingroup
            WHERE shg_sph_id = p_sph_id;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_write (
      p_sph_id           IN     sampleheaderadmingroup.shg_sph_id%TYPE,
      p_agr_id           IN     sampleheaderadmingroup.shg_agr_id%TYPE,
      p_cantondistance   IN     sampleheaderadmingroup.shg_cantondistance%TYPE,
      p_usr_id           IN     sampleheaderadmingroup.shg_usr_id_create%TYPE,
      p_id                  OUT sampleheaderadmingroup.shg_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_sampleheaderadmingroup.NEXTVAL;

      INSERT INTO sampleheaderadmingroup (shg_id,
                                          shg_sph_id,
                                          shg_agr_id,
                                          shg_cantondistance,
                                          shg_usr_id_create,
                                          shg_usr_create_date)
           VALUES (p_id,
                   p_sph_id,
                   p_agr_id,
                   p_cantondistance,
                   p_usr_id,
                   SYSDATE);
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getrecordbysstandagr (
      p_sph_id   IN sampleheaderadmingroup.shg_sph_id%TYPE,
      p_agr_id   IN sampleheaderadmingroup.shg_agr_id%TYPE)
      RETURN sampleheaderadmingroup%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_recsampleheaderadmingroup   sampleheaderadmingroup%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recsampleheaderadmingroup
        FROM sampleheaderadmingroup
       WHERE shg_sph_id = p_sph_id AND shg_agr_id = p_agr_id;

      RETURN l_recsampleheaderadmingroup;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
         NULL;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_buildtxtlistcantonkey (l_listcode IN pkg_ch_canton.t_listcode)
      RETURN VARCHAR2
   /*--------------------------------------------------------------*/
   IS
      l_key          VARCHAR2 (10);
      l_liststring   VARCHAR2 (2048);
   BEGIN
      l_key := l_listcode.FIRST;

      WHILE NOT l_key IS NULL
      LOOP
         IF l_liststring IS NULL
         THEN
            l_liststring := '''' || l_key || '''';
         ELSE
            l_liststring := l_liststring || ',''' || l_key || '''';
         END IF;

         l_key := l_listcode.NEXT (l_key);
      END LOOP;

      RETURN l_liststring;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_setorunsetrightpublic (
      p_sph_id         IN sampleheaderadmingroup.shg_sph_id%TYPE,
      p_publicstatus   IN VARCHAR2,
      p_usr_id         IN sampleheaderadmingroup.shg_usr_id_create%TYPE)
   /*---------------------------------------------------------------*/
   IS
      l_recadmin_group              admin_group%ROWTYPE;
      l_publicstatus                VARCHAR2 (256);
      l_recsampleheaderadmingroup   sampleheaderadmingroup%ROWTYPE;
      l_shg_id                      sampleheaderadmingroup.shg_id%TYPE;
   BEGIN
      l_publicstatus := UPPER (p_publicstatus);

      IF     l_publicstatus != pkg_constante.cst_yes
         AND l_publicstatus != pkg_constante.cst_no
      THEN
         RETURN;
      END IF;

      l_recadmin_group :=
         pkg_admin_group.f_getrecordbyname (
            pkg_admin_group.cst_admin_group_public);

      IF l_recadmin_group.agr_id IS NULL
      THEN
         raise_application_error (
            -20000,
            'pkg_admingroup.cst_admin_group_public undefined',
            TRUE);
      END IF;

      l_recsampleheaderadmingroup :=
         pkg_sampleheaderadmingroup.f_getrecordbysstandagr (
            p_sph_id,
            l_recadmin_group.agr_id);

      IF     l_recsampleheaderadmingroup.shg_id IS NULL
         AND l_publicstatus = pkg_constante.cst_yes
      THEN
         p_write (p_sph_id,
                  l_recadmin_group.agr_id,
                  NULL,
                  p_usr_id,
                  l_shg_id);
      END IF;

      --  SI NOT l_recsampleheaderadmingroup.shg_id IS NULL AND l_publicstatus = pkg_constante.cst_yes --> On ne fait rien
      IF     NOT l_recsampleheaderadmingroup.shg_id IS NULL
         AND l_publicstatus = pkg_constante.cst_no
      THEN
         DELETE FROM sampleheaderadmingroup
               WHERE shg_id = l_recsampleheaderadmingroup.shg_id;
      END IF;
   --  SI l_recsampleheaderadmingroup.shg_id IS NULL AND l_publicstatus = pkg_constante.cst_no --> On ne fait rien

   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_buildtxtlistcantonid (l_listcode IN pkg_ch_canton.t_listcode)
      RETURN VARCHAR2
   /*--------------------------------------------------------------*/
   IS
      l_key              VARCHAR2 (10);
      l_liststring       VARCHAR2 (2048);
      l_recadmin_group   admin_group%ROWTYPE;
   BEGIN
      l_key := l_listcode.FIRST;

      WHILE NOT l_key IS NULL
      LOOP
         l_recadmin_group := pkg_admin_group.f_getrecordbyname (l_key);

         IF l_recadmin_group.agr_id IS NULL
         THEN
            l_liststring := NULL;
            EXIT;
         END IF;

         IF l_liststring IS NULL
         THEN
            l_liststring := l_recadmin_group.agr_id;
         ELSE
            l_liststring := l_liststring || ',' || l_recadmin_group.agr_id;
         END IF;

         l_key := l_listcode.NEXT (l_key);
      END LOOP;

      RETURN l_liststring;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_delete (p_sph_id       IN sampleheaderadmingroup.shg_sph_id%TYPE,
                       p_listcanton   IN VARCHAR2)
   /*--------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (4096);
   BEGIN
      IF p_listcanton IS NULL
      THEN
         RETURN;
      END IF;

      l_sql :=
            'DELETE FROM SAMPLEHEADERADMINGROUP WHERE shg_sph_id ='
         || p_sph_id
         || ' AND shg_agr_id NOT IN ( '
         || p_listcanton
         || ')';
      DBMS_OUTPUT.put_line (l_sql);

      EXECUTE IMMEDIATE l_sql;
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_insertorupdate (
      p_sph_id     IN sampleheaderadmingroup.shg_sph_id%TYPE,
      l_listcode   IN pkg_ch_canton.t_listcode,
      p_usr_id     IN sampleheaderadmingroup.shg_usr_id_create%TYPE)
   /*---------------------------------------------------------------*/
   IS
      l_key                         VARCHAR2 (10);
      l_recadmin_group              admin_group%ROWTYPE;
      l_recsampleheaderadmingroup   sampleheaderadmingroup%ROWTYPE;
      l_shg_id                      sampleheaderadmingroup.shg_id%TYPE;
   BEGIN
      l_key := l_listcode.FIRST;

      WHILE NOT l_key IS NULL
      LOOP
         l_recadmin_group := pkg_admin_group.f_getrecordbyname (l_key);

         IF l_recadmin_group.agr_id IS NULL
         THEN
            EXIT;
         END IF;

         l_recsampleheaderadmingroup :=
            f_getrecordbysstandagr (p_sph_id, l_recadmin_group.agr_id);

         IF l_recsampleheaderadmingroup.shg_id IS NULL
         THEN
            -- INSERT
            p_write (p_sph_id,
                     l_recadmin_group.agr_id,
                     ROUND (l_listcode (l_key), 2),
                     p_usr_id,
                     l_shg_id);
         ELSE
            IF ROUND (l_listcode (l_key), 2) !=
                  l_recsampleheaderadmingroup.shg_cantondistance
            THEN
               UPDATE sampleheaderadmingroup
                  SET shg_cantondistance = ROUND (l_listcode (l_key), 2),
                      shg_usr_id_modify = p_usr_id,
                      shg_usr_modify_date = SYSDATE
                WHERE shg_id = l_recsampleheaderadmingroup.shg_id;
            END IF;
         END IF;

         l_key := l_listcode.NEXT (l_key);
      END LOOP;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_updateadmingroup (
      p_sph_id   IN sampleheaderadmingroup.shg_sph_id%TYPE,
      p_usr_id   IN sampleheaderadmingroup.shg_usr_id_create%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_updateadmingroup (p_sph_id, p_usr_id, NULL);
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_updateadmingroup (
      p_sph_id       IN sampleheaderadmingroup.shg_sph_id%TYPE,
      p_usr_id       IN sampleheaderadmingroup.shg_usr_id_create%TYPE,
      p_buffersize   IN NUMBER)
   /*----------------------------------------------------------------*/
   IS
      l_listcode             pkg_ch_canton.t_listcode;
      l_recsamplestation     samplestation%ROWTYPE;
      l_recsampleheader      sampleheader%ROWTYPE;
      l_liststring           VARCHAR2 (2048);
      l_sql                  VARCHAR2 (4096);
      l_buffersize           NUMBER;
      l_listcodewithpublic   pkg_ch_canton.t_listcode;
   BEGIN
      IF p_buffersize IS NULL
      THEN
         l_buffersize := cst_buffersize;
      ELSE
         l_buffersize := p_buffersize;
      END IF;

      l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);

      IF l_recsampleheader.sph_id IS NULL
      THEN
         RETURN;
      END IF;

      l_recsamplestation :=
         pkg_samplestation.f_getrecord (l_recsampleheader.sph_sst_id);

      IF l_recsamplestation.sst_id IS NULL
      THEN
         RETURN;
      END IF;

      l_listcode :=
         pkg_ch_canton.f_returncantonnearbuffer (
            l_recsamplestation.sst_coordinates,
            l_buffersize);
      l_listcodewithpublic := l_listcode;
      l_listcodewithpublic (pkg_admin_group.cst_admin_group_public) := NULL;

      l_liststring := f_buildtxtlistcantonid (l_listcodewithpublic);

      DBMS_OUTPUT.put_line (l_liststring);
      p_delete (p_sph_id, l_liststring);
      p_insertorupdate (p_sph_id, l_listcode, p_usr_id);
      NULL;
   END;

   /*-------------------------------------------------------------------------------*/
   PROCEDURE p_rebuildallheader (p_buffersize IN NUMBER)
   /*-------------------------------------------------------------------------------*/
   IS
      CURSOR l_listheader
      IS
         SELECT * FROM sampleheader;

      l_reclistheader   l_listheader%ROWTYPE;
   BEGIN
      OPEN l_listheader;

      LOOP
         FETCH l_listheader INTO l_reclistheader;

         EXIT WHEN l_listheader%NOTFOUND;
         p_updateadmingroup (l_reclistheader.sph_id, p_buffersize);
      END LOOP;
   END;

   /*------------------------------------------------------------------------------*/
   PROCEDURE p_test
   /*------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_rebuildallheader (3000);
   END;
END pkg_sampleheaderadmingroup;
/

