create PACKAGE       pkg_validatemassdetail
AS
   /******************************************************************************
      NAME:       pkg_validatemassdetail
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
      1.1        26.09.2017      burrif       2. Midat version 2
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_test;

   PROCEDURE p_validate (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id                 IN     language.lan_id%TYPE,
      p_returnstatus              OUT NUMBER);
END pkg_validatemassdetail;
/

