create PACKAGE BODY       pkg_migr_spear2019_test
AS
    /******************************************************************************
      NAME:       PKG_MIGR_SPEAR2019_TEST
      PURPOSE:     Test

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
   ******************************************************************************/



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_test
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        pkg_spear2019.p_init;
        pkg_spear2019.p_addfrequence (332, 8);                  -- Acroloxidae
        pkg_spear2019.p_addfrequence (333, 7);           -- Ancylidae (Tachet)

        pkg_spear2019.p_addfrequence (335, 2);        -- Ferrissiidae (Tachet)
        pkg_spear2019.p_addfrequence (375, 9);              -- Polymitarcyidae
        pkg_spear2019.p_addfrequence (385, 11);                    -- Lestidae
        pkg_spear2019.p_addfrequence (407, 1);                   -- Nemouridae
        pkg_spear2019.p_addfrequence (466, 2);                -- Psychomyiidae
        pkg_spear2019.p_computespear;
        DBMS_OUTPUT.put_line ('Spear=' || pkg_spear2019.f_getspear);
    END;
END;
/

