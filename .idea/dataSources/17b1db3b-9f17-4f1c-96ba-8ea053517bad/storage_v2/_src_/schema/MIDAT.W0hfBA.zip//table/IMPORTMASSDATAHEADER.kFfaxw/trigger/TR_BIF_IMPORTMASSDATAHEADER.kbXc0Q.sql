create trigger TR_BIF_IMPORTMASSDATAHEADER
    before insert
    on IMPORTMASSDATAHEADER
    for each row
DECLARE
BEGIN
   IF :new.imh_id IS NULL
   THEN
      :new.imh_id := seq_importmassdataheader.NEXTVAL;
   END IF;

   :new.imh_credate := SYSDATE;
   :new.imh_creuser := USER;
END tr_bif_importmassdataheader;

/

