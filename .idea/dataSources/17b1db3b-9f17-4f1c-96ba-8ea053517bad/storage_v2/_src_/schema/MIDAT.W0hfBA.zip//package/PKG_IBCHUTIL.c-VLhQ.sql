create PACKAGE       pkg_ibchutil
AS
   /******************************************************************************
      NAME:       pkg_ibchutil
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        08.10.2019      burrif       1. Created this package.
      1.1        19.02.2020      burrif       2. Ajout du calcul lorsque le taxonibch n'est pas défini
                                                 Remplace pkg_ibchstat
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getibchsomme_vt (p_sph_id IN sampleheader.sph_id%TYPE)
      RETURN NUMBER;

   FUNCTION f_getsumbytaxonibch (
      p_sph_id   IN sampleheader.sph_id%TYPE,
      p_taxon    IN protocolmappinglabo.ptl_taxa%TYPE)
      RETURN NUMBER;

   FUNCTION f_getibch (p_sph_id IN sampleheader.sph_id%TYPE)
      RETURN NUMBER;

   FUNCTION f_getibchgi (p_sph_id IN sampleheader.sph_id%TYPE)
      RETURN NUMBER;

   FUNCTION f_getibchvt (p_sph_id IN sampleheader.sph_id%TYPE)
      RETURN NUMBER;

   FUNCTION f_getibchsumtaxon (p_sph_id IN sampleheader.sph_id%TYPE)
      RETURN NUMBER;

   FUNCTION f_gettaxonindicateur (p_sph_id IN sampleheader.sph_id%TYPE)
      RETURN VARCHAR2;

   FUNCTION f_columntaxonibchexist (
      p_sph_id   IN sampleprotocolmass.smx_sph_id%TYPE)
      RETURN BOOLEAN;

   FUNCTION f_hascolumntaxonibchexist (
      p_sph_id   IN sampleprotocolmass.smx_sph_id%TYPE)
      RETURN VARCHAR2;

   FUNCTION f_identifytaxonibch (p_recsmx IN sampleprotocolmass%ROWTYPE)
      RETURN protocolmappinglabo%ROWTYPE;

   FUNCTION f_search_taxon (p_syv_id   IN sampleprotocolmass.smx_syy_id%TYPE,
                            p_taxon    IN VARCHAR2)
      RETURN systvalue.syv_id%TYPE;
END;
/

