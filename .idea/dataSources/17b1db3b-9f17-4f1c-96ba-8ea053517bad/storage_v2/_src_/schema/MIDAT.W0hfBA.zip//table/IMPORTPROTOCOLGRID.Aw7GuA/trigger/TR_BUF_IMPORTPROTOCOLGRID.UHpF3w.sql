create trigger TR_BUF_IMPORTPROTOCOLGRID
    before update
    on IMPORTPROTOCOLGRID
    for each row
DECLARE
BEGIN
 
   :new.ipg_moddate := SYSDATE;
   :new.ipg_moduser := USER;
END tr_buf_IMPORTPROTOCOLGRID;

/

