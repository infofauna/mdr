create PACKAGE BODY       pkg_importprotocolheader
AS
    /******************************************************************************
       NAME:       PKG_IMPORTPROTOCOLHEADER
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        02.10.2013      burrif       1. Created this package.
       2.0         11.07.2017     burrif       2. Fonctionnalité version 2
    ******************************************************************************/



    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 2.0, Juillet  2017' ;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_deleteconditionnal (
        p_iph_id   IN importprotocolheader.iph_id%TYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM importprotocolheader
              WHERE     iph_id = p_iph_id
                    AND iph_id NOT IN
                            (SELECT imd_iph_id FROM importmassdatadetail)
                    AND iph_id NOT IN
                            (SELECT imh_iph_id FROM importmassdataheader)
                    AND iph_id NOT IN
                            (SELECT ime_iph_id FROM importmassmappingheader)
                    AND iph_id NOT IN
                            (SELECT ipg_iph_id FROM importprotocolgrid)
                    AND iph_id NOT IN
                            (SELECT ipn_iph_id FROM importprotocolgrnd)
                    AND iph_id NOT IN
                            (SELECT ipl_iph_id FROM importprotocollabo)
                    AND iph_id NOT IN
                            (SELECT ipo_iph_id FROM importprotocollog)
                    AND iph_id NOT IN (SELECT sph_iph_id FROM sampleheader);
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_clear_iph_sph_id_parent (
        p_sph_id_parent   IN importprotocolheader.iph_sph_id_parent%TYPE)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_sph_id_parent = NULL
         WHERE iph_sph_id_parent = p_sph_id_parent;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_clear_iph_sst_id_existing (
        p_sst_id   IN importprotocolheader.iph_sst_id_existing%TYPE)
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_sst_id_existing = NULL
         WHERE iph_sst_id_existing = p_sst_id;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_delete_old (p_iph_id IN importprotocolheader.iph_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
        CURSOR l_cursor IS
            SELECT *
              FROM importprotocolheader
             WHERE iph_iph_id = p_iph_id;

        l_reccursor   l_cursor%ROWTYPE;
    BEGIN
        pkg_importprotocolgrid.p_deletebyiphid (p_iph_id);
        pkg_importprotocolgrnd.p_deletebyiphid (p_iph_id);
        pkg_importprotocollabo.p_deletebyiphid (p_iph_id);
        pkg_importprotocollog.p_purgebyiphid (p_iph_id);

        DELETE FROM importprotocolheader
              WHERE iph_iph_id = p_iph_id;


        DELETE FROM importprotocolheader
              WHERE iph_id = p_iph_id;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_update_iph_cvl_id_canton (
        p_iph_id              IN importprotocolheader.iph_id%TYPE,
        p_iph_cvl_id_canton   IN importprotocolheader.iph_cvl_id_canton%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_cvl_id_canton = p_iph_cvl_id_canton
         WHERE iph_id = p_iph_id;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_updateiph_iph_id (
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_sph_id   IN sampleheader.sph_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
        l_recsampleheader   sampleheader%ROWTYPE;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);

        IF l_recsampleheader.sph_id IS NULL
        THEN
            RETURN;
        END IF;

        UPDATE importprotocolheader
           SET iph_iph_id = l_recsampleheader.sph_iph_id
         WHERE iph_id = p_iph_id;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_updateexternal_id (
        p_iph_id        IN importprotocolheader.iph_id%TYPE,
        p_external_id   IN importprotocolheader.iph_external_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_external_id = p_external_id
         WHERE iph_id = p_iph_id;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_updateprocessingdata (
        p_iph_id        IN importprotocolheader.iph_id%TYPE,
        p_external_id   IN importprotocolheader.iph_external_id%TYPE,
        p_pid_id        IN importprotocolheader.iph_pid_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_external_id = p_external_id, iph_pid_id = p_pid_id
         WHERE iph_id = p_iph_id;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_update_ibchnewvalue (
        p_iph_id         IN importprotocolheader.iph_id%TYPE,
        p_ibchnewvalue   IN importprotocolheader.iph_ibchnewvalue%TYPE,
        p_windowibch     IN importprotocolheader.iph_cvl_id_windowibch%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_ibchnewvalue = p_ibchnewvalue,
               iph_cvl_id_windowibch = p_windowibch
         WHERE iph_id = p_iph_id;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_update_computed_data (
        p_iph_id                      IN importprotocolheader.iph_id%TYPE,
        p_ibchnewvalue                IN importprotocolheader.iph_ibchnewvalue%TYPE,
        p_windowibch                  IN importprotocolheader.iph_cvl_id_windowibch%TYPE,
        p_taxonindicateur             IN importprotocolheader.iph_taxonindicateur%TYPE,
        p_ibchrobust                  IN importprotocolheader.iph_ibchrobust%TYPE,
        p_classevariete               IN importprotocolheader.iph_classevariete%TYPE,
        p_classevariete_corr          IN importprotocolheader.iph_classevariete_corr%TYPE,
        p_classevarieterobust         IN importprotocolheader.iph_classevarieterobust%TYPE,
        p_classevarieterobust_corr    IN importprotocolheader.iph_classevarieterobust_corr%TYPE,
        p_classevariete_final         IN importprotocolheader.iph_classevariete_final%TYPE,
        p_classevarieterobust_final   IN importprotocolheader.iph_classevarieterobust_final%TYPE,
        p_taxonfrequencesum           IN importprotocolheader.iph_taxonfrequencesum%TYPE,
        p_gimax                       IN importprotocolheader.iph_gimax%TYPE,
        p_gimaxrobust                 IN importprotocolheader.iph_gimaxrobust%TYPE,
        p_gi_final                    IN importprotocolheader.iph_gi_final%TYPE,
        p_girobust_final              IN importprotocolheader.iph_girobust_final%TYPE,
        p_sumfamily                   IN importprotocolheader.iph_sumfamily%TYPE,
        p_sumfamilycorrected          IN importprotocolheader.iph_sumfamilycorrected%TYPE,
        p_sumfamilyrobust             IN importprotocolheader.iph_sumfamilyrobust%TYPE,
        p_sumfamilyrobustcorrected    IN importprotocolheader.iph_sumfamilyrobustcorrected%TYPE,
        p_ephemeropteracounter        IN importprotocolheader.iph_ephemeropteracounter%TYPE,
        p_plecopteracounter           IN importprotocolheader.iph_plecopteracounter%TYPE,
        p_tricopteracounter           IN importprotocolheader.iph_tricopteracounter%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_ibchnewvalue = p_ibchnewvalue,
               iph_cvl_id_windowibch = p_windowibch,
               iph_taxonindicateur = p_taxonindicateur,
               iph_ibchrobust = p_ibchrobust,
               iph_classevariete = p_classevariete,
               iph_classevariete_corr = p_classevariete_corr,
               iph_classevarieterobust = p_classevarieterobust,
               iph_classevarieterobust_corr = p_classevarieterobust_corr,
               iph_classevariete_final = p_classevariete_final,
               iph_classevarieterobust_final = p_classevarieterobust_final,
               iph_taxonfrequencesum = p_taxonfrequencesum,
               iph_gimax = p_gimax,
               iph_gimaxrobust = p_gimaxrobust,
               iph_gi_final = p_gi_final,
               iph_girobust_final = p_girobust_final,
               iph_sumfamily = p_sumfamily,
               iph_sumfamilycorrected = p_sumfamilycorrected,
               iph_sumfamilyrobust = p_sumfamilyrobust,
               iph_sumfamilyrobustcorrected = p_sumfamilyrobustcorrected,
               iph_ephemeropteracounter = p_ephemeropteracounter,
               iph_plecopteracounter = p_plecopteracounter,
               iph_tricopteracounter = p_tricopteracounter
         WHERE iph_id = p_iph_id;
    END;



    /*----------------------------------------------------------------*/
    PROCEDURE p_update_spearindexnewvalue (
        p_iph_id               IN importprotocolheader.iph_id%TYPE,
        p_spearindexnewvalue   IN importprotocolheader.iph_spearindexnewvalue%TYPE,
        p_windowspear          IN importprotocolheader.iph_cvl_id_windowspear%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_spearindexnewvalue = p_spearindexnewvalue,
               iph_cvl_id_windowspear = p_windowspear
         WHERE iph_id = p_iph_id;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_update_makroindexnewvalue (
        p_iph_id               IN importprotocolheader.iph_id%TYPE,
        p_makroindexnewvalue   IN importprotocolheader.iph_makroindexnewvalue%TYPE,
        p_windowmakroindex     IN importprotocolheader.iph_cvl_id_windowmakroindex%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_spearindexnewvalue = p_makroindexnewvalue,
               iph_cvl_id_windowmakroindex = p_windowmakroindex
         WHERE iph_id = p_iph_id;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_updatepid_id (
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_pid_id   IN importprotocolheader.iph_pid_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_pid_id = p_pid_id
         WHERE iph_id = p_iph_id;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_deletebyiphidmaster (
        p_iph_id   IN importprotocolheader.iph_id%TYPE)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM importprotocolheader
              WHERE iph_id IN (SELECT iph_id
                                 FROM importprotocolheader
                                WHERE iph_iph_id = p_iph_id);

        DELETE FROM importprotocolheader
              WHERE iph_id = p_iph_id;
    END;



    /*----------------------------------------------------------------*/
    PROCEDURE p_purgevaliddata
    /*----------------------------------------------------------------*/
    IS
        CURSOR l_cursor IS
            SELECT DISTINCT iph_id
              FROM importprotocolheader
             WHERE     (iph_validstatus =
                        pkg_importprotocolheader.cst_validstatusok)
                   AND iph_credate <=
                         SYSDATE
                       - pkg_importprotocolheader.cst_purgeperiod / 24;

        l_reccursor   l_cursor%ROWTYPE;
    BEGIN
        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND;
            DBMS_OUTPUT.put_line ('IPH_ID=' || l_reccursor.iph_id);
            pkg_sampleheader.p_clearsph_iph_id (l_reccursor.iph_id);
            pkg_importprotocollog.p_purgebyiphid (l_reccursor.iph_id);
            pkg_importprotocolgrid.p_deletebyiphid (l_reccursor.iph_id);
            pkg_importprotocolgrnd.p_deletebyiphid (l_reccursor.iph_id);
            pkg_importprotocollabo.p_deletebyiphid (l_reccursor.iph_id);
            pkg_samplemkidetailgroup.p_deleteby_iph_id (l_reccursor.iph_id);
            pkg_importmassdataheader.p_deletebyiph_id (l_reccursor.iph_id);
            pkg_importmassmappingheader.p_deletebyiph_id (l_reccursor.iph_id);
            pkg_importmassstation.p_deletebyiph_id (l_reccursor.iph_id);

            DELETE FROM importprotocolheader
                  WHERE iph_id IN (SELECT iph_id
                                     FROM importprotocolheader
                                    WHERE iph_iph_id = l_reccursor.iph_id);

            DELETE FROM importprotocolheader
                  WHERE iph_id = l_reccursor.iph_id;
        END LOOP;

        CLOSE l_cursor;


        COMMIT;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_purgeinvaliddata
    /*----------------------------------------------------------------*/
    IS
        PRAGMA AUTONOMOUS_TRANSACTION;

        CURSOR l_cursor IS
            SELECT DISTINCT iph_id
              FROM importprotocolheader
             WHERE    (iph_validstatus =
                       pkg_importprotocolheader.cst_validstatusnotok)
                   OR (    iph_validstatus =
                           pkg_importprotocolheader.cst_validstatuspending
                       AND iph_credate <=
                             SYSDATE
                           - pkg_importprotocolheader.cst_purgeperiod / 24);



        l_reccursor   l_cursor%ROWTYPE;
    BEGIN
        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND;
            DBMS_OUTPUT.put_line ('IPH_ID=' || l_reccursor.iph_id);
            pkg_sampleheader.p_clearsph_iph_id (l_reccursor.iph_id);
            pkg_importprotocollog.p_purgebyiphid (l_reccursor.iph_id);
            pkg_importprotocolgrid.p_deletebyiphid (l_reccursor.iph_id);
            pkg_importprotocolgrnd.p_deletebyiphid (l_reccursor.iph_id);
            pkg_importprotocollabo.p_deletebyiphid (l_reccursor.iph_id);
            pkg_samplemkidetailgroup.p_deleteby_iph_id (l_reccursor.iph_id);
            pkg_importmassdataheader.p_deletebyiph_id (l_reccursor.iph_id);
            pkg_importmassmappingheader.p_deletebyiph_id (l_reccursor.iph_id);
            pkg_importmassstation.p_deletebyiph_id (l_reccursor.iph_id);

            DELETE FROM importprotocolheader
                  WHERE iph_id IN (SELECT iph_id
                                     FROM importprotocolheader
                                    WHERE iph_iph_id = l_reccursor.iph_id);

            DELETE FROM importprotocolheader
                  WHERE iph_id = l_reccursor.iph_id;
        END LOOP;

        CLOSE l_cursor;


        COMMIT;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_purgeinvalidmassdata
    /*-----------------------------------------------------------------*/
    IS
        PRAGMA AUTONOMOUS_TRANSACTION;

        CURSOR l_cursor IS
            SELECT *
              FROM importmassdataheader
             WHERE    (imh_validstatus =
                       pkg_importprotocolheader.cst_validstatusnotok)
                   OR (    imh_validstatus =
                           pkg_importprotocolheader.cst_validstatuspending
                       AND imh_credate <=
                             SYSDATE
                           - pkg_importprotocolheader.cst_purgeperiod / 24);



        l_reccursor   l_cursor%ROWTYPE;
    BEGIN
        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND;
            DBMS_OUTPUT.put_line (
                   'l_reccursor.imh_id '
                || l_reccursor.imh_id
                || ' l_reccursor.imh_validstatus= '
                || l_reccursor.imh_validstatus);
            pkg_importprotocollog.p_purgebyimh_id (l_reccursor.imh_id);
            pkg_importmassdatadetail.p_deletebyimhid (l_reccursor.imh_id);
            pkg_importmassmappingheader.p_deletebyiph_idconditionnal (
                l_reccursor.imh_iph_id);

            DELETE FROM importmassdataheader
                  WHERE imh_id = l_reccursor.imh_id;

            -- Reste à supprimer les stations qui ne sont plus référencées dans importmassdataherder
            DELETE FROM importmassstation
                  WHERE ims_id NOT IN
                            (SELECT imh_ims_id FROM importmassdataheader);
        END LOOP;

        CLOSE l_cursor;

        COMMIT;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_purge
    /*-----------------------------------------------------------------*/
    IS
    BEGIN
        p_purgeinvaliddata;
        p_purgeinvalidmassdata;
    --      p_purgevaliddata;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_delete (p_iph_id IN importprotocolheader.iph_id%TYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM importprotocolheader
              WHERE iph_id = p_iph_id;

        NULL;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_deleteallchildren (
        p_iph_id   IN importprotocolheader.iph_id%TYPE)
    /*--------------------------------------------------------------*/
    IS
        CURSOR l_listchildren IS
            SELECT *
              FROM importprotocolheader
             WHERE iph_iph_id = p_iph_id;

        l_recimportprotocolheader   l_listchildren%ROWTYPE;
    BEGIN
        OPEN l_listchildren;

        LOOP
            FETCH l_listchildren INTO l_recimportprotocolheader;

            EXIT WHEN l_listchildren%NOTFOUND;
            pkg_importprotocollog.p_purgebyiphid (
                l_recimportprotocolheader.iph_id);
            p_delete (l_recimportprotocolheader.iph_id);
        END LOOP;

        CLOSE l_listchildren;
    END;



    /*---------------------------------------------------------------*/
    FUNCTION f_findprotocolheader (
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_code     IN codevalue.cvl_code%TYPE)
        RETURN importprotocolheader%ROWTYPE
    /*---------------------------------------------------------------*/
    -- p_iph_id contient l'entrée du protocol de laboratoire
    IS
        l_reccodevalue              codevalue%ROWTYPE;
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        l_reccodevalue :=
            pkg_codevalue.f_getfromcode (
                p_code,
                pkg_codereference.cst_crf_midatproto);

        SELECT *
          INTO l_recimportprotocolheader
          FROM importprotocolheader
         WHERE     iph_iph_id = p_iph_id
               AND iph_ptv_id IN
                       (SELECT ptv_id
                          FROM protocolversion
                         WHERE ptv_cvl_id_protocoltype =
                               l_reccodevalue.cvl_id)
               AND ROWNUM < 2;

        RETURN l_recimportprotocolheader;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_deletegrid (p_iph_id IN importprotocolheader.iph_id%TYPE)
    /*---------------------------------------------------------------*/
    -- p_iph_id contient l'entrée du protocol de laboratoire
    /*
     Il y a plusieurs IMPORTPROTOCOLHEADER mais un seul SAMPLEHEADER.
    */
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            f_findprotocolheader (p_iph_id,
                                  pkg_codevalue.cst_protocoltype_grdeval);

        WHILE NOT l_recimportprotocolheader.iph_id IS NULL
        LOOP
            pkg_importprotocolgrid.p_deletebyiphid (
                l_recimportprotocolheader.iph_id);
            pkg_importprotocollog.p_purgebyiphid (
                l_recimportprotocolheader.iph_id);
            p_delete (l_recimportprotocolheader.iph_id);
            l_recimportprotocolheader :=
                f_findprotocolheader (p_iph_id,
                                      pkg_codevalue.cst_protocoltype_grdeval);
        END LOOP;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_deletegrnd (p_iph_id IN importprotocolheader.iph_id%TYPE)
    /*---------------------------------------------------------------*/
    -- p_iph_id contient l'entrée du protocol de laboratoire
    /*
     Il y a plusieurs IMPORTPROTOCOLHEADER mais un seul SAMPLEHEADER.
    */
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            f_findprotocolheader (p_iph_id,
                                  pkg_codevalue.cst_protocoltype_ground);

        WHILE NOT l_recimportprotocolheader.iph_id IS NULL
        LOOP
            pkg_importprotocolgrnd.p_deletebyiphid (
                l_recimportprotocolheader.iph_id);
            pkg_importprotocollog.p_purgebyiphid (
                l_recimportprotocolheader.iph_id);
            p_delete (l_recimportprotocolheader.iph_id);
            l_recimportprotocolheader :=
                f_findprotocolheader (p_iph_id,
                                      pkg_codevalue.cst_protocoltype_ground);
        END LOOP;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_deletelabo (p_iph_id IN importprotocolheader.iph_id%TYPE)
    /*---------------------------------------------------------------*/
    -- p_iph_id contient l'entrée du protocol de laboratoire
    /*
     Il y a plusieurs IMPORTPROTOCOLHEADER mais un seul SAMPLEHEADER.
    */
    IS
    BEGIN
        p_deletegrnd (p_iph_id);
        p_deletegrid (p_iph_id);
        pkg_importprotocollabo.p_deletebyiphid (p_iph_id);

        pkg_importprotocollog.p_purgebyiphid (p_iph_id);
        p_delete (p_iph_id);
    END;



    /*-------------------------------------------------------------------*/
    FUNCTION f_getvirtimportheaderprotocol (
        p_iph_id   IN importprotocolheader.iph_id%TYPE)
        RETURN importprotocolheader%ROWTYPE
    /*------------------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_recsampleheader           sampleheader%ROWTYPE;
        l_recprotocolversion        protocolversion%ROWTYPE;
        l_reccodevalueversion       codevalue%ROWTYPE;
        l_recsampleheaderfile       sampleheaderfile%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);

        IF l_recimportprotocolheader.iph_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_importprotocolheader.f_getrecord('
                || TO_CHAR (NVL (TO_CHAR (p_iph_id), 'NULL'))
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
            RETURN NULL;
        END IF;

        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                l_recimportprotocolheader.iph_ptv_id);

        IF l_recprotocolversion.ptv_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_protocolversion.f_getrecord('
                || TO_CHAR (
                       NVL (TO_CHAR (l_recimportprotocolheader.iph_ptv_id),
                            'NULL'))
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
            RETURN NULL;
        END IF;

        l_reccodevalueversion :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);

        IF l_reccodevalueversion.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   ' pkg_codevalue.f_getrecord.f_getrecord('
                || TO_CHAR (
                       NVL (
                           TO_CHAR (
                               l_recprotocolversion.ptv_cvl_id_protocoltype),
                           'NULL'))
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
            RETURN NULL;
        END IF;

        IF l_reccodevalueversion.cvl_code =
           pkg_codevalue.cst_protocoltype_laboratory
        THEN
            RETURN l_recimportprotocolheader;
        END IF;


        IF l_recimportprotocolheader.iph_sph_id_parent IS NULL
        THEN
            pkg_message.p_setparameter (
                ' pkg_sampleheader.f_getrecord.f_getrecord(' || 'NULL' || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
            RETURN NULL;
        END IF;


        l_recsampleheader :=
            pkg_sampleheader.f_getrecord (
                l_recimportprotocolheader.iph_sph_id_parent);

        IF l_recsampleheader.sph_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   ' pkg_sampleheader.f_getrecord('
                || TO_CHAR (
                       NVL (
                           TO_CHAR (
                               l_recimportprotocolheader.iph_sph_id_parent),
                           'NULL'))
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
            RETURN NULL;
        END IF;

        pkg_debug.p_write (
            'PKG_IMPORTPROTOCOLHEADER.f_getvirtimportheaderprotocol',
               'Avant kg_sampleheaderfile.f_getlaboprotocolfile  l_recsampleheader.sph_id='
            || l_recsampleheader.sph_id);
        l_recsampleheaderfile :=
            pkg_sampleheaderfile.f_getlaboprotocolfile (
                l_recsampleheader.sph_id);
        pkg_debug.p_write (
            'PKG_IMPORTPROTOCOLHEADER.f_getvirtimportheaderprotocol',
               'Après kg_sampleheaderfile.f_getlaboprotocolfile  l_recsampleheaderfile.shf_id='
            || l_recsampleheaderfile.shf_id);

        IF     l_recsampleheaderfile.shf_id IS NULL
           AND l_recsampleheader.sph_smf_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   ' pkg_sampleheaderfile.f_getlaboprotocolfile('
                || TO_CHAR (NVL (TO_CHAR (l_recsampleheader.sph_id), 'NULL'))
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
            RETURN NULL;
        END IF;

        pkg_debug.p_write (
            'PKG_IMPORTPROTOCOLHEADER.f_getvirtimportheaderprotocol',
            'pkg_sampleheaderfile.f_getlaboprotocolfile ok');

        l_recimportprotocolheader.iph_ins_id_principal :=
            NVL (l_recimportprotocolheader.iph_ins_id_principal,
                 l_recsampleheader.sph_ins_id_principal);
        l_recimportprotocolheader.iph_ins_id_mandatary :=
            NVL (l_recimportprotocolheader.iph_ins_id_mandatary,
                 l_recsampleheader.sph_ins_id_mandatary);
        l_recimportprotocolheader.iph_lan_id :=
            NVL (l_recimportprotocolheader.iph_lan_id,
                 l_recsampleheaderfile.shf_lan_id);
        RETURN l_recimportprotocolheader;
    END;



    /*--------------------------------------------------------------*/
    PROCEDURE p_updateexistingstation (
        p_iph_id            IN importprotocolheader.iph_id%TYPE,
        p_sst_id_existing   IN importprotocolheader.iph_sst_id_existing%TYPE,
        p_usr_id            IN importprotocolheader.iph_usr_id_modify%TYPE)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_sst_id_existing = p_sst_id_existing,
               iph_usr_id_modify = p_usr_id
         WHERE iph_id = p_iph_id;
    END;

    /*-------------------------------------------------------------*/
    FUNCTION f_getrecord (p_iph_id IN importprotocolheader.iph_id%TYPE)
        RETURN importprotocolheader%ROWTYPE
    /*-------------------------------------------------------------*/
    IS
        l_record   importprotocolheader%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_record
          FROM importprotocolheader
         WHERE iph_id = p_iph_id;

        RETURN l_record;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*-----------------------------------------------------------------------------------------*/
    PROCEDURE p_updateusrid (
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_usr_id   IN importprotocolheader.iph_usr_id_modify%TYPE)
    /*-----------------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_usr_id_modify = p_usr_id, iph_usr_modify_date = SYSDATE
         WHERE iph_id = p_iph_id;
    END;

    /*----------------------------------------------------------------------------------------*/
    PROCEDURE p_updatevalidatestatus (
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_status   IN importprotocolheader.iph_validstatus%TYPE,
        p_usr_id   IN importprotocolheader.iph_usr_id_modify%TYPE)
    /*----------------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE importprotocolheader
           SET iph_validstatus = p_status,
               iph_usr_id_modify = p_usr_id,
               iph_usr_modify_date = SYSDATE
         WHERE iph_id = p_iph_id;
    END;



    /*----------------------------------------------------------------------------------------*/
    PROCEDURE p_insertlabodata (
        p_ins_id_principal      IN     importprotocolheader.iph_ins_id_principal%TYPE,
        p_ins_id_mandatary      IN     importprotocolheader.iph_ins_id_mandatary%TYPE,
        p_ptv_id                IN     importprotocolheader.iph_ptv_id%TYPE,
        p_per_id_determinator   IN     importprotocolheader.iph_per_id_determinator%TYPE,
        p_determinateddate      IN     importprotocolheader.iph_determinateddate%TYPE,
        p_per_id_operator       IN     importprotocolheader.iph_per_id_operator%TYPE,
        p_observationdate       IN     importprotocolheader.iph_observationdate%TYPE,
        p_cvl_id_midatstat      IN     importprotocolheader.iph_cvl_id_midatstat%TYPE,
        p_reporturl             IN     importprotocolheader.iph_reporturl%TYPE,
        p_lan_id                IN     importprotocolheader.iph_lan_id%TYPE,
        p_cvl_id_systlref       IN     importprotocolheader.iph_cvl_id_systlref%TYPE,
        p_cvl_id_systlprec      IN     importprotocolheader.iph_cvl_id_systlprec%TYPE,
        p_inputfilename         IN     importprotocolheader.iph_inputfilename%TYPE,
        p_file                  IN     importprotocolheader.iph_file%TYPE,
        p_sheetname             IN     importprotocolheader.iph_sheetname%TYPE,
        p_usr_id_create         IN     importprotocolheader.iph_usr_id_create%TYPE,
        p_sph_id_parent         IN     importprotocolheader.iph_sph_id_parent%TYPE,
        p_iph_prj_id            IN     importprotocolheader.iph_prj_id%TYPE,
        p_id                       OUT importprotocolheader.iph_id%TYPE)
    IS
        l_codevaluerecord   codevalue%ROWTYPE;
    BEGIN
        p_id := seq_importprotocolheader.NEXTVAL;



        INSERT INTO importprotocolheader (iph_id,
                                          iph_ins_id_principal,
                                          iph_ins_id_mandatary,
                                          iph_ptv_id,
                                          iph_per_id_determinator,
                                          iph_determinateddate,
                                          iph_per_id_operator,
                                          iph_observationdate,
                                          iph_cvl_id_midatstat,
                                          iph_reporturl,
                                          iph_lan_id,
                                          iph_cvl_id_systlref,
                                          iph_cvl_id_systlprec,
                                          iph_sheetname,
                                          iph_inputfilename,
                                          iph_file,
                                          iph_prj_id,
                                          iph_usr_id_create,
                                          iph_usr_create_date,
                                          iph_sph_id_parent)
             VALUES (p_id,
                     p_ins_id_principal,
                     p_ins_id_mandatary,
                     p_ptv_id,
                     p_per_id_determinator,
                     p_determinateddate,
                     p_per_id_operator,
                     p_observationdate,
                     p_cvl_id_midatstat,
                     p_reporturl,
                     p_lan_id,
                     p_cvl_id_systlref,
                     p_cvl_id_systlprec,
                     p_sheetname,
                     p_inputfilename,
                     p_file,
                     p_iph_prj_id,
                     p_usr_id_create,
                     SYSDATE,
                     p_sph_id_parent);

        COMMIT;
    END;
END;
/

