create trigger TR_BIF_INDICEHISTORY
    before insert
    on INDICEHISTORY
    for each row
DECLARE
BEGIN
   IF :new.IHY_id IS NULL
   THEN
      :new.IHY_id := seq_INDICEHISTORY.NEXTVAL;
   END IF;

   :new.IHY_credate := SYSDATE;
   :new.IHY_creuser := USER;
END tr_bif_INDICEHISTORY;
/

