create PACKAGE BODY       pkg_migr_protocolmappinggrid
AS
   /******************************************************************************
      NAME:       pkg_migr_protocolmappinggrid
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;

   /*---------------------------------------------------------------*/
   PROCEDURE p_complete (p_ptv_id IN protocolmappinggrid.pmg_ptv_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
      l_reccodevalue_integer   codevalue%ROWTYPE;
      l_reccodevalue_string    codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue_integer :=
         pkg_codevalue.f_getfromcode (pkg_codevalue.cst_datatype_integer,
                                      pkg_codereference.cst_crf_datatype);
      l_reccodevalue_string :=
         pkg_codevalue.f_getfromcode (pkg_codevalue.cst_datatype_string,
                                      pkg_codereference.cst_crf_datatype);

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_integer.cvl_id,
             pmg_cellrowvalue = 10,
             pmg_cellcolumnvalue = 'B'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_blkmobil
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_recouvrement
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 10,
             pmg_cellcolumnvalue = 'E'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_blkmobil
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_150
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 10,
             pmg_cellcolumnvalue = 'F'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_blkmobil
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_150_v_75
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 10,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_blkmobil
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_75_v_25
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 10,
             pmg_cellcolumnvalue = 'H'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_blkmobil
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_25_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 10,
             pmg_cellcolumnvalue = 'I'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_blkmobil
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 10,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_blkmobil
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_remark
             AND pmg_ptv_id = p_ptv_id;



      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_integer.cvl_id,
             pmg_cellrowvalue = 11,
             pmg_cellcolumnvalue = 'B'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_bryophyte
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_recouvrement
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 11,
             pmg_cellcolumnvalue = 'E'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_bryophyte
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_150
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 11,
             pmg_cellcolumnvalue = 'F'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_bryophyte
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_150_v_75
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 11,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_bryophyte
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_75_v_25
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 11,
             pmg_cellcolumnvalue = 'H'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_bryophyte
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_25_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 11,
             pmg_cellcolumnvalue = 'I'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_bryophyte
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 11,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_bryophyte
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_remark
             AND pmg_ptv_id = p_ptv_id;



      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_integer.cvl_id,
             pmg_cellrowvalue = 12,
             pmg_cellcolumnvalue = 'B'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytim
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_recouvrement
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 12,
             pmg_cellcolumnvalue = 'E'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytim
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_150
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 12,
             pmg_cellcolumnvalue = 'F'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytim
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_150_v_75
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 12,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytim
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_75_v_25
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 12,
             pmg_cellcolumnvalue = 'H'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytim
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_25_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 12,
             pmg_cellcolumnvalue = 'I'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytim
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 12,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytim
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_remark
             AND pmg_ptv_id = p_ptv_id;


      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_integer.cvl_id,
             pmg_cellrowvalue = 13,
             pmg_cellcolumnvalue = 'B'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elorggross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_recouvrement
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 13,
             pmg_cellcolumnvalue = 'E'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elorggross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_150
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 13,
             pmg_cellcolumnvalue = 'F'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elorggross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_150_v_75
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 13,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elorggross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_75_v_25
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 13,
             pmg_cellcolumnvalue = 'H'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elorggross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_25_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 13,
             pmg_cellcolumnvalue = 'I'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elorggross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 13,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elorggross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_remark
             AND pmg_ptv_id = p_ptv_id;



      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_integer.cvl_id,
             pmg_cellrowvalue = 14,
             pmg_cellcolumnvalue = 'B'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elmingross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_recouvrement
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 14,
             pmg_cellcolumnvalue = 'E'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elmingross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_150
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 14,
             pmg_cellcolumnvalue = 'F'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elmingross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_150_v_75
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 14,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elmingross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_75_v_25
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 14,
             pmg_cellcolumnvalue = 'H'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elmingross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_25_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 14,
             pmg_cellcolumnvalue = 'I'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elmingross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 14,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_elmingross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_remark
             AND pmg_ptv_id = p_ptv_id;



      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_integer.cvl_id,
             pmg_cellrowvalue = 15,
             pmg_cellcolumnvalue = 'B'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_granulgross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_recouvrement
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 15,
             pmg_cellcolumnvalue = 'E'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_granulgross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_150
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 15,
             pmg_cellcolumnvalue = 'F'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_granulgross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_150_v_75
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 15,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_granulgross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_75_v_25
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 15,
             pmg_cellcolumnvalue = 'H'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_granulgross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_25_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 15,
             pmg_cellcolumnvalue = 'I'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_granulgross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 15,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_granulgross
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_remark
             AND pmg_ptv_id = p_ptv_id;



      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_integer.cvl_id,
             pmg_cellrowvalue = 16,
             pmg_cellcolumnvalue = 'B'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytem
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_recouvrement
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 16,
             pmg_cellcolumnvalue = 'E'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytem
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_150
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 16,
             pmg_cellcolumnvalue = 'F'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytem
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_150_v_75
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 16,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytem
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_75_v_25
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 16,
             pmg_cellcolumnvalue = 'H'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytem
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_25_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 16,
             pmg_cellcolumnvalue = 'I'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytem
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 16,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_spermphytem
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_remark
             AND pmg_ptv_id = p_ptv_id;



      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_integer.cvl_id,
             pmg_cellrowvalue = 17,
             pmg_cellcolumnvalue = 'B'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sedimentfin
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_recouvrement
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 17,
             pmg_cellcolumnvalue = 'E'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sedimentfin
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_150
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 17,
             pmg_cellcolumnvalue = 'F'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sedimentfin
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_150_v_75
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 17,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sedimentfin
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_75_v_25
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 17,
             pmg_cellcolumnvalue = 'H'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sedimentfin
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_25_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 17,
             pmg_cellcolumnvalue = 'I'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sedimentfin
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 17,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sedimentfin
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_remark
             AND pmg_ptv_id = p_ptv_id;



      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_integer.cvl_id,
             pmg_cellrowvalue = 18,
             pmg_cellcolumnvalue = 'B'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sablelimon
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_recouvrement
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 18,
             pmg_cellcolumnvalue = 'E'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sablelimon
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_150
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 18,
             pmg_cellcolumnvalue = 'F'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sablelimon
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_150_v_75
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 18,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sablelimon
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_75_v_25
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 18,
             pmg_cellcolumnvalue = 'H'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sablelimon
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_25_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 18,
             pmg_cellcolumnvalue = 'I'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sablelimon
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 18,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_sablelimon
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_remark
             AND pmg_ptv_id = p_ptv_id;


      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_integer.cvl_id,
             pmg_cellrowvalue = 19,
             pmg_cellcolumnvalue = 'B'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_surfnatart
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_recouvrement
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 19,
             pmg_cellcolumnvalue = 'E'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_surfnatart
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_150
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 19,
             pmg_cellcolumnvalue = 'F'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_surfnatart
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_150_v_75
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 19,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_surfnatart
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_75_v_25
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 19,
             pmg_cellcolumnvalue = 'H'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_surfnatart
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_25_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 19,
             pmg_cellcolumnvalue = 'I'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_surfnatart
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 19,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_surfnatart
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_remark
             AND pmg_ptv_id = p_ptv_id;


      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_integer.cvl_id,
             pmg_cellrowvalue = 20,
             pmg_cellcolumnvalue = 'B'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_algmarnarg
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_recouvrement
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 20,
             pmg_cellcolumnvalue = 'E'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_algmarnarg
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_150
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 20,
             pmg_cellcolumnvalue = 'F'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_algmarnarg
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_150_v_75
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 20,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_algmarnarg
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_75_v_25
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 20,
             pmg_cellcolumnvalue = 'H'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_algmarnarg
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_25_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 20,
             pmg_cellcolumnvalue = 'I'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_algmarnarg
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_v_5
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 20,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdro =
                    pkg_codevalue.cst_midatitgrdro_algmarnarg
             AND pmg_cvl_code_midatitgrdcl =
                    pkg_codevalue.cst_midatitgrdcl_remark
             AND pmg_ptv_id = p_ptv_id;



      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 22,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdce =
                    pkg_codevalue.cst_grditemcell_substrdom
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 24,
             pmg_cellcolumnvalue = 'G'
       WHERE     pmg_cvl_code_midatitgrdce =
                    pkg_codevalue.cst_grditemcell_largeurmoy
             AND pmg_ptv_id = p_ptv_id;

      UPDATE protocolmappinggrid
         SET pmg_cvl_id_datatype = l_reccodevalue_string.cvl_id,
             pmg_cellrowvalue = 24,
             pmg_cellcolumnvalue = 'J'
       WHERE     pmg_cvl_code_midatitgrdce =
                    pkg_codevalue.cst_grditemcell_length
             AND pmg_ptv_id = p_ptv_id;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_buildbycvlcode (
      p_ptv_id   IN protocolmappinggrid.pmg_ptv_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
      CURSOR l_protocolmappinggrid
      IS
         SELECT *
           FROM protocolmappinggrid
          WHERE     NOT pmg_cvl_code_midatitgrdro IS NULL
                AND NOT pmg_cvl_code_midatitgrdcl IS NULL
                AND pmg_ptv_id = p_ptv_id
         FOR UPDATE;

      l_reccodevaluerow          codevalue%ROWTYPE;
      l_reccodevaluecol          codevalue%ROWTYPE;

      l_recprotocolmappinggrid   l_protocolmappinggrid%ROWTYPE;
   BEGIN
      OPEN l_protocolmappinggrid;

      LOOP
         FETCH l_protocolmappinggrid INTO l_recprotocolmappinggrid;

         EXIT WHEN l_protocolmappinggrid%NOTFOUND;
         l_reccodevaluerow :=
            pkg_codevalue.f_getfromcode (
               l_recprotocolmappinggrid.pmg_cvl_code_midatitgrdro,
               pkg_codereference.cst_crf_midatitgrdro);
         l_reccodevaluecol :=
            pkg_codevalue.f_getfromcode (
               l_recprotocolmappinggrid.pmg_cvl_code_midatitgrdcl,
               pkg_codereference.cst_crf_midatitgrdcl);

         IF    l_reccodevaluecol.cvl_id IS NULL
            OR l_reccodevaluerow.cvl_id IS NULL
         THEN
            raise_application_error (
               -20000,
                  'Probème d''interrogation des codes row '
               || l_recprotocolmappinggrid.pmg_cvl_code_midatitgrdro
               || ' column '
               || l_recprotocolmappinggrid.pmg_cvl_code_midatitgrdcl,
               TRUE);
         ELSE
            UPDATE protocolmappinggrid
               SET pmg_cvl_id_midatitgrdro = l_reccodevaluerow.cvl_id,
                   pmg_cvl_id_midatitgrdcl = l_reccodevaluecol.cvl_id
             WHERE CURRENT OF l_protocolmappinggrid;
         END IF;
      END LOOP;

      CLOSE l_protocolmappinggrid;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_buildcell (p_ptv_id IN protocolmappinggrid.pmg_ptv_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
      CURSOR l_midatgrdce
      IS
         SELECT *
           FROM codevalue
          WHERE cvl_crf_id =
                   (SELECT crf_id
                      FROM codereference
                     WHERE crf_code = pkg_codereference.cst_crf_midatitgrdce);

      l_recmidatgrdce            l_midatgrdce%ROWTYPE;
      l_recprotocolmappinggrid   protocolmappinggrid%ROWTYPE;
      l_id                       protocolmappinggrid.pmg_id%TYPE;
   BEGIN
      OPEN l_midatgrdce;

      LOOP
         FETCH l_midatgrdce INTO l_recmidatgrdce;

         EXIT WHEN l_midatgrdce%NOTFOUND;
         l_recprotocolmappinggrid :=
            pkg_protocolmappinggrid.f_getrecordbyitemcell (
               p_ptv_id,
               l_recmidatgrdce.cvl_id);

         IF l_recprotocolmappinggrid.pmg_id IS NULL
         THEN
            pkg_protocolmappinggrid.p_write (p_ptv_id,
                                             NULL,
                                             NULL,
                                             l_recmidatgrdce.cvl_id, --pmg_cvl_id_grditemcell
                                             NULL,        -- pmg_cellrowvalue,
                                             NULL,       --pmg_cellcolumnvalue
                                             NULL,
                                             NULL,
                                             l_recmidatgrdce.cvl_code, --pmg_cvl_code_grditemce
                                             l_id);
         END IF;
      END LOOP;

      CLOSE l_midatgrdce;
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_buildgrid (p_ptv_id IN protocolmappinggrid.pmg_ptv_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
      CURSOR l_midatgrdro
      IS
         SELECT *
           FROM codevalue
          WHERE cvl_crf_id =
                   (SELECT crf_id
                      FROM codereference
                     WHERE crf_code = pkg_codereference.cst_crf_midatitgrdro);


      l_recmidatgrdro            l_midatgrdro%ROWTYPE;

      CURSOR l_midatgrdcl
      IS
         SELECT *
           FROM codevalue
          WHERE cvl_crf_id =
                   (SELECT crf_id
                      FROM codereference
                     WHERE crf_code = pkg_codereference.cst_crf_midatitgrdcl);

      l_recmidatgrdcl            l_midatgrdcl%ROWTYPE;
      l_recprotocolmappinggrid   protocolmappinggrid%ROWTYPE;
      l_id                       protocolmappinggrid.pmg_id%TYPE;
   BEGIN
      OPEN l_midatgrdro;



      LOOP
         FETCH l_midatgrdro INTO l_recmidatgrdro;

         EXIT WHEN l_midatgrdro%NOTFOUND;

         OPEN l_midatgrdcl;

         LOOP
            FETCH l_midatgrdcl INTO l_recmidatgrdcl;

            EXIT WHEN l_midatgrdcl%NOTFOUND;

            l_recprotocolmappinggrid :=
               pkg_protocolmappinggrid.f_getrecordbyitemrocol (
                  p_ptv_id,
                  l_recmidatgrdro.cvl_id,
                  l_recmidatgrdcl.cvl_id);

            IF l_recprotocolmappinggrid.pmg_id IS NULL
            THEN
               DBMS_OUTPUT.put_line ('Insert');
               pkg_protocolmappinggrid.p_write (p_ptv_id,
                                                l_recmidatgrdro.cvl_id,
                                                l_recmidatgrdcl.cvl_id,
                                                NULL, --pmg_cvl_id_grditemcell
                                                NULL,     -- pmg_cellrowvalue,
                                                NULL,    --pmg_cellcolumnvalue
                                                l_recmidatgrdro.cvl_code,
                                                l_recmidatgrdcl.cvl_code,
                                                NULL, --pmg_cvl_code_grditemce
                                                l_id);
            ELSE
               DBMS_OUTPUT.put_line ('Update');
               l_recprotocolmappinggrid.pmg_cvl_id_midatitgrdro :=
                  l_recmidatgrdro.cvl_id;
               l_recprotocolmappinggrid.pmg_cvl_id_midatitgrdcl :=
                  l_recmidatgrdcl.cvl_id;
               l_recprotocolmappinggrid.pmg_cvl_code_midatitgrdro :=
                  l_recmidatgrdro.cvl_code;
               l_recprotocolmappinggrid.pmg_cvl_code_midatitgrdcl :=
                  l_recmidatgrdcl.cvl_code;
               pkg_protocolmappinggrid.p_update (l_recprotocolmappinggrid);
            END IF;
         END LOOP;

         CLOSE l_midatgrdcl;
      END LOOP;

      CLOSE l_midatgrdro;
   END;
END pkg_migr_protocolmappinggrid;
/

