create PACKAGE       pkg_ibch2019
AS
    /******************************************************************************
      NAME:       PKG_MIGR_IBCH2019
      PURPOSE:     Calcul de l'indice IBCH2019

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
   ******************************************************************************/

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2020';
    cst_startprotversion_ibch2019   CONSTANT NUMBER := 3;


    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_cascadefrequence (
        p_ptl_id      IN protocolmappinglabo.ptl_id%TYPE,
        p_frequence   IN importprotocollabo.ipl_value%TYPE);

    PROCEDURE p_displayfrequence;

    PROCEDURE p_displayfrequencesort;



    FUNCTION f_gettaxonindicateur
        RETURN VARCHAR2;

    FUNCTION f_getibch
        RETURN NUMBER;

    FUNCTION f_getibchrobust
        RETURN NUMBER;

    FUNCTION f_getclassevariete
        RETURN NUMBER;

    FUNCTION f_getclassevariete_corr
        RETURN NUMBER;

    FUNCTION f_getclassevarieterobust
        RETURN NUMBER;


    FUNCTION f_getclassevarieterobust_corr
        RETURN NUMBER;

    FUNCTION f_getclassevariete_final
        RETURN NUMBER;

    FUNCTION f_getclassevarieterobust_final
        RETURN NUMBER;

    FUNCTION f_gettaxonfrequencesum
        RETURN NUMBER;

    FUNCTION f_getgimax
        RETURN NUMBER;

    FUNCTION f_getgimaxrobust
        RETURN NUMBER;

    FUNCTION f_getgi_final
        RETURN NUMBER;

    FUNCTION f_getgirobust_final
        RETURN NUMBER;

    FUNCTION f_getsumfamily
        RETURN NUMBER;

    FUNCTION f_getsumfamilycorrected
        RETURN NUMBER;

    FUNCTION f_getsumfamilyrobust
        RETURN NUMBER;

    FUNCTION f_getsumfamilyrobustcorrected
        RETURN NUMBER;

    FUNCTION f_getplecopteracounter
        RETURN NUMBER;

    FUNCTION f_getephemeropteracounter
        RETURN NUMBER;

    FUNCTION f_gettrichopteracounter
        RETURN NUMBER;

    PROCEDURE p_init;


    FUNCTION f_getcounterbytaxa (
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE,
        p_taxa     IN protocolmappinglabo.ptl_taxa%TYPE)
        RETURN NUMBER;

    PROCEDURE p_displaygroup_gi;

    PROCEDURE p_compute_ibch2019;

    PROCEDURE p_setibch_q (p_ibch_q IN NUMBER);

    PROCEDURE p_maincompute (
        p_recprotocolheader   IN importprotocolheader%ROWTYPE,
        p_recmassdataheader   IN importmassdataheader%ROWTYPE);
END pkg_ibch2019;
/

