create trigger TR_BUF_IMPORTMASSDATAHEADER
    before update
    on IMPORTMASSDATAHEADER
    for each row
DECLARE
BEGIN


   :new.imh_moddate := SYSDATE;
   :new.imh_moduser := USER;
END tr_buf_importmassdataheader;

/

