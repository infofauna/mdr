create PACKAGE       pkg_samplestation
AS
   /******************************************************************************
      NAME:       pkg_samplestation
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.10.2013   F.Burri          1. Created this package.
      2.0         11.07.2017     burrif       2. Fonctionnalité version 2
   ******************************************************************************/



   cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2017';

   --   cst_startpointtoleranceinfo      CONSTANT NUMBER := 10; -- 10 mètres pour l'affichage d'une info pour les stations existantes
   --    cst_startpointtolerancewarning   CONSTANT NUMBER := 20; -- 20 mètres pour l'affichage d'un warning pour les stations existantes

   --  cst_rayontolerance               CONSTANT NUMBER := 50; -- 50 mètres, distance dans laquelle on cherche une station existante sans OID
   --   cst_rayontolerancesameoid        CONSTANT NUMBER := 10; -- 10 mètres, distance dans laquelle on cherche une station existante avec le même OID
   --  cst_rayonmatching                CONSTANT NUMBER := 5; -- rayon dans lequel on fusionne la station trouvée (protocol laboratoire)

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_deleteifnomoreused (p_sph_id   IN sampleheader.sph_id%TYPE,
                                   p_sst_id   IN samplestation.sst_id%TYPE);

   PROCEDURE p_update_sst_sst_id (
      p_sst_id       IN samplestation.sst_id%TYPE,
      p_sst_sst_id   IN samplestation.sst_sst_id%TYPE,
      p_usr_id       IN samplestation.sst_usr_id_create%TYPE);

   FUNCTION f_buildswisscoord (p_recsamplestation IN samplestation%ROWTYPE)
      RETURN VARCHAR2;

   FUNCTION f_returncounterreference (p_sst_id IN samplestation.sst_id%TYPE)
      RETURN NUMBER;

   PROCEDURE p_returnstationinfo (
      p_sst_id         IN     samplestation.sst_id%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_oid               OUT samplestation.sst_oid%TYPE,
      p_watercourse       OUT VARCHAR2,
      p_locality          OUT VARCHAR2,
      p_returnstatus      OUT NUMBER);


   PROCEDURE p_purge;

   PROCEDURE p_deleteconditional (p_sst_id IN samplestation.sst_id%TYPE);

   PROCEDURE p_getnearsst_id (
      p_coordinates   IN     SDO_GEOMETRY,
      p_ins_id        IN     samplestation.sst_ins_id%TYPE,
      p_sst_id           OUT samplestation.sst_id%TYPE,
      p_distance         OUT NUMBER);

   FUNCTION f_getrecord (p_sst_id IN samplestation.sst_id%TYPE)
      RETURN samplestation%ROWTYPE;

   PROCEDURE p_tr_bif_samplestation (p_newrec IN OUT samplestation%ROWTYPE);

   PROCEDURE p_tr_buf_samplestation (p_oldrec   IN     samplestation%ROWTYPE,
                                     p_newrec   IN OUT samplestation%ROWTYPE);

   FUNCTION f_getrecordbyoid (p_oid IN samplestation.sst_oid%TYPE)
      RETURN samplestation%ROWTYPE;

   FUNCTION f_getrecordbyinsidandoid (
      p_ins_id   IN sampleheader.sph_ins_id_principal%TYPE,
      p_oid      IN samplestation.sst_oid%TYPE)
      RETURN samplestation%ROWTYPE;

   PROCEDURE p_findstationbycoordinates (
      p_x               IN     NUMBER,
      p_y               IN     NUMBER,
      p_z               IN     NUMBER,
      p_ins_id          IN     samplestation.sst_ins_id%TYPE,
      p_samplestation      OUT samplestation%ROWTYPE,
      p_distance           OUT NUMBER);

   PROCEDURE p_findstationbycoordinates (
      p_point           IN     MDSYS.sdo_geometry,
      p_ins_id          IN     samplestation.sst_ins_id%TYPE,
      p_samplestation      OUT samplestation%ROWTYPE,
      p_distance           OUT NUMBER);

   FUNCTION f_calculateoid (p_ins_id IN NUMBER)
      RETURN NUMBER;


   PROCEDURE p_writefulldata (
      p_lan_id                   IN     language.lan_id%TYPE,
      p_oid                      IN     samplestation.sst_oid%TYPE,
      p_oid_calculated           IN     samplestation.sst_oid_calculated%TYPE,
      p_oid_provided             IN     samplestation.sst_oid_provided%TYPE,
      p_ins_id                   IN     samplestation.sst_ins_id%TYPE,
      p_coordinate_x             IN     NUMBER,
      p_coordinate_y             IN     NUMBER,
      p_coordinate_z             IN     NUMBER,
      p_cvl_id_elevationorigin   IN     samplestation.sst_cvl_id_elevationorigin%TYPE,
      p_elevationprecision       IN     samplestation.sst_elevationprecision%TYPE,
      p_title                    IN     samplestation.sst_title%TYPE,
      p_locality                 IN     samplestationitem.ssi_item%TYPE,
      p_calledplace              IN     samplestationitem.ssi_item%TYPE,
      p_watercourse              IN     samplestationitem.ssi_item%TYPE,
      p_gewissnr                 IN     samplestation.sst_gewissnr%TYPE,
      p_usr_id                   IN     samplestation.sst_usr_id_create%TYPE,
      p_cvl_id_canton            IN     samplestation.sst_cvl_id_canton%TYPE,
      p_id                          OUT samplestation.sst_id%TYPE);

   PROCEDURE p_write (
      p_lan_id                   IN     language.lan_id%TYPE,
      p_oid                      IN     samplestation.sst_oid%TYPE,
      p_oid_calculated           IN     samplestation.sst_oid_calculated%TYPE,
      p_oid_provided             IN     samplestation.sst_oid_provided%TYPE,
      p_ins_id                   IN     samplestation.sst_ins_id%TYPE,
      p_coordinate_x             IN     NUMBER,
      p_coordinate_y             IN     NUMBER,
      p_coordinate_z             IN     NUMBER,
      p_cvl_id_elevationorigin   IN     samplestation.sst_cvl_id_elevationorigin%TYPE,
      p_elevationprecision       IN     samplestation.sst_elevationprecision%TYPE,
      p_title                    IN     samplestation.sst_title%TYPE,
      p_gewissnr                 IN     samplestation.sst_gewissnr%TYPE,
      p_usr_id                   IN     samplestation.sst_usr_id_create%TYPE,
      p_cvl_id_canton            IN     samplestation.sst_cvl_id_canton%TYPE,
      p_id                          OUT samplestation.sst_id%TYPE);
END pkg_samplestation;
/

