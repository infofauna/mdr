create trigger TR_BUF_PROTOCOLMASSFIELDROLE
    before update
    on PROTOCOLMASSFIELDROLE
    for each row
DECLARE
BEGIN


   :new.PFR_moddate := SYSDATE;
   :new.PFR_moduser := USER;
END TR_BUF_PROTOCOLMASSFIELDROLE;

/

