create PACKAGE BODY       pkg_spear2019
AS
    /******************************************************************************
       NAME:       PKG_SPEAR2019
       PURPOSE:    Calcul de l'indice SPEAR2019

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    TYPE t_listfrequence IS TABLE OF importprotocollabo.ipl_value%TYPE
        INDEX BY PLS_INTEGER;

    gbl_listfrequence   t_listfrequence;      -- Données fournies + hiérarchie
    gbl_spear           NUMBER := 0;

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-------------------------------------------------------------*/
    FUNCTION f_getspear
        RETURN NUMBER
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_spear;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_addfrequence (
        p_ptl_id      IN protocolmappinglabo.ptl_id%TYPE,
        p_frequence   IN importprotocollabo.ipl_value%TYPE)
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        IF gbl_listfrequence.EXISTS (ROUND (p_ptl_id))
        THEN
            gbl_listfrequence (ROUND (p_ptl_id)) :=
                gbl_listfrequence (ROUND (p_ptl_id)) + p_frequence;
        ELSE
            gbl_listfrequence (ROUND (p_ptl_id)) := p_frequence;
        END IF;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_init
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_listfrequence.delete;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_loaddatafromlabo (
        p_recprotocolheader   IN importprotocolheader%ROWTYPE)
    /*------------------------------------------------------------------*/
    IS
        CURSOR l_listlabodata (p_iph_id IN importprotocolheader.iph_id%TYPE)
        IS
            SELECT *
              FROM importprotocollabo
             WHERE     ipl_iph_id = p_iph_id
                   AND ipl_validstatus = pkg_constante.cst_validstatusok;

        l_reclabodata   l_listlabodata%ROWTYPE;
    BEGIN
        OPEN l_listlabodata (p_recprotocolheader.iph_id);

        LOOP
            FETCH l_listlabodata INTO l_reclabodata;

            EXIT WHEN l_listlabodata%NOTFOUND;

            p_addfrequence (l_reclabodata.ipl_ptl_id,
                            l_reclabodata.ipl_value);
        END LOOP;

        CLOSE l_listlabodata;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_maincompute (
        p_recprotocolheader   IN importprotocolheader%ROWTYPE,
        p_recmassdataheader   IN importmassdataheader%ROWTYPE)
    /*------------------------------------------------------------------*/
    IS
        l_ptv_id               protocolversion.ptv_id%TYPE;
        l_recprotocolversion   protocolversion%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
    BEGIN
        l_recprotocolversion := pkg_protocolversion.f_getrecord (l_ptv_id);
        l_reccodevalue :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);
        pkg_debug.p_write (
            'PKG_SPEAR2019.p_maincompute',
            'l_reccodevalue.cvl_code=' || l_reccodevalue.cvl_code);

        IF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_mass
        THEN
            raise_application_error (
                -20000,
                'MASS PROTOCOL UNSUPORTED WITH SPEAR2019',
                TRUE);
        END IF;

        p_init;
        p_loaddatafromlabo (p_recprotocolheader);
        p_computespear;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_computespear
    /*------------------------------------------------------------------*/
    IS
        l_indice                   PLS_INTEGER;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_sommenumerateur          NUMBER := 0;
        l_sommedenominateur        NUMBER := 0;
    BEGIN
        l_indice := gbl_listfrequence.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (l_indice);

            IF l_recprotocolmappinglabo.ptl_id IS NULL
            THEN
                raise_application_error (
                    -20000,
                    'PTL_ID=' || l_indice || ' non trouvé',
                    TRUE);
            END IF;

            IF NOT l_recprotocolmappinglabo.ptl_spearindexfactor IS NULL
            THEN
                l_sommenumerateur :=
                      l_sommenumerateur
                    +   LOG (10, 4 * gbl_listfrequence (l_indice) + 1)
                      * l_recprotocolmappinglabo.ptl_spearindexfactor;
                l_sommedenominateur :=
                      l_sommedenominateur
                    + LOG (10, 4 * gbl_listfrequence (l_indice) + 1);
            END IF;

            l_indice := gbl_listfrequence.NEXT (l_indice);
        END LOOP;

        IF l_sommedenominateur = 0
        THEN
            gbl_spear := 0;
        ELSE
            gbl_spear := l_sommenumerateur / l_sommedenominateur * 100;
        END IF;

        NULL;
    END;
BEGIN
    p_init;
END;
/

