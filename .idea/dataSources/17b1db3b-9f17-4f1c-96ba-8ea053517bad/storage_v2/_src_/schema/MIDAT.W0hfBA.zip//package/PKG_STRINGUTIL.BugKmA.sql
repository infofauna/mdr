create PACKAGE       pkg_stringutil
AS
   /******************************************************************************
      NAME:       PKG_STRINGUTIL
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/
   TYPE t_listofvalue IS TABLE OF VARCHAR2 (127);

   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_findkeyword (p_keyword      IN VARCHAR2,
                           p_liststring   IN VARCHAR2,
                           p_separator    IN VARCHAR2)
      RETURN VARCHAR2;

   PROCEDURE p_test;

   FUNCTION f_formatdate (p_day     IN NUMBER,
                          p_month   IN NUMBER,
                          p_year    IN NUMBER)
      RETURN VARCHAR2;

   FUNCTION f_formatnumber (p_number IN NUMBER)
      RETURN VARCHAR2;

   FUNCTION f_returnrowcountfromsql (p_sql IN VARCHAR2)
      RETURN NUMBER;

   FUNCTION f_getdatainparenthesis (p_string IN VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION f_removedatainparenthesis (p_string IN VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION f_findcharacterbyend (p_string VARCHAR2, p_char IN CHAR)
      RETURN PLS_INTEGER;

   FUNCTION f_formatdecimalformat (p_numberdigit   IN PLS_INTEGER,
                                   p_decimal       IN PLS_INTEGER)
      RETURN VARCHAR2;

   FUNCTION f_doubleapostrophe (p_string IN VARCHAR2)
      RETURN VARCHAR2;

   PROCEDURE p_createsequence (p_sequence    IN VARCHAR2,
                               p_startwith   IN PLS_INTEGER,
                               p_recreate    IN BOOLEAN);

   FUNCTION f_returnsequencevalue (p_sequence IN VARCHAR2)
      RETURN NUMBER;

   FUNCTION f_returnelapsedtime (p_time1 IN TIMESTAMP, p_time2 IN TIMESTAMP)
      RETURN NUMBER;

   FUNCTION f_convertmilisecond (p_millisecond IN NUMBER)
      RETURN VARCHAR2;

   FUNCTION f_extractsubstring (p_string      IN VARCHAR2,
                                p_separator   IN VARCHAR2,
                                p_occurence   IN NUMBER)
      RETURN VARCHAR2;

   FUNCTION f_splitstring (p_string IN VARCHAR2, p_separator IN VARCHAR2)
      RETURN t_listofvalue;

   FUNCTION f_buildexcelcellref (p_row IN NUMBER, p_column IN VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION f_validatedate (p_date IN VARCHAR2)
      RETURN DATE;

   FUNCTION f_validatenumber (p_numberstring IN VARCHAR2)
      RETURN NUMBER;

   FUNCTION f_formatpersonnames (p_first_name   IN VARCHAR2,
                                 p_last_name    IN VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION f_normalisestring (p_string VARCHAR2)
      RETURN VARCHAR2
      DETERMINISTIC;

   FUNCTION f_validateinteger (p_numberstring IN VARCHAR2)
      RETURN NUMBER;
END pkg_stringutil;
/

