create PACKAGE       pkg_rightutility_v2
AS
    /******************************************************************************
       NAME:       pkg_rightutility_v2
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
         1.0        5.07.2018     burrif       1. Created this package.
    ******************************************************************************/


    cst_rightaccessok       CONSTANT NUMBER := 1;
    cst_rightaccessdenied   CONSTANT NUMBER := -999;

    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_checkwriteright (
        p_x             IN     NUMBER,
        p_y             IN     NUMBER,
        p_usr_id        IN     sampleheader.sph_usr_id_create%TYPE,
        p_rightaccess      OUT NUMBER);

    FUNCTION f_returngrouprightlist (
        p_usr_id             IN sampleheader.sph_usr_id_create%TYPE,
        p_application_code   IN admin_application.apl_code%TYPE,
        p_writable           IN BOOLEAN)
        RETURN VARCHAR2;

    PROCEDURE p_checkcoordinateinlistgroup (
        p_x           IN     NUMBER,
        p_y           IN     NUMBER,
        p_usr_id      IN     sampleheader.sph_usr_id_create%TYPE,
        p_outoflist      OUT BOOLEAN);

    PROCEDURE p_test;

    PROCEDURE p_testlist;

    PROCEDURE p_testcheckwriteright;

    PROCEDURE p_testreturngrouprightlist;


    PROCEDURE p_testcheckcoordinateinlistgrp;
END;
/

