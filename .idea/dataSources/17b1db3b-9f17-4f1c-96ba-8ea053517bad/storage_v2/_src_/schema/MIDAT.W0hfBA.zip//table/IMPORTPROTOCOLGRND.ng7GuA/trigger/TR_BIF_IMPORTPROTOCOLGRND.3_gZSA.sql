create trigger TR_BIF_IMPORTPROTOCOLGRND
    before insert
    on IMPORTPROTOCOLGRND
    for each row
DECLARE
BEGIN
   IF :new.ipn_id IS NULL
   THEN
      :new.ipn_id := seq_IMPORTPROTOCOLGRND.NEXTVAL;
   END IF;

   :new.ipn_credate := SYSDATE;
   :new.ipn_creuser := USER;
END tr_bif_IMPORTPROTOCOLGRND;

/

