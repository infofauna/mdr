create view V_PROTOCOLTYPE as
SELECT sph_id,
           cvl_code,
           cdn_designation,
           (SELECT COUNT (DISTINCT spg_sph_id)
              FROM sampleprotocolgrid
             WHERE spg_sph_id = sph_id)
               has_grid,
           (SELECT COUNT (DISTINCT spd_sph_id)
              FROM sampleprotocolgrnd
             WHERE spd_sph_id = sph_id)
               has_ground
      FROM codedesignation
           INNER JOIN codevalue ON cdn_cvl_id = cvl_id
           INNER JOIN protocolversion ON cvl_id = ptv_cvl_id_protocoltype
           INNER JOIN sampleheader ON sph_ptv_id = ptv_id
           INNER JOIN language ON lan_id = cdn_lan_id
     WHERE lan_code = 'fr'
/

