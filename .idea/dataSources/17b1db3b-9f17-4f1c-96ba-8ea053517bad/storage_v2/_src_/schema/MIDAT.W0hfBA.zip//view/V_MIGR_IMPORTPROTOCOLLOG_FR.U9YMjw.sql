create view V_MIGR_IMPORTPROTOCOLLOG_FR as
SELECT pkg_message.f_returnmessageseverity (ipo_exceptionnumber) severity,
            pkg_importprotocollog.f_buildmessage (ipo_id,
                                                  ipo_exceptionnumber,
                                                  1)
               MESSAGE,
            ipo_fieldname,
            ipo_exceptionnumber,
            ipo_iph_id
       FROM importprotocollog
   ORDER BY ipo_id
/

