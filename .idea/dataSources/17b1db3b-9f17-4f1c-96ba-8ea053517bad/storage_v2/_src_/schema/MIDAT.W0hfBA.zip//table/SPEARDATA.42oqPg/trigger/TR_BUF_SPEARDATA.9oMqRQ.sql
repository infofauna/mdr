create trigger TR_BUF_SPEARDATA
    before update
    on SPEARDATA
    for each row
DECLARE
BEGIN
 
   :new.SRA_moddate := SYSDATE;
   :new.SRA_moduser := USER;
END tr_buf_SPEARDATA;

/

