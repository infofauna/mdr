create PACKAGE       pkg_migr_main
AS
   /******************************************************************************
      NAME:       PKG_MIGR_MAIN
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/

   PROCEDURE p_purgeall;

   PROCEDURE p_buildfkuser;

   PROCEDURE p_removestationdoublon;

   PROCEDURE p_clearsyv_id; -- Pour effecer les lein en vue de la reconstruction du thésaure

   PROCEDURE p_synchronizesyv_id; /* A utiliser après avoir rechargée les données de systématique */

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_build_idx;

   PROCEDURE p_build_fk;

   PROCEDURE p_clearmassdata;

   PROCEDURE p_clearalldata;

   PROCEDURE p_define_synonym;
END pkg_migr_main;
/

