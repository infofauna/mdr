create view V_STATIONSAMPLESTATIONITEM as
SELECT "SSI_ID",
           "SSI_STATUS",
           "SSI_SST_ID",
           "SSI_LAN_ID",
           "SSI_CVL_ID_MIDATSTITMTY",
           "SSI_ITEM",
           "SSI_CREDATE",
           "SSI_CREUSER",
           "SSI_MODDATE",
           "SSI_MODUSER",
           "SSI_USR_ID_CREATE",
           "SSI_USR_CREATE_DATE",
           "SSI_USR_ID_MODIFY",
           "SSI_USR_MODIFY_DATE"
      FROM samplestationitem
/

