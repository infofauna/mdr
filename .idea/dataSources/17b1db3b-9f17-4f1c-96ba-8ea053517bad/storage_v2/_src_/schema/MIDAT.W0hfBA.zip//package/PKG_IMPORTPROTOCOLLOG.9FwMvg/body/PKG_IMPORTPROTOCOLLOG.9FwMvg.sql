create PACKAGE BODY       pkg_importprotocollog
AS
   /******************************************************************************
      NAME:       PKG_IMPORTPROTOCOLLOG
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        01.10.2013      burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, octobre 2013';
   gbl_usr_id_create             importprotocollog.ipo_usr_id_create%TYPE;
   gbl_error_count               NUMBER := 0;

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_write (
      p_ipo_iph_id            IN     importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN     importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN     importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN     importprotocollog.ipo_fieldname%TYPE,
      p_ipo_id                   OUT importprotocollog.ipo_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_ipo_id := seq_importprotocollog.NEXTVAL;

      INSERT INTO importprotocollog (ipo_id,
                                     ipo_iph_id,
                                     ipo_imh_id,
                                     ipo_exceptionnumber,
                                     ipo_fieldname)
           VALUES (p_ipo_id,
                   p_ipo_iph_id,
                   p_ipo_imh_id,
                   p_ipo_exceptionnumber,
                   p_ipo_fieldname);
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_recopyerrorbyimh_id (
      p_imh_id   IN importprotocollog.ipo_imh_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
      /* Permet de recopier les ERREUR pour les besoins du résumé */
      CURSOR l_importprotocollog
      IS
         SELECT *
           FROM importprotocollog
          WHERE     ipo_imh_id = p_imh_id
                AND ipo_exceptionnumber IN
                       (SELECT msg_errornumber
                          FROM MESSAGE
                         WHERE msg_severity =
                                  pkg_message.cst_severity_level_error);

      CURSOR l_importprotocollogparam (
         p_ipo_id   IN importprotocollogparam.ipr_ipo_id%TYPE)
      IS
         SELECT *
           FROM importprotocollogparam
          WHERE ipr_ipo_id = p_ipo_id;

      l_recimportprotocollog        l_importprotocollog%ROWTYPE;
      l_recimportprotocollogparam   l_importprotocollogparam%ROWTYPE;
      l_ipo_id                      importprotocollog.ipo_id%TYPE;
   BEGIN
      OPEN l_importprotocollog;

      LOOP
         FETCH l_importprotocollog INTO l_recimportprotocollog;


         EXIT WHEN l_importprotocollog%NOTFOUND;
         p_write (l_recimportprotocollog.ipo_iph_id,
                  l_recimportprotocollog.ipo_imh_id,
                  l_recimportprotocollog.ipo_exceptionnumber,
                  l_recimportprotocollog.ipo_fieldname,
                  l_ipo_id);

         OPEN l_importprotocollogparam (l_recimportprotocollog.ipo_id);

         LOOP
            FETCH l_importprotocollogparam INTO l_recimportprotocollogparam;

            EXIT WHEN l_importprotocollogparam%NOTFOUND;
            pkg_importprotocollogparam.p_insert (
               l_ipo_id,
               l_recimportprotocollogparam.ipr_sequence,
               l_recimportprotocollogparam.ipr_parameter);
         END LOOP;

         CLOSE l_importprotocollogparam;
      END LOOP;

      CLOSE l_importprotocollog;

      NULL;
   END;



   /*----------------------------------------------------------------*/
   PROCEDURE p_returnvalidatestatus (
      p_iph_id         IN     importprotocolheader.iph_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*----------------------------------------------------------------*/
   IS
      l_counterror   NUMBER;
      l_countfatal   NUMBER;
   BEGIN
      l_counterror :=
         pkg_importprotocollog.f_getcountseveritylevel (
            p_iph_id,
            pkg_constante.cst_severity_level_error);
      l_countfatal :=
         pkg_importprotocollog.f_getcountseveritylevel (
            p_iph_id,
            pkg_constante.cst_severity_level_fatal);

      IF l_counterror + l_countfatal > 0
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
      ELSE
         p_returnstatus := pkg_constante.cst_returnstatusok;
      END IF;
   END;


   /*------------------------------------------------------------*/
   PROCEDURE p_add_error_count (p_add IN NUMBER)
   /*------------------------------------------------------------*/
   IS
   BEGIN
      gbl_error_count := gbl_error_count + p_add;
   END;

   /*-----------------------------------------------------------*/
   PROCEDURE p_reset_error_count
   /*-----------------------------------------------------------*/
   IS
   BEGIN
      gbl_error_count := 0;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_setwebuserinfo (
      p_usr_id_create    importprotocollog.ipo_usr_id_create%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      gbl_usr_id_create := p_usr_id_create;
   END;

   /*-------------------------------------------------------------------------------*/
   PROCEDURE p_logstartsubprocess (
      p_iph_id      IN importprotocolheader.iph_id%TYPE,
      p_imh_id      IN importprotocollog.ipo_imh_id%TYPE,
      p_exception   IN NUMBER)
   /*-------------------------------------------------------------------------------*/
   IS
   BEGIN
      pkg_importprotocollog.p_writelog (
         p_iph_id,
         p_imh_id,
         p_exception,
         NULL,
         TO_CHAR (SYSDATE, 'DD/MM/YYYY HH24:MI:SS'));
   END;

   /*--------------------------------------------------------------------------------*/
   PROCEDURE p_logendsubprocess (
      p_iph_id           IN importprotocolheader.iph_id%TYPE,
      p_imh_id           IN importprotocollog.ipo_imh_id%TYPE,
      p_exception        IN NUMBER,
      p_starttimestamp   IN TIMESTAMP,
      p_recordcount      IN NUMBER)
   /*-------------------------------------------------------------------------------*/
   IS
      l_deltatime      NUMBER;
      l_deltatimefmt   VARCHAR2 (256);
      l_endtime        TIMESTAMP;
   BEGIN
      l_endtime := SYSTIMESTAMP;
      l_deltatime :=
         pkg_stringutil.f_returnelapsedtime (l_endtime, p_starttimestamp);
      l_deltatimefmt := pkg_stringutil.f_convertmilisecond (l_deltatime);


      IF NOT p_recordcount IS NULL
      THEN
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,
            p_exception,
            NULL,
            TO_CHAR (SYSDATE, 'DD/MM/YYYY HH24:MI:SS'),
            l_deltatimefmt,
            TO_CHAR (p_recordcount));
      ELSE
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,
            p_exception,
            NULL,
            TO_CHAR (SYSDATE, 'DD/MM/YYYY HH24:MI:SS'),
            l_deltatimefmt);
      END IF;


      NULL;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_writelog (p_ipo_iph_id,
                  p_ipo_imh_id,
                  p_ipo_exceptionnumber,
                  p_ipo_fieldname,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_writelog (p_ipo_iph_id,
                  p_ipo_imh_id,
                  p_ipo_exceptionnumber,
                  p_ipo_fieldname,
                  p_param1,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_writelog (p_ipo_iph_id,
                  p_ipo_imh_id,
                  p_ipo_exceptionnumber,
                  p_ipo_fieldname,
                  p_param1,
                  p_param2,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL);
   END;


   /*----------------------------------------------------------------*/
   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_writelog (p_ipo_iph_id,
                  p_ipo_imh_id,
                  p_ipo_exceptionnumber,
                  p_ipo_fieldname,
                  p_param1,
                  p_param2,
                  p_param3,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_writelog (p_ipo_iph_id,
                  p_ipo_imh_id,
                  p_ipo_exceptionnumber,
                  p_ipo_fieldname,
                  p_param1,
                  p_param2,
                  p_param3,
                  p_param4,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_writelog (p_ipo_iph_id,
                  p_ipo_imh_id,
                  p_ipo_exceptionnumber,
                  p_ipo_fieldname,
                  p_param1,
                  p_param2,
                  p_param3,
                  p_param4,
                  p_param5,
                  NULL,
                  NULL,
                  NULL,
                  NULL,
                  NULL);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param6                IN importprotocollogparam.ipr_parameter%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_writelog (p_ipo_iph_id,
                  p_ipo_imh_id,
                  p_ipo_exceptionnumber,
                  p_ipo_fieldname,
                  p_param1,
                  p_param2,
                  p_param3,
                  p_param4,
                  p_param5,
                  p_param6,
                  NULL,
                  NULL,
                  NULL,
                  NULL);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param6                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param7                IN importprotocollogparam.ipr_parameter%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_writelog (p_ipo_iph_id,
                  p_ipo_imh_id,
                  p_ipo_exceptionnumber,
                  p_ipo_fieldname,
                  p_param1,
                  p_param2,
                  p_param3,
                  p_param4,
                  p_param5,
                  p_param6,
                  p_param7,
                  NULL,
                  NULL,
                  NULL);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param6                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param7                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param8                IN importprotocollogparam.ipr_parameter%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_writelog (p_ipo_iph_id,
                  p_ipo_imh_id,
                  p_ipo_exceptionnumber,
                  p_ipo_fieldname,
                  p_param1,
                  p_param2,
                  p_param3,
                  p_param4,
                  p_param5,
                  p_param6,
                  p_param7,
                  p_param8,
                  NULL,
                  NULL);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param6                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param7                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param8                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param9                IN importprotocollogparam.ipr_parameter%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_writelog (p_ipo_iph_id,
                  p_ipo_imh_id,
                  p_ipo_exceptionnumber,
                  p_ipo_fieldname,
                  p_param1,
                  p_param2,
                  p_param3,
                  p_param4,
                  p_param5,
                  p_param6,
                  p_param7,
                  p_param8,
                  p_param9,
                  NULL);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param6                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param7                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param8                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param9                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param10               IN importprotocollogparam.ipr_parameter%TYPE)
   /*----------------------------------------------------------------*/
   IS
      l_ipo_id   importprotocollog.ipo_id%TYPE;
   BEGIN
      l_ipo_id := seq_importprotocollog.NEXTVAL;
      p_insert (l_ipo_id,
                p_ipo_iph_id,
                p_ipo_imh_id,
                p_ipo_exceptionnumber,
                p_ipo_fieldname);

      IF NOT gbl_usr_id_create IS NULL
      THEN
         pkg_importprotocollogparam.p_setwebuserinfo (gbl_usr_id_create);
      END IF;

      IF NOT p_param1 IS NULL
      THEN
         pkg_importprotocollogparam.p_insert (l_ipo_id, 1, p_param1);

         IF NOT p_param2 IS NULL
         THEN
            pkg_importprotocollogparam.p_insert (l_ipo_id, 2, p_param2);

            IF NOT p_param3 IS NULL
            THEN
               pkg_importprotocollogparam.p_insert (l_ipo_id, 3, p_param3);

               IF NOT p_param4 IS NULL
               THEN
                  pkg_importprotocollogparam.p_insert (l_ipo_id, 4, p_param4);

                  IF NOT p_param5 IS NULL
                  THEN
                     pkg_importprotocollogparam.p_insert (l_ipo_id,
                                                          5,
                                                          p_param5);

                     IF NOT p_param6 IS NULL
                     THEN
                        pkg_importprotocollogparam.p_insert (l_ipo_id,
                                                             6,
                                                             p_param6);

                        IF NOT p_param7 IS NULL
                        THEN
                           pkg_importprotocollogparam.p_insert (l_ipo_id,
                                                                7,
                                                                p_param7);

                           IF NOT p_param8 IS NULL
                           THEN
                              pkg_importprotocollogparam.p_insert (l_ipo_id,
                                                                   8,
                                                                   p_param8);

                              IF NOT p_param9 IS NULL
                              THEN
                                 pkg_importprotocollogparam.p_insert (
                                    l_ipo_id,
                                    9,
                                    p_param9);

                                 IF NOT p_param10 IS NULL
                                 THEN
                                    pkg_importprotocollogparam.p_insert (
                                       l_ipo_id,
                                       10,
                                       p_param10);
                                 END IF;
                              END IF;
                           END IF;
                        END IF;
                     END IF;
                  END IF;
               END IF;
            END IF;
         END IF;
      END IF;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_insert (
      p_ipo_id                IN importprotocollog.ipo_id%TYPE,
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      IF gbl_usr_id_create IS NULL
      THEN
         INSERT INTO importprotocollog (ipo_id,
                                        ipo_iph_id,
                                        ipo_imh_id,
                                        ipo_exceptionnumber,
                                        ipo_fieldname)
              VALUES (p_ipo_id,
                      p_ipo_iph_id,
                      p_ipo_imh_id,
                      p_ipo_exceptionnumber,
                      p_ipo_fieldname);
      ELSE
         INSERT INTO importprotocollog (ipo_id,
                                        ipo_iph_id,
                                        ipo_imh_id,
                                        ipo_exceptionnumber,
                                        ipo_fieldname,
                                        ipo_usr_id_create,
                                        ipo_usr_create_date)
              VALUES (p_ipo_id,
                      p_ipo_iph_id,
                      p_ipo_imh_id,
                      p_ipo_exceptionnumber,
                      p_ipo_fieldname,
                      gbl_usr_id_create,
                      SYSDATE);
      END IF;
   END;



   /*--------------------------------------------------------------------------------------------*/
   FUNCTION f_getcountseveritylevel (
      p_ipo_iph_id      IN importprotocollog.ipo_iph_id%TYPE,
      p_severitylevel   IN MESSAGE.msg_severity%TYPE)
      RETURN NUMBER
   /*-------------------------------------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM importprotocollog
             INNER JOIN MESSAGE ON ipo_exceptionnumber = msg_errornumber
             INNER JOIN language ON msg_lan_id = lan_id
       WHERE     p_ipo_iph_id = ipo_iph_id
             AND msg_severity = p_severitylevel
             AND lan_code = pkg_language.cst_lan_cde_francais;

      RETURN l_count;
   END;



   /*-------------------------------------------------------------------------------------------*/
   FUNCTION f_getmaxseveritylevel (
      p_ipo_iph_id   IN importprotocollog.ipo_iph_id%TYPE)
      RETURN VARCHAR
   /*-------------------------------------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      l_count :=
         f_getcountseveritylevel (p_ipo_iph_id,
                                  pkg_message.cst_severity_level_fatal);

      IF l_count > 0
      THEN
         RETURN pkg_message.cst_severity_level_fatal;
      END IF;

      l_count :=
         f_getcountseveritylevel (p_ipo_iph_id,
                                  pkg_message.cst_severity_level_error);

      IF l_count > 0
      THEN
         RETURN pkg_message.cst_severity_level_error;
      END IF;

      l_count :=
         f_getcountseveritylevel (p_ipo_iph_id,
                                  pkg_message.cst_severity_level_warning);

      IF l_count > 0
      THEN
         RETURN pkg_message.cst_severity_level_warning;
      END IF;

      RETURN pkg_message.cst_severity_level_info;
   END;


   /*----------------------------------------------------------------------------*/
   PROCEDURE p_test
   /*----------------------------------------------------------------------------*/
   IS
      l_line   VARCHAR2 (1024);                 -- Ligne contenant la fonction
   BEGIN
      l_line := 'f$codedesigation#1 ( SPEAR, MIDATINDICE  )12345 ';
      l_line := pkg_parsefunction.f_parseallfunction (l_line, 1);
      DBMS_OUTPUT.put_line ('l_line=' || l_line);
   END;

   /*-------------------------------------------------------------------------------------------*/
   FUNCTION f_buildmessage (
      p_ipo_id        IN importprotocollog.ipo_id%TYPE,
      p_errornumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_lan_id        IN language.lan_id%TYPE)
      RETURN VARCHAR2
   /*-------------------------------------------------------------------------------------------*/
   IS
      l_textmessage   VARCHAR2 (1024);

      CURSOR l_cursor
      IS
           SELECT ipr_parameter, ipr_sequence
             FROM importprotocollogparam
            WHERE ipr_ipo_id = p_ipo_id
         ORDER BY ipr_sequence;

      l_reccursor     l_cursor%ROWTYPE;
      l_severity      MESSAGE.msg_severity%TYPE;
      l_count         NUMBER := 0;
   BEGIN
      DBMS_OUTPUT.put_line ('p_errornumber:' || p_errornumber);
      l_textmessage :=
         pkg_message.f_returnmessagetext (p_errornumber, p_lan_id);
      DBMS_OUTPUT.put_line ('Message:' || l_textmessage);
      l_severity := pkg_message.f_returnmessageseverity (p_errornumber);

      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         DBMS_OUTPUT.put_line (
            ' l_reccursor.ipr_sequence:' || l_reccursor.ipr_sequence);
         pkg_message.p_setparameter (l_reccursor.ipr_parameter,
                                     l_reccursor.ipr_sequence);
      END LOOP;

      CLOSE l_cursor;

      l_textmessage := pkg_message.f_substituteparameter (l_textmessage);
      DBMS_OUTPUT.put_line ('Message:' || l_textmessage);
      -- On substitue aussi les fonctions
      l_textmessage :=
         pkg_midatparsefunction.f_parseallfunction (l_textmessage, p_lan_id);



      pkg_message.p_clearmessageparameter;
      RETURN l_textmessage;
   END;

   /*-----------------------------------------------------------------------------------------*/
   FUNCTION f_get_error_count (p_severity IN CHAR)
      RETURN VARCHAR2
   /*------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      IF p_severity != pkg_message.cst_severity_level_info
      THEN
         p_add_error_count (1);
         RETURN TO_CHAR (gbl_error_count) || '. ';
      ELSE
         RETURN NULL;
      END IF;
   END;

   PROCEDURE p_logunexpectederror (
      p_iph_id       IN importprotocolheader.iph_id%TYPE,
      p_fieldname    IN importprotocollog.ipo_fieldname%TYPE,
      p_modulename   IN VARCHAR2)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      pkg_importprotocollog.p_writelog (p_iph_id,
                                        NULL,
                                        pkg_exception.cst_unexpectederror,
                                        p_fieldname,
                                        p_modulename);
   END;

   /*-------------------------------------------------------------------------------------------*/
   PROCEDURE p_listerrorlog (
      p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id        IN     language.lan_id%TYPE,
      p_cursorerror      OUT t_cursor,
      p_errorlevel       OUT VARCHAR2)
   /*-------------------------------------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (1024);
   BEGIN
      p_reset_error_count;
      l_sql :=
            'select pkg_message.f_returnmessageseverity(ipo_exceptionnumber) severity, '
         || ' pkg_importprotocollog.f_buildmessage(ipo_id,ipo_exceptionnumber, '
         || TO_CHAR (p_lan_id)
         || ') message, ipo_fieldname, ipo_exceptionnumber '
         || ' from importprotocollog  where ipo_iph_id='
         || TO_CHAR (p_iph_id)
         || ' order by ipo_id';
      pkg_debug.p_write ('pkg_importprotocollog.p_listerrorlog', l_sql);
      p_errorlevel := f_getmaxseveritylevel (p_iph_id);

      OPEN p_cursorerror FOR l_sql;
   END;

   /*-----------------------------------------------------------------------------*/
   PROCEDURE p_purgebyimh_id (p_imh_id IN importprotocollog.ipo_imh_id%TYPE)
   /*------------------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importprotocollogparam
            WHERE ipr_ipo_id IN (SELECT ipo_id
                                   FROM importprotocollog
                                  WHERE ipo_imh_id = p_imh_id);

      DELETE FROM importprotocollog
            WHERE ipo_imh_id = p_imh_id;
   END;

   /*----------------------------------------------------------------------------*/
   PROCEDURE p_clearconditionnaly (
      p_ipo_iph_id   IN importprotocollog.ipo_iph_id%TYPE)
   /*-----------------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importprotocollogparam
            WHERE ipr_ipo_id IN
                     (SELECT ipo_id
                        FROM importprotocollog
                       WHERE     ipo_iph_id = p_ipo_iph_id
                             AND ipo_iph_id NOT IN
                                    (SELECT imh_iph_id
                                       FROM importmassdataheader)
                             AND ipo_iph_id NOT IN
                                    (SELECT ipl_iph_id
                                       FROM importprotocollabo)
                             AND ipo_iph_id NOT IN
                                    (SELECT ipg_iph_id
                                       FROM importprotocolgrid)
                             AND ipo_iph_id NOT IN
                                    (SELECT ipn_iph_id
                                       FROM importprotocolgrnd));


      DELETE FROM importprotocollog
            WHERE     ipo_iph_id = p_ipo_iph_id
                  AND ipo_iph_id NOT IN (SELECT imh_iph_id
                                           FROM importmassdataheader)
                  AND ipo_iph_id NOT IN (SELECT ipl_iph_id
                                           FROM importprotocollabo)
                  AND ipo_iph_id NOT IN (SELECT ipg_iph_id
                                           FROM importprotocolgrid)
                  AND ipo_iph_id NOT IN (SELECT ipn_iph_id
                                           FROM importprotocolgrnd);
   END;



   /*-----------------------------------------------------------------------------*/
   PROCEDURE p_purgebyiphidatlevel (
      p_ipo_iph_id   IN importprotocollog.ipo_iph_id%TYPE)
   /*-----------------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importprotocollogparam
            WHERE ipr_ipo_id IN (SELECT ipo_id
                                   FROM importprotocollog
                                  WHERE ipo_iph_id = p_ipo_iph_id);

      DELETE FROM importprotocollog
            WHERE ipo_iph_id = p_ipo_iph_id;
   END;

   /*----------------------------------------------------------------------------*/
   PROCEDURE p_deleteby_iph_id (
      p_iph_id   IN importprotocollog.ipo_iph_id%TYPE)
   /*----------------------------------------------------------------------------*/
   IS
   BEGIN
      p_purgebyiphidatlevel (p_iph_id);
   END;

   /*-----------------------------------------------------------------------*/
   PROCEDURE p_purgebyiphid (
      p_ipo_iph_id   IN importprotocollog.ipo_iph_id%TYPE)
   /*-----------------------------------------------------------------------------*/
   IS
      CURSOR l_cursorfils                                   -- Fils de l'iphid
      IS
         SELECT iph_id
           FROM importprotocolheader
          WHERE iph_iph_id = p_ipo_iph_id;

      l_reccursorfils   l_cursorfils%ROWTYPE;
   BEGIN
      OPEN l_cursorfils;

      LOOP
         FETCH l_cursorfils INTO l_reccursorfils;

         EXIT WHEN l_cursorfils%NOTFOUND;
         p_purgebyiphidatlevel (l_reccursorfils.iph_id);
      END LOOP;

      CLOSE l_cursorfils;

      p_purgebyiphidatlevel (p_ipo_iph_id);
   END;
END pkg_importprotocollog;
/

