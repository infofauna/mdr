create PACKAGE       pkg_managejob
AS
   /******************************************************************************
      NAME:       PKG_MANAGEJOB
      PURPOSE:    Planification des job

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        26.02.2012  F.Burri          1. Created this package.
   ******************************************************************************/
   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_createpurgejob;

   PROCEDURE p_droppurgejob;

   PROCEDURE p_purgejob;
END pkg_managejob;
/

