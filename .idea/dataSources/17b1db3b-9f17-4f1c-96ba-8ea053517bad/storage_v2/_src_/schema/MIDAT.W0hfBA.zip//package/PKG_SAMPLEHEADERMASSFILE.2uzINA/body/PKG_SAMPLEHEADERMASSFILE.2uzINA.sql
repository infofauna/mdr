create PACKAGE BODY       pkg_sampleheadermassfile
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEHEADERMASSFILE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
      1.1        24.10.2017      burrif       2. Version 2 de MIDAT
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.1, octobre  2017' ;


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;


   /*--------------------------------------------------------------*/
   FUNCTION f_getrecord (p_smf_id IN sampleheadermassfile.smf_id%TYPE)
      RETURN sampleheadermassfile%ROWTYPE
   /*--------------------------------------------------------------*/
   IS
      l_record   sampleheadermassfile%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM sampleheadermassfile
       WHERE smf_id = p_smf_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*---------------------------------------------------------------------*/
   PROCEDURE p_write (
      p_ptv_id      IN     sampleheadermassfile.smf_ptv_id%TYPE,
      p_lan_id      IN     sampleheadermassfile.smf_lan_id%TYPE,
      p_file        IN     sampleheadermassfile.smf_file%TYPE,
      p_filename    IN     sampleheadermassfile.smf_filename%TYPE,
      p_sheetname   IN     sampleheadermassfile.smf_sheetname%TYPE,
      p_usr_id      IN     sampleheadermassfile.smf_usr_id_create%TYPE,
      p_smf_id         OUT sampleheadermassfile.smf_id%TYPE)
   /*---------------------------------------------------------------------*/
   IS
      l_smf_id   sampleheadermassfile.smf_id%TYPE;
   BEGIN
      l_smf_id := seq_sampleheadermassfile.NEXTVAL;

      INSERT INTO sampleheadermassfile (smf_id,
                                        smf_ptv_id,
                                        smf_lan_id,
                                        smf_file,
                                        smf_filename,
                                        smf_sheetname,
                                        smf_usr_id_create,
                                        smf_usr_create_date)
           VALUES (l_smf_id,
                   p_ptv_id,
                   p_lan_id,
                   p_file,
                   p_filename,
                   p_sheetname,
                   p_usr_id,
                   SYSDATE);

      p_smf_id := l_smf_id;
   END;

   /*--------------------------------------------------------------------------------------*/
   PROCEDURE p_delete (p_smf_id IN sampleheadermassfile.smf_id%TYPE)
   /*--------------------------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleheadermassfile
            WHERE smf_id = p_smf_id;
   END;

   /*--------------------------------------------------------------------------------------*/
   PROCEDURE p_deleteconditional (
      p_smf_id   IN sampleheadermassfile.smf_id%TYPE)
   /*--------------------------------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      l_count := pkg_sampleheader.f_getcountbysmfid (p_smf_id);

      IF l_count > 0
      THEN
         RETURN;
      END IF;

      DELETE FROM sampleheadermassfile
            WHERE smf_id = p_smf_id;
   END;
END pkg_sampleheadermassfile;
/

