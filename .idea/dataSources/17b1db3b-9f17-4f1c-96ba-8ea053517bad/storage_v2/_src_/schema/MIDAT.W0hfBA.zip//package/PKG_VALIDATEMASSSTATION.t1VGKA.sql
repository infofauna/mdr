create PACKAGE       pkg_validatemassstation
AS
   /******************************************************************************
      NAME:       pkg_validatemassstation
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
         1.0        19.05.2014      burrif       1. Created this package.
         2.0        27.07.2017      burrif       2. MIDAT version 2
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;
   PROCEDURE p_test1;
   PROCEDURE p_test;

   PROCEDURE p_main (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER);
END pkg_validatemassstation;
/

