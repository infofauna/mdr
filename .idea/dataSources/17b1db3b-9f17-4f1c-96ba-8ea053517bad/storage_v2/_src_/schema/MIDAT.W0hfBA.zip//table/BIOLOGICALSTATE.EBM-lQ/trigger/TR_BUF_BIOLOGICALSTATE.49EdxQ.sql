create trigger TR_BUF_BIOLOGICALSTATE
    before update
    on BIOLOGICALSTATE
    for each row
DECLARE
BEGIN
 
   :new.bls_moddate := SYSDATE;
   :new.bls_moduser := USER;
END tr_buf_BIOLOGICALSTATE;

/

