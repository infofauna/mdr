create PACKAGE       pkg_mkiidentifygroupcounter
AS
   /******************************************************************************
      NAME:       PKG_MKIIDENTIFYGROUPCOUNTER
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        23.02.2015      burrif       1. Created this package.
   ******************************************************************************/
   TYPE rec_mkicounter IS RECORD
   (
      l_taxonname   mkiidentifygroupcounter.mig_taxonname%TYPE,
      l_counter     NUMBER,
      l_isinsecta   CHAR (1),
      l_crf_id      codereference.crf_id%TYPE
   );

   TYPE t_listmkicounter IS TABLE OF rec_mkicounter
      INDEX BY PLS_INTEGER;


   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecordbysyvid (
      p_syv_id   IN mkiidentifygroupcounter.mig_syv_id%TYPE)
      RETURN mkiidentifygroupcounter%ROWTYPE;

   PROCEDURE p_loadmkiidentifylist (l_listmkicounter IN OUT t_listmkicounter);

   PROCEDURE p_insert (
      p_syv_id             IN     mkiidentifygroupcounter.mig_syv_id%TYPE,
      p_crf_id             IN     mkiidentifygroupcounter.mig_crf_id%TYPE,
      p_crf_id_leveltrap   IN     mkiidentifygroupcounter.mig_crf_id_level_trap%TYPE,
      p_taxonname          IN     mkiidentifygroupcounter.mig_taxonname%TYPE,
      p_searchorder        IN     mkiidentifygroupcounter.mig_searchorder%TYPE,
      p_id                    OUT mkiidentifygroupcounter.mig_id%TYPE);
END pkg_mkiidentifygroupcounter;
/

