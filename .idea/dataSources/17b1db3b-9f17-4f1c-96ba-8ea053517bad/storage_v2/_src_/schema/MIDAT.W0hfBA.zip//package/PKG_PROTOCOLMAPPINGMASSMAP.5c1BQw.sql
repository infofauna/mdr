create PACKAGE       pkg_protocolmappingmassmap
AS
   /******************************************************************************
      NAME:       pkg_protocolmappingmassmap
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_checkexistmapping (
      p_lan_id         IN     protocolmappingmassmap.pma_lan_id%TYPE,
      p_ptv_id         IN     protocolmappingmassfield.pmm_ptv_id%TYPE,
      p_returnstatus      OUT NUMBER);

   FUNCTION f_getrecordbypmm_id (
      p_lan_id   IN protocolmappingmassmap.pma_lan_id%TYPE,
      p_pmm_id   IN protocolmappingmassmap.pma_pmm_id%TYPE)
      RETURN protocolmappingmassmap%ROWTYPE;

   PROCEDURE p_writeifnotexist (
      p_lan_id       IN protocolmappingmassmap.pma_lan_id%TYPE,
      p_pmm_id       IN protocolmappingmassmap.pma_pmm_id%TYPE,
      p_columnname   IN protocolmappingmassmap.pma_aliascolumnname%TYPE);

   PROCEDURE p_write (
      p_lan_id       IN protocolmappingmassmap.pma_lan_id%TYPE,
      p_pmm_id       IN protocolmappingmassmap.pma_pmm_id%TYPE,
      p_columnname   IN protocolmappingmassmap.pma_aliascolumnname%TYPE);
      
       FUNCTION f_getrecordbymidatfldcmt (
      p_ptv_id        IN protocolmappingmassfield.pmm_ptv_id%TYPE,
      p_lan_id        IN protocolmappingmassmap.pma_lan_id%TYPE,
      p_midatfldcmt   IN protocolmappingmassfield.pmm_code_midatfldcmt%TYPE)
      RETURN protocolmappingmassmap%ROWTYPE;
END pkg_protocolmappingmassmap;
/

