create trigger TR_BIF_PROTOCOLMAPPINGLABO
    before insert
    on PROTOCOLMAPPINGLABO
    for each row
DECLARE
BEGIN
   IF :new.PTL_id IS NULL
   THEN
      :new.PTL_id := seq_PROTOCOLMAPPINGLABO.NEXTVAL;
   END IF;

   :new.PTL_credate := SYSDATE;
   :new.PTL_creuser := USER;
END tr_bif_PROTOCOLMAPPINGLABO;

/

