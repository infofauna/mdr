create PACKAGE BODY       pkg_migr_protocolmappinglabo
AS
   /******************************************************************************
      NAME:       pkg_migr_protocolmappinglabo
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;

   /* Protocole labo version 1 = ptv_id=5
                              version 2 =ptv_id=1
   */
   cst_ptv_id_v1        CONSTANT protocolversion.ptv_id%TYPE := 5;
   cst_ptv_id_v2        CONSTANT protocolversion.ptv_id%TYPE := 1;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_build_version_v1
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
      p_build_version1_2 (cst_ptv_id_v1);
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_build_version_v2
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
      p_build_version1_2 (cst_ptv_id_v2);
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_build_syv_id_v1
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_build_syv_id_version_1_2 (cst_ptv_id_v1);
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_build_syv_id_v2
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      p_build_syv_id_version_1_2 (cst_ptv_id_v2);
   END;


   /*------------------------------------------------------------------*/
   PROCEDURE p_clearsyv_id
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE protocolmappinglabo
         SET ptl_syv_id = NULL;
   END;



   /*------------------------------------------------------------------*/
   PROCEDURE p_buildspearindexfactor_v1_2 (
      p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
   /*------------------------------------------------------------------*/
   IS
      CURSOR l_protocolmapping
      IS
         SELECT *
           FROM protocolmappinglabo
          WHERE ptl_ptv_id = p_ptv_id AND NOT ptl_syv_id IS NULL
         FOR UPDATE;

      l_recprotocolmapping     l_protocolmapping%ROWTYPE;
      l_recspeardatalinkcscf   speardatalinkcscf%ROWTYPE;
      l_spearindice            speardatalinkcscf.sdf_spearindex%TYPE;
   BEGIN
      UPDATE protocolmappinglabo
         SET ptl_spearindexfactor = NULL
       WHERE ptl_ptv_id = p_ptv_id;

      OPEN l_protocolmapping;

      LOOP
         FETCH l_protocolmapping INTO l_recprotocolmapping;

         EXIT WHEN l_protocolmapping%NOTFOUND;
         l_spearindice :=
            pkg_speardatalinkcscf.f_routereturnspearindex (
               l_recprotocolmapping.ptl_syv_id);

         IF l_spearindice IS NULL
         THEN
            pkg_debug.p_write (
               'PKG_MIGR_PROTOCOLMAPPINGLABO.p_buildspearindexfactor_v1',
                  'Valeur syv_id:='
               || l_recprotocolmapping.ptl_syv_id
               || ' non trouvé');
         ELSE
            UPDATE protocolmappinglabo
               SET ptl_spearindexfactor = l_spearindice
             WHERE CURRENT OF l_protocolmapping;
         END IF;
      END LOOP;

      CLOSE l_protocolmapping;

      UPDATE protocolmappinglabo
         SET ptl_spearindexfactor =
                pkg_protocolmappinglabo.cst_spearindexfactor_noset
       WHERE ptl_spearindexfactor IS NULL;

      NULL;
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_buildspearindexfactor_v1
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
      p_buildspearindexfactor_v1_2 (cst_ptv_id_v1);
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_buildspearindexfactor_v2
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
      p_buildspearindexfactor_v1_2 (cst_ptv_id_v2);
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_buildall_v1
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
   
      p_build_version_v1;
      p_build_syv_id_v1;
      p_buildspearindexfactor_v1;
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_buildall_v1_v2
   /*-------------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (255);
   BEGIN
      DELETE FROM protocolmappinglabo;

      l_sql := 'DROP SEQUENCE SEQ_PROTOCOLMAPPINGLABO';

      EXECUTE IMMEDIATE l_sql;

      l_sql := 'CREATE SEQUENCE SEQ_PROTOCOLMAPPINGLABO';

      EXECUTE IMMEDIATE l_sql;


      pkg_speardatalinkcscf.p_build; -- Rebuild (truncate, build) la table SPEARDATALINKCSCF à partir de la table WK_LOADSPEARDATACSCF
      p_build_version_v1;
      p_build_syv_id_v1;
      p_buildspearindexfactor_v1;
      p_build_version_v2;
      p_build_syv_id_v2;
      p_buildspearindexfactor_v2;
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_build_syv_id_version_1_2 (
      p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
   /*------------------------------------------------------------------*/
   IS
      CURSOR l_protocolmapping
      IS
         SELECT *
           FROM protocolmappinglabo
          WHERE ptl_ptv_id = p_ptv_id
         FOR UPDATE;

      l_recprotocolmapping   l_protocolmapping%ROWTYPE;
      l_recsystdesignation   systdesignation%ROWTYPE;
      l_reccodereference     codereference%ROWTYPE;
   BEGIN
      UPDATE protocolmappinglabo
         SET ptl_syv_id = NULL
       WHERE ptl_ptv_id = p_ptv_id;

      OPEN l_protocolmapping;

      LOOP
         FETCH l_protocolmapping INTO l_recprotocolmapping;

         EXIT WHEN l_protocolmapping%NOTFOUND;

         IF l_recprotocolmapping.ptl_crf_id_level IS NULL
         THEN
            l_recsystdesignation :=
               pkg_systdesignation.f_getrecordbydesignationcode (
                  l_recprotocolmapping.ptl_taxa,
                  pkg_language.cst_lan_cde_latin);

            IF l_recsystdesignation.syd_id IS NULL
            THEN
               IF NOT l_recprotocolmapping.ptl_taxacscf IS NULL
               THEN
                  l_recsystdesignation :=
                     pkg_systdesignation.f_getrecordbydesignationcode (
                        l_recprotocolmapping.ptl_taxacscf,
                        pkg_language.cst_lan_cde_latin);
               END IF;
            END IF;
         ELSE
            l_reccodereference :=
               pkg_codereference.f_getrecord (
                  l_recprotocolmapping.ptl_crf_id_level);
            l_recsystdesignation :=
               pkg_systdesignation.f_getrecordbydesignation (
                  l_recprotocolmapping.ptl_taxa,
                  pkg_language.cst_lan_cde_latin,
                  l_reccodereference.crf_code);

            IF l_recsystdesignation.syd_id IS NULL
            THEN
               IF NOT l_recprotocolmapping.ptl_taxacscf IS NULL
               THEN
                  l_recsystdesignation :=
                     pkg_systdesignation.f_getrecordbydesignation (
                        l_recprotocolmapping.ptl_taxacscf,
                        pkg_language.cst_lan_cde_latin,
                        l_reccodereference.crf_code);
               END IF;
            END IF;
         END IF;



         IF l_recsystdesignation.syd_id IS NULL
         THEN
            DBMS_OUTPUT.put_line (
               'Not found: ' || l_recprotocolmapping.ptl_taxa);
         ELSE
            -- DBMS_OUTPUT.put_line ('Found: ' || l_recprotocolmapping.ptl_taxa);
            UPDATE protocolmappinglabo
               SET ptl_syv_id = l_recsystdesignation.syd_syv_id
             WHERE CURRENT OF l_protocolmapping;
         END IF;
      END LOOP;

      CLOSE l_protocolmapping;
   END;



   /*------------------------------------------------------------------*/
   PROCEDURE p_deleteall
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      -- DELETE FROM protocolmappinglabo;
      NULL;
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_build_version1_2 (
      p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
      l_ptl_id                 protocolmappinglabo.ptl_id%TYPE;
      l_ptl_id_parent          protocolmappinglabo.ptl_id%TYPE;
      l_ptl_id_parent_root     protocolmappinglabo.ptl_id%TYPE;
      l_ptl_id_parent_root_1   protocolmappinglabo.ptl_id%TYPE;
   BEGIN
      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       9,                   /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'PORIFERA',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       10,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'CNIDARIA',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       11,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'BRYOZOA',               /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,                /* cellrowvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'PLATYHELMINTHES',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       14,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Dendrocoelidae',        /* ptl_taxa */
                                       NULL,              /* p_crf_id_level */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       15,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Dugesiidae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       16,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Planariidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);


      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       17,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'NEMATHELMINTHES',       /* ptl_taxa */
                                       'Nematoda',          /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'ANNELIDA',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent_root := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root,  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Hirudinea',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;
      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       21,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Erpobdellidae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       22,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Glossiphoniidae',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       23,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Hirudidae (Tachet)',    /* ptl_taxa */
                                       'Hirudinidae',       /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       1,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       24,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Piscicolidae',          /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root,  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       26,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Oligochaeta',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       1,          /* ptl_ibchfaunagroup_gi */
                                       10,            /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
/* Tous les MOLLUSCA sont 2 */
      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'MOLLUSCA',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent_root := l_ptl_id;
      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root,  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Gastropoda',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;



      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       30,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Acroloxidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       31,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Ancylidae (Tachet)',    /* ptl_taxa */
                                       'Ancylus',           /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       32,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Bithyniidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       33,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Ferrissiidae (Tachet)', /* ptl_taxa */
                                       'Ferrissia',         /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       34,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Hydrobiidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       35,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Lymnaeidae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       36,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Neritidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       37,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Physidae',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       38,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Planorbidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       39,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Valvatidae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       40,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Viviparidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root,  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Bivalvia',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       42,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Corbiculidae',          /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       43,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Dreissenidae',          /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       44,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Sphaeriidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       45,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Unionidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'ARTHROPODA',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent_root := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root,  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Arachnida (Inf.Cl.) Acari', /* ptl_taxa */
                                       'Arachnida',         /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       49,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Hydracarina',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);



      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root,  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Malcostraca (Crustacea)', /* ptl_taxa */
                                       'Malacostraca',      /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent_root_1 := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root_1, /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       51,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Branchiopoda',          /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);


      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root_1, /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Amphipoda',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;



      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       53,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Corophiidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       54,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Gammaridae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       10,            /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       55,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Niphargidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);


      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root_1, /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Isopoda',               /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;
      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       57,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Asellidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       1,          /* ptl_ibchfaunagroup_gi */
                                       10,            /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       58,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Janiridae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root_1, /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Mysida',                /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       60,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Mysidae',               /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root_1, /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Decapoda',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       62,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Astacidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       63,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Cambaridae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);



      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Insecta',               /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       5,          /* p_crf_id_level =classe*/
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent_root := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root,  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Ephemeroptera',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       66,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Ameletidae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       67,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Baetidae',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       10,            /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       68,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Caenidae',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       10,            /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       69,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Ephemerellidae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       3,          /* ptl_ibchfaunagroup_gi */
                                       10,            /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       70,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Ephemeridae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       6,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       71,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Heptageniidae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       5,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       72,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Leptophlebiidae',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       7,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       73,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Oligoneuriidae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       74,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Polymitarcyidae',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       5,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       75,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Potamanthidae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       5,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       76,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Siphlonuridae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);



      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root,  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Odonata',               /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;



      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       78,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Aeshnidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       79,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Calopterygidae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       80,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Coenagrionidae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       81,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Cordulegasteridae',     /* ptl_taxa */
                                       'Cordulegastridae',  /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       82,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Corduliidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       83,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Gomphidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       84,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Lestidae',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       85,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Libellulidae',          /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       86,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Platycnemididae',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent_root,  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Plecoptera',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;
      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       88,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Capniidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       8,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       89,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Chloroperlidae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       9,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       90,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Leuctridae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       7,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       91,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Nemouridae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       6,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       92,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Perlidae',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       9,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       93,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Perlodidae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       9,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       94,                  /* cellrowvalue */
                                       'E',              /* cellcolumnvalue */
                                       'Taeniopterygidae',      /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       9,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Heteroptera',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;



      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       10,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Aphelocheiridae',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       3,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       11,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Corixidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       12,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Gerridae',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,          /* ptl_ibchfaunagroup_gi */
                                       NULL,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       13,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Hebridae',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       14,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Hydrometridae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       15,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Mesoveliidae',          /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       16,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Naucoridae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       17,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Nepidae',               /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       18,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Notonectidae',          /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       19,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Pleidae',               /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       20,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Veliidae',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);


      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Megaloptera',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       22,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Sialidae',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Neuroptera',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;



      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       24,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Osmylidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       25,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Sisyridae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Coleoptera',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;



      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       27,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Curculionidae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       28,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Chrysomelidae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       29,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Dryopidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       30,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Dytiscidae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       31,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Elmidae',               /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       2,          /* ptl_ibchfaunagroup_gi */
                                       10,            /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       32,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Gyrinidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       33,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Haliplidae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       34,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Helophoridae',          /* ptl_taxa */
                                       'Helophoridae (nae)', /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       35,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Hydraenidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       36,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Hydrochidae',           /* ptl_taxa */
                                       'Hydrochidae (nae)', /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       37,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Hydrophilidae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       38,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Hydroscaphidae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       39,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Hygrobiidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       40,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Noteridae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       41,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Psephenidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       42,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Scirtidae (=Helodidae)', /* ptl_taxa */
                                       'Scirtidae',         /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       43,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Spercheidae',           /* ptl_taxa */
                                       'Spercheidae (nae)', /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);



      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       45,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Hymenoptera',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Trichoptera',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      l_ptl_id_parent := l_ptl_id;


      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       47,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Apataniidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       48,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Beraeidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       7,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       49,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Brachycentridae',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       8,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       50,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Ecnomidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       51,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Glossosomatidae',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       7,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       52,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Goeridae',              /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       7,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       53,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Helicopsychidae',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       54,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Hydropsychidae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       3,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       55,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Hydroptilidae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       5,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       56,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Lepidostomatidae',      /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       6,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       57,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Leptoceridae',          /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       4,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       58,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Limnephilidae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       3,          /* ptl_ibchfaunagroup_gi */
                                       10,            /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       59,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Molannidae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       60,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Odontoceridae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       8,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       61,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Philopotamidae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       8,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       62,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Phryganeidae',          /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       63,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Polycentropodidae',     /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       4,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       64,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Psychomyiidae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       4,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       65,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Ptilocolepidae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       66,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Rhyacophilidae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       4,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       67,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Sericostomatidae',      /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       6,          /* ptl_ibchfaunagroup_gi */
                                       3,             /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       118,              /* cellcolumnvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Lepidoptera',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (NULL,                  /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       NULL,             /* cellcolumnvalue */
                                       NULL,             /* cellcolumnvalue */
                                       'Diptera',               /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       9,          /* p_crf_id_level  =Ordre*/
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
      l_ptl_id_parent := l_ptl_id;

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       71,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Anthomyiidae/Muscidae', /* ptl_taxa */
                                       'Anthomyiidae',      /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       72,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Athericidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       73,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Blephariceridae',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       74,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Ceratopogonidae',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       75,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Chaoboridae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       76,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Chironomidae',          /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       1,          /* ptl_ibchfaunagroup_gi */
                                       10,            /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       77,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Culicidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       78,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Cylindrotomidae',       /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       79,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Dixidae',               /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       80,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Dolichopodidae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       81,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Empididae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       82,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Ephydridae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       83,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Limoniidae/Pedicidae',  /* ptl_taxa */
                                       'Limoniidae',        /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       84,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Psychodidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       85,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Ptychopteridae',        /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       86,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Rhagionidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       87,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Scatophagidae',         /* ptl_taxa */
                                       'Scathophagidae',    /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       88,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Sciomyzidae',           /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       89,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Simuliidae',            /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       90,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Stratiomyidae',         /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       91,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Syrphidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       92,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Tabanidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       93,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Thaumaleidae',          /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);

      pkg_protocolmappinglabo.p_write (l_ptl_id_parent,       /* ptl_ptl_id */
                                       p_ptv_id,              /* ptl_ptv_id */
                                       NULL,                  /* ptl_syv_id */
                                       94,                  /* cellrowvalue */
                                       'V',              /* cellcolumnvalue */
                                       'Tipulidae',             /* ptl_taxa */
                                       NULL,                /* ptl_taxacscf */
                                       NULL,              /* p_crf_id_level */
                                       NULL,       /* ptl_ibchfaunagroup_gi */
                                       NULL,          /*ptl_ibchindividumin */
                                       NULL,        /* ptl_spearindexfactor */
                                       NULL,               /* ptl_isnotnull */
                                       NULL,          /* ptl_isnotnullgroup */
                                       l_ptl_id);
   END;
END pkg_migr_protocolmappinglabo;
/

