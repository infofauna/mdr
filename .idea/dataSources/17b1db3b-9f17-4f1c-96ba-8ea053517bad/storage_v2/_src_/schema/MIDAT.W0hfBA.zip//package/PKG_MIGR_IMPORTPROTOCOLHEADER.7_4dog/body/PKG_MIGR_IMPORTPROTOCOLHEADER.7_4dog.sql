create PACKAGE BODY       pkg_migr_importprotocolheader
AS
   /******************************************************************************
      NAME:       pkg_migr_importprotocolheader
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

/*--------------------------------------------------------------------*/
PROCEDURE P_Insertdatatest
/*--------------------------------------------------------------------*/
IS
BEGIN
 NULL;
END;

   /*------------------------------------------------------------------*/
   PROCEDURE p_deleteall
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM importprotocolheader;
   END;

  
END pkg_migr_importprotocolheader;
/

