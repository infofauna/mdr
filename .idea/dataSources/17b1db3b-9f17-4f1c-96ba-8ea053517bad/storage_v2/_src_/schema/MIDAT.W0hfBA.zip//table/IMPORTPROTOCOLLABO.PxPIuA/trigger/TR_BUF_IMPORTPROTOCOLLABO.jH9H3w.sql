create trigger TR_BUF_IMPORTPROTOCOLLABO
    before update
    on IMPORTPROTOCOLLABO
    for each row
DECLARE
BEGIN
 
   :new.IPL_moddate := SYSDATE;
   :new.IPL_moduser := USER;
END tr_buf_IMPORTPROTOCOLLABO;

/

