create PACKAGE BODY       pkg_validatew
AS
   /******************************************************************************
      NAME:       PKG_VALIDATE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;


   /*------------------------------------------------------------*/
   PROCEDURE p_validateprocess (
      p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id        IN     language.lan_id%TYPE,
      p_usr_id        IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_cursorerror      OUT pkg_importprotocollog.t_cursor,
      p_errorlevel       OUT VARCHAR2)
   /*-------------------------------------------------------------*/
   IS
      l_fieldname   VARCHAR2 (128);
      l_number      NUMBER;
   BEGIN
      pkg_debug.p_write (
         'PKG_VALIDATEW.P_VALIDATEPROCESS',
            'p_iph_id='
         || p_iph_id
         || 'p_lan_id='
         || p_lan_id
         || 'p_usr_id='
         || p_usr_id);

      pkg_validate.p_validateprocess (p_iph_id,
                                      p_lan_id,
                                      p_usr_id,
                                      p_cursorerror,
                                      p_errorlevel);
   END;


   /*------------------------------------------------------------*/
   PROCEDURE p_validateprocess (
      p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id        IN     language.lan_id%TYPE,
      p_usr_id        IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_external_id   IN     importprotocolheader.iph_external_id%TYPE,
      p_cursorerror      OUT pkg_importprotocollog.t_cursor,
      p_errorlevel       OUT VARCHAR2)
   /*-------------------------------------------------------------*/
   IS
      l_message     VARCHAR2 (4096);
      l_fieldname   VARCHAR2 (128);
      l_number      NUMBER;
      l_severity    MESSAGE.msg_severity%TYPE;
   BEGIN
      pkg_debug.p_write (
         'PKG_VALIDATEW.P_VALIDATEPROCESS',
            'p_iph_id='
         || p_iph_id
         || 'p_lan_id='
         || p_lan_id
         || 'p_usr_id='
         || p_usr_id);

      pkg_validate.p_validateprocess (p_iph_id,
                                      p_lan_id,
                                      p_usr_id,
                                      p_external_id,
                                      p_cursorerror,
                                      p_errorlevel);
   /*
      pkg_debug.p_write ('PKG_VALIDATEW.P_VALIDATEPROCESS', 'Errolevel'||p_errorlevel);
      LOOP
         FETCH p_cursorerror
            INTO l_severity, l_message, l_fieldname, l_number;

         EXIT WHEN p_cursorerror%NOTFOUND;
         DBMS_OUTPUT.put_line ('Message 1' || l_message);
         pkg_debug.p_write ('PKG_VALIDATEW.P_VALIDATEPROCESS', l_message);
      END LOOP;
      */
   END;

   /*------------------------------------------------------------*/
   PROCEDURE p_validateprocess_v2 (
      p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id        IN     language.lan_id%TYPE,
      p_usr_id        IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_pid_id        IN     importprotocolheader.iph_pid_id%TYPE,
      p_cursorerror      OUT pkg_importprotocollog.t_cursor,
      p_errorlevel       OUT VARCHAR2)
   /*-------------------------------------------------------------*/
   IS
      l_message     VARCHAR2 (4096);
      l_fieldname   VARCHAR2 (128);
      l_number      NUMBER;
      l_severity    MESSAGE.msg_severity%TYPE;
   /* Version utilisé' */
   BEGIN
      pkg_validate.p_validateprocess_v2 (p_iph_id,
                                         p_lan_id,
                                         p_usr_id,
                                         p_pid_id,
                                         p_cursorerror,
                                         p_errorlevel);
   END;

   /*-------------------------------------------------------------------------------------------------*/
   PROCEDURE p_validateconfirm (
      p_iph_id   IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id   IN     language.lan_id%TYPE,
      p_usr_id   IN     sampleheader.sph_usr_id_create%TYPE,
      p_sph_id      OUT sampleheader.sph_id%TYPE)
   /*-------------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      pkg_validate.p_validateconfirm (p_iph_id,
                                      p_lan_id,
                                      p_usr_id,
                                      p_sph_id);
   END;

   /*-------------------------------------------------------------------------------------------------*/
   PROCEDURE p_validateconfirm (
      p_iph_id             IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id             IN     language.lan_id%TYPE,
      p_usr_id             IN     sampleheader.sph_usr_id_create%TYPE,
      p_visibilitystatus   IN     sampleheader.sph_visibilitystatus%TYPE,
      p_publicstatus       IN     VARCHAR2,
      p_sph_id                OUT sampleheader.sph_id%TYPE)
   /*-------------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      pkg_validate.p_validateconfirm (p_iph_id,
                                      p_lan_id,
                                      p_usr_id,
                                      p_visibilitystatus,
                                      p_publicstatus,
                                      p_sph_id);
   END;

   /*-------------------------------------------------------------------------------------------------*/
   PROCEDURE p_initprocessingstatus (
      p_external_id   IN importprotocolheader.iph_external_id%TYPE)
   /*-------------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      pkg_validate.p_initprocessingstatus (p_external_id);
   END;

   /*-------------------------------------------------------------------------------------------------*/
   PROCEDURE p_initprocessingstatus (
      p_external_id   IN     importprotocolheader.iph_external_id%TYPE,
      p_pid_id           OUT processingstatus.pid_id%TYPE)
   /*-------------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      pkg_validate.p_initprocessingstatus (p_external_id, p_pid_id);
   END;

   /*-------------------------------------------------------------------------------------------------*/
   PROCEDURE p_initprocessingstatus_v2 (
      p_pid_id   OUT processingstatus.pid_id%TYPE)
   /*-------------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      pkg_validate.p_initprocessingstatus_v2 (p_pid_id);
   END;
END pkg_validatew;
/

