create PACKAGE BODY       pkg_ibch2019
AS
    /******************************************************************************
       NAME:       PKG_IBCH2019
       PURPOSE:    Calcul de l'indice IBCH2019

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    TYPE t_listfrequence IS TABLE OF importprotocollabo.ipl_value%TYPE
        INDEX BY PLS_INTEGER;

    TYPE t_recfrequencesorted IS RECORD
    (
        l_value     NUMBER,
        l_ptl_id    PLS_INTEGER
    );

    TYPE t_listfrequencesorted IS TABLE OF t_recfrequencesorted
        INDEX BY PLS_INTEGER;

    TYPE t_listgi IS TABLE OF NUMBER
        INDEX BY PLS_INTEGER;


    cst_gi_factor1                  CONSTANT NUMBER := -0.1392405;
    cst_gi_factor2                  CONSTANT NUMBER := 0.1392405;

    cst_classvariete_factor1        CONSTANT NUMBER := -0.08527134;
    cst_classvariete_factor2        CONSTANT NUMBER := 0.08527134;

    cst_ibch_gi_factor              CONSTANT NUMBER := 0.38;
    cst_ibch_classevariete_factor   CONSTANT NUMBER := 0.62;

    cst_plecoptera                  CONSTANT protocolmappinglabo.ptl_taxa%TYPE
        := 'Plecoptera' ;
    cst_ephemeroptera               CONSTANT protocolmappinglabo.ptl_taxa%TYPE
        := 'Ephemeroptera' ;
    cst_trichoptera                 CONSTANT protocolmappinglabo.ptl_taxa%TYPE
        := 'Trichoptera' ;

    gbl_listfrequence                        t_listfrequence; -- Données fournies + hiérarchie
    gbl_listentry                            t_listfrequence; -- Seulement les données fournies

    gbl_listfrequencesorted                  t_listfrequencesorted; -- Donnéées fournies + hiérarchie trié par frequence
    gbl_taxonlisttaxonindicator              VARCHAR2 (4096);
    gbl_listgi                               t_listgi;
    gbl_taxonfrequencesum                    NUMBER;

    gbl_gimax                                NUMBER;
    gbl_gimaxrobust                          NUMBER;
    gbl_sumfamily                            NUMBER;
    gbl_sumfamilycorrected                   NUMBER;
    gbl_sumfamilyrobust                      NUMBER;
    gbl_sumfamilyrobustcorrected             NUMBER;

    gbl_gi_final                             NUMBER;
    gbl_girobust_final                       NUMBER;
    gbl_classevariete_final                  NUMBER;
    gbl_classevarieterobust_final            NUMBER;

    /* Classe de variété: = Nombre de taxon distinct */
    gbl_classevariete                        NUMBER;
    gbl_classevariete_corr                   NUMBER;
    gbl_classevariete_robust                 NUMBER;
    gbl_classevariete_robust_corr            NUMBER;

    gbl_plecopteracounter                    NUMBER := 0;
    gbl_ephemeropteracounter                 NUMBER := 0;
    gbl_trichopteracounter                   NUMBER := 0;


    gbl_ibch_q                               NUMBER := NULL;
    gbl_correctionfactor                     NUMBER := 0;

    gbl_ibch                                 NUMBER;
    gbl_ibchrobust                           NUMBER;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;



    /*---------------------------------------------------------------*/
    FUNCTION f_getibch
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_ibch;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getibchrobust
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_ibchrobust;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getclassevariete_final
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_classevariete_final;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getclassevarieterobust_final
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_classevarieterobust_final;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getclassevariete
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_classevariete;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getclassevariete_corr
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_classevariete_corr;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getclassevarieterobust
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_classevariete_robust;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getclassevarieterobust_corr
        RETURN NUMBER
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_classevariete_robust_corr;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_getsumfamilyrobust
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_sumfamilyrobust;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_getsumfamilyrobustcorrected
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_sumfamilyrobustcorrected;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_getsumfamilycorrected
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_sumfamilycorrected;
    END;



    /*------------------------------------------------------------------*/
    FUNCTION f_getsumfamily
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_sumfamily;
    END;



    /*------------------------------------------------------------------*/
    FUNCTION f_gettaxonfrequencesum
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_taxonfrequencesum;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_getgimax
        RETURN NUMBER
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_gimax;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_getgimaxrobust
        RETURN NUMBER
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_gimaxrobust;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_getgi_final
        RETURN NUMBER
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_gi_final;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_getgirobust_final
        RETURN NUMBER
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_girobust_final;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_gettaxonindicateur
        RETURN VARCHAR2
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_taxonlisttaxonindicator;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_getplecopteracounter
        RETURN NUMBER
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_plecopteracounter;
    END;

    FUNCTION f_getephemeropteracounter
        RETURN NUMBER
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_ephemeropteracounter;
    END;



    FUNCTION f_gettrichopteracounter
        RETURN NUMBER
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_trichopteracounter;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_initlistfrequencesorted
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_listfrequencesorted.delete;
    END;



    /*------------------------------------------------------------------*/
    PROCEDURE p_loadcorrection_factor
    /*------------------------------------------------------------------*/
    IS
        l_rechydroregime   hydroregime%ROWTYPE;
    BEGIN
        IF gbl_ibch_q IS NULL
        THEN
            raise_application_error (-20000, 'IBCH_q not set', TRUE);
        END IF;

        l_rechydroregime :=
            pkg_hydroregime.f_getrecordbycode (TRIM (TO_CHAR (gbl_ibch_q)));

        IF l_rechydroregime.hdr_id IS NULL
        THEN
            raise_application_error (
                -20000,
                'Correction factor not identified by IBCH_q=' || gbl_ibch_q,
                TRUE);
        END IF;

        gbl_correctionfactor := l_rechydroregime.hdr_value;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_computesumfamilycorrected (p_sumfamily IN NUMBER)
        RETURN NUMBER
    /*-----------------------------------------------------------------*/
    IS
        l_sumcorrected   NUMBER;
    BEGIN
        l_sumcorrected :=
            ROUND (EXP (LN (p_sumfamily) + gbl_correctionfactor));
        RETURN l_sumcorrected;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_computegi_max_robust
    /*-----------------------------------------------------------------*/
    IS
        /* Permet de calcule la valeur GI du calcul de robustesse */
        l_indice   PLS_INTEGER;
    BEGIN
        l_indice := gbl_listgi.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            IF     gbl_gimaxrobust < gbl_listgi (l_indice)
               AND gbl_listgi (l_indice) != gbl_gimax
            THEN
                gbl_gimaxrobust := gbl_listgi (l_indice);
            END IF;

            l_indice := gbl_listgi.NEXT (l_indice);
        END LOOP;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_computesumfamilyrobust
    /*-----------------------------------------------------------------*/
    IS
        /* Permet de calcule le nombre de famille après avoir enlevé celles avec la valeur GI=GI_MAX du calcul de robustesse */
        l_indice    PLS_INTEGER;
        l_counter   NUMBER := 0;
    BEGIN
        l_indice := gbl_listgi.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            IF gbl_listgi (l_indice) != gbl_gimax
            THEN
                l_counter := l_counter + 1;
            END IF;

            l_indice := gbl_listgi.NEXT (l_indice);
        END LOOP;

        gbl_sumfamilyrobust := gbl_sumfamily - l_counter;
    END;



    /*-----------------------------------------------------------------*/
    FUNCTION f_returnclassevariete (p_taxonsum IN NUMBER)
        RETURN NUMBER
    /*-----------------------------------------------------------------*/
    IS
        l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
    BEGIN
        IF p_taxonsum IS NULL
        THEN
            raise_application_error (-20000, ' Taxon sum not set', TRUE);
        END IF;

        SELECT abundanceclassrange.*
          INTO l_recabundanceclassrange
          FROM abundanceclassrange
               INNER JOIN codevalue ON cvl_id = acr_cvl_id_midatindice
               INNER JOIN codereference ON cvl_crf_id = crf_id
         WHERE     cvl_code = pkg_codevalue.cst_midatindice_ibch2019
               AND crf_code = pkg_codereference.cst_crf_midatindice
               AND ROUND (p_taxonsum) BETWEEN acr_minvalue AND acr_maxvalue;

        IF l_recabundanceclassrange.acr_id IS NULL
        THEN
            raise_application_error (
                -20000,
                ' The sum of taxon does not make it possible to determine the abundance class',
                TRUE);
        END IF;

        RETURN l_recabundanceclassrange.acr_classe;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_computesumfamilycorrected
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_sumfamilycorrected := f_computesumfamilycorrected (gbl_sumfamily);
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_computesumfamilyrobustcorr
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_sumfamilyrobustcorrected :=
            f_computesumfamilycorrected (gbl_sumfamilyrobust);
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_computeclassevariete
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_classevariete := f_returnclassevariete (gbl_sumfamily);

        gbl_classevariete_corr :=
            f_returnclassevariete (gbl_sumfamilycorrected);

        gbl_classevariete_robust :=
            f_returnclassevariete (gbl_sumfamilyrobust);
        gbl_classevariete_robust_corr :=
            f_returnclassevariete (gbl_sumfamilyrobustcorrected);
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_computeclassevariete_final
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_classevariete_final :=
              cst_classvariete_factor1
            + cst_classvariete_factor2 * gbl_classevariete_corr;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_computeclassevarrobust_final
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_classevarieterobust_final :=
              cst_classvariete_factor1
            + cst_classvariete_factor2 * gbl_classevariete_robust_corr;
    END;


    /*------------------------------------------------------------------*/
    PROCEDURE p_init
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_taxonlisttaxonindicator := NULL;
        gbl_listfrequence.delete;
        gbl_listfrequencesorted.delete;
        gbl_ibch_q := NULL;
        gbl_listgi.delete;
        gbl_correctionfactor := NULL;
        gbl_taxonfrequencesum := 0;
        gbl_sumfamily := 0;
        gbl_gimax := 0;
        gbl_gimaxrobust := 0;
        gbl_listentry.delete;
        gbl_plecopteracounter := 0;
        gbl_ephemeropteracounter := 0;
        gbl_trichopteracounter := 0;
    END;


    /*--------------------------------------------------------------*/
    PROCEDURE p_computegi_max
    /*--------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
    BEGIN
        l_indice := gbl_listgi.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            IF gbl_listgi (l_indice) > gbl_gimax
            THEN
                gbl_gimax := gbl_listgi (l_indice);
            END IF;

            l_indice := gbl_listgi.NEXT (l_indice);
        END LOOP;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_compute_gi_final
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_gi_final := cst_gi_factor1 + cst_gi_factor2 * gbl_gimax;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_compute_girobust_final
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_girobust_final :=
            cst_gi_factor1 + cst_gi_factor2 * gbl_gimaxrobust;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_computeibch
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_ibch :=
              cst_ibch_classevariete_factor * gbl_classevariete_final
            + cst_ibch_gi_factor * gbl_gi_final;
        gbl_ibchrobust :=
              cst_ibch_classevariete_factor * gbl_classevarieterobust_final
            + cst_ibch_gi_factor * gbl_girobust_final;
    END;


    /*------------------------------------------------------------------*/
    PROCEDURE p_insertsortindex (p_index IN PLS_INTEGER)
    /*------------------------------------------------------------------*/
    IS
        l_indice               PLS_INTEGER;
        l_recfrequencesorted   t_recfrequencesorted;
    BEGIN
        IF gbl_listfrequencesorted.EXISTS (p_index)
        THEN
            l_indice := gbl_listfrequencesorted.LAST;

            WHILE l_indice >= p_index
            LOOP
                gbl_listfrequencesorted (l_indice + 1) :=
                    gbl_listfrequencesorted (l_indice);
                l_indice := gbl_listfrequencesorted.PRIOR (l_indice);
            END LOOP;
        END IF;

        l_recfrequencesorted.l_value := 0;
        l_recfrequencesorted.l_ptl_id := 0;
        gbl_listfrequencesorted (p_index) := l_recfrequencesorted;
    END;

    /*------------------------------------------------------------------*/
    FUNCTION f_searchindex (p_value IN importprotocollabo.ipl_value%TYPE)
        RETURN PLS_INTEGER
    /*------------------------------------------------------------------*/
    IS
        l_indice               PLS_INTEGER;

        l_recfrequencesorted   t_recfrequencesorted;
        l_indicefound          PLS_INTEGER := NULL;
    BEGIN
        l_indice := gbl_listfrequencesorted.FIRST;

        IF l_indice IS NULL
        THEN
            RETURN 1;
        END IF;

        WHILE NOT l_indice IS NULL AND l_indicefound IS NULL
        LOOP
            l_recfrequencesorted := gbl_listfrequencesorted (l_indice);

            IF l_recfrequencesorted.l_value >= p_value
            THEN
                l_indicefound := l_indice;
            END IF;

            l_indice := gbl_listfrequencesorted.NEXT (l_indice);
        END LOOP;

        IF l_indicefound IS NULL
        THEN
            l_indicefound := gbl_listfrequencesorted.LAST + 1;
        END IF;

        RETURN l_indicefound;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_addtofrequencesort (
        p_ptl_id      IN protocolmappinglabo.ptl_id%TYPE,
        p_frequence   IN importprotocollabo.ipl_value%TYPE)
    /*------------------------------------------------------------------*/
    IS
        l_recfrequencesorted   t_recfrequencesorted;
        l_index                PLS_INTEGER;
    BEGIN
        l_index := f_searchindex (p_frequence);

        p_insertsortindex (l_index);
        l_recfrequencesorted.l_ptl_id := p_ptl_id;
        l_recfrequencesorted.l_value := p_frequence;
        gbl_listfrequencesorted (l_index) := l_recfrequencesorted;
        NULL;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_buildfrequencesort
    /*-----------------------------------------------------------------*/
    IS
        l_indice   PLS_INTEGER;
    BEGIN
        p_initlistfrequencesorted;
        l_indice := gbl_listfrequence.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            p_addtofrequencesort (l_indice, gbl_listfrequence (l_indice));
            l_indice := gbl_listfrequence.NEXT (l_indice);
        END LOOP;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_appendstring (p_string      IN VARCHAR2,
                             p_append      IN VARCHAR2,
                             p_separator   IN VARCHAR2)
        RETURN VARCHAR2
    /*---------------------------------------------------------------*/
    IS
        l_string   VARCHAR2 (4096);
    BEGIN
        l_string := p_string;

        IF l_string IS NULL
        THEN
            l_string := p_append;
        ELSE
            l_string := p_string || p_separator || p_append;
        END IF;

        RETURN l_string;
        NULL;
    END;



    /*---------------------------------------------------------------*/
    PROCEDURE p_buildlistgi
    /*---------------------------------------------------------------*/
    IS
        l_indice                   PLS_INTEGER;
        l_recfrequencesorted       t_recfrequencesorted;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        gbl_listgi.delete;
        l_indice := gbl_listfrequencesorted.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            l_recfrequencesorted := gbl_listfrequencesorted (l_indice);
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (
                    l_recfrequencesorted.l_ptl_id);

            IF NOT l_recprotocolmappinglabo.ptl_ibchindividumin IS NULL
            THEN
                IF l_recprotocolmappinglabo.ptl_ibchindividumin <=
                   l_recfrequencesorted.l_value
                THEN
                    gbl_listgi (ROUND (l_recfrequencesorted.l_ptl_id)) :=
                        l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi;
                END IF;
            END IF;

            l_indice := gbl_listfrequencesorted.NEXT (l_indice);
        END LOOP;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_buildtaxonindicator
    /*---------------------------------------------------------------*/
    IS
        l_indice                   PLS_INTEGER;

        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        gbl_taxonlisttaxonindicator := NULL;

        l_indice := gbl_listgi.FIRST;


        WHILE NOT l_indice IS NULL
        LOOP
            IF gbl_listgi (l_indice) = gbl_gimax
            THEN
                l_recprotocolmappinglabo :=
                    pkg_protocolmappinglabo.f_getrecord (l_indice);
                gbl_taxonlisttaxonindicator :=
                    f_appendstring (gbl_taxonlisttaxonindicator,
                                    l_recprotocolmappinglabo.ptl_taxa,
                                    ', ');
            END IF;

            l_indice := gbl_listgi.NEXT (l_indice);
        END LOOP;
    END;

    /*-------------------------------------------------------------------------*/
    FUNCTION f_isinhierarchy (
        p_ptl_id_base       IN protocolmappinglabo.ptl_id%TYPE,
        p_plt_id_searched   IN protocolmappinglabo.ptl_id%TYPE)
        RETURN BOOLEAN
    /*-------------------------------------------------------------------------*/
    IS
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecord (p_ptl_id_base);

        WHILE     NOT l_recprotocolmappinglabo.ptl_ptl_id IS NULL
              AND l_recprotocolmappinglabo.ptl_id != p_plt_id_searched
        LOOP
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (
                    l_recprotocolmappinglabo.ptl_ptl_id);
        END LOOP;

        IF l_recprotocolmappinglabo.ptl_id = p_plt_id_searched
        THEN
            RETURN TRUE;
        ELSE
            RETURN FALSE;
        END IF;
    END;


    /* ----------------------------------------------------------------------- */
    FUNCTION f_countinhierarchytaxa (p_taxa IN VARCHAR2)
        RETURN NUMBER
    /*-------------------------------------------------------------------------*/
    IS
        l_indice                   PLS_INTEGER;
        l_ptv_id                   protocolversion.ptv_id%TYPE;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_count                    NUMBER := 0;
    BEGIN
        l_indice := gbl_listentry.FIRST;

        IF l_indice IS NULL
        THEN
            RETURN l_count;
        END IF;

        -- On identifie la version grâce au PTL_ID
        l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecord (l_indice);

        IF l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            RETURN l_count;
        END IF;

        l_ptv_id := l_recprotocolmappinglabo.ptl_ptv_id;
        l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecordbytaxa (l_ptv_id, p_taxa);

        IF l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            RETURN l_count;
        END IF;

        WHILE NOT l_indice IS NULL
        LOOP
            IF f_isinhierarchy (l_indice, l_recprotocolmappinglabo.ptl_id)
            THEN
                l_count := l_count + 1;
            END IF;

            l_indice := gbl_listentry.NEXT (l_indice);
        END LOOP;

        RETURN l_count;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_computeeptcounter
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        gbl_plecopteracounter := f_countinhierarchytaxa (cst_plecoptera);
        gbl_ephemeropteracounter :=
            f_countinhierarchytaxa (cst_ephemeroptera);
        gbl_trichopteracounter := f_countinhierarchytaxa (cst_trichoptera);
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_normalisebetween0_1 (p_value IN NUMBER)
        RETURN NUMBER
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        IF p_value > 1
        THEN
            RETURN 1;
        END IF;

        IF p_value < 0
        THEN
            RETURN 0;
        END IF;

        RETURN p_value;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_normalisegibetween0_1
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        gbl_gi_final := f_normalisebetween0_1 (gbl_gi_final);
        gbl_girobust_final := f_normalisebetween0_1 (gbl_girobust_final);
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_normaliseclassevarbetween0_1
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        gbl_classevariete_final :=
            f_normalisebetween0_1 (gbl_classevariete_final);
        gbl_classevarieterobust_final :=
            f_normalisebetween0_1 (gbl_classevarieterobust_final);
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_compute_ibch2019
    /*---------------------------------------------------------------*/
    IS
    /* Permet de calculer  l'IBCH */
    BEGIN
        IF gbl_ibch_q IS NULL
        THEN
            raise_application_error (-20000, 'IBCH_Q not SET', TRUE);
        END IF;


        p_buildfrequencesort;
        p_buildlistgi;
        p_computegi_max;
        p_buildtaxonindicator;
        p_loadcorrection_factor;
        p_computegi_max_robust;
        p_computesumfamilycorrected;
        p_computesumfamilyrobust;
        p_computesumfamilyrobustcorr;
        p_computeclassevariete;
        p_compute_gi_final;
        p_compute_girobust_final;
        p_computeclassevarrobust_final;
        p_computeclassevariete_final;
        p_computeibch;
        p_computeeptcounter;
        p_normaliseclassevarbetween0_1;
        p_normalisegibetween0_1;
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_displayfrequencesort
    /*---------------------------------------------------------------*/
    IS
        l_indice               PLS_INTEGER;
        l_recfrequencesorted   t_recfrequencesorted;
    BEGIN
        l_indice := gbl_listfrequencesorted.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            l_recfrequencesorted := gbl_listfrequencesorted (l_indice);
            DBMS_OUTPUT.put_line (
                   'l_indice='
                || l_indice
                || ' l_value='
                || l_recfrequencesorted.l_value
                || ' l_ptl_id='
                || l_recfrequencesorted.l_ptl_id);
            l_indice := gbl_listfrequencesorted.NEXT (l_indice);
        END LOOP;
    END;



    /*-----------------------------------------------------------------*/
    FUNCTION f_getcounterbytaxa (
        p_ptv_id   IN protocolmappinglabo.ptl_ptv_id%TYPE,
        p_taxa     IN protocolmappinglabo.ptl_taxa%TYPE)
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
        l_reprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        l_reprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecordbytaxa (p_ptv_id, p_taxa);

        IF l_reprotocolmappinglabo.ptl_id IS NULL
        THEN
            RETURN NULL;
        END IF;

        IF gbl_listfrequence.EXISTS (ROUND (l_reprotocolmappinglabo.ptl_id))
        THEN
            RETURN gbl_listfrequence (ROUND (l_reprotocolmappinglabo.ptl_id));
        ELSE
            RETURN 0;
        END IF;
    END;

    /*---------------------------------------------------------------------------*/
    PROCEDURE p_setibch_q (p_ibch_q IN NUMBER)
    /*---------------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_ibch_q := p_ibch_q;
    END;



    /*------------------------------------------------------------------*/
    PROCEDURE p_addfrequence (
        p_ptl_id      IN protocolmappinglabo.ptl_id%TYPE,
        p_frequence   IN importprotocollabo.ipl_value%TYPE)
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        IF gbl_listfrequence.EXISTS (ROUND (p_ptl_id))
        THEN
            gbl_listfrequence (ROUND (p_ptl_id)) :=
                gbl_listfrequence (ROUND (p_ptl_id)) + p_frequence;
        ELSE
            gbl_listfrequence (ROUND (p_ptl_id)) := p_frequence;
        END IF;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_loaddatafromlabo (
        p_recprotocolheader   IN importprotocolheader%ROWTYPE)
    /*------------------------------------------------------------------*/
    IS
        CURSOR l_listlabodata (p_iph_id IN importprotocolheader.iph_id%TYPE)
        IS
            SELECT *
              FROM importprotocollabo
             WHERE     ipl_iph_id = p_iph_id
                   AND ipl_validstatus = pkg_constante.cst_validstatusok;

        l_reclabodata   l_listlabodata%ROWTYPE;
    BEGIN
        OPEN l_listlabodata (p_recprotocolheader.iph_id);

        LOOP
            FETCH l_listlabodata INTO l_reclabodata;

            EXIT WHEN l_listlabodata%NOTFOUND;
            DBMS_OUTPUT.put_line (
                   'ptl_id='
                || l_reclabodata.ipl_ptl_id
                || ' ipl_value='
                || l_reclabodata.ipl_value);
            p_cascadefrequence (l_reclabodata.ipl_ptl_id,
                                l_reclabodata.ipl_value);
        END LOOP;

        CLOSE l_listlabodata;
    END;



    /*------------------------------------------------------------------*/
    PROCEDURE p_maincompute (
        p_recprotocolheader   IN importprotocolheader%ROWTYPE,
        p_recmassdataheader   IN importmassdataheader%ROWTYPE)
    /*------------------------------------------------------------------*/
    IS
        l_ptv_id               protocolversion.ptv_id%TYPE;
        l_recprotocolversion   protocolversion%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
    BEGIN
        l_recprotocolversion := pkg_protocolversion.f_getrecord (p_recprotocolheader.iph_ptv_id);
        l_reccodevalue :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);
        pkg_debug.p_write (
            'PKG_IBCH2019.p_maincompute',
            'l_reccodevalue.cvl_code=' || l_reccodevalue.cvl_code);

        IF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_mass
        THEN
            raise_application_error (
                -20000,
                'MASS PROTOCOL UNSUPORTED WITH IBCH2019',
                TRUE);
        END IF;

        p_init;
        DBMS_OUTPUT.put_line ('Ici');
        p_setibch_q (p_recprotocolheader.iph_ibchq);
        p_loaddatafromlabo (p_recprotocolheader);
        p_compute_ibch2019;
    END;


    /*------------------------------------------------------------------*/
    PROCEDURE p_cascadefrequence (
        p_ptl_id      IN protocolmappinglabo.ptl_id%TYPE,
        p_frequence   IN importprotocollabo.ipl_value%TYPE)
    /*------------------------------------------------------------------*/
    IS
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        gbl_taxonfrequencesum := gbl_taxonfrequencesum + p_frequence;
        gbl_sumfamily := gbl_sumfamily + 1;
        l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecord (p_ptl_id);

        IF l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            raise_application_error (
                -20000,
                   'Erreur innatendue: La valeur PTL_ID '
                || p_ptl_id
                || ' n''existe pas',
                TRUE);
        END IF;

        gbl_listentry (p_ptl_id) := p_frequence;

        p_addfrequence (l_recprotocolmappinglabo.ptl_id, p_frequence);

        WHILE NOT l_recprotocolmappinglabo.ptl_ptl_id IS NULL
        LOOP
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (
                    l_recprotocolmappinglabo.ptl_ptl_id);
            p_addfrequence (l_recprotocolmappinglabo.ptl_id, p_frequence);
        END LOOP;
    END;

    /*------------------------------------------------------------------------*/
    PROCEDURE p_displayfrequence
    /*------------------------------------------------------------------------*/
    IS
        l_indice                   PLS_INTEGER;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        l_indice := gbl_listfrequence.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (l_indice);
            DBMS_OUTPUT.put_line (
                   'ptl_id='
                || l_indice
                || ' '
                || l_recprotocolmappinglabo.ptl_taxa
                || ' '
                || gbl_listfrequence (l_indice));
            l_indice := gbl_listfrequence.NEXT (l_indice);
        END LOOP;
    END;

    /*------------------------------------------------------------------------*/
    PROCEDURE p_displaygroup_gi
    /*------------------------------------------------------------------------*/
    IS
        l_indice                   PLS_INTEGER;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        l_indice := gbl_listgi.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (l_indice);
            DBMS_OUTPUT.put_line (
                   'ptl_id='
                || l_indice
                || ' '
                || l_recprotocolmappinglabo.ptl_taxa
                || ' '
                || gbl_listgi (l_indice));
            l_indice := gbl_listgi.NEXT (l_indice);
        END LOOP;
    END;
END pkg_ibch2019;
/

