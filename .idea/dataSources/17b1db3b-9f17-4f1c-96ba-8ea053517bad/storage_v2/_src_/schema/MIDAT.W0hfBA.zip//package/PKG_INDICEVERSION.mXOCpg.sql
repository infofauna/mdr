create PACKAGE       pkg_indiceversion
AS
    /******************************************************************************
       NAME:       PKG_INDICEVERSION
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        05.10.2017      burrif       1. Created this package.
    ******************************************************************************/

    /*
     Pour changer de version:
      1) Exécuter la procédure pkg_indicehistory.p_buildhistory pour l'indice en question
      2) Editer la table INDICEVERSION pour placer la valeur IVR_CURRENT = 'Y' en regard de la nouvelle version

    */



    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_getrecord (p_ivr_id IN indiceversion.ivr_id%TYPE)
        RETURN indiceversion%ROWTYPE;

    FUNCTION f_getrecordbyversion (
        p_ivr_version   IN indiceversion.ivr_version%TYPE,
        p_midatindice   IN codevalue.cvl_code%TYPE)
        RETURN indiceversion%ROWTYPE;

    FUNCTION f_getcurrentversion (p_midatindice IN codevalue.cvl_code%TYPE)
        RETURN indiceversion%ROWTYPE;

    FUNCTION f_getpreviousversion (
        p_recindiceversion   IN indiceversion%ROWTYPE)
        RETURN indiceversion%ROWTYPE;

    PROCEDURE p_write (
        p_current              IN     indiceversion.ivr_current%TYPE,
        p_cvl_id_midatindice   IN     indiceversion.ivr_cvl_id_midatindice%TYPE,
        p_ptv_id               IN     indiceversion.ivr_ptv_id%TYPE,
        p_version              IN     indiceversion.ivr_version%TYPE,
        p_designation          IN     indiceversion.ivr_designation%TYPE,
        p_id                      OUT indiceversion.ivr_id%TYPE);
END pkg_indiceversion;
/

