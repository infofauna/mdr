create PACKAGE BODY       pkg_migr_ibch2019
AS
    /******************************************************************************
       NAME:       PKG_MIGR_IBCH2019
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       15.05.2020  F.Burri           1. Created this package body.
    ******************************************************************************/
    cst_newversiontext              CONSTANT protocolversion.ptv_text%TYPE
        := 'Protocole de laboratoire, version 3.0, 29 novembre 2019' ;
    cst_oldversiontext              CONSTANT protocolversion.ptv_text%TYPE
        := 'Protocole de laboratoire, version 2.0, 25 septembre 2013' ;
    cst_newibchindicedesignation    CONSTANT indiceversion.ivr_designation%TYPE
        := 'Version IBCH2019' ;
    cst_newspearindicedesignation   CONSTANT indiceversion.ivr_designation%TYPE
        := 'Version SPEAR2019' ;
    cst_newibchindiceversion        CONSTANT indiceversion.ivr_designation%TYPE
        := 'IBCH2019' ;
    cst_newspearindiceversion       CONSTANT indiceversion.ivr_designation%TYPE
        := 'SPEAR2019' ;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-------------------------------------------------------------------*/
    PROCEDURE p_deleteprotocolheaderdata
    /*-------------------------------------------------------------------*/
    IS
        l_recprotocolversionnew   protocolversion%ROWTYPE;
    BEGIN
        l_recprotocolversionnew :=
            pkg_migr_ibch2019_ptv.f_returnversionbytext (cst_newversiontext);

        IF l_recprotocolversionnew.ptv_id IS NULL
        THEN
            pkg_debug.p_write (
                'pkg_migr_ibch2019.p_deleteprotocolheaderdata',
                   'FATAL*** La version : '
                || cst_newversiontext
                || ' existe pas');
            raise_application_error (
                -20000,
                'La version : ' || cst_newversiontext || ' existe pas',
                TRUE);
        END IF;


        pkg_migr_ibch2019_ipo.p_deletebyptv_id (
            l_recprotocolversionnew.ptv_id);
        pkg_migr_ibch2019_ipl.p_deletebyptv_id (
            l_recprotocolversionnew.ptv_id);
        pkg_migr_ibch2019_iph.p_deletebyptv_id (
            l_recprotocolversionnew.ptv_id);
    END;



    /*--------------------------------------------------------------------*/
    PROCEDURE p_main_1
    /*--------------------------------------------------------------------*/
    IS
        l_ptv_id_new              protocolversion.ptv_id%TYPE;
        l_ptv_id_old              protocolversion.ptv_id%TYPE;
        l_exist                   BOOLEAN;
        l_recprotocolversionold   protocolversion%ROWTYPE;
        l_recprotocolversionnew   protocolversion%ROWTYPE;
        l_ok                      BOOLEAN;
    BEGIN
        pkg_debug.p_truncate;
        l_recprotocolversionold :=
            pkg_migr_ibch2019_ptv.f_returnversionbytext (cst_oldversiontext);

        IF l_recprotocolversionold.ptv_id IS NULL
        THEN
            pkg_debug.p_write (
                'pkg_migr_ibch2019.p_main',
                   'FATAL*** La version à copier : '
                || cst_oldversiontext
                || ' existe pas');
            raise_application_error (
                -20000,
                   'La version à copier : '
                || cst_oldversiontext
                || ' existe pas',
                TRUE);
        END IF;

        l_ptv_id_old := l_recprotocolversionold.ptv_id;

        l_recprotocolversionnew :=
            pkg_migr_ibch2019_ptv.f_returnversionbytext (cst_newversiontext);
        DBMS_OUTPUT.put_line (
               ' l_recprotocolversionnew.ptv_id='
            || l_recprotocolversionnew.ptv_id);


        IF NOT l_recprotocolversionnew.ptv_id IS NULL
        THEN
            -- Les données de la nouvelle version existe, on les supprime.
            pkg_migr_ibch2019_ipo.p_deletebyptv_id (
                l_recprotocolversionnew.ptv_id);
            pkg_migr_ibch2019_ipl.p_deletebyptv_id (
                l_recprotocolversionnew.ptv_id);
            pkg_migr_ibch2019_iph.p_deletebyptv_id (
                l_recprotocolversionnew.ptv_id);

            pkg_migr_ibch2019_ptl.p_deleteversion (
                l_recprotocolversionnew.ptv_id);
            pkg_migr_ibch2019_pmh.p_deletedata (
                l_recprotocolversionnew.ptv_id);
            pkg_migr_ibch2019_ptv.p_deleteversion (
                l_recprotocolversionnew.ptv_id);
        END IF;

        pkg_migr_ibch2019_util.p_recreatesequence ('PROTOCOLVERSION',
                                                   'SEQ_PROTOCOLVERSION',
                                                   'PTV_ID');

      --  pkg_migr_ibch2019_util.p_compilepackage ('PKG_PROTOCOLVERSION');

        pkg_migr_ibch2019_iph.p_add_iph_columns;

        pkg_migr_ibch2019_ptv.p_addversion (cst_newversiontext,
                                            l_ptv_id_new,
                                            l_exist);


        pkg_migr_ibch2019_util.p_recreatesequence ('PROTOCOLMAPPINGLABO',
                                                   'SEQ_PROTOCOLMAPPINGLABO',
                                                   'PTL_ID');
        pkg_migr_ibch2019_util.p_compilepackage ('PKG_PROTOCOLMAPPINGLABO');
        DBMS_OUTPUT.put_line (
               'l_ptv_id_old='
            || l_ptv_id_old
            || ' l_ptv_id_new='
            || l_ptv_id_new);
        pkg_migr_ibch2019_ptl.p_checkalllabo (l_ptv_id_old, l_ok);

        IF NOT l_ok
        THEN
            raise_application_error (
                -20000,
                'FATAL*** Des identifiant de taxons sont manquants ou erronés dans PROTOCOLMAPPINGLABO',
                TRUE);
        END IF;

        pkg_migr_ibch2019_ptl.p_completaxonreplace (l_ptv_id_old);
        pkg_migr_ibch2019_ptl.p_initnewtaxon;
        --
        pkg_migr_ibch2019_ptl.p_copyversion (l_ptv_id_old, l_ptv_id_new);

        pkg_migr_ibch2019_ptl.p_appendnewtaxon (l_ptv_id_new);
        pkg_migr_ibch2019_ptl.p_updatenewtaxonptl_ptl_id (l_ptv_id_new);
        pkg_migr_ibch2019_ptl.p_updatetaxonname (l_ptv_id_new);
        pkg_migr_ibch2019_ptl.p_updatespear (l_ptv_id_new);

        pkg_migr_ibch2019_util.p_recreatesequence (
            'PROTOCOLMAPPINGHEADER',
            'SEQ_PROTOCOLMAPPINGHEADER',
            'PMH_ID');
        pkg_migr_ibch2019_pmh.p_copydata (l_ptv_id_old, l_ptv_id_new);
        pkg_migr_ibch2019_pmh.p_addnewdata (l_ptv_id_new);
        pkg_migr_ibch2019_pmh.p_updatechangemapping (l_ptv_id_new);
        pkg_migr_ibch2019_sph.p_add_sph_columns;
        pkg_migr_ibch2019_hdr.p_delete;
        pkg_migr_ibch2019_hdr.p_insertalldata;
        pkg_migr_ibch2019_ptl.p_updateptl_ptl_id (l_ptv_id_old, l_ptv_id_new);
        pkg_migr_ibch2019_ptl.p_changegi (l_ptv_id_new);
        pkg_migr_ibch2019_util.p_recreatesequence ('abundanceclassrange',
                                                   'SEQ_abundanceclassrange',
                                                   'ACR_ID');

        pkg_migr_ibch2019_acr.p_insertall;
        pkg_migr_ibch2019_util.p_recreatesequence ('biologicalstate',
                                                   'SEQ_biologicalstate',
                                                   'BLS_ID');

        pkg_migr_ibch2019_bls.p_update_bls_ivr_id;
        pkg_migr_ibch2019_bls.p_insertall;
        pkg_migr_ibch2019_util.p_recreatesequence ('neozoaire',
                                                   'SEQ_neozoaire',
                                                   'NEO_ID');
        

        NULL;
    END;
    /*-----------------------------------------------------------------------*/
    procedure p_main_2
    /*-----------------------------------------------------------------------*/
    IS
    BEGIN
     pkg_migr_ibch2019_neo.p_insertall;
        pkg_migr_ibch2019_ivr.p_addcolumn;
        pkg_migr_ibch2019_ivr.p_addindiceversion (
            cst_newversiontext,
            cst_newibchindiceversion,
            cst_newibchindicedesignation,
            cst_newspearindiceversion,
            cst_newspearindicedesignation);

        pkg_migr_ibch2019_ivr.p_updateorder;
        pkg_migr_ibch2019_ihy.p_create_table;

    END; 

    /*-----------------------------------------------------------------------*/
    PROCEDURE p_deletedata_new
    /*-----------------------------------------------------------------------*/
    IS
        l_recprotocolversion   protocolversion%ROWTYPE;

        CURSOR l_sample (p_ptv_id IN protocolversion.ptv_id%TYPE)
        IS
            SELECT *
              FROM sampleheader
             WHERE sph_ptv_id = p_ptv_id;
             

        l_recsample            l_sample%ROWTYPE;
        
         CURSOR l_importprotocolheader (p_ptv_id IN protocolversion.ptv_id%TYPE)
        IS
            SELECT *
              FROM importprotocolheader
             WHERE iph_ptv_id = p_ptv_id;
             

        l_recimportprotocolheader            l_importprotocolheader%ROWTYPE;
        
        
        
    BEGIN
        l_recprotocolversion :=
            pkg_migr_ibch2019_ptv.f_returnversionbytext (cst_newversiontext);

        IF l_recprotocolversion.ptv_id IS NULL
        THEN
            raise_application_error (
                -20000,
                'Version: ' || cst_newversiontext || ' non trouvé');
        END IF;
        DBMS_OUTPUT.put_line ('PTV_ID:=' || l_recprotocolversion.ptv_id);

        OPEN l_sample (l_recprotocolversion.ptv_id);

        LOOP
            FETCH l_sample INTO l_recsample;

            EXIT WHEN l_sample%NOTFOUND;
            DBMS_OUTPUT.put_line ('SPH_ID:=' || l_recsample.sph_id);
            pkg_delete_protocol.p_deleteprotocolentry (l_recsample.sph_id);
        END LOOP;

        CLOSE l_sample;
        
         OPEN l_importprotocolheader (l_recprotocolversion.ptv_id);

        LOOP
            FETCH l_importprotocolheader INTO l_recimportprotocolheader;

            EXIT WHEN l_importprotocolheader%NOTFOUND;
            DBMS_OUTPUT.put_line ('IPH_ID:=' || l_recimportprotocolheader.iph_id);
            pkg_delete_protocol. p_purgeby_iph_id  (l_recimportprotocolheader.iph_id);
        END LOOP;

        CLOSE l_importprotocolheader;
        
    END;
END pkg_migr_ibch2019;
/

