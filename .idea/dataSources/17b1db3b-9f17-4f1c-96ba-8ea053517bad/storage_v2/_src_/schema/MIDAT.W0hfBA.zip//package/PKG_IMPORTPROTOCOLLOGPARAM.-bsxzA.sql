create PACKAGE       pkg_importprotocollogparam
AS
   /******************************************************************************
      NAME:       PKG_IMPORTPROTOCOLLOGPARAM
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        01.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_setwebuserinfo (
      p_usr_id_create importprotocollogparam.ipr_usr_id_create%TYPE);

   PROCEDURE p_insert (
      p_ipr_ipo_id       importprotocollogparam.ipr_ipo_id%TYPE,
      p_ipr_sequence     importprotocollogparam.ipr_sequence%TYPE,
      p_ipr_parameter    importprotocollogparam.ipr_parameter%TYPE);

   FUNCTION f_getparameter (
      p_ipo_id     IN importprotocollogparam.ipr_ipo_id%TYPE,
      p_sequence   IN importprotocollogparam.ipr_sequence%TYPE)
      RETURN importprotocollogparam.ipr_parameter%TYPE;
END pkg_importprotocollogparam;
/

