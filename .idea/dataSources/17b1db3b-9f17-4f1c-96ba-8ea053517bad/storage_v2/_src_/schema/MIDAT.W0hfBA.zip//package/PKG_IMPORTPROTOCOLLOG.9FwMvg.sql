create PACKAGE       pkg_importprotocollog
AS
   /******************************************************************************
      NAME:       PKG_IMPORTPROTOCOLLOG
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        01.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   TYPE t_cursor IS REF CURSOR;

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_test;

   PROCEDURE p_deleteby_iph_id (
      p_iph_id   IN importprotocollog.ipo_iph_id%TYPE);

   PROCEDURE p_clearconditionnaly (
      p_ipo_iph_id   IN importprotocollog.ipo_iph_id%TYPE);

   PROCEDURE p_purgebyimh_id (p_imh_id IN importprotocollog.ipo_imh_id%TYPE);

   PROCEDURE p_logstartsubprocess (
      p_iph_id      IN importprotocolheader.iph_id%TYPE,
      p_imh_id      IN importprotocollog.ipo_imh_id%TYPE,
      p_exception   IN NUMBER);

   PROCEDURE p_logendsubprocess (
      p_iph_id           IN importprotocolheader.iph_id%TYPE,
      p_imh_id           IN importprotocollog.ipo_imh_id%TYPE,
      p_exception        IN NUMBER,
      p_starttimestamp   IN TIMESTAMP,
      p_recordcount      IN NUMBER);

   PROCEDURE p_returnvalidatestatus (
      p_iph_id         IN     importprotocolheader.iph_id%TYPE,
      p_returnstatus      OUT NUMBER);

   FUNCTION f_get_error_count (p_severity IN CHAR)
      RETURN VARCHAR2;

   PROCEDURE p_insert (
      p_ipo_id                IN importprotocollog.ipo_id%TYPE,
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE);

   PROCEDURE p_recopyerrorbyimh_id (
      p_imh_id   IN importprotocollog.ipo_imh_id%TYPE);

   PROCEDURE p_setwebuserinfo (
      p_usr_id_create    importprotocollog.ipo_usr_id_create%TYPE);

   PROCEDURE p_logunexpectederror (
      p_iph_id       IN importprotocolheader.iph_id%TYPE,
      p_fieldname    IN importprotocollog.ipo_fieldname%TYPE,
      p_modulename   IN VARCHAR2);

   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE);

   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE);

   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE);

   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE);

   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE);

   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE);

   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param6                IN importprotocollogparam.ipr_parameter%TYPE);

   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param6                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param7                IN importprotocollogparam.ipr_parameter%TYPE);

   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param6                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param7                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param8                IN importprotocollogparam.ipr_parameter%TYPE);

   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param6                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param7                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param8                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param9                IN importprotocollogparam.ipr_parameter%TYPE);

   PROCEDURE p_writelog (
      p_ipo_iph_id            IN importprotocollog.ipo_iph_id%TYPE,
      p_ipo_imh_id            IN importprotocollog.ipo_imh_id%TYPE,
      p_ipo_exceptionnumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_ipo_fieldname         IN importprotocollog.ipo_fieldname%TYPE,
      p_param1                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param2                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param3                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param4                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param5                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param6                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param7                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param8                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param9                IN importprotocollogparam.ipr_parameter%TYPE,
      p_param10               IN importprotocollogparam.ipr_parameter%TYPE);

   FUNCTION f_buildmessage (
      p_ipo_id        IN importprotocollog.ipo_id%TYPE,
      p_errornumber   IN importprotocollog.ipo_exceptionnumber%TYPE,
      p_lan_id        IN language.lan_id%TYPE)
      RETURN VARCHAR2;

   FUNCTION f_getmaxseveritylevel (
      p_ipo_iph_id   IN importprotocollog.ipo_iph_id%TYPE)
      RETURN VARCHAR;

   FUNCTION f_getcountseveritylevel (
      p_ipo_iph_id      IN importprotocollog.ipo_iph_id%TYPE,
      p_severitylevel   IN MESSAGE.msg_severity%TYPE)
      RETURN NUMBER;

   PROCEDURE p_listerrorlog (
      p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id        IN     language.lan_id%TYPE,
      p_cursorerror      OUT t_cursor,
      p_errorlevel       OUT VARCHAR2);

   PROCEDURE p_purgebyiphid (
      p_ipo_iph_id   IN importprotocollog.ipo_iph_id%TYPE);
END pkg_importprotocollog;
/

