create PACKAGE BODY       pkg_migr_ibch2019_acr
AS
    /******************************************************************************
       NAME:       pkg_migr_ibch2019_acr
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        3.07.2020      burrif       1. Created this package.
    ******************************************************************************/


    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.0, juillet  2020' ;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_insert (
        p_code_midatindice   IN     codevalue.cvl_code%TYPE,
        p_minvalue           IN     abundanceclassrange.acr_minvalue%TYPE,
        p_maxvalue           IN     abundanceclassrange.acr_maxvalue%TYPE,
        p_classe             IN     abundanceclassrange.acr_classe%TYPE,
        p_substitutevalue    IN     abundanceclassrange.acr_substitutevalue%TYPE,
        p_id                    OUT abundanceclassrange.acr_id%TYPE)
    /*--------------------------------------------------------------*/
    IS
        l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
        l_reccodevalue             codevalue%ROWTYPE;
    BEGIN
        l_recabundanceclassrange :=
            pkg_abundanceclassrange.f_getrecordbyclass (p_code_midatindice,
                                                        p_classe);

        IF l_recabundanceclassrange.acr_id IS NULL
        THEN
            l_reccodevalue :=
                pkg_codevalue.f_getrecordbycode (
                    pkg_codereference.cst_crf_midatindice,
                    p_code_midatindice);
            pkg_abundanceclassrange.p_write (l_reccodevalue.cvl_id,
                                             p_minvalue,
                                             p_maxvalue,
                                             p_classe,
                                             p_substitutevalue,
                                             p_id);
        END IF;
    END;

    /*----------------------------------------------------------------------------*/
    PROCEDURE p_delete
    /*----------------------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM abundanceclassrange
              WHERE acr_cvl_id_midatindice =
                    (SELECT cvl_id
                       FROM codevalue
                            INNER JOIN codereference ON cvl_crf_id = crf_id
                      WHERE     cvl_code =
                                pkg_codevalue.cst_midatindice_ibch2019
                            AND crf_code =
                                pkg_codereference.cst_crf_midatindice);
    END;


    /*----------------------------------------------------------------------------*/
    PROCEDURE p_insertall
    /*----------------------------------------------------------------------------*/
    IS
        l_id   abundanceclassrange.acr_id%TYPE;
    BEGIN
        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  1,
                  3,
                  1,
                  NULL,
                  l_id);
        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  4,
                  6,
                  2,
                  NULL,
                  l_id);
        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  7,
                  9,
                  3,
                  NULL,
                  l_id);
        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  10,
                  12,
                  4,
                  NULL,
                  l_id);
        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  13,
                  16,
                  5,
                  NULL,
                  l_id);


        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  17,
                  20,
                  6,
                  NULL,
                  l_id);

        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  21,
                  24,
                  7,
                  NULL,
                  l_id);

        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  25,
                  28,
                  8,
                  NULL,
                  l_id);

        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  29,
                  32,
                  9,
                  NULL,
                  l_id);

        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  33,
                  36,
                  10,
                  NULL,
                  l_id);

        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  37,
                  40,
                  11,
                  NULL,
                  l_id);

        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  41,
                  44,
                  12,
                  NULL,
                  l_id);

        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  45,
                  49,
                  13,
                  NULL,
                  l_id);

        p_insert (pkg_codevalue.cst_midatindice_ibch2019,
                  50,
                  999999999,
                  14,
                  NULL,
                  l_id);
    END;
END;
/

