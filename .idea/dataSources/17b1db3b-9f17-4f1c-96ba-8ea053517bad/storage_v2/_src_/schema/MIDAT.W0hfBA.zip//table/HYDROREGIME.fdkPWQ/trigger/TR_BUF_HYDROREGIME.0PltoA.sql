create trigger TR_BUF_HYDROREGIME
    before update
    on HYDROREGIME
    for each row
DECLARE
BEGIN
    :new.hdr_moddate := SYSDATE;
    :new.hdr_moduser := USER;
END tr_buf_hydroregime;
/

