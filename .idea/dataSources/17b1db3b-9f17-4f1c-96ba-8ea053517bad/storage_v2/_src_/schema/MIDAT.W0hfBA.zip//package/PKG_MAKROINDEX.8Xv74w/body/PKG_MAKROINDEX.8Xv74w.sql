create PACKAGE BODY       pkg_makroindex
AS
   /******************************************************************************
      NAME:       pkg_MAKROINDEX
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        07/07/2015      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion      CONSTANT VARCHAR2 (30)
                                       := 'Version 1.0, juillet  2015' ;



   gbl_mki_range_selected           VARCHAR2 (10) := NULL;
   gbl_mki_range_count              NUMBER := 0;
   gbl_mki_errornumber              NUMBER := NULL;
   gbl_mki_cvl_code_case            codevalue.cvl_code%TYPE := NULL;
   gbl_mki_non_insecta_count        NUMBER := 0;
   gbl_mki_insecta_count            NUMBER := 0;
   gbl_mki_has_baetidae             CHAR (1) := pkg_constante.cst_no;
   gbl_mki_normalizedcount          NUMBER := 0;
   gbl_mki_totalcounter             NUMBER := 0;
   gbl_mki_insectanoninsectaratio   NUMBER := 0;
   gbl_mki_excludetricoptera        NUMBER := 0;
   gbl_mki_makroindexvalue          NUMBER := 0;

   gbl_mki_reference                t_listmkireference;

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;
    /*--------------------------------------------------------------*/
   FUNCTION f_mkibuilddesignationstart (p_recmkisublist IN t_recmkisublist)
      RETURN VARCHAR2
   /*--------------------------------------------------------------*/
   IS
      l_listdesignation      VARCHAR2 (4096);
      l_indice               PLS_INTEGER;
      l_recsystdesignation   systdesignation%ROWTYPE;
   BEGIN
      l_indice := p_recmkisublist.sub_mkistartsyvidsublist.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         l_recsystdesignation :=
            pkg_systdesignation.f_getrecdesignationbylancode (
               p_recmkisublist.sub_mkistartsyvidsublist (l_indice),
               pkg_language.cst_lan_cde_latin);

         IF l_listdesignation IS NULL
         THEN
            l_listdesignation := l_recsystdesignation.syd_designation;
         ELSE
            l_listdesignation :=
                  l_listdesignation
               || ', '
               || l_recsystdesignation.syd_designation;
         END IF;

         l_indice := p_recmkisublist.sub_mkistartsyvidsublist.NEXT (l_indice);
         NULL;
      END LOOP;

      RETURN l_listdesignation;
      NULL;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getmkinoninsectacount
      RETURN NUMBER
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_non_insecta_count;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getmkicvlcodecase
      RETURN codevalue.cvl_code%TYPE
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_cvl_code_case;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getmkierror
      RETURN NUMBER
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_errornumber;
   END;

   /*------------------------------------------------------------*/
   FUNCTION f_getgblmkireference
      RETURN t_listmkireference
   /*------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_reference;
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_getgblmkitotalcounter
      RETURN NUMBER
   /*------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_totalcounter;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_getgblmkiinsectaratio
      RETURN NUMBER
   /*------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_insectanoninsectaratio;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_getgblmkiinsectacount
      RETURN NUMBER
   /*------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_insecta_count;
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_getgblmkirangeselected
      RETURN VARCHAR2
   /*------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_range_selected;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_logerroroncomputedmakroindex (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_imh_id                    IN importmassdataheader.imh_id%TYPE)
   /*-----------------------------------------------------------*/
   IS
      l_mkicountinsecta             NUMBER;
      l_mkinoninsectacount          NUMBER;
      l_mkierror                    NUMBER;
      l_mkicounter                  NUMBER;
      l_listmkireference            pkg_makroindex.t_listmkireference;
      l_mkitextratioinsecta         VARCHAR2 (1024);
      l_mkiinsectanoninsectaratio   NUMBER;
      l_list                        VARCHAR2 (512);
      l_plecoandtrico               NUMBER;
      l_total                       NUMBER;
   BEGIN
      l_mkierror := f_getmkierror;
      l_listmkireference := f_getgblmkireference;
      l_mkicounter := f_getgblmkitotalcounter;
      l_mkiinsectanoninsectaratio := f_getgblmkiinsectaratio;
      l_mkinoninsectacount := f_getmkinoninsectacount;
      l_mkicountinsecta := f_getgblmkiinsectacount;

      IF l_mkiinsectanoninsectaratio =
            pkg_makroindex.cst_insectaratio_zerodivide
      THEN
         l_mkitextratioinsecta := '∞';
      ELSE
         l_mkitextratioinsecta :=
               TRIM (TO_CHAR (l_mkicountinsecta))
            || '/'
            || TRIM (TO_CHAR (l_mkinoninsectacount))
            || '='
            || TO_CHAR (l_mkiinsectanoninsectaratio, '999.99');
      END IF;

      CASE l_mkierror
         WHEN pkg_exception.cst_mkiasselushirudinaeturbifi
         -- %p1% Asselus, %p2% Hirudinae et %p3% Turbificidae avec un rapport insectes/non insectes de %p4%
         THEN
            pkg_importprotocollog.p_writelog (
               p_recimportprotocolheader.iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_mkiasselushirudinaeturbifi,
               NULL,                                             -- Field name
               TO_CHAR (
                  l_listmkireference (pkg_makroindex.cst_mki_asellus).mki_counter,
                  '99999'),
               TO_CHAR (
                  l_listmkireference (pkg_makroindex.cst_mki_hirudinea).mki_counter,
                  '99999'),
               TO_CHAR (
                  l_listmkireference (pkg_makroindex.cst_mki_tubificidae).mki_counter,
                  '99999'),
               l_mkitextratioinsecta);
         WHEN pkg_exception.cst_mkigammarushydropsyche
         -- %p1% Gammarus, %p2% Hydropsyche avec un rapport insectes/non insectes de %p3%
         THEN
            pkg_importprotocollog.p_writelog (
               p_recimportprotocolheader.iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_mkigammarushydropsyche,
               NULL,                                             -- Field name
               TO_CHAR (
                  l_listmkireference (pkg_makroindex.cst_mki_gammarus).mki_counter,
                  '99999'),
               TO_CHAR (
                  l_listmkireference (pkg_makroindex.cst_mki_hydropsyche).mki_counter,
                  '99999'),
               l_mkitextratioinsecta);
         WHEN pkg_exception.cst_mkiephemeropterawithoutbae
         -- %p1% Ephemeroptera sans Baetidae avec un rapport insectes/non insectes de %p2%
         THEN
            pkg_importprotocollog.p_writelog (
               p_recimportprotocolheader.iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_mkiephemeropterawithoutbae,
               NULL,                                             -- Field name
               pkg_makroindex.f_getgblmkirangeselected,
               l_mkitextratioinsecta,
               TO_CHAR (
                  l_listmkireference (pkg_makroindex.cst_mki_ephemeroptera).mki_counter,
                  '99999'));
         WHEN pkg_exception.cst_mkiplecopteratrichoptera
         -- %p1% Plecoptera, %p2% Trichoptera avec un rapport insectes/non insectes de %p3%
         THEN
            l_plecoandtrico :=
                 l_listmkireference (pkg_makroindex.cst_mki_plecoptera).mki_counter
               + l_listmkireference (pkg_makroindex.cst_mki_trichoptera).mki_counter;
            pkg_importprotocollog.p_writelog (
               p_recimportprotocolheader.iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_mkiplecopteratrichoptera,
               NULL,                                             -- Field name
               TO_CHAR (l_plecoandtrico),
               l_mkitextratioinsecta,
               TO_CHAR (
                  l_listmkireference (pkg_makroindex.cst_mki_plecoptera).mki_counter,
                  '99999'),
               TO_CHAR (
                  l_listmkireference (pkg_makroindex.cst_mki_trichoptera).mki_counter,
                  '99999'));
         WHEN pkg_exception.cst_mkiplecoptera
         --  %p1% Plecoptera a avec un rapport insectes/non insectes de %p2%
         THEN
            pkg_importprotocollog.p_writelog (
               p_recimportprotocolheader.iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_mkiplecoptera,
               NULL,                                             -- Field name
               pkg_makroindex.f_getgblmkirangeselected,
               l_mkitextratioinsecta,
               TO_CHAR (
                  l_listmkireference (pkg_makroindex.cst_mki_plecoptera).mki_counter,
                  '99999'));
         WHEN pkg_exception.cst_mkiunabletocompute
         --Les donnees fournies ne permettent pas le calcul du makroindex: %p1%
         THEN
            l_total :=
                 l_listmkireference (pkg_makroindex.cst_mki_trichoptera).mki_counter
               + l_listmkireference (pkg_makroindex.cst_mki_plecoptera).mki_counter;

            l_list :=
                  'Plecoptera='
               || TO_CHAR (
                     l_listmkireference (pkg_makroindex.cst_mki_plecoptera).mki_counter,
                     '99999')
               || ' Trichopretra='
               || TO_CHAR (
                     l_listmkireference (pkg_makroindex.cst_mki_trichoptera).mki_counter,
                     '99999')
               || 'Plecoptera+Trichoptera='
               || TO_CHAR (
                       l_listmkireference (
                          pkg_makroindex.cst_mki_trichoptera).mki_counter
                     + l_listmkireference (pkg_makroindex.cst_mki_plecoptera).mki_counter,
                     '99999')
               || ' Ephemeroptera='
               || TO_CHAR (
                     l_listmkireference (
                        pkg_makroindex.cst_mki_ephemeroptera).mki_counter,
                     '99999')
               || ' Baetidae='
               || TO_CHAR (
                     l_listmkireference (pkg_makroindex.cst_mki_baetidae).mki_counter,
                     '99999')
               || ' Gammarus='
               || TO_CHAR (
                     l_listmkireference (pkg_makroindex.cst_mki_gammarus).mki_counter,
                     '99999')
               || ' Hydropsyche='
               || TO_CHAR (
                     l_listmkireference (pkg_makroindex.cst_mki_hydropsyche).mki_counter,
                     '99999')
               || ' Asellus='
               || TO_CHAR (
                     l_listmkireference (pkg_makroindex.cst_mki_asellus).mki_counter,
                     '99999')
               || ' Hirudinea='
               || TO_CHAR (
                     l_listmkireference (pkg_makroindex.cst_mki_hirudinea).mki_counter,
                     '99999')
               || ' Tubificidae='
               || TO_CHAR (
                     l_listmkireference (pkg_makroindex.cst_mki_tubificidae).mki_counter,
                     '99999')
               || ' Insecta/NonInsecta='
               || TO_CHAR (l_mkicountinsecta, '9999')
               || '/'
               || TO_CHAR (l_mkinoninsectacount, '9999')
               || '='
               || l_mkitextratioinsecta;
            pkg_importprotocollog.p_writelog (
               p_recimportprotocolheader.iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_mkiunabletocompute,
               NULL,
               l_list);


            NULL;
         ELSE
            RETURN;
      END CASE;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_append2list (p_string      IN VARCHAR2,
                           p_addstring   IN VARCHAR2,
                           p_separator   IN VARCHAR2)
      RETURN VARCHAR2
   /*----------------------------------------------------------------*/
   IS
      l_string   VARCHAR2 (1024);
   BEGIN
      IF p_string IS NULL
      THEN
         l_string := p_addstring;
      ELSE
         l_string := p_string || p_separator || p_addstring;
      END IF;

      RETURN l_string;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_buillisttaxonpresent
      RETURN VARCHAR2
   /*----------------------------------------------------------------*/
   IS
      l_listmkireference   pkg_makroindex.t_listmkireference;
      l_string             VARCHAR2 (1024) := NULL;
   BEGIN
      l_listmkireference := f_getgblmkireference;

      IF l_listmkireference (cst_mki_plecoptera).mki_counter > 0
      THEN
         l_string :=
            f_append2list (
               l_string,
                  cst_mki_plecoptera
               || ' -> '
               || TRIM (
                     TO_CHAR (
                        l_listmkireference (cst_mki_plecoptera).mki_counter)),
               ',');
      END IF;

      IF l_listmkireference (cst_mki_trichoptera).mki_counter > 0
      THEN
         l_string :=
            f_append2list (
               l_string,
                  cst_mki_trichoptera
               || ' -> '
               || TRIM (
                     TO_CHAR (
                        l_listmkireference (cst_mki_trichoptera).mki_counter)),
               ',');
      END IF;

      IF l_listmkireference (cst_mki_ephemeroptera).mki_counter > 0
      THEN
         l_string :=
            f_append2list (
               l_string,
                  cst_mki_ephemeroptera
               || ' -> '
               || TRIM (
                     TO_CHAR (
                        l_listmkireference (cst_mki_ephemeroptera).mki_counter)),
               ',');
      END IF;

      IF l_listmkireference (cst_mki_gammarus).mki_counter > 0
      THEN
         l_string :=
            f_append2list (
               l_string,
                  cst_mki_gammarus
               || ' -> '
               || TRIM (
                     TO_CHAR (
                        l_listmkireference (cst_mki_gammarus).mki_counter)),
               ',');
      END IF;

      IF l_listmkireference (cst_mki_hydropsyche).mki_counter > 0
      THEN
         l_string :=
            f_append2list (
               l_string,
                  cst_mki_hydropsyche
               || ' -> '
               || TRIM (
                     TO_CHAR (
                        l_listmkireference (cst_mki_hydropsyche).mki_counter)),
               ',');
      END IF;

      IF l_listmkireference (cst_mki_asellus).mki_counter > 0
      THEN
         l_string :=
            f_append2list (
               l_string,
                  cst_mki_asellus
               || ' -> '
               || TRIM (
                     TO_CHAR (
                        l_listmkireference (cst_mki_asellus).mki_counter)),
               ',');
      END IF;

      IF l_listmkireference (cst_mki_hirudinea).mki_counter > 0
      THEN
         l_string :=
            f_append2list (
               l_string,
                  cst_mki_hirudinea
               || ' -> '
               || TRIM (
                     TO_CHAR (
                        l_listmkireference (cst_mki_hirudinea).mki_counter)),
               ',');
      END IF;

      IF l_listmkireference (cst_mki_tubificidae).mki_counter > 0
      THEN
         l_string :=
            f_append2list (
               l_string,
                  cst_mki_tubificidae
               || ' -> '
               || TRIM (
                     TO_CHAR (
                        l_listmkireference (cst_mki_tubificidae).mki_counter)),
               ',');
      END IF;

      RETURN l_string;
   END;


   /*--------------------------------------------------------------*/
   PROCEDURE p_logusecasecomputedmakroindex (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_imh_id                    IN importmassdataheader.imh_id%TYPE)
   /*--------------------------------------------------------------*/
   IS
      l_mkicountinsecta             NUMBER;
      l_mkinoninsectacount          NUMBER;
      l_mkierror                    NUMBER;
      l_mkicounter                  NUMBER;
      l_listmkireference            pkg_makroindex.t_listmkireference;
      l_mkitextratioinsecta         VARCHAR2 (1024);
      l_mkiinsectanoninsectaratio   NUMBER;
      l_list                        VARCHAR2 (512);
      l_plecoandtrico               NUMBER;
      l_total                       NUMBER;
      l_mkicvl_code_case            codevalue.cvl_code%TYPE;
      l_indice                      NUMBER;
   BEGIN
      l_mkierror := f_getmkierror;
      l_listmkireference := f_getgblmkireference;
      l_mkicounter := f_getgblmkitotalcounter;
      l_mkiinsectanoninsectaratio := f_getgblmkiinsectaratio;
      l_mkinoninsectacount := f_getmkinoninsectacount;
      l_mkicountinsecta := f_getgblmkiinsectacount;
      l_mkicvl_code_case := f_getmkicvlcodecase;

      IF l_mkiinsectanoninsectaratio =
            pkg_makroindex.cst_insectaratio_zerodivide
      THEN
         l_mkitextratioinsecta := '∞';
      ELSE
         l_mkitextratioinsecta :=
            '=' || TO_CHAR (l_mkiinsectanoninsectaratio, '999.99');
      END IF;


      IF l_mkinoninsectacount = 0
      THEN
         --L'échantillon comporte uniquement des insectes (pas de  non insecte détecté). Le rapport insecte/non insecte est considéré comme plus grand que 6
         pkg_importprotocollog.p_writelog (
            p_recimportprotocolheader.iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_mkihasonlyinsecta,
            NULL                                                 -- Field name
                );
      END IF;


      pkg_importprotocollog.p_writelog (
         p_recimportprotocolheader.iph_id,
         p_imh_id,                                                   -- IMH_ID
         pkg_exception.cst_mkiusecase,
         NULL,                                                   -- Field name
         l_mkicvl_code_case,
            TRIM (TO_CHAR (l_mkicountinsecta))
         || '/'
         || TRIM (TO_CHAR (l_mkinoninsectacount)),
         l_mkitextratioinsecta);

      l_list := f_buillisttaxonpresent;
      pkg_importprotocollog.p_writelog (p_recimportprotocolheader.iph_id,
                                        p_imh_id,                    -- IMH_ID
                                        pkg_exception.cst_info,
                                        NULL,
                                        l_list);                 -- Field name
   END;


   /*--------------------------------------------------------------*/
   PROCEDURE p_logusedcase (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_imh_id                    IN importmassdataheader.imh_id%TYPE,
      p_valueindicemki            IN NUMBER)
   /*-----------------------------------------------------------*/
   IS
   BEGIN
      IF    p_valueindicemki IS NULL
         OR p_valueindicemki = pkg_makroindex.cst_mkinotset
      THEN
         p_logerroroncomputedmakroindex (p_recimportprotocolheader, p_imh_id);
         RETURN;
      ELSE
         p_logusecasecomputedmakroindex (p_recimportprotocolheader, p_imh_id);
      END IF;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_mkiinit
   /*------------------------------------------------------------*/
   IS
   BEGIN
      gbl_mki_non_insecta_count := 0;
      gbl_mki_range_selected := NULL;
      gbl_mki_errornumber := NULL;
      gbl_mki_cvl_code_case := NULL;
      gbl_mki_reference.delete;
      gbl_mki_totalcounter := 0;
      gbl_mki_insectanoninsectaratio := 0;
      gbl_mki_excludetricoptera := 0;
      gbl_mki_makroindexvalue := 0;
      gbl_mki_insecta_count := 0;



      gbl_mki_reference (cst_mki_plecoptera).mki_counter := 0;
      gbl_mki_reference (cst_mki_plecoptera).mki_crf_code :=
         cst_mki_plecoptera_crf_code;



      gbl_mki_reference (cst_mki_trichoptera).mki_counter := 0;
      gbl_mki_reference (cst_mki_trichoptera).mki_crf_code :=
         cst_mki_trichoptera_crf_code;


      gbl_mki_reference (cst_mki_baetidae).mki_counter := 0;
      gbl_mki_reference (cst_mki_baetidae).mki_crf_code :=
         cst_mki_baetidae_crf_code;



      gbl_mki_reference (cst_mki_ephemeroptera).mki_counter := 0;
      gbl_mki_reference (cst_mki_ephemeroptera).mki_crf_code :=
         cst_mki_ephemeroptera_crf_code;



      gbl_mki_reference (cst_mki_gammarus).mki_counter := 0;
      gbl_mki_reference (cst_mki_gammarus).mki_crf_code :=
         cst_mki_gammarus_crf_code;


      gbl_mki_reference (cst_mki_hydropsyche).mki_counter := 0;
      gbl_mki_reference (cst_mki_hydropsyche).mki_crf_code :=
         cst_mki_hydropsyche_crf_code;



      gbl_mki_reference (cst_mki_asellus).mki_counter := 0;
      gbl_mki_reference (cst_mki_asellus).mki_crf_code :=
         cst_mki_asellus_crf_code;



      gbl_mki_reference (cst_mki_hirudinea).mki_counter := 0;
      gbl_mki_reference (cst_mki_hirudinea).mki_crf_code :=
         cst_mki_hirudinea_crf_code;



      gbl_mki_reference (cst_mki_tubificidae).mki_counter := 0;
      gbl_mki_reference (cst_mki_tubificidae).mki_crf_code :=
         cst_mki_tubificidae_crf_code;


      gbl_mki_reference (cst_mki_insecta).mki_counter := 0;
      gbl_mki_reference (cst_mki_insecta).mki_crf_code :=
         cst_mki_insecta_crf_code;
      gbl_mki_totalcounter := 0;
   END;

   /*------------------------------------------------------------------------------*/
   PROCEDURE p_test
   /*-----------------------------------------------------------------------------*/
   IS
      l_key   systdesignation.syd_designation%TYPE;
   BEGIN
      p_mkiinit;
      l_key := gbl_mki_reference.FIRST;

      WHILE NOT l_key IS NULL
      LOOP
         DBMS_OUTPUT.put_line ('L_KEY=' || l_key);
         l_key := gbl_mki_reference.NEXT (l_key);
      END LOOP;
   END;

   /*------------------------------------------------------------*/
   PROCEDURE p_mkiadddata (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_syv_id                    IN sampleprotocollabo.spl_syv_id%TYPE)
   /*------------------------------------------------------------*/
   IS
      /*
        La colonne p_count (freq1)  n'est pas utilisé

       */
      l_syv_id_return              sampleprotocollabo.spl_syv_id%TYPE;
      l_crf_code                   codereference.crf_code%TYPE;
      l_key                        systdesignation.syd_designation%TYPE;
      l_rectricopterascabbard      tricopterascabbard%ROWTYPE;
      l_recsysdesignation          systdesignation%ROWTYPE;
      l_recsysdesignationfamilly   systdesignation%ROWTYPE;
      l_recsystvalueatfamily       systvalue%ROWTYPE;
      l_recabundanceclassrange     abundanceclassrange%ROWTYPE;
      l_found                      BOOLEAN;
      l_reclanguage                language%ROWTYPE;
      l_fullpath                   VARCHAR2 (2048);
      l_value                      NUMBER := 1;        -- On compte toujours 1
      l_noninsecta                 NUMBER := 0;
      l_baetidaefound              BOOLEAN := FALSE;
   BEGIN
      l_key := gbl_mki_reference.FIRST;


      l_baetidaefound := FALSE;

      -- Les clés viennent dans l'ordre alphabétique donc BAetidae vien avant Ephemeroptera
      WHILE NOT l_key IS NULL
      LOOP
         l_syv_id_return :=
            pkg_systdesignation.f_designationisinhierarchy (
               p_syv_id,
               gbl_mki_reference (l_key).mki_crf_code,
               l_key);

         -- Le ephémèroptère doivent être ignoré si ce sont de beatidae
         IF l_key = cst_mki_baetidae AND NOT l_syv_id_return IS NULL
         THEN
            l_baetidaefound := TRUE;
         END IF;

         IF     l_key = cst_mki_ephemeroptera
            AND NOT l_syv_id_return IS NULL
            AND l_baetidaefound
         THEN
            l_syv_id_return := NULL; -- Pour ignorer les ephémetoptere baetidae
         END IF;


         IF l_key = cst_mki_trichoptera AND NOT l_syv_id_return IS NULL
         THEN
            -- Pour les trichopteres on ne prend en compte que ceux qui on un fourreau

            l_recsystvalueatfamily :=
               pkg_systvalue.f_getrecordatlevel (
                  p_syv_id,
                  pkg_codereference.cst_crf_family);

            IF l_recsystvalueatfamily.syv_id IS NULL
            THEN
               -- Ce taxon %p1% est ignoré car il appartient à l''ordre des trichopteres mais il n''est pas possible de déterminer si il dispose d''un fourreau car sa famille n''est pas définie dans le thésaurus
               l_recsysdesignation :=
                  pkg_systdesignation.f_getrecdesignationbylancode (
                     p_syv_id,
                     pkg_language.cst_lan_cde_latin);

               IF NOT p_recimportprotocolheader.iph_id IS NULL
               THEN
                  -- Pas de log
                  pkg_importprotocollog.p_writelog (
                     p_recimportprotocolheader.iph_id,
                     NULL,                                           -- IMH_ID
                     pkg_exception.cst_mkitrichounable2detscabbar,
                     NULL,                                       -- Field name
                     l_recsysdesignation.syd_designation);
               END IF;

               l_syv_id_return := NULL;                        -- Pour ignorer
            ELSE
               -- La famille est déterminée. On va regarder si elle dispose d'un fourreau
               l_rectricopterascabbard :=
                  pkg_tricopterascabbard.f_getrecordbysyvid (
                     l_recsystvalueatfamily.syv_id);

               IF l_rectricopterascabbard.tsd_id IS NULL
               THEN
                  l_recsysdesignationfamilly :=
                     pkg_systdesignation.f_getrecdesignationbylancode (
                        l_recsystvalueatfamily.syv_id,
                        pkg_language.cst_lan_cde_latin);
                  l_recsysdesignation :=
                     pkg_systdesignation.f_getrecdesignationbylancode (
                        p_syv_id,
                        pkg_language.cst_lan_cde_latin);

                  IF NOT p_recimportprotocolheader.iph_id IS NULL
                  THEN
                     -- Pas de log
                     -- Ce taxon %p1% n'est pas pris en compte dans le calcul du nombre de tricoptère sans fourreau car  cette information sur la famille %p2% n'est pas disponible dans le thésaurus
                     pkg_importprotocollog.p_writelog (
                        p_recimportprotocolheader.iph_id,
                        NULL,                                        -- IMH_ID
                        pkg_exception.cst_mkifamillyscabbarnotdefine,
                        NULL,                                    -- Field name
                        l_recsysdesignation.syd_designation,
                        l_recsysdesignationfamilly.syd_designation);
                  END IF;

                  l_syv_id_return := NULL;                     -- Pour ignorer
               ELSE
                  IF l_rectricopterascabbard.tsd_hasscabbard =
                        pkg_constante.cst_no
                  THEN
                     gbl_mki_excludetricoptera :=
                        gbl_mki_excludetricoptera + l_value;
                     l_syv_id_return := NULL; -- Pour ignorer car pas de fourreau
                  END IF;
               END IF;
            END IF;
         END IF;                      -- Fin traitement spécifique TRICHOPTERE



         IF NOT l_syv_id_return IS NULL
         THEN
            gbl_mki_reference (l_key).mki_counter :=
               gbl_mki_reference (l_key).mki_counter + l_value;
         END IF;

         l_key := gbl_mki_reference.NEXT (l_key);
      END LOOP;


      gbl_mki_totalcounter := gbl_mki_totalcounter + l_value;
      gbl_mki_non_insecta_count :=
           gbl_mki_totalcounter
         - gbl_mki_reference (cst_mki_insecta).mki_counter;
      gbl_mki_insecta_count := gbl_mki_reference (cst_mki_insecta).mki_counter;

      IF gbl_mki_non_insecta_count = 0
      THEN
         gbl_mki_insectanoninsectaratio :=
            pkg_makroindex.cst_insectaratio_zerodivide;
      ELSE
         gbl_mki_insectanoninsectaratio :=
              gbl_mki_reference (cst_mki_insecta).mki_counter
            / gbl_mki_non_insecta_count;
      END IF;
   END;



   /*-----------------------------------------------------------------*/
   PROCEDURE p_loaddata (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_recmassdataheader         IN importmassdataheader%ROWTYPE)
   /*-----------------------------------------------------------------*/
   IS
      CURSOR l_massdatadetail (
         p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
      IS
         SELECT *
           FROM importmassdatadetail
          WHERE     imd_imh_id = p_imh_id
                AND imd_validstatus = pkg_constante.cst_validstatusok; -- A ce stade, tout doit être contrôler et le status doit être valide

      l_recmassdatadetail   l_massdatadetail%ROWTYPE;
      l_countexclude        NUMBER;
      l_firstfieldvalue     importmassdatadetail.imd_species%TYPE;
   BEGIN
      p_mkiinit;

      OPEN l_massdatadetail (p_recmassdataheader.imh_id);

      LOOP
         FETCH l_massdatadetail INTO l_recmassdatadetail;

         EXIT WHEN l_massdatadetail%NOTFOUND;
         l_countexclude :=
            pkg_codedesignation.f_countdesignation (
               l_recmassdatadetail.imd_species,
               pkg_codereference.cst_crf_excspekeywor);

         IF l_countexclude > 0
         THEN
            l_firstfieldvalue :=
               pkg_importmassdatadetail.f_returnfirstsystfieldfilled (
                  l_recmassdatadetail);
         ELSE
            l_firstfieldvalue := l_recmassdatadetail.imd_species;
         END IF;

         p_mkiadddata (p_recimportprotocolheader,
                       l_recmassdatadetail.imd_syv_id);
      END LOOP;

      CLOSE l_massdatadetail;
   END;

   /*----------------------------------------------------------*/
   FUNCTION f_mkiparseinsectaratio (p_insectaratio    IN NUMBER,
                                    p_valuelower1     IN NUMBER,
                                    p_value1_2        IN NUMBER,
                                    p_valueupper2_6   IN NUMBER,
                                    p_valueupper6     IN NUMBER)
      RETURN NUMBER
   /*----------------------------------------------------------*/
   IS
      l_value          NUMBER;
      l_insectaratio   NUMBER;
   BEGIN
      IF p_insectaratio = pkg_makroindex.cst_insectaratio_zerodivide
      THEN
         l_insectaratio := 9999;                                            --
      ELSE
         l_insectaratio := p_insectaratio;
      END IF;

      CASE
         WHEN l_insectaratio < 1
         THEN
            l_value := p_valuelower1;
         WHEN l_insectaratio >= 1 AND l_insectaratio <= 2
         THEN
            l_value := p_value1_2;
         WHEN l_insectaratio > 2 AND l_insectaratio <= 6
         THEN
            l_value := p_valueupper2_6;
         WHEN l_insectaratio > 6
         THEN
            l_value := p_valueupper6;
         ELSE
            l_value := NULL;
      END CASE;

      RETURN l_value;
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_mkicheckplecoptcase
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_makroindex               NUMBER;
      l_insectanoninsectaratio   NUMBER;
   BEGIN
      l_insectanoninsectaratio := gbl_mki_insectanoninsectaratio;
      pkg_debug.p_write (
         'mykey',
         'l_insectanoninsectaratio=' || l_insectanoninsectaratio);
      pkg_debug.p_write (
         'mykey',
            'gbl_mki_reference (cst_mki_plecoptera).mki_counter='
         || gbl_mki_reference (cst_mki_plecoptera).mki_counter);

      IF gbl_mki_reference (cst_mki_plecoptera).mki_counter = 0
      THEN
         RETURN NULL;
      END IF;

      IF gbl_mki_reference (cst_mki_plecoptera).mki_counter >= 3
      THEN
         gbl_mki_cvl_code_case := pkg_codevalue.cst_mkicase_plecoptera;

         IF gbl_mki_reference (cst_mki_plecoptera).mki_counter > 4
         THEN
            gbl_mki_range_selected := '>4';
            pkg_debug.p_write (
               'mykey',
               'gbl_mki_range_selected=' || gbl_mki_range_selected);
            l_makroindex :=
               f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                       cst_mkinotset,
                                       cst_mkinotset,
                                       2,
                                       1);
            RETURN l_makroindex;
         ELSIF     gbl_mki_reference (cst_mki_plecoptera).mki_counter >= 3
               AND gbl_mki_reference (cst_mki_plecoptera).mki_counter <= 4
         THEN
            gbl_mki_range_selected := '3-4';
            l_makroindex :=
               f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                       cst_mkinotset,
                                       3,
                                       2,
                                       2);
            RETURN l_makroindex;
         END IF;
      END IF;

      RETURN NULL;
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_mkicheckplecopttricopcase
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_makroindex               NUMBER;
      l_insectanoninsectaratio   NUMBER;
      l_total                    NUMBER;
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
   BEGIN
      l_insectanoninsectaratio := gbl_mki_insectanoninsectaratio;
      l_total :=
           gbl_mki_reference (cst_mki_trichoptera).mki_counter
         + gbl_mki_reference (cst_mki_plecoptera).mki_counter;

      IF l_total = 0
      THEN
         RETURN NULL;
      END IF;


      gbl_mki_cvl_code_case := pkg_codevalue.cst_mkicase_plecotricho;

      IF l_total > 4
      THEN
         gbl_mki_range_selected := '>4';
         l_makroindex :=
            f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                    cst_mkinotset,
                                    3,
                                    3,
                                    3);
         RETURN l_makroindex;
      ELSIF l_total <= 4
      THEN
         gbl_mki_range_selected := '<=4';
         l_makroindex :=
            f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                    5,
                                    4,
                                    3,
                                    3);
         RETURN l_makroindex;
      END IF;

      RETURN NULL;
   END;



   /*-----------------------------------------------------------*/
   FUNCTION f_mkicheckephemeohnebaetidae
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_makroindex               NUMBER;
      l_insectanoninsectaratio   NUMBER;
      l_total                    NUMBER;
   BEGIN
      l_insectanoninsectaratio := gbl_mki_insectanoninsectaratio;



      l_total := gbl_mki_reference (cst_mki_ephemeroptera).mki_counter;

      IF l_total = 0
      THEN
         RETURN NULL;
      END IF;


      gbl_mki_cvl_code_case := pkg_codevalue.cst_mkicase_ephemeropter;

      IF l_total > 2
      THEN
         gbl_mki_range_selected := '>2';
         l_makroindex :=
            f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                    5,
                                    4,
                                    4,
                                    3);
         RETURN l_makroindex;
      ELSIF l_total <= 2
      THEN
         gbl_mki_range_selected := '>=2';
         l_makroindex :=
            f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                    6,
                                    5,
                                    5,
                                    cst_mkinotset);
         RETURN l_makroindex;
      END IF;


      RETURN NULL;
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_mkicheckgammarus
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_makroindex               NUMBER;
      l_insectanoninsectaratio   NUMBER;
      l_total                    NUMBER;
   BEGIN
      l_insectanoninsectaratio := gbl_mki_insectanoninsectaratio;
      l_total :=
           gbl_mki_reference (cst_mki_gammarus).mki_counter
         + gbl_mki_reference (cst_mki_hydropsyche).mki_counter;

      IF l_total = 0
      THEN
         RETURN NULL;
      END IF;

      gbl_mki_cvl_code_case := pkg_codevalue.cst_mkicase_gammarus;
      gbl_mki_range_selected := NULL;
      l_makroindex :=
         f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                 7,
                                 6,
                                 5,
                                 cst_mkinotset);
      RETURN l_makroindex;
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_mkicheckasellus
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_makroindex               NUMBER;
      l_insectanoninsectaratio   NUMBER;
      l_total                    NUMBER;
   BEGIN
      l_insectanoninsectaratio := gbl_mki_insectanoninsectaratio;
      l_total :=
           gbl_mki_reference (cst_mki_asellus).mki_counter
         + gbl_mki_reference (cst_mki_hirudinea).mki_counter
         + gbl_mki_reference (cst_mki_tubificidae).mki_counter;

      IF l_total = 0
      THEN
         RETURN NULL;
      END IF;

      gbl_mki_cvl_code_case := pkg_codevalue.cst_mkicase_asellus;
      gbl_mki_range_selected := NULL;
      l_makroindex :=
         f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                 8,
                                 7,
                                 cst_mkinotset,
                                 cst_mkinotset);
      RETURN l_makroindex;
   END;



   /*-----------------------------------------------------------*/
   FUNCTION f_computemakroindex
      RETURN NUMBER
   /*------------------------------------------------------------*/
   IS
      l_insectanoninsectaratio   NUMBER;
      l_countnonisecta           NUMBER;
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
      l_mkiindex                 NUMBER;
   BEGIN
      gbl_mki_errornumber := NULL;
      gbl_mki_cvl_code_case := NULL;
      gbl_mki_normalizedcount := NULL;

      IF gbl_mki_totalcounter = 0
      THEN
         RETURN NULL;
      END IF;

      l_mkiindex := f_mkicheckplecoptcase;

      IF NOT l_mkiindex IS NULL
      THEN
         IF l_mkiindex = cst_mkinotset
         THEN
            gbl_mki_errornumber := pkg_exception.cst_mkiplecoptera;
         END IF;

         RETURN l_mkiindex;
      END IF;

      l_mkiindex := f_mkicheckplecopttricopcase;

      IF NOT l_mkiindex IS NULL
      THEN
         IF l_mkiindex = cst_mkinotset
         THEN
            gbl_mki_errornumber := pkg_exception.cst_mkiplecopteratrichoptera;
         END IF;

         RETURN l_mkiindex;
      END IF;

      l_mkiindex := f_mkicheckephemeohnebaetidae;

      IF NOT l_mkiindex IS NULL
      THEN
         IF l_mkiindex = cst_mkinotset
         THEN
            gbl_mki_errornumber :=
               pkg_exception.cst_mkiephemeropterawithoutbae;
         END IF;

         RETURN l_mkiindex;
      END IF;

      l_mkiindex := f_mkicheckgammarus;

      IF NOT l_mkiindex IS NULL
      THEN
         IF l_mkiindex = cst_mkinotset
         THEN
            gbl_mki_errornumber := pkg_exception.cst_mkigammarushydropsyche;
         END IF;

         RETURN l_mkiindex;
      END IF;

      l_mkiindex := f_mkicheckasellus;

      IF NOT l_mkiindex IS NULL
      THEN
         IF l_mkiindex = cst_mkinotset
         THEN
            gbl_mki_errornumber :=
               pkg_exception.cst_mkiasselushirudinaeturbifi;
         END IF;

         gbl_mki_makroindexvalue := l_mkiindex;

         RETURN l_mkiindex;
      END IF;

      gbl_mki_errornumber := pkg_exception.cst_mkiunabletocompute;
      RETURN NULL;
   END;

   /*--------------------------------------------------------------------------------------*/
   PROCEDURE p_maincompute (
      p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_recmassdataheader         IN     importmassdataheader%ROWTYPE,
      p_mkiindice                    OUT NUMBER)
   /*--------------------------------------------------------------------------------------*/
   IS
      l_ptv_id      protocolversion.ptv_id%TYPE;
      l_mkiindice   NUMBER := 0;
   BEGIN
      l_ptv_id := p_recimportprotocolheader.iph_ptv_id;
      p_loaddata (p_recimportprotocolheader, p_recmassdataheader);

      IF f_getgblmkitotalcounter = 0
      THEN
         p_mkiindice := NULL;
         RETURN;                                    -- Pas de données chargées
      END IF;

      l_mkiindice := f_computemakroindex;
      p_logusedcase (p_recimportprotocolheader,
                     p_recmassdataheader.imh_id,
                     l_mkiindice);
      p_mkiindice := l_mkiindice;
   END;
END pkg_makroindex;
/

