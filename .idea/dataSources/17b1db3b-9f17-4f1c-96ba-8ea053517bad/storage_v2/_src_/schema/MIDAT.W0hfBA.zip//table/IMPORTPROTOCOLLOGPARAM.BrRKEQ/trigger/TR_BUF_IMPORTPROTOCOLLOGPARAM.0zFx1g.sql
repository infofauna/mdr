create trigger TR_BUF_IMPORTPROTOCOLLOGPARAM
    before update
    on IMPORTPROTOCOLLOGPARAM
    for each row
DECLARE
BEGIN
 
   :new.ipr_moddate := SYSDATE;
   :new.ipr_moduser := USER;
END tr_buf_IMPORTPROTOCOLLOGPARAM;

/

