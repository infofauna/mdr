create trigger TR_BIF_SAMPLEPROTOCOLGRID
    before insert
    on SAMPLEPROTOCOLGRID
    for each row
DECLARE
BEGIN
   IF :new.SPG_id IS NULL
   THEN
      :new.SPG_id := seq_SAMPLEPROTOCOLLABO.NEXTVAL;
   END IF; 

   :new.SPG_credate := SYSDATE;
   :new.SPG_creuser := USER;
END tr_bif_SAMPLEPROTOCOLGRID;

/

