create PACKAGE       pkg_gis
AS
   /******************************************************************************
      NAME:       PKG_GIS
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2015      burrif       1. Created this package.
   ******************************************************************************/

   cst_elevationtolerance         CONSTANT NUMBER := 10;          -- 10 Mètres
   cst_distancetolgewiss          CONSTANT NUMBER := 10; -- On chercher une rivière dans le GWN25 a une distance max de 10 mètres
   cst_othernotindeltatolerance   CONSTANT NUMBER := 10; -- Il ne doit pas y avoir d'autre point à moins de 10 mètres avec un GEWISSNR  différents


   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_returncanton (p_coordinates IN SDO_GEOMETRY)
      RETURN ch_canton.code%TYPE;

   FUNCTION f_returnname (p_gewissnr IN ch_gwn25.gewissnr%TYPE)
      RETURN ch_gwn25.name%TYPE;

   FUNCTION f_returngewissnrbyname (p_name IN ch_gwn25.name%TYPE)
      RETURN ch_gwn25.gewissnr%TYPE;

   PROCEDURE p_checkorigineelevation (
      p_iph_id            IN importmassdataheader.imh_iph_id%TYPE,
      p_cvl_code_origin   IN codevalue.cvl_code%TYPE);

   PROCEDURE p_returnelevation (
      p_x                 IN     NUMBER,
      p_y                 IN     NUMBER,
      p_elevation            OUT NUMBER,
      p_cvl_code_origin      OUT codevalue.cvl_code%TYPE,
      p_returnstatus         OUT NUMBER);

   PROCEDURE p_returngewiss (p_x              IN     NUMBER,
                             p_y              IN     NUMBER,
                             p_ch_gwn25          OUT ch_gwn25%ROWTYPE, -- Record le plus proche
                             p_distance          OUT NUMBER, -- Distance du record le plus proche au poin donnée
                             p_returnstatus      OUT NUMBER);

   PROCEDURE p_returngewiss (
      p_x                          IN     NUMBER,
      p_y                          IN     NUMBER,
      p_distancetolerance          IN     NUMBER,
      p_othernotindeltatolerance   IN     NUMBER,
      p_ch_gwn25                      OUT ch_gwn25%ROWTYPE,
      p_distance                      OUT NUMBER,
      p_returnstatus                  OUT NUMBER);
END pkg_gis;
/

