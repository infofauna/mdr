create trigger TR_BUF_SAMPLELOADCOMMENT
    before update
    on SAMPLELOADCOMMENT
    for each row
BEGIN
   :new.slc_moddate := SYSDATE;
   :new.slc_moduser := USER;
END;

/

