create PACKAGE       pkg_migr_speardatalinkcscf
AS
   /******************************************************************************
      NAME:       PKG_MIGR_SPEARDATALINKCSCF
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.10.2017      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_setversion1;
END pkg_migr_speardatalinkcscf;
/

