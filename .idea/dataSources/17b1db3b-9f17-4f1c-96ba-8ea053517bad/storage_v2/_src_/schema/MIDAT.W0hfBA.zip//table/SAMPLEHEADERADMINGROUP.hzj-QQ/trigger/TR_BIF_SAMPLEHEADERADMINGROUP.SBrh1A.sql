create trigger TR_BIF_SAMPLEHEADERADMINGROUP
    before insert
    on SAMPLEHEADERADMINGROUP
    for each row
DECLARE
BEGIN
   IF :new.SHG_id IS NULL
   THEN
      :new.SHG_id := SEQ_SAMPLEHEADERADMINGROUP.NEXTVAL;
   END IF;

   :new.SHG_credate := SYSDATE;
   :new.SHG_creuser := USER;
END tr_bif_SAMPLEHEADERADMINGROUP;

/

