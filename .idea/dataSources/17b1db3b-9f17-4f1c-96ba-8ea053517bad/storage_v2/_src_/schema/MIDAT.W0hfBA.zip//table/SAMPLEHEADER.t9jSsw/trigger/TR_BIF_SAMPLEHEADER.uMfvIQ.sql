create trigger TR_BIF_SAMPLEHEADER
    before insert
    on SAMPLEHEADER
    for each row
DECLARE
BEGIN
   IF :new.sph_id IS NULL
   THEN
      :new.sph_id := seq_sampleheader.NEXTVAL;
   END IF;

   :new.sph_credate := SYSDATE;
   :new.sph_creuser := USER;
END tr_bif_sampleheader;

/

