create trigger TR_BIF_SAMPLEHEADERMASSFILE
    before insert
    on SAMPLEHEADERMASSFILE
    for each row
DECLARE
BEGIN
   IF :new.SMF_id IS NULL
   THEN
      :new.SMF_id := seq_SAMPLEHEADERMASSFILE.NEXTVAL;
   END IF;

   :new.SMF_credate := SYSDATE;
   :new.SMF_creuser := USER;
END tr_bif_SAMPLEHEADERMASSFILE;

/

