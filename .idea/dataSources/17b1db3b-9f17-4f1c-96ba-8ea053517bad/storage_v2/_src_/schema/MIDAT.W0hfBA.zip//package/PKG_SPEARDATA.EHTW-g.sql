create PACKAGE       pkg_speardata
AS
   /******************************************************************************
      NAME:       PKG_SPEARDATA
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25/07/2014      burrif       1. Created this package.
   ******************************************************************************/
   cst_level_species   CONSTANT speardata.sra_level%TYPE := 'species';
   cst_level_genus     CONSTANT speardata.sra_level%TYPE := 'genus';
   cst_level_family    CONSTANT speardata.sra_level%TYPE := 'family';
   cst_level_group     CONSTANT speardata.sra_level%TYPE := 'group';

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_test;

   PROCEDURE p_build;

   FUNCTION f_getrecordbyaqem_id (p_aqem_id IN speardata.sra_aqem_id%TYPE)
      RETURN speardata%ROWTYPE;

   PROCEDURE p_write (p_sra_sra_id           speardata.sra_sra_id%TYPE,
                      p_wls_id        IN     speardata.sra_wls_id%TYPE,
                      p_aqem_id       IN     speardata.sra_aqem_id%TYPE,
                      p_level         IN     speardata.sra_level%TYPE,
                      p_designation   IN     speardata.sra_designation%TYPE,
                      p_spearvalue    IN     speardata.sra_spearvalue%TYPE,
                      p_gt_source     IN     speardata.sra_gt_source%TYPE,
                      p_sens          IN     speardata.sra_sens%TYPE,
                      p_senssource    IN     speardata.sra_senssource%TYPE,
                      p_mig           IN     speardata.sra_mig%TYPE,
                      p_migsource     IN     speardata.sra_migsource%TYPE,
                      p_out           IN     speardata.sra_out%TYPE,
                      p_outsource     IN     speardata.sra_outsource%TYPE,
                      p_gtcode        IN     speardata.sra_gtcode%TYPE,
                      p_senscode      IN     speardata.sra_senscode%TYPE,
                      p_migcode       IN     speardata.sra_migcode%TYPE,
                      p_expcode       IN     speardata.sra_expcode%TYPE,
                      p_id               OUT speardata.sra_id%TYPE);
END pkg_speardata;
/

