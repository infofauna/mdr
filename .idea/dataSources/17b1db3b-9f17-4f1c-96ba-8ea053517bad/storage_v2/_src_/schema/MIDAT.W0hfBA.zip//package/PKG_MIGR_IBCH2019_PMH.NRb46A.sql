create PACKAGE       pkg_migr_ibch2019_pmh
AS
    /******************************************************************************
      NAME:       PKG_MIGR_IBCH2019_PMH
      PURPOSE:    Modification dans la table PROTOCOLMAPPINGHEADER

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       15.05.2020  F.Burri           1. Created this package
   ******************************************************************************/

    cst_packageversion   VARCHAR2 (30) := 'Version 1.0, mai 2020';

    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_copydata (
        p_ptv_id_src    IN protocolmappingheader.pmh_ptv_id%TYPE,
        p_ptv_id_dest   IN protocolmappingheader.pmh_ptv_id%TYPE);

    PROCEDURE p_deletedata (
        p_ptv_id_dest   IN protocolmappingheader.pmh_ptv_id%TYPE);

    PROCEDURE p_addnewdata (
        p_ptv_id   IN protocolmappingheader.pmh_ptv_id%TYPE);

    PROCEDURE p_updatechangemapping (
        p_ptv_id_dest   IN protocolmappingheader.pmh_ptv_id%TYPE);
END pkg_migr_ibch2019_pmh;
/

