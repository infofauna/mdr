create PACKAGE BODY       pkg_migr_indiceversion
AS
   /******************************************************************************
      NAME:       PKG_MIGR_INDICEVERSION
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        05.10.2017      burrif       1. Created this package.
   ******************************************************************************/



   cst_packageversion   VARCHAR2 (30) := 'Version 2.0, juillet 2017';

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_buildspear
   /*----------------------------------------------------------------*/
   IS
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_spear);

      INSERT INTO indiceversion (ivr_cvl_id_midatindice,
                                 ivr_current,
                                 ivr_version,
                                 ivr_designation)
           VALUES (l_reccodevalue.cvl_id,
                   pkg_constante.cst_yes,
                   'SPEAR 2014',
                   'Version 2014');

      INSERT INTO indiceversion (ivr_cvl_id_midatindice,
                                 ivr_current,
                                 ivr_version,
                                 ivr_designation)
              VALUES (
                        l_reccodevalue.cvl_id,
                        NULL,
                        '2017',
                        'Version 2017: basé sur le fichier MIDAT_INDICE_CSCF_20171003.xls ');
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_buildibch
   /*----------------------------------------------------------------*/
   IS
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_ibch);

      INSERT INTO indiceversion (ivr_cvl_id_midatindice,
                                 ivr_current,
                                 ivr_version,
                                 ivr_designation)
              VALUES (
                        l_reccodevalue.cvl_id,
                        pkg_constante.cst_yes,
                        'IBCH 2010',
                        'Version IBCH 2010: Réf: Stucki P. 2010 Méthode d''analyse et d''appréciation des cours d''eau en Suisse. Macrozoobenthos - niveau R. Office fédérale de l''environement, Berne ');
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_buildmakroindex
   /*----------------------------------------------------------------*/
   IS
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_makroindex);

      INSERT INTO indiceversion (ivr_cvl_id_midatindice,
                                 ivr_current,
                                 ivr_version,
                                 ivr_designation)
              VALUES (
                        l_reccodevalue.cvl_id,
                        pkg_constante.cst_yes,
                        'MAKROINDEX 2005',
                        'Version MAKROINDEX 2005: Réf: Makroinvertebraten: taxonomiche Zussammensetzung des Makrozoobenthos, Sharon Woolsey, Eawag (basierend auf BUWAL 2005)');
   END;
END pkg_migr_indiceversion;
/

