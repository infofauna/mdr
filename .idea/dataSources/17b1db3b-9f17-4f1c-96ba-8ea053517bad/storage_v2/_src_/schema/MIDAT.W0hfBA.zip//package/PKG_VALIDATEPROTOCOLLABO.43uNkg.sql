create PACKAGE       pkg_validateprotocollabo
AS
   /******************************************************************************
      NAME:       PKG_VALIDATEPROTOCOLLABO
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
      1.1        19.08.2020      burrif       2. Externalisation Jav (indice calculé dans PKG_VALIDATE_V1  
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;
       PROCEDURE p_validatedetail (
      p_iph_id         IN     importprotocollog.ipo_iph_id%TYPE,
      p_usr_id         IN     importprotocollabo.ipl_usr_id_create%TYPE,
      p_returnstatus      OUT NUMBER);

  
END pkg_validateprotocollabo;
/

