create PACKAGE BODY       PKG_SPEARDATALINKCSCFLOAD AS
/******************************************************************************
   NAME:       PKG_SPEARDATALINKCSCFLOAD
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        05.10.2017      burrif       1. Created this package.
******************************************************************************/

 
   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.1, septembre  2017' ;


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;
 
    
    


END PKG_SPEARDATALINKCSCFLOAD;
/

