create PACKAGE BODY       pkg_migr_ibch2019_ivr
AS
    /******************************************************************************
       NAME:       pkg_migr_ibch2019_ivr
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
    ******************************************************************************/
    TYPE t_list IS TABLE OF indiceversion.ivr_version%TYPE;

    cst_listversionspear   CONSTANT t_list
        := t_list ('SPEAR2019', 'SPEAR 2017', 'SPEAR 2014') ;
    cst_listversionibch    CONSTANT t_list
                                        := t_list ('IBCH2019', 'IBCH 2010') ;

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_updateorder_spear
    /*------------------------------------------------------------------*/
    IS
        l_recindiceversion          indiceversion%ROWTYPE;
        l_recindiceversion_parent   indiceversion%ROWTYPE;
        l_indice                    PLS_INTEGER;
        l_first                     BOOLEAN := TRUE;
    BEGIN
        l_indice := cst_listversionspear.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            l_recindiceversion :=
                pkg_indiceversion.f_getrecordbyversion (
                    cst_listversionspear (l_indice),
                    pkg_codevalue.cst_midatindice_spear);

            IF l_recindiceversion.ivr_id IS NULL
            THEN
                raise_application_error (
                    -20000,
                       'Version: '
                    || cst_listversionspear (l_indice)
                    || ' non trouvé',
                    TRUE);
            END IF;

            IF l_first
            THEN
                l_recindiceversion_parent := l_recindiceversion;
                l_first := FALSE;
            ELSE
                UPDATE indiceversion
                   SET ivr_ivr_id = l_recindiceversion_parent.ivr_id
                 WHERE ivr_id = l_recindiceversion.ivr_id;

                l_recindiceversion_parent := l_recindiceversion;
            END IF;

            l_indice := cst_listversionspear.NEXT (l_indice);
        END LOOP;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_updateorder_ibch
    /*------------------------------------------------------------------*/
    IS
        l_recindiceversion          indiceversion%ROWTYPE;
        l_recindiceversion_parent   indiceversion%ROWTYPE;
        l_indice                    PLS_INTEGER;
        l_first                     BOOLEAN := TRUE;
    BEGIN
        l_indice := cst_listversionibch.FIRST;

        WHILE NOT l_indice IS NULL
        LOOP
            l_recindiceversion :=
                pkg_indiceversion.f_getrecordbyversion (
                    cst_listversionibch (l_indice),
                    pkg_codevalue.cst_midatindice_ibch);

            IF l_recindiceversion.ivr_id IS NULL
            THEN
                raise_application_error (
                    -20000,
                       'Version: '
                    || cst_listversionspear (l_indice)
                    || ' non trouvé',
                    TRUE);
            END IF;

            IF l_first
            THEN
                l_recindiceversion_parent := l_recindiceversion;
                l_first := FALSE;
            ELSE
                UPDATE indiceversion
                   SET ivr_ivr_id = l_recindiceversion_parent.ivr_id
                 WHERE ivr_id = l_recindiceversion.ivr_id;

                l_recindiceversion_parent := l_recindiceversion;
            END IF;

            l_indice := cst_listversionibch.NEXT (l_indice);
        END LOOP;
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_update_current
    /*------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE indiceversion
           SET ivr_current = pkg_constante.cst_no;

        UPDATE indiceversion
           SET ivr_current = pkg_constante.cst_yes
         WHERE ivr_ivr_id IS NULL;
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_updateorder
    /*------------------------------------------------------------*/
    IS
    BEGIN
        p_updateorder_ibch;
        p_updateorder_spear;
        p_update_current;
    END;


    /*------------------------------------------------------------------*/
    PROCEDURE p_addindiceversion (p_newversiontext              IN VARCHAR2,
                                  p_newibchindiceversion        IN VARCHAR2,
                                  p_newibchindicedesignation    IN VARCHAR2,
                                  p_newspearindiceversion       IN VARCHAR2,
                                  p_newspearindicedesignation   IN VARCHAR2) /*------------------------------------------------------------------*/
    IS
        l_reccodevalue         codevalue%ROWTYPE;
        l_recprotocolversion   protocolversion%ROWTYPE;
        l_id                   indiceversion.ivr_id%TYPE;
    BEGIN
        l_recprotocolversion :=
            pkg_migr_ibch2019_ptv.f_returnversionbytext (p_newversiontext);

        IF l_recprotocolversion.ptv_id IS NULL
        THEN
            raise_application_error (
                -20000,
                'Protocol version: ' || p_newversiontext || ' non trouvé',
                TRUE);
        END IF;

        pkg_migr_ibch2019_ivr.p_write (pkg_constante.cst_yes, -- p_current      ,
                                       pkg_codevalue.cst_midatindice_ibch, -- p_midatindice   ,
                                       l_recprotocolversion.ptv_id, -- p_ptv_id,
                                       p_newibchindiceversion,    --p_version,
                                       p_newibchindicedesignation, --p_designation,
                                       l_id);

        pkg_migr_ibch2019_ivr.p_write (pkg_constante.cst_yes, -- p_current      ,
                                       pkg_codevalue.cst_midatindice_spear, -- p_midatindice   ,
                                       l_recprotocolversion.ptv_id, -- p_ptv_id,
                                       p_newspearindiceversion,   --p_version,
                                       p_newspearindicedesignation, --p_designation,
                                       l_id);
    END;

    /*------------------------------------------------------------------------*/
    PROCEDURE p_addcolumn
    /*------------------------------------------------------------------------*/
    IS
        l_done   BOOLEAN;
        l_sql    VARCHAR2 (1024);
    BEGIN
        pkg_migr_ibch2019_util.p_addcolumn ('indiceversion',
                                            'ivr_ivr_id',
                                            'number',
                                            NULL,
                                            l_done);

        IF pkg_migr_ibch2019_util.f_checkconstraintexist ('indiceversion',
                                                          'FK_IVR_IVR_ID') =
           0
        THEN
            l_sql :=
                'CREATE INDEX MIDAT.IDX_IVR_IVR_ID ON MIDAT.INDICEVERSION
(IVR_IVR_ID)
LOGGING
TABLESPACE MIDAT_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL';

            EXECUTE IMMEDIATE l_sql;

            l_sql :=
                'alter table indiceversion ADD  CONSTRAINT FK_IVR_IVR_ID 
  FOREIGN KEY (IVR_IVR_ID) 
  REFERENCES MIDAT.INDICEVERSION (IVR_ID)
  ENABLE VALIDATE';

            EXECUTE IMMEDIATE l_sql;
        END IF;
    END;



    /*------------------------------------------------------------------*/
    PROCEDURE p_write (
        p_current       IN     indiceversion.ivr_current%TYPE,
        p_midatindice   IN     codevalue.cvl_code%TYPE,
        p_ptv_id        IN     indiceversion.ivr_ptv_id%TYPE,
        p_version       IN     indiceversion.ivr_version%TYPE,
        p_designation          indiceversion.ivr_designation%TYPE,
        p_id               OUT indiceversion.ivr_id%TYPE)
    /*--------------------------------------------------------------------*/
    IS
        l_reccodevalue       codevalue%ROWTYPE;
        l_recindiceversion   indiceversion%ROWTYPE;
    BEGIN
        l_reccodevalue :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_midatindice,
                p_midatindice);

        IF l_reccodevalue.cvl_id IS NULL
        THEN
            raise_application_error (-20000,
                                     'P_MIDATINDICE non reconnu',
                                     TRUE);
        END IF;

        l_recindiceversion :=
            pkg_indiceversion.f_getrecordbyversion (p_version, p_midatindice);

        IF l_recindiceversion.ivr_id IS NULL
        THEN
            pkg_indiceversion.p_write (p_current,
                                       l_reccodevalue.cvl_id,
                                       p_ptv_id,
                                       p_version,
                                       p_designation,
                                       p_id);
        END IF;
    END;
END;
/

