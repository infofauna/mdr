create PACKAGE BODY       pkg_excel
AS
   /******************************************************************************
      NAME:       PKG_EXCEL
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.10.2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion    CONSTANT VARCHAR2 (30)
                                     := 'Version 1.0, octobre  2013' ;
   cst_memorysize4mass   CONSTANT NUMBER := 1024 * 1024 * 1024;         -- 1Gb


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_buildsheetlist (
      p_blob         IN     BLOB,
      p_sheetlist       OUT pkg_worksheetlist.t_cursor,
      p_sheetcount      OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      l_worksheetgroup_id   NUMBER;
      l_size                NUMBER;
   BEGIN
      l_size := pkg_java.f_setmaxmemorysize (1024 * 1024 * 1024);
      l_worksheetgroup_id := pkg_java.f_buildlistsheet (p_blob);

      IF (l_worksheetgroup_id = pkg_constante.cst_returnstatusnotok)
      THEN
         RETURN;
      END IF;

      pkg_worksheetlist.p_listsheetname (l_worksheetgroup_id,
                                         p_sheetlist,
                                         p_sheetcount);
   END;

   /*------------------------------------------------------------*/
   PROCEDURE p_testbuildlistsheet (
      p_iph_id   IN importprotocolheader.iph_id%TYPE)
   /*-------------------------------------------------------------*/
   IS
      l_blob                BLOB;
      l_worksheetgroup_id   NUMBER;
      l_sheetlist           pkg_worksheetlist.t_cursor;
      l_sheetcount          NUMBER;
      l_sheetname           VARCHAR2 (256);
      l_sheetnumber         NUMBER;
   BEGIN
      DBMS_JAVA.set_output (50);

      SELECT iph_file
        INTO l_blob
        FROM importprotocolheader
       WHERE iph_id = p_iph_id;

      pkg_excel.p_buildsheetlist (l_blob, l_sheetlist, l_sheetcount);

      DBMS_OUTPUT.put_line ('SHEET_COUNT=' || TO_CHAR (l_sheetcount));

      LOOP
         FETCH l_sheetlist INTO l_sheetnumber, l_sheetname;

         EXIT WHEN l_sheetlist%NOTFOUND;
         DBMS_OUTPUT.put_line (
               'SHEET NUMBER='
            || TO_CHAR (l_sheetnumber)
            || ' SHEETNAME='
            || l_sheetname);
      END LOOP;
   END;
END pkg_excel;
/

