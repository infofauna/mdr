create PACKAGE       pkg_samplemkidetailgroup
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEMKIDETAILGROUP
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.02.2015      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_deleteby_sph_id (
      p_sph_id   IN samplemkidetailgroup.mkd_sph_id%TYPE);

   PROCEDURE p_deleteby_iph_id (p_iph_id IN importprotocolheader.iph_id%TYPE);

   PROCEDURE p_deleteby_imh_id (
      p_imh_id   IN samplemkidetailgroup.mkd_imh_id%TYPE);

   PROCEDURE p_flushmkidispatchlist (
      p_imh_id         IN samplemkidetailgroup.mkd_imh_id%TYPE,
      p_mkipatchlist   IN pkg_indice_utility.t_mkidispatchlist);

   PROCEDURE p_setlink2sampleheader (
      p_imh_id   IN samplemkidetailgroup.mkd_imh_id%TYPE,
      p_sph_id   IN samplemkidetailgroup.mkd_sph_id%TYPE);

   PROCEDURE p_write (
      p_imh_id                IN     samplemkidetailgroup.mkd_imh_id%TYPE,
      p_sph_id                IN     samplemkidetailgroup.mkd_sph_id%TYPE,
      p_syv_id_group          IN     samplemkidetailgroup.mkd_syv_id_group%TYPE,
      p_syv_id_inferedfrom    IN     samplemkidetailgroup.mkd_syv_id_inferedfrom%TYPE,
      p_unspeciefiedspecies   IN     samplemkidetailgroup.mkd_unspeciefiedspecies%TYPE,
      p_id                       OUT samplemkidetailgroup.mkd_id%TYPE);
END pkg_samplemkidetailgroup;
/

