create PACKAGE       pkg_sampleprotocollabo
AS
   /******************************************************************************
      NAME:       pkg_sampleprotocollabo
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.10.2013   F.Burri          1. Created this package.
      1.1       12.10.2017  F. Burri          2. Version 2 MIDAT
   ******************************************************************************/



   cst_packageversion   VARCHAR2 (30) := 'Version 1.1, octobre  2017';

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_recomputespearindex (p_flag IN VARCHAR2);

   PROCEDURE p_recomputeibchindex (p_flag IN VARCHAR2);

   PROCEDURE p_recomputemakroindex (p_flag IN VARCHAR2);


   PROCEDURE p_routeupdatesortorder (
      p_sph_id   IN sampleprotocollabo.spl_sph_id%TYPE);

   PROCEDURE p_deleteby_sph_id (p_sph_id IN sampleheader.sph_id%TYPE);

   FUNCTION f_getrecord (p_spl_id IN sampleprotocollabo.spl_id%TYPE)
      RETURN sampleprotocollabo%ROWTYPE;

   PROCEDURE p_tr_bif_sampleprotocollabo (
      p_newrec   IN OUT sampleprotocollabo%ROWTYPE);

   PROCEDURE p_tr_buf_sampleprotocollabo (
      p_oldrec   IN     sampleprotocollabo%ROWTYPE,
      p_newrec   IN OUT sampleprotocollabo%ROWTYPE);

   PROCEDURE p_writeorupdate (
      p_sph_id                IN     sampleprotocollabo.spl_sph_id%TYPE,
      p_ptl_id                IN     sampleprotocollabo.spl_ptl_id%TYPE,
      p_syv_id                IN     sampleprotocollabo.spl_syv_id%TYPE,
      p_cvl_id_zoostadium     IN     sampleprotocollabo.spl_cvl_id_zoostadium%TYPE,
      p_frequency             IN     sampleprotocollabo.spl_frequency%TYPE,
      p_frequencymodified     IN     sampleprotocollabo.spl_frequencymodified%TYPE,
      p_freqlum               IN     sampleprotocollabo.spl_freqlum%TYPE,
      p_stadium               IN     sampleprotocollabo.spl_stadium%TYPE,
      p_sampleno              IN     sampleprotocollabo.spl_sampleno%TYPE,
      p_comment               IN     sampleprotocollabo.spl_comment%TYPE,
      p_unidentifiedspecies   IN     sampleprotocollabo.spl_unidentifiedspecies%TYPE,
      p_usr_id                IN     sampleprotocollabo.spl_usr_id_create%TYPE,
      p_spl_id                   OUT sampleprotocollabo.spl_id%TYPE);
END pkg_sampleprotocollabo;
/

