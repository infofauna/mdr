create PACKAGE       pkg_hydroregime
AS
    /******************************************************************************
       NAME:       pkg_hydroregime
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        3.07.2020      burrif       1. Created this package.
    ******************************************************************************/


    FUNCTION f_getversion
        RETURN VARCHAR2;

    FUNCTION f_getrecord (p_hdr_id IN hydroregime.hdr_id%TYPE)
        RETURN hydroregime%ROWTYPE;

    FUNCTION f_getrecordbyibch_q_id (
        p_hdr_cvl_id_ibch_q   IN hydroregime.hdr_cvl_id_ibch_q%TYPE)
        RETURN hydroregime%ROWTYPE;

    FUNCTION f_getrecordbyibch_q_code (p_ibch_q IN codevalue.cvl_code%TYPE)
        RETURN hydroregime%ROWTYPE;

    FUNCTION f_getrecordbycode (p_code IN hydroregime.hdr_code%TYPE)
        RETURN hydroregime%ROWTYPE;

    PROCEDURE p_write (
        p_code            IN     hydroregime.hdr_code%TYPE,
        p_cvl_id_ibch_q   IN     hydroregime.hdr_cvl_id_ibch_q%TYPE,
        p_hdr_order       IN     hydroregime.hdr_order%TYPE,
        p_hdr_value       IN     hydroregime.hdr_value%TYPE,
        p_hdr_id             OUT hydroregime.hdr_id%TYPE);

    PROCEDURE p_writewithcode (
        p_ibch_q      IN     codevalue.cvl_code%TYPE,
        p_hdr_order   IN     hydroregime.hdr_order%TYPE,
        p_hdr_value   IN     hydroregime.hdr_value%TYPE,
        p_hdr_id         OUT hydroregime.hdr_id%TYPE);
END pkg_hydroregime;
/

