create PACKAGE BODY       pkg_speardatalinkcscf
AS
   /******************************************************************************
      NAME:       PKG_SPEARDATALINKCSCF
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25/07/2014      burrif       1. Created this package.
      2.0        05.10.2017       burrif       2. Nouveau calcul de spear avec version
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 2.0, octobre  2017' ;
   cst_version2014      CONSTANT indiceversion.ivr_version%TYPE
                                    := 'SPEAR 2014' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;



   /*-----------------------------------------------------------------*/
   FUNCTION f_getrecordby_spv_id (
      p_ivr_id   IN speardatalinkcscf.sdf_ivr_id%TYPE,
      p_syv_id   IN speardatalinkcscf.sdf_syv_id%TYPE)
      RETURN speardatalinkcscf%ROWTYPE
   /*-----------------------------------------------------------------*/
   IS
      l_recspeardatalinkcscf   speardatalinkcscf%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recspeardatalinkcscf
        FROM speardatalinkcscf
       WHERE sdf_ivr_id = p_ivr_id AND sdf_syv_id = p_syv_id;

      RETURN l_recspeardatalinkcscf;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_returnspearindex (
      p_syv_id   IN speardatalinkcscf.sdf_syv_id%TYPE)
      RETURN speardatalinkcscf.sdf_spearindex%TYPE
   /*-----------------------------------------------------------------*/
   IS
      l_recindiceversion   indiceversion%ROWTYPE;
      l_spearindex         speardatalinkcscf.sdf_spearindex%TYPE;
   BEGIN
      l_recindiceversion :=
         pkg_indiceversion.f_getcurrentversion (
            pkg_codevalue.cst_midatindice_spear);

      IF l_recindiceversion.ivr_id IS NULL
      THEN
         raise_application_error (-20000,
                                  'Spearversion non identifié',
                                  TRUE);
      END IF;

      l_spearindex := f_returnspearindex (l_recindiceversion.ivr_id, p_syv_id);
      RETURN l_spearindex;
   END;


   /*-----------------------------------------------------------------*/
   FUNCTION f_returnspearindex (
      p_spv_id   IN speardatalinkcscf.sdf_ivr_id%TYPE,
      p_syv_id   IN speardatalinkcscf.sdf_syv_id%TYPE)
      RETURN speardatalinkcscf.sdf_spearindex%TYPE
   /*-----------------------------------------------------------------*/
   IS
      /*
       Règle: On cherche dans la liste un SYV_ID qui correspond au paramètre p_syv_id
              Si on le trouve pas, on remonte la hiérarchie de p_syv_id et on procdent à la même recherche
      */
      l_recspeardatalinkcscf   speardatalinkcscf%ROWTYPE;
      l_recsysvalue            systvalue%ROWTYPE;
      l_syv_id                 systvalue.syv_id%TYPE;
      l_spearindex             speardatalinkcscf.sdf_spearindex%TYPE;
   BEGIN
      l_syv_id := p_syv_id;
      l_recspeardatalinkcscf := f_getrecordby_spv_id (p_spv_id, l_syv_id);

      WHILE     NOT l_syv_id IS NULL
            AND l_recspeardatalinkcscf.sdf_spearindex IS NULL
      LOOP
         l_recsysvalue := pkg_systvalue.f_getrecord (l_syv_id);
         l_syv_id := l_recsysvalue.syv_syv_id;

         IF NOT l_syv_id IS NULL
         THEN
            l_recspeardatalinkcscf :=
               f_getrecordby_spv_id (p_spv_id, l_syv_id);
         END IF;
      END LOOP;

      RETURN l_recspeardatalinkcscf.sdf_spearindex;
      NULL;
   END;

   /*----------------------------------------------------------------------*/
   FUNCTION f_getspearindexbysyvid (
      p_syv_id   IN speardatalinkcscf.sdf_syv_id%TYPE)
      RETURN speardatalinkcscf.sdf_spearindex%TYPE
   /*-----------------------------------------------------------------------*/
   IS
      l_spearindex   speardatalinkcscf.sdf_spearindex%TYPE;
   /* Cette fonction ne doit être utilisé que pour la version 2014*/
   BEGIN
      /* plusieurs syv_id se rapporte au même sdf_aqem_id  donc on utilise le distinct car le spearindex doit être le même*/
 

      SELECT DISTINCT sdf_spearindex
        INTO l_spearindex
        FROM speardatalinkcscf
             INNER JOIN indiceversion ON sdf_ivr_id = ivr_id
       WHERE sdf_syv_id = p_syv_id AND ivr_version = cst_version2014; -- Uniquement pour la version 2014

      RETURN l_spearindex;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*----------------------------------------------------------------------*/
   FUNCTION f_routereturnspearindex (
      p_syv_id   IN speardatalinkcscf.sdf_syv_id%TYPE)
      RETURN speardatalinkcscf.sdf_spearindex%TYPE
   /*----------------------------------------------------------------------*/
   IS
      l_recindiceversion   indiceversion%ROWTYPE;
      l_spearindex         speardatalinkcscf.sdf_spearindex%TYPE;
   BEGIN
      l_recindiceversion :=
         pkg_indiceversion.f_getcurrentversion (
            pkg_codevalue.cst_midatindice_spear);

      IF l_recindiceversion.ivr_id IS NULL
      THEN
         raise_application_error (-20000,
                                  'Spearversion non identifié',
                                  TRUE);
      END IF;

      IF TRIM (UPPER (l_recindiceversion.ivr_version)) =
            TRIM (UPPER (cst_version2014))
      THEN
         l_spearindex := f_getspearindexbysyvid (p_syv_id);
         pkg_debug.p_write ('pkg_speardatalinkcscf.f_routereturnspearindex',
                            'SPEARINDEX 2014=' || l_spearindex);
      ELSE
         l_spearindex :=
            f_returnspearindex (l_recindiceversion.ivr_id, p_syv_id);
         pkg_debug.p_write ('pkg_speardatalinkcscf.f_routereturnspearindex',
                            'SPEARINDEX 2017=' || l_spearindex);
      END IF;

      RETURN l_spearindex;
   END;



   /*------------------------------------------------------------------*/
   PROCEDURE p_clearbyversion (p_ivr_id IN speardatalinkcscf.sdf_ivr_id%TYPE)
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM speardatalinkcscf
            WHERE sdf_ivr_id = p_ivr_id;
   END;

   /*------------------------------------------------------------------*/
   PROCEDURE p_loadfromloadtable (
      p_spv_id   IN speardatalinkcscf.sdf_ivr_id%TYPE)
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
      --   p_clearbyversion (p_spv_id);

      INSERT INTO speardatalinkcscf (sdf_spearindex, sdf_syv_id, sdf_ivr_id)
         SELECT sdl_spear, sdl_syv_id, p_spv_id FROM speardatalinkcscfload;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_clearalldata
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM speardatalinkcscf;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_write (
      p_aqem_id      IN     speardatalinkcscf.sdf_aqem_id%TYPE,
      p_syv_id       IN     speardatalinkcscf.sdf_syv_id%TYPE,
      p_spearindex   IN     speardatalinkcscf.sdf_spearindex%TYPE,
      p_id              OUT speardatalinkcscf.sdf_id%TYPE)
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_speardatalinkcscf.NEXTVAL;

      INSERT INTO speardatalinkcscf (sdf_id,
                                     sdf_aqem_id,
                                     sdf_syv_id,
                                     sdf_spearindex)
           VALUES (p_id,
                   p_aqem_id,
                   p_syv_id,
                   p_spearindex);
   END;

   /*------------------------------------------------------------*/
   FUNCTION f_convertlevel (
      p_wlf_level   IN wk_loadspeardatacscf.wlf_level%TYPE)
      RETURN codereference.crf_code%TYPE
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      IF LOWER (TRIM (p_wlf_level)) = 'species'
      THEN
         RETURN pkg_codereference.cst_crf_species;
      END IF;

      IF LOWER (TRIM (p_wlf_level)) = 'undergenus'
      THEN
         RETURN pkg_codereference.cst_crf_subgenus;
      END IF;

      IF LOWER (TRIM (p_wlf_level)) = 'genus'
      THEN
         RETURN pkg_codereference.cst_crf_genus;
      END IF;

      IF LOWER (TRIM (p_wlf_level)) = 'underorder'
      THEN
         RETURN pkg_codereference.cst_crf_suborder;
      END IF;

      IF LOWER (TRIM (p_wlf_level)) = 'order'
      THEN
         RETURN pkg_codereference.cst_crf_order;
      END IF;

      IF LOWER (TRIM (p_wlf_level)) = 'family'
      THEN
         RETURN pkg_codereference.cst_crf_family;
      END IF;

      IF LOWER (TRIM (p_wlf_level)) = 'underclass'
      THEN
         RETURN pkg_codereference.cst_crf_subclass;
      END IF;

      IF LOWER (TRIM (p_wlf_level)) = 'class'
      THEN
         RETURN pkg_codereference.cst_crf_class;
      END IF;

      IF LOWER (TRIM (p_wlf_level)) = 'underphylum'
      THEN
         RETURN pkg_codereference.cst_crf_subphylum;
      END IF;
   END;



   /*------------------------------------------------------------*/
   FUNCTION f_identifylevel (
      p_recwk_loadspeardatacscf   IN wk_loadspeardatacscf%ROWTYPE)
      RETURN codereference.crf_code%TYPE
   /*--------------------------------------------------------------*/
   -- ON regarde ou la valeur contenue dans le champ TAXA est identique
   IS
      l_codereference   codereference.crf_code%TYPE;
   BEGIN
      IF NOT p_recwk_loadspeardatacscf.wlf_ss_espece IS NULL
      THEN
         IF UPPER (TRIM (p_recwk_loadspeardatacscf.wlf_ss_espece)) =
               UPPER (TRIM (p_recwk_loadspeardatacscf.wlf_taxa))
         THEN
            l_codereference := pkg_codereference.cst_crf_subspecies;
            RETURN l_codereference;
         END IF;
      END IF;

      IF NOT p_recwk_loadspeardatacscf.wlf_espece IS NULL
      THEN
         IF UPPER (TRIM (p_recwk_loadspeardatacscf.wlf_espece)) =
               UPPER (TRIM (p_recwk_loadspeardatacscf.wlf_taxa))
         THEN
            l_codereference := pkg_codereference.cst_crf_species;
            RETURN l_codereference;
         END IF;
      END IF;

      IF NOT p_recwk_loadspeardatacscf.wlf_ss_genus IS NULL
      THEN
         IF UPPER (TRIM (p_recwk_loadspeardatacscf.wlf_ss_genus)) =
               UPPER (TRIM (p_recwk_loadspeardatacscf.wlf_taxa))
         THEN
            l_codereference := pkg_codereference.cst_crf_subgenus;
            RETURN l_codereference;
         END IF;
      END IF;

      IF NOT p_recwk_loadspeardatacscf.wlf_genus IS NULL
      THEN
         IF UPPER (TRIM (p_recwk_loadspeardatacscf.wlf_genus)) =
               UPPER (TRIM (p_recwk_loadspeardatacscf.wlf_taxa))
         THEN
            l_codereference := pkg_codereference.cst_crf_genus;
            RETURN l_codereference;
         END IF;
      END IF;

      IF NOT p_recwk_loadspeardatacscf.wlf_family IS NULL
      THEN
         IF UPPER (TRIM (p_recwk_loadspeardatacscf.wlf_family)) =
               UPPER (TRIM (p_recwk_loadspeardatacscf.wlf_taxa))
         THEN
            l_codereference := pkg_codereference.cst_crf_family;
            RETURN l_codereference;
         END IF;
      END IF;

      RETURN NULL;
   END;

   /*------------------------------------------------------------*/
   PROCEDURE p_routebylevel (
      p_recwk_loadspeardatacscf   IN     wk_loadspeardatacscf%ROWTYPE,
      p_syv_id                       OUT systvalue.syv_id%TYPE)
   /*---------------------------------------------------------*/
   IS
      /*
      Règle définie par Y.G le 7 août 2014
      - Le nom fourni au niveau espece et sous espece n'est pas forcément celui de la base de donnée CSCF. Il faut utiler le nuesp pour ces niveaux
      - Les niveaux supérieurs doivent avoir le même nom que dans la base CSCF

     */



      l_recsystexternalcode   systexternalcode%ROWTYPE;
      l_designation           systdesignation.syd_designation%TYPE;
      l_recsystdesignation    systdesignation%ROWTYPE;
      l_syv_id                systvalue.syv_id%TYPE;
      l_codereference         codereference.crf_code%TYPE;
   BEGIN
      -- Si la colonne NUESP est renseignée, on l'utilise pour identifier le SYV_ID
      IF p_recwk_loadspeardatacscf.wlf_nuesp != 1
      THEN
         -- on cherche avec le NUESP
         l_recsystexternalcode :=
            pkg_systexternalcode.f_getrecordbyexternalcode (
               p_recwk_loadspeardatacscf.wlf_nuesp,
               pkg_codesource.cst_csc_cscf_nuesp);
         l_syv_id := l_recsystexternalcode.sye_syv_id;
      ELSE
         -- Sinon  on prend le contenu de la colonne TAXA au level défini
         l_codereference := f_identifylevel (p_recwk_loadspeardatacscf);


         l_codereference :=
            f_convertlevel (p_recwk_loadspeardatacscf.wlf_level);

         IF    l_codereference IS NULL
            OR l_codereference = pkg_codereference.cst_crf_species
         THEN
            l_codereference := f_identifylevel (p_recwk_loadspeardatacscf);
         END IF;



         IF NOT l_codereference IS NULL
         THEN
            l_designation := p_recwk_loadspeardatacscf.wlf_taxa;
            l_recsystdesignation :=
               pkg_systdesignation.f_getrecordbyleveldesignation (
                  l_designation,
                  l_codereference);
            l_syv_id := l_recsystdesignation.syd_syv_id;

            IF l_syv_id IS NULL
            THEN
               pkg_debug.p_write (
                  'PKG_SPEARDATALINKCSCF.p_routebylevel',
                  l_designation || ' ->' || l_codereference || ' non trouvé');
            END IF;
         ELSE
            l_syv_id := NULL;
         END IF;
      END IF;


      p_syv_id := l_syv_id;
   END;



   /*-----------------------------------------------------------*/
   PROCEDURE p_truncate
   /*-----------------------------------------------------------*/

   IS
      l_sql   VARCHAR2 (1024);
   BEGIN
      l_sql := 'TRUNCATE TABLE SPEARDATALINKCSCF';

      EXECUTE IMMEDIATE l_sql;

      l_sql := 'DROP SEQUENCE SEQ_SPEARDATALINKCSCF';

      EXECUTE IMMEDIATE l_sql;

      l_sql := 'CREATE SEQUENCE SEQ_SPEARDATALINKCSCF';

      EXECUTE IMMEDIATE l_sql;
   END;


   /*------------------------------------------------------------*/
   PROCEDURE p_build
   /*------------------------------------------------------------*/
   IS
      /* Attention: Si le NUESP est égale à 1, la colonne TAXA doit contenir le libellé CSCF */
      CURSOR l_wk_loadspeardatacscf
      IS
         SELECT * FROM wk_loadspeardatacscf;

      l_recwk_loadspeardatacscf   l_wk_loadspeardatacscf%ROWTYPE;
      l_syv_id                    systvalue.syv_id%TYPE;
      l_recspeardata              speardata%ROWTYPE;
      l_sdf_id                    speardatalinkcscf.sdf_id%TYPE;
   BEGIN
      pkg_debug.p_truncate;
      pkg_speardatalinkcscf.p_truncate;

      OPEN l_wk_loadspeardatacscf;

      LOOP
         FETCH l_wk_loadspeardatacscf INTO l_recwk_loadspeardatacscf;

         EXIT WHEN l_wk_loadspeardatacscf%NOTFOUND;
         p_routebylevel (l_recwk_loadspeardatacscf, l_syv_id);

         IF NOT l_syv_id IS NULL
         THEN
            l_recspeardata :=
               pkg_speardata.f_getrecordbyaqem_id (
                  l_recwk_loadspeardatacscf.wlf_aqem_id);

            IF l_recspeardata.sra_id IS NULL
            THEN
               raise_application_error (
                  -20000,
                     'aquem_id='
                  || l_recwk_loadspeardatacscf.wlf_aqem_id
                  || 'non trouvé',
                  TRUE);
            END IF;

            IF l_recspeardata.sra_spearvalue !=
                  l_recwk_loadspeardatacscf.wlf_spearindex
            THEN
               raise_application_error (
                  -20000,
                     'aquem_id='
                  || l_recwk_loadspeardatacscf.wlf_aqem_id
                  || 'n'' pas le même spearindex dans speardata',
                  TRUE);
            END IF;

            p_write (l_recwk_loadspeardatacscf.wlf_aqem_id,
                     l_syv_id,
                     l_recwk_loadspeardatacscf.wlf_spearindex,
                     l_sdf_id);
         ELSE
            pkg_debug.p_write (
               'PKG_SPEARDATALINKCSCF.p_build',
                  'Designation recherché ID:='
               || l_recwk_loadspeardatacscf.wlf_id
               || ' non trouvé');
         END IF;
      END LOOP;

      CLOSE l_wk_loadspeardatacscf;
   END;

   /*----------------------------------------------------------------------*/
   FUNCTION f_getspearindexbyaqem_id (
      p_aqem_id   IN speardatalinkcscf.sdf_aqem_id%TYPE)
      RETURN speardatalinkcscf.sdf_spearindex%TYPE
   /*-----------------------------------------------------------------------*/
   IS
      l_spearindex   speardatalinkcscf.sdf_spearindex%TYPE;
   BEGIN
      SELECT sdf_spearindex
        INTO l_spearindex
        FROM speardatalinkcscf
       WHERE sdf_aqem_id = p_aqem_id;

      RETURN l_spearindex;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
END pkg_speardatalinkcscf;
/

