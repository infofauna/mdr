create PACKAGE BODY       pkg_protocolmappingmassmap
AS
   /******************************************************************************
      NAME:       pkg_protocolmappingmassmap
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_countrequired (
      p_lan_id   IN protocolmappingmassmap.pma_lan_id%TYPE,
      p_ptv_id   IN protocolmappingmassfield.pmm_ptv_id%TYPE)
      RETURN NUMBER
   /*-------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM protocolmappingmassmap
             INNER JOIN protocolmappingmassfield ON pmm_id = pma_pmm_id
       WHERE     pma_lan_id = p_lan_id
             AND pmm_ptv_id = p_ptv_id
             AND pmm_isnotnull = pkg_constante.cst_yes;

      RETURN l_count;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_countgrouprequired (
      p_lan_id   IN protocolmappingmassmap.pma_lan_id%TYPE,
      p_ptv_id   IN protocolmappingmassfield.pmm_ptv_id%TYPE)
      RETURN NUMBER
   /*-------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM protocolmappingmassmap
             INNER JOIN protocolmappingmassfield ON pmm_id = pma_pmm_id
       WHERE     pma_lan_id = p_lan_id
             AND pmm_ptv_id = p_ptv_id
             AND NOT pmm_isnotnullgroup IS NULL;

      RETURN l_count;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_checkexistmapping (
      p_lan_id         IN     protocolmappingmassmap.pma_lan_id%TYPE,
      p_ptv_id         IN     protocolmappingmassfield.pmm_ptv_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*-------------------------------------------------------------*/
   IS
      l_countrequiredreference        NUMBER;
      l_countgrouprequiredreference   NUMBER;
      l_countrequired                 NUMBER;
      l_countgrouprequired            NUMBER;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_countgrouprequiredreference :=
         pkg_protocolmappingmassfield.f_countgrouprequired (p_ptv_id);
      l_countrequiredreference :=
         pkg_protocolmappingmassfield.f_countrequired (p_ptv_id);
      l_countrequired := f_countrequired (p_lan_id, p_ptv_id);
      l_countgrouprequired := f_countgrouprequired (p_lan_id, p_ptv_id);

      IF l_countrequired != l_countrequiredreference
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;

      IF l_countgrouprequired != l_countgrouprequiredreference
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_getrecordbypmm_id (
      p_lan_id   IN protocolmappingmassmap.pma_lan_id%TYPE,
      p_pmm_id   IN protocolmappingmassmap.pma_pmm_id%TYPE)
      RETURN protocolmappingmassmap%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_recprotocolmappingmap   protocolmappingmassmap%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recprotocolmappingmap
        FROM protocolmappingmassmap
       WHERE pma_lan_id = p_lan_id AND pma_pmm_id = p_pmm_id;

      RETURN l_recprotocolmappingmap;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_exist (
      p_lan_id       IN protocolmappingmassmap.pma_lan_id%TYPE,
      p_pmm_id       IN protocolmappingmassmap.pma_pmm_id%TYPE,
      p_columnname   IN protocolmappingmassmap.pma_aliascolumnname%TYPE)
      RETURN protocolmappingmassmap%ROWTYPE
   /*---------------------------------------------------------------*/
   IS
      l_recprotocolmappingmap   protocolmappingmassmap%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recprotocolmappingmap
        FROM protocolmappingmassmap
       WHERE     pma_lan_id = p_lan_id
             AND pma_pmm_id = p_pmm_id
             AND pma_aliascolumnname = p_columnname;

      RETURN l_recprotocolmappingmap;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_writeifnotexist (
      p_lan_id       IN protocolmappingmassmap.pma_lan_id%TYPE,
      p_pmm_id       IN protocolmappingmassmap.pma_pmm_id%TYPE,
      p_columnname   IN protocolmappingmassmap.pma_aliascolumnname%TYPE)
   /*-----------------------------------------------------------------*/
   IS
      l_recprotocolmappingmap   protocolmappingmassmap%ROWTYPE;
   BEGIN
      l_recprotocolmappingmap := f_exist (p_lan_id, p_pmm_id, p_columnname);

      IF l_recprotocolmappingmap.pma_id IS NULL
      THEN
         INSERT
           INTO protocolmappingmassmap (pma_lan_id,
                                        pma_pmm_id,
                                        pma_aliascolumnname)
         VALUES (p_lan_id, p_pmm_id, p_columnname);
      END IF;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_write (
      p_lan_id       IN protocolmappingmassmap.pma_lan_id%TYPE,
      p_pmm_id       IN protocolmappingmassmap.pma_pmm_id%TYPE,
      p_columnname   IN protocolmappingmassmap.pma_aliascolumnname%TYPE)
   /*-----------------------------------------------------------------*/
   IS
   BEGIN
      INSERT
        INTO protocolmappingmassmap (pma_lan_id,
                                     pma_pmm_id,
                                     pma_aliascolumnname)
      VALUES (p_lan_id, p_pmm_id, p_columnname);
   END;

   /*-------------------------------------------------------------------------*/
   FUNCTION f_getrecordbymidatfldcmt (
      p_ptv_id        IN protocolmappingmassfield.pmm_ptv_id%TYPE,
      p_lan_id        IN protocolmappingmassmap.pma_lan_id%TYPE,
      p_midatfldcmt   IN protocolmappingmassfield.pmm_code_midatfldcmt%TYPE)
      RETURN protocolmappingmassmap%ROWTYPE
   /*-------------------------------------------------------------------------*/
   IS
      l_recprotocolmappingmassmap   protocolmappingmassmap%ROWTYPE;
   BEGIN
      SELECT protocolmappingmassmap.*
        INTO l_recprotocolmappingmassmap
        FROM protocolmappingmassmap
             INNER JOIN protocolmappingmassfield ON pmm_id = pma_pmm_id
       WHERE     pmm_ptv_id = p_ptv_id
             AND pmm_code_midatfldcmt = p_midatfldcmt
             AND pma_lan_id = p_lan_id;
             RETURN l_recprotocolmappingmassmap;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
END pkg_protocolmappingmassmap;
/

