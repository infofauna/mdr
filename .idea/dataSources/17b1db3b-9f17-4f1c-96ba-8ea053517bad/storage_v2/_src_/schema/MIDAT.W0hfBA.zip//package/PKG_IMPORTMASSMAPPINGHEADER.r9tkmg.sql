create PACKAGE       pkg_importmassmappingheader
AS
   /******************************************************************************
      NAME:       pkg_importmassmappingheader
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_deletebyiph_idconditionnal (
      p_iph_id   IN importmassmappingheader.ime_iph_id%TYPE);

   FUNCTION f_fieldispresent (
      p_iph_id       IN importmassmappingheader.ime_iph_id%TYPE,
      p_columnname      protocolmappingmassfield.pmm_columnname%TYPE)
      RETURN importmassmappingheader%ROWTYPE;

   FUNCTION f_fieldrefispresent (
      p_iph_id            IN importmassmappingheader.ime_iph_id%TYPE,
      p_codemidatfldcmt      protocolmappingmassfield.pmm_code_midatfldcmt%TYPE)
      RETURN importmassmappingheader%ROWTYPE;

   PROCEDURE p_logmapping (
      p_iph_id   IN importmassmappingheader.ime_iph_id%TYPE,
      p_lan_id   IN importprotocolheader.iph_lan_id%TYPE);

   PROCEDURE p_deletebyiph_id (
      p_iph_id   IN importmassmappingheader.ime_iph_id%TYPE);

   PROCEDURE p_insert (
      p_iph_id           IN importmassmappingheader.ime_iph_id%TYPE,
      p_pmm_id           IN importmassmappingheader.ime_pmm_id%TYPE,
      p_excelfieldname   IN importmassmappingheader.ime_excelfieldname%TYPE);

   FUNCTION f_getrecord (p_ime_id IN importmassmappingheader.ime_id%TYPE)
      RETURN importmassmappingheader%ROWTYPE;

   FUNCTION f_getrecordbymidatfldcnt (
      p_iph_id        IN importmassmappingheader.ime_iph_id%TYPE,
      p_midatfldcnt   IN protocolmappingmassfield.pmm_code_midatfldcmt%TYPE)
      RETURN importmassmappingheader%ROWTYPE;
END pkg_importmassmappingheader;
/

