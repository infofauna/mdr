create PACKAGE BODY       pkg_tricopterascabbard
AS
   /******************************************************************************
      NAME:       .PKG_TRICOPTERASCABBARD
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        13.03.2015     burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, mars  2015';



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-----------------------------------------------------------------*/
   FUNCTION f_getrecord (p_tsd_id IN tricopterascabbard.tsd_id%TYPE)
      RETURN tricopterascabbard%ROWTYPE
   /*------------------------------------------------------------------*/
   IS
      l_tricopterascabbard   tricopterascabbard%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_tricopterascabbard
        FROM tricopterascabbard
       WHERE tsd_id = p_tsd_id;

      RETURN l_tricopterascabbard;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
   /*----------------------------------------------------------------*/
   FUNCTION f_getrecordbysyvid(p_syv_id IN tricopterascabbard.tsd_syv_id%TYPE)
   RETURN tricopterascabbard%rowtype
   /*----------------------------------------------------------------*/
   IS
        l_tricopterascabbard   tricopterascabbard%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_tricopterascabbard
        FROM tricopterascabbard
       WHERE tsd_syv_id = p_syv_id;

      RETURN l_tricopterascabbard;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_write (
      p_syv_id        IN     tricopterascabbard.tsd_syv_id%TYPE,
      p_text          IN     tricopterascabbard.tsd_text%TYPE,
      p_hasscabbard   IN     tricopterascabbard.tsd_hasscabbard%TYPE,
      p_id               OUT tricopterascabbard.tsd_id%TYPE)
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_tricopterascabbard.NEXTVAL;

      INSERT INTO tricopterascabbard (tsd_id,
                                      tsd_syv_id,
                                      tsd_text,
                                      tsd_hasscabbard)
           VALUES (p_id,
                   p_syv_id,
                   p_text,
                   p_hasscabbard);
   END;
END pkg_tricopterascabbard;
/

