create trigger TR_BUF_PROCESSINGSTATUS
    before update
    on PROCESSINGSTATUS
    for each row
DECLARE
BEGIN
 
   :new.pid_moddate := SYSDATE;
   :new.pid_moduser := USER;
END tr_buf_PROCESSINGSTATUS;

/

