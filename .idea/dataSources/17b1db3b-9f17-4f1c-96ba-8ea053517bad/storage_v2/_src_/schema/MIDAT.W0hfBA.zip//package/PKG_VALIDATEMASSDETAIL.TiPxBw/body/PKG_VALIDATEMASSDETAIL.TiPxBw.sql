create PACKAGE BODY       pkg_validatemassdetail
AS
   /******************************************************************************
      NAME:       pkg_validatemassdetail
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
      1.1        26.09.2017      burrif       2. Midat version 2
   ******************************************************************************/



   TYPE t_cursor IS REF CURSOR;



   TYPE t_listrequiredfield
      IS TABLE OF protocolmappingmassfield.pmm_code_midatfldcmt%TYPE
      INDEX BY protocolmappingmassfield.pmm_columnname%TYPE;

   cst_notnulltypefield        CONSTANT VARCHAR2 (12) := 'FIELD';
   cst_notnulltypegroupfield   CONSTANT VARCHAR2 (12) := 'GROUPFIELD';
   cst_packageversion          CONSTANT VARCHAR2 (30)
                                           := 'Version 1.1, septembre  2017' ;
   gbl_listrequiredfield                t_listrequiredfield;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;



   /*-------------------------------------------------------------------*/
   PROCEDURE p_validateunicityheader (
      p_iph_id              IN     importmassdatadetail.imd_iph_id%TYPE,
      p_imh_id              IN     importmassdatadetail.imd_imh_id%TYPE,
      p_swisscoord_x        IN     importmassdatadetail.imd_swisscoord_x%TYPE,
      p_swisscoord_y        IN     importmassdatadetail.imd_swisscoord_y%TYPE,
      p_swisscoord_z        IN     importmassdatadetail.imd_swisscoord_z%TYPE,
      p_day                 IN     importmassdatadetail.imd_day%TYPE,
      p_month               IN     importmassdatadetail.imd_month%TYPE,
      p_year                IN     importmassdatadetail.imd_year%TYPE,
      p_systemprecision     IN     pkg_importmassdataheader.t_systemprecision,
      p_codeprecision       IN     pkg_importmassdataheader.t_codeprecision,
      p_oid                 IN     pkg_importmassdataheader.t_oid,
      p_watercourse         IN     pkg_importmassdataheader.t_watercourse,
      p_locality            IN     pkg_importmassdataheader.t_locality,
      p_calledplace         IN     pkg_importmassdataheader.t_calledplace,
      p_observers           IN     pkg_importmassdataheader.t_observers,
      p_period              IN     pkg_importmassdataheader.t_period,
      p_project             IN     pkg_importmassdataheader.t_project,
      p_reporturl           IN     pkg_importmassdataheader.t_reporturl,
      p_makroindexprovide   IN     pkg_importmassdataheader.t_makroindexprovide,
      p_spearindexprovide   IN     pkg_importmassdataheader.t_spearindexprovide,
      p_ibchindexprovide    IN     pkg_importmassdataheader.t_ibchindexprovide,
      p_elevation           IN     pkg_importmassdataheader.t_elevation,
      p_indicetype          IN     pkg_importmassdataheader.t_indicetype,
      p_remarkcode1         IN     pkg_importmassdataheader.t_remarkcode1,
      p_remarkcode2         IN     pkg_importmassdataheader.t_remarkcode2,
      p_remarkcode3         IN     pkg_importmassdataheader.t_remarkcode3,
      p_remarkcode4         IN     pkg_importmassdataheader.t_remarkcode4,
      p_remarktext          IN     pkg_importmassdataheader.t_remarktext,
      p_oidlink             IN     pkg_importmassdataheader.t_oidlink,
      p_determinator        IN     pkg_importmassdataheader.t_determinator,
      p_returnstatus           OUT NUMBER)
   /*------------------------------------------------------------------*/
   IS
      l_indice                        PLS_INTEGER;
      l_date                          VARCHAR2 (30);
      l_xyz                           VARCHAR2 (256);
      l_columnname                    VARCHAR2 (256);
      l_indice1                       PLS_INTEGER;
      l_count                         NUMBER;

      l_recimportmassmappingheader    importmassmappingheader%ROWTYPE;
      l_recprototolmappingmassfield   protocolmappingmassfield%ROWTYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_date := p_day || '/' || p_month || '/' || p_year;
      l_xyz :=
            '('
         || p_swisscoord_x
         || ';'
         || p_swisscoord_y
         || ';'
         || p_swisscoord_z
         || ')';

      IF p_systemprecision.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_systemprec);
         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_systemprecision.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
      END IF;

      IF p_codeprecision.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_prec);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_codeprecision.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_codeprecision.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_codeprecision (l_indice1));
            l_indice1 := p_codeprecision.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_oid.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_oid);
         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_oid.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_oid.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_oid (l_indice1));
            l_indice1 := p_oid.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_watercourse.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_water);
         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_watercourse.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_watercourse.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_watercourse (l_indice1));
            l_indice1 := p_watercourse.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_locality.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_locality);
         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_locality.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_locality.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_locality (l_indice1));
            l_indice1 := p_locality.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_calledplace.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_calledplace);
         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_calledplace.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_calledplace.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_calledplace (l_indice1));
            l_indice1 := p_calledplace.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_observers.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_observer);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_observers.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_observers.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_observers (l_indice1));
            l_indice1 := p_observers.NEXT (l_indice1);
         END LOOP;
      END IF;


      IF p_project.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_project);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_project.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_project.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_project (l_indice1));
            l_indice1 := p_project.NEXT (l_indice1);
         END LOOP;
      END IF;



      IF p_reporturl.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_repurl);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_reporturl.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_reporturl.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_project (l_indice1));
            l_indice1 := p_reporturl.NEXT (l_indice1);
         END LOOP;
      END IF;



      IF p_makroindexprovide.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_makroindex);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_makroindexprovide.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_makroindexprovide.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_makroindexprovide (l_indice1));
            l_indice1 := p_makroindexprovide.NEXT (l_indice1);
         END LOOP;
      END IF;


      IF p_spearindexprovide.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_spearindex);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_spearindexprovide.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_spearindexprovide.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_spearindexprovide (l_indice1));
            l_indice1 := p_spearindexprovide.NEXT (l_indice1);
         END LOOP;
      END IF;


      IF p_ibchindexprovide.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_ibchindex);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_ibchindexprovide.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_ibchindexprovide.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_ibchindexprovide (l_indice1));
            l_indice1 := p_ibchindexprovide.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_elevation.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_swiss_z);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_elevation.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_elevation.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_elevation (l_indice1));
            l_indice1 := p_elevation.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_indicetype.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_indicetype);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_indicetype.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_indicetype.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_indicetype (l_indice1));
            l_indice1 := p_indicetype.NEXT (l_indice1);
         END LOOP;
      END IF;



      IF p_remarkcode1.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_remarkcode1);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_remarkcode1.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_remarkcode1.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_remarkcode1 (l_indice1));
            l_indice1 := p_remarkcode1.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_remarkcode2.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_remarkcode2);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_remarkcode2.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_remarkcode2.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_remarkcode2 (l_indice1));
            l_indice1 := p_remarkcode2.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_remarkcode3.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_remarkcode3);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_remarkcode3.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_remarkcode3.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_remarkcode3 (l_indice1));
            l_indice1 := p_remarkcode3.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_remarkcode4.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_remarkcode4);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_remarkcode4.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_remarkcode4.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_remarkcode4 (l_indice1));
            l_indice1 := p_remarkcode4.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_remarktext.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_remarktext);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_remarktext.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_remarktext.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_remarktext (l_indice1));
            l_indice1 := p_remarktext.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_determinator.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_determinator);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_determinator.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_determinator.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_determinator (l_indice1));
            l_indice1 := p_determinator.NEXT (l_indice1);
         END LOOP;
      END IF;

      IF p_oidlink.COUNT > 1
      THEN
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
               p_iph_id,
               pkg_codevalue.cst_midatfldcmt_oidlink);

         l_recprototolmappingmassfield :=
            pkg_protocolmappingmassfield.f_getrecord (
               l_recimportmassmappingheader.ime_pmm_id);
         l_columnname := l_recprototolmappingmassfield.pmm_columnname;
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            p_imh_id,                                                -- IMH_ID
            pkg_exception.cst_samesamplehasmorevalue,
            l_columnname,                                        -- Field name
            l_date,
            l_xyz,
            l_recimportmassmappingheader.ime_excelfieldname,
            TO_CHAR (p_oidlink.COUNT));
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         l_indice1 := p_oidlink.FIRST;
         l_count := 0;

         WHILE NOT l_indice1 IS NULL
         LOOP
            l_count := l_count + 1;
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               p_imh_id,                                             -- IMH_ID
               pkg_exception.cst_info,
               l_columnname,                                     -- Field name
               TO_CHAR (l_count) || '. ' || p_oidlink (l_indice1));
            l_indice1 := p_oidlink.NEXT (l_indice1);
         END LOOP;
      END IF;


      NULL;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_completeheaderitem (
      p_systemprecision      IN     pkg_importmassdataheader.t_systemprecision,
      p_codeprecision        IN     pkg_importmassdataheader.t_codeprecision,
      p_oid                  IN     pkg_importmassdataheader.t_oid,
      p_watercourse          IN     pkg_importmassdataheader.t_watercourse,
      p_locality             IN     pkg_importmassdataheader.t_locality,
      p_calledplace          IN     pkg_importmassdataheader.t_calledplace,
      p_observers            IN     pkg_importmassdataheader.t_observers,
      p_period               IN     pkg_importmassdataheader.t_period,
      p_project              IN     pkg_importmassdataheader.t_project,
      p_reporturl            IN     pkg_importmassdataheader.t_reporturl,
      p_makroindexprovide    IN     pkg_importmassdataheader.t_makroindexprovide,
      p_spearindexprovide    IN     pkg_importmassdataheader.t_spearindexprovide,
      p_ibchindexprovide     IN     pkg_importmassdataheader.t_ibchindexprovide,
      p_elevation            IN     pkg_importmassdataheader.t_elevation,
      p_indicetype           IN     pkg_importmassdataheader.t_indicetype,
      p_remarkcode1          IN     pkg_importmassdataheader.t_remarkcode1,
      p_remarkcode2          IN     pkg_importmassdataheader.t_remarkcode2,
      p_remarkcode3          IN     pkg_importmassdataheader.t_remarkcode3,
      p_remarkcode4          IN     pkg_importmassdataheader.t_remarkcode4,
      p_remarktext           IN     pkg_importmassdataheader.t_remarktext,
      p_oidlink              IN     pkg_importmassdataheader.t_oidlink,
      p_determinator         IN     pkg_importmassdataheader.t_determinator,
      p_systemprecisiontxt      OUT importmassdataheader.imh_systemprecision%TYPE,
      p_codeprecisiontxt        OUT importmassdataheader.imh_codeprecision%TYPE,
      p_oidtxt                  OUT importmassdataheader.imh_oid%TYPE,
      p_watercoursetxt          OUT importmassdataheader.imh_watercourse%TYPE,
      p_localitytxt             OUT importmassdataheader.imh_locality%TYPE,
      p_calledplacetxt          OUT importmassdataheader.imh_calledplace%TYPE,
      p_observerstxt            OUT importmassdataheader.imh_observers%TYPE,
      p_periodtxt               OUT importmassdataheader.imh_period%TYPE,
      p_projecttxt              OUT importmassdataheader.imh_project%TYPE,
      p_reporturltxt            OUT importmassdataheader.imh_reporturl%TYPE,
      p_makroindextxt           OUT importmassdataheader.imh_makroindexprovide%TYPE,
      p_spearindextxt           OUT importmassdataheader.imh_spearindexprovide%TYPE,
      p_ibchindextxt            OUT importmassdataheader.imh_ibchindexprovide%TYPE,
      p_elevationtxt            OUT importmassdataheader.imh_elevation%TYPE,
      p_indicetypetxt           OUT importmassdataheader.imh_indicetype%TYPE,
      p_remarkcode1txt          OUT importmassdataheader.imh_remarkcode1%TYPE,
      p_remarkcode2txt          OUT importmassdataheader.imh_remarkcode2%TYPE,
      p_remarkcode3txt          OUT importmassdataheader.imh_remarkcode3%TYPE,
      p_remarkcode4txt          OUT importmassdataheader.imh_remarkcode4%TYPE,
      p_remarktexttxt           OUT importmassdataheader.imh_remarktext%TYPE,
      p_oidlinktxt              OUT importmassdataheader.imh_oidlink%TYPE,
      p_determinatortxt         OUT importmassdataheader.imh_determinator%TYPE)
   /*----------------------------------------------------------------------------------------------------*/
   IS
      l_indice   PLS_INTEGER;
   BEGIN
      p_systemprecisiontxt := NULL;
      p_codeprecisiontxt := NULL;
      p_oidtxt := NULL;
      p_watercoursetxt := NULL;
      p_localitytxt := NULL;
      p_calledplacetxt := NULL;
      p_observerstxt := NULL;
      p_periodtxt := NULL;
      p_projecttxt := NULL;
      p_reporturltxt := NULL;
      p_makroindextxt := NULL;
      p_elevationtxt := NULL;
      p_ibchindextxt := NULL;
      p_spearindextxt := NULL;
      p_indicetypetxt := NULL;

      IF p_systemprecision.COUNT = 1
      THEN
         l_indice := p_systemprecision.FIRST;
         p_systemprecisiontxt := p_systemprecision (l_indice);
      END IF;

      IF p_codeprecision.COUNT = 1
      THEN
         l_indice := p_codeprecision.FIRST;
         p_codeprecisiontxt := p_codeprecision (l_indice);
      END IF;

      IF p_oid.COUNT = 1
      THEN
         l_indice := p_oid.FIRST;
         p_oidtxt := p_oid (l_indice);
      END IF;

      IF p_watercourse.COUNT = 1
      THEN
         l_indice := p_watercourse.FIRST;
         p_watercoursetxt := p_watercourse (l_indice);
      END IF;

      IF p_locality.COUNT = 1
      THEN
         l_indice := p_locality.FIRST;
         p_localitytxt := p_locality (l_indice);
      END IF;

      IF p_calledplace.COUNT = 1
      THEN
         l_indice := p_calledplace.FIRST;
         p_calledplacetxt := p_calledplace (l_indice);
      END IF;

      IF p_observers.COUNT = 1
      THEN
         l_indice := p_observers.FIRST;
         p_observerstxt := p_observers (l_indice);
      END IF;

      IF p_period.COUNT = 1
      THEN
         l_indice := p_period.FIRST;
         p_periodtxt := p_period (l_indice);
      END IF;

      IF p_project.COUNT = 1
      THEN
         l_indice := p_project.FIRST;
         p_projecttxt := p_project (l_indice);
      END IF;

      IF p_reporturl.COUNT = 1
      THEN
         l_indice := p_reporturl.FIRST;
         p_reporturltxt := p_reporturl (l_indice);
      END IF;

      IF p_makroindexprovide.COUNT = 1
      THEN
         l_indice := p_makroindexprovide.FIRST;
         p_makroindextxt := p_makroindexprovide (l_indice);
      END IF;

      IF p_spearindexprovide.COUNT = 1
      THEN
         l_indice := p_spearindexprovide.FIRST;
         p_spearindextxt := p_spearindexprovide (l_indice);
      END IF;


      IF p_ibchindexprovide.COUNT = 1
      THEN
         l_indice := p_ibchindexprovide.FIRST;
         p_ibchindextxt := p_ibchindexprovide (l_indice);
      END IF;

      IF p_elevation.COUNT = 1
      THEN
         l_indice := p_elevation.FIRST;
         p_elevationtxt := p_elevation (l_indice);
      END IF;

      IF p_indicetype.COUNT = 1
      THEN
         l_indice := p_indicetype.FIRST;
         p_indicetypetxt := p_indicetype (l_indice);
      END IF;

      IF p_remarkcode1.COUNT = 1
      THEN
         l_indice := p_remarkcode1.FIRST;
         p_remarkcode1txt := p_remarkcode1 (l_indice);
      END IF;

      IF p_remarkcode2.COUNT = 1
      THEN
         l_indice := p_remarkcode2.FIRST;
         p_remarkcode2txt := p_remarkcode2 (l_indice);
      END IF;

      IF p_remarkcode3.COUNT = 1
      THEN
         l_indice := p_remarkcode3.FIRST;
         p_remarkcode3txt := p_remarkcode3 (l_indice);
      END IF;

      IF p_remarkcode4.COUNT = 1
      THEN
         l_indice := p_remarkcode4.FIRST;
         p_remarkcode4txt := p_remarkcode4 (l_indice);
      END IF;

      IF p_remarktext.COUNT = 1
      THEN
         l_indice := p_remarktext.FIRST;
         p_remarktexttxt := p_remarktext (l_indice);
      END IF;

      IF p_oidlink.COUNT = 1
      THEN
         l_indice := p_oidlink.FIRST;
         p_oidlinktxt := p_oidlink (l_indice);
      END IF;

      IF p_determinator.COUNT = 1
      THEN
         l_indice := p_determinator.FIRST;
         p_determinatortxt := p_determinator (l_indice);
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_completeheader (
      p_iph_id   IN importmassdatadetail.imd_iph_id%TYPE,
      p_lan_id   IN language.lan_id%TYPE)
   /*-----------------------------------------------------------------*/
   IS
      /*
       Chaque entrée de header doit disposer des mêmes attributs dans les colonnes
       IIMH_SYSTEMPRECISION     VARCHAR2(60 CHAR),
       IMH_CODEPRECISION       VARCHAR2(60 CHAR),
       IMH_OID                 VARCHAR2(30 CHAR),
       IMH_WATERCOURSE         VARCHAR2(30 CHAR),
       MH_LOCALITY            VARCHAR2(60 CHAR),
       IMH_CALLEDPLACE         VARCHAR2(256 CHAR),
       IMH_OBSERVERS           VARCHAR2(120 CHAR),
       IMH_ELEVATION

      */



      l_systemprecision           pkg_importmassdataheader.t_systemprecision
                                     := pkg_importmassdataheader.t_systemprecision ();
      l_codeprecision             pkg_importmassdataheader.t_codeprecision
                                     := pkg_importmassdataheader.t_codeprecision ();
      l_oid                       pkg_importmassdataheader.t_oid
                                     := pkg_importmassdataheader.t_oid ();
      l_watercourse               pkg_importmassdataheader.t_watercourse
                                     := pkg_importmassdataheader.t_watercourse ();
      l_locality                  pkg_importmassdataheader.t_locality
                                     := pkg_importmassdataheader.t_locality ();
      l_calledplace               pkg_importmassdataheader.t_calledplace
                                     := pkg_importmassdataheader.t_calledplace ();
      l_observers                 pkg_importmassdataheader.t_observers
                                     := pkg_importmassdataheader.t_observers ();
      l_period                    pkg_importmassdataheader.t_period
                                     := pkg_importmassdataheader.t_period ();

      l_project                   pkg_importmassdataheader.t_project
                                     := pkg_importmassdataheader.t_project ();
      l_reporturl                 pkg_importmassdataheader.t_reporturl
                                     := pkg_importmassdataheader.t_reporturl ();
      l_makroindexprovide         pkg_importmassdataheader.t_makroindexprovide
         := pkg_importmassdataheader.t_makroindexprovide ();
      l_spearindexprovide         pkg_importmassdataheader.t_spearindexprovide
         := pkg_importmassdataheader.t_spearindexprovide ();
      l_ibchindexprovide          pkg_importmassdataheader.t_ibchindexprovide
         := pkg_importmassdataheader.t_ibchindexprovide ();

      l_elevation                 pkg_importmassdataheader.t_elevation
                                     := pkg_importmassdataheader.t_elevation ();
      l_indicetype                pkg_importmassdataheader.t_indicetype
                                     := pkg_importmassdataheader.t_indicetype ();

      l_remarkcode1               pkg_importmassdataheader.t_remarkcode1
                                     := pkg_importmassdataheader.t_remarkcode1 ();
      l_remarkcode2               pkg_importmassdataheader.t_remarkcode2
                                     := pkg_importmassdataheader.t_remarkcode2 ();
      l_remarkcode3               pkg_importmassdataheader.t_remarkcode3
                                     := pkg_importmassdataheader.t_remarkcode3 ();
      l_remarkcode4               pkg_importmassdataheader.t_remarkcode4
                                     := pkg_importmassdataheader.t_remarkcode4 ();
      l_remarktext                pkg_importmassdataheader.t_remarktext
                                     := pkg_importmassdataheader.t_remarktext ();
      l_oidlink                   pkg_importmassdataheader.t_oidlink
                                     := pkg_importmassdataheader.t_oidlink ();
      l_determinator              pkg_importmassdataheader.t_determinator
                                     := pkg_importmassdataheader.t_determinator ();



      l_systemprecisiontxt        importmassdataheader.imh_systemprecision%TYPE;

      l_codeprecisiontxt          importmassdataheader.imh_codeprecision%TYPE;

      l_oidtxt                    importmassdataheader.imh_oid%TYPE;

      l_watercoursetxt            importmassdataheader.imh_watercourse%TYPE;

      l_localitytxt               importmassdataheader.imh_locality%TYPE;

      l_calledplacetxt            importmassdataheader.imh_calledplace%TYPE;

      l_observerstxt              importmassdataheader.imh_observers%TYPE;
      l_periodtxt                 importmassdataheader.imh_period%TYPE;
      l_projecttxt                importmassdataheader.imh_project%TYPE;
      l_reporturltxt              importmassdataheader.imh_reporturl%TYPE;
      l_makroindextxt             importmassdataheader.imh_makroindexprovide%TYPE;
      l_spearindextxt             importmassdataheader.imh_spearindexprovide%TYPE;
      l_ibchindextxt              importmassdataheader.imh_ibchindexprovide%TYPE;
      l_elevationtxt              importmassdataheader.imh_elevation%TYPE;
      l_indicetypetxt             importmassdataheader.imh_indicetype%TYPE;

      l_remarkcode1txt            importmassdataheader.imh_remarkcode1%TYPE;
      l_remarkcode2txt            importmassdataheader.imh_remarkcode2%TYPE;
      l_remarkcode3txt            importmassdataheader.imh_remarkcode3%TYPE;
      l_remarkcode4txt            importmassdataheader.imh_remarkcode4%TYPE;
      l_remarktexttxt             importmassdataheader.imh_remarktext%TYPE;
      l_oidlinktxt                importmassdataheader.imh_oidlink%TYPE;
      l_determinatortxt           importmassdataheader.imh_determinator%TYPE;



      CURSOR l_importmassdataheader
      IS
         SELECT *
           FROM importmassdataheader
          WHERE imh_iph_id = p_iph_id;


      l_recimportmassdataheader   l_importmassdataheader%ROWTYPE;

      CURSOR l_importmassdatadetail (
         p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
      IS
         SELECT *
           FROM importmassdatadetail
          WHERE imd_imh_id = p_imh_id;

      l_recimportmassdatadetail   l_importmassdatadetail%ROWTYPE;
      l_returnstatus              NUMBER;
      l_indice                    PLS_INTEGER;
      l_counttotal                NUMBER;
      l_count                     NUMBER := 0;
      l_importprotocolheader      importprotocolheader%ROWTYPE;
      l_date                      VARCHAR2 (20);
      l_xyz                       VARCHAR2 (60);
      l_invalidrowcount           NUMBER;
      l_line                      VARCHAR2 (170) := RPAD (' ', 170, '-');
   BEGIN
      l_importprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);

      SELECT COUNT (*)
        INTO l_counttotal
        FROM importmassdataheader
       WHERE imh_iph_id = p_iph_id;

      OPEN l_importmassdataheader;

      LOOP
         FETCH l_importmassdataheader INTO l_recimportmassdataheader;

         EXIT WHEN l_importmassdataheader%NOTFOUND;
         l_count := l_count + 1;
         pkg_processingstatus.p_setstatusbar (l_count, l_counttotal);

         l_systemprecision.delete ();
         l_codeprecision.delete ();
         l_oid.delete ();
         l_watercourse.delete ();
         l_locality.delete ();
         l_calledplace.delete ();
         l_observers.delete ();
         l_period.delete ();
         l_project.delete ();
         l_reporturl.delete ();
         l_makroindexprovide.delete ();
         l_spearindexprovide.delete ();
         l_ibchindexprovide.delete ();
         l_elevation.delete ();
         l_indicetype.delete ();
         l_remarkcode1.delete ();
         l_remarkcode2.delete ();
         l_remarkcode3.delete ();
         l_remarkcode4.delete ();
         l_remarktext.delete ();
         l_oidlink.delete ();
         l_determinator.delete ();

         l_date :=
               NVL (l_recimportmassdataheader.imh_day, '--')
            || '/'
            || NVL (l_recimportmassdataheader.imh_month, '--')
            || '/'
            || NVL (l_recimportmassdataheader.imh_year, '----');
         l_xyz :=
               '('
            || l_recimportmassdataheader.imh_startpoint_x
            || ';'
            || l_recimportmassdataheader.imh_startpoint_y
            || ';'
            || NVL (l_recimportmassdataheader.imh_elevation, '----')
            || ')';
         pkg_importprotocollog.p_writelog (p_iph_id,
                                           l_recimportmassdataheader.imh_id, -- IMH_ID
                                           pkg_exception.cst_info,
                                           NULL,                 -- Field name
                                           l_line);
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            l_recimportmassdataheader.imh_id,                        -- IMH_ID
            pkg_exception.cst_startcheckuniqbycoord,
            NULL,                                                -- Field name
            l_date,
            l_xyz);

         OPEN l_importmassdatadetail (l_recimportmassdataheader.imh_id);

         LOOP
            FETCH l_importmassdatadetail INTO l_recimportmassdatadetail;

            EXIT WHEN l_importmassdatadetail%NOTFOUND;

            IF NOT l_recimportmassdatadetail.imd_systemprecision IS NULL
            THEN
               pkg_importmassdataheader.p_addsystemprecision (
                  l_recimportmassdatadetail.imd_systemprecision,
                  l_systemprecision);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_codeprecision IS NULL
            THEN
               pkg_importmassdataheader.p_addcodeprecision (
                  l_recimportmassdatadetail.imd_codeprecision,
                  l_codeprecision);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_oid IS NULL
            THEN
               pkg_importmassdataheader.p_addoid (
                  l_recimportmassdatadetail.imd_oid,
                  l_oid);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_watercourse IS NULL
            THEN
               pkg_importmassdataheader.p_addwatercourse (
                  l_recimportmassdatadetail.imd_watercourse,
                  l_watercourse);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_locality IS NULL
            THEN
               pkg_importmassdataheader.p_addlocality (
                  l_recimportmassdatadetail.imd_locality,
                  l_locality);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_calledplace IS NULL
            THEN
               pkg_importmassdataheader.p_addcalledplace (
                  l_recimportmassdatadetail.imd_calledplace,
                  l_calledplace);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_observers IS NULL
            THEN
               pkg_importmassdataheader.p_addobservers (
                  l_recimportmassdatadetail.imd_observers,
                  l_observers);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_period IS NULL
            THEN
               pkg_importmassdataheader.p_addperiod (
                  l_recimportmassdatadetail.imd_period,
                  l_period);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_project IS NULL
            THEN
               pkg_importmassdataheader.p_addproject (
                  l_recimportmassdatadetail.imd_project,
                  l_project);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_reporturl IS NULL
            THEN
               pkg_importmassdataheader.p_addreporturl (
                  l_recimportmassdatadetail.imd_reporturl,
                  l_reporturl);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_makroindexprovide IS NULL
            THEN
               pkg_importmassdataheader.p_addmakroindexprovide (
                  l_recimportmassdatadetail.imd_makroindexprovide,
                  l_makroindexprovide);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_spearindexprovide IS NULL
            THEN
               pkg_importmassdataheader.p_addspearindexprovide (
                  l_recimportmassdatadetail.imd_spearindexprovide,
                  l_spearindexprovide);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_ibchindexprovide IS NULL
            THEN
               pkg_importmassdataheader.p_addibchindexprovide (
                  l_recimportmassdatadetail.imd_ibchindexprovide,
                  l_ibchindexprovide);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_swisscoord_z IS NULL
            THEN
               pkg_importmassdataheader.p_addelevation (
                  l_recimportmassdatadetail.imd_swisscoord_z,
                  l_elevation);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_indicetype IS NULL
            THEN
               pkg_importmassdataheader.p_addindicetype (
                  l_recimportmassdatadetail.imd_indicetype,
                  l_indicetype);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_remarkcode1 IS NULL
            THEN
               pkg_importmassdataheader.p_addremarkcode1 (
                  l_recimportmassdatadetail.imd_remarkcode1,
                  l_remarkcode1);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_remarkcode2 IS NULL
            THEN
               pkg_importmassdataheader.p_addremarkcode2 (
                  l_recimportmassdatadetail.imd_remarkcode2,
                  l_remarkcode2);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_remarkcode3 IS NULL
            THEN
               pkg_importmassdataheader.p_addremarkcode3 (
                  l_recimportmassdatadetail.imd_remarkcode3,
                  l_remarkcode3);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_remarkcode4 IS NULL
            THEN
               pkg_importmassdataheader.p_addremarkcode4 (
                  l_recimportmassdatadetail.imd_remarkcode4,
                  l_remarkcode4);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_remarktext IS NULL
            THEN
               pkg_importmassdataheader.p_addremarktext (
                  l_recimportmassdatadetail.imd_remarktext,
                  l_remarktext);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_oidlink IS NULL
            THEN
               pkg_importmassdataheader.p_addoidlink (
                  l_recimportmassdatadetail.imd_oidlink,
                  l_oidlink);
            END IF;

            IF NOT l_recimportmassdatadetail.imd_determinator IS NULL
            THEN
               pkg_importmassdataheader.p_adddeterminator (
                  l_recimportmassdatadetail.imd_determinator,
                  l_determinator);
            END IF;
         END LOOP;

         CLOSE l_importmassdatadetail;

         p_validateunicityheader (p_iph_id,
                                  l_recimportmassdataheader.imh_id,
                                  l_recimportmassdataheader.imh_startpoint_x,
                                  l_recimportmassdataheader.imh_startpoint_y,
                                  l_recimportmassdataheader.imh_elevation,
                                  l_recimportmassdataheader.imh_day,
                                  l_recimportmassdataheader.imh_month,
                                  l_recimportmassdataheader.imh_year,
                                  l_systemprecision,
                                  l_codeprecision,
                                  l_oid,
                                  l_watercourse,
                                  l_locality,
                                  l_calledplace,
                                  l_observers,
                                  l_period,
                                  l_project,
                                  l_reporturl,
                                  l_makroindexprovide,
                                  l_spearindexprovide,
                                  l_ibchindexprovide,
                                  l_elevation,
                                  l_indicetype,
                                  l_remarkcode1,
                                  l_remarkcode2,
                                  l_remarkcode3,
                                  l_remarkcode4,
                                  l_remarktext,
                                  l_oidlink,
                                  l_determinator,
                                  l_returnstatus);
         p_completeheaderitem (l_systemprecision,
                               l_codeprecision,
                               l_oid,
                               l_watercourse,
                               l_locality,
                               l_calledplace,
                               l_observers,
                               l_period,
                               l_project,
                               l_reporturl,
                               l_makroindexprovide,
                               l_spearindexprovide,
                               l_ibchindexprovide,
                               l_elevation,
                               l_indicetype,
                               l_remarkcode1,
                               l_remarkcode2,
                               l_remarkcode3,
                               l_remarkcode4,
                               l_remarktext,
                               l_oidlink,
                               l_determinator,
                               l_systemprecisiontxt,
                               l_codeprecisiontxt,
                               l_oidtxt,
                               l_watercoursetxt,
                               l_localitytxt,
                               l_calledplacetxt,
                               l_observerstxt,
                               l_periodtxt,
                               l_projecttxt,
                               l_reporturltxt,
                               l_makroindextxt,
                               l_spearindextxt,
                               l_ibchindextxt,
                               l_elevationtxt,
                               l_indicetypetxt,
                               l_remarkcode1txt,
                               l_remarkcode2txt,
                               l_remarkcode3txt,
                               l_remarkcode4txt,
                               l_remarktexttxt,
                               l_oidlinktxt,
                               l_determinatortxt);



         pkg_importmassdataheader.p_updateheader (
            l_recimportmassdataheader.imh_id,
            l_systemprecisiontxt,
            l_codeprecisiontxt,
            l_oidtxt,
            l_watercoursetxt,
            l_localitytxt,
            l_calledplacetxt,
            l_observerstxt,
            l_periodtxt,
            l_projecttxt,
            l_reporturltxt,
            l_makroindextxt,
            l_spearindextxt,
            l_ibchindextxt,
            l_elevationtxt,
            l_indicetypetxt,
            l_remarkcode1txt,
            l_remarkcode2txt,
            l_remarkcode3txt,
            l_remarkcode4txt,
            l_remarktexttxt,
            l_oidlinktxt,
            l_determinatortxt);

         IF l_returnstatus = pkg_constante.cst_returnstatusok
         THEN
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               l_recimportmassdataheader.imh_id,                     -- IMH_ID
               pkg_exception.cst_endcheckuniqbycoord,
               NULL,                                             -- Field name
               l_date,
               l_xyz);
         ELSE
            pkg_importmassdataheader.p_setvalidstatus (
               l_recimportmassdataheader.imh_id,
               pkg_constante.cst_validstatusnotok);
            pkg_importmassdatadetail.p_setvalidstatusbyimh_id (
               l_recimportmassdataheader.imh_id,
               pkg_constante.cst_validstatusnotok);
            l_invalidrowcount :=
               pkg_importmassdatadetail.f_getinvalidrowcount (
                  l_recimportmassdataheader.imh_id);
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               l_recimportmassdataheader.imh_id,                     -- IMH_ID
               pkg_exception.cst_endcheckuniqbycoorderror,
               NULL,                                             -- Field name
               TO_CHAR (l_invalidrowcount),
               l_date,
               l_xyz);


            NULL;
         END IF;
      END LOOP;

      CLOSE l_importmassdataheader;

      pkg_processingsteplog.p_setmeasuredata (
         l_counttotal,
         pkg_processingsteplog.cst_measureunitrowcount);
      NULL;
   END;



   /*-------------------------------------------------------------------*/
   PROCEDURE p_loadlistrequiredfield (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE)
   /*------------------------------------------------------------------*/
   IS
      CURSOR l_protocolmappingmassfield
      IS
         SELECT pmm_code_midatfldcmt, pmm_columnname
           FROM protocolmappingmassfield
          WHERE     pmm_ptv_id = p_importprotocolheader.iph_ptv_id
                AND pmm_isnotnull = pkg_constante.cst_yes;

      l_recprotocolmappingmassfield   l_protocolmappingmassfield%ROWTYPE;
   BEGIN
      gbl_listrequiredfield.delete;

      OPEN l_protocolmappingmassfield;

      LOOP
         FETCH l_protocolmappingmassfield INTO l_recprotocolmappingmassfield;

         EXIT WHEN l_protocolmappingmassfield%NOTFOUND;

         gbl_listrequiredfield (l_recprotocolmappingmassfield.pmm_columnname) :=
            l_recprotocolmappingmassfield.pmm_code_midatfldcmt;
      END LOOP;

      CLOSE l_protocolmappingmassfield;
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_loadlistrequiredgroupfield (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_groupfield             IN protocolmappingmassfield.pmm_isnotnullgroup%TYPE)
   /*------------------------------------------------------------------*/
   IS
      CURSOR l_protocolmappingmassfield
      IS
         SELECT pmm_code_midatfldcmt, pmm_columnname
           FROM protocolmappingmassfield
          WHERE     pmm_ptv_id = p_importprotocolheader.iph_ptv_id
                AND pmm_isnotnullgroup = p_groupfield;

      l_recprotocolmappingmassfield   l_protocolmappingmassfield%ROWTYPE;
   BEGIN
      gbl_listrequiredfield.delete;

      OPEN l_protocolmappingmassfield;

      LOOP
         FETCH l_protocolmappingmassfield INTO l_recprotocolmappingmassfield;

         EXIT WHEN l_protocolmappingmassfield%NOTFOUND;
         gbl_listrequiredfield (l_recprotocolmappingmassfield.pmm_columnname) :=
            l_recprotocolmappingmassfield.pmm_code_midatfldcmt;
      END LOOP;

      CLOSE l_protocolmappingmassfield;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_displayrequiredfield (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_lan_id                 IN language.lan_id%TYPE,
      p_exceptionheader        IN NUMBER)
   /*-------------------------------------------------------------*/
   IS
      l_key                          protocolmappingmassfield.pmm_columnname%TYPE;
      l_reccodevalue                 codevalue%ROWTYPE;
      l_reccodedesignation           codedesignation%ROWTYPE;
      l_count                        NUMBER;
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
   BEGIN
      l_key := gbl_listrequiredfield.FIRST;
      pkg_importprotocollog.p_writelog (p_importprotocolheader.iph_id,
                                        NULL,                        -- IMH_ID
                                        p_exceptionheader,
                                        NULL                     -- Field name
                                            );

      l_count := 0;

      WHILE NOT l_key IS NULL -- Key contient le nom du champ dans la table (IMD_*)
      LOOP
         -- Il est possible qu'un champ requis ne soit pas défini dans le cas d'un groupe (exemple pour la systématique
         l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_fieldispresent (
               p_importprotocolheader.iph_id,
               l_key);

         IF NOT l_recimportmassmappingheader.ime_id IS NULL
         THEN
            l_count := l_count + 1;
            l_reccodevalue :=
               pkg_codevalue.f_getfromcode (
                  gbl_listrequiredfield (l_key),
                  pkg_codereference.cst_crf_midatfldcmt);
            l_reccodedesignation :=
               pkg_codedesignation.f_returnrecmaintypeatleastone (
                  l_reccodevalue.cvl_id,
                  p_lan_id);


            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,                                                 -- IMH_ID
               pkg_exception.cst_displayrequiredfield,
               l_key,                                            -- Field name
                  ' - '
               || TO_CHAR (l_count)
               || ' - '
               || l_recimportmassmappingheader.ime_excelfieldname,
               l_reccodedesignation.cdn_designation);
         END IF;

         l_key := gbl_listrequiredfield.NEXT (l_key);
      END LOOP;
   END;



   /*-------------------------------------------------------------*/
   FUNCTION f_buildsqlmandatoryfldnotfill (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_type                   IN VARCHAR2)
      RETURN VARCHAR2
   /*------------------------------------------------------------*/
   IS
      l_sql        VARCHAR2 (18000);
      l_key        protocolmappingmassfield.pmm_columnname%TYPE;
      l_first      BOOLEAN := TRUE;
      l_operator   VARCHAR2 (10);
   BEGIN
      IF p_type = cst_notnulltypefield
      THEN
         l_operator := ' OR ';
      ELSIF p_type = cst_notnulltypegroupfield
      THEN
         l_operator := ' AND ';
      END IF;

      l_sql := ' SELECT IMD_ID , 
            IMD_SOURCELINE,
            IMD_day,
            IMD_month,
            IMD_year,
            IMD_swisscoord_x,
            IMD_swisscoord_y,
            IMD_swisscoord_z FROM IMPORTMASSDATADETAIL
            WHERE IMD_IPH_ID= ' || TO_CHAR (p_importprotocolheader.iph_id);
      l_key := gbl_listrequiredfield.FIRST;

      WHILE NOT l_key IS NULL
      LOOP
         IF l_first
         THEN
            l_first := FALSE;
            l_sql := l_sql || ' AND ( ' || l_key || ' IS NULL ';
         ELSE
            l_sql := l_sql || l_operator || l_key || ' IS NULL';
         END IF;

         l_key := gbl_listrequiredfield.NEXT (l_key);
      END LOOP;

      IF NOT l_first
      THEN
         l_sql := l_sql || ')';
      ELSE
         -- Aucun champ n'est requis
         l_sql := l_sql || ' AND 1=0';
      END IF;

      pkg_debug.p_write (
         'PKG_VALIDATEMASSDETAIL.f_buildsqlmandatoryfldnotfill',
         l_sql);
      RETURN l_sql;
   END;

   /*------------------------------------------------------------*/
   FUNCTION f_fieldfilled (
      p_imd_id      IN importmassdatadetail.imd_id%TYPE,
      p_fieldname   IN protocolmappingmassfield.pmm_columnname%TYPE)
      RETURN CHAR
   /*------------------------------------------------------------*/
   IS
      l_sql      VARCHAR2 (9000);
      l_cursor   t_cursor;
      l_count    NUMBER;
   BEGIN
      l_sql :=
            'SELECT COUNT(*) FROM importmassdatadetail WHERE IMD_ID='
         || TO_CHAR (p_imd_id)
         || ' AND NOT '
         || p_fieldname
         || ' IS NULL';
      pkg_debug.p_write ('PKG_VALIDATEMASSDETAIL.f_fieldfilled', l_sql);

      OPEN l_cursor FOR l_sql;

      FETCH l_cursor INTO l_count;

      CLOSE l_cursor;

      IF l_count = 0
      THEN
         RETURN pkg_constante.cst_no;
      ELSE
         RETURN pkg_constante.cst_yes;
      END IF;

      NULL;
   END;


   /*-------------------------------------------------------------*/
   FUNCTION f_buildfieldtextisnull (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_imd_id                 IN importmassdatadetail.imd_id%TYPE)
      RETURN VARCHAR2
   /*-----------------------------------------------------------------*/
   IS
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
      l_text                         VARCHAR2 (1024);
      l_response                     VARCHAR2 (10);

      CURSOR l_listnotnullfield
      IS
         SELECT ime_excelfieldname, pmm_columnname
           FROM protocolmappingmassfield
                INNER JOIN importmassmappingheader ON pmm_id = ime_pmm_id
          WHERE     pmm_isnotnull = pkg_constante.cst_yes
                AND pmm_ptv_id = p_importprotocolheader.iph_ptv_id
                AND ime_iph_id = p_importprotocolheader.iph_id;

      l_reclistnotnullfield          l_listnotnullfield%ROWTYPE;
   BEGIN
      OPEN l_listnotnullfield;

      LOOP
         FETCH l_listnotnullfield INTO l_reclistnotnullfield;

         EXIT WHEN l_listnotnullfield%NOTFOUND;
         l_response :=
            f_fieldfilled (p_imd_id, l_reclistnotnullfield.pmm_columnname);

         IF l_response = pkg_constante.cst_no
         THEN
            IF l_text IS NULL
            THEN
               l_text := l_reclistnotnullfield.ime_excelfieldname;
            ELSE
               l_text :=
                  l_text || ', ' || l_reclistnotnullfield.ime_excelfieldname;
            END IF;
         END IF;
      END LOOP;

      CLOSE l_listnotnullfield;

      RETURN l_text;

      NULL;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_buildfieldgrptextisnull (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_imd_id                 IN importmassdatadetail.imd_id%TYPE,
      p_isnotnullgroup         IN protocolmappingmassfield.pmm_isnotnullgroup%TYPE)
      RETURN VARCHAR2
   /*-----------------------------------------------------------------*/
   IS
      l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
      l_text                         VARCHAR2 (4096);

      CURSOR l_listgroupfield
      IS
         SELECT ime_excelfieldname
           FROM protocolmappingmassfield
                INNER JOIN importmassmappingheader ON pmm_id = ime_pmm_id
          WHERE     pmm_isnotnullgroup = p_isnotnullgroup
                AND pmm_ptv_id = p_importprotocolheader.iph_ptv_id
                AND ime_iph_id = p_importprotocolheader.iph_id;

      l_reclistgroupfield            l_listgroupfield%ROWTYPE;
   BEGIN
      l_text := NULL;

      OPEN l_listgroupfield;

      LOOP
         FETCH l_listgroupfield INTO l_reclistgroupfield;

         EXIT WHEN l_listgroupfield%NOTFOUND;

         IF l_text IS NULL
         THEN
            l_text := l_reclistgroupfield.ime_excelfieldname;
         ELSE
            l_text := l_text || ', ' || l_reclistgroupfield.ime_excelfieldname;
         END IF;
      END LOOP;

      CLOSE l_listgroupfield;

      RETURN l_text;

      NULL;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_validaterequiredgrpfield (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_lan_id                 IN     language.lan_id%TYPE,
      p_errorcount                OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      CURSOR l_protocolmappingmassfield
      IS
         SELECT DISTINCT pmm_isnotnullgroup
           FROM protocolmappingmassfield
          WHERE     pmm_ptv_id = p_importprotocolheader.iph_ptv_id
                AND NOT pmm_isnotnullgroup IS NULL;

      l_recprotocolmappingmassfield   l_protocolmappingmassfield%ROWTYPE;

      l_sql                           VARCHAR2 (18000);
      l_cursor                        t_cursor;
      l_imd_id                        importmassdatadetail.imd_id%TYPE;
      l_day                           importmassdatadetail.imd_day%TYPE;
      l_month                         importmassdatadetail.imd_month%TYPE;
      l_year                          importmassdatadetail.imd_year%TYPE;
      l_swisscoord_x                  importmassdatadetail.imd_swisscoord_x%TYPE;
      l_swisscoord_y                  importmassdatadetail.imd_swisscoord_y%TYPE;
      l_swisscoord_z                  importmassdatadetail.imd_swisscoord_z%TYPE;
      l_sourceline                    importmassdatadetail.imd_sourceline%TYPE;
      l_first                         BOOLEAN := TRUE;
      l_count                         NUMBER;
      l_buildedtext                   VARCHAR2 (1024);
      l_counttotal                    NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_counttotal
        FROM protocolmappingmassfield
       WHERE     pmm_ptv_id = p_importprotocolheader.iph_ptv_id
             AND NOT pmm_isnotnullgroup IS NULL;

      -- Un des  champs obligatoires de groupe doit être renseignées
      OPEN l_protocolmappingmassfield;

      LOOP
         FETCH l_protocolmappingmassfield INTO l_recprotocolmappingmassfield;

         EXIT WHEN l_protocolmappingmassfield%NOTFOUND;
         p_loadlistrequiredgroupfield (
            p_importprotocolheader,
            l_recprotocolmappingmassfield.pmm_isnotnullgroup);

         l_sql :=
            f_buildsqlmandatoryfldnotfill (p_importprotocolheader,
                                           cst_notnulltypegroupfield);

         l_count := 0;

         OPEN l_cursor FOR l_sql;

         LOOP
            FETCH l_cursor
               INTO l_imd_id,
                    l_sourceline,
                    l_day,
                    l_month,
                    l_year,
                    l_swisscoord_x,
                    l_swisscoord_y,
                    l_swisscoord_z;

            EXIT WHEN l_cursor%NOTFOUND;
            l_count := l_count + 1;
            pkg_processingstatus.p_setstatusbar (l_count, l_counttotal);

            IF l_first
            THEN
               p_displayrequiredfield (
                  p_importprotocolheader,
                  p_lan_id,
                  pkg_exception.cst_massgroupfieldrequired);
               pkg_importprotocollog.p_writelog (
                  p_importprotocolheader.iph_id,
                  NULL,                                              -- IMH_ID
                  pkg_exception.cst_excludereqfieldnotfilled,
                  NULL                                           -- Field name
                      );
               l_first := FALSE;
            END IF;

            l_buildedtext :=
               f_buildfieldgrptextisnull (
                  p_importprotocolheader,
                  l_imd_id,
                  l_recprotocolmappingmassfield.pmm_isnotnullgroup);
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,                                                 -- IMH_ID
               pkg_exception.cst_fieldnotfilled,
               NULL,                                             -- Field name
               l_buildedtext,
               TO_CHAR (l_sourceline));
            pkg_importmassdatadetail.p_setvalidstatus (
               l_imd_id,
               pkg_constante.cst_validstatusnotok);
         END LOOP;

         CLOSE l_cursor;
      END LOOP;

      CLOSE l_protocolmappingmassfield;

      p_errorcount := l_count;
      pkg_processingsteplog.p_setmeasuredata (
         l_count,
         pkg_processingsteplog.cst_measureunitrowcount);

      NULL;
   END;



   /*--------------------------------------------------------------*/
   PROCEDURE p_validaterequiredfield (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_lan_id                 IN     language.lan_id%TYPE,
      p_errorcount                OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      l_sql            VARCHAR2 (18000);
      l_cursor         t_cursor;
      l_imd_id         importmassdatadetail.imd_id%TYPE;
      l_day            importmassdatadetail.imd_day%TYPE;
      l_month          importmassdatadetail.imd_month%TYPE;
      l_year           importmassdatadetail.imd_year%TYPE;
      l_swisscoord_x   importmassdatadetail.imd_swisscoord_x%TYPE;
      l_swisscoord_y   importmassdatadetail.imd_swisscoord_y%TYPE;
      l_swisscoord_z   importmassdatadetail.imd_swisscoord_z%TYPE;
      l_sourceline     importmassdatadetail.imd_sourceline%TYPE;
      l_first          BOOLEAN := TRUE;
      l_count          NUMBER;
      l_buildedtext    VARCHAR2 (1024);
      l_counttotal     NUMBER;
   BEGIN
      -- Les champs obligatoires doivent être renseignées
      p_loadlistrequiredfield (p_importprotocolheader);
      l_sql :=
         f_buildsqlmandatoryfldnotfill (p_importprotocolheader,
                                        cst_notnulltypefield);
      l_counttotal := pkg_stringutil.f_returnrowcountfromsql (l_sql);

      l_count := 0;

      OPEN l_cursor FOR l_sql;

      LOOP
         FETCH l_cursor
            INTO l_imd_id,
                 l_sourceline,
                 l_day,
                 l_month,
                 l_year,
                 l_swisscoord_x,
                 l_swisscoord_y,
                 l_swisscoord_z;

         EXIT WHEN l_cursor%NOTFOUND;
         l_count := l_count + 1;
         pkg_processingstatus.p_setstatusbar (l_count, l_counttotal);

         IF l_first
         THEN
            p_displayrequiredfield (p_importprotocolheader,
                                    p_lan_id,
                                    pkg_exception.cst_massfieldrequired);
            pkg_importprotocollog.p_writelog (
               p_importprotocolheader.iph_id,
               NULL,                                                 -- IMH_ID
               pkg_exception.cst_excludereqfieldnotfilled,
               NULL                                              -- Field name
                   );
            l_first := FALSE;
         END IF;

         l_buildedtext :=
            f_buildfieldtextisnull (p_importprotocolheader, l_imd_id);


         pkg_importprotocollog.p_writelog (p_importprotocolheader.iph_id,
                                           NULL,                     -- IMH_ID
                                           pkg_exception.cst_fieldnotfilled,
                                           NULL,                 -- Field name
                                           l_buildedtext,
                                           TO_CHAR (l_sourceline));
         pkg_importmassdatadetail.p_setvalidstatus (
            l_imd_id,
            pkg_constante.cst_validstatusnotok);
      END LOOP;

      CLOSE l_cursor;

      p_errorcount := l_count;
      pkg_processingsteplog.p_setmeasuredata (
         l_count,
         pkg_processingsteplog.cst_measureunitrowcount);

      NULL;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_test
   /*--------------------------------------------------------------*/
   IS
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
      l_iph_id                    NUMBER := 531;
      l_count                     NUMBER;
   BEGIN
      pkg_importprotocollog.p_purgebyiphid (l_iph_id);
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (l_iph_id);
      p_validaterequiredfield (l_recimportprotocolheader, 1, l_count);
      p_validaterequiredgrpfield (l_recimportprotocolheader, 1, l_count);
      pkg_importmassdatadetail.p_identifyheader (l_iph_id, 1, l_count);
      p_completeheader (l_iph_id, 1);
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_validateheader
   /*--------------------------------------------------------------*/
   IS
   /*
    L'identifiant du header est:
      p_day
     p_month
     p_year
     p_startpoint_x
     p_startpoint_y
     p_elevation
     -- Les autres  attributs:
       p_systemprecision
     p_codeprecision
     p_oid
     p_watercourse
     p_locality
     p_calledplace
     p_observers
     doivent être identiques

     Les attributs:
        p_reporturl     ,
      p_comment
    Sont associés au détail
  */



   BEGIN
      NULL;
   END;



   /*--------------------------------------------------------------*/
   PROCEDURE p_validate (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id                 IN     language.lan_id%TYPE,
      p_returnstatus              OUT NUMBER) -- Retourne NOTOK si aucun header n'est valide
   /*--------------------------------------------------------------*/
   IS
      l_starttime               TIMESTAMP;
      l_recordcount             NUMBER;
      l_countrequiredgrperror   NUMBER;
      l_countrequirederror      NUMBER;
      l_countidentify           NUMBER;
   BEGIN
      l_starttime := SYSTIMESTAMP;
      p_returnstatus := pkg_constante.cst_returnstatusok;
      pkg_importprotocollog.p_logstartsubprocess (
         p_importprotocolheader.iph_id,
         NULL,
         pkg_exception.cst_midatstartexceldataload);
      pkg_processingstatus.p_setstep (
         p_importprotocolheader.iph_pid_id,
         pkg_processingstep.cst_stepcodeloaddata,
         p_lan_id,
         p_usr_id);                                                  -- Step 2

      pkg_java.p_processmassdetail (p_importprotocolheader.iph_id);
      pkg_importmassmappingheader.p_logmapping (
         p_importprotocolheader.iph_id,
         p_lan_id);
      l_recordcount :=
         pkg_importmassdatadetail.f_getrowcount (
            p_importprotocolheader.iph_id);
      pkg_processingstatus.p_updatenumberrecord (
         p_importprotocolheader.iph_pid_id,
         l_recordcount,
         p_usr_id);
      pkg_processingstep.p_setrecordcount (l_recordcount);
      pkg_processingsteplog.p_setmeasuredata (
         l_recordcount,
         pkg_processingsteplog.cst_measureunitrowcount);
      pkg_importprotocollog.p_logendsubprocess (
         p_importprotocolheader.iph_id,
         NULL,
         pkg_exception.cst_midatendexceldataload,
         l_starttime,
         l_recordcount);


      l_starttime := SYSTIMESTAMP;
      pkg_importprotocollog.p_logstartsubprocess (
         p_importprotocolheader.iph_id,
         NULL,
         pkg_exception.cst_midatstartcheckrequiredfld);
      pkg_processingstatus.p_setstep (
         p_importprotocolheader.iph_pid_id,
         pkg_processingstep.cst_checkrequiredfield,
         p_lan_id,
         p_usr_id);                                                  -- Step 3


      p_validaterequiredfield (p_importprotocolheader,
                               p_lan_id,
                               l_countrequirederror);
      pkg_processingstatus.p_setstep (
         p_importprotocolheader.iph_pid_id,
         pkg_processingstep.cst_checkrequiredgrpfield,
         p_lan_id,
         p_usr_id);                                                  -- Step 4
      p_validaterequiredgrpfield (p_importprotocolheader,
                                  p_lan_id,
                                  l_countrequiredgrperror);

      pkg_processingstatus.p_setstep (p_importprotocolheader.iph_pid_id,
                                      pkg_processingstep.cst_buildheader,
                                      p_lan_id,
                                      p_usr_id);                      -- Step5
      pkg_importmassdatadetail.p_identifyheader (
         p_importprotocolheader.iph_id,
         p_lan_id,
         l_countidentify);

      pkg_importprotocollog.p_logendsubprocess (
         p_importprotocolheader.iph_id,
         NULL,
         pkg_exception.cst_midatendcheckrequiredfld,
         l_starttime,
         NULL);



      l_starttime := SYSTIMESTAMP;
      pkg_importprotocollog.p_logstartsubprocess (
         p_importprotocolheader.iph_id,
         NULL,
         pkg_exception.cst_startmasscompleteheader);

      pkg_processingstatus.p_setstep (
         p_importprotocolheader.iph_pid_id,
         pkg_processingstep.cst_consolidateheader,
         p_lan_id,
         p_usr_id);                                                  -- Step 6

      p_completeheader (p_importprotocolheader.iph_id, p_lan_id);
      --
      pkg_validatemassheader.p_validateoidlink (p_importprotocolheader);
      l_recordcount :=
         pkg_importmassdataheader.f_countrows (p_importprotocolheader.iph_id);
      pkg_importprotocollog.p_logendsubprocess (
         p_importprotocolheader.iph_id,
         NULL,
         pkg_exception.cst_endmasscompleteheader,
         l_starttime,
         l_recordcount);



      NULL;
   END;
END pkg_validatemassdetail;
/

