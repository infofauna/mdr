create PACKAGE BODY       pkg_migr_ibch2019_hdr
AS
    /******************************************************************************
       NAME:       pkg_migr_ibch2019_hdr
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        3.07.2020      burrif       1. Created this package.
    ******************************************************************************/


    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.0, juillet  2020' ;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_insertdata (p_ibch_q      IN     codevalue.cvl_code%TYPE,
                            p_hdr_order   IN     hydroregime.hdr_order%TYPE,
                            p_hdr_value   IN     hydroregime.hdr_value%TYPE,
                            p_hdr_id         OUT hydroregime.hdr_id%TYPE)
    /*-----------------------------------------------------------------*/
    IS
        l_rechydroregime   hydroregime%ROWTYPE;
    BEGIN
        l_rechydroregime :=
            pkg_hydroregime.f_getrecordbyibch_q_code (p_ibch_q);

        IF l_rechydroregime.hdr_id IS NULL
        THEN
            pkg_hydroregime.p_writewithcode (p_ibch_q,
                                             p_hdr_order,
                                             p_hdr_value,
                                             p_hdr_id);
        ELSE
            p_hdr_id := l_rechydroregime.hdr_id;
        END IF;
    END;

    /*--------------------------------------------------------------------*/
    PROCEDURE p_delete
    /*--------------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM hydroregime;

        pkg_migr_ibch2019_util.p_recreatesequence ('HYDROREGIME',
                                                   'SEQ_HYDROREGIME',
                                                   'HDR_ID');
    END;

    /*-------------------------------------------------------*/
    PROCEDURE p_insertalldata
    /*-------------------------------------------------------*/
    IS
        l_hdr_id   hydroregime.hdr_id%TYPE;
    BEGIN
        p_insertdata (pkg_codevalue.cst_ibch_q_1,
                      1,                                       --  p_hdr_order
                      0.98,                                --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_2,
                      2,                                       --  p_hdr_order
                      0.98,                                --  p_hdr_value   ,
                      l_hdr_id);
        p_insertdata (pkg_codevalue.cst_ibch_q_3,
                      3,                                       --  p_hdr_order
                      0.85,                                --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_4,
                      4,                                       --  p_hdr_order
                      0.78,                                --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_5,
                      5,                                       --  p_hdr_order
                      0.79,                                --  p_hdr_value   ,
                      l_hdr_id);


        p_insertdata (pkg_codevalue.cst_ibch_q_6,
                      6,                                       --  p_hdr_order
                      0.40,                                --  p_hdr_value   ,
                      l_hdr_id);


        p_insertdata (pkg_codevalue.cst_ibch_q_7,
                      7,                                       --  p_hdr_order
                      0.30,                                --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_8,
                      8,                                       --  p_hdr_order
                      0.22,                                --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_9,
                      9,                                       --  p_hdr_order
                      -0.13,                               --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_10,
                      10,                                      --  p_hdr_order
                      0,                                   --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_11,
                      11,                                      --  p_hdr_order
                      -0.32,                               --  p_hdr_value   ,
                      l_hdr_id);


        p_insertdata (pkg_codevalue.cst_ibch_q_12,
                      12,                                      --  p_hdr_order
                      -0.24,                               --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_13,
                      13,                                      --  p_hdr_order
                      0.61,                                --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_14,
                      14,                                      --  p_hdr_order
                      0.31,                                --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_15,
                      15,                                      --  p_hdr_order
                      -0.06,                               --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_16,
                      16,                                      --  p_hdr_order
                      0.21,                                --  p_hdr_value   ,
                      l_hdr_id);

        p_insertdata (pkg_codevalue.cst_ibch_q_17,
                      17,                                      --  p_hdr_order
                      0.06,                                --  p_hdr_value   ,
                      l_hdr_id);
    END;
END pkg_migr_ibch2019_hdr;
/

