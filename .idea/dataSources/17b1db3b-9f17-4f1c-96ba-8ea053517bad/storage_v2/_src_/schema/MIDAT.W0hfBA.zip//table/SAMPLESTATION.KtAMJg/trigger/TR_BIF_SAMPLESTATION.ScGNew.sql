create trigger TR_BIF_SAMPLESTATION
    before insert
    on SAMPLESTATION
    for each row
DECLARE
BEGIN
   IF :new.SST_id IS NULL
   THEN
      :new.SST_id := seq_SAMPLESTATION.NEXTVAL;
   END IF;

   :new.SST_credate := SYSDATE;
   :new.SST_creuser := USER;
END tr_bif_SAMPLESTATION;

/

