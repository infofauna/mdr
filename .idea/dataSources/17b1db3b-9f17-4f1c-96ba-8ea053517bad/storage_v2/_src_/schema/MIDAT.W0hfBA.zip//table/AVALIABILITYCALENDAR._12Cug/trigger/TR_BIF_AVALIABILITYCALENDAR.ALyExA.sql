create trigger TR_BIF_AVALIABILITYCALENDAR
    before insert
    on AVALIABILITYCALENDAR
    for each row
DECLARE
BEGIN
   IF :new.iac_id IS NULL
   THEN
      :new.iac_id := seq_AVALIABILITYCALENDAR.NEXTVAL;
   END IF;

   :new.iac_credate := SYSDATE;
   :new.iac_creuser := USER;
END tr_bif_AVALIABILITYCALENDAR;

/

