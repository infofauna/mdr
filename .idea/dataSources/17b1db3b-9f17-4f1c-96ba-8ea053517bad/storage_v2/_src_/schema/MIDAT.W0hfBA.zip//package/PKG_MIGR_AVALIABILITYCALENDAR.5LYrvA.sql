create PACKAGE       pkg_migr_avaliabilitycalendar
AS
   /******************************************************************************
      NAME:       PKG_MIGR_AVALIABILITYCALENDAR
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        28/07/2014      burrif       1. Created this package.
   ******************************************************************************/
   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_build_ibch;

   PROCEDURE p_build_spear;

   PROCEDURE p_buildall;
END pkg_migr_avaliabilitycalendar;
/

