create trigger TR_BUF_SAMPLEPROTOCOLGRID
    before update
    on SAMPLEPROTOCOLGRID
    for each row
DECLARE
BEGIN
 
   :new.SPG_moddate := SYSDATE;
   :new.SPG_moduser := USER;
END tr_buf_SAMPLEPROTOCOLGRID;

/

