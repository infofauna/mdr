create trigger TR_BUF_SAMPLEHEADER
    before update
    on SAMPLEHEADER
    for each row
DECLARE
BEGIN
   :new.sph_moddate := SYSDATE;
   :new.sph_moduser := USER;
END tr_buf_sampleheader;

/

