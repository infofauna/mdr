create PACKAGE BODY       pkg_protocolmassfieldrole
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLMASSFIELDROLE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        16.10.2017      burrif       1. Created this package.
   ******************************************************************************/



   /* La table PROTOCOLMASSFIELDROLE contient les restrictions d'utilisation des
    colonnes du protocol de masse en fonction des rôles. */

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, octobre  2017' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_fieldhasrestrictrole (
      p_pmm_id   IN protocolmassfieldrole.pfr_pmm_id%TYPE)
      RETURN VARCHAR2
   /*----------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM protocolmassfieldrole
       WHERE pfr_pmm_id = p_pmm_id;

      IF l_count > 0
      THEN
         RETURN pkg_constante.cst_yes;
      ELSE
         RETURN pkg_constante.cst_no;
      END IF;
   END;

   /*--------------------------------------------------------*/
   PROCEDURE p_write (
      p_apr_id   IN     protocolmassfieldrole.pfr_apr_id%TYPE,
      p_pmm_id   IN     protocolmassfieldrole.pfr_pmm_id%TYPE,
      p_pfr_id      OUT protocolmassfieldrole.pfr_id%TYPE)
   /*---------------------------------------------------------*/
   IS
   BEGIN
      p_pfr_id := seq_protocolmassfieldrole.NEXTVAL;

      INSERT INTO protocolmassfieldrole (pfr_apr_id, pfr_pmm_id, pfr_id)
           VALUES (p_apr_id, p_pmm_id, p_pfr_id);
   END;


   /*--------------------------------------------------------*/
   FUNCTION f_getrecord (p_pfr_id IN protocolmassfieldrole.pfr_id%TYPE)
      RETURN protocolmassfieldrole%ROWTYPE
   /*--------------------------------------------------------*/
   IS
      l_recprotocolmassfieldrole   protocolmassfieldrole%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recprotocolmassfieldrole
        FROM protocolmassfieldrole
       WHERE pfr_id = p_pfr_id;

      RETURN l_recprotocolmassfieldrole;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*--------------------------------------------------------*/
   FUNCTION f_userhasright (
      p_usr_id   IN admin_user_role.aur_usr_id%TYPE,
      p_pmm_id   IN protocolmassfieldrole.pfr_pmm_id%TYPE)
      RETURN VARCHAR2
   /*--------------------------------------------------------*/
   IS
      CURSOR l_listrestrictrole
      IS
         SELECT *
           FROM protocolmassfieldrole
          WHERE pfr_pmm_id = p_pmm_id;

      l_reclistrestrictrole   l_listrestrictrole%ROWTYPE;
      l_hasroleid             VARCHAR2 (10);
      l_recadmin_user         admin_user%ROWTYPE;
   BEGIN
      l_recadmin_user := pkg_admin_user.f_getrecord (p_usr_id);

      IF l_recadmin_user.usr_id IS NULL
      THEN
         -- L'utilisateur n'existe pas donc pas de droits
         RETURN pkg_constante.cst_no;
      END IF;

      IF f_fieldhasrestrictrole (p_pmm_id) = pkg_constante.cst_no
      THEN
         -- Pas de restriction donc l'utilisateur a les droits
         RETURN pkg_constante.cst_yes;
      END IF;

      l_hasroleid := pkg_constante.cst_no;

      OPEN l_listrestrictrole;

      LOOP
         FETCH l_listrestrictrole INTO l_reclistrestrictrole;

         EXIT WHEN    l_listrestrictrole%NOTFOUND
                   OR l_hasroleid = pkg_constante.cst_yes;
         l_hasroleid :=
            pkg_admin_user_role.f_userhasroleid (
               p_usr_id,
               l_reclistrestrictrole.pfr_apr_id);
      END LOOP;

      CLOSE l_listrestrictrole;

      RETURN l_hasroleid;
      NULL;
   END;
END pkg_protocolmassfieldrole;
/

