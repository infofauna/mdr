create PACKAGE BODY       pkg_validateprotocolgrid
AS
   /******************************************************************************
      NAME:       PKG_VALIDATEPROTOCOLGRID
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
   ******************************************************************************/


   cst_packageversion      CONSTANT VARCHAR2 (30)
                                       := 'Version 1.0, septembre  2013' ;

   cst_recouvrement_min    CONSTANT NUMBER := 1;
   cst_recouvrement_max    CONSTANT NUMBER := 4;

   cst_substratrange_min   CONSTANT NUMBER := 0;
   cst_substratrange_max   CONSTANT NUMBER := 10;

   cst_largeurmoy_min      CONSTANT NUMBER := 0;
   cst_largeurmoy_max      CONSTANT NUMBER := 9999;

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;



   /*--------------------------------------------------------------*/
   PROCEDURE p_logunexpectederror (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_fieldname                 IN importprotocollog.ipo_fieldname%TYPE,
      p_modulename                IN VARCHAR2)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      pkg_importprotocollog.p_writelog (p_recimportprotocolheader.iph_id,
                                        NULL,
                                        pkg_exception.cst_unexpectederror,
                                        p_fieldname,
                                        p_modulename);
   END;


   /* -------------------------------------------------------------------*/
   PROCEDURE p_returncodevalue (
      p_cvl_id                    IN     codevalue.cvl_id%TYPE,
      p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_reccodevalue                 OUT codevalue%ROWTYPE)
   /*--------------------------------------------------------------------*/
   IS
   BEGIN
      p_reccodevalue := pkg_codevalue.f_getrecord (p_cvl_id);

      IF p_reccodevalue.cvl_id IS NULL
      THEN
         p_logunexpectederror (
            p_recimportprotocolheader,
            NULL,
            'pkg_codevalue.f_getrecord(' || TO_CHAR (p_cvl_id) || ')');
      END IF;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checkcellrange (
      p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_cvl_id_midatitgrdro       IN     protocolmappinggrid.pmg_cvl_code_midatitgrdro%TYPE,
      p_cvl_id_midatitgrdcl       IN     protocolmappinggrid.pmg_cvl_code_midatitgrdcl%TYPE,
      p_cellpos                          VARCHAR2,
      p_value                     IN     importprotocolgrid.ipg_value%TYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      l_reccodevaluemidatitgrdro   codevalue%ROWTYPE;
      l_reccodevaluemidatitgrdcl   codevalue%ROWTYPE;
      l_value                      NUMBER;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      IF p_value IS NULL
      THEN
         RETURN;
      END IF;

      p_returncodevalue (p_cvl_id_midatitgrdro,
                         p_recimportprotocolheader,
                         l_reccodevaluemidatitgrdro);

      IF l_reccodevaluemidatitgrdro.cvl_id IS NULL
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusok;
         RETURN;
      END IF;

      p_returncodevalue (p_cvl_id_midatitgrdcl,
                         p_recimportprotocolheader,
                         l_reccodevaluemidatitgrdcl);

      IF l_reccodevaluemidatitgrdcl.cvl_id IS NULL
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusok;
         RETURN;
      END IF;

      IF NOT l_reccodevaluemidatitgrdro.cvl_code IN
                (pkg_codevalue.cst_midatitgrdro_blkmobil,
                 pkg_codevalue.cst_midatitgrdro_bryophyte,
                 pkg_codevalue.cst_midatitgrdro_spermphytim,
                 pkg_codevalue.cst_midatitgrdro_elorggross,
                 pkg_codevalue.cst_midatitgrdro_elmingross,
                 pkg_codevalue.cst_midatitgrdro_granulgross,
                 pkg_codevalue.cst_midatitgrdro_spermphytem,
                 pkg_codevalue.cst_midatitgrdro_sedimentfin,
                 pkg_codevalue.cst_midatitgrdro_sablelimon,
                 pkg_codevalue.cst_midatitgrdro_surfnatart,
                 pkg_codevalue.cst_midatitgrdro_algmarnarg)
      THEN
         pkg_importprotocollog.p_writelog (
            p_recimportprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_unexpectederroritem,
               l_reccodevaluemidatitgrdro.cvl_code
            || ', '
            || l_reccodevaluemidatitgrdcl.cvl_code,
               l_reccodevaluemidatitgrdro.cvl_code
            || ', '
            || l_reccodevaluemidatitgrdcl.cvl_code);
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         RETURN;
      END IF;


      IF l_reccodevaluemidatitgrdcl.cvl_code =
            pkg_codevalue.cst_midatitgrdcl_recouvrement
      THEN
         -- Recouvremenet entre 0 et 4, le type INTEGER a déjà été validé
         l_value := pkg_stringutil.f_validatenumber (p_value);

         IF l_value < cst_recouvrement_min OR l_value > cst_recouvrement_max
         THEN
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            pkg_importprotocollog.p_writelog (
               p_recimportprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_recouvrementoutofrange,
                  l_reccodevaluemidatitgrdro.cvl_code
               || ', '
               || l_reccodevaluemidatitgrdcl.cvl_code,
               p_value,
               p_cellpos,
               TO_CHAR (cst_recouvrement_min),
               TO_CHAR (cst_recouvrement_max));
         END IF;                                                     -- Erreur

         RETURN;
      END IF;

      IF l_reccodevaluemidatitgrdcl.cvl_code IN
            (pkg_codevalue.cst_midatitgrdcl_v_150,
             pkg_codevalue.cst_midatitgrdcl_150_v_75,
             pkg_codevalue.cst_midatitgrdcl_75_v_25,
             pkg_codevalue.cst_midatitgrdcl_25_v_5,
             pkg_codevalue.cst_midatitgrdcl_v_5)
      THEN
         NULL;                     -- l'utilisateur peut saisir n'importe quoi
      END IF;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_checkonedetail (
      p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_cvl_id_midatitgrdro       IN     protocolmappinggrid.pmg_cvl_code_midatitgrdro%TYPE,
      p_cvl_id_midatitgrdcl       IN     protocolmappinggrid.pmg_cvl_code_midatitgrdcl%TYPE,
      p_cvl_id_grditemcell        IN     protocolmappinggrid.pmg_cvl_id_midatitgrdce%TYPE,
      p_cellpos                   IN     VARCHAR2,
      p_value                     IN     importprotocolgrid.ipg_value%TYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------*/
   IS
      l_reccodevaluegrditemcell   codevalue%ROWTYPE;
      l_value                     NUMBER;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      IF p_value IS NULL
      THEN
         RETURN;
      END IF;

      IF p_cvl_id_grditemcell IS NULL
      THEN
         p_checkcellrange (p_recimportprotocolheader,
                           p_cvl_id_midatitgrdro,
                           p_cvl_id_midatitgrdcl,
                           p_cellpos,
                           p_value,
                           p_returnstatus);
         RETURN;
      END IF;

      p_returncodevalue (p_cvl_id_grditemcell,
                         p_recimportprotocolheader,
                         l_reccodevaluegrditemcell);

      IF l_reccodevaluegrditemcell.cvl_id IS NULL
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusok;
         RETURN;
      END IF;

      IF l_reccodevaluegrditemcell.cvl_code =
            pkg_codevalue.cst_grditemcell_substrdom
      THEN
         l_value := pkg_stringutil.f_validatenumber (p_value);

         IF    l_value < cst_substratrange_min
            OR l_value > cst_substratrange_max
         THEN
            pkg_importprotocollog.p_writelog (
               p_recimportprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_substratoutofrange,
               NULL,
               p_value,
               p_cellpos,
               cst_substratrange_min,
               cst_substratrange_max);
            p_returnstatus := pkg_constante.cst_returnstatusok;
         END IF;

         RETURN;
      END IF;

    

      IF l_reccodevaluegrditemcell.cvl_code =
            pkg_codevalue.cst_grditemcell_largeurmoy
      THEN
         l_value := pkg_stringutil.f_validatenumber (p_value);

         IF l_value < cst_largeurmoy_min OR l_value > cst_largeurmoy_max
         THEN
            pkg_importprotocollog.p_writelog (
               p_recimportprotocolheader.iph_id,
               NULL,
               pkg_exception.cst_averagewidthoutofrange,
               NULL,
               p_value,
               p_cellpos,
               cst_substratrange_min,
               cst_substratrange_max);
         END IF;

         RETURN;
      END IF;
   END;


   /*--------------------------------------------------------------*/
   PROCEDURE p_validatedetail (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      CURSOR l_importprotocolgrid
      IS
         SELECT ipg_id,
                ipg_value,
                pmg_cvl_id_midatitgrdro,
                pmg_cvl_id_midatitgrdcl,
                pmg_cvl_id_midatitgrdce,
                cvl_code,
                pkg_stringutil.f_buildexcelcellref (pmg_cellrowvalue,
                                                    pmg_cellcolumnvalue)
                   cell
           FROM importprotocolgrid
                INNER JOIN protocolmappinggrid ON ipg_pmg_id = pmg_id
                INNER JOIN codevalue ON cvl_id = pmg_cvl_id_datatype
          WHERE ipg_iph_id = p_importprotocolheader.iph_id;

      l_recmidatitgrdro         codevalue%ROWTYPE;
      l_recmidatitgrdcl         codevalue%ROWTYPE;
      l_recgrditemcell          codevalue%ROWTYPE;
      l_returnstatus            NUMBER;

      l_recimportprotocolgrid   l_importprotocolgrid%ROWTYPE;
   BEGIN
      pkg_debug.p_write ('pkg_validateprotocolgrid.p_validatedetail',
                         'START p_validatedetail');
      p_returnstatus := pkg_constante.cst_returnstatusok;

      OPEN l_importprotocolgrid;

      LOOP
         FETCH l_importprotocolgrid INTO l_recimportprotocolgrid;

         EXIT WHEN l_importprotocolgrid%NOTFOUND;
         pkg_debug.p_write (
            'pkg_validateprotocolgrid.p_validatedetail',
               'START LOOP p_validatedetail l_recimportprotocolgrid.ipg_value='
            || l_recimportprotocolgrid.ipg_value);

         IF NOT l_recimportprotocolgrid.ipg_value IS NULL
         THEN
            pkg_debug.p_write ('pkg_validateprotocolgrid.p_validatedetail',
                               'NOT NULL');
            pkg_debug.p_write (
               'pkg_validateprotocolgrid.p_validatedetail',
                  'pkg_datatype.f_checkdatatype ('
               || l_recimportprotocolgrid.ipg_value
               || ','
               || l_recimportprotocolgrid.cvl_code
               || ')');

            IF NOT pkg_datatype.f_checkdatatype (
                      l_recimportprotocolgrid.ipg_value,
                      l_recimportprotocolgrid.cvl_code)
            THEN
               pkg_debug.p_write (
                  'pkg_validateprotocolgrid.p_validatedetail',
                  'pkg_importprotocollog.p_writelog');
               pkg_importprotocollog.p_writelog (
                  p_importprotocolheader.iph_id,
                  NULL,
                  pkg_exception.cst_datatypeexcelinvalid,
                  NULL,
                  l_recimportprotocolgrid.ipg_value,
                  l_recimportprotocolgrid.cell,
                  l_recimportprotocolgrid.cvl_code);
               p_returnstatus := pkg_constante.cst_returnstatusnotok;
               pkg_debug.p_write (
                  'pkg_validateprotocolgrid.p_validatedetail',
                  ' pkg_importprotocolgrid.p_updatevalidatestatus');
               pkg_importprotocolgrid.p_updatevalidatestatus (
                  l_recimportprotocolgrid.ipg_id,
                  pkg_constante.cst_validstatusnotok,
                  p_usr_id);
               pkg_debug.p_write (
                  'pkg_validateprotocolgrid.p_validatedetail',
                  ' pkg_importprotocolgrid.p_updatevalidatestatus done');
            ELSE
               pkg_debug.p_write (
                  'pkg_validateprotocolgrid.p_checkonedetail',
                  'START p_checkonedetail');
               p_checkonedetail (
                  p_importprotocolheader,
                  l_recimportprotocolgrid.pmg_cvl_id_midatitgrdro,
                  l_recimportprotocolgrid.pmg_cvl_id_midatitgrdcl,
                  l_recimportprotocolgrid.pmg_cvl_id_midatitgrdce,
                  l_recimportprotocolgrid.cell,
                  l_recimportprotocolgrid.ipg_value,
                  l_returnstatus);
               pkg_debug.p_write (
                  'pkg_validateprotocolgrid.p_checkonedetail',
                  'STOP p_checkonedetail');

               IF l_returnstatus != pkg_constante.cst_returnstatusok
               THEN
                  pkg_importprotocolgrid.p_updatevalidatestatus (
                     l_recimportprotocolgrid.ipg_id,
                     pkg_constante.cst_validstatusnotok,
                     p_usr_id);
                  p_returnstatus := l_returnstatus;
               ELSE
                  pkg_importprotocolgrid.p_updatevalidatestatus (
                     l_recimportprotocolgrid.ipg_id,
                     pkg_constante.cst_validstatusok,
                     p_usr_id);
               END IF;
            END IF;
         END IF;
      END LOOP;

      CLOSE l_importprotocolgrid;

      pkg_debug.p_write ('pkg_validateprotocolgrid.p_validatedetail',
                         'STOP p_validatedetail');
      NULL;
   END;
END pkg_validateprotocolgrid;
/

