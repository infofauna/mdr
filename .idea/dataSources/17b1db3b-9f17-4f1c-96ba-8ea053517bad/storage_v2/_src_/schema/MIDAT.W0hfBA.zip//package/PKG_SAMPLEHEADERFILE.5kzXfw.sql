create PACKAGE       pkg_sampleheaderfile
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEHEADERFILE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
       1.1        24.10.2017      burrif       2. Version 2 de MIDAT
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_delete (p_shf_id IN sampleheaderfile.shf_id%TYPE);

   PROCEDURE p_delete_by_iph_id (
      p_iph_id   IN sampleheaderfile.shf_iph_id%TYPE);

   FUNCTION f_getbysphidandprotocoltype (
      p_sph_id         IN sampleheaderfile.shf_sph_id%TYPE,
      p_protocoltype   IN codevalue.cvl_code%TYPE)
      RETURN sampleheaderfile%ROWTYPE;

   PROCEDURE p_deleteby_cvl_id_protocoltype (
      p_sph_id                IN sampleheaderitem.shm_sph_id%TYPE,
      p_cvl_id_protocoltype   IN sampleheaderitem.shm_cvl_id_midatproto%TYPE);

   FUNCTION f_getbysphidandprotocoltypeid (
      p_sph_id   IN sampleheaderfile.shf_sph_id%TYPE,
      p_cvl_id   IN protocolversion.ptv_cvl_id_protocoltype%TYPE)
      RETURN sampleheaderfile%ROWTYPE;

   PROCEDURE p_deleteby_ptv_id (
      p_sph_id   IN sampleheaderfile.shf_sph_id%TYPE,
      p_ptv_id   IN sampleheaderfile.shf_ptv_id%TYPE);

   PROCEDURE p_test;

   PROCEDURE p_deleteby_sph_id (p_sph_id IN sampleheaderfile.shf_sph_id%TYPE);

   PROCEDURE p_write (p_ptv_id      IN sampleheaderfile.shf_ptv_id%TYPE,
                      p_sph_id      IN sampleheaderfile.shf_sph_id%TYPE,
                      p_lan_id      IN sampleheaderfile.shf_lan_id%TYPE,
                      p_usr_id      IN sampleheaderfile.shf_usr_id_create%TYPE,
                      p_file        IN sampleheaderfile.shf_file%TYPE,
                      p_filename    IN sampleheaderfile.shf_filename%TYPE,
                      p_sheetname   IN sampleheaderfile.shf_sheetname%TYPE,
                      p_iph_id      IN sampleheaderfile.shf_iph_id%TYPE);

   FUNCTION f_getrecord (p_shf_id IN sampleheaderfile.shf_id%TYPE)
      RETURN sampleheaderfile%ROWTYPE;

   FUNCTION f_getbysphidandptvid (
      p_sph_id   IN sampleheaderfile.shf_sph_id%TYPE,
      p_ptv_id   IN sampleheaderfile.shf_ptv_id%TYPE)
      RETURN sampleheaderfile%ROWTYPE;

   FUNCTION f_getlaboprotocolfile (
      p_sph_id   IN sampleheaderfile.shf_sph_id%TYPE)
      RETURN sampleheaderfile%ROWTYPE;
END pkg_sampleheaderfile;
/

