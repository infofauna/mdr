create PACKAGE BODY       pkg_identifysystematique
AS
   /******************************************************************************
      NAME:       PKG_IDENTIFYSYSTEMATIQUE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        17.03.2016      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion      CONSTANT VARCHAR2 (30) := 'Version 1.0, mars  2016';

   TYPE t_listconceptfound IS TABLE OF pkg_systdesignation.t_listcrf_code
      INDEX BY importmassdatadetail.imd_species%TYPE;

   TYPE t_listconceptsonlevel IS TABLE OF codereference.crf_code%TYPE;

   l_listconceptonlevelsubspecies   t_listconceptsonlevel
      := t_listconceptsonlevel (pkg_codereference.cst_crf_subform,
                                pkg_codereference.cst_crf_form,
                                pkg_codereference.cst_crf_subspecies);

   l_listconceptonlevelspecies      t_listconceptsonlevel
      := t_listconceptsonlevel (pkg_codereference.cst_crf_aggsubspec,
                                pkg_codereference.cst_crf_species);

   l_listconceptonlevelgenus        t_listconceptsonlevel
      := t_listconceptsonlevel (pkg_codereference.cst_crf_aggspecies,
                                pkg_codereference.cst_crf_hybrid,
                                pkg_codereference.cst_crf_subgenus,
                                pkg_codereference.cst_crf_genus);

   l_listconceptonlevelfamily       t_listconceptsonlevel
      := t_listconceptsonlevel (pkg_codereference.cst_crf_tribe,
                                pkg_codereference.cst_crf_subfamily,
                                pkg_codereference.cst_crf_family);

   l_listconceptonlevelhighertaxo   t_listconceptsonlevel
      := t_listconceptsonlevel (pkg_codereference.cst_crf_superfamil,
                                pkg_codereference.cst_crf_infraorder,
                                pkg_codereference.cst_crf_suborder,
                                pkg_codereference.cst_crf_order,
                                pkg_codereference.cst_crf_superorder,
                                pkg_codereference.cst_crf_infraclass,
                                pkg_codereference.cst_crf_subclass,
                                pkg_codereference.cst_crf_class,
                                pkg_codereference.cst_crf_infraphylu,
                                pkg_codereference.cst_crf_subphylum,
                                pkg_codereference.cst_crf_phylum);

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------------------*/
   FUNCTION f_checkcrfcodeinlist (
      p_crf_code              IN codereference.crf_code%TYPE,
      p_listconceptsonlevel   IN t_listconceptsonlevel)
      RETURN BOOLEAN
   /*-----------------------------------------------------------------------------*/
   IS
      l_indice         PLS_INTEGER;
      l_returnstatus   BOOLEAN := FALSE;
   BEGIN
      l_indice := p_listconceptsonlevel.FIRST;

      WHILE NOT l_indice IS NULL AND NOT l_returnstatus
      LOOP
         IF p_listconceptsonlevel (l_indice) = p_crf_code
         THEN
            l_returnstatus := TRUE;
         END IF;

         l_indice := p_listconceptsonlevel.NEXT (l_indice);
      END LOOP;

      RETURN l_returnstatus;
   END;

   /*-----------------------------------------------------------------------------*/
   PROCEDURE p_sortcrfcode (
      p_listcrf   IN OUT pkg_systdesignation.t_listcrf_code)
   /*-----------------------------------------------------------------------------*/
   IS
      l_listcrf   pkg_systdesignation.t_listcrf_code;
      l_indice    PLS_INTEGER;
      l_level     PLS_INTEGER;
   BEGIN
      l_indice := p_listcrf.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         l_level :=
            pkg_codereference.f_returnlevelbycode (p_listcrf (l_indice));
         l_listcrf (100 - l_level) := p_listcrf (l_indice); -- Pour avoir du plus petit au plus grand
         l_indice := p_listcrf.NEXT (l_indice);
      END LOOP;

      p_listcrf := l_listcrf;

      NULL;
   END;

   /*-----------------------------------------------------------------------------*/
   PROCEDURE p_refinecrfcode (
      p_listconceptsonlevel   IN     t_listconceptsonlevel,
      p_listconceptfound      IN OUT t_listconceptfound)
   /*-----------------------------------------------------------------------------*/
   IS
      l_conceptkey   importmassdatadetail.imd_subspecies%TYPE;
      l_listcrf      pkg_systdesignation.t_listcrf_code;
      l_indice       PLS_INTEGER;
   BEGIN
      l_conceptkey := p_listconceptfound.FIRST;

      WHILE NOT l_conceptkey IS NULL
      LOOP
         l_listcrf := p_listconceptfound (l_conceptkey);
         l_indice := l_listcrf.FIRST;

         WHILE NOT l_indice IS NULL
         LOOP
            IF NOT f_checkcrfcodeinlist (l_listcrf (l_indice),
                                         p_listconceptsonlevel)
            THEN
               l_listcrf.delete (l_indice);
            END IF;

            l_indice := l_listcrf.NEXT (l_indice);
         END LOOP;

         IF l_listcrf.COUNT = 0
         THEN
            p_listconceptfound.delete (l_conceptkey);
         ELSE
            p_sortcrfcode (l_listcrf);
            p_listconceptfound (l_conceptkey) := l_listcrf;
         END IF;

         l_conceptkey := p_listconceptfound.NEXT (l_conceptkey);
         NULL;
      END LOOP;
   END;



   /*---------------------------------------------------------------*/
   PROCEDURE p_associateconcept (
      p_listconcept        IN     pkg_stringutil.t_listofvalue,
      p_listconceptfound   IN OUT t_listconceptfound)
   /*--------------------------------------------------------------*/
   IS
      l_listcrf   pkg_systdesignation.t_listcrf_code;
      l_indice    PLS_INTEGER;
   BEGIN
      l_listcrf.delete ();
      l_indice := p_listconcept.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         l_listcrf :=
            pkg_systdesignation.f_getlistcrfbydesignation (
               p_listconcept (l_indice),
               pkg_language.cst_lan_cde_latin);
         p_listconceptfound (p_listconcept (l_indice)) := l_listcrf;
         l_indice := p_listconcept.NEXT (l_indice);
      END LOOP;
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_addfindbyconceptfound (p_listconceptfound t_listconceptfound)
   /*-------------------------------------------------------------------*/
   IS
      l_conceptkey   importmassdatadetail.imd_subspecies%TYPE;
      l_listcrf      pkg_systdesignation.t_listcrf_code;
      l_indice       PLS_INTEGER;
   BEGIN
      l_conceptkey := p_listconceptfound.FIRST;

      WHILE NOT l_conceptkey IS NULL
      LOOP
         l_listcrf := p_listconceptfound (l_conceptkey);
         l_indice := l_listcrf.FIRST;

         WHILE NOT l_indice IS NULL
         LOOP
            pkg_systdesignation.p_addfindbydesignation (
               pkg_language.cst_lan_cde_latin,
               l_listcrf (l_indice),
               l_conceptkey);

            l_indice := l_listcrf.NEXT (l_indice);
         END LOOP;

         l_conceptkey := p_listconceptfound.NEXT (l_conceptkey);
      END LOOP;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_afficheconcept (p_listconceptfound t_listconceptfound)
   /*---------------------------------------------------------------*/
   IS
      l_conceptkey   importmassdatadetail.imd_subspecies%TYPE;
      l_listcrf      pkg_systdesignation.t_listcrf_code;
      l_indice       PLS_INTEGER;
   BEGIN
      l_conceptkey := p_listconceptfound.FIRST;

      WHILE NOT l_conceptkey IS NULL
      LOOP
         l_listcrf := p_listconceptfound (l_conceptkey);
         l_indice := l_listcrf.FIRST;
         DBMS_OUTPUT.put_line ('Concept: ' || l_conceptkey);

         WHILE NOT l_indice IS NULL
         LOOP
            DBMS_OUTPUT.put_line ('CRF_CODE: ' || l_listcrf (l_indice));

            l_indice := l_listcrf.NEXT (l_indice);
         END LOOP;

         l_conceptkey := p_listconceptfound.NEXT (l_conceptkey);
      END LOOP;
   END;


   /*---------------------------------------------------------------*/
   PROCEDURE p_identifiesystematique (
      /*---------------------------------------------------------------*/
      p_subspecies            IN     importmassdatadetail.imd_subspecies%TYPE,
      p_species               IN     importmassdatadetail.imd_species%TYPE,
      p_genus                 IN     importmassdatadetail.imd_genus%TYPE,
      p_family                IN     importmassdatadetail.imd_family%TYPE,
      p_highertaxon           IN     importmassdatadetail.imd_highertaxon%TYPE,
      p_taxonibch             IN     importmassdatadetail.imd_taxonibch%TYPE,
      p_ptv_id_ibchfrommass   IN     protocolversion.ptv_id%TYPE,
      p_syv_startwith            OUT systvalue.syv_id%TYPE,
      p_crf_id                   OUT codereference.crf_id%TYPE,
      p_flagprecisionmax         OUT CHAR,
      p_returnstatus             OUT NUMBER)
   /*----------------------------------------------------------------*/
   IS
      l_subspecies                    importmassdatadetail.imd_subspecies%TYPE;
      l_species                       importmassdatadetail.imd_species%TYPE;
      l_genus                         importmassdatadetail.imd_genus%TYPE;
      l_family                        importmassdatadetail.imd_family%TYPE;
      l_highertaxon                   importmassdatadetail.imd_highertaxon%TYPE;
      l_taxonibch                     importmassdatadetail.imd_taxonibch%TYPE;
      l_syv_id_detail                 systvalue.syv_id%TYPE;
      l_syv_id_labo                   systvalue.syv_id%TYPE;
      l_listsubspecies                pkg_stringutil.t_listofvalue;
      l_listspecies                   pkg_stringutil.t_listofvalue;
      l_listgenus                     pkg_stringutil.t_listofvalue;
      l_listfamily                    pkg_stringutil.t_listofvalue;
      l_listhighertaxon               pkg_stringutil.t_listofvalue;
      l_listconceptfoundsubspecies    t_listconceptfound;
      l_listconceptfoundspecies       t_listconceptfound;
      l_listconceptfoundgenus         t_listconceptfound;
      l_listconceptfoundfamily        t_listconceptfound;
      l_listconceptfoundhighertaxon   t_listconceptfound;
      l_recprotocolmappinglabo        protocolmappinglabo%ROWTYPE;
      l_recsystvalue                  systvalue%ROWTYPE;
   BEGIN
      /*
       Règle: on cherche la meilleure occurence à partir des détails
                  si la valeur p_taxonibch est définie on cherche aussi dans les protocole de laboratoire
      */
      l_subspecies := pkg_stringutil.f_removedatainparenthesis (p_subspecies);
      l_species := pkg_stringutil.f_removedatainparenthesis (p_species);
      l_genus := pkg_stringutil.f_removedatainparenthesis (p_genus);
      l_family := pkg_stringutil.f_removedatainparenthesis (p_family);
      l_highertaxon :=
         pkg_stringutil.f_removedatainparenthesis (p_highertaxon);
      l_taxonibch := pkg_stringutil.f_removedatainparenthesis (p_taxonibch);
      l_listsubspecies := pkg_stringutil.f_splitstring (l_subspecies, '/');
      l_listspecies := pkg_stringutil.f_splitstring (l_species, '/');
      l_listgenus := pkg_stringutil.f_splitstring (l_genus, '/');
      l_listfamily := pkg_stringutil.f_splitstring (l_family, '/');
      l_listhighertaxon := pkg_stringutil.f_splitstring (l_highertaxon, '/');
      p_associateconcept (l_listsubspecies, l_listconceptfoundsubspecies);
      p_associateconcept (l_listspecies, l_listconceptfoundspecies);
      p_associateconcept (l_listgenus, l_listconceptfoundgenus);
      p_associateconcept (l_listfamily, l_listconceptfoundfamily);
      p_associateconcept (l_listhighertaxon, l_listconceptfoundhighertaxon);
      p_refinecrfcode (l_listconceptonlevelsubspecies,
                       l_listconceptfoundsubspecies);
      p_refinecrfcode (l_listconceptonlevelspecies,
                       l_listconceptfoundspecies);
      p_refinecrfcode (l_listconceptonlevelgenus, l_listconceptfoundgenus);
      p_refinecrfcode (l_listconceptonlevelfamily, l_listconceptfoundfamily);
      p_refinecrfcode (l_listconceptonlevelhighertaxo,
                       l_listconceptfoundhighertaxon);
      pkg_systdesignation.p_clearfindbydesignation;
      p_addfindbyconceptfound (l_listconceptfoundsubspecies);
      p_addfindbyconceptfound (l_listconceptfoundspecies);
      p_addfindbyconceptfound (l_listconceptfoundgenus);
      p_addfindbyconceptfound (l_listconceptfoundfamily);
      p_addfindbyconceptfound (l_listconceptfoundhighertaxon);
      p_afficheconcept (l_listconceptfoundsubspecies);
      p_afficheconcept (l_listconceptfoundspecies);
      p_afficheconcept (l_listconceptfoundgenus);
      p_afficheconcept (l_listconceptfoundfamily);
      p_afficheconcept (l_listconceptfoundhighertaxon);



      pkg_systdesignation.p_processfindbyscoredesign (p_syv_startwith, -- Identifiant du niveau le plus bas
                                                      p_crf_id, -- Identifiant du code de référence
                                                      p_flagprecisionmax); -- Flag (Y/N) permttant de savoir si l'élément le plus précis est utilisé

      IF p_syv_startwith IS NULL
      THEN
         IF NOT p_taxonibch IS NULL
         THEN
            l_recprotocolmappinglabo :=
               pkg_protocolmappinglabo.f_getrecordbytaxa (
                  p_ptv_id_ibchfrommass,
                  p_taxonibch);
         END IF;

         IF NOT l_recprotocolmappinglabo.ptl_syv_id IS NULL
         THEN
            p_syv_startwith := l_recprotocolmappinglabo.ptl_syv_id;
            l_recsystvalue := pkg_systvalue.f_getrecord (p_syv_startwith);
            p_crf_id := l_recsystvalue.syv_crf_id;
            p_flagprecisionmax := pkg_constante.cst_no;
         END IF;
      END IF;
      p_returnstatus:=pkg_constante.cst_returnstatusok;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_returnfullpath (p_syv_id IN systvalue.syv_id%TYPE)
      RETURN VARCHAR2
   /*..............................................................................*/
   IS
      l_path   VARCHAR2 (4096);
   BEGIN
      SELECT path1
        INTO l_path
        FROM (    SELECT SYS_CONNECT_BY_PATH (syd_designation, '->') path1,
                         LEVEL lev,
                         syv_id
                    FROM systvalue sy
                         INNER JOIN systdesignation sd ON syv_id = syd_syv_id
                         INNER JOIN language lg ON lan_id = syd_lan_id
                         INNER JOIN codereference cr ON crf_id = syv_crf_id
                   WHERE     syd_lan_id = lan_id
                         AND lan_code = pkg_language.cst_lan_cde_latin
              CONNECT BY PRIOR syv_id = syv_syv_id)
       WHERE     syv_id = p_syv_id
             AND lev =
                    (SELECT MAX (lev1)
                       FROM (    SELECT LEVEL lev1, sy1.syv_id
                                   FROM systvalue sy1
                                        INNER JOIN systdesignation sd1
                                           ON sy1.syv_id = sd1.syd_syv_id
                                        INNER JOIN language lg1
                                           ON lg1.lan_id = sd1.syd_lan_id
                                        INNER JOIN codereference cr1
                                           ON cr1.crf_id = sy1.syv_crf_id
                                  WHERE     sd1.syd_lan_id = lg1.lan_id
                                        AND lg1.lan_code =
                                               pkg_language.cst_lan_cde_latin
                             CONNECT BY PRIOR sy1.syv_id = sy1.syv_syv_id)
                      WHERE syv_id = p_syv_id);

      RETURN l_path;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
      WHEN TOO_MANY_ROWS
      THEN
         DBMS_OUTPUT.put_line ('p_syv_id=' || TO_CHAR (p_syv_id));
         raise_application_error (-20000, SQLERRM, TRUE);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_testidentifiesystematique
   /*----------------------------------------------------------------*/
   IS
      l_subspecies         importmassdatadetail.imd_subspecies%TYPE;
      l_species            importmassdatadetail.imd_species%TYPE;
      l_genus              importmassdatadetail.imd_genus%TYPE;
      l_family             importmassdatadetail.imd_family%TYPE;
      l_highertaxon        importmassdatadetail.imd_highertaxon%TYPE;
      l_crf_id             codereference.crf_id%TYPE;
      l_flagprecisionmax   CHAR;
      l_returnstatus       NUMBER;
      l_taxonibch          importmassdatadetail.imd_taxonibch%TYPE;
      l_ptv_id_ibch        protocolversion.ptv_id%TYPE;
      l_syv_startwith      systvalue.syv_id%TYPE;
      l_full_path          VARCHAR2 (1024);
   BEGIN
      l_species := 'braueri';
      l_genus := 'Leuctra';
      l_family := 'Leuctridae';
      l_highertaxon := 'Plecoptera';



      p_identifiesystematique (l_subspecies,
                               l_species,
                               l_genus,
                               l_family,
                               l_highertaxon,
                               l_taxonibch,
                               l_ptv_id_ibch,
                               l_syv_startwith,
                               l_crf_id,
                               l_flagprecisionmax,
                               l_returnstatus);

      IF NOT l_syv_startwith IS NULL
      THEN
         l_full_path := f_returnfullpath (l_syv_startwith);
         DBMS_OUTPUT.put_line (l_full_path);
      END IF;



      NULL;
   END;
END pkg_identifysystematique;
/

