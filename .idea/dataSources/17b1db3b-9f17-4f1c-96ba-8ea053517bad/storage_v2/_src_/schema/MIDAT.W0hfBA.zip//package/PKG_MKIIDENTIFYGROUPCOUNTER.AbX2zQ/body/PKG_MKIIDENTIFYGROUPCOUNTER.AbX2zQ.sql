create PACKAGE BODY       pkg_mkiidentifygroupcounter
AS
   /******************************************************************************
      NAME:       PKG_MKIIDENTIFYGROUPCOUNTER
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        23.02.2015      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, février  2015' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_getrecordbysyvid (
      p_syv_id   IN mkiidentifygroupcounter.mig_syv_id%TYPE)
      RETURN mkiidentifygroupcounter%ROWTYPE
   /*----------------------------------------------------------------*/
   IS
      l_recmkiidentifygroupcounter   mkiidentifygroupcounter%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recmkiidentifygroupcounter
        FROM mkiidentifygroupcounter
       WHERE mig_syv_id = p_syv_id;

      RETURN l_recmkiidentifygroupcounter;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*----------------------------------------------------------------*/
   PROCEDURE p_insert (
      p_syv_id             IN     mkiidentifygroupcounter.mig_syv_id%TYPE,
      p_crf_id             IN     mkiidentifygroupcounter.mig_crf_id%TYPE,
      p_crf_id_leveltrap   IN     mkiidentifygroupcounter.mig_crf_id_level_trap%TYPE,
      p_taxonname          IN     mkiidentifygroupcounter.mig_taxonname%TYPE,
      p_searchorder        IN     mkiidentifygroupcounter.mig_searchorder%TYPE,
      p_id                    OUT mkiidentifygroupcounter.mig_id%TYPE)
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_mkiidentifygroupcounter.NEXTVAL;

      INSERT INTO mkiidentifygroupcounter (mig_id,
                                           mig_syv_id,
                                           mig_crf_id,
                                           mig_crf_id_level_trap,
                                           mig_taxonname,
                                           mig_searchorder)
           VALUES (p_id,
                   p_syv_id,
                   p_crf_id,
                   p_crf_id_leveltrap,
                   p_taxonname,
                   p_searchorder);
   END;



   /*--------------------------------------------------------------------------------*/
   PROCEDURE p_loadmkiidentifylist (l_listmkicounter IN OUT t_listmkicounter)
   /*-------------------------------------------------------------------------------*/
   IS
      CURSOR l_mkiidentifygroupcounter
      IS
           SELECT *
             FROM mkiidentifygroupcounter
         ORDER BY mig_searchorder;

      l_recmkiidentifygroupcounter   l_mkiidentifygroupcounter%ROWTYPE;
      l_syv_id_return                systvalue.syv_id%TYPE;
      l_recsystdesignation           systdesignation%ROWTYPE;
      l_reccordereference            codereference%ROWTYPE;
   BEGIN
      OPEN l_mkiidentifygroupcounter;

      LOOP
         FETCH l_mkiidentifygroupcounter INTO l_recmkiidentifygroupcounter;

         EXIT WHEN l_mkiidentifygroupcounter%NOTFOUND;
         l_reccordereference :=
            pkg_codereference.f_getrecord (
               l_recmkiidentifygroupcounter.mig_crf_id);
         l_recsystdesignation :=
            pkg_systdesignation.f_getrecordbyleveldesignation (
               l_recmkiidentifygroupcounter.mig_taxonname,
               l_reccordereference.crf_code);
         l_listmkicounter (l_recsystdesignation.syd_syv_id).l_taxonname :=
            l_recmkiidentifygroupcounter.mig_taxonname;
         l_listmkicounter (l_recsystdesignation.syd_syv_id).l_counter := 0;
         l_listmkicounter (l_recsystdesignation.syd_syv_id).l_isinsecta :=
            NULL;
         l_listmkicounter (l_recsystdesignation.syd_syv_id).l_crf_id :=
            l_reccordereference.crf_id;
      END LOOP;

      CLOSE l_mkiidentifygroupcounter;

      NULL;
   END;
END pkg_mkiidentifygroupcounter;
/

