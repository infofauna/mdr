create PACKAGE BODY       pkg_validatemassstation
AS
   /******************************************************************************
      NAME:       pkg_validatemassstation
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.05.2014      burrif       1. Created this package.
      2.0        27.07.2017      burrif       2. MIDAT version 2
   ******************************************************************************/



   /*
INSERT INTO user_sdo_geom_metadata
      VALUES ('IMPORTMASSSTATION',
              'IMS_COORDINATES',
              mdsys.sdo_dim_array (mdsys.sdo_dim_element ('X',
                                                          480000,
                                                          837000,
                                                          1),
                                   mdsys.sdo_dim_element ('Y',
                                                          75000,
                                                          300000,
                                                          1),
                                   mdsys.sdo_dim_element ('Z',
                                                          0,
                                                          5000,
                                                          1)),
              21781);


CREATE INDEX MIDAT.IDX_IMPORTMASSSTATION ON MIDAT.IMPORTMASSSTATION
(IMS_COORDINATES)
INDEXTYPE IS MDSYS.SPATIAL_INDEX
PARAMETERS(' layer_gtype=point,TABLESPACE=MIDAT_INDEX')
NOPARALLEL;

   */



   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 2.0, juillet  2017' ;

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------------*/
   PROCEDURE p_invalidatestationbyoid (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_oid            IN     importmassstation.ims_oid%TYPE,
      p_returnstatus      OUT NUMBER)
   /*---------------------------------------------------------------------*/
   IS
   BEGIN
      pkg_importmassstation.p_invalidstationbyoid (p_iph_id,
                                                   p_oid,
                                                   p_returnstatus);
      pkg_importmassdataheader.p_writeinvalidatemessagebyoid (p_iph_id,
                                                              p_oid);
   END;

   /*-----------------------------------------------------------------*/
   FUNCTION f_countallstationtobuild (
      p_iph_id   IN importmassdataheader.imh_iph_id%TYPE)
      RETURN NUMBER
   /*----------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM (  SELECT imh_oid,
                       imh_startpoint_x,
                       imh_startpoint_y,
                       imh_elevation
                  FROM importmassdataheader
                 WHERE     imh_iph_id = p_iph_id
                       AND imh_validstatus !=
                              pkg_constante.cst_validstatusnotok
              GROUP BY imh_oid,
                       imh_startpoint_x,
                       imh_startpoint_y,
                       imh_elevation);

      RETURN l_count;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_findbywatersourcename (
      p_listwatercourse   IN     pkg_importmassdataheader.t_listvarchar,
      p_name                 OUT VARCHAR2,
      p_gewissnr             OUT NUMBER,
      p_returnstatus         OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_key                       VARCHAR2 (128);
      l_found                     BOOLEAN := TRUE;
      l_recimportmassdataheader   importmassdataheader%ROWTYPE;
      l_gewissnr                  NUMBER;
   BEGIN
      l_key := p_listwatercourse.FIRST;
      p_returnstatus := pkg_constante.cst_returnstatusnotok;
      p_gewissnr := NULL;
      p_name := NULL;

      WHILE NOT l_key IS NULL AND NOT l_found
      LOOP
         l_recimportmassdataheader :=
            pkg_importmassdataheader.f_getrecord (p_listwatercourse (l_key));
         l_gewissnr :=
            pkg_gis.f_returngewissnrbyname (
               l_recimportmassdataheader.imh_watercourse);

         IF NOT l_gewissnr IS NULL
         THEN
            l_found := TRUE;
            p_gewissnr := l_gewissnr;
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
            p_name := l_recimportmassdataheader.imh_watercourse;
         ELSE
            l_key := p_listwatercourse.NEXT (l_key);
         END IF;
      END LOOP;
   END;

   /*---------------------------------------------------------------------*/
   PROCEDURE p_returnstringinfoheader (
      p_ims_id              IN     importmassstation.ims_id%TYPE,
      p_stringlocality         OUT VARCHAR2,
      p_stringwatercourse      OUT VARCHAR2,
      p_stringdate             OUT VARCHAR2)
   /*---------------------------------------------------------------------*/
   IS
      l_listlocality      pkg_importmassdataheader.t_listvarchar;
      l_listwatercourse   pkg_importmassdataheader.t_listvarchar;
      l_listdate          pkg_importmassdataheader.t_listvarchar;
   BEGIN
      pkg_importmassdataheader.p_returninfoheaderbyims_id (p_ims_id,
                                                           l_listlocality,
                                                           l_listwatercourse,
                                                           l_listdate);
      p_stringlocality :=
         pkg_importmassdataheader.f_formatlistvarchar (
            l_listlocality,
            pkg_importmassdataheader.cst_fieldlocality);
      p_stringwatercourse :=
         pkg_importmassdataheader.f_formatlistvarchar (
            l_listwatercourse,
            pkg_importmassdataheader.cst_fieldwatercourse);
      p_stringdate :=
         pkg_importmassdataheader.f_formatlistvarchar (
            l_listdate,
            pkg_importmassdataheader.cst_fielddate);
   END;

   /*------------------------------------------------------------------*/

   PROCEDURE p_checkduplicatecoordinatesoid (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*----------------------------------------------------------------*/
   IS
      /* Permet de vérifier qu'une coordonnée ne définissent pas plusieurs OID */
      CURSOR l_cursor (
         p_coordinates   IN SDO_GEOMETRY,
         p_ins_id        IN institution.ins_id%TYPE,
         p_oid           IN importmassstation.ims_oid%TYPE)
      IS
         --       SELECT st.ims_id, sdo_nn_distance (1) distance, st.ims_oid
         SELECT st.ims_id,
                pkg_sdoutil.f_computedistance2d (p_coordinates,
                                                 ims_coordinates)
                   distance,
                st.ims_oid
           FROM importmassstation st
          WHERE     pkg_sdoutil.f_computedistance2d (p_coordinates,
                                                     ims_coordinates) <=
                       pkg_codevalue.f_get_midatparam_rayontol
                /*
                      sdo_nn (st.ims_coordinates,
                                       p_coordinates,
                                       --               pkg_sdoutil.f_setz (p_coordinates,
                                       --                                    st.ims_coordinates.sdo_point.z),
                                       'sdo_num_res=1 unit=M ',
                                       1) = 'TRUE'
           */
                AND st.ims_ins_id = p_ins_id
                AND NVL (ims_oid, p_oid) != p_oid
                AND ims_validstatus != pkg_constante.cst_validstatusnotok
                AND ims_id IN (SELECT imh_ims_id
                                 FROM importmassdataheader
                                WHERE imh_iph_id = p_iph_id);

      l_reccursor                l_cursor%ROWTYPE;

      CURSOR l_cursormain
      IS
         SELECT importmassstation.*
           FROM importmassstation
                INNER JOIN importmassdataheader ON imh_ims_id = ims_id
          WHERE     imh_iph_id = p_iph_id
                AND ims_validstatus != pkg_constante.cst_validstatusnotok
                AND NOT ims_oid IS NULL;

      l_reccursormain            l_cursormain%ROWTYPE;
      l_returnstatus             NUMBER;
      l_recimportmassstation1    importmassstation%ROWTYPE;
      l_recimportmassstation2    importmassstation%ROWTYPE;
      l_stringlocality_oid1      VARCHAR2 (1024);
      l_stringwatercourse_oid1   VARCHAR2 (1024);
      l_stringdate_oid1          VARCHAR2 (1024);
      l_stringlocality_oid2      VARCHAR2 (1024);
      l_stringwatercourse_oid2   VARCHAR2 (1024);
      l_stringdate_oid2          VARCHAR2 (1024);
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      -- Identification des  nouvelles stations qui possèdent un OID différents et qui se trouvent dans un rayon de tolérance (%p1%) de proximité
      pkg_importprotocollog.p_writelog (
         p_iph_id,
         NULL,
         pkg_exception.cst_infostationnearoidnotdsame,
         NULL,
         TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol, '9999999.9'));

      OPEN l_cursormain;

      LOOP
         FETCH l_cursormain INTO l_reccursormain;

         EXIT WHEN l_cursormain%NOTFOUND;
         p_returnstringinfoheader (l_reccursormain.ims_id,
                                   l_stringlocality_oid1,
                                   l_stringwatercourse_oid1,
                                   l_stringdate_oid1);

         pkg_debug.p_write (
            'PKG_VALIDATEMASSSTATION.p_checkduplicatecoordinatesoid',
               ' l_reccursormain.ims_oid='
            || l_reccursormain.ims_oid
            || ' x : '
            || l_reccursormain.ims_coordinates.sdo_point.x
            || ' y : '
            || l_reccursormain.ims_coordinates.sdo_point.y
            || ' l_reccursormain.ims_ins_id: '
            || l_reccursormain.ims_ins_id);

         OPEN l_cursor (l_reccursormain.ims_coordinates,
                        l_reccursormain.ims_ins_id,
                        l_reccursormain.ims_oid);

         LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND;
            p_returnstringinfoheader (l_reccursor.ims_id,
                                      l_stringlocality_oid2,
                                      l_stringwatercourse_oid2,
                                      l_stringdate_oid2);


            pkg_debug.p_write (
               'PKG_VALIDATEMASSSTATION.p_checkduplicatecoordinatesoid',
                  'l_reccursor.ims_oid='
               || l_reccursor.ims_oid
               || ' distance '
               || l_reccursor.distance);

            IF l_reccursor.distance <= pkg_codevalue.f_get_midatparam_rayontol
            THEN
               -- Les deux stations (OID %p1%  Cours d'eau: %p2%  Localité: %p3%) et (OID %p4%  Cours d'eau: %p5%  Localité: %p6%)  se trouvent à une distance de %p7% mètre(s). Ces deux stations sont invalidées car elles sont  dans le rayon de tolérance de %p8% d'invalidations
               -- La station avec l'OID = %p1% se trouve à une distance de %p2% par rapport à la station avec l'OID=%p3%.


               pkg_importprotocollog.p_writelog (
                  p_iph_id,
                  NULL,
                  pkg_exception.cst_closestbetweenstationoid,
                  NULL,
                  l_reccursor.ims_oid,
                  l_stringwatercourse_oid1,
                  l_stringlocality_oid1,
                  l_reccursormain.ims_oid,
                  l_stringwatercourse_oid2,
                  l_stringlocality_oid2,
                  TO_CHAR (l_reccursor.distance, 9999999.9),
                  TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol, 9999999.9));

               p_invalidatestationbyoid (p_iph_id,
                                         l_reccursormain.ims_oid,
                                         l_returnstatus);
               p_invalidatestationbyoid (p_iph_id,
                                         l_reccursor.ims_oid,
                                         l_returnstatus);
            END IF;
         END LOOP;

         CLOSE l_cursor;
      END LOOP;

      CLOSE l_cursormain;


      NULL;
   END;


   /*-----------------------------------------------------------------*/

   PROCEDURE p_completedata (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*----------------------------------------------------------------*/
   IS
      /* Permet de compléter
            - la valeur d'altitude si elle n'est pas renseignée
            - le numéro de rivière
        */
      cst_identifiedmodebyname   CONSTANT NUMBER := 0;
      cst_identifiedmodebyxy     CONSTANT NUMBER := 1;

      CURSOR l_allstation
      IS
         SELECT *
           FROM importmassstation
          WHERE ims_id IN (SELECT imh_ims_id
                             FROM importmassdataheader
                            WHERE imh_iph_id = p_iph_id)
         FOR UPDATE;

      l_recallstation                     l_allstation%ROWTYPE;
      l_elevation                         NUMBER;
      l_elevationwrite                    NUMBER;
      l_gewissnr                          NUMBER;
      l_gewissnrwrite                     NUMBER := NULL;
      l_returnstatus                      NUMBER;
      l_gwn25                             ch_gwn25%ROWTYPE;
      l_distance                          NUMBER;
      l_reccodevalueelevationorigin       codevalue%ROWTYPE;
      l_sdo_geometry                      SDO_GEOMETRY;
      l_listwatercourse                   pkg_importmassdataheader.t_listvarchar;
      l_listlocality                      pkg_importmassdataheader.t_listvarchar;
      l_listdate                          pkg_importmassdataheader.t_listvarchar;
      l_stringlocality                    VARCHAR2 (1024);
      l_stringwatercourse                 VARCHAR2 (1024);
      l_stringdate                        VARCHAR2 (1024);
      l_identifiedmode                    NUMBER;
      l_watercoursename_gwn25             VARCHAR2 (256);
      l_watercoursegewissnr               NUMBER;
      l_cvl_code_origin                   codevalue.cvl_code%TYPE;
      l_cvl_id_canton                     importmassstation.ims_cvl_id_canton%TYPE;
      l_recmassdataheader                 importmassdataheader%ROWTYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_reccodevalueelevationorigin :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_elevorigin,
            pkg_codevalue.cst_elevorigin_swisstopo);
      pkg_debug.p_write ('PKG_VALIDATEMASSSTATION.p_completedata',
                         'Start ...');

      OPEN l_allstation;

      LOOP
         FETCH l_allstation INTO l_recallstation;

         EXIT WHEN l_allstation%NOTFOUND;
         l_elevationwrite := NULL;
         l_gewissnrwrite := NULL;
         -- On met à jour le canton
         l_recmassdataheader :=
            pkg_importmassdataheader.f_getrecordbyims_id (
               p_iph_id,
               l_recallstation.ims_id);
         pkg_importmassstation.p_update_ims_cvl_id_canton (
            l_recallstation.ims_id,
            l_recmassdataheader.imh_cvl_id_canton,
            p_usr_id);
         /*
         pkg_importmassdataheader.p_returninfoheaderbycoordinate (
            p_iph_id,
            l_recallstation.ims_oid,
            TO_CHAR (l_recallstation.ims_coordinates.sdo_point.z),
            TO_CHAR (l_recallstation.ims_coordinates.sdo_point.x),
            TO_CHAR (l_recallstation.ims_coordinates.sdo_point.y),
            l_listlocality,
            l_listwatercourse,
            l_listdate);
            */
         pkg_importmassdataheader.p_returninfoheaderbyims_id (
            l_recallstation.ims_id,
            l_listlocality,
            l_listwatercourse,
            l_listdate);
         l_stringlocality :=
            pkg_importmassdataheader.f_formatlistvarchar (
               l_listlocality,
               pkg_importmassdataheader.cst_fieldlocality);
         l_stringwatercourse :=
            pkg_importmassdataheader.f_formatlistvarchar (
               l_listwatercourse,
               pkg_importmassdataheader.cst_fieldwatercourse);
         l_stringdate :=
            pkg_importmassdataheader.f_formatlistvarchar (
               l_listdate,
               pkg_importmassdataheader.cst_fielddate);

         -- Enrichissement des données de la station créée à partir prélèvements suivants:  Cours d'eau :%p1%, localité: %p2%, date: %p3%, coordonnée: %p4%



         pkg_importprotocollog.p_writelog (
            p_iph_id,
            NULL,
            pkg_exception.cst_improvedatastation,
            NULL,
            l_stringwatercourse,
            l_stringlocality,
            l_stringdate,
               '('
            || TO_CHAR (l_recallstation.ims_coordinates.sdo_point.x)
            || ' : '
            || TO_CHAR (l_recallstation.ims_coordinates.sdo_point.y)
            || ')');

         -- On enrichi l'altitude
         IF l_recallstation.ims_z IS NULL
         THEN
            pkg_gis.p_returnelevation (
               l_recallstation.ims_coordinates.sdo_point.x,
               l_recallstation.ims_coordinates.sdo_point.y,
               l_elevation,
               l_cvl_code_origin,
               l_returnstatus);
            pkg_gis.p_checkorigineelevation (p_iph_id, l_cvl_code_origin);

            IF l_returnstatus != pkg_constante.cst_returnstatusok
            THEN
               NULL;
               -- Impossible de déterminer l'altitude

               p_returnstatus := l_returnstatus;
               l_elevationwrite := NULL;
            ELSE
               l_elevationwrite := l_elevation;
            END IF;

            NULL;
         END IF;

         -- On enrichi le GEWISSNR
         pkg_gis.p_returngewiss (l_recallstation.ims_coordinates.sdo_point.x,
                                 l_recallstation.ims_coordinates.sdo_point.y,
                                 l_gwn25,
                                 l_distance,
                                 l_returnstatus);
         pkg_debug.p_write ('PKG_VALIDATEMASSSTATION.p_completedata',
                            'l_gwn25.gewissnr=' || l_gwn25.gewissnr);

         IF l_returnstatus = pkg_constante.cst_returnstatusok
         THEN
            l_identifiedmode := cst_identifiedmodebyxy;
            l_gewissnrwrite := l_gwn25.gewissnr;
            NULL;
         ELSE
            IF l_distance < pkg_gis.cst_distancetolgewiss
            THEN
               IF NVL (l_gwn25.gewissnr, 0) != 0
               THEN
                  --  Impossible d'identifier le cours d'eau avec les données swisstopo car plusieurs cours d'eau se trouvent dans le rayon de tolérance (%p1%) autour de la coordonnée(%p2%)
                  pkg_importprotocollog.p_writelog (
                     p_iph_id,
                     NULL,
                     pkg_exception.cst_unableidentifywtcbyswissto,
                     NULL,
                     TO_CHAR (
                          pkg_gis.cst_othernotindeltatolerance
                        + pkg_gis.cst_distancetolgewiss),
                        TO_CHAR (l_recallstation.ims_coordinates.sdo_point.x)
                     || ' : '
                     || TO_CHAR (l_recallstation.ims_coordinates.sdo_point.y));
                  --  cst_unableidentifywtcbyswissto
                  NULL;
               ELSE
                  --  Un cours d'eau a été trouvé avec les données swisstopo dans le rayon de tolérance (%p1%) autour de la coordonnée (%p2%) à une distance de %p3% mètres. Ce
                  --  cours d'eau n'a pas pu être identifié car il ne possède pas de valeur dans la colonne "gewissnr"
                  --cst_gewissnrmissing
                  pkg_importprotocollog.p_writelog (
                     p_iph_id,
                     NULL,
                     pkg_exception.cst_gewissnrmissing,
                     NULL,
                     TO_CHAR (pkg_gis.cst_distancetolgewiss),
                        TO_CHAR (l_recallstation.ims_coordinates.sdo_point.x)
                     || ' : '
                     || TO_CHAR (l_recallstation.ims_coordinates.sdo_point.y),
                     TO_CHAR (l_distance, '9999999.9'));

                  NULL;
               END IF;
            ELSE
               -- Le cours d'eau n'a pu être identifié par ses coordonnées (%p1%)  dans la rayon de %p2% mètres. Le cours d'eau le plus proche se trouve à %p3% mètres (Nom: %p4%)
               -- cst_wtcoutofradius

               pkg_importprotocollog.p_writelog (
                  p_iph_id,
                  NULL,
                  pkg_exception.cst_wtcoutofradius,
                  NULL,
                     TO_CHAR (l_recallstation.ims_coordinates.sdo_point.x)
                  || ' : '
                  || TO_CHAR (l_recallstation.ims_coordinates.sdo_point.y),
                  TO_CHAR (pkg_gis.cst_distancetolgewiss),
                  TO_CHAR (l_distance, '9999999.9'),
                  NVL (l_gwn25.name, '<nul>'));

               IF l_listwatercourse.EXISTS (UPPER (l_gwn25.name))
               THEN
                  l_identifiedmode := cst_identifiedmodebyname;
                  l_gewissnrwrite := l_gwn25.gewissnr;
               END IF;

               NULL;
            END IF;
         END IF;

         IF NOT l_elevationwrite IS NULL
         THEN
         
       

            UPDATE importmassstation
               SET ims_cvl_id_elevationorigin =
                      l_reccodevalueelevationorigin.cvl_id,
                   ims_z=l_elevationwrite
             WHERE CURRENT OF l_allstation;

            -- L'atitude de la coordonnée (%p1%) de la station n'a pas été renseignée. Elle est automatiquement déterminée par les données de Swisstopo. Altitude trouvée: %p2% mètres
            -- cst_autocompleteelevation

            pkg_importprotocollog.p_writelog (
               p_iph_id,
               NULL,
               pkg_exception.cst_autocompleteelevation,
               NULL,
                  TO_CHAR (l_recallstation.ims_coordinates.sdo_point.x)
               || ' : '
               || TO_CHAR (l_recallstation.ims_coordinates.sdo_point.y),
               TO_CHAR (l_elevationwrite));
         END IF;

         IF l_gewissnrwrite IS NULL
         THEN
            -- On essaye encore avec le nom
            p_findbywatersourcename (l_listwatercourse,
                                     l_watercoursename_gwn25,
                                     l_watercoursegewissnr,
                                     l_returnstatus);

            IF l_returnstatus = pkg_constante.cst_returnstatusok
            THEN
               l_gewissnrwrite := l_watercoursegewissnr;
            END IF;
         END IF;

         IF NOT l_gewissnrwrite IS NULL
         THEN
            UPDATE importmassstation
               SET ims_gewissnr = l_gewissnrwrite
             WHERE CURRENT OF l_allstation;

            IF l_identifiedmode = cst_identifiedmodebyxy
            THEN
               -- Le cours d'eau a pu être identifié dans le données de Swisstopo. Il est automatiquement renseignée avec les valeurs: Nom: %p1%, "gewissnr": %p2%
               -- cst_autocompletegewissnr
               pkg_importprotocollog.p_writelog (
                  p_iph_id,
                  NULL,
                  pkg_exception.cst_autocompletegewissnr,
                  NULL,
                  l_gwn25.name,
                  l_gwn25.gewissnr);
            END IF;

            IF l_identifiedmode = cst_identifiedmodebyname
            THEN
               -- Le cours d'eau a pu être identifié par son nom  (%p1%) qui est identique à celui contenu dans les données de Swisstopo
               pkg_importprotocollog.p_writelog (
                  p_iph_id,
                  NULL,
                  pkg_exception.cst_toponamematch,
                  NULL,
                  l_gwn25.name);
            END IF;
         END IF;
      END LOOP;

      CLOSE l_allstation;
   END;



   /*----------------------------------------------------------------*/

   PROCEDURE p_checkelevation (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_startpoint_x   IN     importmassdataheader.imh_startpoint_x%TYPE,
      p_startpoint_y   IN     importmassdataheader.imh_startpoint_y%TYPE,
      p_elevation      IN     importmassdataheader.imh_elevation%TYPE,
      p_returnstatus      OUT NUMBER)
   /*----------------------------------------------------------------------------------*/
   IS
      l_x                    NUMBER;
      l_y                    NUMBER;
      l_elevation            NUMBER;
      l_elevationreference   NUMBER;
      l_returnstatus         NUMBER;
      l_cvl_code_origin      codevalue.cvl_code%TYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      -- l-x et l_y  on déjà été testé. On a seulement besoin de la valeur numérique
      l_x := pkg_datatype.f_validateswisscoordx (p_startpoint_x);
      l_y := pkg_datatype.f_validateswisscoordy (p_startpoint_y);



      IF p_elevation IS NULL
      THEN
         RETURN;                                       -- Pas saisi, pas testé
      END IF;

      -- L'elevation a déja été tester on a seulement besoin de la valeur numérique
      l_elevation := pkg_datatype.f_validateswisselev (p_elevation);

      pkg_gis.p_returnelevation (l_x,
                                 l_y,
                                 l_elevationreference,
                                 l_cvl_code_origin,
                                 l_returnstatus);

      pkg_gis.p_checkorigineelevation (p_iph_id, l_cvl_code_origin);

      IF l_returnstatus = pkg_constante.cst_returnstatusok
      THEN
         -- cst_buildstationinfo.
         IF ABS (l_elevation - l_elevationreference) >
               pkg_gis.cst_elevationtolerance
         THEN
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               NULL,
               pkg_exception.cst_elevationnotmatchprovided,
               NULL,
               l_elevation,
               l_elevationreference);
         END IF;
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_completesst_id_oidlink (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      CURSOR l_allheader
      IS
         SELECT *
           FROM importmassdataheader
          WHERE     imh_iph_id = p_iph_id
                AND imh_validstatus != pkg_constante.cst_validstatusnotok
                AND NOT imh_sst_id_oidlink IS NULL
                AND NOT imh_ims_id IS NULL;

      l_recallheader   l_allheader%ROWTYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      OPEN l_allheader;

      LOOP
         FETCH l_allheader INTO l_recallheader;

         EXIT WHEN l_allheader%NOTFOUND;

         UPDATE importmassstation
            SET ims_sst_id_oidlink = l_recallheader.imh_sst_id_oidlink,
                ims_usr_id_modify = p_usr_id,
                ims_usr_modify_date = SYSDATE
          WHERE ims_id = l_recallheader.imh_ims_id;
      END LOOP;

      CLOSE l_allheader;

      NULL;
   END;


   /*----------------------------------------------------------------*/

   PROCEDURE p_buildimportstation (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*--------------------------------------------------------------*/
   IS
      /* A ce niveau, imh_startpoint_x, imh_startpoint_y, imh_elevation sont déjà validé par pkg_validatemassheaderfield
           Attention: IMH_ELEVATION peut être NULL
           Attention: L'enrichissement par la valeur de l'altitude de swisstopo est réalisé dans la procédure p_completedata
           */

      CURSOR l_allstation      -- Toute les données de ce curseur sont valides
      IS
           SELECT imh_oid,
                  imh_startpoint_x,
                  imh_startpoint_y,
                  imh_elevation
             FROM importmassdataheader
            WHERE     imh_iph_id = p_iph_id
                  AND imh_validstatus != pkg_constante.cst_validstatusnotok
         GROUP BY imh_oid,
                  imh_startpoint_x,
                  imh_startpoint_y,
                  imh_elevation
         ORDER BY imh_oid,
                  imh_startpoint_x,
                  imh_startpoint_y,
                  imh_elevation;


      l_recallstation                 l_allstation%ROWTYPE;
      l_reclaststation                l_allstation%ROWTYPE;
      l_recimportprotocolheader       importprotocolheader%ROWTYPE;
      l_ims_id                        importmassstation.ims_id%TYPE;
      l_starttime                     TIMESTAMP;
      l_totalcount                    NUMBER;
      l_returnstatus                  NUMBER;
      l_count                         NUMBER;
      l_reccodevalueelevationorigin   codevalue%ROWTYPE;
      l_elevationorigin               codevalue.cvl_id%TYPE;
      l_elevation                     NUMBER;
      l_x                             NUMBER;
      l_y                             NUMBER;
      l_listwatercourse               pkg_importmassdataheader.t_listvarchar;
      l_listlocality                  pkg_importmassdataheader.t_listvarchar;
      l_listdate                      pkg_importmassdataheader.t_listvarchar;
      l_stringlocality                VARCHAR2 (1024);
      l_stringwatercourse             VARCHAR2 (1024);
      l_stringdate                    VARCHAR2 (1024);
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_totalcount := f_countallstationtobuild (p_iph_id);

      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);

      pkg_importmassstation.p_deletebyiph_id (p_iph_id);
      l_count := 0;
      l_reccodevalueelevationorigin :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_elevorigin,
            pkg_codevalue.cst_elevorigin_data);

      OPEN l_allstation;

      LOOP
         FETCH l_allstation INTO l_recallstation;

         EXIT WHEN l_allstation%NOTFOUND;
         pkg_importmassdataheader.p_returninfoheaderbycoordinate (
            p_iph_id,
            l_recallstation.imh_oid,
            l_recallstation.imh_elevation,
            l_recallstation.imh_startpoint_x,
            l_recallstation.imh_startpoint_y,
            l_listlocality,
            l_listwatercourse,
            l_listdate);
         l_stringlocality :=
            pkg_importmassdataheader.f_formatlistvarchar (
               l_listlocality,
               pkg_importmassdataheader.cst_fieldlocality);
         l_stringwatercourse :=
            pkg_importmassdataheader.f_formatlistvarchar (
               l_listwatercourse,
               pkg_importmassdataheader.cst_fieldwatercourse);
         l_stringdate :=
            pkg_importmassdataheader.f_formatlistvarchar (
               l_listdate,
               pkg_importmassdataheader.cst_fielddate);
         -- Création des données de la station a partir des données des prélévements suivants: Cours d'eau :%p1%, localité: %p2%, date: %p3%, coordonnée: %p4%
         pkg_importprotocollog.p_writelog (
            p_iph_id,
            NULL,
            pkg_exception.cst_buildstationinfo,
            NULL,
            l_stringwatercourse,
            l_stringlocality,
            l_stringdate,
               '('
            || l_recallstation.imh_startpoint_x
            || ' : '
            || l_recallstation.imh_startpoint_y
            || ')');

         IF l_listlocality.COUNT > 1
         THEN
            --  La station définie par les coordonnées %p1% est définie avec plusieurs valeurs (%p2%) de localités différentes
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               NULL,
               pkg_exception.cst_samestationhasmorelocality,
               NULL,
                  '('
               || l_recallstation.imh_startpoint_x
               || ' : '
               || l_recallstation.imh_startpoint_y
               || ')',
               l_stringlocality);
         END IF;

         IF l_listwatercourse.COUNT > 1
         THEN
            --  La station définie par les coordonnées %p1% est définie avec plusieurs valeurs (%p2%) de cours d'eau différentes
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               NULL,
               pkg_exception.cst_samestationhasmorewtc,
               NULL,
                  '('
               || l_recallstation.imh_startpoint_x
               || ' : '
               || l_recallstation.imh_startpoint_y
               || ')',
               l_stringwatercourse);
         END IF;



         l_count := l_count + 1;
         pkg_processingstatus.p_setstatusbar (l_count, l_totalcount);
         -- L'élévation est NUL ou valide car déjà validée
         l_elevation :=
            pkg_datatype.f_validatedouble (l_recallstation.imh_elevation);

         IF NOT l_elevation IS NULL
         THEN
            l_elevationorigin := l_reccodevalueelevationorigin.cvl_id;
            p_checkelevation (p_iph_id,
                              p_lan_id,
                              l_recallstation.imh_startpoint_x,
                              l_recallstation.imh_startpoint_y,
                              l_recallstation.imh_elevation,
                              l_returnstatus);
         ELSE
            l_elevationorigin := NULL;
         END IF;

         l_x :=
            pkg_datatype.f_validatedouble (l_recallstation.imh_startpoint_x);
         l_y :=
            pkg_datatype.f_validatedouble (l_recallstation.imh_startpoint_y);
         pkg_debug.p_write ('PKG_VALIDATEMASSSTATION.p_buildimportstation',
                            'Altitude=' || l_elevation);
         pkg_importmassstation.p_write (
            p_lan_id,
            l_recallstation.imh_oid,
            l_recimportprotocolheader.iph_ins_id_principal,
            l_x,
            l_y,
            l_elevation,
            l_elevationorigin,
            NULL,                                        -- elevationprecision
            NULL,                                                      --TITLE
            p_usr_id,
            l_ims_id);

         pkg_importmassdataheader.p_update_imh_ims_id (
            p_iph_id,
            l_ims_id,
            l_recallstation.imh_oid,
            l_recallstation.imh_startpoint_x,
            l_recallstation.imh_startpoint_y,
            l_recallstation.imh_elevation,
            p_usr_id);
      END LOOP;

      CLOSE l_allstation;
   END;



   /*------------------------------------------------------------------------------*/

   PROCEDURE p_checkduplicateoid (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*-------------------------------------------------------------------------------*/
   IS
      -- On contrôle que le même OID ai la même coordonnée
      CURSOR l_allduplicateoid
      IS
           SELECT ims_oid
             FROM importmassstation
            WHERE     NOT ims_oid IS NULL
                  AND ims_id IN (SELECT imh_ims_id
                                   FROM importmassdataheader
                                  WHERE imh_iph_id = p_iph_id)
                  AND ims_validstatus = pkg_constante.cst_validstatuspending
         GROUP BY ims_oid
           HAVING COUNT (*) > 1;

      l_recallduplicateoid   l_allduplicateoid%ROWTYPE;

      CURSOR l_sameoid (p_oid IN importmassstation.ims_oid%TYPE)
      IS
         SELECT *
           FROM importmassstation
          WHERE     ims_oid = p_oid
                AND ims_id IN (SELECT imh_ims_id
                                 FROM importmassdataheader
                                WHERE imh_iph_id = p_iph_id);

      CURSOR l_listsameoid (
         p_oid              IN VARCHAR2,
         p_iph_id           IN importprotocolheader.iph_id%TYPE,
         p_exclude_ims_id   IN importmassstation.ims_id%TYPE)
      IS
         SELECT *
           FROM importmassstation
          WHERE     ims_id IN (SELECT imh_ims_id
                                 FROM importmassdataheader
                                WHERE imh_iph_id = p_iph_id)
                AND ims_oid = p_oid
                AND ims_id != p_exclude_ims_id;

      l_reclistsameoid       l_listsameoid%ROWTYPE;

      l_recsameoid           l_sameoid%ROWTYPE;
      l_recsameoidref        l_sameoid%ROWTYPE;
      l_distance             NUMBER;
      l_ok                   BOOLEAN;
      l_stringlocality1      VARCHAR2 (1024);
      l_stringwatercourse1   VARCHAR2 (1024);
      l_stringdate1          VARCHAR2 (1024);
      l_stringlocality2      VARCHAR2 (1024);
      l_stringwatercourse2   VARCHAR2 (1024);
      l_stringdate2          VARCHAR2 (1024);
      l_coordinates1         VARCHAR2 (128);
      l_coordinates2         VARCHAR2 (128);
      l_returnstatus         NUMBER;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      -- Identification des nouvelles stations qui ont un même OID et une coordonnées différentes, hors des limites du rayon de tolérance (%p1%)
      pkg_importprotocollog.p_writelog (
         p_iph_id,
         NULL,
         pkg_exception.cst_infostationsameoidcoorderr,
         NULL,
         TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol, '9999999.9'));

      OPEN l_allduplicateoid;

      LOOP
         FETCH l_allduplicateoid INTO l_recallduplicateoid;

         EXIT WHEN l_allduplicateoid%NOTFOUND;
         l_recsameoidref.ims_id := NULL;
         l_ok := TRUE;

         OPEN l_sameoid (l_recallduplicateoid.ims_oid);

         LOOP
            FETCH l_sameoid INTO l_recsameoid;

            EXIT WHEN l_sameoid%NOTFOUND OR NOT l_ok;

            IF l_recsameoidref.ims_id IS NULL
            THEN
               l_recsameoidref := l_recsameoid;
            ELSE
               l_distance :=
                  pkg_sdoutil.f_computedistance2d (
                     l_recsameoidref.ims_coordinates,
                     l_recsameoid.ims_coordinates);

               IF l_distance > pkg_codevalue.f_get_midatparam_rayontol
               THEN
                  -- exc_stationsameoidnotsamecoord
                  p_returnstringinfoheader (l_recsameoid.ims_id,
                                            l_stringlocality2,
                                            l_stringwatercourse2,
                                            l_stringdate2);
                  l_coordinates2 :=
                        TO_CHAR (l_recsameoid.ims_coordinates.sdo_point.x,
                                 '9999999.9')
                     || '/'
                     || TO_CHAR (l_recsameoid.ims_coordinates.sdo_point.y,
                                 '9999999.9');

                  OPEN l_listsameoid (l_recallduplicateoid.ims_oid,
                                      p_iph_id,
                                      l_recsameoid.ims_id);

                  LOOP
                     FETCH l_listsameoid INTO l_reclistsameoid;

                     EXIT WHEN l_listsameoid%NOTFOUND;
                     l_coordinates1 :=
                           TO_CHAR (
                              l_reclistsameoid.ims_coordinates.sdo_point.x,
                              '9999999.9')
                        || '/'
                        || TO_CHAR (
                              l_reclistsameoid.ims_coordinates.sdo_point.y,
                              '9999999.9');
                     p_returnstringinfoheader (l_reclistsameoid.ims_id,
                                               l_stringlocality1,
                                               l_stringwatercourse1,
                                               l_stringdate1);
                     -- Le nouvelle station (Cours d'eau: %p1%   Localité: %p2%  Coordonnées: %p3%) a le même OID (%p4%) défini que la station (Cours d'eau: %p5%   Localité: %p6%  Coordonnées: %p6%). La distance (%p7% mètres) entre les deux est hors de la tolérance admise

                     pkg_importprotocollog.p_writelog (
                        p_iph_id,
                        NULL,                           -- Il y en a plusieurs
                        pkg_exception.cst_stationsameoidnotsamecoord,
                        'IMS_COORDINATES',
                        l_stringwatercourse1,
                        l_stringlocality1,
                        l_coordinates1,
                        l_recallduplicateoid.ims_oid,
                        l_stringwatercourse2,
                        l_stringlocality2,
                        l_coordinates2,
                        TO_CHAR (l_distance, '999999.9'));
                  END LOOP;

                  CLOSE l_listsameoid;

                  p_invalidatestationbyoid (p_iph_id,
                                            l_recallduplicateoid.ims_oid,
                                            l_returnstatus);



                  l_ok := FALSE;
               END IF;

               NULL;
            END IF;
         END LOOP;

         CLOSE l_sameoid;
      END LOOP;

      CLOSE l_allduplicateoid;



      NULL;
   END;



   /*------------------------------------------------------------------------------*/

   PROCEDURE p_checkduplicatecoordinates (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*-------------------------------------------------------------------------------*/
   IS
      /* On contrôle si des coordonnées de stations différentes sont très proches sans qu'elles possèdent d'OID
        ATTENTION: Il n'y a pas besoin de contrôler dans SAMPLESTATION car  dans SAMPLESTATION il y a un OID */
      CURSOR l_duplicate (
         p_coordinates      IN importmassstation.ims_coordinates%TYPE,
         p_ims_id_exclude   IN importmassstation.ims_id%TYPE,
         p_ins_id           IN importmassstation.ims_ins_id%TYPE)
      IS
         SELECT importmassstation.*,
                pkg_sdoutil.f_computedistance2d (p_coordinates,
                                                 ims_coordinates)
                   distance
           FROM importmassstation
          WHERE     pkg_sdoutil.f_computedistance2d (p_coordinates,
                                                     ims_coordinates) <=
                       pkg_codevalue.f_get_midatparam_rayontol
                AND ims_id IN (SELECT imh_ims_id
                                 FROM importmassdataheader
                                WHERE imh_iph_id = p_iph_id)
                AND ims_oid IS NULL
                AND ims_id != p_ims_id_exclude
                AND ims_validstatus = pkg_constante.cst_validstatuspending;

      CURSOR l_listfull
      IS
         SELECT ims_id, ims_coordinates, ims_validstatus
           FROM importmassstation
          WHERE     ims_id IN (SELECT imh_ims_id
                                 FROM importmassdataheader
                                WHERE imh_iph_id = p_iph_id)
                AND ims_validstatus = pkg_constante.cst_validstatuspending
                AND ims_oid IS NULL;



      l_recduplicate              l_duplicate%ROWTYPE;
      l_reclistfull               l_listfull%ROWTYPE;
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
      l_merge                     BOOLEAN;
      l_recimportmassstation      importmassstation%ROWTYPE;
      l_ims_id_concerve           importmassstation.ims_id%TYPE;
      l_ims_id_supprime           importmassstation.ims_id%TYPE;
      l_listlocality              pkg_importmassdataheader.t_listvarchar;
      l_listwatercourse           pkg_importmassdataheader.t_listvarchar;
      l_listdate                  pkg_importmassdataheader.t_listvarchar;
      l_stringlocality1           VARCHAR2 (1024);
      l_stringwatercourse1        VARCHAR2 (1024);
      l_stringdate1               VARCHAR2 (1024);
      l_stringlocality2           VARCHAR2 (1024);
      l_stringwatercourse2        VARCHAR2 (1024);
      l_stringdate2               VARCHAR2 (1024);
      l_coordinate1               VARCHAR2 (128);
      l_coordinate2               VARCHAR2 (128);
      l_distance                  NUMBER;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      -- Identification des nouvelles stations fournies sans OID qui se trouve dans un rayon de %p1% mètres d'une autre nouvelle station en vue d'aggrégation
      pkg_importprotocollog.p_writelog (
         p_iph_id,
         NULL,
         pkg_exception.cst_infostationnearnotsame,
         NULL,
         TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol, '9999999.9'));
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);


      OPEN l_listfull;

      LOOP
         FETCH l_listfull INTO l_reclistfull;

         EXIT WHEN l_listfull%NOTFOUND;
         DBMS_OUTPUT.put_line (
            'l_reclistfull.ims_id=' || l_reclistfull.ims_id);
         l_merge := FALSE;
         l_recimportmassstation :=
            pkg_importmassstation.f_getrecord (l_reclistfull.ims_id); -- Le curseur n'est pas rafraichi . Il faut relancer l'interrogation pour savoir si il y a M

         IF l_recimportmassstation.ims_validstatus =
               pkg_constante.cst_validstatuspending
         THEN
            l_ims_id_concerve := NULL;

            OPEN l_duplicate (l_reclistfull.ims_coordinates,
                              l_reclistfull.ims_id,
                              l_recimportprotocolheader.iph_ins_id_principal);

            LOOP
               -- On cherche si dans la liste il n'y a pas une station qui est aussi dans SAMPLESTATION
               FETCH l_duplicate INTO l_recduplicate;

               EXIT WHEN    l_duplicate%NOTFOUND
                         OR NOT l_ims_id_concerve IS NULL;

               IF NOT l_recduplicate.ims_sst_id IS NULL
               THEN
                  l_ims_id_concerve := l_recduplicate.ims_id;
               END IF;
            END LOOP;

            CLOSE l_duplicate;

            IF l_ims_id_concerve IS NULL
            THEN
               l_ims_id_concerve := l_reclistfull.ims_id;
            END IF;

            l_coordinate1 :=
                  TO_CHAR (l_reclistfull.ims_coordinates.sdo_point.x,
                           '9999999.9')
               || '/'
               || TO_CHAR (l_reclistfull.ims_coordinates.sdo_point.y,
                           '9999999.9');

            OPEN l_duplicate (l_reclistfull.ims_coordinates,
                              l_reclistfull.ims_id,
                              l_recimportprotocolheader.iph_ins_id_principal);

            LOOP
               FETCH l_duplicate INTO l_recduplicate;

               EXIT WHEN l_duplicate%NOTFOUND;

               l_coordinate2 :=
                     TO_CHAR (l_recduplicate.ims_coordinates.sdo_point.x,
                              '9999999.9')
                  || '/'
                  || TO_CHAR (l_recduplicate.ims_coordinates.sdo_point.y,
                              '9999999.9');

               DBMS_OUTPUT.put_line (
                  'l_recduplicate.ims_id=' || l_recduplicate.ims_id);
               pkg_importmassdataheader.p_returninfoheaderbyims_id (
                  l_ims_id_concerve,
                  l_listlocality,
                  l_listwatercourse,
                  l_listdate);
               l_stringlocality1 :=
                  pkg_importmassdataheader.f_formatlistvarchar (
                     l_listlocality,
                     pkg_importmassdataheader.cst_fieldlocality);
               l_stringwatercourse1 :=
                  pkg_importmassdataheader.f_formatlistvarchar (
                     l_listwatercourse,
                     pkg_importmassdataheader.cst_fieldwatercourse);
               l_stringdate1 :=
                  pkg_importmassdataheader.f_formatlistvarchar (
                     l_listdate,
                     pkg_importmassdataheader.cst_fielddate);
               l_ims_id_supprime := l_recduplicate.ims_id;
               pkg_importmassdataheader.p_returninfoheaderbyims_id (
                  l_ims_id_supprime,
                  l_listlocality,
                  l_listwatercourse,
                  l_listdate);
               l_stringlocality2 :=
                  pkg_importmassdataheader.f_formatlistvarchar (
                     l_listlocality,
                     pkg_importmassdataheader.cst_fieldlocality);
               l_stringwatercourse2 :=
                  pkg_importmassdataheader.f_formatlistvarchar (
                     l_listwatercourse,
                     pkg_importmassdataheader.cst_fieldwatercourse);
               l_stringdate2 :=
                  pkg_importmassdataheader.f_formatlistvarchar (
                     l_listdate,
                     pkg_importmassdataheader.cst_fielddate);
               -- La station (Cours d'eau: %p1% Localité %p2% Coordonnée: %p3%) se trouve à une distance de %p4% de la station  (Cours d'eau: %p5% Localité %p6% Coordonnée: %p7%) . Ces deux stations sont fusionnées (les données de la première station sont concervées) car elles sont dans le rayon de tolérance (%p8%) de proximité autorisant la fusion
               l_distance :=
                  pkg_sdoutil.f_computedistance2d (
                     l_recduplicate.ims_coordinates,
                     l_reclistfull.ims_coordinates);
               pkg_importprotocollog.p_writelog (
                  p_iph_id,
                  NULL,
                  pkg_exception.cst_infostationfusion,
                  NULL,
                  l_stringwatercourse1,
                  l_stringlocality1,
                  l_coordinate1,
                  TO_CHAR (l_distance, '99999.9'),
                  l_stringwatercourse2,
                  l_stringlocality2,
                  l_coordinate2,
                  TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol, '9999999.9'));
               pkg_importmassstation.p_processwhensamecoordinates (
                  l_ims_id_concerve,
                  l_ims_id_supprime,
                  p_usr_id);
               l_merge := TRUE;
            END LOOP;



            CLOSE l_duplicate;
         END IF;
      END LOOP;

      CLOSE l_listfull;



      NULL;
   END;

   /*------------------------------------------------------------------------------*/

   PROCEDURE p_test1
   /*------------------------------------------------------------------------------*/
   IS
      l_returnstatus   NUMBER;
   BEGIN
      p_checkduplicatecoordinates (2,
                                   2,
                                   1,
                                   l_returnstatus);
   END;

   /*-----------------------------------------------------------------*/

   PROCEDURE p_findsavedstationbycoordinate (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*------------------------------------------------------------------*/
   IS
      -- On cherche les stations déjà sauvées qui sont dans un rayon de tolérance
      -- Utilisé lors de la confirmation

      CURSOR l_station
      IS
         SELECT *
           FROM importmassstation
          WHERE     ims_id IN (SELECT imh_ims_id
                                 FROM importmassdataheader
                                WHERE imh_iph_id = p_iph_id)
                AND ims_oid IS NULL
                AND ims_validstatus = pkg_constante.cst_validstatuspending;

      l_reccursor                 l_station%ROWTYPE;
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
      l_sst_id                    samplestation.sst_id%TYPE;
      l_distance                  NUMBER;
      l_listlocality              pkg_importmassdataheader.t_listvarchar;
      l_listwatercourse           pkg_importmassdataheader.t_listvarchar;
      l_listdate                  pkg_importmassdataheader.t_listvarchar;
      l_stringlocality            VARCHAR2 (1024);
      l_stringwatercourse         VARCHAR2 (1024);
      l_stringdate                VARCHAR2 (1024);
      l_watercourse               samplestationitem.ssi_item%TYPE;
      l_locality                  samplestationitem.ssi_item%TYPE;
      l_oid                       samplestation.sst_oid%TYPE;
      l_returnstatus              NUMBER;
   /*
              AND pkg_sdoutil.f_computedistance2d (p_coordinates,
                                                 ims_coordinates) <
                     pkg_samplestation.cst_rayontolerance;
                     */
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);
      -- Comparaison des coordonnnées des nouvelles stations avec les coordonnées des stations existantes dans un rayon de %p1% mètres pour aggrégation.
      pkg_importprotocollog.p_writelog (
         p_iph_id,
         NULL,
         pkg_exception.cst_infostationaggregate,
         NULL,
         TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol, '99999.9'));

      OPEN l_station;

      LOOP
         FETCH l_station INTO l_reccursor;

         EXIT WHEN l_station%NOTFOUND;
         pkg_samplestation.p_getnearsst_id (
            l_reccursor.ims_coordinates,
            l_recimportprotocolheader.iph_ins_id_principal,
            l_sst_id,
            l_distance);

         IF NVL (l_distance, pkg_codevalue.f_get_midatparam_rayontol + 1) <=
               pkg_codevalue.f_get_midatparam_rayontol
         THEN
            pkg_importmassdataheader.p_returninfoheaderbyims_id (
               l_reccursor.ims_id,
               l_listlocality,
               l_listwatercourse,
               l_listdate);
            l_stringlocality :=
               pkg_importmassdataheader.f_formatlistvarchar (
                  l_listlocality,
                  pkg_importmassdataheader.cst_fieldlocality);
            l_stringwatercourse :=
               pkg_importmassdataheader.f_formatlistvarchar (
                  l_listwatercourse,
                  pkg_importmassdataheader.cst_fieldwatercourse);
            l_stringdate :=
               pkg_importmassdataheader.f_formatlistvarchar (
                  l_listdate,
                  pkg_importmassdataheader.cst_fielddate);
            -- La station (Cours d'eau: %p1% Localité: %p2% ) fournie dans le jeu de données se trouve à une distance de %p3% de la station existante (Cours d'eau %p4% Localité: %p5%). La station existante est utilisée pour référencer les données car elle se trouve dans le rayon de tolérance de (%p6%) mètres
            pkg_samplestation.p_returnstationinfo (l_sst_id,
                                                   p_lan_id,
                                                   l_oid,
                                                   l_watercourse,
                                                   l_locality,
                                                   l_returnstatus);

            IF l_returnstatus = pkg_constante.cst_returnstatusok
            THEN
               pkg_importprotocollog.p_writelog (
                  p_iph_id,
                  NULL,
                  pkg_exception.cst_stationmatching,
                  NULL,
                  l_stringwatercourse,
                  l_stringlocality,
                  TO_CHAR (l_distance, '99999.9'),
                  l_watercourse,
                  l_locality,
                  TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol, '99999.9'));
               NULL;
            END IF;



            pkg_importmassstation.p_update_ims_sst_id (l_reccursor.ims_id,
                                                       l_sst_id,
                                                       p_usr_id);
            pkg_importmassdataheader.p_update_imh_sst_id_by_ims_id (
               l_reccursor.ims_id,
               l_sst_id,
               p_usr_id);
         END IF;
      END LOOP;

      CLOSE l_station;

      NULL;
   END;



   /*-----------------------------------------------------------------*/

   PROCEDURE p_associateoidbycoordinates (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*------------------------------------------------------------------*/
   IS
      /* Il est possible qu'une entrée avec un OID soit proche d'une entrée sans OID.
       L'entrée avec OID doit primer */
      CURSOR l_alloidstation
      IS
         SELECT *
           FROM importmassstation
          WHERE     ims_id IN (SELECT imh_ims_id
                                 FROM importmassdataheader
                                WHERE imh_iph_id = p_iph_id)
                AND NOT ims_oid IS NULL
                AND ims_validstatus = pkg_constante.cst_validstatuspending;

      l_recalloidstation       l_alloidstation%ROWTYPE;
      l_ims_id_concerve        importmassstation.ims_id%TYPE;
      l_ims_id_supprime        importmassstation.ims_id%TYPE;

      CURSOR l_stationindistance (
         p_coordinates   IN importmassstation.ims_coordinates%TYPE)
      IS
         SELECT *
           FROM importmassstation
          WHERE     ims_id IN (SELECT imh_ims_id
                                 FROM importmassdataheader
                                WHERE imh_iph_id = p_iph_id)
                AND ims_oid IS NULL
                AND ims_validstatus != pkg_constante.cst_validstatuspending
                AND pkg_sdoutil.f_computedistance2d (p_coordinates,
                                                     ims_coordinates) <
                       pkg_codevalue.f_get_midatparam_rayontol;

      l_recstationindistance   l_stationindistance%ROWTYPE;
      l_listlocality           pkg_importmassdataheader.t_listvarchar;
      l_listwatercourse        pkg_importmassdataheader.t_listvarchar;
      l_listdate               pkg_importmassdataheader.t_listvarchar;
      l_stringlocality1        VARCHAR2 (1024);
      l_stringwatercourse1     VARCHAR2 (1024);
      l_stringdate1            VARCHAR2 (1024);
      l_stringlocality2        VARCHAR2 (1024);
      l_stringwatercourse2     VARCHAR2 (1024);
      l_stringdate2            VARCHAR2 (1024);
      l_coordinate1            VARCHAR2 (128);
      l_coordinate2            VARCHAR2 (128);
      l_distance               NUMBER;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      -- Identification des nouvelles stations avec OID qui sont proches (rayon de tolérance %p1%)  d'une nouvelle station  sans OID. Les stations avec OID sont concervées en cas de fusion
      --cst_infostationnearoidnotoid
      pkg_importprotocollog.p_writelog (
         p_iph_id,
         NULL,
         pkg_exception.cst_infostationnearoidnotoid,
         NULL,
         TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol, '99999.9'));

      OPEN l_alloidstation;

      LOOP
         FETCH l_alloidstation INTO l_recalloidstation;

         EXIT WHEN l_alloidstation%NOTFOUND;
         l_ims_id_concerve := l_recalloidstation.ims_id;
         pkg_importmassdataheader.p_returninfoheaderbyims_id (
            l_ims_id_concerve,
            l_listlocality,
            l_listwatercourse,
            l_listdate);
         l_stringlocality1 :=
            pkg_importmassdataheader.f_formatlistvarchar (
               l_listlocality,
               pkg_importmassdataheader.cst_fieldlocality);
         l_stringwatercourse1 :=
            pkg_importmassdataheader.f_formatlistvarchar (
               l_listwatercourse,
               pkg_importmassdataheader.cst_fieldwatercourse);
         l_stringdate1 :=
            pkg_importmassdataheader.f_formatlistvarchar (
               l_listdate,
               pkg_importmassdataheader.cst_fielddate);


         OPEN l_stationindistance (l_recalloidstation.ims_coordinates);

         LOOP
            FETCH l_stationindistance INTO l_recstationindistance;

            EXIT WHEN l_stationindistance%NOTFOUND;
            l_ims_id_supprime := l_recstationindistance.ims_id;
            pkg_importmassdataheader.p_returninfoheaderbyims_id (
               l_ims_id_supprime,
               l_listlocality,
               l_listwatercourse,
               l_listdate);
            l_stringlocality2 :=
               pkg_importmassdataheader.f_formatlistvarchar (
                  l_listlocality,
                  pkg_importmassdataheader.cst_fieldlocality);
            l_stringwatercourse2 :=
               pkg_importmassdataheader.f_formatlistvarchar (
                  l_listwatercourse,
                  pkg_importmassdataheader.cst_fieldwatercourse);
            l_stringdate2 :=
               pkg_importmassdataheader.f_formatlistvarchar (
                  l_listdate,
                  pkg_importmassdataheader.cst_fielddate);
            l_distance :=
               pkg_sdoutil.f_computedistance2d (
                  l_recalloidstation.ims_coordinates,
                  l_recstationindistance.ims_coordinates);

            pkg_importprotocollog.p_writelog (
               p_iph_id,
               NULL,
               pkg_exception.cst_infostationfusion,
               NULL,
               l_stringwatercourse1,
               l_stringlocality1,
               l_coordinate1,
               TO_CHAR (l_distance, '99999.9'),
               l_stringwatercourse2,
               l_stringlocality2,
               l_coordinate2,
               TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol, '9999999.9'));
            pkg_importmassstation.p_processwhensamecoordinates (
               l_ims_id_concerve,
               l_ims_id_supprime,
               p_usr_id);
         END LOOP;

         CLOSE l_stationindistance;
      END LOOP;

      CLOSE l_alloidstation;

      NULL;
   END;

   /*-----------------------------------------------------------------*/

   PROCEDURE p_stationsavednotmatch (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*------------------------------------------------------------------*/
   IS
      /* Permet de vérifier que la station avec OID a les même coordonnées
          que la station avec l'OID équivalent dans la table SAMPLESTATION
       */
      CURSOR l_allstation
      IS
         SELECT *
           FROM importmassstation
          WHERE     ims_id IN (SELECT imh_ims_id
                                 FROM importmassdataheader
                                WHERE imh_iph_id = p_iph_id)
                AND NOT ims_oid IS NULL
                AND ims_validstatus = pkg_constante.cst_validstatuspending;

      l_recallstation             l_allstation%ROWTYPE;
      l_recsamplestation          samplestation%ROWTYPE;
      l_recimportprotocolheader   importprotocolheader%ROWTYPE;
      l_distance                  NUMBER;
      l_fmtcoordinates1           VARCHAR2 (256);
      l_fmtcoordinates2           VARCHAR2 (256);
      l_returnstatus              NUMBER;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      -- Identification des nouvelles stations qui ont  un OID défini et qui existe déjà dans la base de données avec une coordonnées différentes (Hors du rayon de tolérance %p1%)
      -- cst_infostationoidwithavedoid
      pkg_importprotocollog.p_writelog (
         p_iph_id,
         NULL,
         pkg_exception.cst_infostationoidwithsavedoid,
         NULL,
         TO_CHAR (pkg_codevalue.f_get_midatparam_rayontol, '99999.9'));

      l_recimportprotocolheader :=
         pkg_importprotocolheader.f_getrecord (p_iph_id);

      OPEN l_allstation;

      LOOP
         FETCH l_allstation INTO l_recallstation;

         EXIT WHEN l_allstation%NOTFOUND;
         l_recsamplestation :=
            pkg_samplestation.f_getrecordbyinsidandoid (
               l_recimportprotocolheader.iph_ins_id_principal,
               l_recallstation.ims_oid);

         IF NOT l_recsamplestation.sst_id IS NULL
         THEN
            l_distance :=
               pkg_sdoutil.f_computedistance2d (
                  l_recsamplestation.sst_coordinates,
                  l_recallstation.ims_coordinates);

            IF l_distance < pkg_codevalue.f_get_midatparam_rayontol
            THEN
               -- On fait le lien avec la station existante
               pkg_importmassstation.p_update_ims_sst_id (
                  l_recallstation.ims_id,
                  l_recsamplestation.sst_id,
                  p_usr_id);
               pkg_importmassdataheader.p_update_imh_sst_id_by_ims_id (
                  l_recallstation.ims_id,
                  l_recsamplestation.sst_id,
                  p_usr_id);
            ELSE
               -- On affiche une erreur
               l_fmtcoordinates1 :=
                  pkg_sdoutil.f_formatpointcoordinates (
                     l_recsamplestation.sst_coordinates,
                     8,
                     0);
               l_fmtcoordinates2 :=
                  pkg_sdoutil.f_formatpointcoordinates (
                     l_recallstation.ims_coordinates,
                     8,
                     0);
               pkg_importprotocollog.p_writelog (
                  p_iph_id,
                  NULL,                                 -- Il y en a plusieurs
                  pkg_exception.cst_stationnotmatchcoordinates,
                  'IMS_OID',
                  l_recallstation.ims_oid,
                  l_fmtcoordinates1,
                  l_fmtcoordinates2,
                  TO_CHAR (l_distance) || '(m)');
               p_invalidatestationbyoid (p_iph_id,
                                         l_recallstation.ims_oid,
                                         l_returnstatus);

               NULL;
            END IF;
         END IF;
      END LOOP;

      CLOSE l_allstation;
   END;

   /*---------------------------------------------------------------*/

   PROCEDURE p_invalideheaderwithoutstation (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*----------------------------------------------------------------*/
   IS
      -- Permet d'invalider les enregistrement de la table IMPORTMASSDATAHEADER qui n'ont pas de station valide associée
      CURSOR l_stationinvalide
      IS
         SELECT *
           FROM importmassstation
          WHERE     ims_id IN (SELECT imh_ims_id
                                 FROM importmassdataheader
                                WHERE imh_iph_id = p_iph_id)
                AND ims_validstatus = pkg_constante.cst_validstatusnotok;

      l_recstationinvalide   l_stationinvalide%ROWTYPE;
      l_timestamp            TIMESTAMP;
      l_count                NUMBER := 0;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_timestamp := SYSTIMESTAMP;
      pkg_importprotocollog.p_logstartsubprocess (
         p_iph_id,
         NULL,
         pkg_exception.cst_startinvalidstationdepende);

      OPEN l_stationinvalide;

      LOOP
         FETCH l_stationinvalide INTO l_recstationinvalide;

         EXIT WHEN l_stationinvalide%NOTFOUND;
         l_count := l_count + 1;

         pkg_importmassdataheader.p_setvalidstatuscascade (
            l_recstationinvalide.ims_imh_id,
            pkg_constante.cst_validstatusnotok);
      END LOOP;

      CLOSE l_stationinvalide;


      pkg_importprotocollog.p_logendsubprocess (
         p_iph_id,
         NULL,
         pkg_exception.cst_endinvalidstationdepende,
         l_timestamp,
         l_count);
   END;

   /*----------------------------------------------------------------*/

   PROCEDURE p_main (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER)
   /*----------------------------------------------------------------*/
   IS
      l_totalcount   NUMBER;
      l_starttime    TIMESTAMP;
   BEGIN
      -- On prend comme élément de mesure le select suivant
      SELECT COUNT (*)
        INTO l_totalcount
        FROM (  SELECT imh_oid,
                       imh_startpoint_x,
                       imh_startpoint_y,
                       imh_elevation
                  FROM importmassdataheader
                 WHERE     imh_iph_id = p_iph_id
                       AND imh_validstatus !=
                              pkg_constante.cst_validstatusnotok
              GROUP BY imh_oid,
                       imh_startpoint_x,
                       imh_startpoint_y,
                       imh_elevation);

      pkg_processingsteplog.p_setmeasuredata (
         l_totalcount,
         pkg_processingsteplog.cst_measureunitrowcount);
      -- On construit la table IMPORTMASSSTATION à partir des données contenues dans IMPORTMASSDATAHEADER

      l_starttime := SYSTIMESTAMP;
      pkg_importprotocollog.p_logstartsubprocess (
         p_iph_id,
         NULL,
         pkg_exception.cst_startbuildimportstation);
      p_buildimportstation (p_iph_id,
                            p_usr_id,
                            p_lan_id,
                            p_returnstatus);

      IF p_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         RETURN;
      END IF;

      -- On ajoute l'altitude et le gewissnr
      p_completedata (p_iph_id,
                      p_usr_id,
                      p_lan_id,
                      p_returnstatus);


      IF p_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         RETURN;
      END IF;


      pkg_importprotocollog.p_logendsubprocess (
         p_iph_id,
         NULL,
         pkg_exception.cst_endbuildimportstation,
         l_starttime,
         l_totalcount);
      l_starttime := SYSTIMESTAMP;
      pkg_importprotocollog.p_logstartsubprocess (
         p_iph_id,
         NULL,
         pkg_exception.cst_startcheckstationconsisten);

      -- Contrôle que des station avec OID différents ne se trouve pas dans le rayon de tolérance de %p1% mètre(s)
      p_checkduplicatecoordinatesoid (p_iph_id,
                                      p_usr_id,
                                      p_lan_id,
                                      p_returnstatus);

      IF p_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         RETURN;
      END IF;

      -- On cherche dans la table SAMPLESTATION les stations qui peuvent être associées ( coordonnées dans le rayon de tolérance)

      p_findsavedstationbycoordinate (p_iph_id,
                                      p_usr_id,
                                      p_lan_id,
                                      p_returnstatus);

      IF p_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         RETURN;
      END IF;

      -- On identifie les stations sans OID qui sont dans un rayon de tolérance défini pour les fusionner
      p_checkduplicatecoordinates (p_iph_id,
                                   p_usr_id,
                                   p_lan_id,
                                   p_returnstatus);

      IF p_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         RETURN;
      END IF;

      -- On identifie les stations pour lesquelle le même OID est défini alors que les coordonnées sont hors des tolérances admise
      p_checkduplicateoid (p_iph_id,
                           p_usr_id,
                           p_lan_id,
                           p_returnstatus);

      IF p_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         RETURN;
      END IF;

      -- On identifie les stations avec OID qui sont proches (rayon de tolérance) de station sans OID. Les stations sans OID
      -- qui répondent à ce critère sont fusionner avec les stations avec OID.
      p_associateoidbycoordinates (p_iph_id,
                                   p_usr_id,
                                   p_lan_id,
                                   p_returnstatus);


      IF p_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         RETURN;
      END IF;



      /* Permet de vérifier que la station avec OID a les même coordonnées
            que la station avec l'OID équivalent dans la table SAMPLESTATION
         */

      p_stationsavednotmatch (p_iph_id,
                              p_usr_id,
                              p_lan_id,
                              p_returnstatus);

      IF p_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         RETURN;
      END IF;

      pkg_importprotocollog.p_logendsubprocess (
         p_iph_id,
         NULL,
         pkg_exception.cst_endcheckstationconsistency,
         l_starttime,
         l_totalcount);


      -- On invalide les entrées de IMPORTMASSDATAHEADER qui référencie une station invalide
      p_invalideheaderwithoutstation (p_iph_id,
                                      p_usr_id,
                                      p_lan_id,
                                      p_returnstatus);
      -- On établi le lien avec les station linke
      p_completesst_id_oidlink (p_iph_id,
                                p_usr_id,
                                p_lan_id,
                                p_returnstatus);
   END;

   /*-------------------------------------------------------------*/

   PROCEDURE p_test
   /*------------------------------------------------------------*/
   IS
      l_iph_id         importmassdataheader.imh_iph_id%TYPE;
      l_usr_id         importmassstation.ims_usr_id_modify%TYPE;
      l_lan_id         language.lan_id%TYPE;
      l_returnstatus   NUMBER;
   BEGIN
      l_iph_id := 634;
      l_usr_id := 1;
      l_lan_id := 1;
      p_main (l_iph_id,
              l_usr_id,
              l_lan_id,
              l_returnstatus);
   END;
END;
/

