create trigger TR_BUF_NEOZOAIRE
    before update
    on NEOZOAIRE
    for each row
DECLARE
BEGIN
    :new.NEO_moddate := SYSDATE;
    :new.NEO_moduser := USER;
END tr_buf_NEOZOAIRE;
/

