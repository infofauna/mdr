create PACKAGE       pkg_protocolmappingheader
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLMAPPINGHEADER
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecord (p_pmh_id IN protocolmappingheader.pmh_id%TYPE)
      RETURN protocolmappingheader%ROWTYPE;

   FUNCTION f_getrecordbyptvandmidatitmstr (
      p_ptv_id        IN protocolmappingheader.pmh_ptv_id%TYPE,
      p_midathditem   IN codevalue.cvl_code%TYPE)
      RETURN protocolmappingheader%ROWTYPE;

   FUNCTION f_getrecordbyptvandmidathditem (
      p_ptv_id        IN protocolmappingheader.pmh_ptv_id%TYPE,
      p_midathditem   IN protocolmappingheader.pmh_cvl_id_midathditem%TYPE)
      RETURN protocolmappingheader%ROWTYPE;

   FUNCTION f_getrecordbyptvandfieldnameto (
      p_ptv_id        IN protocolmappingheader.pmh_ptv_id%TYPE,
      p_fieldnameto   IN protocolmappingheader.pmh_fieldnameto%TYPE)
      RETURN protocolmappingheader%ROWTYPE;

   PROCEDURE p_write (
      p_ptv_id                 IN     protocolmappingheader.pmh_ptv_id%TYPE,
      p_cvl_id_midathditem     IN     protocolmappingheader.pmh_cvl_id_midathditem%TYPE,
      p_cellrowvalue           IN     protocolmappingheader.pmh_cellrowvalue%TYPE,
      p_cellcolumnvalue        IN     protocolmappingheader.pmh_cellcolumnvalue%TYPE,
      p_fieldnameto            IN     protocolmappingheader.pmh_fieldnameto%TYPE,
      p_cvl_code_midahdtitem   IN     protocolmappingheader.pmh_cvl_code_midathditem%TYPE,
      p_cvl_id_datatype        IN     protocolmappingheader.pmh_cvl_id_datatype%TYPE,
      p_isnotnull              IN     protocolmappingheader.pmh_isnotnull%TYPE,
      p_isnotnullgroup         IN     protocolmappingheader.pmh_isnotnullgroup%TYPE,
      p_id                        OUT protocolmappingheader.pmh_id%TYPE);
END pkg_protocolmappingheader;
/

