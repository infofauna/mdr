create trigger TR_BIF_IMPORTPROTOCOLLOGPARAM
    before insert
    on IMPORTPROTOCOLLOGPARAM
    for each row
DECLARE
BEGIN
   IF :new.ipr_id IS NULL
   THEN
      :new.ipr_id := seq_IMPORTPROTOCOLLOG.NEXTVAL;
   END IF;

   :new.ipr_credate := SYSDATE;
   :new.ipr_creuser := USER;
END tr_bif_IMPORTPROTOCOLLOGPARAM;

/

