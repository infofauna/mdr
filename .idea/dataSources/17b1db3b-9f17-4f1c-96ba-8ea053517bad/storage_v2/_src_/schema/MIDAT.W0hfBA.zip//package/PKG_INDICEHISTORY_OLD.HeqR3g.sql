create PACKAGE       pkg_indicehistory_old
AS
   /******************************************************************************
      NAME:       PKG_INDICEHISTORY
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        06.10.2017      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getrecord (p_ihy_id indicehistory.ihy_id%TYPE)
      RETURN indicehistory%ROWTYPE;

   FUNCTION f_getrecordbysph_ivr_id (
      p_sph_id    indicehistory.ihy_sph_id%TYPE,
      p_ivr_id    indicehistory.ihy_ivr_id%TYPE)
      RETURN indicehistory%ROWTYPE;

   PROCEDURE p_write (p_sph_id   IN     indicehistory.ihy_sph_id%TYPE,
                      p_ivr_id   IN     indicehistory.ihy_ivr_id%TYPE,
                      p_value    IN     indicehistory.ihy_value%TYPE,
                      p_ihy_id      OUT indicehistory.ihy_id%TYPE);

   PROCEDURE p_update (p_sph_id   IN indicehistory.ihy_sph_id%TYPE,
                       p_ivr_id   IN indicehistory.ihy_ivr_id%TYPE,
                       p_value    IN indicehistory.ihy_value%TYPE);

   PROCEDURE p_insert_or_update (
      p_sph_id   IN     indicehistory.ihy_sph_id%TYPE,
      p_ivr_id   IN     indicehistory.ihy_ivr_id%TYPE,
      p_value    IN     indicehistory.ihy_value%TYPE,
      p_ihy_id      OUT indicehistory.ihy_id%TYPE);

   PROCEDURE p_delete (p_ivr_id indicehistory.ihy_ivr_id%TYPE);

   PROCEDURE p_deleteby_ihy_sph_id (p_sph_id indicehistory.ihy_sph_id%TYPE);

   PROCEDURE p_buildhistory (p_midatindice IN codevalue.cvl_code%TYPE);
END pkg_indicehistory_old;
/

