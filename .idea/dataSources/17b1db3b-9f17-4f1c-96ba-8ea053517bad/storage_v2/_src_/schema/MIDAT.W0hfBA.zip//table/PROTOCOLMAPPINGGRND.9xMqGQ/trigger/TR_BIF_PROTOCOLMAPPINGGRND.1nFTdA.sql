create trigger TR_BIF_PROTOCOLMAPPINGGRND
    before insert
    on PROTOCOLMAPPINGGRND
    for each row
DECLARE
BEGIN
   IF :new.PMR_id IS NULL
   THEN
      :new.PMR_id := seq_PROTOCOLMAPPINGGRND.NEXTVAL;
   END IF;

   :new.PMR_credate := SYSDATE;
   :new.PMR_creuser := USER;
END tr_bif_PROTOCOLMAPPINGGRND;

/

