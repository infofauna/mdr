create PACKAGE BODY       pkg_managejob
AS
   /******************************************************************************
      NAME:       PKG_MANAGEJOB
      PURPOSE:    Planification des jobs

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        26.02.2014 F.Burri          1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (40)
                                    := 'Version 1.0., février 2014' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_purgejob
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DBMS_STATS.gather_schema_stats ('MIDAT');
 --     RETURN;                                                      -- Déactivé
      pkg_importprotocolheader.p_purge;
      pkg_worksheetlist.p_purge;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_createpurgejob
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      pkg_job.p_createprogram (
         'PGM_PURGE',
         'PKG_MANAGEJOB.p_purgejob',
         ' Purge les entrées non valides et obsolètes');
      pkg_job.p_createschedule (
         'SCH_PURGE',
         ' FREQ=DAILY;BYHOUR=6,7,8,9,10,11,12,13,14,15,16,17,18,19,20;BYMINUTE=0;BYSECOND=0',
         'Tous les jours entre 6 et 20 heures');
      pkg_job.p_schedulejob ('JOB_PURGE',
                             'SCH_PURGE',
                             'PGM_PURGE',
                             'Purge les entrées non valides et obsolète');
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_droppurgejob
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      pkg_job.p_dropjob ('JOB_PURGE');
      pkg_job.p_dropschedule ('SCH_PURGE');
      pkg_job.p_dropprogram ('PGM_PURGE');
   END;
END pkg_managejob;
/

