create trigger TR_BUF_WK_LOADSPEARDATACSCF
    before update
    on WK_LOADSPEARDATACSCF
    for each row
DECLARE
BEGIN
   :new.wlf_moddate := SYSDATE;
   :new.wlf_moduser := USER;
END tr_buf_wk_loadspeardatacscf;

/

