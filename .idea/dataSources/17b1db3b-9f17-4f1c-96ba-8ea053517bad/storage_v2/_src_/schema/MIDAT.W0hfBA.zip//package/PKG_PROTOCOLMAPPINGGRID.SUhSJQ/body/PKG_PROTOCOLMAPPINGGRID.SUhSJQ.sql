create PACKAGE BODY       pkg_protocolmappinggrid
AS
   /******************************************************************************
      NAME:       PKG_PROTOCOLMAPPINGGRID
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;


   /*-------------------------------------------------------------*/
   FUNCTION f_getrecord (p_pmg_id IN protocolmappinggrid.pmg_id%TYPE)
      RETURN protocolmappinggrid%ROWTYPE
   /*-------------------------------------------------------------*/
   IS
      l_record   protocolmappinggrid%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM protocolmappinggrid
       WHERE pmg_id = p_pmg_id;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-------------------------------------------------------------------------------*/
   PROCEDURE p_write (
      p_ptv_id                  IN     protocolmappinggrid.pmg_ptv_id%TYPE,
      p_cvl_id_midatitgrdro     IN     protocolmappinggrid.pmg_cvl_id_midatitgrdro%TYPE,
      p_cvl_id_midatitgrdcl     IN     protocolmappinggrid.pmg_cvl_id_midatitgrdcl%TYPE,
      p_cvl_id_midatitgrdce     IN     protocolmappinggrid.pmg_cvl_id_midatitgrdce%TYPE,
      p_cellrowvalue            IN     protocolmappinggrid.pmg_cellrowvalue%TYPE,
      p_cellcolumnvalue         IN     protocolmappinggrid.pmg_cellcolumnvalue%TYPE,
      p_cvl_code_midatitgrdro   IN     protocolmappinggrid.pmg_cvl_code_midatitgrdro%TYPE,
      p_cvl_code_midatitgrdcl   IN     protocolmappinggrid.pmg_cvl_code_midatitgrdcl%TYPE,
      p_cvl_code_midatitgrdce   IN     protocolmappinggrid.pmg_cvl_code_midatitgrdce%TYPE,
      p_id                         OUT protocolmappinggrid.pmg_id%TYPE)
   IS
   BEGIN
      p_id := seq_protocolmappinggrid.NEXTVAL;

      INSERT INTO protocolmappinggrid (pmg_id,
                                       pmg_ptv_id,
                                       pmg_cvl_id_midatitgrdro,
                                       pmg_cvl_id_midatitgrdcl,
                                       pmg_cvl_id_midatitgrdce,
                                       pmg_cellrowvalue,
                                       pmg_cellcolumnvalue,
                                       pmg_cvl_code_midatitgrdro,
                                       pmg_cvl_code_midatitgrdcl,
                                       pmg_cvl_code_midatitgrdce)
           VALUES (p_id,
                   p_ptv_id,
                   p_cvl_id_midatitgrdro,
                   p_cvl_id_midatitgrdcl,
                   p_cvl_id_midatitgrdce,
                   p_cellrowvalue,
                   p_cellcolumnvalue,
                   p_cvl_code_midatitgrdro,
                   p_cvl_code_midatitgrdcl,
                   p_cvl_code_midatitgrdce);
   END;

   /*-------------------------------------------------------------------------------*/
   PROCEDURE p_update (
      p_id                      IN protocolmappinggrid.pmg_id%TYPE,
      p_ptv_id                  IN protocolmappinggrid.pmg_ptv_id%TYPE,
      p_cvl_id_midatitgrdro     IN protocolmappinggrid.pmg_cvl_id_midatitgrdro%TYPE,
      p_cvl_id_midatitgrdcl     IN protocolmappinggrid.pmg_cvl_id_midatitgrdcl%TYPE,
      p_cvl_id_midatitgrdce     IN protocolmappinggrid.pmg_cvl_id_midatitgrdce%TYPE,
      p_cellrowvalue            IN protocolmappinggrid.pmg_cellrowvalue%TYPE,
      p_cellcolumnvalue         IN protocolmappinggrid.pmg_cellcolumnvalue%TYPE,
      p_cvl_code_midatitgrdro   IN protocolmappinggrid.pmg_cvl_code_midatitgrdro%TYPE,
      p_cvl_code_midatitgrdcl   IN protocolmappinggrid.pmg_cvl_code_midatitgrdcl%TYPE,
      p_cvl_code_midatitgrdce   IN protocolmappinggrid.pmg_cvl_code_midatitgrdce%TYPE)
   /*-------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE protocolmappinggrid
         SET pmg_ptv_id = p_ptv_id,
             pmg_cvl_id_midatitgrdro = p_cvl_id_midatitgrdro,
             pmg_cvl_id_midatitgrdcl = p_cvl_id_midatitgrdcl,
             pmg_cvl_id_midatitgrdce = p_cvl_id_midatitgrdce,
             pmg_cellrowvalue = p_cellrowvalue,
             pmg_cellcolumnvalue = p_cellcolumnvalue,
             pmg_cvl_code_midatitgrdro = p_cvl_code_midatitgrdro,
             pmg_cvl_code_midatitgrdcl = p_cvl_code_midatitgrdcl,
             pmg_cvl_code_midatitgrdce = p_cvl_code_midatitgrdce
       WHERE pmg_id = p_id;
   END;

   /*-------------------------------------------------------------------------------*/
   PROCEDURE p_update (p_protocolmapping IN protocolmappinggrid%ROWTYPE)
   /*-------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE protocolmappinggrid
         SET pmg_ptv_id = p_protocolmapping.pmg_ptv_id,
             pmg_cvl_id_midatitgrdro =
                p_protocolmapping.pmg_cvl_id_midatitgrdro,
             pmg_cvl_id_midatitgrdcl =
                p_protocolmapping.pmg_cvl_id_midatitgrdcl,
             pmg_cvl_id_midatitgrdce =
                p_protocolmapping.pmg_cvl_id_midatitgrdce,
             pmg_cellrowvalue = p_protocolmapping.pmg_cellrowvalue,
             pmg_cellcolumnvalue = p_protocolmapping.pmg_cellcolumnvalue,
             pmg_cvl_code_midatitgrdro =
                p_protocolmapping.pmg_cvl_code_midatitgrdro,
             pmg_cvl_code_midatitgrdcl =
                p_protocolmapping.pmg_cvl_code_midatitgrdcl,
             pmg_cvl_code_midatitgrdce =
                p_protocolmapping.pmg_cvl_code_midatitgrdce
       WHERE pmg_id = p_protocolmapping.pmg_id;
   END;


   /*---------------------------------------------------------------------------*/
   FUNCTION f_getrecordbyitemrocol (
      p_ptv_id                IN protocolmappinggrid.pmg_ptv_id%TYPE,
      p_cvl_id_midatitgrdro   IN protocolmappinggrid.pmg_cvl_id_midatitgrdro%TYPE,
      p_cvl_id_midatitgrdcl   IN protocolmappinggrid.pmg_cvl_id_midatitgrdcl%TYPE)
      RETURN protocolmappinggrid%ROWTYPE
   /*---------------------------------------------------------------------------*/
   IS
      l_record   protocolmappinggrid%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM protocolmappinggrid
       WHERE     pmg_ptv_id = p_ptv_id
             AND pmg_cvl_id_midatitgrdro = p_cvl_id_midatitgrdro
             AND pmg_cvl_id_midatitgrdcl = p_cvl_id_midatitgrdcl;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*---------------------------------------------------------------------------*/
   FUNCTION f_getrecordbyitemcell (
      p_ptv_id                IN protocolmappinggrid.pmg_ptv_id%TYPE,
      p_cvl_id_midatitgrdce   IN protocolmappinggrid.pmg_cvl_id_midatitgrdce%TYPE)
      RETURN protocolmappinggrid%ROWTYPE
   /*---------------------------------------------------------------------------*/
   IS
      l_record   protocolmappinggrid%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_record
        FROM protocolmappinggrid
       WHERE     pmg_ptv_id = p_ptv_id
             AND pmg_cvl_id_midatitgrdce = p_cvl_id_midatitgrdce;

      RETURN l_record;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;
END;
/

