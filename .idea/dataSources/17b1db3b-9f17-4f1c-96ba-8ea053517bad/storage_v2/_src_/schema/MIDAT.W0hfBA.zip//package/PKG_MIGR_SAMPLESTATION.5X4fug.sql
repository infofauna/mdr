create PACKAGE pkg_migr_samplestation
AS
   /******************************************************************************
      NAME:       PKG_MIGR_SAMPLESTATION
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        07.06.2018      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_externalise_z;         -- 1) Pour externaliser la coordonnéee Z

   PROCEDURE p_clear_sdo_point_z; -- 2) Pour supprimer la coordonnéee Z de l'objet SDO_GEOMETRY

   PROCEDURE p_restore_sdo_point_z; -- A utiliser uniquement pour remettre en 3D

   PROCEDURE p_save_sdo_point_z;
END pkg_migr_samplestation;
/

