create PACKAGE BODY       pkg_migr_ibch2019_ipl
AS
    /******************************************************************************
       NAME:       pkg_migr_ibch2019_IPL
       PURPOSE:    Modification dans la table IMPORTPROTOCOLLABO

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       15.05.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-------------------------------------------------------------------*/
    PROCEDURE p_deletebyptv_id (p_ptv_id IN importprotocolheader.iph_ptv_id%TYPE)
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM importprotocollabo
              WHERE ipl_iph_id IN (SELECT iph_id
                                     FROM importprotocolheader
                                    WHERE iph_ptv_id = p_ptv_id);
    END;
END pkg_migr_ibch2019_ipl;
/

