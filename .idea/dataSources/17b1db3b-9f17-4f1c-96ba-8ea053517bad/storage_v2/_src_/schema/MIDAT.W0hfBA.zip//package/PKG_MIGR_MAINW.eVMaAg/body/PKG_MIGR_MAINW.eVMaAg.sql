create PACKAGE BODY       pkg_migr_mainw
AS
   /******************************************************************************
      NAME:       PKG_MIGR_MAINW
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.08.2015      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, août  2014';

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_clearalldata
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      pkg_migr_main.p_clearalldata;
      COMMIT;
   END;
END pkg_migr_mainw;
/

