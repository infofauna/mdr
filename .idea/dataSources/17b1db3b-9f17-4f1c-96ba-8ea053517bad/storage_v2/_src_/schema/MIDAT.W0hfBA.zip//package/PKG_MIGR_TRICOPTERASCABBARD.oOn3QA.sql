create PACKAGE       pkg_migr_tricopterascabbard
AS
   /******************************************************************************
      NAME:       pkg_MIGR_tricopterascabbard
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        13.03.2015     burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_load;
END pkg_migr_tricopterascabbard;
/

