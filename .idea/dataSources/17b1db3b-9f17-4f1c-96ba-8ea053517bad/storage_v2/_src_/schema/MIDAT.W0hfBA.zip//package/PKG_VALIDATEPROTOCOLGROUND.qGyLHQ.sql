create PACKAGE       pkg_validateprotocolground
AS
   /******************************************************************************
      NAME:       PKG_VALIDATEPROTOCOLGROUND
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
      1.1        13.10.2017      burrif       2. Modification règle 
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_testpresencecause;

   PROCEDURE p_test;

   PROCEDURE p_test1;

   PROCEDURE p_validatedetail (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus              OUT NUMBER);
END pkg_validateprotocolground;
/

