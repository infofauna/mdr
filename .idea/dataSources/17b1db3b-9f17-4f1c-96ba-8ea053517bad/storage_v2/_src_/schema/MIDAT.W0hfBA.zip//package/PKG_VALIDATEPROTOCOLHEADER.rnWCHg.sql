create PACKAGE       pkg_validateprotocolheader
AS
   /******************************************************************************
      NAME:       PKG_VALIDATEPROTOCOLHEADER
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        08.10.2013      burrif       1. Created this package.
      1.1        16.03.2017      burrif       2. Règles de proximité
      1.2        21.01.2018      burrif       3. Nouvelle règles de gestion des droits
      1.3        11.09.2020      burrif       4. Externalisation Java
   ******************************************************************************/

   cst_elevationtolerance   CONSTANT NUMBER := 10;                -- 10 mètres

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_validatemain (
      p_iph_id         IN     importprotocolheader.iph_id%TYPE,
      p_usr_id         IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus      OUT NUMBER);
END pkg_validateprotocolheader;
/

