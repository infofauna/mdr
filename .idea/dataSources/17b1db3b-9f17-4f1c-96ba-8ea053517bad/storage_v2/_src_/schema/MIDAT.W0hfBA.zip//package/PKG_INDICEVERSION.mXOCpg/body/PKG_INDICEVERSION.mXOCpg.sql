create PACKAGE BODY       pkg_indiceversion
AS
    /******************************************************************************
       NAME:       pkg_INDICEVERSION
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        05.10.2017      burrif       1. Created this package.
    ******************************************************************************/


    cst_spear_version_2017        CONSTANT indiceversion.ivr_version%TYPE
                                               := 'SPEAR 2017' ;
    cst_spear_version_2014        CONSTANT indiceversion.ivr_version%TYPE
                                               := 'SPEAR 2014' ;
    cst_ibch_version_2010         CONSTANT indiceversion.ivr_version%TYPE
                                               := 'IBCH 2010' ;
    cst_makroindex_version_2008   CONSTANT indiceversion.ivr_version%TYPE
                                               := 'MOKROINDEX 2005' ;

    cst_packageversion            CONSTANT VARCHAR2 (30)
        := 'Version 2.0, octobre  2017' ;



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;


    /*---------------------------------------------------------------*/
    FUNCTION f_getrecord (p_ivr_id IN indiceversion.ivr_id%TYPE)
        RETURN indiceversion%ROWTYPE
    /*----------------------------------------------------------------*/
    IS
        l_recindiceversion   indiceversion%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recindiceversion
          FROM indiceversion
         WHERE ivr_id = p_ivr_id;

        RETURN l_recindiceversion;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getrecordbyversion (
        p_ivr_version   IN indiceversion.ivr_version%TYPE,
        p_midatindice   IN codevalue.cvl_code%TYPE)
        RETURN indiceversion%ROWTYPE
    /*----------------------------------------------------------------*/
    IS
        l_recindiceversion   indiceversion%ROWTYPE;
    BEGIN
        SELECT indiceversion.*
          INTO l_recindiceversion
          FROM indiceversion
               INNER JOIN codevalue ON cvl_id = ivr_cvl_id_midatindice
         WHERE     TRIM (UPPER (ivr_version)) = TRIM (UPPER (p_ivr_version))
               AND TRIM (UPPER (cvl_code)) = TRIM (UPPER (p_midatindice));

        RETURN l_recindiceversion;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;


    /*-----------------------------------------------------------------*/
    FUNCTION f_getcurrentversion (p_midatindice IN codevalue.cvl_code%TYPE)
        RETURN indiceversion%ROWTYPE
    /*------------------------------------------------------------------*/
    IS
        l_reclanguage          language%ROWTYPE;
        l_reccodedesignation   codedesignation%ROWTYPE;
        l_recindiceversion     indiceversion%ROWTYPE;
    BEGIN
        SELECT indiceversion.*
          INTO l_recindiceversion
          FROM indiceversion
               INNER JOIN codevalue ON cvl_id = ivr_cvl_id_midatindice
               INNER JOIN codereference ON crf_id = cvl_crf_id
         WHERE     cvl_code = p_midatindice
               AND ivr_current = pkg_constante.cst_yes
               AND crf_code = pkg_codereference.cst_crf_midatindice;



        RETURN l_recindiceversion;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;



            NULL;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_getpreviousversion (
        p_recindiceversion   IN indiceversion%ROWTYPE)
        RETURN indiceversion%ROWTYPE
    /*------------------------------------------------------------------*/
    IS
        l_reclanguage          language%ROWTYPE;
        l_reccodedesignation   codedesignation%ROWTYPE;
        l_recindiceversion     indiceversion%ROWTYPE;
    BEGIN
        SELECT indiceversion.*
          INTO l_recindiceversion
          FROM indiceversion
         WHERE     p_recindiceversion.ivr_cvl_id_midatindice =
                   ivr_cvl_id_midatindice
               AND ivr_ivr_id = p_recindiceversion.ivr_id;



        RETURN l_recindiceversion;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;



            NULL;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_write (
        p_current              IN     indiceversion.ivr_current%TYPE,
        p_cvl_id_midatindice   IN     indiceversion.ivr_cvl_id_midatindice%TYPE,
        p_ptv_id               IN     indiceversion.ivr_ptv_id%TYPE,
        p_version              IN     indiceversion.ivr_version%TYPE,
        p_designation          IN     indiceversion.ivr_designation%TYPE,
        p_id                      OUT indiceversion.ivr_id%TYPE)
    /*-------------------------------------------------------------------*/
    IS
        l_reccodevalue   codevalue%ROWTYPE;
    BEGIN
        l_reccodevalue := pkg_codevalue.f_getrecord (p_cvl_id_midatindice);


        IF l_reccodevalue.cvl_code = pkg_codevalue.cst_midatindice_spear
        THEN
            SELECT seq_spearversion.NEXTVAL INTO p_id FROM DUAL;
        ELSIF l_reccodevalue.cvl_code = pkg_codevalue.cst_midatindice_ibch
        THEN
            SELECT seq_ibchversion.NEXTVAL INTO p_id FROM DUAL;
        ELSIF l_reccodevalue.cvl_code =
              pkg_codevalue.cst_midatindice_makroindex
        THEN
            SELECT seq_makroindexversion.NEXTVAL INTO p_id FROM DUAL;
        END IF;


        INSERT INTO indiceversion (ivr_id,
                                   ivr_current,
                                   ivr_cvl_id_midatindice,
                                   ivr_ptv_id,
                                   ivr_version,
                                   ivr_designation)
             VALUES (p_id,
                     p_current,
                     p_cvl_id_midatindice,
                     p_ptv_id,
                     p_version,
                     p_designation);

        NULL;
    END;
END pkg_indiceversion;
/

