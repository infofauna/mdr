create trigger TR_BIF_MKIIDENTIFYGROUPCOUNTER
    before insert
    on MKIIDENTIFYGROUPCOUNTER
    for each row
DECLARE
BEGIN
   IF :new.mig_id IS NULL
   THEN
      :new.mig_id := seq_mkiidentifygroupcounter.NEXTVAL;
   END IF;

   :new.mig_credate := SYSDATE;
   :new.mig_creuser := USER;
END tr_bif_mkiidentifygroupcounter;

/

