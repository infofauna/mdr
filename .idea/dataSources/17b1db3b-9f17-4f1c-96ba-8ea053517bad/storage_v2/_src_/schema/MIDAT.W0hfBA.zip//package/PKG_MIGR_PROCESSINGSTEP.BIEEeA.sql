create PACKAGE       pkg_migr_processingstep
AS
   /******************************************************************************
      NAME:       PKG_MIGR_PROCESSINGSTEP
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10/11/2013      burrif       1. Created this package.
   ******************************************************************************/

   TYPE t_cursor IS REF CURSOR;



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_loadstep;
END pkg_migr_processingstep;
/

