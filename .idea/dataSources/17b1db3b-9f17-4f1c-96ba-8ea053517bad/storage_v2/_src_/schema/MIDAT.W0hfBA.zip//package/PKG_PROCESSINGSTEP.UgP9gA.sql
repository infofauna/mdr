create PACKAGE       pkg_processingstep
AS
   /******************************************************************************
      NAME:       PKG_PROCESSINGSTEP
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_stepcodereadvalidateheader   CONSTANT processingstep.psi_stepcode%TYPE
                                                := 'READANDVALID' ;
   cst_stepcodeloaddata             CONSTANT processingstep.psi_stepcode%TYPE
                                                := 'LOADDATA' ;
   cst_checkrequiredfield           CONSTANT processingstep.psi_stepcode%TYPE
                                                := 'CHECKREQFLD' ;
   cst_checkrequiredgrpfield        CONSTANT processingstep.psi_stepcode%TYPE
                                                := 'CHECKREQGRP' ;
   cst_buildheader                  CONSTANT processingstep.psi_stepcode%TYPE
                                                := 'BUILDHEADER' ;
   cst_consolidateheader            CONSTANT processingstep.psi_stepcode%TYPE
                                                := 'CONSHEADER' ;
   cst_validateheader               CONSTANT processingstep.psi_stepcode%TYPE
                                                := 'VALIDHEADER' ;

   cst_validatedetail               CONSTANT processingstep.psi_stepcode%TYPE
                                                := 'VALIDDETAIL' ;
   cst_buildvalidatestation         CONSTANT processingstep.psi_stepcode%TYPE
                                                := 'BUILDSTATION' ;
   cst_computeindice                CONSTANT processingstep.psi_stepcode%TYPE
                                                := 'COMPUTEINDIC' ;

   cst_loadingdone                  CONSTANT processingstep.psi_stepcode%TYPE
                                                := 'LOADINGDONE' ;



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_test;

   PROCEDURE p_test1;

   PROCEDURE p_test2;

   PROCEDURE p_cleargbl;

   PROCEDURE p_clearlisttimestamp;

   PROCEDURE p_setblobsize (p_size IN NUMBER);

   PROCEDURE p_setrecordcount (p_count IN NUMBER);

   FUNCTION f_getrecordbystepcode (
      p_psi_stepcode   IN processingstep.psi_stepcode%TYPE)
      RETURN processingstep%ROWTYPE;

   FUNCTION f_getrecord (p_psi_id IN processingstep.psi_id%TYPE)
      RETURN processingstep%ROWTYPE;

   PROCEDURE p_write (p_sequence      IN processingstep.psi_sequence%TYPE,
                      p_stepcode      IN processingstep.psi_stepcode%TYPE,
                      p_comment       IN processingstep.psi_comment%TYPE,
                      p_errornumber   IN processingstep.psi_errornumber%TYPE,
                      p_percentdone   IN processingstep.psi_percentdone%TYPE);

   PROCEDURE p_computestatusbarmasterstep (
      p_step          IN     processingstep.psi_stepcode%TYPE,
      p_fulltime         OUT NUMBER,
      p_lefttime         OUT NUMBER,
      p_percentdone      OUT NUMBER);

   PROCEDURE p_computestatusdetailstep (
      p_currentstatusbarvalue   IN     NUMBER, -- Nombre d'enregistrement traité
      p_rowstotal               IN     NUMBER, -- Nombre d'enregistrement total
      p_fulltime                   OUT NUMBER,
      p_lefttime                   OUT NUMBER,
      p_percentdone                OUT NUMBER);
END pkg_processingstep;
/

