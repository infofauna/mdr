create trigger TR_BUF_SAMPLEHEADERITEM
    before update
    on SAMPLEHEADERITEM
    for each row
DECLARE
   l_newrec   sampleheaderitem%ROWTYPE;
   l_oldrec   sampleheaderitem%ROWTYPE;
BEGIN
   l_oldrec.shm_id := :old.shm_id;
   l_oldrec.shm_status := :old.shm_status;
   l_oldrec.shm_sph_id := :old.shm_sph_id;
   l_oldrec.shm_cvl_id_midathditmty := :old.shm_cvl_id_midathditmty;
   l_oldrec.shm_item := :old.shm_item;
      l_oldrec.shm_per_id := :old.shm_per_id;
   l_oldrec.shm_credate := :old.shm_credate;
   l_oldrec.shm_creuser := :old.shm_creuser;
   l_oldrec.shm_moddate := :old.shm_moddate;
   l_oldrec.shm_moduser := :old.shm_moduser;


   l_newrec.shm_id := :new.shm_id;
   l_newrec.shm_status := :new.shm_status;
   l_newrec.shm_sph_id := :new.shm_sph_id;

   l_newrec.shm_cvl_id_midathditmty := :new.shm_cvl_id_midathditmty;
   l_newrec.shm_item := :new.shm_item;
      l_newrec.shm_per_id := :new.shm_per_id;
   l_newrec.shm_credate := :new.shm_credate;
   l_newrec.shm_creuser := :new.shm_creuser;
   l_newrec.shm_moddate := :new.shm_moddate;
   l_newrec.shm_moduser := :new.shm_moduser;

   --   pkg_SAMPLESTATION.p_tr_buf_SAMPLESTATION (l_oldrec, l_newrec);

   :new.shm_id := l_newrec.shm_id;

   :new.shm_sph_id := l_newrec.shm_sph_id;

   :new.shm_cvl_id_midathditmty := l_newrec.shm_cvl_id_midathditmty;
   :new.shm_item := l_newrec.shm_item;
   :new.shm_per_id := l_newrec.shm_per_id;
   :new.shm_credate := l_newrec.shm_credate;
   :new.shm_creuser := l_newrec.shm_creuser;
   :new.shm_moddate := l_newrec.shm_moddate;
   :new.shm_moduser := l_newrec.shm_moduser;
END;

/

