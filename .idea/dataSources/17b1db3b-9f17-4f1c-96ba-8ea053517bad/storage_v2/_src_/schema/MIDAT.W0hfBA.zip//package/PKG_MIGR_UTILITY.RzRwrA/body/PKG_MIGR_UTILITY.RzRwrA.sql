create PACKAGE BODY       pkg_migr_utility
AS
   /******************************************************************************
      NAME:       PKG_MIGR_UTILITY
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10/11/2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, novembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*------------------------------------------------------------------*/
   FUNCTION f_checkindex (p_index_name IN user_indexes.index_name%TYPE)
      RETURN user_indexes.table_name%TYPE
   /*------------------------------------------------------------------*/
   IS
      l_table_name   user_indexes.table_name%TYPE;
   BEGIN
      SELECT table_name
        INTO l_table_name
        FROM user_indexes
       WHERE index_name = UPPER (p_index_name);

      RETURN l_table_name;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*------------------------------------------------------------------*/
   PROCEDURE p_drop_index (p_index_name IN VARCHAR2)
   /*------------------------------------------------------------------*/
   IS
      l_table_name   user_indexes.table_name%TYPE;
      l_sql          VARCHAR2 (1096);
   BEGIN
      l_table_name := f_checkindex (substr(p_index_name,1,30));

      IF NOT l_table_name IS NULL
      THEN
         l_sql := ' DROP INDEX ' || substr(p_index_name,1,30);

         EXECUTE IMMEDIATE l_sql;
      END IF;
   END;

   /*-----------------------------------------------------------------------*/
   PROCEDURE p_create_index (p_column_name   IN VARCHAR2,
                             p_table_name       user_indexes.table_name%TYPE,
                             p_bitmap        IN BOOLEAN)
   /*----------------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (4096);
   BEGIN
      IF p_bitmap
      THEN
         l_sql := 'CREATE BITMAP INDEX ';
      ELSE
         l_sql := 'CREATE INDEX ';
      END IF;

      l_sql :=
            l_sql
         || SUBSTR ('IDX_' || p_column_name, 1, 30)
         || ' ON '
         || p_table_name
         || '('
         || p_column_name
         || ')'
         || ' LOGGING '
         || 'TABLESPACE MIDAT_INDEX STORAGE    (
            BUFFER_POOL      DEFAULT
            FLASH_CACHE      DEFAULT
            CELL_FLASH_CACHE DEFAULT
           )
         NOPARALLEL ';
      DBMS_OUTPUT.put_line (l_sql);

      EXECUTE IMMEDIATE l_sql;
   END;


   /*------------------------------------------------------------------*/
   FUNCTION f_checkconstraint (
      p_constraint_name IN user_constraints.constraint_name%TYPE)
      RETURN user_constraints.constraint_type%TYPE
   /*------------------------------------------------------------------*/
   IS
      l_constraint_type   user_constraints.constraint_type%TYPE;
   BEGIN
      SELECT constraint_type
        INTO l_constraint_type
        FROM user_constraints
       WHERE UPPER (p_constraint_name) = UPPER (constraint_name);

      RETURN l_constraint_type;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*-----------------------------------------------------------------------------*/
   PROCEDURE p_drop_constraint (
      p_table_name        IN user_constraints.table_name%TYPE,
      p_constraint_name   IN user_constraints.constraint_name%TYPE)
   /*------------------------------------------------------------------------------*/
   IS
      l_sql               VARCHAR2 (1024);
      l_constraint_type   user_constraints.constraint_type%TYPE;
   BEGIN
      l_constraint_type := f_checkconstraint (p_constraint_name);

      IF NOT l_constraint_type IS NULL
      THEN
         l_sql :=
               ' ALTER TABLE '
            || p_table_name
            || ' DROP CONSTRAINT '
            || p_constraint_name;
         DBMS_OUTPUT.put_line (l_sql);

         EXECUTE IMMEDIATE l_sql;
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_drop_constraint_one_table (
      p_table_name        IN user_constraints.table_name%TYPE,
      p_constraint_type      user_constraints.constraint_type%TYPE)
   /*---------------------------------------------------------------*/
   IS
      CURSOR l_list_constraint
      IS
         SELECT *
           FROM user_constraints
          WHERE     constraint_type = p_constraint_type
                AND table_name = p_table_name;

      l_rec_list_constraint   l_list_constraint%ROWTYPE;
   BEGIN
      OPEN l_list_constraint;

      LOOP
         FETCH l_list_constraint INTO l_rec_list_constraint;

         EXIT WHEN l_list_constraint%NOTFOUND;
         DBMS_OUTPUT.put_line (
               'table_name='
            || l_rec_list_constraint.table_name
            || ' constraint_name='
            || l_rec_list_constraint.constraint_name);
         p_drop_constraint (l_rec_list_constraint.table_name,
                            l_rec_list_constraint.constraint_name);
      END LOOP;

      CLOSE l_list_constraint;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_create_fk (p_table_name        IN VARCHAR2,
                          p_column_name       IN VARCHAR2,
                          p_ref_table_name    IN VARCHAR2,
                          p_ref_column_name   IN VARCHAR2)
   /*---------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (1024);
   BEGIN
      l_sql :=
            'ALTER TABLE '
         || p_table_name
         || ' ADD CONSTRAINT FK_'
         || p_column_name
         || ' FOREIGN KEY ('
         || p_column_name
         || ') '
         || ' REFERENCES '
         || p_ref_table_name
         || ' ('
         || p_ref_column_name
         || ') '
         || ' ENABLE '
         || ' VALIDATE';
      DBMS_OUTPUT.put_line (l_sql);

      EXECUTE IMMEDIATE l_sql;
   END;



  

   /*---------------------------------------------------------------*/
   PROCEDURE p_clearalldata_old
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM sampleprotocollabo;

      DELETE FROM sampleprotocolgrid;

      DELETE FROM sampleprotocolgrnd;

      DELETE FROM sampleheaderfile;

      DELETE FROM sampleheaderitem;

      DELETE FROM sampledocument;

      DELETE FROM sampleheader;

      DELETE FROM samplestationitem;

      DELETE FROM samplestation;

      DELETE FROM sampleheadermassfile;

      DELETE FROM importmassstation;

      DELETE FROM importmassdatadetail;

      DELETE FROM importmassdataheader;

      DELETE FROM importmassmappingheader;

      DELETE FROM importprotocolgrid;

      DELETE FROM importprotocolgrnd;

      DELETE FROM importprotocollabo;

      DELETE FROM importprotocollogparam;

      DELETE FROM importprotocollog;

      DELETE FROM importprotocolheader;

      DELETE FROM debug;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_checksequence (p_name IN user_sequences.sequence_name%TYPE)
      RETURN BOOLEAN
   /*--------------------------------------------------------------*/
   IS
      l_name   user_sequences.sequence_name%TYPE;
   BEGIN
      SELECT sequence_name
        INTO l_name
        FROM user_sequences
       WHERE UPPER (TRIM (p_name)) = UPPER (sequence_name);

      RETURN TRUE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN FALSE;
   END;

   /*--------------------------------------------------------------------------*/
   FUNCTION f_returnlastid (p_table IN VARCHAR2, p_name_id VARCHAR2)
      RETURN NUMBER
   /*---------------------------------------------------------------------------*/
   IS
      l_sql      VARCHAR2 (1024);
      l_cursor   t_cursor;
      l_id       NUMBER;
   BEGIN
      l_sql := 'SELECT MAX(' || p_name_id || ') FROM ' || p_table;

      OPEN l_cursor FOR l_sql;

      FETCH l_cursor INTO l_id;

      CLOSE l_cursor;

      RETURN NVL (l_id, 0);
   END;


   /*--------------------------------------------------------------------------*/
   PROCEDURE p_createsequence (p_name        IN user_sequences.sequence_name%TYPE,
                               p_startwith   IN NUMBER,
                               p_maxvalue    IN NUMBER)
   /*--------------------------------------------------------------------------*/
   IS
      l_startwith   NUMBER;

      l_sql         VARCHAR2 (1024);
   BEGIN
      IF p_startwith IS NULL
      THEN
         l_startwith := 1;
      ELSE
         l_startwith := p_startwith;
      END IF;

      l_sql :=
            'CREATE SEQUENCE  '
         || p_name
         || ' START  WITH '
         || TO_CHAR (l_startwith);

      IF NOT p_maxvalue IS NULL
      THEN
         l_sql := l_sql || ' MAXVALUE ' || TO_CHAR (p_maxvalue);
      END IF;

      l_sql := l_sql || ' MINVALUE ' || TO_CHAR (l_startwith);

      DBMS_OUTPUT.put_line (l_sql);

      EXECUTE IMMEDIATE l_sql;
   END;

   /*-------------------------------------------------------------------------------*/
   PROCEDURE p_dropsequence (p_name IN user_sequences.sequence_name%TYPE)
   /*-------------------------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (1024);
   BEGIN
      l_sql := 'drop sequence ' || p_name;

      EXECUTE IMMEDIATE l_sql;
   END;

   /*--------------------------------------------------------------------------*/
   PROCEDURE p_recreatesequence (
      p_table_name   IN VARCHAR2,
      p_seq_name     IN user_sequences.sequence_name%TYPE,
      p_name_id      IN VARCHAR2)
   /*--------------------------------------------------------------------------*/
   IS
      l_last_id   NUMBER;
   BEGIN
      IF f_checksequence (p_seq_name)
      THEN
         l_last_id := f_returnlastid (p_table_name, p_name_id);
         p_dropsequence (p_seq_name);
         p_createsequence (p_seq_name, l_last_id + 1, NULL);
      END IF;
   END;
END pkg_migr_utility;
/

