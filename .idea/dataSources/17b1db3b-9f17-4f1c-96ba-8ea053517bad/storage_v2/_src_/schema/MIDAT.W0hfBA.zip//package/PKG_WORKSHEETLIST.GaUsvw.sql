create PACKAGE       pkg_worksheetlist
AS
   /******************************************************************************
      NAME:       PKG_WORKSHEETLIST
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   TYPE t_cursor IS REF CURSOR;

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_purge;

   FUNCTION f_getrecord (p_wsl_id IN worksheetlist.wsl_id%TYPE)
      RETURN worksheetlist%ROWTYPE;

   PROCEDURE p_insert (
      p_worksheetgroup_id   IN worksheetlist.wsl_worksheetgroup_id%TYPE,
      p_sheetname           IN worksheetlist.wsl_sheetname%TYPE,
      p_sheetnumber         IN worksheetlist.wsl_sheetnumber%TYPE);

   PROCEDURE p_listsheetname (
      p_worksheetgroup_id   IN     worksheetlist.wsl_worksheetgroup_id%TYPE,
      p_sheetlist              OUT t_cursor,
      p_sheetcount             OUT NUMBER);

   FUNCTION f_getnewworksheetgroupid
      RETURN NUMBER;
END pkg_worksheetlist;
/

