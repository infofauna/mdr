create PACKAGE       pkg_migr_indiceversion
AS
   /******************************************************************************
      NAME:       PKG_MIGR_INDICEVERSION
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        05.10.2017      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_buildspear;

   PROCEDURE p_buildibch;

   PROCEDURE p_buildmakroindex;
END pkg_migr_indiceversion;
/

