create PACKAGE BODY       pkg_validate
AS
    /******************************************************************************
       NAME:       PKG_VALIDATE
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        11.10.2013      burrif       1. Created this package.
       1.1        20.07.2017      burrif       2. Ajout des projets
       1.2        21.01.2019      burrif       3. Changement des droits
       1.3        20.01.2020      burrif       4. Mise à jour des champs statistique IBCH
       1.4        18.08.2020      burrif       5. externalisation du chargement java PKG_VALIDATE
    ******************************************************************************/



    cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.4, août  2020';



    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*---------------------------------------------------------------------------*/
    PROCEDURE p_test
    /*---------------------------------------------------------------------------*/
    IS
        p_iph_id         NUMBER;
        p_protocoltype   VARCHAR2 (10);
        l_size           NUMBER;
    BEGIN
        p_iph_id := 631;
        pkg_importprotocollog.p_purgebyiphid (p_iph_id);

        p_protocoltype := 'MASS';
        l_size := pkg_java.f_setmaxmemorysize (1024 * 1024 * 1024);
        pkg_java.p_enablenewspace (0);
        pkg_java.p_processinit (p_iph_id, p_protocoltype);
        COMMIT;
    END;


    /*--------------------------------------------------------------------------------*/
    PROCEDURE p_deleteby_pid_id (
        p_pid_id   IN importprotocolheader.iph_pid_id%TYPE)
    /*---------------------------------------------------------------------------------*/
    IS
        /* on purge ceux qui n'ont pas été sauvé */
        CURSOR l_cursor IS
            SELECT iph_id
              FROM importprotocolheader
             WHERE     iph_pid_id = p_pid_id
                   AND iph_id NOT IN (SELECT sph_iph_id FROM sampleheader);

        l_reccursor   l_cursor%ROWTYPE;
    BEGIN
        RETURN; -- Cette fonction est désactivés. La purge périodique la remplace

        OPEN l_cursor;

        LOOP
            FETCH l_cursor INTO l_reccursor;

            EXIT WHEN l_cursor%NOTFOUND;
            pkg_importprotocollog.p_purgebyiphid (l_reccursor.iph_id);
            pkg_importmassdatadetail.p_deletebyiph_id (l_reccursor.iph_id);
            pkg_importmassstation.p_deletebyiph_id (l_reccursor.iph_id);
            pkg_samplemkidetailgroup.p_deleteby_iph_id (l_reccursor.iph_id);
            pkg_importmassdataheader.p_deletebyiph_id (l_reccursor.iph_id);
        END LOOP;

        CLOSE l_cursor;
    END;



    /*--------------------------------------------------------------------------------*/
    PROCEDURE p_validatemass (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE,
        p_usr_id                 IN importprotocolheader.iph_usr_id_modify%TYPE,
        p_lan_id                 IN language.lan_id%TYPE)
    /*------------------------------------------------------------------------------*/
    IS
        l_returnstatusstructure       NUMBER;
        l_returnstatusloaded          NUMBER;
        l_returnstatusallheader       NUMBER;
        l_returnstatusalldetail       NUMBER;
        l_returnstatusmappingexist    NUMBER;
        l_returnstatusstation         NUMBER;
        l_returnstatuscheckstation    NUMBER;
        l_returnstatusallreadyexist   NUMBER;
        l_size                        NUMBER;
        l_timestamp                   TIMESTAMP;
        l_blobsize                    NUMBER;
        l_returnstatuscomputeincide   NUMBER;
        l_lan_id_auto                 importprotocolheader.iph_lan_id%TYPE;
    BEGIN
        l_timestamp := SYSTIMESTAMP;
        pkg_importmassdatadetail.p_cleargblcounter;
        p_deleteby_pid_id (p_importprotocolheader.iph_pid_id);


        l_blobsize := DBMS_LOB.getlength (p_importprotocolheader.iph_file);
        pkg_processingstep.p_setblobsize (l_blobsize);
        pkg_processingstatus.p_setstep (
            p_importprotocolheader.iph_pid_id,
            pkg_processingstep.cst_stepcodereadvalidateheader,
            p_lan_id,
            p_usr_id);
        pkg_importprotocollog.p_logstartsubprocess (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_midatstartidentifymassfld);

        -- On contrôle si le mapping existe
        pkg_validatemassheader.p_validatemapping (p_importprotocolheader,
                                                  p_lan_id,
                                                  l_returnstatusmappingexist);

        IF l_returnstatusmappingexist != pkg_constante.cst_returnstatusok
        THEN
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
            pkg_importprotocollog.p_logendsubprocess (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_unrecoverableerror,
                l_timestamp,
                NULL);
            RETURN;
        END IF;


        pkg_processingsteplog.p_setmeasuredata (
            l_blobsize,
            pkg_processingsteplog.cst_measureunitblobsize);


        pkg_validatemassheader.p_mastervalidate (
            p_importprotocolheader.iph_id);

        pkg_importprotocollog.p_returnvalidatestatus (
            p_importprotocolheader.iph_id,
            l_returnstatusstructure);
        DBMS_OUTPUT.put_line ('Status=' || l_returnstatusstructure);


        -- Si la structure n'est pas  correcte, il est inutile de continuer
        IF l_returnstatusstructure != pkg_constante.cst_returnstatusok
        THEN
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
            pkg_importprotocollog.p_logendsubprocess (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_unrecoverableerror,
                l_timestamp,
                NULL);

            -- Le fichier de masse contient peut-être des entêtes de colonne définies dans une autre langue que celle que vous avez indiqué dans le formulaire de chargement
            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_datalanguagemissmatch,
                NULL,
                TO_CHAR (p_importprotocolheader.iph_lan_id));
            NULL;


            RETURN;
        END IF;



        pkg_importprotocollog.p_logendsubprocess (
            p_importprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_midatendidentifymassfld,
            l_timestamp,
            NULL);

        -- Le step 2 se trouve dans la procédure ci-dessous
        pkg_validatemassdetail.p_validate (p_importprotocolheader,
                                           p_usr_id,
                                           p_lan_id,
                                           l_returnstatusloaded); /*Charge les données,
                                                                             Vérification que les champs obligatoires soient renseignées,
                                                                             Vérification que les groupes de champs obligatoires soient rensiegnées
                                                                             Structuration des Header
                                                                      */

        -- Si aucun header n'est conforme, alors on sort
        IF l_returnstatusloaded != pkg_constante.cst_returnstatusok
        THEN
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
            pkg_importprotocollog.p_logendsubprocess (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_unrecoverableerror,
                l_timestamp,
                NULL);


            RETURN;
        END IF;

        -- On vérifie que les header contruit à partir de la liste de détail soient cohérent
        pkg_processingstatus.p_setstep (
            p_importprotocolheader.iph_pid_id,
            pkg_processingstep.cst_validateheader,
            p_lan_id,
            p_usr_id);                                               -- Step 7
        pkg_validatemassheaderfield.p_valideallheader (
            p_importprotocolheader.iph_id,
            p_usr_id,
            p_lan_id,
            l_returnstatusallheader);

        -- Si aucun header n'est conforme, alors on sort
        IF l_returnstatusallheader != pkg_constante.cst_returnstatusok
        THEN
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
            pkg_importprotocollog.p_logendsubprocess (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_unrecoverableerror,
                l_timestamp,
                NULL);


            RETURN;
        END IF;

        pkg_processingstatus.p_setstep (
            p_importprotocolheader.iph_pid_id,
            pkg_processingstep.cst_validatedetail,
            p_lan_id,
            p_usr_id);                                               -- Step 8
        pkg_validatemassdetailfield.p_validealldetail (
            p_importprotocolheader.iph_id,
            p_usr_id,
            p_lan_id,
            l_returnstatusalldetail);

        IF l_returnstatusalldetail != pkg_constante.cst_returnstatusok
        THEN
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
            pkg_importprotocollog.p_logendsubprocess (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_unrecoverableerror,
                l_timestamp,
                NULL);


            RETURN;
        END IF;

        -- A ce niveau, tous les enregistrements de header qui n'ont pas d'erreur dans le détail reste en status valisstatuspending
        -- Il reste à les modifer en validstatusok
        pkg_importmassdataheader.p_updatevalidtatuspending (
            p_importprotocolheader,
            p_lan_id,
            p_usr_id);
        pkg_processingstatus.p_setstep (
            p_importprotocolheader.iph_pid_id,
            pkg_processingstep.cst_buildvalidatestation,
            p_lan_id,
            p_usr_id);                                               -- Step 9
        -- On construit la table importmassstation et on valide la cohérence des données
        pkg_validatemassstation.p_main (p_importprotocolheader.iph_id,
                                        p_usr_id,
                                        p_lan_id,
                                        l_returnstatusstation);

        IF l_returnstatusstation != pkg_constante.cst_returnstatusok
        THEN
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
            pkg_importprotocollog.p_logendsubprocess (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_unrecoverableerror,
                l_timestamp,
                NULL);


            RETURN;
        END IF;

        pkg_importmassstation.p_checkifstationallreadeyexist (
            p_importprotocolheader.iph_id,
            p_usr_id,
            p_lan_id,
            l_returnstatuscheckstation);

        IF l_returnstatuscheckstation != pkg_constante.cst_returnstatusok
        THEN
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
            pkg_importprotocollog.p_logendsubprocess (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_unrecoverableerror,
                l_timestamp,
                NULL);


            RETURN;
        END IF;

        -- Finalement on vérifie si les données encore valide ne sont pas déjà enregistrées
        pkg_validatemassheader.p_checkheaderallreadyexist (
            p_importprotocolheader.iph_id,
            l_returnstatusallreadyexist);

        IF l_returnstatusallreadyexist != pkg_constante.cst_returnstatusok
        THEN
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
            pkg_importprotocollog.p_logendsubprocess (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_unrecoverableerror,
                l_timestamp,
                NULL);



            RETURN;
        END IF;


        pkg_debug.p_write ('pkg_validate.p_validatemass',
                           'p_calculateindiceforallheader start...');
        pkg_validatemassheader.p_calculateindiceforallheader (
            p_importprotocolheader,
            p_usr_id,
            p_lan_id,
            l_returnstatuscomputeincide);
        pkg_debug.p_write ('pkg_validate.p_validatemass',
                           'p_calculateindiceforallheader end...');
        pkg_processingstatus.p_setstep (p_importprotocolheader.iph_pid_id,
                                        pkg_processingstep.cst_loadingdone,
                                        p_lan_id,
                                        p_usr_id);                  -- Step 11
        pkg_importmassdataheader.p_logendstatistique (p_importprotocolheader);
    END;

    /*--------------------------------------------------------------------------------*/
    PROCEDURE p_validatelaboratory (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE,
        p_usr_id                 IN importprotocolheader.iph_usr_id_modify%TYPE)
    /*------------------------------------------------------------------------------*/
    IS
        l_returnstatusheader   NUMBER;
        l_returnstatusdetail   NUMBER;
    BEGIN
        l_returnstatusheader := pkg_constante.cst_returnstatusok;
        l_returnstatusdetail := pkg_constante.cst_returnstatusok;
        --   pkg_importprotocollabo.p_deletebyiphid (
        --       p_importprotocolheader.iph_id); -- Pour pouvoir refaire plusieurs fois

        pkg_validateprotocolheader.p_validatemain (
            p_importprotocolheader.iph_id,
            p_usr_id,
            l_returnstatusheader);

        IF l_returnstatusheader = pkg_constante.cst_returnstatusok
        THEN
            pkg_validateprotocollabo.p_validatedetail (
                p_importprotocolheader.iph_id,
                p_usr_id,
                l_returnstatusdetail);
        END IF;

        IF    l_returnstatusheader != pkg_constante.cst_returnstatusok
           OR l_returnstatusdetail != pkg_constante.cst_returnstatusok
        THEN
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
        ELSE
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusok,
                p_usr_id);
        END IF;
    END;


    /*--------------------------------------------------------------------------------*/
    PROCEDURE p_validategrid (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE,
        p_spm_id                 IN sampleheader.sph_id%TYPE,
        p_usr_id                 IN importprotocolheader.iph_usr_id_modify%TYPE)
    /*------------------------------------------------------------------------------*/
    IS
        l_returnstatusheader   NUMBER;
        l_returnstatusdetail   NUMBER;
    BEGIN
        l_returnstatusheader := pkg_constante.cst_returnstatusok;
        l_returnstatusdetail := pkg_constante.cst_returnstatusok;
        pkg_importprotocolgrid.p_deletebyiphid (
            p_importprotocolheader.iph_id);

        IF p_spm_id IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_laboratoryprotocolrequired,
                NULL,
                pkg_codevalue.cst_protocoltype_grdeval);
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
            RETURN;
        END IF;


        pkg_validateprotocolheader.p_validatemain (
            p_importprotocolheader.iph_id,
            p_usr_id,
            l_returnstatusheader);

        IF l_returnstatusheader = pkg_constante.cst_returnstatusok
        THEN
            pkg_validateprotocolgrid.p_validatedetail (
                p_importprotocolheader,
                p_usr_id,
                l_returnstatusdetail);
        END IF;

        IF    l_returnstatusheader != pkg_constante.cst_returnstatusok
           OR l_returnstatusdetail != pkg_constante.cst_returnstatusok
        THEN
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
        ELSE
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
        END IF;
    END;

    /*--------------------------------------------------------------------------------*/
    PROCEDURE p_validateground (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE,
        p_spm_id                 IN sampleheader.sph_id%TYPE,
        p_usr_id                 IN importprotocolheader.iph_usr_id_modify%TYPE)
    /*------------------------------------------------------------------------------*/
    IS
        l_returnstatusheader   NUMBER;
        l_returnstatusdetail   NUMBER;
    BEGIN
        l_returnstatusheader := pkg_constante.cst_returnstatusok;
        l_returnstatusdetail := pkg_constante.cst_returnstatusok;

        pkg_importprotocolgrnd.p_deletebyiphid (
            p_importprotocolheader.iph_id);

        IF p_spm_id IS NULL
        THEN
            pkg_importprotocollog.p_writelog (
                p_importprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_laboratoryprotocolrequired,
                NULL,
                pkg_codevalue.cst_protocoltype_ground);
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
            RETURN;
        END IF;


        pkg_validateprotocolheader.p_validatemain (
            p_importprotocolheader.iph_id,
            p_usr_id,
            l_returnstatusheader);

        IF l_returnstatusheader = pkg_constante.cst_returnstatusok
        THEN
            pkg_validateprotocolground.p_validatedetail (
                p_importprotocolheader,
                p_usr_id,
                l_returnstatusdetail);
        END IF;

        IF    l_returnstatusheader != pkg_constante.cst_returnstatusok
           OR l_returnstatusdetail != pkg_constante.cst_returnstatusok
        THEN
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusnotok,
                p_usr_id);
        ELSE
            pkg_importprotocolheader.p_updatevalidatestatus (
                p_importprotocolheader.iph_id,
                pkg_importprotocolheader.cst_validstatusok,
                p_usr_id);
        END IF;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_loadheaderandversion (
        p_iph_id                     IN     importprotocolheader.iph_id%TYPE,
        p_importprotocolheader          OUT importprotocolheader%ROWTYPE,
        p_reccodevalueprotocoltype      OUT codevalue%ROWTYPE,
        p_recprotocolversion            OUT protocolversion%ROWTYPE)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        p_importprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);

        IF p_importprotocolheader.iph_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_importprotocolheader.f_getrecord('
                || TO_CHAR (p_iph_id)
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;


        p_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                p_importprotocolheader.iph_ptv_id);

        IF p_recprotocolversion.ptv_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'PKG_PROTOCOLVERSION.f_getrecord('
                || TO_CHAR (p_importprotocolheader.iph_ptv_id)
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        p_reccodevalueprotocoltype :=
            pkg_codevalue.f_getrecord (
                p_recprotocolversion.ptv_cvl_id_protocoltype);

        IF p_reccodevalueprotocoltype.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'PKG_CODEVALUE.f_getrecord('
                || TO_CHAR (p_recprotocolversion.ptv_cvl_id_protocoltype)
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_logstatistiquelaboratory (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE)
    /*---------------------------------------------------------------*/
    IS
        l_counttaxondistinct   NUMBER;
        l_sumtaxon             NUMBER;
    BEGIN
        pkg_importprotocollabo.p_countentry (p_importprotocolheader.iph_id,
                                             l_counttaxondistinct,
                                             l_sumtaxon);
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_logstatistique (
        p_iph_id   IN importprotocolheader.iph_id%TYPE,
        p_usr_id   IN importprotocolheader.iph_usr_id_modify%TYPE)
    /*--------------------------------------------------------------*/
    IS
        l_importprotocolheader   importprotocolheader%ROWTYPE;
        l_reccodevalue           codevalue%ROWTYPE;
        l_recprotocolversion     protocolversion%ROWTYPE;
        l_counterror             NUMBER;
        l_countwarning           NUMBER;
        l_totalcounter           NUMBER;
        l_validcounter           NUMBER;
        l_invalidcounter         NUMBER;
        l_allreadyexistcounter   NUMBER;
        l_canbesaved             BOOLEAN := TRUE;
        l_countprotocoltype      NUMBER;
        l_listversion            VARCHAR2 (2048);
    BEGIN
        p_loadheaderandversion (p_iph_id,
                                l_importprotocolheader,
                                l_reccodevalue,
                                l_recprotocolversion);
        l_importprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id); -- On recharge le header pour disposer de toutes les informations

        IF l_importprotocolheader.iph_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_importprotocolheader.f_getrecord('
                || TO_CHAR (p_iph_id)
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        l_counterror :=
              pkg_importprotocollog.f_getcountseveritylevel (
                  p_iph_id,
                  pkg_message.cst_severity_level_fatal)
            + pkg_importprotocollog.f_getcountseveritylevel (
                  p_iph_id,
                  pkg_message.cst_severity_level_error);


        IF l_reccodevalue.cvl_code != pkg_codevalue.cst_protocoltype_mass
        THEN
            IF l_counterror > 0
            THEN
                l_countprotocoltype :=
                    pkg_protocolversion.f_countprotocoltype (
                        l_recprotocolversion.ptv_cvl_id_protocoltype);

                IF l_countprotocoltype > 1
                THEN
                    l_listversion :=
                        pkg_protocolversion.f_returnlistversion (
                            l_recprotocolversion.ptv_cvl_id_protocoltype);

                    pkg_importprotocollog.p_writelog (
                        l_importprotocolheader.iph_id,
                        NULL,
                        pkg_exception.cst_moreversion,
                        NULL,
                        TO_CHAR (l_countprotocoltype),
                        l_listversion,
                        l_recprotocolversion.ptv_version);
                END IF;

                pkg_importprotocollog.p_writelog (
                    l_importprotocolheader.iph_id,
                    NULL,
                    pkg_exception.cst_unabletosaveform,
                    NULL,
                    l_importprotocolheader.iph_sheetname,
                    TO_CHAR (l_counterror)); -- Le formulaire ne peut pas être sauvé en raison de la présence de n erreurs
                RETURN;
            ELSE                                               -- counterror=0
                pkg_importprotocolheader.p_updatevalidatestatus (
                    l_importprotocolheader.iph_id,
                    pkg_constante.cst_validstatusok,
                    p_usr_id);
                l_countwarning :=
                    pkg_importprotocollog.f_getcountseveritylevel (
                        p_iph_id,
                        pkg_message.cst_severity_level_warning);

                IF l_countwarning > 0
                THEN
                    pkg_importprotocollog.p_writelog (
                        l_importprotocolheader.iph_id,
                        NULL,
                        pkg_exception.cst_warningvalidate,
                        NULL,
                        l_importprotocolheader.iph_sheetname,
                        TO_CHAR (l_countwarning));
                ELSE
                    pkg_importprotocollog.p_writelog (
                        l_importprotocolheader.iph_id,
                        NULL,
                        pkg_exception.cst_processdonewithouterror,
                        NULL,
                        l_importprotocolheader.iph_sheetname);
                END IF;

                IF l_reccodevalue.cvl_code =
                   pkg_codevalue.cst_protocoltype_laboratory
                THEN
                    p_logstatistiquelaboratory (l_importprotocolheader);
                END IF;
            END IF;
        ELSE                                              -- Protocol de masse
            pkg_importmassdataheader.p_returncounter (
                l_importprotocolheader.iph_id,
                l_totalcounter,
                l_validcounter,
                l_invalidcounter,
                l_allreadyexistcounter);

            IF l_validcounter = 0
            THEN
                pkg_importprotocollog.p_writelog (
                    l_importprotocolheader.iph_id,
                    NULL,
                    pkg_exception.cst_unabletosavemass,
                    NULL,
                    l_importprotocolheader.iph_sheetname,
                    TO_CHAR (l_totalcounter),
                    TO_CHAR (l_invalidcounter),
                    TO_CHAR (l_allreadyexistcounter));
            ELSE
                pkg_importprotocolheader.p_updatevalidatestatus (
                    l_importprotocolheader.iph_id,
                    pkg_constante.cst_validstatusok,
                    p_usr_id);
                pkg_importprotocollog.p_writelog (
                    l_importprotocolheader.iph_id,
                    NULL,
                    pkg_exception.cst_massstatistics,
                    NULL,
                    TO_CHAR (l_totalcounter),
                    TO_CHAR (l_validcounter),
                    TO_CHAR (l_invalidcounter),
                    TO_CHAR (l_allreadyexistcounter));
                NULL;
            END IF;
        END IF;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_logstart (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_protocoltype              IN codevalue.cvl_code%TYPE)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        pkg_importprotocollog.p_writelog (
            p_recimportprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_strartprocess,
            NULL,
            p_recimportprotocolheader.iph_sheetname,
            p_protocoltype,
            TO_CHAR (SYSDATE, 'DD/MM/YYYY HH24:MI:SS'));
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_logend (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_protocoltype              IN codevalue.cvl_code%TYPE,
        p_deltatimefmt              IN VARCHAR2)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        pkg_importprotocollog.p_writelog (
            p_recimportprotocolheader.iph_id,
            NULL,
            pkg_exception.cst_endprocess,
            NULL,
            p_recimportprotocolheader.iph_sheetname,
            p_protocoltype,
            TO_CHAR (SYSDATE, 'DD/MM/YYYY HH24:MI:SS'),
            p_deltatimefmt);
    END;

    /*-----------------------------------------------------------*/
    PROCEDURE p_test1
    /*----------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_cursorerror               pkg_importprotocollog.t_cursor;
        l_errorlevel                VARCHAR2 (126);
        l_status                    VARCHAR2 (10);
        l_exceptionnumber           NUMBER;
        l_message                   VARCHAR2 (4096);
        l_pid_id                    processingstatus.pid_id%TYPE;
    BEGIN
        UPDATE importprotocolheader
           SET iph_validstatus = pkg_constante.cst_validstatuspending
         WHERE iph_id = 27;

        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (27);
        p_initprocessingstatus_v2 (l_pid_id);

        p_validateprocess_v2 (l_recimportprotocolheader.iph_id,
                              l_recimportprotocolheader.iph_lan_id,
                              3,
                              l_pid_id,
                              l_cursorerror,
                              l_errorlevel);



        pkg_debug.p_write ('PKG_VALIDATEW.P_VALIDATE',
                           'Terminé message1 : ' || l_message);
    END;

    /*-----------------------------------------------------------*/
    PROCEDURE p_test2
    /*----------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_cursorerror               pkg_importprotocollog.t_cursor;
        l_errorlevel                VARCHAR2 (126);
        l_iph_id                    NUMBER := 612;
        l_severity                  VARCHAR2 (100);
        l_message                   VARCHAR2 (4096);
        l_fieldname                 VARCHAR2 (64);
        l__exceptionnumber          NUMBER;
    BEGIN
        pkg_importprotocolheader.p_updatevalidatestatus (
            l_iph_id,
            pkg_constante.cst_validstatuspending,
            2);
        pkg_debug.p_truncate;
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (l_iph_id);
        p_validateprocess_v2 (l_recimportprotocolheader.iph_id,
                              l_recimportprotocolheader.iph_lan_id,
                              1,
                              121,
                              l_cursorerror,
                              l_errorlevel);

        LOOP
            FETCH l_cursorerror
                INTO l_severity,
                     l_message,
                     l_fieldname,
                     l__exceptionnumber;

            EXIT WHEN l_cursorerror%NOTFOUND;
            DBMS_OUTPUT.put_line (l_severity || ' ' || l_message);
        END LOOP;

        CLOSE l_cursorerror;
    END;

    /*-----------------------------------------------------------*/
    PROCEDURE p_test3
    /*----------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_sph_id                    NUMBER;
        l_iph_id                    importprotocolheader.iph_id%TYPE := 2;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (l_iph_id);
        p_validateconfirm (l_recimportprotocolheader.iph_id,
                           l_recimportprotocolheader.iph_lan_id,
                           2,
                           'Y',
                           'Y',
                           l_sph_id);
    END;



    /*------------------------------------------------------------*/
    PROCEDURE p_validateprocess (
        p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
        p_lan_id        IN     language.lan_id%TYPE,
        p_usr_id        IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_cursorerror      OUT pkg_importprotocollog.t_cursor,
        p_errorlevel       OUT VARCHAR2)
    /*-------------------------------------------------------------*/
    IS
    BEGIN
        p_validateprocess (p_iph_id,
                           p_lan_id,
                           p_usr_id,
                           NULL,
                           p_cursorerror,
                           p_errorlevel);
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_initprocessingstatus (
        p_external_id   IN importprotocolheader.iph_external_id%TYPE)
    /*------------------------------------------------------------*/
    IS
    BEGIN
        pkg_processingstatus.p_initprocessingstatus (p_external_id);
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_initprocessingstatus_v2 (
        p_pid_id   OUT processingstatus.pid_id%TYPE)
    /*------------------------------------------------------------*/
    IS
    BEGIN
        pkg_processingstatus.p_initprocessingstatus_v2 (p_pid_id);
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_initprocessingstatus (
        p_external_id   IN     importprotocolheader.iph_external_id%TYPE,
        p_pid_id           OUT processingstatus.pid_id%TYPE)
    /*------------------------------------------------------------*/
    IS
    BEGIN
        pkg_processingstatus.p_initprocessingstatus (p_external_id, p_pid_id);
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_validateprocess (
        p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
        p_lan_id        IN     language.lan_id%TYPE,
        p_usr_id        IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_external_id   IN     importprotocolheader.iph_external_id%TYPE,
        p_cursorerror      OUT pkg_importprotocollog.t_cursor,
        p_errorlevel       OUT VARCHAR2)
    /*-------------------------------------------------------------*/
    IS
        l_recprocessingstatus   processingstatus%ROWTYPE;
    BEGIN
        l_recprocessingstatus :=
            pkg_processingstatus.f_getrecordbyexternalid (p_external_id);

        --  Si c'est NULL, l'interface WEB est en version inférieure
        IF l_recprocessingstatus.pid_id IS NULL
        THEN
            pkg_validate.p_initprocessingstatus (p_external_id);
            l_recprocessingstatus :=
                pkg_processingstatus.f_getrecordbyexternalid (p_external_id);
        END IF;

        pkg_importprotocolheader.p_updateprocessingdata ( -- On met à jour la colonne iph_external_id er iph_pid_id
            p_iph_id,
            p_external_id,
            l_recprocessingstatus.pid_id);
        p_validateprocess_v2 (p_iph_id,
                              p_lan_id,
                              p_usr_id,
                              l_recprocessingstatus.pid_id,
                              p_cursorerror,
                              p_errorlevel);
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_validateprocess_v2 (
        p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
        p_lan_id        IN     language.lan_id%TYPE,
        p_usr_id        IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_pid_id        IN     importprotocolheader.iph_pid_id%TYPE,
        p_cursorerror      OUT pkg_importprotocollog.t_cursor,
        p_errorlevel       OUT VARCHAR2)
    /*-------------------------------------------------------------*/
    IS
        /* Version utilisé */


        l_returnstatus              NUMBER;
        l_bug                       NUMBER;
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_reccodevalue              codevalue%ROWTYPE;
        l_recprotocolversion        protocolversion%ROWTYPE;


        l_message                   VARCHAR2 (4098);
        l_fieldname                 VARCHAR2 (4096);
        l_exceptionnumber           NUMBER;
        l_starttime                 TIMESTAMP;
        l_endtime                   TIMESTAMP;
        l_deltatime                 NUMBER;
        l_deltatimefmt              VARCHAR2 (256);
        l_pid_id                    processingstatus.pid_id%TYPE;
        l_processstatus             NUMBER;
        l_rightlistgrouptxt         VARCHAR2 (1024);
        l_recprocessingstatus       processingstatus%ROWTYPE;
    BEGIN
        l_starttime := SYSTIMESTAMP;



        pkg_processingstatus.p_initprocessingstatus_v2 (l_pid_id);
        l_recprocessingstatus := pkg_processingstatus.f_getrecord (l_pid_id);

        pkg_importprotocolheader.p_updateprocessingdata ( -- On met à jour la colonne iph_external_id er iph_pid_id
            p_iph_id,
            l_recprocessingstatus.pid_externalid,
            l_recprocessingstatus.pid_id);
        l_pid_id := l_recprocessingstatus.pid_id;
        pkg_debug.p_write (
            'PKG_VALIDATE.p_validate',
               'P_LAN_ID='
            || TO_CHAR (p_lan_id)
            || ' P_PID_ID='
            || TO_CHAR (p_pid_id));

        pkg_importprotocollog.p_purgebyiphid (p_iph_id);

        p_loadheaderandversion (p_iph_id,
                                l_recimportprotocolheader,
                                l_reccodevalue,
                                l_recprotocolversion);

        pkg_debug.p_write (
            'PKG_VALIDATE.p_validate',
               'l_recimportprotocolheader.iph_validstatus='
            || l_recimportprotocolheader.iph_validstatus);

        IF l_recimportprotocolheader.iph_validstatus !=
           pkg_importprotocolheader.cst_validstatuspending
        THEN
            -- La validation a déja été effectuée sur cette entrée
            pkg_importprotocollog.p_writelog (
                l_recimportprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_validprocessallreadydone,
                'ALL FIELDS');
            pkg_importprotocollog.p_listerrorlog (p_iph_id,
                                                  p_lan_id,
                                                  p_cursorerror,
                                                  p_errorlevel);
            RETURN;
        END IF;

        p_logstart (l_recimportprotocolheader, l_reccodevalue.cvl_code);

        l_rightlistgrouptxt :=
            pkg_rightutility_v2.f_returngrouprightlist (
                p_usr_id,
                pkg_admin_application.cst_application_midat,
                TRUE);                                             -- writable
        pkg_importprotocollog.p_writelog (l_recimportprotocolheader.iph_id,
                                          NULL,
                                          pkg_exception.cst_cantonlistright,
                                          NULL,
                                          l_rightlistgrouptxt);

        CASE l_reccodevalue.cvl_code
            WHEN pkg_codevalue.cst_protocoltype_laboratory
            THEN
                pkg_debug.p_write ('PKG_VALIDATE.p_validate', 'ICI');
                p_validatelaboratory (l_recimportprotocolheader, p_usr_id);
            WHEN pkg_codevalue.cst_protocoltype_mass
            THEN
                pkg_processingstatus.p_updateprocessingstatus (p_usr_id,
                                                               l_pid_id);

                p_validatemass (l_recimportprotocolheader,
                                p_usr_id,
                                p_lan_id);

                pkg_processingstatus.p_endprocessingstatus (
                    l_recimportprotocolheader,
                    p_usr_id);
            WHEN pkg_codevalue.cst_protocoltype_grdeval
            THEN
                p_validategrid (l_recimportprotocolheader,
                                l_recimportprotocolheader.iph_sph_id_parent,
                                p_usr_id);

                pkg_importprotocollog.p_returnvalidatestatus (
                    l_recimportprotocolheader.iph_id,
                    l_processstatus);

                IF l_processstatus = pkg_constante.cst_returnstatusok
                THEN
                    IF NOT pkg_sampleheader.f_checkprotocoleallreadyexist (
                               l_recimportprotocolheader.iph_id)
                               IS NULL
                    THEN
                        pkg_importprotocollog.p_writelog (
                            l_recimportprotocolheader.iph_id,
                            NULL,
                            pkg_exception.cst_protocolwillbereplace,
                            NULL);
                    END IF;
                END IF;

                NULL;
            WHEN pkg_codevalue.cst_protocoltype_ground
            THEN
                p_validateground (
                    l_recimportprotocolheader,
                    l_recimportprotocolheader.iph_sph_id_parent,
                    p_usr_id);


                pkg_importprotocollog.p_returnvalidatestatus (
                    l_recimportprotocolheader.iph_id,
                    l_processstatus);

                IF l_processstatus = pkg_constante.cst_returnstatusok
                THEN
                    IF NOT pkg_sampleheader.f_checkprotocoleallreadyexist (
                               l_recimportprotocolheader.iph_id)
                               IS NULL
                    THEN
                        pkg_importprotocollog.p_writelog (
                            l_recimportprotocolheader.iph_id,
                            NULL,
                            pkg_exception.cst_protocolwillbereplace,
                            NULL);
                    END IF;
                END IF;
            ELSE
                NULL;
        END CASE;

        l_endtime := SYSTIMESTAMP;
        l_deltatime :=
            pkg_stringutil.f_returnelapsedtime (l_endtime, l_starttime);
        l_deltatimefmt := pkg_stringutil.f_convertmilisecond (l_deltatime);
        p_logend (l_recimportprotocolheader,
                  l_reccodevalue.cvl_code,
                  l_deltatimefmt);
        p_logstatistique (p_iph_id, p_usr_id);

        -- Pour les protocole de masse, on purge les données après le calcul statistique

        /*
              IF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_mass
              THEN
                 -- On purge les données invalides
                 pkg_importmassdataheader.p_purgeinvalidemassdata (
                    l_recimportprotocolheader.iph_id);
                 -- On purge les orphelins
                 pkg_importmassdatadetail.p_purgeorphan;
              END IF;
        */
        pkg_importprotocollog.p_listerrorlog (p_iph_id,
                                              p_lan_id,
                                              p_cursorerror,
                                              p_errorlevel);
                                         /*
EXCEPTION
   WHEN OTHERS
   THEN
      pkg_debug.p_write ('PKG_VALIDATE.p_validateprocess',
                         DBMS_UTILITY.format_error_backtrace);
      pkg_exception.p_putexception2cache;
      */
    END;



    /*------------------------------------------------------------*/

    PROCEDURE p_validateprocessold (
        p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
        p_lan_id        IN     language.lan_id%TYPE,
        p_usr_id        IN     importprotocolheader.iph_usr_id_modify%TYPE,
        p_external_id   IN     importprotocolheader.iph_external_id%TYPE,
        p_cursorerror      OUT pkg_importprotocollog.t_cursor,
        p_errorlevel       OUT VARCHAR2)
    /*-------------------------------------------------------------*/
    IS
        /* Logique du traitement
           1) Protocol de masse
               1 Purge l'historique: pkg_importprotocollog.p_purgebyiphid
               2 Appel procédure p_validatemass
                  3 Appel procédure pkg_java.p_processinit
                     3.a Charge les lignes d'entêtes du fichier excel
                     3.b Valide l'entête (champ obligatoire, identifiable,)
                   4. Appel procédure pkg_validatemassdetail.p_validate
                      4.a p_processmassdetail (charge les données depuis Excel dans la table importmassdatadetail)
                      4.b p_validaterequiredfield (vérifie que les champ obligatoire soient renseignées)
                      4.c p_validaterequiredgrpfield(vérifie que les groupe de champ obligatoire soient renseignée)
                      4.d  pkg_importmassdatadetail.p_identifyheader. Identifie les header (même date, même lieu)
                      4.e  p_completeheader Complète l'entête avec les données associées (systemprecison,...)

             Reste:
                  Valider les champs (x,y,z, etc.)
          */



        l_returnstatus              NUMBER;
        l_bug                       NUMBER;
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_reccodevalue              codevalue%ROWTYPE;
        l_recprotocolversion        protocolversion%ROWTYPE;


        l_message                   VARCHAR2 (4098);
        l_fieldname                 VARCHAR2 (4096);
        l_exceptionnumber           NUMBER;
        l_starttime                 TIMESTAMP;
        l_endtime                   TIMESTAMP;
        l_deltatime                 NUMBER;
        l_deltatimefmt              VARCHAR2 (256);
        l_pid_id                    processingstatus.pid_id%TYPE;
        l_processstatus             NUMBER;
        l_rightlistgrouptxt         VARCHAR2 (1024);
        l_recprocessingstatus       processingstatus%ROWTYPE;
    BEGIN
        pkg_debug.p_write ('PKG_VALIDATE.p_validate',
                           'P_LAN_ID=' || TO_CHAR (p_lan_id));
        l_starttime := SYSTIMESTAMP;

        IF NOT p_external_id IS NULL
        THEN
            -- La fonction p_initprocessingstatus  a déjà écrit dans la table processingstatus
            l_recprocessingstatus :=
                pkg_processingstatus.f_getrecordbyexternalid (p_external_id);
            /*
                     --  Si c'est NULL, l'interface WEB est en version inférieure
                     IF l_recprocessingstatus.pid_id IS NULL
                     THEN
                        pkg_validate.p_initprocessingstatus (p_external_id);
                        l_recprocessingstatus :=
                           pkg_processingstatus.f_getrecordbyexternalid (p_external_id);
                     END IF;
            */
            pkg_importprotocolheader.p_updateprocessingdata ( -- On met à jour la colonne iph_external_id er iph_pid_id
                p_iph_id,
                p_external_id,
                l_recprocessingstatus.pid_id);
            l_pid_id := l_recprocessingstatus.pid_id;
        END IF;

        pkg_importprotocollog.p_purgebyiphid (p_iph_id);

        p_loadheaderandversion (p_iph_id,
                                l_recimportprotocolheader,
                                l_reccodevalue,
                                l_recprotocolversion);


        IF l_recimportprotocolheader.iph_validstatus !=
           pkg_importprotocolheader.cst_validstatuspending
        THEN
            -- La validation a déja été effectuée sur cette entrée
            pkg_importprotocollog.p_writelog (
                l_recimportprotocolheader.iph_id,
                NULL,
                pkg_exception.cst_validprocessallreadydone,
                'ALL FIELDS');
            RETURN;
        END IF;

        p_logstart (l_recimportprotocolheader, l_reccodevalue.cvl_code);

        l_rightlistgrouptxt :=
            pkg_rightutility_v2.f_returngrouprightlist (
                p_usr_id,
                pkg_admin_application.cst_application_midat,
                TRUE);                                             -- writable
        pkg_importprotocollog.p_writelog (l_recimportprotocolheader.iph_id,
                                          NULL,
                                          pkg_exception.cst_cantonlistright,
                                          NULL,
                                          l_rightlistgrouptxt);

        CASE l_reccodevalue.cvl_code
            WHEN pkg_codevalue.cst_protocoltype_laboratory
            THEN
                p_validatelaboratory (l_recimportprotocolheader, p_usr_id);
            WHEN pkg_codevalue.cst_protocoltype_mass
            THEN
                pkg_processingstatus.p_updateprocessingstatus (p_usr_id,
                                                               l_pid_id);
                --        pkg_importprotocolheader.p_updatepid_id (
                --           l_recimportprotocolheader.iph_id,
                --          l_pid_id);
                --        l_recimportprotocolheader.iph_pid_id := l_pid_id;

                p_validatemass (l_recimportprotocolheader,
                                p_usr_id,
                                p_lan_id);

                pkg_processingstatus.p_endprocessingstatus (
                    l_recimportprotocolheader,
                    p_usr_id);
            WHEN pkg_codevalue.cst_protocoltype_grdeval
            THEN
                p_validategrid (l_recimportprotocolheader,
                                l_recimportprotocolheader.iph_sph_id_parent,
                                p_usr_id);

                pkg_importprotocollog.p_returnvalidatestatus (
                    l_recimportprotocolheader.iph_id,
                    l_processstatus);

                IF l_processstatus = pkg_constante.cst_returnstatusok
                THEN
                    IF NOT pkg_sampleheader.f_checkprotocoleallreadyexist (
                               l_recimportprotocolheader.iph_id)
                               IS NULL
                    THEN
                        pkg_importprotocollog.p_writelog (
                            l_recimportprotocolheader.iph_id,
                            NULL,
                            pkg_exception.cst_protocolwillbereplace,
                            NULL);
                    END IF;
                END IF;

                NULL;
            WHEN pkg_codevalue.cst_protocoltype_ground
            THEN
                p_validateground (
                    l_recimportprotocolheader,
                    l_recimportprotocolheader.iph_sph_id_parent,
                    p_usr_id);


                pkg_importprotocollog.p_returnvalidatestatus (
                    l_recimportprotocolheader.iph_id,
                    l_processstatus);

                IF l_processstatus = pkg_constante.cst_returnstatusok
                THEN
                    IF NOT pkg_sampleheader.f_checkprotocoleallreadyexist (
                               l_recimportprotocolheader.iph_id)
                               IS NULL
                    THEN
                        pkg_importprotocollog.p_writelog (
                            l_recimportprotocolheader.iph_id,
                            NULL,
                            pkg_exception.cst_protocolwillbereplace,
                            NULL);
                    END IF;
                END IF;
            ELSE
                NULL;
        END CASE;

        l_endtime := SYSTIMESTAMP;
        l_deltatime :=
            pkg_stringutil.f_returnelapsedtime (l_endtime, l_starttime);
        l_deltatimefmt := pkg_stringutil.f_convertmilisecond (l_deltatime);
        p_logend (l_recimportprotocolheader,
                  l_reccodevalue.cvl_code,
                  l_deltatimefmt);
        p_logstatistique (p_iph_id, p_usr_id);

        -- Pour les protocole de masse, on purge les données après le calcul statistique
        /*
              IF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_mass
              THEN
                 -- On purge les données invalides
                 pkg_importmassdataheader.p_purgeinvalidemassdata (
                    l_recimportprotocolheader.iph_id);
                 -- On purge les orphelins
                 pkg_importmassdatadetail.p_purgeorphan;
              END IF;
        */
        pkg_importprotocollog.p_listerrorlog (p_iph_id,
                                              p_lan_id,
                                              p_cursorerror,
                                              p_errorlevel);
                                         /*
EXCEPTION
   WHEN OTHERS
   THEN
      pkg_debug.p_write ('PKG_VALIDATE.p_validateprocess',
                         DBMS_UTILITY.format_error_backtrace);
      pkg_exception.p_putexception2cache;
      */
    END;

    /*--------------------------------------------------------------*/

    FUNCTION f_getperson (p_per_id IN person.per_id%TYPE)
        RETURN person%ROWTYPE
    /*---------------------------------------------------------------*/
    IS
        l_recperson   person%ROWTYPE;
    BEGIN
        l_recperson := pkg_person.f_getrecord (p_per_id);

        IF l_recperson.per_id IS NULL
        THEN
            pkg_message.p_setparameter (
                'pkg_person.f_getrecord (' || TO_CHAR (p_per_id) || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        RETURN l_recperson;
    END;



    /*-------------------------------------------------------------------------------------------------*/

    PROCEDURE p_saveprotocolmass (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_lan_id                    IN language.lan_id%TYPE,
        p_usr_id                    IN sampleprotocolgrnd.spd_usr_id_create%TYPE,
        p_visibilitystatus          IN sampleheader.sph_visibilitystatus%TYPE,
        p_publicstatus              IN VARCHAR2)
    /*------------------------------------------------------------------------------------------------*/
    IS
        -- Traitement uniquement pour les headers VALIDES
        -- 1. On sauve le fichier dans la table SAMPLEHEADERMASSFILE
        -- 2. On sauve les stations, la valeur SST_ID est enregistré dans la colonne IMH_SST_ID de tous les enregistrements qui ont IMH_IMS_ID = IMS_ID
        -- 3. On sauve les HEADER de la table IMPORTMASSHEADER dans les tables SAMPLEHEADER et SAMPLEHEADERITEM et SAMPLEDOCUMENT
        --   3.1 On sauve dans la table SAMPLEPROTOCOLLABO les données associées contenues dans la table IMPORTMASSDATADETAIL et associé au HEADER
        l_smf_id   sampleheadermassfile.smf_id%TYPE;
    BEGIN
        --1. On sauve le fichier
        pkg_sampleheadermassfile.p_write (
            p_recimportprotocolheader.iph_ptv_id,
            p_recimportprotocolheader.iph_lan_id,
            p_recimportprotocolheader.iph_file,
            p_recimportprotocolheader.iph_inputfilename,
            p_recimportprotocolheader.iph_sheetname,
            p_usr_id,
            l_smf_id);
        -- 2. On sauve les stations
        pkg_importmassstation.p_saveprotocolmassstation (
            p_recimportprotocolheader,
            p_lan_id,
            p_usr_id);
        --3. On sauve les headers et les détails asscoiés au header
        pkg_importmassdataheader.p_saveprotocolmassheader (
            p_recimportprotocolheader,
            p_lan_id,
            p_usr_id,
            l_smf_id,
            p_visibilitystatus,
            p_publicstatus);
    END;


    /*--------------------------------------------------------------------------------------------------*/

    PROCEDURE p_savelaboprotocoldetail (
        l_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_sph_id                    IN sampleheader.sph_id%TYPE,
        p_usr_id                    IN sampleprotocolgrnd.spd_usr_id_create%TYPE)
    /*--------------------------------------------------------------------------------------------------*/
    IS
        CURSOR l_curimportprotocollabo IS
            SELECT *
              FROM importprotocollabo
             WHERE     ipl_iph_id = l_recimportprotocolheader.iph_id
                   AND NOT ipl_value IS NULL;

        l_recimportprotocollabo    l_curimportprotocollabo%ROWTYPE;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
        l_spl_id                   sampleprotocollabo.spl_id%TYPE;
    BEGIN
        OPEN l_curimportprotocollabo;

        LOOP
            FETCH l_curimportprotocollabo INTO l_recimportprotocollabo;

            EXIT WHEN l_curimportprotocollabo%NOTFOUND;
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (
                    l_recimportprotocollabo.ipl_ptl_id);
            pkg_sampleprotocollabo.p_writeorupdate (
                p_sph_id,
                l_recimportprotocollabo.ipl_ptl_id,
                l_recprotocolmappinglabo.ptl_syv_id,                 -- syv_id
                NULL,                                      --cvl_id_zoostadium
                pkg_stringutil.f_validatenumber (
                    l_recimportprotocollabo.ipl_value),           -- Frequency
                NULL,                                     -- frequencymodified
                NULL,                                              -- freqlum,
                NULL,                                               -- stadium
                NULL,                                               --sampleno
                NULL,                                               -- COMMENT
                NULL,                               -- spl_unidentifiedspecies
                p_usr_id,
                l_spl_id);
        END LOOP;

        CLOSE l_curimportprotocollabo;
    END;

    /*--------------------------------------------------------------------------------------------------*/

    PROCEDURE p_savegridprotocolgrounddetail (
        l_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_sph_id                    IN sampleheader.sph_id%TYPE,
        p_usr_id                    IN sampleprotocolgrnd.spd_usr_id_create%TYPE)
    /*--------------------------------------------------------------------------------------------------*/
    IS
        l_spd_id              sampleprotocolgrnd.spd_id%TYPE;

        CURSOR l_protocolground IS
            SELECT *
              FROM importprotocolgrnd
             WHERE ipn_iph_id = l_recimportprotocolheader.iph_id;

        l_recprotocolground   l_protocolground%ROWTYPE;
    BEGIN
        OPEN l_protocolground;

        LOOP
            FETCH l_protocolground INTO l_recprotocolground;

            EXIT WHEN l_protocolground%NOTFOUND;
            pkg_sampleprotocolgrnd.p_write (p_sph_id,
                                            l_recprotocolground.ipn_pmr_id,
                                            l_recprotocolground.ipn_value,
                                            p_usr_id,
                                            l_spd_id);
        END LOOP;

        CLOSE l_protocolground;

        NULL;
    END;

    /*--------------------------------------------------------------------------------------------------*/

    PROCEDURE p_savegridprotocolgriddetail (
        l_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_sph_id                    IN sampleheader.sph_id%TYPE,
        p_usr_id                    IN sampleprotocolgrid.spg_usr_id_create%TYPE)
    /*--------------------------------------------------------------------------------------------------*/
    IS
        CURSOR l_curimportprotocolgrid IS
            SELECT *
              FROM importprotocolgrid
             WHERE     ipg_iph_id = l_recimportprotocolheader.iph_id
                   AND NOT ipg_value IS NULL;

        l_recimportprotocolgrid   l_curimportprotocolgrid%ROWTYPE;
        l_spg_id                  sampleprotocolgrid.spg_id%TYPE;
    BEGIN
        OPEN l_curimportprotocolgrid;

        LOOP
            FETCH l_curimportprotocolgrid INTO l_recimportprotocolgrid;

            EXIT WHEN l_curimportprotocolgrid%NOTFOUND;

            pkg_sampleprotocolgrid.p_write (
                p_sph_id,
                l_recimportprotocolgrid.ipg_pmg_id,
                l_recimportprotocolgrid.ipg_value,
                p_usr_id,
                l_spg_id);
        END LOOP;

        CLOSE l_curimportprotocolgrid;

        NULL;
    END;



    /*----------------------------------------------------------------------------------*/

    PROCEDURE p_saveprotocolnotlabo (
        p_iph_id         IN     importprotocollog.ipo_iph_id%TYPE,
        p_lan_id         IN     language.lan_id%TYPE,
        p_usr_id         IN     sampleheader.sph_usr_id_create%TYPE,
        p_protocoltype   IN     codevalue.cvl_code%TYPE,
        p_sph_id            OUT sampleheader.sph_id%TYPE)
    /*-------------------------------------------------------------------------------------------------*/
    IS
        l_recordvalueoperator        codevalue%ROWTYPE;
        l_recordvaluelocality        codevalue%ROWTYPE;
        l_recordvaluewatercourse     codevalue%ROWTYPE;
        l_recimportprotocolheader    importprotocolheader%ROWTYPE;
        l_recsampleheader            sampleheader%ROWTYPE;
        l_virtimportprotocolheader   importprotocolheader%ROWTYPE;
        l_shm_id                     sampleheaderitem.shm_id%TYPE;
        l_recperson                  person%ROWTYPE;
        l_person                     sampleheaderitem.shm_item%TYPE;
        l_cvl_id_midatstitmty        samplestationitem.ssi_cvl_id_midatstitmty%TYPE;
        l_reccodevalue               codevalue%ROWTYPE;
        l_ssi_id                     samplestationitem.ssi_id%TYPE;
        l_spt_id                     sampledocument.spt_id%TYPE;
    -- Note: Localité et watrcourse sont enregitré dans SAMPLEHEADERITEM pour pouvoir reconstituer le headeer complet et dans SAMPLESTATIONITEM s'il n'existe pas
    BEGIN
        l_recordvalueoperator :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_operator,
                pkg_codereference.cst_crf_midathditmty);

        IF l_recordvalueoperator.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_operator
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        l_recordvaluelocality :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_locality,
                pkg_codereference.cst_crf_midathditmty);

        IF l_recordvaluelocality.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_locality
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        l_recordvaluewatercourse :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_watercourse,
                pkg_codereference.cst_crf_midathditmty);

        IF l_recordvaluewatercourse.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_watercourse
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;


        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);

        IF l_recimportprotocolheader.iph_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'PKG_IMPORTPROTOCOL.f_getrecord('
                || TO_CHAR (p_iph_id)
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        p_sph_id := l_recimportprotocolheader.iph_sph_id_parent;
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
        pkg_debug.p_write ('PKG_VALIDATE.p_saveprotocolnotlabo',
                           'p_sph_id=' || p_sph_id);



        -- On sauve le nom de l'opérateur
        pkg_sampleheaderitem.p_write (
            p_sph_id,
            p_lan_id,
            l_recordvalueoperator.cvl_id,
            l_recimportprotocolheader.iph_ptv_id,
            pkg_sampleheaderitem.cst_typecodefromexcelform,
            l_recimportprotocolheader.iph_operator,
            NULL,
            p_usr_id,
            l_shm_id);

        -- On sauve le nom de la localité

        pkg_sampleheaderitem.p_writeconditionnaly (
            p_sph_id,
            p_lan_id,
            l_recordvaluelocality.cvl_id,
            l_recimportprotocolheader.iph_ptv_id,
            pkg_sampleheaderitem.cst_typecodefromexcelform,
            l_recimportprotocolheader.iph_locality,
            NULL,
            p_usr_id,
            l_shm_id);

        IF NOT l_recimportprotocolheader.iph_locality IS NULL -- Dans SAMPLESTATIONITEM
        THEN
            l_reccodevalue :=
                pkg_codevalue.f_getfromcode (
                    pkg_codevalue.cst_midatstitmty_locality,
                    pkg_codereference.cst_crf_midatstitmty);

            pkg_samplestationitem.p_writeifnotexist (
                l_recsampleheader.sph_sst_id,
                p_lan_id,
                l_reccodevalue.cvl_id,
                l_recimportprotocolheader.iph_locality,
                p_usr_id,
                l_ssi_id);
        END IF;

        -- On sauve le nom de la rivière
        pkg_sampleheaderitem.p_writeconditionnaly (
            p_sph_id,
            p_lan_id,
            l_recordvaluewatercourse.cvl_id,
            l_recimportprotocolheader.iph_ptv_id,
            pkg_sampleheaderitem.cst_typecodefromexcelform,
            l_recimportprotocolheader.iph_watercourse,
            NULL,
            p_usr_id,
            l_shm_id);

        IF NOT l_recimportprotocolheader.iph_watercourse IS NULL -- Dans SAMPLESTATIONITEM
        THEN
            l_reccodevalue :=
                pkg_codevalue.f_getfromcode (
                    pkg_codevalue.cst_midatstitmty_watercourse,
                    pkg_codereference.cst_crf_midatstitmty);

            pkg_samplestationitem.p_writeifnotexist (
                l_recsampleheader.sph_sst_id,
                p_lan_id,
                l_reccodevalue.cvl_id,
                l_recimportprotocolheader.iph_watercourse,
                p_usr_id,
                l_ssi_id);
        END IF;

        IF NOT l_recimportprotocolheader.iph_per_id_operator IS NULL
        THEN
            l_recperson :=
                f_getperson (l_recimportprotocolheader.iph_per_id_operator);

            IF l_recperson.per_id IS NULL
            THEN
                RETURN;
            END IF;

            l_person :=
                pkg_stringutil.f_formatpersonnames (
                    l_recperson.per_firstname,
                    l_recperson.per_lastname);
            pkg_sampleheaderitem.p_write (
                p_sph_id,
                p_lan_id,
                l_recordvalueoperator.cvl_id,
                l_recimportprotocolheader.iph_ptv_id,
                pkg_sampleheaderitem.cst_typecodefromtableperson,
                l_person,
                l_recimportprotocolheader.iph_per_id_operator,
                p_usr_id,
                l_shm_id);
        END IF;

        -- On sauve le fichier
        l_virtimportprotocolheader :=
            pkg_importprotocolheader.f_getvirtimportheaderprotocol (p_iph_id);

        IF l_virtimportprotocolheader.iph_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_importprotocolheader.f_getvirtimportheaderprotocol('
                || NVL (TO_CHAR (p_iph_id), 'NULL')
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        pkg_sampleheaderfile.p_write (
            l_recimportprotocolheader.iph_ptv_id,
            p_sph_id,
            l_virtimportprotocolheader.iph_lan_id,
            p_usr_id,
            l_recimportprotocolheader.iph_file,
            l_recimportprotocolheader.iph_inputfilename,
            l_recimportprotocolheader.iph_sheetname,
            p_iph_id);

        -- On sauve le report_url
        IF NOT l_recimportprotocolheader.iph_reporturl IS NULL
        THEN
            pkg_sampledocument.p_write (
                p_sph_id,
                l_recimportprotocolheader.iph_ptv_id,
                l_recimportprotocolheader.iph_reporturl,
                NULL                                                 -- title;
                    ,
                p_usr_id,
                l_spt_id);
        END IF;

        IF p_protocoltype = pkg_codevalue.cst_protocoltype_grdeval
        THEN
            pkg_debug.p_write ('PKG_VALIDATE.p_saveprotocolnotlabo',
                               'p_sph_id=' || p_sph_id);
            p_savegridprotocolgriddetail (l_recimportprotocolheader,
                                          p_sph_id,
                                          p_usr_id);
        ELSIF p_protocoltype = pkg_codevalue.cst_protocoltype_ground
        THEN
            p_savegridprotocolgrounddetail (l_recimportprotocolheader,
                                            p_sph_id,
                                            p_usr_id);
            NULL;
        END IF;

        pkg_importprotocolheader.p_updatevalidatestatus (
            l_recimportprotocolheader.iph_id,
            pkg_importprotocolheader.cst_validstatusok,
            p_usr_id);
        pkg_importprotocolheader.p_updateiph_iph_id (
            l_recimportprotocolheader.iph_id,
            p_sph_id);
    END;

    /*-------------------------------------------------------------------------------------------------*/
    PROCEDURE p_savegewissname (
        p_iph_id     IN importprotocollog.ipo_iph_id%TYPE,
        p_lan_id     IN language.lan_id%TYPE,
        p_sst_id     IN samplestation.sst_id%TYPE,
        p_gewissnr   IN samplestation.sst_gewissnr%TYPE,
        p_usr_id     IN sampleheader.sph_usr_id_create%TYPE)
    /*----------------------------------------------------------------------------------------------*/
    IS
        l_ssi_id         samplestationitem.ssi_id%TYPE;
        l_gewissname     VARCHAR2 (256);
        l_reccodevalue   codevalue%ROWTYPE;
    BEGIN
        pkg_debug.p_write ('PKG_VALIDATE.p_savegewissname',
                           'p_gewissnr=' || p_gewissnr);

        IF NVL (p_gewissnr, 0) = 0
        THEN
            RETURN;
        END IF;

        l_gewissname := pkg_gis.f_returnname (p_gewissnr);
        pkg_debug.p_write ('PKG_VALIDATE.p_savegewissname',
                           'l_gewissname=' || l_gewissname);

        IF l_gewissname IS NULL
        THEN
            RETURN;
        END IF;

        l_reccodevalue :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midatstitmty_watercourse,
                pkg_codereference.cst_crf_midatstitmty);

        pkg_samplestationitem.p_writeifnotexist (p_sst_id,
                                                 p_lan_id,         --p_lan_id,
                                                 l_reccodevalue.cvl_id,
                                                 l_gewissname,
                                                 p_usr_id,
                                                 l_ssi_id);
    END;

    /*-------------------------------------------------------------------------------------------------*/

    PROCEDURE p_savelaboprotocol (
        p_iph_id             IN     importprotocollog.ipo_iph_id%TYPE,
        p_lan_id             IN     language.lan_id%TYPE,
        p_usr_id             IN     sampleheader.sph_usr_id_create%TYPE,
        p_visibilitystatus   IN     sampleheader.sph_visibilitystatus%TYPE,
        p_publicstatus       IN     VARCHAR2,
        p_sph_id                OUT sampleheader.sph_id%TYPE)
    /*-------------------------------------------------------------------------------------------------*/
    IS
        /* permet de copier les données des protocoleS dans les tables definitives */
        l_recordvaluelocality        codevalue%ROWTYPE;
        l_recordvaluewatercourse     codevalue%ROWTYPE;
        l_recimportprotocolheader    importprotocolheader%ROWTYPE;
        l_reccodevalueoperator       codevalue%ROWTYPE;
        l_reccodevaluedeterminator   codevalue%ROWTYPE;
        l_recperson                  person%ROWTYPE;
        l_reccodevalue               codevalue%ROWTYPE;
        l_ssi_id                     samplestationitem.ssi_id%TYPE;


        l_sst_id                     samplestation.sst_id%TYPE;
        l_shm_id                     sampleheaderitem.shm_id%TYPE;
        l_person                     sampleheaderitem.shm_item%TYPE;
        l_spt_id                     sampledocument.spt_id%TYPE;
        l_date                       DATE;
        l_reccodevalueorigindata     codevalue%ROWTYPE;
        l_ivr_cvl_id_spear           sampleheader.sph_ivr_id_spear%TYPE;
        l_ivr_cvl_id_ibch            sampleheader.sph_ivr_id_ibch%TYPE;
        l_ivr_cvl_id_makroindex      sampleheader.sph_ivr_id_ibch%TYPE;
    -- Note: Localité et watrcourse sont enregitré dans SAMPLEHEADERITEM pour pouvoir reconstituer le headeer complet et dans SAMPLESTATIONITEM s'il n'existe pas
    BEGIN
        l_reccodevalueorigindata :=
            pkg_codevalue.f_getrecordbycode (
                pkg_codereference.cst_crf_elevorigin,
                pkg_codevalue.cst_elevorigin_data);
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);

        IF l_recimportprotocolheader.iph_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'PKG_IMPORTPROTOCOL.f_getrecord('
                || TO_CHAR (p_iph_id)
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;



        l_reccodevalueoperator :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_operator,
                pkg_codereference.cst_crf_midathditmty);

        IF l_reccodevalueoperator.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_operator
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        l_reccodevaluedeterminator :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_determinator,
                pkg_codereference.cst_crf_midathditmty);

        IF l_reccodevaluedeterminator.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_determinator
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        l_recordvaluelocality :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_locality,
                pkg_codereference.cst_crf_midathditmty);

        IF l_recordvaluelocality.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_locality
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        l_recordvaluewatercourse :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_watercourse,
                pkg_codereference.cst_crf_midathditmty);

        IF l_recordvaluewatercourse.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_watercourse
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;



        IF l_recimportprotocolheader.iph_sst_id_existing IS NULL
        THEN
            -- La station n'existe pas il faut la créer
            pkg_samplestation.p_writefulldata (
                l_recimportprotocolheader.iph_lan_id,
                l_recimportprotocolheader.iph_oid,
                NULL,                                        -- oid calculated
                l_recimportprotocolheader.iph_oid,             -- OID PROVIDED
                l_recimportprotocolheader.iph_ins_id_principal,
                pkg_stringutil.f_validatenumber (
                    l_recimportprotocolheader.iph_startpoint_x),
                pkg_stringutil.f_validatenumber (
                    l_recimportprotocolheader.iph_startpoint_y),
                pkg_stringutil.f_validatenumber (
                    l_recimportprotocolheader.iph_elevation),
                l_reccodevalueorigindata.cvl_id,           -- Elevation source
                NULL,                                   -- Elevation precision
                NULL,                                             -- sst_title
                l_recimportprotocolheader.iph_locality,
                NULL,                                           -- calledplace
                l_recimportprotocolheader.iph_watercourse,
                l_recimportprotocolheader.iph_gewissnr,
                p_usr_id,
                l_recimportprotocolheader.iph_cvl_id_canton,
                l_sst_id);
            /*
                     pkg_samplestation.p_write (
                        l_recimportprotocolheader.iph_lan_id,
                        TO_CHAR (
                           pkg_stringutil.f_validatenumber (
                              l_recimportprotocolheader.iph_oid)),
                        l_recimportprotocolheader.iph_ins_id_principal,
                        pkg_stringutil.f_validatenumber (
                           l_recimportprotocolheader.iph_startpoint_x),
                        pkg_stringutil.f_validatenumber (
                           l_recimportprotocolheader.iph_startpoint_y),
                        pkg_stringutil.f_validatenumber (
                           l_recimportprotocolheader.iph_elevation),
                        NULL,                                                 -- sst_title
                        p_usr_id,
                        l_sst_id);
                        */
            p_savegewissname (p_iph_id,
                              p_lan_id,
                              l_sst_id,
                              l_recimportprotocolheader.iph_gewissnr,
                              p_usr_id);
        ELSE
            l_sst_id := l_recimportprotocolheader.iph_sst_id_existing;

            IF NOT l_recimportprotocolheader.iph_watercourse IS NULL -- Dans SAMPLESTATIONITEM
            THEN
                l_reccodevalue :=
                    pkg_codevalue.f_getfromcode (
                        pkg_codevalue.cst_midatstitmty_watercourse,
                        pkg_codereference.cst_crf_midatstitmty);

                pkg_samplestationitem.p_writeifnotexist (
                    l_sst_id,
                    p_lan_id,
                    l_reccodevalue.cvl_id,
                    l_recimportprotocolheader.iph_watercourse,
                    p_usr_id,
                    l_ssi_id);
            END IF;

            p_savegewissname (p_iph_id,
                              p_lan_id,
                              l_sst_id,
                              l_recimportprotocolheader.iph_gewissnr,
                              p_usr_id);

            IF NOT l_recimportprotocolheader.iph_locality IS NULL -- Dans SAMPLESTATIONITEM
            THEN
                l_reccodevalue :=
                    pkg_codevalue.f_getfromcode (
                        pkg_codevalue.cst_midatstitmty_locality,
                        pkg_codereference.cst_crf_midatstitmty);

                pkg_samplestationitem.p_writeifnotexist (
                    l_sst_id,
                    p_lan_id,
                    l_reccodevalue.cvl_id,
                    l_recimportprotocolheader.iph_locality,
                    p_usr_id,
                    l_ssi_id);
            END IF;
        END IF;


        l_date :=
            TO_DATE (l_recimportprotocolheader.iph_observationdatetxt,
                     'DD/MM/YYYY');
        pkg_sampleheader.p_setiffilledivr_id (
            l_recimportprotocolheader.iph_spearindexnewvalue,
            l_recimportprotocolheader.iph_ibchnewvalue,
            l_recimportprotocolheader.iph_makroindexnewvalue,
            l_ivr_cvl_id_spear,
            l_ivr_cvl_id_ibch,
            l_ivr_cvl_id_makroindex);


        pkg_sampleheader.p_writefull (
            l_sst_id,
            l_recimportprotocolheader.iph_id,
            NULL,                                                -- sph_imh_id
            NULL,                                                 --sph_smf_id
            l_recimportprotocolheader.iph_ins_id_principal,
            l_recimportprotocolheader.iph_ins_id_mandatary,
            l_recimportprotocolheader.iph_cvl_id_systlref,
            l_recimportprotocolheader.iph_cvl_id_systlprec,
            l_recimportprotocolheader.iph_ptv_id,
            l_recimportprotocolheader.iph_cvl_id_windowibch,
            l_recimportprotocolheader.iph_cvl_id_windowmakroindex,
            l_recimportprotocolheader.iph_cvl_id_windowspear,
            NULL,                                               --.sph_project
            l_recimportprotocolheader.iph_determinateddate,
            l_recimportprotocolheader.iph_cvl_id_midatstat,
            l_recimportprotocolheader.iph_absolutenumberflag,
            l_date,
            NULL,                                         --sph_observationday
            NULL,                                      -- sph_observationmonth
            NULL,                                       -- sph_observationyear
            NULL,                                                -- sph_period
            l_recimportprotocolheader.iph_ibchnewvalue,   --sph_indesvalueibch
            pkg_stringutil.f_validatenumber (
                l_recimportprotocolheader.iph_ibchvalue), --sph_indexvalueibch_orig
            l_recimportprotocolheader.iph_makroindexnewvalue, --.sph_mackoindexvalue
            NULL,                                   --sph_makroindexvalue_orig
            l_recimportprotocolheader.iph_spearindexnewvalue, -- sph_spearindexvalue
            NULL,                                  -- sph_spearindexvalue_orig
            p_usr_id,
            p_visibilitystatus,
            l_recimportprotocolheader.iph_prj_id,
            l_ivr_cvl_id_spear,
            l_ivr_cvl_id_ibch,
            l_ivr_cvl_id_makroindex,
            l_recimportprotocolheader.iph_sommeneoz,
            l_recimportprotocolheader.iph_autreneoz_1,
            l_recimportprotocolheader.iph_autreneoz_2,
            l_recimportprotocolheader.iph_sommeept,
            l_recimportprotocolheader.iph_sommeabon,
            l_recimportprotocolheader.iph_sommetxobs,
            l_recimportprotocolheader.iph_sommetxcor,
            l_recimportprotocolheader.iph_valeurvt,
            l_recimportprotocolheader.iph_valeurgi,
            l_recimportprotocolheader.iph_valeurgimax,
            l_recimportprotocolheader.iph_ibchq,
            l_recimportprotocolheader.iph_vc,
            l_recimportprotocolheader.iph_taxonindicateur,
            l_recimportprotocolheader.iph_ibchrobust,
            l_recimportprotocolheader.iph_classevariete,
            l_recimportprotocolheader.iph_classevariete_corr,
            l_recimportprotocolheader.iph_classevarieterobust,
            l_recimportprotocolheader.iph_classevarieterobust_corr,
            l_recimportprotocolheader.iph_classevariete_final,
            l_recimportprotocolheader.iph_classevarieterobust_final,
            l_recimportprotocolheader.iph_taxonfrequencesum,
            l_recimportprotocolheader.iph_gimax,
            l_recimportprotocolheader.iph_gimaxrobust,
            l_recimportprotocolheader.iph_gi_final,
            l_recimportprotocolheader.iph_girobust_final,
            l_recimportprotocolheader.iph_sumfamily,
            l_recimportprotocolheader.iph_sumfamilycorrected,
            l_recimportprotocolheader.iph_sumfamilyrobust,
            l_recimportprotocolheader.iph_sumfamilyrobustcorrected,
            l_recimportprotocolheader.iph_ephemeropteracounter,
            l_recimportprotocolheader.iph_plecopteracounter,
            l_recimportprotocolheader.iph_tricopteracounter,
            p_sph_id);



        pkg_sampleheaderadmingroup.p_updateadmingroup (p_sph_id, p_usr_id);
        pkg_sampleheaderadmingroup.p_setorunsetrightpublic (p_sph_id,
                                                            p_publicstatus,
                                                            p_usr_id);
        pkg_sampleheaderfile.p_write (
            l_recimportprotocolheader.iph_ptv_id,
            p_sph_id,
            l_recimportprotocolheader.iph_lan_id,
            p_usr_id,
            l_recimportprotocolheader.iph_file,
            l_recimportprotocolheader.iph_inputfilename,
            l_recimportprotocolheader.iph_sheetname,
            p_iph_id);

        IF NOT l_recimportprotocolheader.iph_per_id_operator IS NULL
        THEN
            l_recperson :=
                f_getperson (l_recimportprotocolheader.iph_per_id_operator);

            IF l_recperson.per_id IS NULL
            THEN
                RETURN;
            END IF;

            l_person :=
                pkg_stringutil.f_formatpersonnames (
                    l_recperson.per_firstname,
                    l_recperson.per_lastname);
            pkg_sampleheaderitem.p_write (
                p_sph_id,
                p_lan_id,
                l_reccodevalueoperator.cvl_id,
                l_recimportprotocolheader.iph_ptv_id,
                pkg_sampleheaderitem.cst_typecodefromtableperson,
                l_person,
                l_recimportprotocolheader.iph_per_id_operator,
                p_usr_id,
                l_shm_id);
        END IF;

        IF NOT l_recimportprotocolheader.iph_per_id_determinator IS NULL
        THEN
            l_recperson :=
                f_getperson (
                    l_recimportprotocolheader.iph_per_id_determinator);

            IF l_recperson.per_id IS NULL
            THEN
                RETURN;
            END IF;

            l_person :=
                pkg_stringutil.f_formatpersonnames (
                    l_recperson.per_firstname,
                    l_recperson.per_lastname);
            pkg_sampleheaderitem.p_write (
                p_sph_id,
                p_lan_id,
                l_reccodevaluedeterminator.cvl_id,
                l_recimportprotocolheader.iph_ptv_id,
                pkg_sampleheaderitem.cst_typecodefromtableperson,
                l_person,
                l_recimportprotocolheader.iph_per_id_determinator,
                p_usr_id,
                l_shm_id);
        END IF;

        IF NOT l_recimportprotocolheader.iph_operator IS NULL
        THEN
            pkg_sampleheaderitem.p_write (
                p_sph_id,
                p_lan_id,
                l_reccodevalueoperator.cvl_id,
                l_recimportprotocolheader.iph_ptv_id,
                pkg_sampleheaderitem.cst_typecodefromexcelform,
                l_recimportprotocolheader.iph_operator,
                NULL,
                p_usr_id,
                l_shm_id);
        END IF;

        IF NOT l_recimportprotocolheader.iph_determinator IS NULL
        THEN
            pkg_sampleheaderitem.p_write (
                p_sph_id,
                p_lan_id,
                l_reccodevaluedeterminator.cvl_id,
                l_recimportprotocolheader.iph_ptv_id,
                pkg_sampleheaderitem.cst_typecodefromexcelform,
                l_recimportprotocolheader.iph_determinator,
                NULL,
                p_usr_id,
                l_shm_id);
        END IF;

        -- On sauve la localité
        IF NOT l_recimportprotocolheader.iph_locality IS NULL
        THEN
            pkg_sampleheaderitem.p_write (
                p_sph_id,
                p_lan_id,
                l_recordvaluelocality.cvl_id,
                l_recimportprotocolheader.iph_ptv_id,
                pkg_sampleheaderitem.cst_typecodefromexcelform,
                l_recimportprotocolheader.iph_locality,
                NULL,
                p_usr_id,
                l_shm_id);
        END IF;

        -- On sauve la rivière
        IF NOT l_recimportprotocolheader.iph_watercourse IS NULL
        THEN
            pkg_sampleheaderitem.p_write (
                p_sph_id,
                p_lan_id,
                l_recordvaluewatercourse.cvl_id,
                l_recimportprotocolheader.iph_ptv_id,
                pkg_sampleheaderitem.cst_typecodefromexcelform,
                l_recimportprotocolheader.iph_watercourse,
                NULL,
                p_usr_id,
                l_shm_id);
        END IF;

        -- On sauve le report_url
        IF NOT l_recimportprotocolheader.iph_reporturl IS NULL
        THEN
            pkg_sampledocument.p_write (
                p_sph_id,
                l_recimportprotocolheader.iph_ptv_id,
                l_recimportprotocolheader.iph_reporturl,
                NULL                                                 -- title;
                    ,
                p_usr_id,
                l_spt_id);
        END IF;

        p_savelaboprotocoldetail (l_recimportprotocolheader,
                                  p_sph_id,
                                  p_usr_id);

        pkg_importprotocolheader.p_updatevalidatestatus (
            l_recimportprotocolheader.iph_id,
            pkg_importprotocolheader.cst_validstatusok,
            p_usr_id);
   
        COMMIT;
    EXCEPTION
        WHEN OTHERS
        THEN
            pkg_exception.p_putexception2cache;
    END;



    /*-------------------------------------------------------------------------------------------------*/

    PROCEDURE p_validateconfirm (
        p_iph_id             IN     importprotocollog.ipo_iph_id%TYPE,
        p_lan_id             IN     language.lan_id%TYPE,
        p_usr_id             IN     sampleheader.sph_usr_id_create%TYPE,
        p_visibilitystatus   IN     sampleheader.sph_visibilitystatus%TYPE,
        p_publicstatus       IN     VARCHAR2,
        p_sph_id                OUT sampleheader.sph_id%TYPE)
    /*-------------------------------------------------------------------------------------------------*/
    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_recprotocolversion        protocolversion%ROWTYPE;
        l_reccodevalue              codevalue%ROWTYPE;
        l_recdesignationprotocol    codedesignation%ROWTYPE;
        l_recsampleheader           sampleheader%ROWTYPE;
        l_cvl_id_protocoltype       protocolversion.ptv_cvl_id_protocoltype%TYPE;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecordbyiphid (p_iph_id);

        IF NOT l_recsampleheader.sph_id IS NULL
        THEN
            RAISE pkg_exception.exc_saveallreadydone;
        END IF;


        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);

        IF l_recimportprotocolheader.iph_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'PKG_IMPORTPROTOCOL.f_getrecord('
                || TO_CHAR (p_iph_id)
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;



        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                l_recimportprotocolheader.iph_ptv_id);

        IF l_recprotocolversion.ptv_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'PKG_PROTOCOLVERSION.f_getrecord('
                || TO_CHAR (l_recimportprotocolheader.iph_ptv_id)
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;


        l_reccodevalue :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);

        IF l_reccodevalue.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'PKG_CODEVALUE.f_getrecord('
                || TO_CHAR (l_recprotocolversion.ptv_cvl_id_protocoltype)
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;


        l_recdesignationprotocol :=
            pkg_codedesignation.f_returnrecmaintypeatleastone (
                l_reccodevalue.cvl_id,
                p_lan_id);

        IF l_recdesignationprotocol.cdn_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codedesignation.f_returnrecmaintypeatleastone('
                || TO_CHAR (l_reccodevalue.cvl_id)
                || ','
                || TO_CHAR (p_lan_id)
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;



        IF l_recimportprotocolheader.iph_validstatus !=
           pkg_importprotocolheader.cst_validstatusok
        THEN
            pkg_message.p_setparameter (
                l_recdesignationprotocol.cdn_designation,
                1);
            pkg_message.p_setparameter (
                l_recimportprotocolheader.iph_inputfilename,
                2);
            DBMS_OUTPUT.put_line ('raise');
            RAISE pkg_exception.exc_protocanotbesave;
        END IF;

        DBMS_OUTPUT.put_line ('cvl_code=' || l_reccodevalue.cvl_code);
        l_cvl_id_protocoltype :=
            pkg_sampleheader.f_checkprotocoleallreadyexist (p_iph_id);



        CASE l_reccodevalue.cvl_code
            WHEN pkg_codevalue.cst_protocoltype_laboratory
            THEN
                p_savelaboprotocol (p_iph_id,
                                    p_lan_id,
                                    p_usr_id,
                                    p_visibilitystatus,
                                    p_publicstatus,
                                    p_sph_id);
                pkg_sampleprotocollabo.p_routeupdatesortorder (p_sph_id);
                NULL;
            WHEN pkg_codevalue.cst_protocoltype_grdeval
            THEN
                IF NOT l_cvl_id_protocoltype IS NULL
                THEN
                    -- Le protocole existe déjà. il faut le remplacer
                    l_recsampleheader :=
                        pkg_sampleheader.f_returnsampleheaderbyiphid (
                            p_iph_id);
                    pkg_sampleprotocolgrid.p_deleteby_sph_id (
                        l_recsampleheader.sph_id);
                    pkg_sampleheaderfile.p_deleteby_cvl_id_protocoltype (
                        l_recsampleheader.sph_id,
                        l_cvl_id_protocoltype);
                    pkg_sampleheaderitem.p_deleteby_cvl_id_protocoltype (
                        l_recsampleheader.sph_id,
                        l_cvl_id_protocoltype);
                END IF;

                p_saveprotocolnotlabo (p_iph_id,
                                       p_lan_id,
                                       p_usr_id,
                                       l_reccodevalue.cvl_code,
                                       p_sph_id);
                NULL;
            WHEN pkg_codevalue.cst_protocoltype_ground
            THEN
                IF NOT l_cvl_id_protocoltype IS NULL
                THEN
                    -- Le protocole existe déjà. il faut le remplacer
                    l_recsampleheader :=
                        pkg_sampleheader.f_returnsampleheaderbyiphid (
                            p_iph_id);
                    pkg_sampleprotocolgrnd.p_deleteby_sph_id (
                        l_recsampleheader.sph_id);
                    pkg_sampleheaderfile.p_deleteby_cvl_id_protocoltype (
                        l_recsampleheader.sph_id,
                        l_cvl_id_protocoltype);
                    pkg_sampleheaderitem.p_deleteby_cvl_id_protocoltype (
                        l_recsampleheader.sph_id,
                        l_cvl_id_protocoltype);
                END IF;

                p_saveprotocolnotlabo (p_iph_id,
                                       p_lan_id,
                                       p_usr_id,
                                       l_reccodevalue.cvl_code,
                                       p_sph_id);
                NULL;
            WHEN pkg_codevalue.cst_protocoltype_mass
            THEN
                p_saveprotocolmass (l_recimportprotocolheader,
                                    p_lan_id,
                                    p_usr_id,
                                    p_visibilitystatus,
                                    p_publicstatus);
            ELSE
                NULL;
        END CASE;

        pkg_debug.p_write ('pkg_validate.p_validateconfirm', 'ok');
    /*
 EXCEPTION
    WHEN OTHERS
    THEN
       pkg_exception.p_putexception2cache;
       */
    END;

    /*-------------------------------------------------------------------------------------------------*/

    PROCEDURE p_validateconfirm (
        p_iph_id   IN     importprotocollog.ipo_iph_id%TYPE,
        p_lan_id   IN     language.lan_id%TYPE,
        p_usr_id   IN     sampleheader.sph_usr_id_create%TYPE,
        p_sph_id      OUT sampleheader.sph_id%TYPE)
    /*-------------------------------------------------------------------------------------------------*/
    IS
    BEGIN
        p_validateconfirm (p_iph_id,
                           p_lan_id,
                           p_usr_id,
                           NULL,
                           NULL,
                           p_sph_id);
    END;
END pkg_validate;
/

