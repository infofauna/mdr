create PACKAGE       pkg_importmassdatadetail
AS
   /******************************************************************************
      NAME:       pkg_importmassdatadetail
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
      2.0         11.07.2017     burrif       2. Fonctionnalité version 2
      2.1         27.10.2019     burrif       3. Les détails invalides sont associés à un IMH_ID
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_returnfirstsystfieldfilled (
      p_recimportmassdatadetail   IN importmassdatadetail%ROWTYPE)
      RETURN importmassdatadetail.imd_species%TYPE;

   FUNCTION f_getinvalidrowcount (
      p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
      RETURN NUMBER;

   FUNCTION f_getvalidrowcount (
      p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
      RETURN NUMBER;

   PROCEDURE p_purgeorphan;

   PROCEDURE p_cleargblcounter;

   FUNCTION f_buildsourceline (
      p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
      RETURN VARCHAR2;

   FUNCTION f_buildsourcelinefilled (
      p_imh_id      IN importmassdatadetail.imd_imh_id%TYPE,
      p_fieldname   IN VARCHAR2)
      RETURN VARCHAR2;

   FUNCTION f_countfieldfilled (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_codemidatfldcmt           protocolmappingmassfield.pmm_code_midatfldcmt%TYPE)
      RETURN NUMBER;

   FUNCTION f_getrowcount (p_iph_id IN importmassdatadetail.imd_iph_id%TYPE)
      RETURN NUMBER;

   PROCEDURE p_setgbliphid (p_iph_id IN NUMBER);

   PROCEDURE p_setgblrownum (p_rownum IN NUMBER);

   PROCEDURE p_setsyv_id (p_imd_id   IN importmassdatadetail.imd_id%TYPE,
                          p_syv_id   IN importmassdatadetail.imd_syv_id%TYPE);

   PROCEDURE p_setptl_id (p_imd_id   IN importmassdatadetail.imd_id%TYPE,
                          p_ptl_id   IN importmassdatadetail.imd_ptl_id%TYPE);

   PROCEDURE p_setcvl_id_zoostadium (
      p_imd_id              IN importmassdatadetail.imd_id%TYPE,
      p_cvl_id_zoostadium   IN importmassdatadetail.imd_cvl_id_zoostadium%TYPE);

   PROCEDURE p_identifyheader (
      p_iph_id     IN     importmassdatadetail.imd_iph_id%TYPE,
      p_lan_id     IN     language.lan_id%TYPE,
      p_rowcount      OUT NUMBER);

   PROCEDURE p_setvalidstatus (
      p_imd_id   IN importmassdatadetail.imd_id%TYPE,
      p_status   IN importmassdatadetail.imd_validstatus%TYPE);

   PROCEDURE p_setvalidstatusbyimh_id (
      p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE,
      p_status   IN importmassdatadetail.imd_validstatus%TYPE);

   PROCEDURE p_deletebyiph_id (
      p_iph_id   IN importmassdatadetail.imd_iph_id%TYPE);

   PROCEDURE p_clearlistfieldheader (
      p_iph_id   IN importmassmappingheader.ime_iph_id%TYPE);

   PROCEDURE p_addlistfieldheader (
      p_aliascolumnname   IN protocolmappingmassmap.pma_aliascolumnname%TYPE,
      p_column            IN PLS_INTEGER);

   PROCEDURE p_addfielddata (p_column IN PLS_INTEGER, p_value IN VARCHAR2);

   PROCEDURE p_flushfielddata;

   PROCEDURE p_saveprotocolmassdetail (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_importmassdataheader      IN importmassdataheader%ROWTYPE,
      p_sph_id                    IN sampleheader.sph_id%TYPE,
      p_lan_id                    IN language.lan_id%TYPE,
      p_usr_id                    IN sampleprotocolgrnd.spd_usr_id_create%TYPE);

   PROCEDURE p_deletebyimhid (
      p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE);

   FUNCTION f_getrecord (p_imd_id IN importmassdatadetail.imd_id%TYPE)
      RETURN importmassdatadetail%ROWTYPE;
END pkg_importmassdatadetail;
/

