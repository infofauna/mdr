create PACKAGE BODY       pkg_indice_utility
AS
   /******************************************************************************
      NAME:       PKG_INDICE_UTILITY
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        07/04/2014      burrif       1. Created this package.


Nom    Niveau
Asellus    SS_GENRE
Asellus    GENRE    OK
asellus    ESPECE
asellus    SS_ESPECE
Baetidae    FAMILLE    OK
Ephemeroptera    ORDRE    OK
Gammarus    GENRE    OK
Gammarus    SS_GENRE
Hirudinea    CLASSE    OK
Plecoptera    ORDRE    OK
Trichoptera    ORDRE    OK
Tubificidae    FAMILLE    OK

Calcul des unités taxonomiques nécessaires à la détermination de l'indice Makroindex
Regroupement des espèces dans la hiérarchie taxonomique de %p1% (%p2%)
 sp. (inféré à partir du taxon %p1% (%p2%)
 %p1%
Total du regroupement %p1%. Nombre d'insecte: %p2%. Nonbre de non-insecte %p3%
Regroupement des genres dans la hiérarchie taxonomique de %p1% (%p2%)
 sp. (inféré à partir du taxon %p1% (%p2%)
 %p1%
Total du regroupement %p1%. Nombre d'insecte: %p2%. Nonbre de non-insecte %p3%
Regroupement des familles dans la hiérarchie taxonomique de %p1% (%p2%)
 sp. (inféré à partir du taxon %p1% (%p2%)
 %p1%
Total du regroupement %p1%. Nombre d'insecte: %p2%. Nonbre de non-insecte %p3%
Regroupement des taxons supérieurs dans la hiérarchie taxonomique de %p1% (%p2%)
 sp. (inféré à partir du taxon %p1% (%p2%)
 %p1%
Total du regroupement %p1%. Nombre d'insecte: %p2%. Nonbre de non-insecte %p3%
Total global: Nombre d'insecte=%p1%. Nombre de non-insecte=%p2%. Rapport Insecte/non-insecte=%p2%
Inventaire des taxons nécessaires à la détermination de l'indice Makroindex
-- Pour  les plecoptere, tricopthere, plecoptere + tricopthere, ephemeropter, baetidae
Nombre d'individu de %p1% (par m2) = %p2%. Nombre d'unité retenue pour le calcul de l'indice = %p3%
-- Pour les cammarus, hydropsyche,Asellus, Hirudinea Tubificidae
Nombre d'individu de %p1% (par m2) = %p2%.
Il découle de l'inventaire des taxons que l'indice Mackoindex peut être déterminé sur la base du cas: %p1%

   ******************************************************************************/


   cst_packageversion      CONSTANT VARCHAR2 (30) := 'Version 1.0, avril  2014';
   cst_maxvalue            CONSTANT NUMBER := 999999999;
   cst_gi_undef            CONSTANT NUMBER := -999999;


   gbl_listibchvalue                t_listibchvalue := t_listibchvalue ();
   gbl_listibchvaluemass            t_listibchvaluemass
                                       := t_listibchvaluemass ();
   gbl_listspearvalue               t_listspearvalue := t_listspearvalue ();
   gbl_mki_range_selected           VARCHAR2 (10) := NULL;
   gbl_mki_range_count              NUMBER := 0;
   gbl_mki_errornumber              NUMBER := NULL;
   gbl_mki_cvl_code_case            codevalue.cvl_code%TYPE := NULL;
   gbl_mki_non_insecta_count        NUMBER := 0;
   gbl_mki_insecta_count            NUMBER := 0;
   gbl_mki_has_baetidae             CHAR (1) := pkg_constante.cst_no;
   gbl_mki_normalizedcount          NUMBER := 0;
   gbl_mkidispatchlist              t_mkidispatchlist;



   gbl_mki_reference                t_listmkireference;
   gbl_mki_totalcounter             NUMBER := 0;
   gbl_insectanoninsectaratio       NUMBER := 0;

   gbl_ibch_vt                      NUMBER := 0;
   gbl_ibch_gi                      NUMBER := 0;
   gbl_ibchidentifiedtaxoncounter   NUMBER := 0;
   gbl_mkiexculetricoptera          NUMBER := 0;


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*------------------------------------------------------------------*/
   PROCEDURE p_test
   /*-----------------------------------------------------------------*/
   IS
      l_recimportprotocolheader      importprotocolheader%ROWTYPE;

      CURSOR l_cursor
      IS
         SELECT *
           FROM importmassdatadetail
          WHERE imd_imh_id = 14961;

      l_reccursor                    l_cursor%ROWTYPE;
      l_valueindiceibch              NUMBER;
      l_ibchidentifiedtaxoncounter   NUMBER;
   BEGIN
      l_recimportprotocolheader := pkg_importprotocolheader.f_getrecord (27);
      pkg_indice_utility.p_initlistibchvaluemass;

      OPEN l_cursor;

      LOOP
         FETCH l_cursor INTO l_reccursor;

         EXIT WHEN l_cursor%NOTFOUND;
         DBMS_OUTPUT.put_line (
            'l_reccursor.imd_syv_id=' || l_reccursor.imd_syv_id);
         pkg_indice_utility.p_addlistibchvaluemass (l_reccursor.imd_syv_id,
                                                    l_reccursor.imd_freq1);
      END LOOP;

      CLOSE l_cursor;

      pkg_indice_utility.p_convertmass2ibch (
         l_recimportprotocolheader.iph_ptv_id,
         l_recimportprotocolheader.iph_id,
         l_reccursor.imd_imh_id);
      l_valueindiceibch :=
         pkg_indice_utility.f_computeibchfrommemory (
            pkg_indice_utility.cst_abondanceflag_absolu);
      DBMS_OUTPUT.put_line (' l_valueindiceibch=' || l_valueindiceibch);
      l_ibchidentifiedtaxoncounter :=
         pkg_indice_utility.f_getgblibchidentifiedtaxoncou;
   END;



   /*----------------------------------------------------------------*/
   FUNCTION f_gblmkiexculetricoptera
      RETURN NUMBER
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mkiexculetricoptera;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_getgblibchvt
      RETURN NUMBER
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_ibch_vt;
   END;

   /*----------------------------------------------------------------*/
   FUNCTION f_getgblibchgi
      RETURN NUMBER
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_ibch_gi;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getgblibchidentifiedtaxoncou
      RETURN NUMBER
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_ibchidentifiedtaxoncounter;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getgblnormalizedcount
      RETURN NUMBER
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_normalizedcount;
   END;


   /*---------------------------------------------------------------*/
   FUNCTION f_getgblrangecount
      RETURN NUMBER
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_range_count;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getgblinsectacount
      RETURN NUMBER
   /*----------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_insecta_count;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_clearmkigbl
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      gbl_mkidispatchlist.delete;
      gbl_mki_range_selected := NULL;
      gbl_mki_errornumber := NULL;
      gbl_mki_cvl_code_case := NULL;
      gbl_mki_reference.delete;
      gbl_mki_totalcounter := 0;
      gbl_insectanoninsectaratio := 0;
      gbl_mki_insecta_count := 0;
      gbl_mki_non_insecta_count := 0;
      gbl_mki_range_count := 0;
      gbl_mki_has_baetidae := pkg_constante.cst_no;
      gbl_mki_normalizedcount := NULL;
      gbl_mkiexculetricoptera := 0;
   END;


   /*---------------------------------------------------------------*/
   FUNCTION f_getmkierror
      RETURN NUMBER
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_errornumber;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getmkinoninsectacount
      RETURN NUMBER
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_non_insecta_count;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_getmkicvlcodecase
      RETURN codevalue.cvl_code%TYPE
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_cvl_code_case;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_initlistibchvaluemass
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      gbl_ibchidentifiedtaxoncounter := 0;
      gbl_listibchvaluemass.delete;
   END;

   /*--------------------------------------------------------------*/
   PROCEDURE p_addlistibchvaluemass (p_syv_id   IN systvalue.syv_id%TYPE,
                                     p_count       NUMBER)
   /*--------------------------------------------------------------*/
   IS
   BEGIN
      gbl_listibchvaluemass.EXTEND (1);
      -- Si p_syv_id est un synomyme on va chercher le parent

      gbl_listibchvaluemass (gbl_listibchvaluemass.LAST).ibm_syv_id :=
         p_syv_id;
      gbl_listibchvaluemass (gbl_listibchvaluemass.LAST).ibm_counter :=
         p_count;
   END;



   FUNCTION f_normaliseabondance (p_value           IN NUMBER,
                                  p_abondanceflag   IN VARCHAR2)
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      /* Selon commentaire dans le feuille "protocole de laboratoire"
          les abondances entre
            1 et 10 sont des nombres absolu
            11 et 100 => 11
            101 et 1000 => 101
            > 1000 => 1001

            Si p_abondanceflag= cst_abondanceflag_absolu  alors toute les valeurs sont en absolue
         */

      l_value   NUMBER;
   BEGIN
      IF NVL (p_abondanceflag, cst_abondanceflag_class) =
            cst_abondanceflag_absolu
      THEN
         RETURN p_value;
      END IF;

      -- Selon des classes
      CASE
         WHEN p_value >= 0 AND p_value <= 10
         THEN
            l_value := p_value;
         WHEN p_value >= 11 AND p_value <= 100
         THEN
            l_value := 11;
         WHEN p_value >= 101 AND p_value <= 1000
         THEN
            l_value := 101;
         WHEN p_value > 1000
         THEN
            l_value := 1001;
         ELSE
            l_value := NULL;
      END CASE;

      RETURN l_value;
   END;

   /*-----------------------------------------------------------------*/
   FUNCTION f_spearreturnlistvalue
      RETURN t_listspearvalue
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_listspearvalue;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_spearadddata (
      p_syv_id    IN     speardatalinkcscf.sdf_syv_id%TYPE,
      p_counter   IN     NUMBER,
      p_status       OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_spearindexfactor   speardatalinkcscf.sdf_spearindex%TYPE;
   BEGIN
      l_spearindexfactor :=
         pkg_speardatalinkcscf.f_routereturnspearindex (p_syv_id);

      IF l_spearindexfactor IS NULL
      THEN
         p_status := pkg_constante.cst_returnstatusnotok;
      ELSE
         p_status := pkg_constante.cst_returnstatusok;

         gbl_listspearvalue.EXTEND (1);
         gbl_listspearvalue (gbl_listspearvalue.LAST).spr_syv_id := p_syv_id;
         gbl_listspearvalue (gbl_listspearvalue.LAST).spr_spearindexfactor :=
            l_spearindexfactor;
         gbl_listspearvalue (gbl_listspearvalue.LAST).spr_counter := p_counter;
      END IF;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_spearadddataclass (
      p_syv_id    IN     speardatalinkcscf.sdf_syv_id%TYPE,
      p_counter   IN     NUMBER,
      p_status       OUT NUMBER)
   /*-----------------------------------------------------------------*/
   IS
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
   BEGIN
      l_recabundanceclassrange :=
         pkg_abundanceclassrange.f_getrecordbyclass (
            pkg_codevalue.cst_midatfldcmt_makroindex,
            p_counter);
      p_spearadddata (p_syv_id,
                      l_recabundanceclassrange.acr_substitutevalue,
                      p_status);
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_loadspearlistfromibchlist (
      p_iph_id   IN importprotocolheader.iph_id%TYPE)
   /*----------------------------------------------------------------*/
   IS
      /* Pour le calcul du spear index à partir des données de l'iBCH, on
          copie les élément d'un table vers l'autre
          ATTENTION: On admet que le speraindexfactor est renseigné dans la table PROTOCOLMAPPINGLABO

          */
      l_indiceibch               PLS_INTEGER;
      l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
      l_header                   BOOLEAN := FALSE;
      l_counter                  NUMBER := 0;
   BEGIN
      p_spearvalueinit;
      l_indiceibch := gbl_listibchvalue.FIRST;

      WHILE NOT l_indiceibch IS NULL
      LOOP
         l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecord (
               gbl_listibchvalue (l_indiceibch).ibc_ptl_id);

         IF l_recprotocolmappinglabo.ptl_spearindexfactor !=
               pkg_protocolmappinglabo.cst_spearindexfactor_noset
         THEN
            gbl_listspearvalue.EXTEND (1);
            gbl_listspearvalue (gbl_listspearvalue.LAST).spr_syv_id :=
               l_recprotocolmappinglabo.ptl_syv_id;
            gbl_listspearvalue (gbl_listspearvalue.LAST).spr_spearindexfactor :=
               l_recprotocolmappinglabo.ptl_spearindexfactor;
            gbl_listspearvalue (gbl_listspearvalue.LAST).spr_counter :=
               gbl_listibchvalue (l_indiceibch).ibc_counter;
         ELSE
            IF NOT l_header
            THEN
               pkg_importprotocollog.p_writelog (
                  p_iph_id,
                  NULL,
                  pkg_exception.cst_taxanotusedforcomputespear,
                  NULL);
               l_header := TRUE;
            END IF;

            l_counter := l_counter + 1;

            pkg_importprotocollog.p_writelog (
               p_iph_id,
               NULL,
               pkg_exception.cst_info,
               NULL,
                  TO_CHAR (l_counter)
               || '. '
               || l_recprotocolmappinglabo.ptl_taxa);
         END IF;

         l_indiceibch := gbl_listibchvalue.NEXT (l_indiceibch);
      END LOOP;
   END;

   /*----------------------------------------------------------*/
   FUNCTION f_computespearfrommemory (p_abondanceflag IN VARCHAR2)
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_indicespear    PLS_INTEGER;
      l_abondance      NUMBER;
      l_numerateur     NUMBER;
      l_denominateur   NUMBER;
      l_spearvalue     NUMBER;
   BEGIN
      l_numerateur := 0;
      l_denominateur := 0;
      l_indicespear := gbl_listspearvalue.FIRST;

      WHILE NOT l_indicespear IS NULL
      LOOP
         l_abondance :=
            f_normaliseabondance (
               gbl_listspearvalue (l_indicespear).spr_counter,
               p_abondanceflag);
         l_numerateur :=
              l_numerateur
            +   LOG (10, l_abondance + 1)
              * gbl_listspearvalue (l_indicespear).spr_spearindexfactor;
         l_denominateur := l_denominateur + LOG (10, l_abondance + 1);
         l_indicespear := gbl_listspearvalue.NEXT (l_indicespear);
      END LOOP;

      IF l_denominateur = 0
      THEN
         RETURN NULL;
      END IF;

      l_spearvalue := l_numerateur / l_denominateur * 100;
      RETURN ROUND (l_spearvalue, 1);
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_getgblmkitotalcounter
      RETURN NUMBER
   /*------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_totalcounter;
   END;


   /*-----------------------------------------------------------*/

   FUNCTION f_getgblmkirangeselected
      RETURN VARCHAR2
   /*------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_range_selected;
   END;

   /*------------------------------------------------------------*/

   FUNCTION f_getgblmkireference
      RETURN t_listmkireference
   /*------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mki_reference;
   END;

   /*-------------------------------------------------------------*/
   FUNCTION f_getgblmkidispatchlist
      RETURN t_mkidispatchlist
   /*-------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_mkidispatchlist;
   END;


   /*-------------------------------------------------------------*/
   FUNCTION f_getgblmkiinsectaratio
      RETURN NUMBER
   /*------------------------------------------------------------*/
   IS
   BEGIN
      RETURN gbl_insectanoninsectaratio;
   END;

   /*---------------------------------------------------------------------------------*/
   PROCEDURE p_checkmkiidentifylist (
      p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                    IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id                    IN     language.lan_id%TYPE,
      p_returnstatus                 OUT NUMBER)
   /*---------------------------------------------------------------------------------*/
   IS
      CURSOR l_mkiidentifygroupcounter
      IS
           SELECT *
             FROM mkiidentifygroupcounter
         ORDER BY mig_searchorder;

      l_recmkiidentifygroupcounter   l_mkiidentifygroupcounter%ROWTYPE;
      l_recsystdesignation           systdesignation%ROWTYPE;
      l_reccordereference            codereference%ROWTYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;

      OPEN l_mkiidentifygroupcounter;

      LOOP
         FETCH l_mkiidentifygroupcounter INTO l_recmkiidentifygroupcounter;

         EXIT WHEN l_mkiidentifygroupcounter%NOTFOUND;
         l_reccordereference :=
            pkg_codereference.f_getrecord (
               l_recmkiidentifygroupcounter.mig_crf_id);
         l_recsystdesignation :=
            pkg_systdesignation.f_getrecordbyleveldesignation (
               l_recmkiidentifygroupcounter.mig_taxonname,
               l_reccordereference.crf_code);

         IF l_recsystdesignation.syd_id IS NULL
         THEN
            -- L''entrée %p1%  définie pour le calcul du rapport insecte/non-insecte  n'a pas pu être identifié dan sle thésaurus
            pkg_importprotocollog.p_writelog (
               p_recimportprotocolheader.iph_id,
               NULL,                                                 -- IMH_ID
               pkg_exception.cst_mkientryrationotfound,
               NULL,                                             -- Field name
               l_recmkiidentifygroupcounter.mig_taxonname);
            p_returnstatus := pkg_constante.cst_returnstatusnotok;
         END IF;
      END LOOP;

      CLOSE l_mkiidentifygroupcounter;
   END;


   /*-------------------------------------------------------------*/
   PROCEDURE p_mkicheckthesaurus (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id                 IN     language.lan_id%TYPE,
      p_returnstatus              OUT NUMBER)
   /*------------------------------------------------------------*/
   IS
      /* Permet de contrôler que tous les textes (plecoptera, etc) nécessaires au calcul
      de l'indice mokroindex */
      l_returnstatus   NUMBER;
      l_key            systdesignation.syd_designation%TYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;


      pkg_importprotocollog.p_writelog (
         p_importprotocolheader.iph_id,
         NULL,                                                       -- IMH_ID
         pkg_exception.cst_mkithesaurusentrycheck,
         NULL);                                                   -- FIELDNAME
      l_key := gbl_mki_reference.FIRST;


      WHILE NOT l_key IS NULL
      LOOP
         p_mkicheckthesaurusoneentry (p_importprotocolheader,
                                      p_usr_id,
                                      p_lan_id,
                                      l_key,
                                      gbl_mki_reference (l_key).mki_crf_code,
                                      l_returnstatus);

         IF l_returnstatus != pkg_constante.cst_returnstatusok
         THEN
            p_returnstatus := l_returnstatus;
         END IF;

         l_key := gbl_mki_reference.NEXT (l_key);
      END LOOP;

      IF p_returnstatus != pkg_constante.cst_returnstatusok
      THEN
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,                                                    -- IMH_ID
            pkg_exception.cst_mkiicannotbecomputed,
            NULL);                                                -- FIELDNAME
      END IF;
   END;

   /*-------------------------------------------------------------*/

   PROCEDURE p_mkicheckthesaurusoneentry (
      p_importprotocolheader   IN     importprotocolheader%ROWTYPE,
      p_usr_id                 IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_lan_id                 IN     language.lan_id%TYPE,
      p_mkidesignation         IN     systdesignation.syd_designation%TYPE,
      p_mkicrfcode             IN     codereference.crf_code%TYPE,
      p_returnstatus              OUT NUMBER)
   /*------------------------------------------------------------*/
   IS
      l_recsystdesignation   systdesignation%ROWTYPE;
   BEGIN
      p_returnstatus := pkg_constante.cst_returnstatusok;
      l_recsystdesignation :=
         pkg_systdesignation.f_getrecordbyleveldesignation (p_mkidesignation,
                                                            p_mkicrfcode);

      IF l_recsystdesignation.syd_id IS NULL
      THEN
         p_returnstatus := pkg_constante.cst_returnstatusnotok;
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,                                                    -- IMH_ID
            pkg_exception.cst_mkithesaurusentrynotfound,
            NULL,                                                 -- FIELDNAME
            p_mkidesignation,
            p_mkicrfcode);
      ELSE
         pkg_importprotocollog.p_writelog (
            p_importprotocolheader.iph_id,
            NULL,                                                    -- IMH_ID
            pkg_exception.cst_mkithesaurusentryfound,
            NULL,                                                 -- FIELDNAME
            p_mkidesignation,
            p_mkicrfcode);
      END IF;

      NULL;
   END;

   /*------------------------------------------------------------*/

   PROCEDURE p_ibchinit
   /*------------------------------------------------------------*/
   IS
   BEGIN
      gbl_listibchvalue.delete;
      gbl_ibch_vt := 0;
      gbl_ibch_gi := 0;
      gbl_ibchidentifiedtaxoncounter := 0;
   END;

   /*------------------------------------------------------------*/

   PROCEDURE p_spearvalueinit
   /*------------------------------------------------------------*/
   IS
   BEGIN
      gbl_listspearvalue.delete;
   END;


   /*-------------------------------------------------------------*/
   PROCEDURE p_mkiinit
   /*------------------------------------------------------------*/
   IS
   BEGIN
      gbl_mkidispatchlist.delete;
      gbl_mki_non_insecta_count := 0;
      gbl_mki_range_selected := NULL;
      gbl_mki_errornumber := NULL;
      gbl_mki_cvl_code_case := NULL;
      gbl_mki_reference.delete;
      gbl_mki_totalcounter := 0;
      gbl_insectanoninsectaratio := 0;
      gbl_mkiexculetricoptera := 0;

      gbl_mki_reference (cst_mki_plecoptera).mki_counter := 0;
      gbl_mki_reference (cst_mki_plecoptera).mki_crf_code :=
         cst_mki_plecoptera_crf_code;
      gbl_mki_reference (cst_mki_plecoptera).mki_normalizedcounter := 0;
      gbl_mki_reference (cst_mki_plecoptera).mki_normalizedcountflag :=
         pkg_constante.cst_yes;

      gbl_mki_reference (cst_mki_trichoptera).mki_counter := 0;
      gbl_mki_reference (cst_mki_trichoptera).mki_crf_code :=
         cst_mki_trichoptera_crf_code;
      gbl_mki_reference (cst_mki_trichoptera).mki_normalizedcounter := 0;
      gbl_mki_reference (cst_mki_trichoptera).mki_normalizedcountflag :=
         pkg_constante.cst_yes;

      gbl_mki_reference (cst_mki_ephemeroptera).mki_counter := 0;
      gbl_mki_reference (cst_mki_ephemeroptera).mki_crf_code :=
         cst_mki_ephemeroptera_crf_code;
      gbl_mki_reference (cst_mki_ephemeroptera).mki_normalizedcounter := 0;
      gbl_mki_reference (cst_mki_ephemeroptera).mki_normalizedcountflag :=
         pkg_constante.cst_yes;

      gbl_mki_reference (cst_mki_baetidae).mki_counter := 0;
      gbl_mki_reference (cst_mki_baetidae).mki_crf_code :=
         cst_mki_baetidae_crf_code;
      gbl_mki_reference (cst_mki_baetidae).mki_normalizedcounter := 0;
      gbl_mki_reference (cst_mki_baetidae).mki_normalizedcountflag :=
         pkg_constante.cst_yes;

      gbl_mki_reference (cst_mki_gammarus).mki_counter := 0;
      gbl_mki_reference (cst_mki_gammarus).mki_crf_code :=
         cst_mki_gammarus_crf_code;
      gbl_mki_reference (cst_mki_gammarus).mki_normalizedcounter := 0;
      gbl_mki_reference (cst_mki_gammarus).mki_normalizedcountflag :=
         pkg_constante.cst_no;

      gbl_mki_reference (cst_mki_hydropsyche).mki_counter := 0;
      gbl_mki_reference (cst_mki_hydropsyche).mki_crf_code :=
         cst_mki_hydropsyche_crf_code;
      gbl_mki_reference (cst_mki_hydropsyche).mki_normalizedcounter := 0;
      gbl_mki_reference (cst_mki_hydropsyche).mki_normalizedcountflag :=
         pkg_constante.cst_no;


      gbl_mki_reference (cst_mki_asellus).mki_counter := 0;
      gbl_mki_reference (cst_mki_asellus).mki_crf_code :=
         cst_mki_asellus_crf_code;
      gbl_mki_reference (cst_mki_asellus).mki_normalizedcounter := 0;
      gbl_mki_reference (cst_mki_asellus).mki_normalizedcountflag :=
         pkg_constante.cst_no;


      gbl_mki_reference (cst_mki_hirudinea).mki_counter := 0;
      gbl_mki_reference (cst_mki_hirudinea).mki_crf_code :=
         cst_mki_hirudinea_crf_code;
      gbl_mki_reference (cst_mki_hirudinea).mki_normalizedcounter := 0;
      gbl_mki_reference (cst_mki_hirudinea).mki_normalizedcountflag :=
         pkg_constante.cst_no;


      gbl_mki_reference (cst_mki_tubificidae).mki_counter := 0;
      gbl_mki_reference (cst_mki_tubificidae).mki_crf_code :=
         cst_mki_tubificidae_crf_code;
      gbl_mki_reference (cst_mki_tubificidae).mki_normalizedcounter := 0;
      gbl_mki_reference (cst_mki_tubificidae).mki_normalizedcountflag :=
         pkg_constante.cst_no;
   /*
         gbl_mki_reference (cst_mki_insecta).mki_counter := 0;
         gbl_mki_reference (cst_mki_insecta).mki_crf_code :=
            cst_mki_insecta_crf_code;
         gbl_mki_totalcounter := 0;
   */
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_mkibuilddesignationstart (p_recmkisublist IN t_recmkisublist)
      RETURN VARCHAR2
   /*--------------------------------------------------------------*/
   IS
      l_listdesignation      VARCHAR2 (4096);
      l_indice               PLS_INTEGER;
      l_recsystdesignation   systdesignation%ROWTYPE;
   BEGIN
      l_indice := p_recmkisublist.sub_mkistartsyvidsublist.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         l_recsystdesignation :=
            pkg_systdesignation.f_getrecdesignationbylancode (
               p_recmkisublist.sub_mkistartsyvidsublist (l_indice),
               pkg_language.cst_lan_cde_latin);

         IF l_listdesignation IS NULL
         THEN
            l_listdesignation := l_recsystdesignation.syd_designation;
         ELSE
            l_listdesignation :=
                  l_listdesignation
               || ', '
               || l_recsystdesignation.syd_designation;
         END IF;

         l_indice := p_recmkisublist.sub_mkistartsyvidsublist.NEXT (l_indice);
         NULL;
      END LOOP;

      RETURN l_listdesignation;
      NULL;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_add2mkidispatchlist (
      p_syv_id_mastergroup   IN     systvalue.syv_id%TYPE,
      p_syv_id               IN     systvalue.syv_id%TYPE, -- SYV_ID de l'élément de la hiérarchie de regroupement
      p_syv_id_start         IN     systvalue.syv_id%TYPE, -- SYV_ID de l'élément fourni dans le formulaire
      p_species              IN     VARCHAR2,
      p_mkidispatchlist      IN OUT t_mkidispatchlist)
   /*-------------------------------------------------------------*/
   IS
      l_mkisublist             t_mkisublist;

      l_syv_id_key             PLS_INTEGER;
      l_syv_id                 PLS_INTEGER;
      l_mkistartsyvidsublist   t_mkistartsyvidsublist;
   BEGIN
      pkg_debug.p_write (
         'pkg_indice_utility.p_add2mkidispatchlist',
            'p_syv_id_mastergroup='
         || p_syv_id_mastergroup
         || ' p_syv_id='
         || p_syv_id
         || ' p_syv_id_start='
         || p_syv_id_start
         || ' p_species='
         || p_species);

      IF p_species = cst_species_code
      THEN
         -- Opérateur d'ajour d'une espèce indéterminé dans le regroupement


         IF NOT p_mkidispatchlist.EXISTS (p_syv_id_mastergroup)
         THEN
            l_syv_id := -1;
         ELSE
            l_mkisublist := p_mkidispatchlist (p_syv_id_mastergroup);
            l_syv_id := -1;

            WHILE l_mkisublist.EXISTS (l_syv_id)
            LOOP
               l_syv_id := l_syv_id - 1;
            END LOOP;
         END IF;
      ELSE
         l_syv_id := p_syv_id;
      END IF;

      IF NOT p_mkidispatchlist.EXISTS (p_syv_id_mastergroup)
      THEN
         l_mkistartsyvidsublist := t_mkistartsyvidsublist ();
         l_mkisublist (l_syv_id).sub_counter := 1;


         l_mkisublist (l_syv_id).sub_mkistartsyvidsublist :=
            l_mkistartsyvidsublist;
         l_mkisublist (l_syv_id).sub_mkistartsyvidsublist.EXTEND (1);
         l_mkisublist (l_syv_id).sub_mkistartsyvidsublist (
            l_mkisublist (l_syv_id).sub_mkistartsyvidsublist.LAST) :=
            p_syv_id_start;
         p_mkidispatchlist (p_syv_id_mastergroup) := l_mkisublist;
      ELSE
         l_mkisublist := p_mkidispatchlist (p_syv_id_mastergroup);

         IF NOT l_mkisublist.EXISTS (l_syv_id)
         THEN
            l_mkisublist (l_syv_id).sub_counter := 1;
            l_mkistartsyvidsublist := t_mkistartsyvidsublist ();
            l_mkisublist (l_syv_id).sub_mkistartsyvidsublist :=
               l_mkistartsyvidsublist;
         ELSE
            -- Le l_syv_id ne devrait pas être nécgatif donc pas de  l_mkisublist (l_syv_id).sub_syv_id_upper_sp := l_syv_id_upper_sp;
            l_mkisublist (l_syv_id).sub_counter :=
               l_mkisublist (l_syv_id).sub_counter + 1;
         END IF;

         l_mkisublist (l_syv_id).sub_mkistartsyvidsublist.EXTEND (1);
         l_mkisublist (l_syv_id).sub_mkistartsyvidsublist (
            l_mkisublist (l_syv_id).sub_mkistartsyvidsublist.LAST) :=
            p_syv_id_start;
         p_mkidispatchlist (p_syv_id_mastergroup) := l_mkisublist;
      END IF;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_displaymkidispatch
   /*-------------------------------------------------------------*/
   IS
      l_mkisublist                     t_mkisublist;
      l_syv_id_key_master              PLS_INTEGER;
      l_syv_id_key                     PLS_INTEGER;
      l_recsystdesignation             systdesignation%ROWTYPE;
      l_recsystdesignationupperlevel   systdesignation%ROWTYPE;
      l_reclanguage                    language%ROWTYPE;
      l_first_indice                   PLS_INTEGER;
   BEGIN
      pkg_debug.p_write ('PKG_INDICE_UTILITY.p_displaymkidispatch',
                         'Start list....');
      l_reclanguage :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);
      l_syv_id_key_master := gbl_mkidispatchlist.FIRST;

      WHILE NOT l_syv_id_key_master IS NULL
      LOOP
         l_mkisublist := gbl_mkidispatchlist (l_syv_id_key_master);
         l_recsystdesignation :=
            pkg_systdesignation.f_getrecorddesignation (l_syv_id_key_master,
                                                        l_reclanguage.lan_id);


         pkg_debug.p_write ('PKG_INDICE_UTILITY.p_displaymkidispatch',
                            l_recsystdesignation.syd_designation);
         l_syv_id_key := l_mkisublist.FIRST;

         WHILE NOT l_syv_id_key IS NULL
         LOOP
            IF l_syv_id_key != ABS (l_syv_id_key)
            THEN
               l_first_indice :=
                  l_mkisublist (l_syv_id_key).sub_mkistartsyvidsublist.FIRST;
               l_recsystdesignationupperlevel :=
                  pkg_systdesignation.f_getrecorddesignation (
                     l_mkisublist (l_syv_id_key).sub_mkistartsyvidsublist (
                        l_first_indice),
                     l_reclanguage.lan_id);
               pkg_debug.p_write (
                  'PKG_INDICE_UTILITY.p_displaymkidispatch',
                     '                sp. ('
                  || TO_CHAR (l_syv_id_key)
                  || ') '
                  || l_mkisublist (l_syv_id_key).sub_mkistartsyvidsublist (
                        l_first_indice)
                  || ' '
                  || l_recsystdesignationupperlevel.syd_designation);
            ELSE
               l_recsystdesignation :=
                  pkg_systdesignation.f_getrecorddesignation (
                     l_syv_id_key,
                     l_reclanguage.lan_id);
               pkg_debug.p_write (
                  'PKG_INDICE_UTILITY.p_displaymkidispatch',
                  '                ' || l_recsystdesignation.syd_designation);
            END IF;

            l_syv_id_key := l_mkisublist.NEXT (l_syv_id_key);
         END LOOP;

         l_syv_id_key_master := gbl_mkidispatchlist.NEXT (l_syv_id_key_master);
      END LOOP;

      pkg_debug.p_write ('PKG_INDICE_UTILITY.p_displaymkidispatch',
                         'End list');
   END;



   /*-------------------------------------------------------------*/
   PROCEDURE p_mkidispatch (
      p_syv_id    IN     systvalue.syv_id%TYPE,
      p_species   IN     importmassdatadetail.imd_species%TYPE,
      p_found        OUT BOOLEAN)
   /*-------------------------------------------------------------*/
   IS
      -- p_syv_id : Valeur fournie dans le formulaire
      -- Permet de construire  la liste des différentes espèces, genres, familles, taxon_sup selon le tableau 4
      /*
       Tableau 4:
       | ----------------------------------------------------------------------------------------------------------- |
       | Taxon_SUP                   | Familles des :          |   Genres des :           | Espèces des :    |
       | ------------------------------------------------------------------------------------------------------------ |
       | Classe Nematomorpha   | Gastropoda             | Lamellibranchiata     | Turbellaria           |
       | Classe Nematoda           | Oligochaeta            |  Ephemeroptera*     | Hirudinea             |
       | Ordre Hydracarina          | Baetidae*              | Plecoptera               |  Gammaridea        |
       |                                      | Odonata                | Megaloptera            | Asellota                |
       |                                       | Heteroptera          | Trichoptera             | Coleoptera            |
       |                                       | Chironomidae*      | Diptera *                | Simuliidae             |
       |                                       | Ceratopogonidae* |                               |                             |
       | ------------------------------------------------------------------------------------------------------------ |
      */
      /*
       Si p_species = sp. on ajoute toujours une entrée dans mkisublist avec l'indice -1
       si le niveau d'interception est "espèces des"
      */
      CURSOR l_curmkiidentifygroupcounter
      IS
           SELECT *
             FROM mkiidentifygroupcounter
         ORDER BY mig_searchorder;

      l_recmkiidentifygroupcounter    l_curmkiidentifygroupcounter%ROWTYPE;

      l_recsystvalue                  systvalue%ROWTYPE;
      l_reccodereferenceonhierarchy   codereference%ROWTYPE;
      l_reccodereferenceonleveltrap   codereference%ROWTYPE;
      l_recsystdesignation            systdesignation%ROWTYPE;
      l_reccodereference              codereference%ROWTYPE;
      l_found                         BOOLEAN := FALSE;
      l_systvalueatlevel              systvalue%ROWTYPE;
      l_recsystvalueonhierarchy       systvalue%ROWTYPE;
      l_process                       BOOLEAN := TRUE;
   BEGIN
      -- La veleur fournie est à quel  niveau hiérarchaique
      l_recsystvalue := pkg_systvalue.f_getrecord (p_syv_id);

      IF l_recsystvalue.syv_id IS NULL
      THEN
         RETURN;
      END IF;



      OPEN l_curmkiidentifygroupcounter;

      LOOP
         FETCH l_curmkiidentifygroupcounter INTO l_recmkiidentifygroupcounter;

         EXIT WHEN l_curmkiidentifygroupcounter%NOTFOUND OR l_found;
         l_process := FALSE;

         -- Si le niveau du crf_id associé au syv_id fourni est plus grand que  mig_crf_id_level_trap
         -- on ne peut pas comptabilisé à ce niveau
         l_reccodereferenceonleveltrap :=
            pkg_codereference.f_getrecord (
               l_recmkiidentifygroupcounter.mig_crf_id_level_trap);

         IF     TRIM (LOWER (p_species)) = cst_species_code
            AND l_reccodereferenceonleveltrap.crf_code =
                   pkg_codereference.cst_crf_species
         THEN
            l_recsystvalueonhierarchy :=
               pkg_systvalue.f_getrecordathierarchy (
                  p_syv_id,
                  l_recmkiidentifygroupcounter.mig_syv_id);

            IF NOT l_recsystvalueonhierarchy.syv_id IS NULL
            THEN
               p_add2mkidispatchlist (
                  l_recmkiidentifygroupcounter.mig_syv_id,
                  p_syv_id,
                  p_syv_id,
                  p_species,
                  gbl_mkidispatchlist);
               l_found := TRUE;
            END IF;
         ELSE
            l_reccodereferenceonhierarchy :=
               pkg_codereference.f_getrecordonhierarchy (
                  l_recsystvalue.syv_crf_id,
                  l_reccodereferenceonleveltrap.crf_code);

            IF NOT l_reccodereferenceonhierarchy.crf_id IS NULL
            THEN
               l_recsystvalueonhierarchy :=
                  pkg_systvalue.f_getrecordathierarchy (
                     p_syv_id,
                     l_recmkiidentifygroupcounter.mig_syv_id);

               IF NOT l_recsystvalueonhierarchy.syv_id IS NULL
               THEN
                  l_systvalueatlevel :=
                     pkg_systvalue.f_getrecordatlevel (
                        p_syv_id,
                        l_reccodereferenceonleveltrap.crf_code);
                  p_add2mkidispatchlist (
                     l_recmkiidentifygroupcounter.mig_syv_id,
                     l_systvalueatlevel.syv_id,
                     p_syv_id,
                     p_species,                                   -- p_species
                     gbl_mkidispatchlist);
                  l_found := TRUE;
               END IF;
            END IF;
         END IF;
      END LOOP;

      p_found := l_found;
   END;

   /*-----------------------------------------------------------*/
   PROCEDURE p_mkicomputemormalizedvalue
   /*-----------------------------------------------------------*/
   IS
      l_key                      systdesignation.syd_designation%TYPE;
      l_mkireference             t_mkireference;
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
   BEGIN
      l_key := gbl_mki_reference.FIRST;

      WHILE NOT l_key IS NULL
      LOOP
         IF gbl_mki_reference (l_key).mki_normalizedcountflag =
               pkg_constante.cst_yes
         THEN
            IF gbl_mki_reference (l_key).mki_counter > 0
            THEN
               l_recabundanceclassrange :=
                  pkg_abundanceclassrange.f_getrecordbyindiceandvalue (
                     pkg_codevalue.cst_midatfldcmt_makroindex,
                     gbl_mki_reference (l_key).mki_counter);
               gbl_mki_reference (l_key).mki_normalizedcounter :=
                  l_recabundanceclassrange.acr_substitutevalue;
            END IF;
         END IF;

         l_key := gbl_mki_reference.NEXT (l_key);
      END LOOP;
   END;



   /*------------------------------------------------------------*/
   PROCEDURE p_mkiadddata (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_syv_id                    IN sampleprotocollabo.spl_syv_id%TYPE,
      p_count                     IN sampleprotocollabo.spl_frequency%TYPE,
      p_species                   IN importmassdatadetail.imd_species%TYPE)
   /*------------------------------------------------------------*/
   IS
      /*
        La colonne freq1 contient toujours des classes. On doit convertir les classes en
        valeur

       */
      l_syv_id_return              sampleprotocollabo.spl_syv_id%TYPE;
      l_crf_code                   codereference.crf_code%TYPE;
      l_key                        systdesignation.syd_designation%TYPE;
      l_value                      NUMBER;
      l_rectricopterascabbard      tricopterascabbard%ROWTYPE;
      l_recsysdesignation          systdesignation%ROWTYPE;
      l_recsysdesignationfamilly   systdesignation%ROWTYPE;
      l_recsystvalueatfamily       systvalue%ROWTYPE;
      l_recabundanceclassrange     abundanceclassrange%ROWTYPE;
      l_found                      BOOLEAN;
      l_reclanguage                language%ROWTYPE;
      l_fullpath                   VARCHAR2 (2048);
   BEGIN
      l_recabundanceclassrange :=
         pkg_abundanceclassrange.f_getrecordbyclass (
            pkg_codevalue.cst_midatfldcmt_makroindex,
            p_count);
      l_value := l_recabundanceclassrange.acr_substitutevalue;
      l_key := gbl_mki_reference.FIRST;


      WHILE NOT l_key IS NULL
      LOOP
         l_syv_id_return :=
            pkg_systdesignation.f_designationisinhierarchy (
               p_syv_id,
               gbl_mki_reference (l_key).mki_crf_code,
               l_key);

         IF l_key = cst_mki_trichoptera AND NOT l_syv_id_return IS NULL
         THEN
            -- Pour les trichopteres on ne prend en compte que ceux qui on un fourreau
            pkg_debug.p_write ('PKG_INDICE_UTILITY.p_mkiadddata',
                               'p_syv_id=' || p_syv_id);
            l_recsystvalueatfamily :=
               pkg_systvalue.f_getrecordatlevel (
                  p_syv_id,
                  pkg_codereference.cst_crf_family);

            IF l_recsystvalueatfamily.syv_id IS NULL
            THEN
               -- Ce taxon %p1% est ignoré car il appartient à l''ordre des trichopteres mais il n''est pas possible de déterminer si il dispose d''un fourreau car sa famille n''est pas définie dans le thésaurus
               l_recsysdesignation :=
                  pkg_systdesignation.f_getrecdesignationbylancode (
                     p_syv_id,
                     pkg_language.cst_lan_cde_latin);
               pkg_importprotocollog.p_writelog (
                  p_recimportprotocolheader.iph_id,
                  NULL,                                              -- IMH_ID
                  pkg_exception.cst_mkitrichounable2detscabbar,
                  NULL,                                          -- Field name
                  l_recsysdesignation.syd_designation);
               l_syv_id_return := NULL;                        -- Pour ignorer
            ELSE
               -- La famille est déterminée. On va regarder si elle dispose d'un fourreau
               l_rectricopterascabbard :=
                  pkg_tricopterascabbard.f_getrecordbysyvid (
                     l_recsystvalueatfamily.syv_id);

               IF l_rectricopterascabbard.tsd_id IS NULL
               THEN
                  l_recsysdesignationfamilly :=
                     pkg_systdesignation.f_getrecdesignationbylancode (
                        l_recsystvalueatfamily.syv_id,
                        pkg_language.cst_lan_cde_latin);
                  l_recsysdesignation :=
                     pkg_systdesignation.f_getrecdesignationbylancode (
                        p_syv_id,
                        pkg_language.cst_lan_cde_latin);
                  -- Ce taxon %p1% n'est pas pris en compte dans le calcul du nombre de tricoptère sans fourreau car  cette information sur la famille %p2% n'est pas disponible dans le thésaurus
                  pkg_importprotocollog.p_writelog (
                     p_recimportprotocolheader.iph_id,
                     NULL,                                           -- IMH_ID
                     pkg_exception.cst_mkifamillyscabbarnotdefine,
                     NULL,                                       -- Field name
                     l_recsysdesignation.syd_designation,
                     l_recsysdesignationfamilly.syd_designation);
                  l_syv_id_return := NULL;                     -- Pour ignorer
               ELSE
                  IF l_rectricopterascabbard.tsd_hasscabbard =
                        pkg_constante.cst_no
                  THEN
                     gbl_mkiexculetricoptera :=
                        gbl_mkiexculetricoptera + l_value;
                     l_syv_id_return := NULL; -- Pour ignorer car pas de fourreau
                  END IF;
               END IF;
            END IF;
         END IF;                      -- Fin traitement spécifique TRICHOPTERE



         IF NOT l_syv_id_return IS NULL
         THEN
            gbl_mki_reference (l_key).mki_normalizedcounter :=
               gbl_mki_reference (l_key).mki_normalizedcounter + l_value;
            gbl_mki_reference (l_key).mki_counter :=
               gbl_mki_reference (l_key).mki_counter + p_count;
         END IF;

         l_key := gbl_mki_reference.NEXT (l_key);
      END LOOP;


      gbl_mki_totalcounter := gbl_mki_totalcounter + l_value;
      p_mkidispatch (p_syv_id, p_species, l_found);

      IF NOT l_found
      THEN
         -- L'entrée n'a pas été trouvé dans la hiérarchie du tableau 3
         l_reclanguage :=
            pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);
         l_recsysdesignation :=
            pkg_systdesignation.f_getrecdesignationbylancode (
               p_syv_id,
               pkg_language.cst_lan_cde_latin);
         l_fullpath :=
            pkg_systdesignation.f_returnpathdesignation (
               p_syv_id,
               l_reclanguage.lan_id,
               '/');
         pkg_importprotocollog.p_writelog (
            p_recimportprotocolheader.iph_id,
            NULL,                                                    -- IMH_ID
            pkg_exception.cst_mkitaxonignored,
            NULL,                                                -- Field name
            l_recsysdesignation.syd_designation,
            l_fullpath);
         NULL;
      END IF;
   END;

   /*----------------------------------------------------------*/
   PROCEDURE p_displaymakroindexdata
   /*----------------------------------------------------------*/
   IS
   BEGIN
      pkg_debug.p_write (
         'PKG_INDICE_UTILITY.p_displaymakroindexdata',
            cst_mki_plecoptera
         || ' counter = '
         || gbl_mki_reference (cst_mki_plecoptera).mki_counter);
      pkg_debug.p_write (
         'PKG_INDICE_UTILITY.p_displaymakroindexdata',
            cst_mki_trichoptera
         || ' counter = '
         || gbl_mki_reference (cst_mki_trichoptera).mki_counter);
      pkg_debug.p_write (
         'PKG_INDICE_UTILITY.p_displaymakroindexdata',
            cst_mki_ephemeroptera
         || ' counter = '
         || gbl_mki_reference (cst_mki_ephemeroptera).mki_counter);
      pkg_debug.p_write (
         'PKG_INDICE_UTILITY.p_displaymakroindexdata',
            cst_mki_baetidae
         || ' counter = '
         || gbl_mki_reference (cst_mki_baetidae).mki_counter);
      pkg_debug.p_write (
         'PKG_INDICE_UTILITY.p_displaymakroindexdata',
            cst_mki_gammarus
         || ' counter = '
         || gbl_mki_reference (cst_mki_gammarus).mki_counter);
      pkg_debug.p_write (
         'PKG_INDICE_UTILITY.p_displaymakroindexdata',
            cst_mki_hydropsyche
         || ' counter = '
         || gbl_mki_reference (cst_mki_hydropsyche).mki_counter);
      pkg_debug.p_write (
         'PKG_INDICE_UTILITY.p_displaymakroindexdata',
            cst_mki_asellus
         || ' counter = '
         || gbl_mki_reference (cst_mki_asellus).mki_counter);
      pkg_debug.p_write (
         'PKG_INDICE_UTILITY.p_displaymakroindexdata',
            cst_mki_hirudinea
         || ' counter = '
         || gbl_mki_reference (cst_mki_hirudinea).mki_counter);
      pkg_debug.p_write (
         'PKG_INDICE_UTILITY.p_displaymakroindexdata',
            cst_mki_tubificidae
         || ' counter = '
         || gbl_mki_reference (cst_mki_tubificidae).mki_counter);


      pkg_debug.p_write ('PKG_INDICE_UTILITY.p_displaymakroindexdata',
                         ' total counter = ' || gbl_mki_totalcounter);

      NULL;
   END;



   /*----------------------------------------------------------*/
   FUNCTION f_mkiparseinsectaratio (p_insectaratio    IN NUMBER,
                                    p_valuelower1     IN NUMBER,
                                    p_value1_2        IN NUMBER,
                                    p_valueupper2_6   IN NUMBER,
                                    p_valueupper6     IN NUMBER)
      RETURN NUMBER
   /*----------------------------------------------------------*/
   IS
      l_value   NUMBER;
   BEGIN
      CASE
         WHEN p_insectaratio < 1
         THEN
            l_value := p_valuelower1;
         WHEN p_insectaratio >= 1 AND p_insectaratio <= 2
         THEN
            l_value := p_value1_2;
         WHEN p_insectaratio > 2 AND p_insectaratio <= 6
         THEN
            l_value := p_valueupper2_6;
         WHEN p_insectaratio > 6
         THEN
            l_value := p_valueupper6;
         ELSE
            l_value := NULL;
      END CASE;

      RETURN l_value;
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_mkicheckplecoptcase
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_makroindex               NUMBER;
      l_insectanoninsectaratio   NUMBER;
   BEGIN
      l_insectanoninsectaratio := gbl_insectanoninsectaratio;

      IF gbl_mki_reference (cst_mki_plecoptera).mki_normalizedcounter = 0
      THEN
         RETURN NULL;
      END IF;

      IF gbl_mki_reference (cst_mki_plecoptera).mki_normalizedcounter > 30
      THEN
         gbl_mki_cvl_code_case := pkg_codevalue.cst_mkicase_plecoptera;

         IF gbl_mki_reference (cst_mki_plecoptera).mki_normalizedcounter >
               150
         THEN
            gbl_mki_range_selected := '>4';
            l_makroindex :=
               f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                       cst_mkinotset,
                                       cst_mkinotset,
                                       2,
                                       1);
            RETURN l_makroindex;
         ELSIF     gbl_mki_reference (cst_mki_plecoptera).mki_normalizedcounter >=
                      31
               AND gbl_mki_reference (cst_mki_plecoptera).mki_normalizedcounter <=
                      150
         THEN
            gbl_mki_range_selected := '3-4';
            l_makroindex :=
               f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                       cst_mkinotset,
                                       3,
                                       2,
                                       2);
            RETURN l_makroindex;
         END IF;
      END IF;

      RETURN NULL;
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_mkicheckplecopttricopcase
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_makroindex               NUMBER;
      l_insectanoninsectaratio   NUMBER;
      l_total                    NUMBER;
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
   BEGIN
      pkg_debug.p_write ('pkg_indice_itility.f_mkicheckplecopttricopcase',
                         'Start...');
      l_insectanoninsectaratio := gbl_insectanoninsectaratio;
      l_total :=
           gbl_mki_reference (cst_mki_trichoptera).mki_counter
         + gbl_mki_reference (cst_mki_plecoptera).mki_counter;
      -- Le total    cst_mki_plecoptera + cst_mki_trichoptera doit être normalisé
      pkg_debug.p_write ('pkg_indice_itility.f_mkicheckplecopttricopcase',
                         'l_total non normalisé=' || l_total);
      l_recabundanceclassrange :=
         pkg_abundanceclassrange.f_getrecordbyindiceandvalue (
            pkg_codevalue.cst_midatfldcmt_makroindex,
            l_total);
      l_total := l_recabundanceclassrange.acr_substitutevalue;
      pkg_debug.p_write ('pkg_indice_itility.f_mkicheckplecopttricopcase',
                         'l_total normalisé=' || l_total);

      IF l_total = 0
      THEN
         RETURN NULL;
      END IF;

      pkg_debug.p_write (
         'pkg_indice_itility.f_mkicheckplecopttricopcase',
         'l_insectanoninsectaratio=' || l_insectanoninsectaratio);

      gbl_mki_cvl_code_case := pkg_codevalue.cst_mkicase_plecotricho;

      IF l_total > 150
      THEN
         pkg_debug.p_write ('pkg_indice_itility.f_mkicheckplecopttricopcase',
                            'l_total > 150=' || l_total);
         gbl_mki_range_selected := '>4';
         l_makroindex :=
            f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                    cst_mkinotset,
                                    3,
                                    3,
                                    3);
         RETURN l_makroindex;
      ELSIF l_total <= 150
      THEN
         pkg_debug.p_write ('pkg_indice_itility.f_mkicheckplecopttricopcase',
                            'l_total <= 150=' || l_total);
         gbl_mki_range_selected := '<=4';
         l_makroindex :=
            f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                    5,
                                    4,
                                    3,
                                    3);
         RETURN l_makroindex;
      END IF;

      RETURN NULL;
   END;



   /*-----------------------------------------------------------*/
   FUNCTION f_mkicheckephemeohnebaetidae
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_makroindex               NUMBER;
      l_insectanoninsectaratio   NUMBER;
      l_total                    NUMBER;
   BEGIN
      l_insectanoninsectaratio := gbl_insectanoninsectaratio;

      IF gbl_mki_reference (cst_mki_baetidae).mki_normalizedcounter > 0
      THEN
         RETURN NULL;
      END IF;

      l_total :=
         gbl_mki_reference (cst_mki_ephemeroptera).mki_normalizedcounter;

      IF l_total = 0
      THEN
         RETURN NULL;
      END IF;


      gbl_mki_cvl_code_case := pkg_codevalue.cst_mkicase_ephemeropter;

      IF l_total > 30
      THEN
         gbl_mki_range_selected := '>2';
         l_makroindex :=
            f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                    5,
                                    4,
                                    4,
                                    3);
         RETURN l_makroindex;
      ELSIF l_total <= 11
      THEN
         gbl_mki_range_selected := '>=2';
         l_makroindex :=
            f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                    6,
                                    5,
                                    5,
                                    cst_mkinotset);
         RETURN l_makroindex;
      END IF;


      RETURN NULL;
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_mkicheckgammarus
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_makroindex               NUMBER;
      l_insectanoninsectaratio   NUMBER;
      l_total                    NUMBER;
   BEGIN
      l_insectanoninsectaratio := gbl_insectanoninsectaratio;
      l_total :=
           gbl_mki_reference (cst_mki_gammarus).mki_normalizedcounter
         + gbl_mki_reference (cst_mki_hydropsyche).mki_normalizedcounter;

      IF l_total = 0
      THEN
         RETURN NULL;
      END IF;

      gbl_mki_cvl_code_case := pkg_codevalue.cst_mkicase_gammarus;
      gbl_mki_range_selected := NULL;
      l_makroindex :=
         f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                 7,
                                 6,
                                 5,
                                 cst_mkinotset);
      RETURN l_makroindex;
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_mkicheckasellus
      RETURN NUMBER
   /*-----------------------------------------------------------*/
   IS
      l_makroindex               NUMBER;
      l_insectanoninsectaratio   NUMBER;
      l_total                    NUMBER;
   BEGIN
      l_insectanoninsectaratio := gbl_insectanoninsectaratio;
      l_total :=
           gbl_mki_reference (cst_mki_asellus).mki_normalizedcounter
         + gbl_mki_reference (cst_mki_hirudinea).mki_normalizedcounter
         + gbl_mki_reference (cst_mki_tubificidae).mki_normalizedcounter;

      IF l_total = 0
      THEN
         RETURN NULL;
      END IF;

      gbl_mki_cvl_code_case := pkg_codevalue.cst_mkicase_asellus;
      gbl_mki_range_selected := NULL;
      l_makroindex :=
         f_mkiparseinsectaratio (l_insectanoninsectaratio,
                                 8,
                                 7,
                                 cst_mkinotset,
                                 cst_mkinotset);
      RETURN l_makroindex;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_mkiisinsecta (p_syv_id IN systvalue.syv_id%TYPE)
      RETURN CHAR
   /*--------------------------------------------------------------*/
   IS
      l_syv_id   systvalue.syv_id%TYPE;
   BEGIN
      l_syv_id :=
         pkg_systdesignation.f_designationisinhierarchy (
            p_syv_id,
            cst_mki_insecta_crf_code,
            cst_mki_insecta);

      IF NOT l_syv_id IS NULL
      THEN
         RETURN pkg_constante.cst_yes;
      ELSE
         RETURN pkg_constante.cst_no;
      END IF;
   END;

   /*-----------------------------------------------------------*/
   PROCEDURE p_mkicomputeinsectaratio
   /*-----------------------------------------------------------*/
   IS
      l_master_indice     PLS_INTEGER;
      l_mkidispatchlist   pkg_indice_utility.t_mkidispatchlist;
      l_mkisublist        pkg_indice_utility.t_mkisublist;
      l_syv_id_return     systvalue.syv_id%TYPE;
   BEGIN
      gbl_mki_non_insecta_count := 0;
      gbl_mki_insecta_count := 0;
      gbl_insectanoninsectaratio := 0;
      l_mkidispatchlist := pkg_indice_utility.f_getgblmkidispatchlist;
      l_master_indice := l_mkidispatchlist.FIRST;

      WHILE NOT l_master_indice IS NULL
      LOOP
         l_mkisublist := l_mkidispatchlist (l_master_indice);
         -- La variable master_indice contient le syv_id du regroupement. On l'utilise pour déterminer si c'est un insecte
         l_syv_id_return :=
            pkg_systdesignation.f_designationisinhierarchy (
               l_master_indice,
               cst_mki_insecta_crf_code,
               cst_mki_insecta);

         IF NOT l_syv_id_return IS NULL
         THEN
            gbl_mki_insecta_count :=
               gbl_mki_insecta_count + l_mkisublist.COUNT ();
         ELSE
            gbl_mki_non_insecta_count :=
               gbl_mki_non_insecta_count + +l_mkisublist.COUNT ();
         END IF;

         l_master_indice := l_mkidispatchlist.NEXT (l_master_indice);
      END LOOP;

      IF gbl_mki_non_insecta_count != 0
      THEN
         gbl_insectanoninsectaratio :=
            gbl_mki_insecta_count / gbl_mki_non_insecta_count;
      ELSE
         gbl_insectanoninsectaratio :=
            pkg_indice_utility.cst_insectaratio_zerodivide;
      END IF;
   END;

   /*-----------------------------------------------------------*/
   FUNCTION f_computemakroindex
      RETURN NUMBER
   /*------------------------------------------------------------*/
   IS
      l_insectanoninsectaratio   NUMBER;
      l_countnonisecta           NUMBER;
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
      l_mkiindex                 NUMBER;
   BEGIN
      gbl_mki_errornumber := NULL;
      gbl_mki_cvl_code_case := NULL;
      gbl_mki_normalizedcount := NULL;

      IF gbl_mki_totalcounter = 0
      THEN
         RETURN NULL;
      END IF;



      p_displaymakroindexdata;

      l_mkiindex := f_mkicheckplecoptcase;

      IF NOT l_mkiindex IS NULL
      THEN
         IF l_mkiindex = cst_mkinotset
         THEN
            gbl_mki_errornumber := pkg_exception.cst_mkiplecoptera;
         END IF;

         RETURN l_mkiindex;
      END IF;

      l_mkiindex := f_mkicheckplecopttricopcase;

      IF NOT l_mkiindex IS NULL
      THEN
         IF l_mkiindex = cst_mkinotset
         THEN
            gbl_mki_errornumber := pkg_exception.cst_mkiplecopteratrichoptera;
         END IF;

         RETURN l_mkiindex;
      END IF;

      l_mkiindex := f_mkicheckephemeohnebaetidae;

      IF NOT l_mkiindex IS NULL
      THEN
         IF l_mkiindex = cst_mkinotset
         THEN
            gbl_mki_errornumber :=
               pkg_exception.cst_mkiephemeropterawithoutbae;
         END IF;

         RETURN l_mkiindex;
      END IF;

      l_mkiindex := f_mkicheckgammarus;

      IF NOT l_mkiindex IS NULL
      THEN
         IF l_mkiindex = cst_mkinotset
         THEN
            gbl_mki_errornumber := pkg_exception.cst_mkigammarushydropsyche;
         END IF;

         RETURN l_mkiindex;
      END IF;

      l_mkiindex := f_mkicheckasellus;

      IF NOT l_mkiindex IS NULL
      THEN
         IF l_mkiindex = cst_mkinotset
         THEN
            gbl_mki_errornumber :=
               pkg_exception.cst_mkiasselushirudinaeturbifi;
         END IF;

         RETURN l_mkiindex;
      END IF;

      gbl_mki_errornumber := pkg_exception.cst_mkiunabletocompute;
      RETURN NULL;
   END;

   /*------------------------------------------------------------*/

   FUNCTION f_ibchreturnclassevariete (p_sommevt IN NUMBER)
      RETURN NUMBER
   /*------------------------------------------------------------*/
   /* Tableau 6, page 30 :http://www.sib.admin.ch/uploads/media/UV-1026-F_01.pdf
   */
   IS
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
   BEGIN
      l_recabundanceclassrange :=
         pkg_abundanceclassrange.f_getrecordbyindiceandvalue (
            pkg_codevalue.cst_midatindice_ibch,
            p_sommevt);
      RETURN l_recabundanceclassrange.acr_classe;
   END;


   /*------------------------------------------------------------*/

   FUNCTION f_ibchreturnclassevarieteold (p_sommevt IN NUMBER)
      RETURN NUMBER
   /*------------------------------------------------------------*/
   /* Tableau 6, page 30 :http://www.sib.admin.ch/uploads/media/UV-1026-F_01.pdf
   */
   IS
      l_classe   NUMBER;
   BEGIN
      CASE
         WHEN p_sommevt >= 50
         THEN
            l_classe := 14;
         WHEN p_sommevt >= 45 AND p_sommevt <= 49
         THEN
            l_classe := 13;
         WHEN p_sommevt >= 41 AND p_sommevt <= 44
         THEN
            l_classe := 12;
         WHEN p_sommevt >= 37 AND p_sommevt <= 40
         THEN
            l_classe := 11;
         WHEN p_sommevt >= 33 AND p_sommevt <= 36
         THEN
            l_classe := 10;
         WHEN p_sommevt >= 29 AND p_sommevt <= 32
         THEN
            l_classe := 9;
         WHEN p_sommevt >= 25 AND p_sommevt <= 28
         THEN
            l_classe := 8;
         WHEN p_sommevt >= 21 AND p_sommevt <= 24
         THEN
            l_classe := 7;
         WHEN p_sommevt >= 17 AND p_sommevt <= 20
         THEN
            l_classe := 6;
         WHEN p_sommevt >= 13 AND p_sommevt <= 16
         THEN
            l_classe := 5;
         WHEN p_sommevt >= 10 AND p_sommevt <= 12
         THEN
            l_classe := 4;
         WHEN p_sommevt >= 7 AND p_sommevt <= 9
         THEN
            l_classe := 3;
         WHEN p_sommevt >= 4 AND p_sommevt <= 6
         THEN
            l_classe := 2;
         WHEN p_sommevt >= 1 AND p_sommevt <= 3
         THEN
            l_classe := 1;
         ELSE
            l_classe := NULL;
      END CASE;

      RETURN l_classe;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_ibchadddataclass (
      p_ptl_id   IN sampleprotocollabo.spl_ptl_id%TYPE,
      p_count    IN sampleprotocollabo.spl_frequency%TYPE)
   /*-----------------------------------------------------------*/
   IS
      --- p_count est une classe
      l_recabundanceclassrange   abundanceclassrange%ROWTYPE;
   BEGIN
      l_recabundanceclassrange :=
         pkg_abundanceclassrange.f_getrecordbyclass (
            pkg_codevalue.cst_midatfldcmt_makroindex,
            p_count);
      p_ibchadddata (p_ptl_id, l_recabundanceclassrange.acr_substitutevalue);
   END;



   /*------------------------------------------------------------*/

   PROCEDURE p_ibchadddata (
      p_ptl_id   IN sampleprotocollabo.spl_ptl_id%TYPE,
      p_count    IN sampleprotocollabo.spl_frequency%TYPE)
   /*-----------------------------------------------------------*/
   IS
      l_indice        PLS_INTEGER;
      l_indicefound   PLS_INTEGER;
   BEGIN
      IF p_ptl_id IS NULL
      THEN
         RETURN;
      END IF;

      l_indicefound := -1;
      l_indice := gbl_listibchvalue.FIRST;

      WHILE NOT l_indice IS NULL AND l_indicefound = -1
      LOOP
         IF gbl_listibchvalue (l_indice).ibc_ptl_id = p_ptl_id
         THEN                         -- L'entrée existe déjà, on doit cumuler
            l_indicefound := l_indice;
         END IF;

         l_indice := gbl_listibchvalue.NEXT (l_indice);
      END LOOP;

      IF l_indicefound = -1
      THEN
         gbl_listibchvalue.EXTEND (1);
         gbl_listibchvalue (gbl_listibchvalue.LAST).ibc_ptl_id := p_ptl_id;
         gbl_listibchvalue (gbl_listibchvalue.LAST).ibc_counter := p_count;
      ELSE
         gbl_listibchvalue (l_indicefound).ibc_counter :=
            gbl_listibchvalue (l_indicefound).ibc_counter + p_count;
      END IF;

      NULL;
   END;


   /*----------------------------------------------------------------*/

   FUNCTION f_computeibchfrommemory (p_abondanceflag IN VARCHAR2)
      RETURN NUMBER
   /*----------------------------------------------------------------*/
   IS
      l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
      l_error                    BOOLEAN := FALSE;
      l_ibchindice               NUMBER;
      l_sommevt                  NUMBER; -- Variété taxonimique: Nombre de taxon (nombre de ligne renseigné)
      l_classevt                 NUMBER; -- Classe découlant de la variété taxonomique
      l_ibch                     NUMBER;
      l_indice                   PLS_INTEGER;
      l_value                    NUMBER;
      l_gi_max                   NUMBER := cst_gi_undef;
   BEGIN
      l_gi_max := cst_gi_undef;

      l_sommevt := gbl_listibchvalue.COUNT;

      l_classevt := f_ibchreturnclassevariete (l_sommevt);

      -- Calcul du groupe faunistique indicateur (GI)
      l_indice := gbl_listibchvalue.FIRST;

      WHILE NOT l_indice IS NULL AND NOT l_error
      LOOP
         l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecord (
               gbl_listibchvalue (l_indice).ibc_ptl_id);

         IF l_recprotocolmappinglabo.ptl_id IS NULL
         THEN
            l_error := TRUE;
         ELSE
            l_value :=
               f_normaliseabondance (
                  gbl_listibchvalue (l_indice).ibc_counter,
                  p_abondanceflag);


            IF l_value >=
                  NVL (l_recprotocolmappinglabo.ptl_ibchindividumin,
                       cst_maxvalue)
            THEN
               IF NVL (l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi, -1) >
                     l_gi_max
               THEN --  Le  groupe GI avec l'indice le plus grand est déterminant
                  l_gi_max := l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi;
               END IF;
            END IF;
         END IF;

         l_indice := gbl_listibchvalue.NEXT (l_indice);
      END LOOP;

      IF l_error
      THEN
         RETURN NULL;
      END IF;


 
      IF l_gi_max < 0
      THEN
         --    l_ibch := l_classevt - 1;
         l_ibch := 0; -- Email de PS du 7.04.2015
      ELSE
         l_ibch := l_gi_max + l_classevt - 1;
      END IF;


      gbl_ibch_vt := l_classevt;
      gbl_ibch_gi := l_gi_max;

      RETURN l_ibch;
   END;

   /*------------------------------------------------------------*/

   FUNCTION f_computeibchfromsample (p_sph_id          IN sampleheader.sph_id%TYPE,
                                     p_abondanceflag   IN VARCHAR2)
      RETURN NUMBER
   /*-------------------------------------------------------------*/
   /*
    Référence: Calcul de l'IBCH: http://www.sib.admin.ch/uploads/media/UV-1026-F_01.pdf
 */
   IS
      CURSOR l_cursampleprotocollabo
      IS
         SELECT *
           FROM sampleprotocollabo
          WHERE spl_sph_id = p_sph_id AND NVL (spl_frequency, 0) > 0;

      l_recsampleprotocollabo   l_cursampleprotocollabo%ROWTYPE;
      l_ibch                    NUMBER;
   BEGIN
      gbl_listibchvalue.delete ();

      OPEN l_cursampleprotocollabo;

      LOOP
         FETCH l_cursampleprotocollabo INTO l_recsampleprotocollabo;

         EXIT WHEN l_cursampleprotocollabo%NOTFOUND;
         p_ibchadddata (l_recsampleprotocollabo.spl_ptl_id,
                        l_recsampleprotocollabo.spl_frequency);
      END LOOP;

      CLOSE l_cursampleprotocollabo;

      l_ibch := f_computeibchfrommemory (p_abondanceflag);
      RETURN l_ibch;
   END;

   /*------------------------------------------------------------*/

   FUNCTION f_computeibchfromimport (
      p_ipl_iph_id      IN importprotocollabo.ipl_iph_id%TYPE,
      p_abondanceflag   IN VARCHAR2)
      RETURN NUMBER
   /*-------------------------------------------------------------*/
   /*
    Référence: Calcul de l'IBCH: http://www.sib.admin.ch/uploads/media/UV-1026-F_01.pdf
 */
   IS
      CURSOR l_curimportprotocollabo
      IS
         SELECT *
           FROM importprotocollabo
          WHERE ipl_iph_id = p_ipl_iph_id AND NVL (ipl_value, 0) > 0;

      l_reccurimportprotocollabo   l_curimportprotocollabo%ROWTYPE;
      l_ibch                       NUMBER;
   BEGIN
      gbl_listibchvalue.delete ();

      OPEN l_curimportprotocollabo;

      LOOP
         FETCH l_curimportprotocollabo INTO l_reccurimportprotocollabo;

         EXIT WHEN l_curimportprotocollabo%NOTFOUND;
         p_ibchadddata (l_reccurimportprotocollabo.ipl_ptl_id,
                        l_reccurimportprotocollabo.ipl_value);
      END LOOP;

      CLOSE l_curimportprotocollabo;

      l_ibch := f_computeibchfrommemory (p_abondanceflag);
      RETURN l_ibch;
   END;

   /*-----------------------------------------------------------------------------------*/
   PROCEDURE p_checkifspearcanbecomputed (
      p_iph_id   IN     importprotocolheader.iph_id%TYPE,
      p_status      OUT NUMBER)
   /*-----------------------------------------------------------------------------------*/
   IS
      l_indice               PLS_INTEGER;
      l_listspearvalue       pkg_indice_utility.t_listspearvalue;
      l_reclanguage_lat      language%ROWTYPE;
      l_recsystdesignation   systdesignation%ROWTYPE;
      l_counter              NUMBER := 0;
      l_header               BOOLEAN := FALSE;
   BEGIN
      p_status := pkg_constante.cst_returnstatusok;
      l_reclanguage_lat :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);
      -- Après le computefromimport, les données IBCH sont dans le buffer
      pkg_indice_utility.p_loadspearlistfromibchlist (p_iph_id);
      l_listspearvalue := pkg_indice_utility.f_spearreturnlistvalue;
      -- Pour calculer l'indice SPEAR, on vérifie que toutes les entrées aient un indice défini
      l_indice := l_listspearvalue.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         IF l_listspearvalue (l_indice).spr_spearindexfactor IS NULL
         THEN
            IF NOT l_header
            THEN
               pkg_importprotocollog.p_writelog (
                  p_iph_id,
                  NULL,
                  pkg_exception.cst_spearindexcannotbecomputed,
                  NULL);
               l_header := TRUE;
            END IF;

            l_counter := l_counter + 1;
            l_recsystdesignation :=
               pkg_systdesignation.f_getrecorddesignation (
                  l_listspearvalue (l_indice).spr_syv_id,
                  l_reclanguage_lat.lan_id);
            pkg_importprotocollog.p_writelog (
               p_iph_id,
               NULL,
               pkg_exception.cst_info,
               NULL,
                  TO_CHAR (l_counter)
               || '. '
               || l_recsystdesignation.syd_designation);
         END IF;

         l_indice := l_listspearvalue.NEXT (l_indice);
      END LOOP;

      IF l_counter > 0
      THEN
         p_status := pkg_constante.cst_returnstatusnotok;
      END IF;
   END;

   /*-----------------------------------------------------------------*/

   PROCEDURE p_convertmass2ibch (
      p_ptv_id   IN protocolversion.ptv_id%TYPE,
      p_iph_id   IN importprotocolheader.iph_id%TYPE,
      p_imh_id   IN importmassdataheader.imh_id%TYPE)
   /*-----------------------------------------------------------------*/
   IS
      l_indice                   PLS_INTEGER;
      l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
      l_recsystdesignation       systdesignation%ROWTYPE;
      l_reclanguage              language%ROWTYPE;
      l_recprotocolversion       protocolversion%ROWTYPE;
      l_textemapping             VARCHAR2 (1024);
      l_counter                  NUMBER;
   BEGIN
      pkg_indice_utility.p_ibchinit;
      l_reclanguage :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);
      l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);
      l_counter := 0;
      l_indice := gbl_listibchvaluemass.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         l_recsystdesignation :=
            pkg_systdesignation.f_getrecorddesignation (
               gbl_listibchvaluemass (l_indice).ibm_syv_id,
               l_reclanguage.lan_id);
         l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_identifyentrybyhierarchy (
               gbl_listibchvaluemass (l_indice).ibm_syv_id,
               l_recprotocolversion.ptv_ptv_id_labofrommass);

         IF l_recprotocolmappinglabo.ptl_id IS NULL
         THEN
            l_textemapping :=
                  l_recsystdesignation.syd_designation
               || ' -> ('
               || pkg_codevalue.cst_midatindice_ibch
               || ') ? ';
         ELSE
            l_textemapping :=
                  l_recsystdesignation.syd_designation
               || ' -> ('
               || pkg_codevalue.cst_midatindice_ibch
               || ') '
               || l_recprotocolmappinglabo.ptl_taxa;


            pkg_indice_utility.p_ibchadddata (
               l_recprotocolmappinglabo.ptl_id,
               gbl_listibchvaluemass (l_indice).ibm_counter);
            gbl_ibchidentifiedtaxoncounter :=
               gbl_ibchidentifiedtaxoncounter + 1;
         END IF;

         l_counter := l_counter + 1;
         DBMS_OUTPUT.put_line (l_textemapping);

         pkg_importprotocollog.p_writelog (
            p_iph_id,
            NULL,
            pkg_exception.cst_info,
            NULL,
            TO_CHAR (l_counter) || '. ' || l_textemapping);

         l_indice := gbl_listibchvaluemass.NEXT (l_indice);
      END LOOP;

      NULL;
   END;



   /*----------------------------------------------------------------*/

   FUNCTION f_computeibchfrommassold (
      p_ptv_id          IN protocolversion.ptv_id%TYPE,
      p_iph_id          IN importprotocolheader.iph_id%TYPE,
      p_imh_id          IN importmassdataheader.imh_id%TYPE,
      p_abondanceflag   IN VARCHAR2)
      RETURN NUMBER
   /*----------------------------------------------------------------*/
   IS
      l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
      l_error                    BOOLEAN := FALSE;
      l_ibchindice               NUMBER;
      l_sommevt                  NUMBER; -- Variété taxonimique: Nombre de taxon (nombre de ligne renseigné)
      l_classevt                 NUMBER; -- Classe découlant de la variété taxonomique
      l_ibch                     NUMBER;
      l_indice                   PLS_INTEGER;
      l_value                    NUMBER;
      l_gi_max                   NUMBER := cst_gi_undef;
      l_textemapping             VARCHAR2 (1024);
      l_recsystdesignation       systdesignation%ROWTYPE;
      l_reclanguage              language%ROWTYPE;
      l_recprotocolversion       protocolversion%ROWTYPE;
   BEGIN
      l_gi_max := cst_gi_undef;
      /* Le PTV_ID est celui du formulaire mass. Celui qui doit être utilisée est celui de l'IBCH' soit celui qui a le PTV_ID_LABOFROMMASS*/
      l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);

      l_reclanguage :=
         pkg_language.f_getfromcode (pkg_language.cst_lan_cde_latin);
      DBMS_OUTPUT.put_line ('p_abondanceflag=' || TO_CHAR (p_abondanceflag));
      l_sommevt := gbl_listibchvaluemass.COUNT;
      pkg_debug.p_write ('PKG_INDICE_UTILITY.f_computeibchfrommass ',
                         'SommeVt=' || TO_CHAR (l_sommevt));
      l_classevt := f_ibchreturnclassevariete (l_sommevt);
      pkg_debug.p_write ('PKG_INDICE_UTILITY.f_computeibchfrommass ',
                         'ClasseVT=' || TO_CHAR (l_classevt));
      -- Calcul du groupe faunistique indicateur (GI)
      pkg_importprotocollog.p_writelog (
         p_iph_id,
         p_imh_id,
         pkg_exception.cst_makroindexibchmapping,
         NULL);

      l_indice := gbl_listibchvaluemass.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         l_recsystdesignation :=
            pkg_systdesignation.f_getrecorddesignation (
               gbl_listibchvaluemass (l_indice).ibm_syv_id,
               l_reclanguage.lan_id);
         l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_identifyentrybyhierarchy (
               gbl_listibchvaluemass (l_indice).ibm_syv_id,
               l_recprotocolversion.ptv_ptv_id_labofrommass);

         IF l_recprotocolmappinglabo.ptl_id IS NULL
         THEN
            l_error := TRUE;
            l_textemapping :=
                  '('
               || pkg_codevalue.cst_midatindice_makroindex
               || ') '
               || l_recsystdesignation.syd_designation
               || ' -> ('
               || pkg_codevalue.cst_midatindice_ibch
               || ') ? ';
         ELSE
            l_textemapping :=
                  '('
               || pkg_codevalue.cst_midatindice_makroindex
               || ') '
               || l_recsystdesignation.syd_designation
               || ' -> ('
               || pkg_codevalue.cst_midatindice_ibch
               || ') '
               || l_recprotocolmappinglabo.ptl_taxa;

            l_value :=
               f_normaliseabondance (
                  gbl_listibchvaluemass (l_indice).ibm_counter,
                  p_abondanceflag);
            pkg_debug.p_write (
               'PKG_INDICE_UTILITY.f_computeibchfrommass ',
                  'Espece:'
               || l_recprotocolmappinglabo.ptl_taxa
               || ' Abondance:'
               || l_value
               || ' l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi='
               || l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi
               || ' l_recprotocolmappinglabo.ptl_ibchindividumin: '
               || l_recprotocolmappinglabo.ptl_ibchindividumin);

            IF l_value >=
                  NVL (l_recprotocolmappinglabo.ptl_ibchindividumin,
                       cst_maxvalue)
            THEN
               pkg_debug.p_write (
                  'PKG_INDICE_UTILITY.f_computeibchfrommass ',
                     'l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi='
                  || l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi);

               IF NVL (l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi, -1) >
                     l_gi_max
               THEN --  Le  groupe GI avec l'indice le plus grand est déterminant
                  l_gi_max := l_recprotocolmappinglabo.ptl_ibchfaunagroup_gi;
                  pkg_debug.p_write (
                     'PKG_INDICE_UTILITY.f_computeibchfrommass ',
                     'l_gi_max=' || l_gi_max);
               END IF;
            END IF;
         END IF;

         pkg_importprotocollog.p_writelog (p_iph_id,
                                           p_imh_id,
                                           pkg_exception.cst_info,
                                           NULL,
                                           l_textemapping);

         l_indice := gbl_listibchvaluemass.NEXT (l_indice);
      END LOOP;

      IF l_error
      THEN
         NULL; -- Pour l'instant si une valeur n'est pas trouvé on en tien pas compte
      END IF;



      pkg_debug.p_write (
         'PKG_INDICE_UTILITY.f_computeibchfrommass ',
         'GI=' || TO_CHAR (l_gi_max) || ' VT=' || TO_CHAR (l_classevt));

      IF l_gi_max < 0
      THEN
         l_ibch := 0;
      ELSE
         l_ibch := l_gi_max + l_classevt - 1;
      END IF;

      pkg_debug.p_write ('PKG_INDICE_UTILITY.f_computeibchfrommass ',
                         'l_ibch=' || TO_CHAR (l_ibch));
      RETURN l_ibch;
   END;
END pkg_indice_utility;
/

