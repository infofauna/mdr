create trigger TR_BIF_NEOZOAIRE
    before insert
    on NEOZOAIRE
    for each row
DECLARE
BEGIN
    IF :new.NEO_id IS NULL
    THEN
        :new.NEO_id := seq_NEOZOAIRE.NEXTVAL;
    END IF;

    :new.NEO_credate := SYSDATE;
    :new.NEO_creuser := USER;
END tr_bif_NEOZOAIRE;
/

