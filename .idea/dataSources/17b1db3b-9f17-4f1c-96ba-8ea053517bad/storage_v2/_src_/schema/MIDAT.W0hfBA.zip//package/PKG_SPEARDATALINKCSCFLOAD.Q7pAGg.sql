create PACKAGE PKG_SPEARDATALINKCSCFLOAD AS
/******************************************************************************
   NAME:       PKG_SPEARDATALINKCSCFLOAD
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        05.10.2017      burrif       1. Created this package.
******************************************************************************/

  FUNCTION f_getversion
      RETURN VARCHAR2;

END PKG_SPEARDATALINKCSCFLOAD;
/

