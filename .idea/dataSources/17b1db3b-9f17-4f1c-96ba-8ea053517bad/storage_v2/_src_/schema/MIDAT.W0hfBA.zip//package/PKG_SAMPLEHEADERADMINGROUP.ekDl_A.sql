create PACKAGE       pkg_sampleheaderadmingroup
AS
   /******************************************************************************
      NAME:       pkg_SAMPLEHEADERADMINGROUP
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
        1.0       24.02.2015 F.Burri           1. Created this package body.
   ******************************************************************************/
   cst_buffersize   CONSTANT NUMBER := 1000;                          --mètres

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_test;

   PROCEDURE p_deleteby_sph_id (
      p_sph_id   IN sampleheaderadmingroup.shg_sph_id%TYPE);

   PROCEDURE p_setorunsetrightpublic (
      p_sph_id         IN sampleheaderadmingroup.shg_sph_id%TYPE,
      p_publicstatus   IN VARCHAR2,
      p_usr_id         IN sampleheaderadmingroup.shg_usr_id_create%TYPE);

   PROCEDURE p_updateadmingroup (
      p_sph_id   IN sampleheaderadmingroup.shg_sph_id%TYPE,
      p_usr_id   IN sampleheaderadmingroup.shg_usr_id_create%TYPE);

   FUNCTION f_getrecordbysstandagr (
      p_sph_id   IN sampleheaderadmingroup.shg_sph_id%TYPE,
      p_agr_id   IN sampleheaderadmingroup.shg_agr_id%TYPE)
      RETURN sampleheaderadmingroup%ROWTYPE;

   PROCEDURE p_updateadmingroup (
      p_sph_id       IN sampleheaderadmingroup.shg_sph_id%TYPE,
      p_usr_id       IN sampleheaderadmingroup.shg_usr_id_create%TYPE,
      p_buffersize   IN NUMBER);
END pkg_sampleheaderadmingroup;
/

