create PROCEDURE       PROCESSPROTOCOL(P_IPH_ID NUMBER)
   AS LANGUAGE JAVA NAME 'com.unine.sitel.ProcessProtocol.processLaboratory(long)';
/

