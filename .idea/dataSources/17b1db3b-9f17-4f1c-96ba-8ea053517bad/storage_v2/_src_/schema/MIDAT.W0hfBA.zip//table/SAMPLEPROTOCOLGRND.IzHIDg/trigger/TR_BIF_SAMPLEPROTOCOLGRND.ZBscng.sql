create trigger TR_BIF_SAMPLEPROTOCOLGRND
    before insert
    on SAMPLEPROTOCOLGRND
    for each row
DECLARE
BEGIN
   IF :new.SPD_id IS NULL
   THEN
      :new.SPD_id := seq_SAMPLEPROTOCOLGRND.NEXTVAL;
   END IF;

   :new.SPD_credate := SYSDATE;
   :new.SPD_creuser := USER;
END tr_bif_SAMPLEPROTOCOLGRND;

/

