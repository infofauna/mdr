create trigger TR_BUF_IMPORTPROTOCOLLOG
    before update
    on IMPORTPROTOCOLLOG
    for each row
DECLARE
BEGIN
 
   :new.IPO_moddate := SYSDATE;
   :new.IPO_moduser := USER;
END tr_buf_IMPORTPROTOCOLLOG;

/

