create trigger TR_BUF_SAMPLEPROTOCOLGRND
    before update
    on SAMPLEPROTOCOLGRND
    for each row
DECLARE
BEGIN
 
   :new.SPD_moddate := SYSDATE;
   :new.SPD_moduser := USER;
END tr_buf_SAMPLEPROTOCOLGRND;

/

