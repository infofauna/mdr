create PACKAGE BODY       pkg_stringutil
AS
   /******************************************************************************
      NAME:       PKG_STRINGUTIL
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        02.10.2013      burrif       1. Created this package.
   ******************************************************************************/
   TYPE t_cursor IS REF CURSOR;

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*---------------------------------------------------------------*/
   FUNCTION f_findkeyword (p_keyword      IN VARCHAR2,
                           p_liststring   IN VARCHAR2,
                           p_separator    IN VARCHAR2)
      RETURN VARCHAR2
   /*---------------------------------------------------------------*/
   IS
      l_indice       PLS_INTEGER;
      l_listindice   pkg_stringutil.t_listofvalue;
      l_found        BOOLEAN;
      l_string       VARCHAR2 (1024);
   BEGIN
      l_string := NULL;
      l_listindice := pkg_stringutil.f_splitstring (p_liststring, p_separator);
      l_indice := l_listindice.FIRST;

      WHILE NOT l_indice IS NULL AND NOT l_found
      LOOP
         IF TRIM (UPPER (l_listindice (l_indice))) = UPPER (TRIM (p_keyword))
         THEN
            l_found := TRUE;
            l_string := l_listindice (l_indice);
         ELSE
            l_indice := l_listindice.NEXT (l_indice);
         END IF;
      END LOOP;

      RETURN l_string;
   END;

   /*--------------------------------------------------------------*/
   FUNCTION f_returnrowcountfromsql (p_sql IN VARCHAR2)
      RETURN NUMBER
   /*-------------------------------------------------------------*/
   IS
      l_sql      VARCHAR2 (9000);
      l_cursor   t_cursor;
      l_count    NUMBER;
   BEGIN
      l_sql := 'SELECT COUNT(*) FROM (' || p_sql || ')';
      pkg_debug.p_write ('PKG_STRINGUTIL.f_returnrowcountfromsql', l_sql);

      OPEN l_cursor FOR l_sql;

      FETCH l_cursor INTO l_count;

      CLOSE l_cursor;

      RETURN l_count;
   END;

   /*---------------------------------------------------------------------*/

   PROCEDURE p_dropsequence (p_sequence IN VARCHAR2)
   /*---------------------------------------------------------------------*/
   IS
      l_sql   VARCHAR2 (1024);
   BEGIN
      l_sql := 'DROP SEQUENCE ' || p_sequence;

      EXECUTE IMMEDIATE l_sql;
   END;

   /*---------------------------------------------------------------------*/

   FUNCTION f_existsequence (p_sequence IN VARCHAR2)
      RETURN BOOLEAN
   /*----------------------------------------------------------------------*/
   IS
      l_lastnumber   NUMBER;
   BEGIN
      SELECT last_number
        INTO l_lastnumber
        FROM user_sequences
       WHERE UPPER (p_sequence) = UPPER (sequence_name);

      RETURN TRUE;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN FALSE;
   END;

   /*---------------------------------------------------------------------*/

   FUNCTION f_returnsequencevalue (p_sequence IN VARCHAR2)
      RETURN NUMBER
   /*--------------------------------------------------------------------*/
   IS
      l_cursor   t_cursor;
      l_sql      VARCHAR2 (1024);
      l_number   NUMBER;
   BEGIN
      l_sql := 'SELECT ' || p_sequence || '.nextval FROM DUAL';

      OPEN l_cursor FOR l_sql;

      FETCH l_cursor INTO l_number;

      CLOSE l_cursor;

      RETURN l_number;
   END;


   /*---------------------------------------------------------------------*/

   PROCEDURE p_createsequence (p_sequence    IN VARCHAR2,
                               p_startwith   IN PLS_INTEGER,
                               p_recreate    IN BOOLEAN)
   /*-----------------------------------------------------------------------*/
   IS
      l_sql         VARCHAR2 (1024);
      l_startwith   NUMBER;
   BEGIN
      IF f_existsequence (p_sequence)
      THEN
         IF p_recreate
         THEN
            p_dropsequence (p_sequence);
         ELSE
            RETURN;
         END IF;
      END IF;

      IF p_startwith IS NULL
      THEN
         l_startwith := 1;
      ELSE
         l_startwith := p_startwith;
      END IF;

      l_sql :=
            'CREATE SEQUENCE '
         || p_sequence
         || ' START WITH '
         || TO_CHAR (l_startwith);

      EXECUTE IMMEDIATE l_sql;
   END;


   /*--------------------------------------------------------------------*/

   FUNCTION f_findcharacterbyend (p_string VARCHAR2, p_char IN CHAR)
      RETURN PLS_INTEGER
   /*---------------------------------------------------------------------*/
   IS
      l_indice   PLS_INTEGER;
      l_length   PLS_INTEGER;
      l_found    BOOLEAN := FALSE;
   BEGIN
      l_length := LENGTH (p_string);
      l_indice := l_length;

      WHILE l_indice > 0 AND NOT l_found
      LOOP
         IF SUBSTR (p_string, l_indice, 1) = p_char
         THEN
            l_found := TRUE;
         ELSE
            l_indice := l_indice - 1;
         END IF;
      END LOOP;

      RETURN l_indice;
   END;

   /*--------------------------------------------------------------------*/
   FUNCTION f_getdatainparenthesis (p_string IN VARCHAR2)
      RETURN VARCHAR2
   /*---------------------------------------------------------------------*/
   IS
      l_pos_start_parenthesis   PLS_INTEGER;
      l_pos_end_parenthesis     PLS_INTEGER;
      l_string                  VARCHAR2 (9000);
   BEGIN
      l_pos_start_parenthesis := INSTR (p_string, '(', 1);

      IF l_pos_start_parenthesis = 0
      THEN
         RETURN p_string;
      END IF;

      l_pos_end_parenthesis := f_findcharacterbyend (p_string, ')');

      IF l_pos_end_parenthesis = 0
      THEN
         RETURN p_string;
      END IF;

      l_string :=
         SUBSTR (p_string,
                 l_pos_start_parenthesis + 1,
                 l_pos_end_parenthesis - l_pos_start_parenthesis - 1);



      RETURN l_string;
   END;



   /*--------------------------------------------------------------------*/
   FUNCTION f_removedatainparenthesis (p_string IN VARCHAR2)
      RETURN VARCHAR2
   /*---------------------------------------------------------------------*/
   IS
      l_pos_start_parenthesis   PLS_INTEGER;
      l_pos_end_parenthesis     PLS_INTEGER;
      l_string                  VARCHAR2 (9000);
   BEGIN
      l_pos_start_parenthesis := INSTR (p_string, '(', 1);

      IF l_pos_start_parenthesis = 0
      THEN
         RETURN p_string;
      ELSE
         l_pos_end_parenthesis := f_findcharacterbyend (p_string, ')');


         IF l_pos_end_parenthesis = 0
         THEN
            RETURN p_string;
         END IF;

         IF l_pos_start_parenthesis = 1
         THEN
            l_string := NULL;
         ELSE
            l_string := SUBSTR (p_string, 1, l_pos_start_parenthesis - 1);
         END IF;



         IF l_pos_end_parenthesis < LENGTH (p_string)
         THEN
            l_string :=
               l_string || SUBSTR (p_string, l_pos_end_parenthesis + 1);
         END IF;
      END IF;

      RETURN l_string;
   END;

   /*---------------------------------------------------------------------*/

   FUNCTION f_formatdecimalformat (p_numberdigit   IN PLS_INTEGER,
                                   p_decimal       IN PLS_INTEGER)
      RETURN VARCHAR2
   /*---------------------------------------------------------------------*/
   IS
      l_format   VARCHAR2 (200);
      l_digit    VARCHAR2 (100);
      l_indice   PLS_INTEGER;
   BEGIN
      FOR l_indice IN 1 .. p_decimal
      LOOP
         l_format := l_format || '9';
      END LOOP;

      FOR l_indice IN 1 .. p_numberdigit
      LOOP
         l_digit := l_digit || '9';
      END LOOP;

      IF NOT l_format IS NULL
      THEN
         l_format := l_digit || '.' || l_format;
      ELSE
         l_format := l_digit;
      END IF;

      RETURN l_format;
   END;



   /*---------------------------------------------------------------------*/

   FUNCTION f_doubleapostrophe (p_string IN VARCHAR2)
      RETURN VARCHAR2
   /*---------------------------------------------------------------------*/
   IS
      l_indice   PLS_INTEGER;
      l_string   VARCHAR2 (18000);
      l_length   PLS_INTEGER;
   BEGIN
      IF INSTR (p_string, '''', 1) = 0
      THEN
         RETURN p_string;
      END IF;

      l_length := LENGTH (p_string);

      FOR l_indice IN 1 .. l_length
      LOOP
         IF SUBSTR (p_string, l_indice, 1) = ''''
         THEN
            l_string := l_string || '''''';
         ELSE
            l_string := l_string || SUBSTR (p_string, l_indice, 1);
         END IF;
      END LOOP;

      RETURN l_string;
   END;



   /*----------------------------------------------------------------------*/

   FUNCTION f_returnelapsedtime (p_time1 IN TIMESTAMP, p_time2 IN TIMESTAMP)
      RETURN NUMBER
   /*-----------------------------------------------------------------------*/
   IS
      l_elapsedtime   NUMBER;
      l_year1         NUMBER;
      l_month1        NUMBER;
      l_day1          NUMBER;
      l_year2         NUMBER;
      l_month2        NUMBER;
      l_day2          NUMBER;
      l_date1         DATE;
      l_date2         DATE;
      l_deltaday      NUMBER;
   BEGIN
      l_day1 := EXTRACT (DAY FROM p_time1);
      l_day2 := EXTRACT (DAY FROM p_time2);
      l_month1 := EXTRACT (MONTH FROM p_time1);
      l_month2 := EXTRACT (MONTH FROM p_time2);
      l_year1 := EXTRACT (YEAR FROM p_time1);
      l_year2 := EXTRACT (YEAR FROM p_time2);


      l_date1 :=
         TO_DATE (
               TO_CHAR (l_day1, '99')
            || '/'
            || TO_CHAR (l_month1, '99')
            || '/'
            || TO_CHAR (l_year1, '9999'),
            'DD/MM/YYYY');
      l_date2 :=
         TO_DATE (
               TO_CHAR (l_day2, '99')
            || '/'
            || TO_CHAR (l_month2, '99')
            || '/'
            || TO_CHAR (l_year2, '9999'),
            'DD/MM/YYYY');
      l_deltaday := l_date1 - l_date2;


      SELECT   (    (  EXTRACT (HOUR FROM p_time1)
                     - EXTRACT (HOUR FROM p_time2))
                  * 3600
                +   (  EXTRACT (MINUTE FROM p_time1)
                     - EXTRACT (MINUTE FROM p_time2))
                  * 60
                + EXTRACT (SECOND FROM p_time1)
                - EXTRACT (SECOND FROM p_time2))
             * 1000
        INTO l_elapsedtime
        FROM DUAL;

      RETURN l_elapsedtime + l_deltaday * 24 * 3600 * 1000;
   END;

   /*-----------------------------------------------------------------------*/

   FUNCTION f_convertmilisecond (p_millisecond IN NUMBER)
      RETURN VARCHAR2
   /*-----------------------------------------------------------------------*/
   IS
      l_seconde      NUMBER;
      l_minute       NUMBER;
      l_heure        NUMBER;
      l_reste        NUMBER;
      l_returntime   VARCHAR2 (20);
   BEGIN
      l_heure := TRUNC (p_millisecond / (1000 * 60 * 60));
      l_reste := p_millisecond - l_heure * 1000 * 60 * 60;
      l_minute := TRUNC (l_reste / (1000 * 60));
      l_reste := l_reste - l_minute * 1000 * 60;
      l_seconde := l_reste / 1000;
      l_returntime :=
            TO_CHAR (l_heure, '00')
         || ':'
         || TO_CHAR (l_minute, '00')
         || ':'
         || TO_CHAR (l_seconde, '00.999');
      RETURN l_returntime;
   END;

   /*-------------------------------------------------------------------------*/

   FUNCTION f_normalisestring (p_string VARCHAR2)
      /*-------------------------------------------------------------------------*/
      RETURN VARCHAR2
      DETERMINISTIC
   IS
      l_string       VARCHAR2 (1024);
      l_string1      VARCHAR2 (1024);
      l_pos          NUMBER := 1;
      l_asciivalue   NUMBER;
   BEGIN
      l_string := UPPER (DECOMPOSE (p_string));

      WHILE l_pos <= LENGTH (l_string)
      LOOP
         l_asciivalue := ASCII (SUBSTR (l_string, l_pos, 1));

         IF    (l_asciivalue >= 65 AND l_asciivalue <= 90)
            OR (l_asciivalue >= 48 AND l_asciivalue <= 57)
         THEN
            IF l_string1 IS NULL
            THEN
               l_string1 := SUBSTR (l_string, l_pos, 1);
            ELSE
               l_string1 := l_string1 || SUBSTR (l_string, l_pos, 1);
            END IF;
         END IF;

         l_pos := l_pos + 1;
      END LOOP;

      RETURN l_string1;
   END;

   /*---------------------------------------------------------------*/

   FUNCTION f_formatpersonnames (p_first_name   IN VARCHAR2,
                                 p_last_name    IN VARCHAR2)
      RETURN VARCHAR2
   /*---------------------------------------------------------------*/
   IS
      l_name   VARCHAR2 (1024);
   BEGIN
      IF p_first_name IS NULL AND p_last_name IS NULL
      THEN
         RETURN NULL;
      END IF;

      IF NOT p_first_name IS NULL AND NOT p_last_name IS NULL
      THEN
         l_name := INITCAP (p_first_name) || ' ' || INITCAP (p_last_name);
         RETURN l_name;
      END IF;

      IF NOT p_first_name IS NULL
      THEN
         l_name := INITCAP (p_first_name);
         RETURN l_name;
      END IF;

      IF NOT p_last_name IS NULL
      THEN
         l_name := INITCAP (p_last_name);
         RETURN l_name;
      END IF;

      RETURN NULL;
   END;

   /*--------------------------------------------------------------*/

   FUNCTION f_buildexcelcellref (p_row IN NUMBER, p_column IN VARCHAR2)
      RETURN VARCHAR2
   /*--------------------------------------------------------------*/
   IS
      l_cellref   VARCHAR2 (128);
      l_column    VARCHAR2 (128);
   BEGIN
      l_column := f_extractsubstring (p_column, ':', 1);
      l_cellref := TRIM (l_column) || TRIM (TO_CHAR (p_row));
      RETURN l_cellref;
   END;

   /*---------------------------------------------------------------------------*/

   FUNCTION f_extractsubstring (p_string      IN VARCHAR2,
                                p_separator   IN VARCHAR2,
                                p_occurence   IN NUMBER)
      RETURN VARCHAR2
   /*  --------------------------------------------------------------------------
   Description:
       Retourne une sous chaine separe par un delimiteur ( un ou plusieurs caracteres)

       Parametres: P_String    => Chaine  de carcteres a traiter
                   P_Separator => Chaine de caracteres servant de separateurs
                   P_Occurence => Numero de l'occurence a extraire

      Retourne NULL si il n'y a pas de sous chaines de l'occurence recherchee
    */
   /*---------------------------------------------------------------------------*/
   IS
      l_startpos       NUMBER;
      l_startpossave   NUMBER;
      l_endpos         NUMBER;
   BEGIN
      IF p_occurence < 1
      THEN
         RETURN NULL;
      END IF;

      l_endpos :=
         INSTR (p_string,
                p_separator,
                1,
                p_occurence);

      IF l_endpos = 0
      THEN
         l_endpos := LENGTH (p_string) + 1;
      END IF;

      IF p_occurence > 1
      THEN
         l_startpossave :=
            INSTR (p_string,
                   p_separator,
                   1,
                   p_occurence - 1);
         l_startpos := l_startpossave + LENGTH (p_separator);
      ELSE
         l_startpossave := 1;
         l_startpos := 1;
      END IF;

      IF l_startpossave = 0
      THEN
         RETURN NULL;
      ELSE
         RETURN SUBSTR (p_string, l_startpos, l_endpos - l_startpos);
      END IF;
   END;

   /*---------------------------------------------------------------------------*/
   PROCEDURE p_test
   /*---------------------------------------------------------------------------*/
   IS
      l_string        VARCHAR2 (1024) := 'IBCH ; SPEAR;MAKROINDEX';
      l_listofvalue   t_listofvalue;
      l_indice        PLS_INTEGER;
   BEGIN
      l_listofvalue := f_splitstring (l_string, ';');
      l_indice := l_listofvalue.FIRST;

      WHILE NOT l_indice IS NULL
      LOOP
         DBMS_OUTPUT.put_line ('*' || l_listofvalue (l_indice) || '*');
         l_indice := l_listofvalue.NEXT (l_indice);
      END LOOP;
   END;

   /*---------------------------------------------------------------------------*/

   FUNCTION f_splitstring (p_string IN VARCHAR2, p_separator IN VARCHAR2)
      RETURN t_listofvalue
   /*---------------------------------------------------------------------------*/
   IS
      l_listofvalue   t_listofvalue := t_listofvalue ();
      l_string        VARCHAR2 (255);
      l_indice        PLS_INTEGER := 1;
   BEGIN
      l_string := f_extractsubstring (p_string, p_separator, l_indice);

      WHILE NOT l_string IS NULL
      LOOP
         l_listofvalue.EXTEND (1);
         l_listofvalue (l_listofvalue.LAST) := TRIM (l_string);
         l_indice := l_indice + 1;
         l_string := f_extractsubstring (p_string, p_separator, l_indice);
      END LOOP;

      RETURN l_listofvalue;
   END;

   /*---------------------------------------------------------------------*/

   FUNCTION f_validatedate (p_date IN VARCHAR2)
      RETURN DATE
   /*---------------------------------------------------------------------*/
   IS
      l_date   DATE;
   BEGIN
      DBMS_OUTPUT.put_line ('DAte= ' || p_date);
      l_date := TO_DATE (p_date);
      RETURN l_date;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   /*-------------------------------------------------------------------------*/

   FUNCTION f_validatenumber (p_numberstring IN VARCHAR2)
      RETURN NUMBER
   /*-------------------------------------------------------------------------*/
   IS
      l_number         NUMBER;
      l_numberstring   VARCHAR2 (100);
      cst_format       VARCHAR2 (100) := '9999999999999D999999999999999999';
      cst_oldformat    VARCHAR2 (100) := '999999999999D99999999';
   BEGIN
      IF INSTR (p_numberstring, ',') > 0
      THEN
         l_number :=
            TO_NUMBER (TRIM (p_numberstring),
                       cst_format,
                       'nls_numeric_characters='', ''');
      ELSE
         l_number :=
            TO_NUMBER (TRIM (p_numberstring),
                       cst_format,
                       'nls_numeric_characters=''. ''');
      END IF;

      RETURN l_number;
   EXCEPTION
      WHEN OTHERS
      THEN
         RETURN NULL;
   END;

   /*-------------------------------------------------------------------------*/

   FUNCTION f_validateinteger (p_numberstring IN VARCHAR2)
      RETURN NUMBER
   /*-------------------------------------------------------------------------*/
   IS
      l_number   NUMBER;
   BEGIN
      l_number := f_validatenumber (p_numberstring);

      IF l_number IS NULL
      THEN
         RETURN NULL;
      END IF;

      IF l_number = TRUNC (l_number)
      THEN
         RETURN l_number;
      END IF;

      RETURN NULL;
   END;

   /*------------------------------------------------------------------------------------------*/
   FUNCTION f_formatnumber (p_number IN NUMBER)
      RETURN VARCHAR2
   /*------------------------------------------------------------------------------------------*/
   IS
      l_numberstring   VARCHAR2 (255);
   BEGIN
      IF NOT p_number IS NULL
      THEN
         l_numberstring := TO_CHAR (p_number);
      ELSE
         l_numberstring := '------';
      END IF;

      RETURN l_numberstring;
   END;


   /*-----------------------------------------------------------------------------------------*/
   FUNCTION f_formatdate (p_day     IN NUMBER,
                          p_month   IN NUMBER,
                          p_year    IN NUMBER)
      RETURN VARCHAR2
   /*------------------------------------------------------------------------------------------*/
   IS
      l_daystring     VARCHAR2 (10);
      l_monthstring   VARCHAR2 (10);
      l_yearstring    VARCHAR2 (10);
   BEGIN
      IF NOT p_day IS NULL
      THEN
         l_daystring := TO_CHAR (p_day);
      ELSE
         l_daystring := '--';
      END IF;

      IF NOT p_month IS NULL
      THEN
         l_monthstring := TO_CHAR (p_month);
      ELSE
         l_monthstring := '--';
      END IF;

      IF NOT p_year IS NULL
      THEN
         l_yearstring := TO_CHAR (p_year);
      ELSE
         l_yearstring := '----';
      END IF;

      RETURN l_daystring || '/' || l_monthstring || '/' || l_yearstring;
   END;
END pkg_stringutil;
/

