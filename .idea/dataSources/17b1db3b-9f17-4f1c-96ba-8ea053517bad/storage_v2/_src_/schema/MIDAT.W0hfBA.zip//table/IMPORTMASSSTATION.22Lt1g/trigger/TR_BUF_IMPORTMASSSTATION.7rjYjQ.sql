create trigger TR_BUF_IMPORTMASSSTATION
    before update
    on IMPORTMASSSTATION
    for each row
DECLARE
   l_newrec   importmassstation%ROWTYPE;
   l_oldrec   importmassstation%ROWTYPE;
BEGIN
   l_oldrec.ims_id := :old.ims_id;
   l_oldrec.ims_status := :old.ims_status;

   l_oldrec.ims_oid := :old.ims_oid;
   l_oldrec.ims_coordinates := :old.ims_coordinates;
   l_oldrec.ims_gewissnr := :old.ims_gewissnr;
   l_oldrec.ims_gemeindenr := :old.ims_gemeindenr;
   l_oldrec.ims_credate := :old.ims_credate;
   l_oldrec.ims_creuser := :old.ims_creuser;
   l_oldrec.ims_moddate := :old.ims_moddate;
   l_oldrec.ims_moduser := :old.ims_moduser;


   l_newrec.ims_id := :new.ims_id;
   l_newrec.ims_status := :new.ims_status;
   l_newrec.ims_oid := :new.ims_oid;
   l_newrec.ims_coordinates := :new.ims_coordinates;
   l_newrec.ims_gewissnr := :new.ims_gewissnr;
   l_newrec.ims_gemeindenr := :new.ims_gemeindenr;
   l_newrec.ims_credate := :new.ims_credate;
   l_newrec.ims_creuser := :new.ims_creuser;
   l_newrec.ims_moddate := :new.ims_moddate;
   l_newrec.ims_moduser := :new.ims_moduser;

   --   pkg_IMPORTMASSSTATION.p_tr_buf_IMPORTMASSSTATION (l_oldrec, l_newrec);

   :new.ims_id := l_newrec.ims_id;

   :new.ims_oid := l_newrec.ims_oid;
   :new.ims_coordinates := l_newrec.ims_coordinates;
   :new.ims_gewissnr := l_newrec.ims_gewissnr;
   :new.ims_gemeindenr := l_newrec.ims_gemeindenr;

   :new.ims_credate := l_newrec.ims_credate;
   :new.ims_creuser := l_newrec.ims_creuser;
   :new.ims_moddate := l_newrec.ims_moddate;
   :new.ims_moduser := l_newrec.ims_moduser;
END;

/

