create trigger TR_BIF_PROCESSINGSTATUS
    before insert
    on PROCESSINGSTATUS
    for each row
DECLARE
BEGIN
   IF :new.pid_id IS NULL
   THEN
      :new.pid_id := seq_PROCESSINGSTATUS.NEXTVAL;
   END IF;

   :new.pid_credate := SYSDATE;
   :new.pid_creuser := USER;
END tr_bif_PROCESSINGSTATUS;

/

