create PACKAGE       pkg_sampleheader
AS
    /******************************************************************************
       NAME:       PKG_SAMPLEHEADER
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        10.10.2013   F.Burri          1. Created this package.
       1.1       20.07.2017  F.Burri           2 Ajout de la gestion des projets
       1.2        17.01.2020   F.Burri          3 Mise à jour des champs statistique IBCH
    ******************************************************************************/



    FUNCTION f_getversion
        RETURN VARCHAR2;

    PROCEDURE p_saveibch_statdata (p_sph_id IN sampleheader.sph_id%TYPE);

    PROCEDURE p_test1;

    FUNCTION f_countother_sph_id_and_sst_id (
        p_sph_id   IN sampleheader.sph_id%TYPE,
        p_sst_id   IN sampleheader.sph_sst_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_countother_iph_id_and_imh_id (
        p_iph_id   IN sampleheader.sph_iph_id%TYPE,
        p_imh_id   IN sampleheader.sph_imh_id%TYPE)
        RETURN NUMBER;

    PROCEDURE p_testdelete;

    PROCEDURE p_delete (p_sph_id IN sampleheader.sph_id%TYPE);

    FUNCTION f_getcountbysmfid (p_smf_id IN sampleheader.sph_smf_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_getcountbysstid (p_sst_id IN sampleheader.sph_sst_id%TYPE)
        RETURN NUMBER;

    FUNCTION f_returnsampleheaderbyiphid (
        p_iph_id   IN importprotocolheader.iph_id%TYPE)
        RETURN sampleheader%ROWTYPE;

    FUNCTION f_checkprotocoleallreadyexist (
        p_iph_id   IN importprotocolheader.iph_id%TYPE)
        RETURN protocolversion.ptv_cvl_id_protocoltype%TYPE;

    PROCEDURE p_clearsph_iph_id (p_iph_id IN sampleheader.sph_iph_id%TYPE);



    PROCEDURE p_test (p_iph_id IN importprotocolheader.iph_id%TYPE);

    FUNCTION f_returnlastrecordbysstid (
        p_sst_id   IN samplestation.sst_id%TYPE)
        RETURN sampleheader%ROWTYPE;

    FUNCTION f_findheaderbyimportdata (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE)
        RETURN sampleheader%ROWTYPE;

    FUNCTION f_findheaderbyimportmassheader (
        p_importmassdataheader   IN importmassdataheader%ROWTYPE)
        RETURN sampleheader%ROWTYPE;

    FUNCTION f_getrecord (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN sampleheader%ROWTYPE;

    FUNCTION f_getrecordbyiphid (p_iph_id IN sampleheader.sph_iph_id%TYPE)
        RETURN sampleheader%ROWTYPE;

    FUNCTION f_getrecordbyoidanddate (
        p_oid                IN samplestation.sst_oid%TYPE,
        p_ins_id_principal   IN sampleheader.sph_ins_id_principal%TYPE,
        p_date               IN sampleheader.sph_observationdate%TYPE,
        p_protocoltype       IN sampleheader.sph_ptv_id%TYPE)
        RETURN sampleheader%ROWTYPE;

    PROCEDURE p_tr_bif_sampleheader (p_newrec IN OUT sampleheader%ROWTYPE);

    PROCEDURE p_tr_buf_sampleheader (p_oldrec   IN     sampleheader%ROWTYPE,
                                     p_newrec   IN OUT sampleheader%ROWTYPE);

    PROCEDURE p_deleteprotocolentry (
        p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE,
        p_ptv_id   IN sampleheader.sph_ptv_id%TYPE);

    PROCEDURE p_deleteprotocolentry (
        p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE);

    PROCEDURE p_setiffilledivr_id (
        p_spearindexvalue         IN     sampleheader.sph_spearindexvalue%TYPE,
        p_indexvalueibch          IN     sampleheader.sph_indexvalueibch%TYPE,
        p_makroindexvalue         IN     sampleheader.sph_makroindexvalue%TYPE,
        p_ivr_cvl_id_spear           OUT sampleheader.sph_ivr_id_spear%TYPE,
        p_ivr_cvl_id_ibch            OUT sampleheader.sph_ivr_id_ibch%TYPE,
        p_ivr_cvl_id_makroindex      OUT sampleheader.sph_ivr_id_makroindex%TYPE);

    /*-----------------------------------------------------------------------------------*/
    PROCEDURE p_savealldata (
        p_iph_lan_id                   IN     importprotocolheader.iph_lan_id%TYPE,
        p_usr_id                       IN     sampleheader.sph_usr_id_create%TYPE,
        p_smf_id                       IN     sampleheader.sph_smf_id%TYPE,
        p_sst_id                       IN     sampleheader.sph_sst_id%TYPE,
        p_iph_id                       IN     sampleheader.sph_iph_id%TYPE,
        p_imh_id                       IN     sampleheader.sph_imh_id%TYPE,
        p_ins_id_principal             IN     sampleheader.sph_ins_id_principal%TYPE,
        p_ins_id_mandatary             IN     sampleheader.sph_ins_id_mandatary%TYPE,
        p_cvl_id_sysprecisionref       IN     sampleheader.sph_cvl_id_sysprecisionref%TYPE,
        p_cvl_id_sysprecision          IN     sampleheader.sph_cvl_id_sysprecision%TYPE,
        p_ptv_id                       IN     sampleheader.sph_ptv_id%TYPE,
        p_cvl_id_windowibch            IN     sampleheader.sph_cvl_id_windowibch%TYPE,
        p_cvl_id_windowmakroindex      IN     sampleheader.sph_cvl_id_windowmakroindex%TYPE,
        p_cvl_id_windowspear           IN     sampleheader.sph_cvl_id_windowspear%TYPE,
        p_project                      IN     sampleheader.sph_project%TYPE,
        p_determinateddate             IN     sampleheader.sph_determinateddate%TYPE,
        p_cvl_id_midatstat             IN     sampleheader.sph_cvl_id_midatstat%TYPE, -- IMH_INDICETYPE doit être traduit en cvl_id_midatstat (pour l'instant on le défini dans le détail)
        p_absolutenumberflag           IN     sampleheader.sph_absolutenumberflag%TYPE,
        p_observationdate              IN     sampleheader.sph_observationdate%TYPE,
        p_observationday               IN     sampleheader.sph_observationday%TYPE,
        p_observationmonth             IN     sampleheader.sph_observationmonth%TYPE,
        p_observationyear              IN     sampleheader.sph_observationyear%TYPE,
        p_period                       IN     sampleheader.sph_period%TYPE,
        p_locality                     IN     sampleheaderitem.shm_item%TYPE,
        p_watercourse                  IN     sampleheaderitem.shm_item%TYPE,
        p_calledplace                  IN     sampleheaderitem.shm_item%TYPE,
        p_title                        IN     sampledocument.spt_title%TYPE,
        p_filename                     IN     sampledocument.spt_filename%TYPE,
        p_indexvalueibch_orig          IN     sampleheader.sph_indexvalueibch_orig%TYPE,
        p_indexvalueibch               IN     sampleheader.sph_indexvalueibch%TYPE,
        p_makroindexvalue_orig         IN     sampleheader.sph_makroindexvalue_orig%TYPE,
        p_makroindexvalue              IN     sampleheader.sph_makroindexvalue%TYPE,
        p_spearindexvalue_orig         IN     sampleheader.sph_spearindexvalue_orig%TYPE,
        p_spearindexvalue              IN     sampleheader.sph_spearindexvalue%TYPE,
        p_cvl_id_mkicase               IN     sampleheader.sph_cvl_id_mkicase%TYPE,
        p_mkirangecount                IN     sampleheader.sph_mkirangecount%TYPE,
        p_mkiinsectacount              IN     sampleheader.sph_mkiinsectacount%TYPE,
        p_mkinonisectacount            IN     sampleheader.sph_mkinonisectacount%TYPE,
        p_mkiplecopteracount           IN     sampleheader.sph_mkiplecopteracount%TYPE,
        p_mkitricopteracount           IN     sampleheader.sph_mkitricopteracount%TYPE,
        p_mkiephemeropteracount        IN     sampleheader.sph_mkiephemeropteracount%TYPE,
        p_mkibaetidaecount             IN     sampleheader.sph_mkibaetidaecount%TYPE,
        p_mkigammaruscount             IN     sampleheader.sph_mkigammaruscount%TYPE,
        p_mkihydropsychecount          IN     sampleheader.sph_mkihydropsychecount%TYPE,
        p_mkiaselluscount              IN     sampleheader.sph_mkiaselluscount%TYPE,
        p_mkihirudinaecount            IN     sampleheader.sph_mkihirudinaecount%TYPE,
        p_mkitubificidaecount          IN     sampleheader.sph_mkitubificidaecount%TYPE,
        p_mkierrornumber               IN     sampleheader.sph_mkierrornumber%TYPE,
        p_identifiedtaxoncount         IN     sampleheader.sph_identifiedtaxoncount%TYPE,
        p_identifiedtaxoncountlowlev   IN     sampleheader.sph_identifiedtaxoncountlowlev%TYPE,
        p_identifiedtaxoncountuplev    IN     sampleheader.sph_identifiedtaxoncountuplev%TYPE,
        p_ibchidentifiedtaxoncount     IN     sampleheader.sph_ibchidentifiedtaxoncount%TYPE,
        p_spearidentifiedtaxoncount    IN     sampleheader.sph_spearidentifiedtaxoncount%TYPE,
        p_ibchgivalue                  IN     sampleheader.sph_ibchgivalue%TYPE,
        p_ibchvtvalue                  IN     sampleheader.sph_ibchvtvalue%TYPE,
        p_visibilitystatus             IN     sampleheader.sph_visibilitystatus%TYPE,
        p_observer                     IN     sampleheaderitem.shm_item%TYPE,
        p_prj_id                       IN     sampleheader.sph_prj_id%TYPE,
        p_ivr_id_spear                 IN     sampleheader.sph_ivr_id_spear%TYPE,
        p_ivr_id_ibch                  IN     sampleheader.sph_ivr_id_ibch%TYPE,
        p_ivr_id_makroindex            IN     sampleheader.sph_ivr_id_makroindex%TYPE,
        p_sph_id                          OUT sampleheader.sph_id%TYPE);

    PROCEDURE p_write (
        p_sst_id                    IN     sampleheader.sph_sst_id%TYPE,
        p_iph_id                    IN     sampleheader.sph_iph_id%TYPE,
        p_imh_id                    IN     sampleheader.sph_imh_id%TYPE,
        p_smf_id                    IN     sampleheader.sph_smf_id%TYPE,
        p_ins_id_principal          IN     sampleheader.sph_ins_id_principal%TYPE,
        p_ins_id_mandatary          IN     sampleheader.sph_ins_id_mandatary%TYPE,
        p_cvl_id_sysprecisionref    IN     sampleheader.sph_cvl_id_sysprecisionref%TYPE,
        p_cvl_id_sysprecision       IN     sampleheader.sph_cvl_id_sysprecision%TYPE,
        p_ptv_id                    IN     sampleheader.sph_ptv_id%TYPE,
        p_cvl_id_windowibch         IN     sampleheader.sph_cvl_id_windowibch%TYPE,
        p_cvl_id_windowmakroindex   IN     sampleheader.sph_cvl_id_windowmakroindex%TYPE,
        p_cvl_id_windowspear        IN     sampleheader.sph_cvl_id_windowspear%TYPE,
        p_project                   IN     sampleheader.sph_project%TYPE,
        p_determinateddate          IN     sampleheader.sph_determinateddate%TYPE,
        p_cvl_id_midatstat          IN     sampleheader.sph_cvl_id_midatstat%TYPE, -- IMH_INDICETYPE doit être traduit en cvl_id_midatstat (pour l'instant on le défini dans le détail)
        p_absolutenumberflag        IN     sampleheader.sph_absolutenumberflag%TYPE,
        p_observationdate           IN     sampleheader.sph_observationdate%TYPE,
        p_observationday            IN     sampleheader.sph_observationday%TYPE,
        p_observationmonth          IN     sampleheader.sph_observationmonth%TYPE,
        p_observationyear           IN     sampleheader.sph_observationyear%TYPE,
        p_period                    IN     sampleheader.sph_period%TYPE,
        p_indexvalueibch            IN     sampleheader.sph_indexvalueibch%TYPE,
        p_indexvalueibch_orig       IN     sampleheader.sph_indexvalueibch_orig%TYPE,
        p_makroindexvalue           IN     sampleheader.sph_makroindexvalue%TYPE,
        p_makroindexvalue_orig      IN     sampleheader.sph_makroindexvalue_orig%TYPE,
        p_spearindexvalue           IN     sampleheader.sph_spearindexvalue%TYPE,
        p_spearindexvalue_orig      IN     sampleheader.sph_spearindexvalue_orig%TYPE,
        p_usr_id                    IN     sampleheader.sph_usr_id_create%TYPE,
        p_visibilitystatus          IN     sampleheader.sph_visibilitystatus%TYPE,
        p_prj_id                    IN     sampleheader.sph_prj_id%TYPE,
        p_ivr_id_spear              IN     sampleheader.sph_ivr_id_spear%TYPE,
        p_ivr_id_ibch               IN     sampleheader.sph_ivr_id_ibch%TYPE,
        p_ivr_id_makroindex         IN     sampleheader.sph_ivr_id_makroindex%TYPE,
        p_id                           OUT sampleheader.sph_id%TYPE);

    PROCEDURE p_writefull (
        p_sst_id                      IN     sampleheader.sph_sst_id%TYPE,
        p_iph_id                      IN     sampleheader.sph_iph_id%TYPE,
        p_imh_id                      IN     sampleheader.sph_imh_id%TYPE,
        p_smf_id                      IN     sampleheader.sph_smf_id%TYPE,
        p_ins_id_principal            IN     sampleheader.sph_ins_id_principal%TYPE,
        p_ins_id_mandatary            IN     sampleheader.sph_ins_id_mandatary%TYPE,
        p_cvl_id_sysprecisionref      IN     sampleheader.sph_cvl_id_sysprecisionref%TYPE,
        p_cvl_id_sysprecision         IN     sampleheader.sph_cvl_id_sysprecision%TYPE,
        p_ptv_id                      IN     sampleheader.sph_ptv_id%TYPE,
        p_cvl_id_windowibch           IN     sampleheader.sph_cvl_id_windowibch%TYPE,
        p_cvl_id_windowmakroindex     IN     sampleheader.sph_cvl_id_windowmakroindex%TYPE,
        p_cvl_id_windowspear          IN     sampleheader.sph_cvl_id_windowspear%TYPE,
        p_project                     IN     sampleheader.sph_project%TYPE,
        p_determinateddate            IN     sampleheader.sph_determinateddate%TYPE,
        p_cvl_id_midatstat            IN     sampleheader.sph_cvl_id_midatstat%TYPE, -- IMH_INDICETYPE doit être traduit en cvl_id_midatstat (pour l'instant on le défini dans le détail)
        p_absolutenumberflag          IN     sampleheader.sph_absolutenumberflag%TYPE,
        p_observationdate             IN     sampleheader.sph_observationdate%TYPE,
        p_observationday              IN     sampleheader.sph_observationday%TYPE,
        p_observationmonth            IN     sampleheader.sph_observationmonth%TYPE,
        p_observationyear             IN     sampleheader.sph_observationyear%TYPE,
        p_period                      IN     sampleheader.sph_period%TYPE,
        p_indexvalueibch              IN     sampleheader.sph_indexvalueibch%TYPE,
        p_indexvalueibch_orig         IN     sampleheader.sph_indexvalueibch_orig%TYPE,
        p_makroindexvalue             IN     sampleheader.sph_makroindexvalue%TYPE,
        p_makroindexvalue_orig        IN     sampleheader.sph_makroindexvalue_orig%TYPE,
        p_spearindexvalue             IN     sampleheader.sph_spearindexvalue%TYPE,
        p_spearindexvalue_orig        IN     sampleheader.sph_spearindexvalue_orig%TYPE,
        p_usr_id                      IN     sampleheader.sph_usr_id_create%TYPE,
        p_visibilitystatus            IN     sampleheader.sph_visibilitystatus%TYPE,
        p_prj_id                      IN     sampleheader.sph_prj_id%TYPE,
        p_ivr_id_spear                IN     sampleheader.sph_ivr_id_spear%TYPE,
        p_ivr_id_ibch                 IN     sampleheader.sph_ivr_id_ibch%TYPE,
        p_ivr_id_makroindex           IN     sampleheader.sph_ivr_id_makroindex%TYPE,
        p_sommeneoz                   IN     sampleheader.sph_sommeneoz%TYPE,
        p_autreneoz_1                 IN     sampleheader.sph_autreneoz_1%TYPE,
        p_autreneoz_2                 IN     sampleheader.sph_autreneoz_2%TYPE,
        p_sommeept                    IN     sampleheader.sph_sommeept%TYPE,
        p_sommeabon                   IN     sampleheader.sph_sommeabon%TYPE,
        p_sommetxobs                  IN     sampleheader.sph_sommetxobs%TYPE,
        p_sommetxcor                  IN     sampleheader.sph_sommetxcor%TYPE,
        p_valeurvt                    IN     sampleheader.sph_valeurvt%TYPE,
        p_valeurgi                    IN     sampleheader.sph_valeurgi%TYPE,
        p_valeurgimax                 IN     sampleheader.sph_valeurgimax%TYPE,
        p_ibchq                       IN     sampleheader.sph_ibchq%TYPE,
        p_vc                          IN     sampleheader.sph_vc%TYPE,
        p_taxonindicateur             IN     sampleheader.sph_taxonindicateur%TYPE,
        p_ibchrobust                  IN     sampleheader.sph_ibchrobust%TYPE,
        p_classevariete               IN     sampleheader.sph_classevariete%TYPE,
        p_classevariete_corr          IN     sampleheader.sph_classevariete_corr%TYPE,
        p_classevarieterobust         IN     sampleheader.sph_classevarieterobust%TYPE,
        p_classevarieterobust_corr    IN     sampleheader.sph_classevarieterobust_corr%TYPE,
        p_classevariete_final         IN     sampleheader.sph_classevariete_final%TYPE,
        p_classevarieterobust_final   IN     sampleheader.sph_classevarieterobust_final%TYPE,
        p_taxonfrequencesum           IN     sampleheader.sph_taxonfrequencesum%TYPE,
        p_gimax                       IN     sampleheader.sph_gimax%TYPE,
        p_gimaxrobust                 IN     sampleheader.sph_gimaxrobust%TYPE,
        p_gi_final                    IN     sampleheader.sph_gi_final%TYPE,
        p_girobust_final              IN     sampleheader.sph_girobust_final%TYPE,
        p_sumfamily                   IN     sampleheader.sph_sumfamily%TYPE,
        p_sumfamilycorrected          IN     sampleheader.sph_sumfamilycorrected%TYPE,
        p_sumfamilyrobust             IN     sampleheader.sph_sumfamilyrobust%TYPE,
        p_sumfamilyrobustcorrected    IN     sampleheader.sph_sumfamilyrobustcorrected%TYPE,
        p_ephemeropteracounter        IN     sampleheader.sph_ephemeropteracounter%TYPE,
        p_plecopteracounter           IN     sampleheader.sph_plecopteracounter%TYPE,
        p_tricopteracounter           IN     sampleheader.sph_tricopteracounter%TYPE,
        p_id                             OUT sampleheader.sph_id%TYPE);

    PROCEDURE p_write (
        p_sst_id                    IN     sampleheader.sph_sst_id%TYPE,
        p_iph_id                    IN     sampleheader.sph_iph_id%TYPE,
        p_imh_id                    IN     sampleheader.sph_imh_id%TYPE,
        p_smf_id                    IN     sampleheader.sph_smf_id%TYPE,
        p_ins_id_principal          IN     sampleheader.sph_ins_id_principal%TYPE,
        p_ins_id_mandatary          IN     sampleheader.sph_ins_id_mandatary%TYPE,
        p_cvl_id_sysprecisionref    IN     sampleheader.sph_cvl_id_sysprecisionref%TYPE,
        p_cvl_id_sysprecision       IN     sampleheader.sph_cvl_id_sysprecision%TYPE,
        p_ptv_id                    IN     sampleheader.sph_ptv_id%TYPE,
        p_cvl_id_windowibch         IN     sampleheader.sph_cvl_id_windowibch%TYPE,
        p_cvl_id_windowmakroindex   IN     sampleheader.sph_cvl_id_windowmakroindex%TYPE,
        p_cvl_id_windowspear        IN     sampleheader.sph_cvl_id_windowspear%TYPE,
        p_project                   IN     sampleheader.sph_project%TYPE,
        p_determinateddate          IN     sampleheader.sph_determinateddate%TYPE,
        p_cvl_id_midatstat          IN     sampleheader.sph_cvl_id_midatstat%TYPE, -- IMH_INDICETYPE doit être traduit en cvl_id_midatstat (pour l'instant on le défini dans le détail)
        p_absolutenumberflag        IN     sampleheader.sph_absolutenumberflag%TYPE,
        p_observationdate           IN     sampleheader.sph_observationdate%TYPE,
        p_observationday            IN     sampleheader.sph_observationday%TYPE,
        p_observationmonth          IN     sampleheader.sph_observationmonth%TYPE,
        p_observationyear           IN     sampleheader.sph_observationyear%TYPE,
        p_period                    IN     sampleheader.sph_period%TYPE,
        p_indexvalueibch            IN     sampleheader.sph_indexvalueibch%TYPE,
        p_indexvalueibch_orig       IN     sampleheader.sph_indexvalueibch_orig%TYPE,
        p_makroindexvalue           IN     sampleheader.sph_makroindexvalue%TYPE,
        p_makroindexvalue_orig             sampleheader.sph_makroindexvalue_orig%TYPE,
        p_spearindexvalue           IN     sampleheader.sph_spearindexvalue%TYPE,
        p_spearindexvalue_orig             sampleheader.sph_spearindexvalue_orig%TYPE,
        p_usr_id                    IN     sampleheader.sph_usr_id_create%TYPE,
        p_visibilitystatus          IN     sampleheader.sph_visibilitystatus%TYPE,
        p_prj_id                    IN     sampleheader.sph_prj_id%TYPE,
        p_ivr_id_spear              IN     sampleheader.sph_ivr_id_spear%TYPE,
        p_ivr_id_ibch               IN     sampleheader.sph_ivr_id_ibch%TYPE,
        p_ivr_id_makroindex         IN     sampleheader.sph_ivr_id_makroindex%TYPE,
        p_ibch_sum_taxon            IN     sampleheader.sph_ibch_sum_taxon%TYPE,
        p_ibch_sum_ephemeroptera    IN     sampleheader.sph_ibch_sum_ephemeroptera%TYPE,
        p_ibch_sum_plecoptera       IN     sampleheader.sph_ibch_sum_plecoptera%TYPE,
        p_ibch_sum_tricoptera       IN     sampleheader.sph_ibch_sum_tricoptera%TYPE,
        p_ibch_indicator_group      IN     sampleheader.sph_ibch_indicator_group%TYPE,
        p_sommeneoz                 IN     sampleheader.sph_sommeneoz%TYPE,
        p_autreneoz_1               IN     sampleheader.sph_autreneoz_1%TYPE,
        p_autreneoz_2               IN     sampleheader.sph_autreneoz_2%TYPE,
        p_sommeept                  IN     sampleheader.sph_sommeept%TYPE,
        p_sommeabon                 IN     sampleheader.sph_sommeabon%TYPE,
        p_sommetxobs                IN     sampleheader.sph_sommetxobs%TYPE,
        p_sommetxcor                IN     sampleheader.sph_sommetxcor%TYPE,
        p_valeurvt                  IN     sampleheader.sph_valeurvt%TYPE,
        p_valeurgi                  IN     sampleheader.sph_valeurgi%TYPE,
        p_valeurgimax               IN     sampleheader.sph_valeurgimax%TYPE,
        p_ibchq                     IN     sampleheader.sph_ibchq%TYPE,
        p_vc                        IN     sampleheader.sph_vc%TYPE,
        p_id                           OUT sampleheader.sph_id%TYPE);
END pkg_sampleheader;
/

