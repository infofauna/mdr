create trigger TR_BIF_SAMPLEHEADERFILE
    before insert
    on SAMPLEHEADERFILE
    for each row
DECLARE
BEGIN
   IF :new.SHF_id IS NULL
   THEN
      :new.SHF_id := seq_SAMPLEHEADERFILE.NEXTVAL;
   END IF;

   :new.SHF_credate := SYSDATE;
   :new.SHF_creuser := USER;
END tr_bif_SAMPLEHEADERFILE;

/

