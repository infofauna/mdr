create PACKAGE BODY       pkg_migr_avaliabilitycalendar
AS
   /******************************************************************************
      NAME:       PKG_MIGR_AVALIABILITYCALENDAR
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        28/07/2014      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, juillet  2014' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*-------------------------------------------------------------*/
   PROCEDURE p_buildall
   /*------------------------------------------------------------*/
   IS
   BEGIN
      pkg_avaliabilitycalendar.p_deleteall;
      p_build_ibch;
      p_build_spear;
   END;

   /*------------------------------------------------------------*/
   PROCEDURE p_build_ibch
   /*------------------------------------------------------------*/
   IS
      l_reccodevalue              codevalue%ROWTYPE;
      l_id                        avaliabilitycalendar.iac_id%TYPE;
      l_recordvalueperiodouter    codevalue%ROWTYPE;
      l_recordvalueperiodtampon   codevalue%ROWTYPE;
      l_recordvalueperiodnormal   codevalue%ROWTYPE;
   BEGIN
      l_recordvalueperiodouter :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatwindow,
            pkg_codevalue.cst_midat_window_outer);
      l_recordvalueperiodtampon :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatwindow,
            pkg_codevalue.cst_midat_window_tampon);
      l_recordvalueperiodnormal :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatwindow,
            pkg_codevalue.cst_midat_window_normal);
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_ibch);
      -- 200-600 mètres
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodtampon.cvl_id, -- periodtype
                                        200,            ---elevationmin      ,
                                        600,                   -- elevationmax
                                        16,                        -- startday
                                        28,                         --  endday
                                        2,                      --  startmonth
                                        2,                          --endmonth
                                        l_id);
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodnormal.cvl_id, -- periodtype
                                        200,            ---elevationmin      ,
                                        600,                   -- elevationmax
                                        1,                         -- startday
                                        31,                         --  endday
                                        3,                      --  startmonth
                                        3,                          --endmonth
                                        l_id);
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodtampon.cvl_id, -- periodtype
                                        200,            ---elevationmin      ,
                                        600,                   -- elevationmax
                                        1,                         -- startday
                                        15,                         --  endday
                                        4,                      --  startmonth
                                        4,                          --endmonth
                                        l_id);



      -- 601-1000 mètres
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodtampon.cvl_id, -- periodtype
                                        601,            ---elevationmin      ,
                                        1000,                  -- elevationmax
                                        16,                        -- startday
                                        31,                         --  endday
                                        3,                      --  startmonth
                                        3,                          --endmonth
                                        l_id);
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodnormal.cvl_id, -- periodtype
                                        601,            ---elevationmin      ,
                                        1000,                  -- elevationmax
                                        1,                         -- startday
                                        30,                         --  endday
                                        4,                      --  startmonth
                                        4,                          --endmonth
                                        l_id);
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodtampon.cvl_id, -- periodtype
                                        601,            ---elevationmin      ,
                                        1000,                  -- elevationmax
                                        1,                         -- startday
                                        15,                         --  endday
                                        5,                      --  startmonth
                                        5,                          --endmonth
                                        l_id);

      -- 1001-1400 mètres
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodtampon.cvl_id, -- periodtype
                                        1001,           ---elevationmin      ,
                                        1400,                  -- elevationmax
                                        1,                         -- startday
                                        15,                         --  endday
                                        4,                      --  startmonth
                                        4,                          --endmonth
                                        l_id);
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodnormal.cvl_id, -- periodtype
                                        1001,           ---elevationmin      ,
                                        1400,                  -- elevationmax
                                        16,                        -- startday
                                        15,                         --  endday
                                        4,                      --  startmonth
                                        5,                          --endmonth
                                        l_id);
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodtampon.cvl_id, -- periodtype
                                        1001,           ---elevationmin      ,
                                        1400,                  -- elevationmax
                                        16,                        -- startday
                                        31,                         --  endday
                                        5,                      --  startmonth
                                        5,                          --endmonth
                                        l_id);

      -- 1401-1800 mètres
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodtampon.cvl_id, -- periodtype
                                        1401,           ---elevationmin      ,
                                        1800,                  -- elevationmax
                                        16,                        -- startday
                                        30,                         --  endday
                                        4,                      --  startmonth
                                        4,                          --endmonth
                                        l_id);
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodnormal.cvl_id, -- periodtype
                                        1401,           ---elevationmin      ,
                                        1800,                  -- elevationmax
                                        1,                         -- startday
                                        31,                         --  endday
                                        5,                      --  startmonth
                                        5,                          --endmonth
                                        l_id);
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodtampon.cvl_id, -- periodtype
                                        1401,           ---elevationmin      ,
                                        1800,                  -- elevationmax
                                        1,                         -- startday
                                        15,                         --  endday
                                        6,                      --  startmonth
                                        6,                          --endmonth
                                        l_id);



      -- 1800 mètres
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodtampon.cvl_id, -- periodtype
                                        1801,           ---elevationmin      ,
                                        9999,                  -- elevationmax
                                        16,                        -- startday
                                        31,                         --  endday
                                        5,                      --  startmonth
                                        5,                          --endmonth
                                        l_id);
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodnormal.cvl_id, -- periodtype
                                        1801,           ---elevationmin      ,
                                        9999,                  -- elevationmax
                                        1,                         -- startday
                                        30,                         --  endday
                                        6,                      --  startmonth
                                        6,                          --endmonth
                                        l_id);
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodtampon.cvl_id, -- periodtype
                                        1801,           ---elevationmin      ,
                                        9999,                  -- elevationmax
                                        1,                         -- startday
                                        15,                         --  endday
                                        7,                      --  startmonth
                                        7,                          --endmonth
                                        l_id);
   END;

   /*------------------------------------------------------------*/
   PROCEDURE p_build_makroindex
   /*------------------------------------------------------------*/
   IS
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_makroindex);
   END;

   /*------------------------------------------------------------*/
   PROCEDURE p_build_spear
   /*------------------------------------------------------------*/
   IS
      l_reccodevalue              codevalue%ROWTYPE;
      l_id                        avaliabilitycalendar.iac_id%TYPE;
      l_recordvalueperiodouter    codevalue%ROWTYPE;
      l_recordvalueperiodtampon   codevalue%ROWTYPE;
      l_recordvalueperiodnormal   codevalue%ROWTYPE;
   BEGIN
      l_recordvalueperiodouter :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatwindow,
            pkg_codevalue.cst_midat_window_outer);
      l_recordvalueperiodtampon :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatwindow,
            pkg_codevalue.cst_midat_window_tampon);
      l_recordvalueperiodnormal :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatwindow,
            pkg_codevalue.cst_midat_window_normal);
      l_reccodevalue :=
         pkg_codevalue.f_getrecordbycode (
            pkg_codereference.cst_crf_midatindice,
            pkg_codevalue.cst_midatindice_spear);
      -- 200-9999mètres
      pkg_avaliabilitycalendar.p_write (l_reccodevalue.cvl_id,  -- midatindice
                                        l_recordvalueperiodnormal.cvl_id,
                                        -9999,            ---elevationmin      ,
                                        9999,                  -- elevationmax
                                        15,                        -- startday
                                        30,                         --  endday
                                        4,                      --  startmonth
                                        6,                          --endmonth
                                        l_id);
   END;
END pkg_migr_avaliabilitycalendar;
/

