create trigger TR_BUF_PROTOCOLINDICEVERSION
    before update
    on PROTOCOLINDICEVERSION
    for each row
DECLARE
BEGIN
 
   :new.PiV_moddate := SYSDATE;
   :new.PiV_moduser := USER;
END tr_buf_PROTOCOLINDICEVERSION;

/

