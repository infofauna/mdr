create PACKAGE BODY       pkg_delete_protocol
AS
    /******************************************************************************
       NAME:       PKG_DELETE
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        19.10.2017      burrif       1. Created this package.
       1.1        17.12.2018      burrif       2. Correction bug suppression de masse (fonction f_getcountims_id)
    ******************************************************************************/



    /*
    Attention: Il faut purger les données non enregistrées
               Exemple: Dans la table IMPORTPROTOCOLHEADER il peut y avoir plusieurs IPH_IPH_ID

    Supprimer un sampleheader
     -- Créer depuis le protocol de  laboratoire
        1) Supprimer les données de la table sampleheaderitem (SPH_ID)
        2) Supprimer les données de la table sampleheaderfile (SPH_ID)
        3) Supprimer les données de la table sampleheaderadmingroup (SPH_ID)
        4) Supprimer les données de la table sampleprotocollabo
        5) Supprimer conditionnellement les données de la table samplestation, samplestationitem  (SPH_ID) (SST_SPH_ID)
           et définir avec la valeur NULL la colonne IPH_SST_ID_EXISTING
        -- On ne peut pas supprimer ici les données de la table sampleheader car on en a besoin
        6) Supprimer les données de la table sampledocument (SPH_ID)
        7) Supprimer les données de la table sampleloadcomment (SPH_ID)
        8) Supprimer les données de la table indicehistory (SPH_ID)
        9) Supprimer les données de la table importprotocollabo (SPH_IPH_ID)
       10) Supprimer les données de la table importprotocollogparam
       11) Supprimer les données de la table importprotocollog (SPH_IPH_ID)
       12) Supprimer les données de la table importprotocolheader  (SPH_IPH_ID)
       13) Supprimer les données de la table sampleheader (SPH_ID)

     -- Créer depuis un protocole de masse

     1) Supprimer les données de la table sampleheaderitem (SPH_ID)
        2) Supprimer les données de la table sampleheadermassfile (SPH_ID)
        3) Supprimer les données de la table sampleheaderadmingroup (SPH_ID)
        4) Supprimer les données de la table sampleprotocollabo
        5) Supprimer conditionnellement les données de la table samplestation, samplestationitem (SPH_ID) (SST_SPH_ID)
           et définir avec la valeur NULL la colonne IMS_SST_ID_OIDLINK
        -- On ne peut pas supprimer ici les données de la table sampleheader car on en a besoin
        6) Supprimer les données de la table sampledocument (SPH_ID)
        7) Supprimer les données de la table sampleloadcomment (SPH_ID)
        8) Supprimer les données de la table indicehistory (SPH_ID)
        9) Supprimer les données de la table samplemkidetailgroup(SPH_ID)
       10) supprimer les données de la table sampleprotocolmass (SPH_ID)

       11) Supprimer les données de la table importmassstation (SPH_IPH_ID, SST_ID)
       12) Supprimer les données de la table importmassdataheader (SPH_IPH_ID)
       13) Supprimer les données de la table importmassdetailheader (SPH_IPH_ID, IMS_ID)
       14) Supprimer les données de la table importprotocollogparam (seulement si IMH_IPH_ID est non trouvé)
       15) Supprimer les données de la table importprotocollog (seulement si IMH_IPH_ID est non trouvé)
       16) Supprimer les données de la table importmassmappingheader (seulement si IMH_IPH_ID est non trouvé)
       17) Supprimer les données de la table importprotocolheader  (seulement si IMH_IPH_ID est non trouvé)
       18) Supprimer les données de la table sampleheader(SPH_ID)

    Supprimer un protocole GRID
        1) Supprimer les données de la table sampleprotocolgrid (SPH_ID)
        2) Supprimer les données de la table sampleheaderfile (SPH_ID)
        3) Supprimer les données de la table importprotocolgrid (SPH_ID)
        3) Supprimer les données de la table importprotocollogparam
        4) Supprimer les données de la table importprotocollog (SPH_IPH_ID)
        5) Supprimer les données de la table importprotocolheader (SPH_IPH_ID)

    Supprimer un protocole GROUND
        1) Supprimer les données de la table sampleprotocolgrnd (SPH_ID)
        2) Supprimer les données de la table sampleheaderfile (SPH_ID)
        3) Supprimer les données de la table importprotocolgrnd (SPH_ID)
        3) Supprimer les données de la table importprotocollogparam
        4) Supprimer les données de la table importprotocollog (SPH_IPH_ID)
        5) Supprimer les données de la table importprotocolheader (SPH_IPH_ID)



    */



    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.1, décembre  2018' ;

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_deleteprotocolentry (
        p_sph_id   IN sampleheader.sph_id%TYPE,
        p_ptv_id   IN protocolversion.ptv_id%TYPE)
    /*------------------------------------------------------------------*/
    IS
        l_recprotocolversion        protocolversion%ROWTYPE;
        l_reccodevalue              codevalue%ROWTYPE;
        l_recsampleheader           sampleheader%ROWTYPE;
        l_recimportmassdataheader   importmassdataheader%ROWTYPE;
    BEGIN
        l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);
        l_reccodevalue :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);

        IF l_reccodevalue.cvl_code =
           pkg_codevalue.cst_protocoltype_laboratory
        THEN
            p_delete_labo (p_sph_id);
        ELSIF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_ground
        THEN
            p_delete_grnd (p_sph_id);
        ELSIF l_reccodevalue.cvl_code =
              pkg_codevalue.cst_protocoltype_grdeval
        THEN
            p_delete_grid (p_sph_id);
        ELSIF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_mass
        THEN
            p_delete_mass (p_sph_id);
            NULL;
        END IF;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_deleteprotocolentry (p_sph_id IN sampleheader.sph_id%TYPE)
    /*------------------------------------------------------------------*/
    IS
        /* Si le PTV_ID n'est pas  founi, on considère que c'est un protocole prinicipa et c'est le SPH_PTV_ID qui est utilisé
           Ce n'est pas un protocol additionnelle
        */
        l_recsampleheader   sampleheader%ROWTYPE;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
        p_deleteprotocolentry (p_sph_id, l_recsampleheader.sph_ptv_id);
    END;



    /*------------------------------------------------------------------*/
    PROCEDURE p_delete_grnd (p_sph_id IN sampleheader.sph_id%TYPE)
    /*-------------------------------------------------------------------*/
    IS
        l_recsampleheaderfile   sampleheaderfile%ROWTYPE;
        l_recsampleheader       sampleheader%ROWTYPE;
        l_reccodevalue          codevalue%ROWTYPE;
    BEGIN
        l_reccodevalue :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_protocoltype_ground,
                pkg_codereference.cst_crf_midatproto);
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
        DBMS_OUTPUT.put_line ('Protocole de ground. Suppression');
        l_recsampleheaderfile :=
            pkg_sampleheaderfile.f_getbysphidandprotocoltype (
                l_recsampleheader.sph_id,
                pkg_codevalue.cst_protocoltype_ground);
        pkg_sampleprotocolgrnd.p_deleteby_sph_id (l_recsampleheader.sph_id);
        pkg_importprotocolgrnd.p_deletebyiphid (
            l_recsampleheaderfile.shf_iph_id);
        pkg_sampleheaderfile.p_delete (l_recsampleheaderfile.shf_id);

        pkg_importprotocollog.p_deleteby_iph_id (
            l_recsampleheaderfile.shf_iph_id);               -- Inclu logparam
        pkg_importprotocolheader.p_delete (l_recsampleheaderfile.shf_iph_id);
        pkg_sampleheaderitem.p_deleteby_cvl_id_protocoltype (
            p_sph_id,
            l_reccodevalue.cvl_id);
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_delete_grid (p_sph_id IN sampleheader.sph_id%TYPE)
    /*-------------------------------------------------------------------*/
    IS
        l_recsampleheaderfile   sampleheaderfile%ROWTYPE;
        l_recsampleheader       sampleheader%ROWTYPE;
        l_reccodevalue          codevalue%ROWTYPE;
    BEGIN
        l_reccodevalue :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_protocoltype_grdeval,
                pkg_codereference.cst_crf_midatproto);
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
        DBMS_OUTPUT.put_line ('Protocole de grid. Suppression');
        l_recsampleheaderfile :=
            pkg_sampleheaderfile.f_getbysphidandprotocoltype (
                l_recsampleheader.sph_id,
                pkg_codevalue.cst_protocoltype_grdeval);
        pkg_sampleprotocolgrid.p_deleteby_sph_id (l_recsampleheader.sph_id);
        pkg_importprotocolgrid.p_deletebyiphid (
            l_recsampleheaderfile.shf_iph_id);
        pkg_sampleheaderfile.p_delete (l_recsampleheaderfile.shf_id);
        pkg_importprotocollog.p_deleteby_iph_id (
            l_recsampleheaderfile.shf_iph_id);               -- Inclu logparam
        pkg_importprotocolheader.p_delete (l_recsampleheaderfile.shf_iph_id);
        DBMS_OUTPUT.put_line (
            'l_reccodevalue.cvl_id=' || l_reccodevalue.cvl_id);
        pkg_sampleheaderitem.p_deleteby_cvl_id_protocoltype (
            p_sph_id,
            l_reccodevalue.cvl_id);
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_delete_children (p_iph_id importprotocolheader.iph_id%TYPE)
    /*--------------------------------------------------------------*/
    IS
        CURSOR l_listimportprotocolheader
        IS
            SELECT *
              FROM importprotocolheader
             WHERE iph_iph_id = p_iph_id;

        l_reclistimportprotocolheader   l_listimportprotocolheader%ROWTYPE;
        l_recimportprotocolheader       importprotocolheader%ROWTYPE;
    BEGIN
        DBMS_OUTPUT.put_line ('p_delete_children p_iph_id=' || p_iph_id);

        OPEN l_listimportprotocolheader;

        LOOP
            FETCH l_listimportprotocolheader
                INTO l_reclistimportprotocolheader;

            EXIT WHEN l_listimportprotocolheader%NOTFOUND;
            p_purgeby_iph_id (l_reclistimportprotocolheader.iph_id);
        END LOOP;

        CLOSE l_listimportprotocolheader;

        NULL;
    END;



    /*---------------------------------------------------------------*/
    PROCEDURE p_delete_labo (p_sph_id IN sampleheader.sph_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
        l_recsampleheader           sampleheader%ROWTYPE;
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        DBMS_OUTPUT.put_line ('Protocole de labo. Suppression');
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
        p_delete_grid (l_recsampleheader.sph_id);
        p_delete_grnd (l_recsampleheader.sph_id);
        pkg_importprotocollog.p_deleteby_iph_id (
            l_recsampleheader.sph_iph_id);                   -- Inclu logparam
        pkg_sampledocument.p_deleteby_sph_id (p_sph_id);
        pkg_sampleheaderadmingroup.p_deleteby_sph_id (p_sph_id);
        pkg_sampleheaderfile.p_deleteby_sph_id (p_sph_id);
        pkg_sampleloadcomment.p_deleteby_sph_id (p_sph_id);

        pkg_sampleprotocollabo.p_deleteby_sph_id (p_sph_id);

        pkg_importprotocollabo.p_deletebyiphid (l_recsampleheader.sph_iph_id);

        pkg_sampleheaderitem.p_deleteby_sph_id (p_sph_id);

        pkg_sampleheader.p_delete (p_sph_id);
        pkg_samplestation.p_deleteifnomoreused (p_sph_id,
                                                l_recsampleheader.sph_sst_id);
        -- Le protocol labo peut être référencé par des protocoles invalides ou non confirmée
        p_delete_children (l_recsampleheader.sph_iph_id);
        p_purgenotconfirmed (p_sph_id);

        pkg_importprotocolheader.p_delete (l_recsampleheader.sph_iph_id); -- Ne peut pas être détruit avant le sampleheader
    END;


    /*---------------------------------------------------------------*/
    PROCEDURE p_delete_mass (p_sph_id IN sampleheader.sph_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
        l_recmassdataheader   importmassdataheader%ROWTYPE;
        l_recsampleheader     sampleheader%ROWTYPE;
        l_count               NUMBER;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
        -- On peut "tout" détruire si le protocole de masse ne contient plus qu'un header
        l_recmassdataheader :=
            pkg_importmassdataheader.f_getrecord (
                l_recsampleheader.sph_imh_id);
        l_count :=
            pkg_importmassdataheader.f_getcountvalidentries (
                l_recsampleheader.sph_iph_id);
        DBMS_OUTPUT.put_line ('p_sph_id=' || p_sph_id);

        IF l_count = 1
        THEN
            DBMS_OUTPUT.put_line (
                'Protocole de masse, suppression complète');
            pkg_importprotocollog.p_deleteby_iph_id (
                l_recsampleheader.sph_iph_id);               -- Inclu logparam
            pkg_importmassdataheader.p_deletebyiph_id (
                l_recsampleheader.sph_iph_id);
            pkg_importmassstation.p_deletebyiph_id (
                l_recsampleheader.sph_iph_id);

            pkg_importmassdatadetail.p_deletebyiph_id (
                l_recsampleheader.sph_iph_id);
            pkg_importmassmappingheader.p_deletebyiph_id (
                l_recsampleheader.sph_iph_id);

            p_delete_grid (l_recsampleheader.sph_id); -- Si il y a des protocoles associées on les détruits
            p_delete_grnd (l_recsampleheader.sph_id);
            pkg_sampledocument.p_deleteby_sph_id (p_sph_id);
            pkg_sampleheaderadmingroup.p_deleteby_sph_id (p_sph_id);

            pkg_sampleprotocolmass.p_deleteby_sph_id (p_sph_id);
            pkg_sampleheaderfile.p_deleteby_sph_id (p_sph_id);
            pkg_sampleprotocollabo.p_deleteby_sph_id (p_sph_id);

            pkg_sampleheaderitem.p_deleteby_sph_id (p_sph_id);
            pkg_samplemkidetailgroup.p_deleteby_sph_id (p_sph_id);
            pkg_indicehistory.p_deleteby_ihy_sph_id (p_sph_id);
            pkg_sampleheader.p_delete (p_sph_id);
            pkg_sampleheadermassfile.p_delete (l_recsampleheader.sph_smf_id);
            pkg_samplestation.p_deleteifnomoreused (
                p_sph_id,
                l_recsampleheader.sph_sst_id);
            p_delete_children (l_recsampleheader.sph_iph_id);
            pkg_importprotocolheader.p_delete (l_recsampleheader.sph_iph_id); -- Ne peut pas être détruit avant le sampleheader
        ELSE
            DBMS_OUTPUT.put_line (
                'Protocole de masse, suppression partielle');



            pkg_importmassdatadetail.p_deletebyimhid (
                l_recsampleheader.sph_imh_id);
            DBMS_OUTPUT.put_line (
                   'Les donnéee de la table IMPORTMASSHEADER IMH_ID='
                || l_recsampleheader.sph_imh_id
                || ' ont été supprimée');


            pkg_importmassdataheader.p_delete (l_recsampleheader.sph_imh_id);

            l_count :=
                pkg_importmassdataheader.f_getcountims_id (
                    l_recmassdataheader.imh_ims_id);

            IF l_count = 0
            THEN -- On peut supprimer la station car elle n'est référencée qu'une seule fois dans
                pkg_importmassstation.p_delete (
                    l_recmassdataheader.imh_ims_id);
            END IF;

            pkg_sampleheaderadmingroup.p_deleteby_sph_id (p_sph_id);

            pkg_samplemkidetailgroup.p_deleteby_sph_id (p_sph_id);
            pkg_sampledocument.p_deleteby_sph_id (p_sph_id);
            pkg_sampleloadcomment.p_deleteby_sph_id (p_sph_id);
            pkg_sampleprotocolmass.p_deleteby_sph_id (p_sph_id);

            p_delete_grid (l_recsampleheader.sph_id); -- Si il y a des protocoles associées on les détruits
            p_delete_grnd (l_recsampleheader.sph_id);
            pkg_sampleprotocollabo.p_deleteby_sph_id (
                l_recsampleheader.sph_id);
            pkg_sampledocument.p_deleteby_sph_id (l_recsampleheader.sph_id);

            pkg_sampleheaderitem.p_deleteby_sph_id (l_recsampleheader.sph_id);
            pkg_indicehistory.p_deleteby_ihy_sph_id (
                l_recsampleheader.sph_id);
            pkg_sampleheader.p_delete (l_recsampleheader.sph_id);
        END IF;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_purgeby_iph_id (p_iph_id IN importprotocolheader.iph_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
        -- Permet du supprimer la hiérarchie de toutes les données référencées par un IPH_ID
        -- Ces données n'ont jamais été confirmées
        --  1) Pas de SPH_ID lié
        --  2) STATUSVALID='N' OU 'P'
        l_recsampleheader           sampleheader%ROWTYPE;
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecordbyiphid (p_iph_id);

        IF NOT l_recsampleheader.sph_id IS NULL
        THEN
            raise_application_error (
                -20000,
                'Ces données ne peuvent pas être purgées car elles sont définies dans SAMPLEHEADER',
                TRUE);
        END IF;

        DBMS_OUTPUT.put_line ('IPH_ID=' || p_iph_id);

        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);



        pkg_importprotocollog.p_deleteby_iph_id (p_iph_id);  -- Inclu logparam
        pkg_importmassdataheader.p_deletebyiph_id (p_iph_id);
        pkg_importmassstation.p_deletebyiph_id (p_iph_id);

        pkg_importmassdatadetail.p_deletebyiph_id (p_iph_id);
        pkg_importmassmappingheader.p_deletebyiph_id (p_iph_id);
        pkg_importprotocollabo.p_deletebyiphid (p_iph_id);

        pkg_importprotocolgrid.p_deletebyiphid (p_iph_id);
        pkg_importprotocolgrnd.p_deletebyiphid (p_iph_id);

        pkg_importprotocolheader.p_delete (p_iph_id);



        NULL;
    END;

    /*-----------------------------------------------------------------*/
    PROCEDURE p_purgeallinvalide
    /*-----------------------------------------------------------------*/
    IS
        /* Supprime les données non validés */
        CURSOR l_listimportprotocolheader
        IS
            SELECT *
              FROM importprotocolheader
             WHERE     iph_id NOT IN (SELECT sph_iph_id FROM sampleheader)
                   AND iph_validstatus = pkg_constante.cst_validstatusnotok;


        l_reclistimportprotocolheader   l_listimportprotocolheader%ROWTYPE;
    BEGIN
        OPEN l_listimportprotocolheader;

        LOOP
            FETCH l_listimportprotocolheader
                INTO l_reclistimportprotocolheader;

            EXIT WHEN l_listimportprotocolheader%NOTFOUND;
            p_purgeby_iph_id (l_reclistimportprotocolheader.iph_id);
        END LOOP;

        CLOSE l_listimportprotocolheader;

        NULL;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_purgenotconfirmed (
        p_sph_id   IN importprotocolheader.iph_sph_id_parent%TYPE)
    /*----------------------------------------------------------------*/
    IS
        CURSOR l_listimportprotocolheader
        IS
            SELECT *
              FROM importprotocolheader
             WHERE     iph_sph_id_parent = p_sph_id
                   AND iph_sph_id_parent NOT IN
                           (SELECT sph_id FROM sampleheader) -- Protocole labo + mass
                   AND iph_id NOT IN
                           (SELECT shf_iph_id FROM sampleheaderfile); -- Protocol additionelle



        l_reclistimportprotocolheader   l_listimportprotocolheader%ROWTYPE;
    BEGIN
        OPEN l_listimportprotocolheader;

        LOOP
            FETCH l_listimportprotocolheader
                INTO l_reclistimportprotocolheader;

            EXIT WHEN l_listimportprotocolheader%NOTFOUND;
            p_purgeby_iph_id (l_reclistimportprotocolheader.iph_id);
        END LOOP;

        CLOSE l_listimportprotocolheader;

        NULL;
    END;



    /*-----------------------------------------------------------------*/
    PROCEDURE p_purgeallnotconfirmed
    /*-----------------------------------------------------------------*/
    IS
        /* Supprime les données non confirmées */
        CURSOR l_listimportprotocolheader
        IS
            SELECT *
              FROM importprotocolheader
             WHERE     iph_id NOT IN (SELECT sph_iph_id FROM sampleheader) -- Protocole labo + mass
                   AND iph_id NOT IN
                           (SELECT shf_iph_id FROM sampleheaderfile) -- Protocol additionelle
                   AND iph_credate < SYSDATE - (1 / 24)      -- moins 1 heures
                   AND iph_ptv_id IN
                           (SELECT ptv_id
                              FROM protocolversion
                                   INNER JOIN codevalue
                                       ON ptv_cvl_id_protocoltype = cvl_id
                             WHERE cvl_code IN
                                       (pkg_codevalue.cst_protocoltype_mass,
                                        pkg_codevalue.cst_protocoltype_laboratory,
                                        pkg_codevalue.cst_protocoltype_grdeval,
                                        pkg_codevalue.cst_protocoltype_ground));



        l_reclistimportprotocolheader   l_listimportprotocolheader%ROWTYPE;
    BEGIN
        OPEN l_listimportprotocolheader;

        LOOP
            FETCH l_listimportprotocolheader
                INTO l_reclistimportprotocolheader;

            EXIT WHEN l_listimportprotocolheader%NOTFOUND;
            p_purgeby_iph_id (l_reclistimportprotocolheader.iph_id);
        END LOOP;

        CLOSE l_listimportprotocolheader;

        NULL;
    END;
END pkg_delete_protocol;
/

