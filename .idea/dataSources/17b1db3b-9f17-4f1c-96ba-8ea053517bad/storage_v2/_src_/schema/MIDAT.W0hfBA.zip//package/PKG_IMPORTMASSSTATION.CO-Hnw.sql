create PACKAGE       pkg_importmassstation
AS
   /******************************************************************************
      NAME:       pkg_importmassstation
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
         1.0        19.05.2014      burrif       1. Created this package.
         2.0         11.07.2017     burrif       2. Fonctionnalité version 2
   ******************************************************************************/


   /*
   INSERT INTO user_sdo_geom_metadata
        VALUES ('IMPORTMASSSTATION',
                'IMS_COORDINATES',
                mdsys.sdo_dim_array (mdsys.sdo_dim_element ('X',
                                                            480000,
                                                            837000,
                                                            1),
                                     mdsys.sdo_dim_element ('Y',
                                                            75000,
                                                            300000,
                     
                21781);

   CREATE INDEX midat.idx_importmassstation
      ON midat.importmassstation (ims_coordinates)
      INDEXTYPE IS mdsys.spatial_index
         PARAMETERS (' layer_gtype=point,TABLESPACE=MIDAT_INDEX')
   NOPARALLEL;
   */



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_delete (p_ims_id IN importmassstation.ims_id%TYPE);

   FUNCTION f_getrecordbyoid (
      p_ins_id   IN importmassstation.ims_ins_id%TYPE,
      p_oid      IN importmassstation.ims_oid%TYPE)
      RETURN importmassstation%ROWTYPE;

   PROCEDURE p_invalidstationbyoid (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_oid            IN     importmassstation.ims_oid%TYPE,
      p_returnstatus      OUT NUMBER);

   FUNCTION f_getrecmassdataheader (
      p_ims_id   IN importmassstation.ims_id%TYPE)
      RETURN importmassdataheader%ROWTYPE;

   PROCEDURE p_saveprotocolmassstation (
      p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
      p_lan_id                    IN language.lan_id%TYPE,
      p_usr_id                    IN sampleprotocolgrnd.spd_usr_id_create%TYPE);

   PROCEDURE p_deleteconditionnal (
      p_ims_id   IN importmassdataheader.imh_ims_id%TYPE);

   PROCEDURE p_update_ims_sst_id (
      p_ims_id       IN importmassstation.ims_id%TYPE,
      p_ims_sst_id   IN importmassstation.ims_sst_id%TYPE,
      p_usr_id       IN importmassstation.ims_usr_id_modify%TYPE);

   PROCEDURE p_updatevalidstatus (
      p_ims_id        IN importmassstation.ims_id%TYPE,
      p_validstatus   IN importmassstation.ims_validstatus%TYPE);

   PROCEDURE p_updatevalidstatusbyoid (
      p_iph_id        IN importmassdataheader.imh_iph_id%TYPE,
      p_oid           IN importmassstation.ims_oid%TYPE,
      p_validstatus   IN importmassstation.ims_validstatus%TYPE);



   FUNCTION f_getrecord (p_ims_id importmassstation.ims_id%TYPE)
      RETURN importmassstation%ROWTYPE;

   PROCEDURE p_deletebyiph_id (p_iph_id IN importprotocolheader.iph_id%TYPE);

   PROCEDURE p_deletebyimh_id (p_imh_id IN importmassstation.ims_imh_id%TYPE);

   PROCEDURE p_processwhensamecoordinates (
      p_ims_id_1   IN importmassstation.ims_id%TYPE,
      p_ims_id_2   IN importmassstation.ims_id%TYPE,
      p_usr_id     IN importmassstation.ims_usr_id_modify%TYPE);

   PROCEDURE p_write (
      p_lan_id                   IN     language.lan_id%TYPE,
      p_oid                      IN     importmassstation.ims_oid%TYPE,
      p_ins_id                   IN     importmassstation.ims_ins_id%TYPE,
      p_coordinate_x             IN     NUMBER,
      p_coordinate_y             IN     NUMBER,
      p_coordinate_z             IN     NUMBER,
      p_cvl_id_elevationorigin   IN     importmassstation.ims_cvl_id_elevationorigin%TYPE,
      p_elevationprecision       IN     importmassstation.ims_elevationprecision%TYPE,
      p_title                    IN     importmassstation.ims_title%TYPE,
      p_usr_id                   IN     importmassstation.ims_usr_id_create%TYPE,
      p_id                          OUT importmassstation.ims_id%TYPE);

   PROCEDURE p_checkifstationallreadeyexist (
      p_iph_id         IN     importmassdataheader.imh_iph_id%TYPE,
      p_usr_id         IN     importmassstation.ims_usr_id_modify%TYPE,
      p_lan_id         IN     language.lan_id%TYPE,
      p_returnstatus      OUT NUMBER);

   PROCEDURE p_update_ims_cvl_id_canton (
      p_ims_id              IN importmassstation.ims_id%TYPE,
      p_ims_cvl_id_canton   IN importmassstation.ims_cvl_id_canton%TYPE,
      p_usr_id              IN importmassstation.ims_usr_id_modify%TYPE);
END pkg_importmassstation;
/

