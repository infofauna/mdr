create PACKAGE BODY       pkg_samplemkidetailgroup
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEMKIDETAILGROUP
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.02.2015      burrif       1. Created this package.
   ******************************************************************************/

   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, février 2015' ;



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;
   
   /*----------------------------------------------------------------*/
   PROCEDURE p_deleteby_sph_id (
      p_sph_id   IN samplemkidetailgroup.mkd_sph_id%TYPE)
   /*----------------------------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM samplemkidetailgroup
            WHERE mkd_sph_id = p_sph_id;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_deleteby_imh_id (
      p_imh_id   IN samplemkidetailgroup.mkd_imh_id%TYPE)
   /*----------------------------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM samplemkidetailgroup
            WHERE mkd_imh_id = p_imh_id;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_deleteby_iph_id (p_iph_id IN importprotocolheader.iph_id%TYPE)
   /*----------------------------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM samplemkidetailgroup
            WHERE mkd_imh_id IN (SELECT imh_id
                                   FROM importmassdataheader
                                  WHERE imh_iph_id = p_iph_id);
   END;

   /*----------------------------------------------------------------------------------------*/
   PROCEDURE p_write (
      p_imh_id                IN     samplemkidetailgroup.mkd_imh_id%TYPE,
      p_sph_id                IN     samplemkidetailgroup.mkd_sph_id%TYPE,
      p_syv_id_group          IN     samplemkidetailgroup.mkd_syv_id_group%TYPE,
      p_syv_id_inferedfrom    IN     samplemkidetailgroup.mkd_syv_id_inferedfrom%TYPE,
      p_unspeciefiedspecies   IN     samplemkidetailgroup.mkd_unspeciefiedspecies%TYPE,
      p_id                       OUT samplemkidetailgroup.mkd_id%TYPE)
   /*----------------------------------------------------------------------------------------*/
   IS
   BEGIN
      p_id := seq_samplemkidetailgroup.NEXTVAL;

      INSERT INTO samplemkidetailgroup (mkd_id,
                                        mkd_imh_id,
                                        mkd_sph_id,
                                        mkd_syv_id_group,
                                        mkd_syv_id_inferedfrom,
                                        mkd_unspeciefiedspecies)
           VALUES (p_id,
                   p_imh_id,
                   p_sph_id,
                   p_syv_id_group,
                   p_syv_id_inferedfrom,
                   p_unspeciefiedspecies);
   END;

   /*------------------------------------------------------------------------------------*/
   PROCEDURE p_setlink2sampleheader (
      p_imh_id   IN samplemkidetailgroup.mkd_imh_id%TYPE,
      p_sph_id   IN samplemkidetailgroup.mkd_sph_id%TYPE)
   /*-------------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE samplemkidetailgroup
         SET mkd_sph_id = p_sph_id
       WHERE mkd_imh_id = p_imh_id;
   END;

   /*-------------------------------------------------------------------------------------*/
   PROCEDURE p_flushmkidispatchlist (
      p_imh_id         IN samplemkidetailgroup.mkd_imh_id%TYPE,
      p_mkipatchlist   IN pkg_indice_utility.t_mkidispatchlist)
   /*-------------------------------------------------------------------------------------*/
   IS
      l_mkisublist            pkg_indice_utility.t_mkisublist;
      l_syv_id_key_master     PLS_INTEGER;
      l_syv_id_key            PLS_INTEGER;
      l_first_indice          PLS_INTEGER;

      l_syv_id_group          samplemkidetailgroup.mkd_syv_id_group%TYPE;
      l_syv_id_inferedfrom    samplemkidetailgroup.mkd_syv_id_inferedfrom%TYPE;
      l_unspeciefiedspecies   samplemkidetailgroup.mkd_unspeciefiedspecies%TYPE;
      l_mkd_id                samplemkidetailgroup.mkd_id%TYPE;
   BEGIN
      pkg_debug.p_write (
         'pkg_samplemkidetailgroup.p_flushmkidispatchlist',
         'Start p_mkipatchlist.count=' || TO_CHAR (p_mkipatchlist.COUNT));
      l_syv_id_key_master := p_mkipatchlist.FIRST;

      WHILE NOT l_syv_id_key_master IS NULL
      LOOP
         l_syv_id_group := l_syv_id_key_master;
         l_mkisublist := p_mkipatchlist (l_syv_id_key_master);

         l_syv_id_key := l_mkisublist.FIRST;

         WHILE NOT l_syv_id_key IS NULL
         LOOP
            IF l_syv_id_key != ABS (l_syv_id_key)
            THEN
               l_unspeciefiedspecies := pkg_constante.cst_yes;
               l_first_indice :=
                  l_mkisublist (l_syv_id_key).sub_mkistartsyvidsublist.FIRST;
               l_syv_id_inferedfrom :=
                  l_mkisublist (l_syv_id_key).sub_mkistartsyvidsublist (
                     l_first_indice);
            ELSE
               l_unspeciefiedspecies := pkg_constante.cst_no;
               l_syv_id_inferedfrom := l_syv_id_key;
            END IF;

            p_write (p_imh_id,
                     NULL,
                     l_syv_id_group,
                     l_syv_id_inferedfrom,
                     l_unspeciefiedspecies,
                     l_mkd_id);

            l_syv_id_key := l_mkisublist.NEXT (l_syv_id_key);
         END LOOP;

         l_syv_id_key_master := p_mkipatchlist.NEXT (l_syv_id_key_master);
      END LOOP;

      NULL;
   END;
END pkg_samplemkidetailgroup;
/

