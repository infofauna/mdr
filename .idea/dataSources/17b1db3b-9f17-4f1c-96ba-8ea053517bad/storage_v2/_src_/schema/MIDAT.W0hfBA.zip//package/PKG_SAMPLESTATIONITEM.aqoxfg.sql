create PACKAGE       pkg_samplestationitem
AS
   /******************************************************************************
      NAME:       pkg_samplestationitem
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.10.2013   F.Burri          1. Created this package.
      1.1        04.08.2019   F.Burri          2. f_getleastoneitem
   ******************************************************************************/


    cst_packageversion   VARCHAR2 (30) := 'Version 1.1, août 2019';

   FUNCTION f_getversion
      RETURN VARCHAR2;

   FUNCTION f_getleastoneitem (
      p_sst_id              IN samplestationitem.ssi_sst_id%TYPE,
      p_lan_id              IN samplestationitem.ssi_lan_id%TYPE,
      p_smpstaitmtyp_code   IN codevalue.cvl_code%TYPE)
      RETURN samplestationitem.ssi_item%TYPE;

   PROCEDURE p_deletebysstid (p_sst_id IN samplestationitem.ssi_sst_id%TYPE);

   FUNCTION f_getrecordbyitemandcvl_id (
      p_sst_id     IN samplestationitem.ssi_sst_id%TYPE,
      p_ssi_item   IN samplestationitem.ssi_item%TYPE,
      p_lan_id     IN samplestationitem.ssi_lan_id%TYPE,
      p_cvl_id     IN codevalue.cvl_id%TYPE)
      RETURN samplestationitem%ROWTYPE;

   PROCEDURE p_writeifnotexist (
      p_sst_id                IN     samplestationitem.ssi_sst_id%TYPE,
      p_lan_id                IN     samplestationitem.ssi_lan_id%TYPE,
      p_cvl_id_midatstitmty   IN     samplestationitem.ssi_cvl_id_midatstitmty%TYPE,
      p_item                  IN     samplestationitem.ssi_item%TYPE,
      p_usr_id                IN     samplestationitem.ssi_usr_id_create%TYPE,
      p_id                       OUT samplestationitem.ssi_id%TYPE);

   FUNCTION f_getrecord (p_ssi_id IN samplestationitem.ssi_id%TYPE)
      RETURN samplestationitem%ROWTYPE;

   FUNCTION f_getrecordbyitem (
      p_sst_id     IN samplestationitem.ssi_sst_id%TYPE,
      p_ssi_item   IN samplestationitem.ssi_item%TYPE,
      p_cvl_code   IN codevalue.cvl_code%TYPE)
      RETURN samplestationitem%ROWTYPE;

   FUNCTION f_getrecordbyitem (
      p_sst_id     IN samplestationitem.ssi_sst_id%TYPE,
      p_ssi_item   IN samplestationitem.ssi_item%TYPE,
      p_lan_id     IN samplestationitem.ssi_lan_id%TYPE,
      p_cvl_code   IN codevalue.cvl_code%TYPE)
      RETURN samplestationitem%ROWTYPE;

   FUNCTION f_getatleastonerecord (
      p_sst_id              IN samplestationitem.ssi_sst_id%TYPE,
      p_smpstaitmtyp_code   IN codevalue.cvl_code%TYPE)
      RETURN samplestationitem%ROWTYPE;

   FUNCTION f_getatleastonerecord (
      p_sst_id              IN samplestationitem.ssi_sst_id%TYPE,
      p_lan_id              IN samplestationitem.ssi_lan_id%TYPE,
      p_smpstaitmtyp_code   IN codevalue.cvl_code%TYPE)
      RETURN samplestationitem%ROWTYPE;

   FUNCTION f_getrecordwithtypeandlanid (
      p_sst_id              IN samplestationitem.ssi_sst_id%TYPE,
      p_smpstaitmtyp_code   IN codevalue.cvl_code%TYPE,
      p_lan_id              IN samplestationitem.ssi_lan_id%TYPE)
      RETURN samplestationitem%ROWTYPE;

   PROCEDURE p_tr_buf_samplestationitem (
      p_oldrec   IN     samplestationitem%ROWTYPE,
      p_newrec   IN OUT samplestationitem%ROWTYPE);

   PROCEDURE p_write (
      p_sst_id                IN     samplestationitem.ssi_sst_id%TYPE,
      p_lan_id                IN     samplestationitem.ssi_lan_id%TYPE,
      p_cvl_id_midatstitmty   IN     samplestationitem.ssi_cvl_id_midatstitmty%TYPE,
      p_item                  IN     samplestationitem.ssi_item%TYPE,
      p_usr_id                IN     samplestationitem.ssi_usr_id_create%TYPE,
      p_id                       OUT samplestationitem.ssi_id%TYPE);

   PROCEDURE p_tr_bif_samplestationitem (
      p_newrec   IN OUT samplestationitem%ROWTYPE);
END pkg_samplestationitem;
/

