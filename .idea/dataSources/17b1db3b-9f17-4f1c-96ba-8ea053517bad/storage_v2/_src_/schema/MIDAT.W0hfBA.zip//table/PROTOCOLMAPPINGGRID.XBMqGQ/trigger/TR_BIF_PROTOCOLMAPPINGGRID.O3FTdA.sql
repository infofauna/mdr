create trigger TR_BIF_PROTOCOLMAPPINGGRID
    before insert
    on PROTOCOLMAPPINGGRID
    for each row
DECLARE
BEGIN
   IF :new.PMG_id IS NULL
   THEN
      :new.PMG_id := seq_PROTOCOLMAPPINGGRID.NEXTVAL;
   END IF;

   :new.PMG_credate := SYSDATE;
   :new.PMG_creuser := USER;
END tr_bif_PROTOCOLMAPPINGGRID;

/

