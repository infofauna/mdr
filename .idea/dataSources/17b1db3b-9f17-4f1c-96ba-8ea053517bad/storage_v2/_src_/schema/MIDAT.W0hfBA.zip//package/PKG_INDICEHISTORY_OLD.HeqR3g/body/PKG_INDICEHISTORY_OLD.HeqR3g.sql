create PACKAGE BODY       pkg_indicehistory_old
AS
   /******************************************************************************
      NAME:       PKG_INDICEHISTORY
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        06.10.2017      burrif       1. Created this package.
   ******************************************************************************/



   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, octobre 2017';


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_insert_or_update (
      p_sph_id   IN     indicehistory.ihy_sph_id%TYPE,
      p_ivr_id   IN     indicehistory.ihy_ivr_id%TYPE,
      p_value    IN     indicehistory.ihy_value%TYPE,
      p_ihy_id      OUT indicehistory.ihy_id%TYPE)
   /*-----------------------------------------------------------------*/
   IS
      l_recindicehistory   indicehistory%ROWTYPE;
   BEGIN
      l_recindicehistory :=
         pkg_indicehistory.f_getrecordbysph_ivr_id (p_sph_id, p_ivr_id);

      IF NOT l_recindicehistory.ihy_id IS NULL
      THEN
         p_update (p_sph_id, p_ivr_id, p_value);
         p_ihy_id := l_recindicehistory.ihy_id;
      ELSE
         p_write (p_sph_id,
                  p_ivr_id,
                  p_value,
                  p_ihy_id);
      END IF;
   END;

   /*-----------------------------------------------------------------*/
   PROCEDURE p_update (p_sph_id   IN indicehistory.ihy_sph_id%TYPE,
                       p_ivr_id   IN indicehistory.ihy_ivr_id%TYPE,
                       p_value    IN indicehistory.ihy_value%TYPE)
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE indicehistory
         SET ihy_value = p_value
       WHERE ihy_sph_id = p_sph_id AND ihy_ivr_id = p_ivr_id;
   END;

   /*------------------------------------------------------------------*/
   PROCEDURE p_write (p_sph_id   IN     indicehistory.ihy_sph_id%TYPE,
                      p_ivr_id   IN     indicehistory.ihy_ivr_id%TYPE,
                      p_value    IN     indicehistory.ihy_value%TYPE,
                      p_ihy_id      OUT indicehistory.ihy_id%TYPE)
   /*-------------------------------------------------------------------*/
   IS
   BEGIN
      p_ihy_id := seq_indicehistory.NEXTVAL;

      INSERT INTO indicehistory (ihy_sph_id,
                                 ihy_id,
                                 ihy_ivr_id,
                                 ihy_value)
           VALUES (p_sph_id,
                   p_ihy_id,
                   p_ivr_id,
                   p_value);
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_delete (p_ivr_id indicehistory.ihy_ivr_id%TYPE)
   /*--------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM indicehistory
            WHERE ihy_ivr_id = p_ivr_id;
   END;

   /*-------------------------------------------------------------------*/
   PROCEDURE p_deleteby_ihy_sph_id (p_sph_id indicehistory.ihy_sph_id%TYPE)
   /*--------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM indicehistory
            WHERE ihy_sph_id = p_sph_id;
   END;

   /*---------------------------------------------------------------------*/
   FUNCTION f_getrecord (p_ihy_id indicehistory.ihy_id%TYPE)
      RETURN indicehistory%ROWTYPE
   /*----------------------------------------------------------------------*/
   IS
      l_recindicehistory   indicehistory%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recindicehistory
        FROM indicehistory
       WHERE p_ihy_id = ihy_id;

      RETURN l_recindicehistory;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;

   /*---------------------------------------------------------------------*/
   FUNCTION f_getrecordbysph_ivr_id (
      p_sph_id    indicehistory.ihy_sph_id%TYPE,
      p_ivr_id    indicehistory.ihy_ivr_id%TYPE)
      RETURN indicehistory%ROWTYPE
   /*----------------------------------------------------------------------*/
   IS
      l_recindicehistory   indicehistory%ROWTYPE;
   BEGIN
      SELECT *
        INTO l_recindicehistory
        FROM indicehistory
       WHERE p_ivr_id = ihy_ivr_id AND ihy_sph_id = p_sph_id;

      RETURN l_recindicehistory;
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN NULL;
   END;



   /*---------------------------------------------------------------------*/
   PROCEDURE p_buildspearhistory (
      p_version   IN indiceversion.ivr_version%TYPE)
   /*----------------------------------------------------------------------*/
   IS
      CURSOR l_listsampleheader
      IS
         SELECT *
           FROM sampleheader
          WHERE NOT sph_spearindexvalue IS NULL;

      --   AND sph_status = pkg_constante.cst_status_actif;

      l_reclistsampleheader   l_listsampleheader%ROWTYPE;



      l_ihy_id                indicehistory.ihy_id%TYPE;
      l_recindiceversion      indiceversion%ROWTYPE;
   BEGIN
      l_recindiceversion :=
         pkg_indiceversion.f_getrecordbyversion (
            p_version,
            pkg_codevalue.cst_midatindice_spear);

      IF l_recindiceversion.ivr_id IS NULL
      THEN
         raise_application_error (
            -20000,
            'Version SPEAR ' || p_version || ' non trouvée',
            TRUE);
      END IF;

      OPEN l_listsampleheader;

      LOOP
         FETCH l_listsampleheader INTO l_reclistsampleheader;

         EXIT WHEN l_listsampleheader%NOTFOUND;
         p_insert_or_update (l_reclistsampleheader.sph_id,
                             l_recindiceversion.ivr_id,
                             l_reclistsampleheader.sph_spearindexvalue,
                             l_ihy_id);
      END LOOP;

      CLOSE l_listsampleheader;
   END;

   /*---------------------------------------------------------------------*/
   PROCEDURE p_buildibchhistory (p_version IN indiceversion.ivr_version%TYPE)
   /*----------------------------------------------------------------------*/
   IS
      CURSOR l_listsampleheader
      IS
         SELECT *
           FROM sampleheader
          WHERE NOT sph_indexvalueibch IS NULL;

      --   AND sph_status = pkg_constante.cst_status_actif;

      l_reclistsampleheader   l_listsampleheader%ROWTYPE;



      l_ihy_id                indicehistory.ihy_id%TYPE;
      l_recindiceversion      indiceversion%ROWTYPE;
   BEGIN
      l_recindiceversion :=
         pkg_indiceversion.f_getrecordbyversion (
            p_version,
            pkg_codevalue.cst_midatindice_ibch);

      IF l_recindiceversion.ivr_id IS NULL
      THEN
         raise_application_error (
            -20000,
            'Version IBCH' || p_version || ' non trouvée',
            TRUE);
      END IF;

      OPEN l_listsampleheader;

      LOOP
         FETCH l_listsampleheader INTO l_reclistsampleheader;

         EXIT WHEN l_listsampleheader%NOTFOUND;
         p_insert_or_update (l_reclistsampleheader.sph_id,
                             l_recindiceversion.ivr_id,
                             l_reclistsampleheader.sph_indexvalueibch,
                             l_ihy_id);
      END LOOP;

      CLOSE l_listsampleheader;
   END;

   /*---------------------------------------------------------------------*/
   PROCEDURE p_buildmakroindexhistory (
      p_version   IN indiceversion.ivr_version%TYPE)
   /*----------------------------------------------------------------------*/
   IS
      CURSOR l_listsampleheader
      IS
         SELECT *
           FROM sampleheader
          WHERE NOT sph_makroindexvalue IS NULL;

      --   AND sph_status = pkg_constante.cst_status_actif;

      l_reclistsampleheader   l_listsampleheader%ROWTYPE;



      l_ihy_id                indicehistory.ihy_id%TYPE;
      l_recindiceversion      indiceversion%ROWTYPE;
   BEGIN
      l_recindiceversion :=
         pkg_indiceversion.f_getrecordbyversion (
            p_version,
            pkg_codevalue.cst_midatindice_ibch);

      IF l_recindiceversion.ivr_id IS NULL
      THEN
         raise_application_error (
            -20000,
            'Version SPEAR' || p_version || ' non trouvée',
            TRUE);
      END IF;

      OPEN l_listsampleheader;

      LOOP
         FETCH l_listsampleheader INTO l_reclistsampleheader;

         EXIT WHEN l_listsampleheader%NOTFOUND;

         p_insert_or_update (l_reclistsampleheader.sph_id,
                             l_recindiceversion.ivr_id,
                             l_reclistsampleheader.sph_makroindexvalue,
                             l_ihy_id);
      END LOOP;

      CLOSE l_listsampleheader;
   END;

   /*-------------------------------------------------------------------*/
   FUNCTION f_countbyivr_id (p_ivr_id IN indicehistory.ihy_ivr_id%TYPE)
      RETURN NUMBER
   /*-------------------------------------------------------------------*/
   IS
      l_count   NUMBER;
   BEGIN
      SELECT COUNT (*)
        INTO l_count
        FROM indicehistory
       WHERE ihy_ivr_id = p_ivr_id;

      RETURN l_count;
   END;



   /*---------------------------------------------------------------------*/
   PROCEDURE p_buildhistory (p_midatindice IN codevalue.cvl_code%TYPE)
   /*----------------------------------------------------------------------*/
   IS
      l_recindiceversion   indiceversion%ROWTYPE;

      l_reccodevalue       codevalue%ROWTYPE;
      l_count              NUMBER;
   BEGIN
      l_recindiceversion :=
         pkg_indiceversion.f_getcurrentversion (p_midatindice);

      IF l_recindiceversion.ivr_id IS NULL
      THEN
         raise_application_error (
            -20000,
               'La valeur p_midatindice='
            || p_midatindice
            || ' ne permet pas de trouver la version',
            TRUE);
      END IF;

    


      l_reccodevalue :=
         pkg_codevalue.f_getrecord (
            l_recindiceversion.ivr_cvl_id_midatindice);

      CASE l_reccodevalue.cvl_code
         WHEN pkg_codevalue.cst_midatindice_spear
         THEN
            p_buildspearhistory (l_recindiceversion.ivr_version);
         WHEN pkg_codevalue.cst_midatindice_ibch
         THEN
            p_buildibchhistory (l_recindiceversion.ivr_version);
         WHEN pkg_codevalue.cst_midatindice_makroindex
         THEN
            p_buildmakroindexhistory (l_recindiceversion.ivr_version);
         ELSE
            NULL;
      END CASE;
   END;
END pkg_indicehistory_old;
/

