create trigger TR_BIF_PROTOCOLMAPPINGHEADER
    before insert
    on PROTOCOLMAPPINGHEADER
    for each row
DECLARE
BEGIN
   IF :new.PMH_id IS NULL
   THEN
      :new.PMH_id := seq_PROTOCOLMAPPINGHEADER.NEXTVAL;
   END IF;

   :new.PMH_credate := SYSDATE;
   :new.PMH_creuser := USER;
END tr_bif_PROTOCOLMAPPINGHEADER;

/

