create PACKAGE       pkg_migr_mkiidentifygroupcount
AS
   /******************************************************************************
      NAME:       PKG_MIGR_MKIIDENTIFYGROUPCOUNT
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        23.02.2015      burrif       1. Created this package.
   ******************************************************************************/




   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_load;
END pkg_migr_mkiidentifygroupcount;
/

