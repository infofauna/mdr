create PACKAGE BODY       pkg_spear
AS
    /******************************************************************************
       NAME:       PKG_SPEAR
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0        08.07.2015      burrif       1. Created this package.
       1.1        02.10.2017      burrif       2. Version 2
    ******************************************************************************/


    cst_packageversion   CONSTANT VARCHAR2 (30)
                                      := 'Version 1.1, septembre  2017' ;
    gbl_listspearvalue            t_listspearvalue := t_listspearvalue ();
    gbl_identifiedtaxoncount      NUMBER := 0;

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*------------------------------------------------------------------*/
    PROCEDURE p_spearinit
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        gbl_listspearvalue.delete;
        gbl_identifiedtaxoncount := 0;
    END;

    /*-------------------------------------------------------------------*/
    FUNCTION f_getgblidentifiedtaxoncount
        RETURN NUMBER
    /*-------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_identifiedtaxoncount;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_spearreturnlistvalue
        RETURN t_listspearvalue
    /*------------------------------------------------------------------*/
    IS
    BEGIN
        RETURN gbl_listspearvalue;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_spearadddata (
        p_syv_id    IN     speardatalinkcscf.sdf_syv_id%TYPE,
        p_counter   IN     NUMBER,
        p_ptv_id    IN     protocolversion.ptv_id%TYPE,
        p_status       OUT NUMBER)
    /*-----------------------------------------------------------------*/
    IS
        l_spearindexfactor         speardatalinkcscf.sdf_spearindex%TYPE;
        l_recprotocolmappinglabo   protocolmappinglabo%ROWTYPE;
    BEGIN
        l_recprotocolmappinglabo :=
            pkg_protocolmappinglabo.f_getrecordfromsyv_id (p_syv_id,
                                                           p_ptv_id);


        IF l_recprotocolmappinglabo.ptl_id IS NULL
        THEN
            p_status := pkg_constante.cst_returnstatusnotok;
        ELSE
            p_status := pkg_constante.cst_returnstatusok;

            IF NVL (l_recprotocolmappinglabo.ptl_spearindexfactor, -999) !=
               -999
            THEN
                gbl_listspearvalue.EXTEND (1);
                gbl_listspearvalue (gbl_listspearvalue.LAST).spr_syv_id :=
                    p_syv_id;
                gbl_listspearvalue (gbl_listspearvalue.LAST).spr_spearindexfactor :=
                    l_recprotocolmappinglabo.ptl_spearindexfactor;
                gbl_listspearvalue (gbl_listspearvalue.LAST).spr_counter :=
                    p_counter;
            END IF;
        END IF;
    END;

    PROCEDURE p_loaddatafrommass (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN importmassdataheader%ROWTYPE)
    /*-----------------------------------------------------------------*/
    IS
        CURSOR l_massdatadetail (
            p_imh_id   IN importmassdatadetail.imd_imh_id%TYPE)
        IS
            SELECT *
              FROM importmassdatadetail
             WHERE     imd_imh_id = p_imh_id
                   AND imd_validstatus = pkg_constante.cst_validstatusok; -- A ce stade, tout doit être contrôler et le status doit être valide

        l_recmassdatadetail            l_massdatadetail%ROWTYPE;
        l_status                       NUMBER;

        l_recimportmassmappingheader   importmassmappingheader%ROWTYPE;
        l_recprotocolmappinglabo       protocolmappinglabo%ROWTYPE;
        l_recprotocolversion           protocolversion%ROWTYPE;
    BEGIN
        p_spearinit;
        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                p_recimportprotocolheader.iph_ptv_id);
        l_recimportmassmappingheader :=
            pkg_importmassmappingheader.f_getrecordbymidatfldcnt (
                p_recimportprotocolheader.iph_id,
                pkg_codevalue.cst_midatfldcmt_taxonibch);
        pkg_debug.p_write ('p_loaddatafrommass', 'Load MASS DATA');

        IF NOT l_recimportmassmappingheader.ime_id IS NULL
        THEN
            -- La colonne IBCH a été définie dans le protocole de masse


            OPEN l_massdatadetail (p_recmassdataheader.imh_id);

            LOOP
                FETCH l_massdatadetail INTO l_recmassdatadetail;


                EXIT WHEN l_massdatadetail%NOTFOUND;
                DBMS_OUTPUT.put_line (
                       'l_recmassdatadetail.imd_syv_id='
                    || l_recmassdatadetail.imd_syv_id
                    || ' l_recmassdatadetail.imd_freq1='
                    || l_recmassdatadetail.imd_freq1);

                p_spearadddata (l_recmassdatadetail.imd_syv_id,
                                l_recmassdatadetail.imd_freq1,
                                l_recprotocolversion.ptv_ptv_id_labofrommass,
                                l_status);

                IF l_status = pkg_constante.cst_returnstatusok
                THEN
                    gbl_identifiedtaxoncount := gbl_identifiedtaxoncount + 1;
                END IF;
            END LOOP;

            CLOSE l_massdatadetail;

            DBMS_OUTPUT.put_line (
                   'p_loaddatafrommass: gbl_listspearvalue.count='
                || gbl_listspearvalue.COUNT);
        ELSE                            -- La colonne IBCH n'a pas été définie
            -- Pour charger les données nécessaire au calcul de l'IBCH on doit relire le détail

            OPEN l_massdatadetail (p_recmassdataheader.imh_id);

            LOOP
                FETCH l_massdatadetail INTO l_recmassdatadetail;


                EXIT WHEN l_massdatadetail%NOTFOUND;
                p_spearadddata (l_recmassdatadetail.imd_syv_id,
                                l_recmassdatadetail.imd_freq1,
                                l_recprotocolversion.ptv_ptv_id_labofrommass,
                                l_status);

                IF l_status = pkg_constante.cst_returnstatusok
                THEN
                    gbl_identifiedtaxoncount := gbl_identifiedtaxoncount + 1;
                END IF;
            END LOOP;

            CLOSE l_massdatadetail;
        END IF;

        pkg_debug.p_write (
            'p_loaddatafrommass',
               'Nombre de données identifiées:='
            || TO_CHAR (gbl_identifiedtaxoncount));
    END;

    /*------------------------------------------------------------*/
    PROCEDURE p_loaddatafromlabo (
        p_recimportprotocolheader   IN importprotocolheader%ROWTYPE)
    /*-------------------------------------------------------------*/
    /*
     Référence: Calcul de l'IBCH: http://www.sib.admin.ch/uploads/media/UV-1026-F_01.pdf
  */
    IS
        CURSOR l_curimportprotocollabo IS
            SELECT *
              FROM importprotocollabo
             WHERE     ipl_iph_id = p_recimportprotocolheader.iph_id
                   AND NVL (ipl_value, 0) > 0;

        l_reccurimportprotocollabo   l_curimportprotocollabo%ROWTYPE;
        l_recprotocolmappinglabo     protocolmappinglabo%ROWTYPE;
        l_status                     NUMBER;
    BEGIN
        p_spearinit;

        OPEN l_curimportprotocollabo;

        LOOP
            FETCH l_curimportprotocollabo INTO l_reccurimportprotocollabo;

            EXIT WHEN l_curimportprotocollabo%NOTFOUND;
            l_recprotocolmappinglabo :=
                pkg_protocolmappinglabo.f_getrecord (
                    l_reccurimportprotocollabo.ipl_ptl_id);
            DBMS_OUTPUT.put_line (
                'Add: ' || l_reccurimportprotocollabo.ipl_value);
            p_spearadddata (l_recprotocolmappinglabo.ptl_syv_id,
                            l_reccurimportprotocollabo.ipl_value,
                            l_recprotocolmappinglabo.ptl_ptv_id,
                            l_status);
        END LOOP;

        CLOSE l_curimportprotocollabo;
    END;


    /*----------------------------------------------------------*/
    FUNCTION f_computespearfrommemory (p_abondanceflag IN VARCHAR2)
        RETURN NUMBER
    /*-----------------------------------------------------------*/
    IS
        l_indicespear    PLS_INTEGER;
        l_abondance      NUMBER;
        l_numerateur     NUMBER;
        l_denominateur   NUMBER;
        l_spearvalue     NUMBER;
    BEGIN
        l_numerateur := 0;
        l_denominateur := 0;
        l_indicespear := gbl_listspearvalue.FIRST;
        DBMS_OUTPUT.put_line (
            'gbl_listspearvalue.count=' || gbl_listspearvalue.COUNT);

        WHILE NOT l_indicespear IS NULL
        LOOP
            l_abondance :=
                pkg_ibch.f_normaliseabondance (
                    gbl_listspearvalue (l_indicespear).spr_counter,
                    p_abondanceflag);
            l_numerateur :=
                  l_numerateur
                +   LOG (10, l_abondance + 1)
                  * gbl_listspearvalue (l_indicespear).spr_spearindexfactor;
            l_denominateur := l_denominateur + LOG (10, l_abondance + 1);
            l_indicespear := gbl_listspearvalue.NEXT (l_indicespear);
            DBMS_OUTPUT.put_line ('l_numerateur=' || l_numerateur);
        END LOOP;

        DBMS_OUTPUT.put_line ('l_numerateur=' || l_numerateur);
        DBMS_OUTPUT.put_line ('l_denominateur=' || l_denominateur);

        IF l_denominateur = 0
        THEN
            RETURN NULL;
        END IF;

        l_spearvalue := l_numerateur / l_denominateur * 100;
        RETURN ROUND (l_spearvalue, 1);
    END;

    /*-------------------------------------------------------------------------------------*/
    PROCEDURE p_recompute (p_sampleheader   IN     sampleheader%ROWTYPE,
                           p_spearindice       OUT NUMBER)
    /*-------------------------------------------------------------------------------------*/
    IS
    BEGIN
        NULL;
    END;


    /*--------------------------------------------------------------------------------------*/
    PROCEDURE p_maincompute (
        p_recimportprotocolheader   IN     importprotocolheader%ROWTYPE,
        p_recmassdataheader         IN     importmassdataheader%ROWTYPE, -- NULL si le type de protocol n'est pas MASS
        p_spearindice                  OUT NUMBER)
    /*--------------------------------------------------------------------------------------*/
    IS
        l_ptv_id               protocolversion.ptv_id%TYPE;
        l_recprotocolversion   protocolversion%ROWTYPE;
        l_reccodevalue         codevalue%ROWTYPE;
        l_abondanceflag        codevalue.cvl_code%TYPE;
    BEGIN
        pkg_debug.p_write ('PKG_SPEAR.p_MAINCOMPUTE',
                           'Start compute SPEAR index...');


        IF NOT p_recmassdataheader.imh_id IS NULL
        THEN
            DBMS_OUTPUT.put_line ('Mass');
            l_abondanceflag := pkg_ibch.cst_abondanceflag_absolu;


            p_loaddatafrommass (p_recimportprotocolheader,
                                p_recmassdataheader);
        ELSE                                      -- Pas un protocole de masse
            IF NOT p_recimportprotocolheader.iph_absolutenumberflag IS NULL
            THEN
                l_abondanceflag := pkg_ibch.cst_abondanceflag_absolu;
            ELSE
                l_abondanceflag := pkg_ibch.cst_abondanceflag_class;
            END IF;

            DBMS_OUTPUT.put_line ('labo');
            p_loaddatafromlabo (p_recimportprotocolheader);
        END IF;

        p_spearindice := f_computespearfrommemory (l_abondanceflag);
    END;
END;
/

