create PACKAGE       pkg_sampleprotocolgrid
AS
   /******************************************************************************
      NAME:       pkg_pkg_sampleprotocolgrid
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.10.2013   F.Burri          1. Created this package.
   ******************************************************************************/

   cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2013';

   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_deleteby_sph_id (
      p_sph_id IN sampleprotocolgrid.spg_sph_id%TYPE);

   PROCEDURE p_write (p_sph_id   IN     sampleprotocolgrid.spg_sph_id%TYPE,
                      p_pmg_id   IN     sampleprotocolgrid.spg_pmg_id%TYPE,
                      p_value    IN     sampleprotocolgrid.spg_value%TYPE,
                      p_usr_id   IN     sampleprotocolgrid.spg_usr_id_create%TYPE,
                      p_spg_id      OUT sampleprotocolgrid.spg_id%TYPE);

   PROCEDURE p_tr_buf_sampleprotocolgrid (
      p_oldrec   IN     sampleprotocolgrid%ROWTYPE,
      p_newrec   IN OUT sampleprotocolgrid%ROWTYPE);

   PROCEDURE p_tr_bif_sampleprotocolgrid (
      p_newrec IN OUT sampleprotocolgrid%ROWTYPE);
END pkg_sampleprotocolgrid;
/

