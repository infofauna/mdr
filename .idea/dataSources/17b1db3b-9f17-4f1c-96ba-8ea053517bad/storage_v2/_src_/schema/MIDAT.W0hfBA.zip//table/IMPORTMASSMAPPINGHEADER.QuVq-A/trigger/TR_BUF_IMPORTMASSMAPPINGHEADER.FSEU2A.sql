create trigger TR_BUF_IMPORTMASSMAPPINGHEADER
    before update
    on IMPORTMASSMAPPINGHEADER
    for each row
DECLARE
BEGIN
 
   :new.IME_moddate := SYSDATE;
   :new.IME_moduser := USER;
END TR_BUF_IMPORTMASSMAPPINGHEADER;

/

