create PACKAGE BODY       pkg_sampleheader
AS
    /******************************************************************************
       NAME:       PKG_SAMPLEHEADER
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       25.07.2013  F.Burri           1. Created this package body.
       1.1       20.07.2017  F.Burri           2 Ajout de la gestion des projets
       1.2        17.01.2020   F.Burri          3 Mise à jour des champs statistique IBCH
    ******************************************************************************/



    gbl_debugflag        BOOLEAN;
    cst_packageversion   VARCHAR2 (30) := 'Version 1.2, janvier 2020';

    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;

    /*-------------------------------------------------------------*/
    PROCEDURE p_updateibch_statdata (
        p_sph_id              IN sampleheader.sph_id%TYPE,
        p_sum_taxon           IN sampleheader.sph_ibch_sum_taxon%TYPE,
        p_sum_ephemeroptera   IN sampleheader.sph_ibch_sum_ephemeroptera%TYPE,
        p_sum_plecoptera      IN sampleheader.sph_ibch_sum_plecoptera%TYPE,
        p_sum_tricoptera      IN sampleheader.sph_ibch_sum_tricoptera%TYPE,
        p_indicator_group     IN sampleheader.sph_ibch_indicator_group%TYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE sampleheader
           SET sph_ibch_sum_taxon = p_sum_taxon,
               sph_ibch_sum_ephemeroptera = p_sum_ephemeroptera,
               sph_ibch_sum_plecoptera = p_sum_plecoptera,
               sph_ibch_sum_tricoptera = p_sum_tricoptera,
               sph_ibch_indicator_group = p_indicator_group
         WHERE sph_id = p_sph_id;

        NULL;
    END;

    /*------------------------------------------------------------------------*/
    PROCEDURE p_saveibch_statdata (p_sph_id IN sampleheader.sph_id%TYPE)
    /*-------------------------------------------------------------------------*/
    IS
        l_sum_taxon           sampleheader.sph_ibch_sum_taxon%TYPE;
        l_sum_ephemeroptera   sampleheader.sph_ibch_sum_ephemeroptera%TYPE;
        l_sum_plecoptera      sampleheader.sph_ibch_sum_plecoptera%TYPE;
        l_sum_tricoptera      sampleheader.sph_ibch_sum_tricoptera%TYPE;
        l_indicator_group     sampleheader.sph_ibch_indicator_group%TYPE;
    BEGIN
        l_sum_taxon := pkg_ibchutil.f_getibchsomme_vt (p_sph_id);
        l_indicator_group := pkg_ibchutil.f_gettaxonindicateur (p_sph_id);


        l_sum_ephemeroptera :=
            pkg_ibchutil.f_getsumbytaxonibch (p_sph_id, 'EPHEMEROPTERA');

        l_sum_plecoptera :=
            pkg_ibchutil.f_getsumbytaxonibch (p_sph_id, 'PLECOPTERA');

        l_sum_tricoptera :=
            pkg_ibchutil.f_getsumbytaxonibch (p_sph_id, 'TRICHOPTERA');

        pkg_sampleheader.p_updateibch_statdata (p_sph_id,
                                                l_sum_taxon,
                                                l_sum_ephemeroptera,
                                                l_sum_plecoptera,
                                                l_sum_tricoptera,
                                                l_indicator_group);
    END;


    /*-------------------------------------------------------------------------------------*/
    PROCEDURE p_delete (p_sph_id IN sampleheader.sph_id%TYPE)
    /*-------------------------------------------------------------------------------------*/
    IS
    BEGIN
        DELETE FROM sampleheader
              WHERE sph_id = p_sph_id;
    END;

    /*------------------------------------------------------------------------------------*/
    FUNCTION f_returnsampleheaderbyiphid (
        p_iph_id   IN importprotocolheader.iph_id%TYPE)
        RETURN sampleheader%ROWTYPE
    /*-------------------------------------------------------------------------------------*/

    IS
        l_recimportprotocolheader   importprotocolheader%ROWTYPE;

        l_recsampleheader           sampleheader%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);

        IF l_recimportprotocolheader.iph_id IS NULL
        THEN
            RETURN NULL;
        END IF;

        IF NOT l_recimportprotocolheader.iph_sph_id_parent IS NULL
        THEN
            l_recsampleheader :=
                pkg_sampleheader.f_getrecord (
                    l_recimportprotocolheader.iph_sph_id_parent);

            IF l_recsampleheader.sph_id IS NULL
            THEN
                RETURN NULL;
            ELSE
                RETURN l_recsampleheader;
            END IF;
        ELSE
            -- Pas de iph_shp_parent, c'est un protocole de laboratoire
            RETURN NULL;
        END IF;
    END;

    /*------------------------------------------------------------------------------------*/
    FUNCTION f_checkprotocoleallreadyexist (
        p_iph_id   IN importprotocolheader.iph_id%TYPE)
        RETURN protocolversion.ptv_cvl_id_protocoltype%TYPE
    /*-------------------------------------------------------------------------------------*/

    IS
        /* Permet de déterminer si un protocole exsite déjà */

        l_recimportprotocolheader   importprotocolheader%ROWTYPE;
        l_recsampleheader           sampleheader%ROWTYPE;
        l_recsampleheaderfile       sampleheaderfile%ROWTYPE;
        l_recprotocolversion        protocolversion%ROWTYPE;
    BEGIN
        l_recimportprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);

        IF l_recimportprotocolheader.iph_id IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_recsampleheader := f_returnsampleheaderbyiphid (p_iph_id);

        IF l_recsampleheader.sph_id IS NULL
        THEN
            RETURN pkg_constante.cst_returnstatusnotok;
        END IF;

        l_recprotocolversion :=
            pkg_protocolversion.f_getrecord (
                l_recimportprotocolheader.iph_ptv_id);

        IF l_recprotocolversion.ptv_id IS NULL
        THEN
            RETURN NULL;
        END IF;

        l_recsampleheaderfile :=
            pkg_sampleheaderfile.f_getbysphidandprotocoltypeid (
                l_recsampleheader.sph_id,
                l_recprotocolversion.ptv_cvl_id_protocoltype);



        IF l_recsampleheaderfile.shf_id IS NULL
        THEN
            RETURN NULL;
        ELSE
            RETURN l_recprotocolversion.ptv_cvl_id_protocoltype;
        END IF;



        NULL;
    END;

    /*----------------------------------------------------------------------------------*/
    PROCEDURE p_write (
        p_sst_id                    IN     sampleheader.sph_sst_id%TYPE,
        p_iph_id                    IN     sampleheader.sph_iph_id%TYPE,
        p_imh_id                    IN     sampleheader.sph_imh_id%TYPE,
        p_smf_id                    IN     sampleheader.sph_smf_id%TYPE,
        p_ins_id_principal          IN     sampleheader.sph_ins_id_principal%TYPE,
        p_ins_id_mandatary          IN     sampleheader.sph_ins_id_mandatary%TYPE,
        p_cvl_id_sysprecisionref    IN     sampleheader.sph_cvl_id_sysprecisionref%TYPE,
        p_cvl_id_sysprecision       IN     sampleheader.sph_cvl_id_sysprecision%TYPE,
        p_ptv_id                    IN     sampleheader.sph_ptv_id%TYPE,
        p_cvl_id_windowibch         IN     sampleheader.sph_cvl_id_windowibch%TYPE,
        p_cvl_id_windowmakroindex   IN     sampleheader.sph_cvl_id_windowmakroindex%TYPE,
        p_cvl_id_windowspear        IN     sampleheader.sph_cvl_id_windowspear%TYPE,
        p_project                   IN     sampleheader.sph_project%TYPE,
        p_determinateddate          IN     sampleheader.sph_determinateddate%TYPE,
        p_cvl_id_midatstat          IN     sampleheader.sph_cvl_id_midatstat%TYPE, -- IMH_INDICETYPE doit être traduit en cvl_id_midatstat (pour l'instant on le défini dans le détail)
        p_absolutenumberflag        IN     sampleheader.sph_absolutenumberflag%TYPE,
        p_observationdate           IN     sampleheader.sph_observationdate%TYPE,
        p_observationday            IN     sampleheader.sph_observationday%TYPE,
        p_observationmonth          IN     sampleheader.sph_observationmonth%TYPE,
        p_observationyear           IN     sampleheader.sph_observationyear%TYPE,
        p_period                    IN     sampleheader.sph_period%TYPE,
        p_indexvalueibch            IN     sampleheader.sph_indexvalueibch%TYPE,
        p_indexvalueibch_orig       IN     sampleheader.sph_indexvalueibch_orig%TYPE,
        p_makroindexvalue           IN     sampleheader.sph_makroindexvalue%TYPE,
        p_makroindexvalue_orig             sampleheader.sph_makroindexvalue_orig%TYPE,
        p_spearindexvalue           IN     sampleheader.sph_spearindexvalue%TYPE,
        p_spearindexvalue_orig             sampleheader.sph_spearindexvalue_orig%TYPE,
        p_usr_id                    IN     sampleheader.sph_usr_id_create%TYPE,
        p_visibilitystatus          IN     sampleheader.sph_visibilitystatus%TYPE,
        p_prj_id                    IN     sampleheader.sph_prj_id%TYPE,
        p_ivr_id_spear              IN     sampleheader.sph_ivr_id_spear%TYPE,
        p_ivr_id_ibch               IN     sampleheader.sph_ivr_id_ibch%TYPE,
        p_ivr_id_makroindex         IN     sampleheader.sph_ivr_id_makroindex%TYPE,
        p_id                           OUT sampleheader.sph_id%TYPE)
    /*---------------------------------------------------------------------------------*/
    IS
        l_observationday       sampleheader.sph_observationday%TYPE;
        l_observationmonth     sampleheader.sph_observationmonth%TYPE;
        l_observationyear      sampleheader.sph_observationyear%TYPE;
        l_absolutenumberflag   sampleheader.sph_absolutenumberflag%TYPE;
    BEGIN
        p_id := seq_sampleheader.NEXTVAL;
        pkg_debug.p_write ('PKG_SAMPLEHEADER.p_write',
                           'Absolute number flag=' || p_absolutenumberflag);
        l_absolutenumberflag := pkg_constante.cst_no;

        IF p_absolutenumberflag IS NULL
        THEN
            l_absolutenumberflag := pkg_constante.cst_no;
        ELSIF UPPER (p_absolutenumberflag) =
              UPPER (pkg_constante.cst_casesetted)
        THEN
            l_absolutenumberflag := pkg_constante.cst_yes;
        END IF;

        IF NOT p_observationdate IS NULL
        THEN
            l_observationday := TO_NUMBER (TO_CHAR (p_observationdate, 'DD'));
            l_observationmonth :=
                TO_NUMBER (TO_CHAR (p_observationdate, 'MM'));
            l_observationyear :=
                TO_NUMBER (TO_CHAR (p_observationdate, 'YYYY'));
        ELSE
            l_observationday := p_observationday;
            l_observationmonth := p_observationmonth;
            l_observationyear := p_observationyear;
        END IF;

        DBMS_OUTPUT.put_line (
               'Sampleheader: '
            || p_observationdate
            || ' day='
            || l_observationday
            || ' month='
            || l_observationmonth
            || ' year='
            || l_observationyear);

        INSERT INTO sampleheader (sph_id,
                                  sph_sst_id,
                                  sph_iph_id,
                                  sph_imh_id,
                                  sph_smf_id,
                                  sph_ins_id_principal,
                                  sph_ins_id_mandatary,
                                  sph_cvl_id_sysprecisionref,
                                  sph_cvl_id_sysprecision,
                                  sph_ptv_id,
                                  sph_cvl_id_windowibch,
                                  sph_cvl_id_windowmakroindex,
                                  sph_cvl_id_windowspear,
                                  sph_project,
                                  sph_determinateddate,
                                  sph_cvl_id_midatstat,
                                  sph_absolutenumberflag,
                                  sph_observationdate,
                                  sph_observationday,
                                  sph_observationmonth,
                                  sph_observationyear,
                                  sph_period,
                                  sph_indexvalueibch,
                                  sph_indexvalueibch_orig,
                                  sph_makroindexvalue,
                                  sph_spearindexvalue,
                                  sph_makroindexvalue_orig,
                                  sph_spearindexvalue_orig,
                                  sph_visibilitystatus,
                                  sph_prj_id,
                                  sph_ivr_id_spear,
                                  sph_ivr_id_ibch,
                                  sph_ivr_id_makroindex,
                                  sph_usr_id_create,
                                  sph_usr_create_date)
             VALUES (p_id,
                     p_sst_id,
                     p_iph_id,
                     p_imh_id,
                     p_smf_id,
                     p_ins_id_principal,
                     p_ins_id_mandatary,
                     p_cvl_id_sysprecisionref,
                     p_cvl_id_sysprecision,
                     p_ptv_id,
                     p_cvl_id_windowibch,
                     p_cvl_id_windowmakroindex,
                     p_cvl_id_windowspear,
                     p_project,
                     p_determinateddate,
                     p_cvl_id_midatstat,
                     l_absolutenumberflag,
                     p_observationdate,
                     l_observationday,
                     l_observationmonth,
                     l_observationyear,
                     p_period,
                     p_indexvalueibch,
                     p_indexvalueibch_orig,
                     p_makroindexvalue,
                     p_spearindexvalue,
                     p_makroindexvalue_orig,
                     p_spearindexvalue_orig,
                     p_visibilitystatus,
                     p_prj_id,
                     p_ivr_id_spear,
                     p_ivr_id_ibch,
                     p_ivr_id_makroindex,
                     p_usr_id,
                     SYSDATE);

        NULL;
    END;

    /*----------------------------------------------------------------------------------*/
    PROCEDURE p_write (
        p_sst_id                    IN     sampleheader.sph_sst_id%TYPE,
        p_iph_id                    IN     sampleheader.sph_iph_id%TYPE,
        p_imh_id                    IN     sampleheader.sph_imh_id%TYPE,
        p_smf_id                    IN     sampleheader.sph_smf_id%TYPE,
        p_ins_id_principal          IN     sampleheader.sph_ins_id_principal%TYPE,
        p_ins_id_mandatary          IN     sampleheader.sph_ins_id_mandatary%TYPE,
        p_cvl_id_sysprecisionref    IN     sampleheader.sph_cvl_id_sysprecisionref%TYPE,
        p_cvl_id_sysprecision       IN     sampleheader.sph_cvl_id_sysprecision%TYPE,
        p_ptv_id                    IN     sampleheader.sph_ptv_id%TYPE,
        p_cvl_id_windowibch         IN     sampleheader.sph_cvl_id_windowibch%TYPE,
        p_cvl_id_windowmakroindex   IN     sampleheader.sph_cvl_id_windowmakroindex%TYPE,
        p_cvl_id_windowspear        IN     sampleheader.sph_cvl_id_windowspear%TYPE,
        p_project                   IN     sampleheader.sph_project%TYPE,
        p_determinateddate          IN     sampleheader.sph_determinateddate%TYPE,
        p_cvl_id_midatstat          IN     sampleheader.sph_cvl_id_midatstat%TYPE, -- IMH_INDICETYPE doit être traduit en cvl_id_midatstat (pour l'instant on le défini dans le détail)
        p_absolutenumberflag        IN     sampleheader.sph_absolutenumberflag%TYPE,
        p_observationdate           IN     sampleheader.sph_observationdate%TYPE,
        p_observationday            IN     sampleheader.sph_observationday%TYPE,
        p_observationmonth          IN     sampleheader.sph_observationmonth%TYPE,
        p_observationyear           IN     sampleheader.sph_observationyear%TYPE,
        p_period                    IN     sampleheader.sph_period%TYPE,
        p_indexvalueibch            IN     sampleheader.sph_indexvalueibch%TYPE,
        p_indexvalueibch_orig       IN     sampleheader.sph_indexvalueibch_orig%TYPE,
        p_makroindexvalue           IN     sampleheader.sph_makroindexvalue%TYPE,
        p_makroindexvalue_orig             sampleheader.sph_makroindexvalue_orig%TYPE,
        p_spearindexvalue           IN     sampleheader.sph_spearindexvalue%TYPE,
        p_spearindexvalue_orig             sampleheader.sph_spearindexvalue_orig%TYPE,
        p_usr_id                    IN     sampleheader.sph_usr_id_create%TYPE,
        p_visibilitystatus          IN     sampleheader.sph_visibilitystatus%TYPE,
        p_prj_id                    IN     sampleheader.sph_prj_id%TYPE,
        p_ivr_id_spear              IN     sampleheader.sph_ivr_id_spear%TYPE,
        p_ivr_id_ibch               IN     sampleheader.sph_ivr_id_ibch%TYPE,
        p_ivr_id_makroindex         IN     sampleheader.sph_ivr_id_makroindex%TYPE,
        p_ibch_sum_taxon            IN     sampleheader.sph_ibch_sum_taxon%TYPE,
        p_ibch_sum_ephemeroptera    IN     sampleheader.sph_ibch_sum_ephemeroptera%TYPE,
        p_ibch_sum_plecoptera       IN     sampleheader.sph_ibch_sum_plecoptera%TYPE,
        p_ibch_sum_tricoptera       IN     sampleheader.sph_ibch_sum_tricoptera%TYPE,
        p_ibch_indicator_group      IN     sampleheader.sph_ibch_indicator_group%TYPE,
        p_sommeneoz                 IN     sampleheader.sph_sommeneoz%TYPE,
        p_autreneoz_1               IN     sampleheader.sph_autreneoz_1%TYPE,
        p_autreneoz_2               IN     sampleheader.sph_autreneoz_2%TYPE,
        p_sommeept                  IN     sampleheader.sph_sommeept%TYPE,
        p_sommeabon                 IN     sampleheader.sph_sommeabon%TYPE,
         p_sommetxobs                  IN     sampleheader.sph_sommetxobs%TYPE,
        p_sommetxcor                  IN     sampleheader.sph_sommetxcor%TYPE,
        p_valeurvt                  IN     sampleheader.sph_valeurvt%TYPE,
        p_valeurgi                  IN     sampleheader.sph_valeurgi%TYPE,
        p_valeurgimax               IN     sampleheader.sph_valeurgimax%TYPE,
        p_ibchq                     IN     sampleheader.sph_ibchq%TYPE,
        p_vc                        IN     sampleheader.sph_vc%TYPE,
        p_id                           OUT sampleheader.sph_id%TYPE)
    /*---------------------------------------------------------------------------------*/
    IS
        l_observationday       sampleheader.sph_observationday%TYPE;
        l_observationmonth     sampleheader.sph_observationmonth%TYPE;
        l_observationyear      sampleheader.sph_observationyear%TYPE;
        l_absolutenumberflag   sampleheader.sph_absolutenumberflag%TYPE;
    BEGIN
        p_id := seq_sampleheader.NEXTVAL;
        pkg_debug.p_write ('PKG_SAMPLEHEADER.p_write',
                           'Absolute number flag=' || p_absolutenumberflag);
        l_absolutenumberflag := pkg_constante.cst_no;

        IF p_absolutenumberflag IS NULL
        THEN
            l_absolutenumberflag := pkg_constante.cst_no;
        ELSIF UPPER (p_absolutenumberflag) =
              UPPER (pkg_constante.cst_casesetted)
        THEN
            l_absolutenumberflag := pkg_constante.cst_yes;
        END IF;

        IF NOT p_observationdate IS NULL
        THEN
            l_observationday := TO_NUMBER (TO_CHAR (p_observationdate, 'DD'));
            l_observationmonth :=
                TO_NUMBER (TO_CHAR (p_observationdate, 'MM'));
            l_observationyear :=
                TO_NUMBER (TO_CHAR (p_observationdate, 'YYYY'));
        ELSE
            l_observationday := p_observationday;
            l_observationmonth := p_observationmonth;
            l_observationyear := p_observationyear;
        END IF;

        DBMS_OUTPUT.put_line (
               'Sampleheader: '
            || p_observationdate
            || ' day='
            || l_observationday
            || ' month='
            || l_observationmonth
            || ' year='
            || l_observationyear);

        INSERT INTO sampleheader (sph_id,
                                  sph_sst_id,
                                  sph_iph_id,
                                  sph_imh_id,
                                  sph_smf_id,
                                  sph_ins_id_principal,
                                  sph_ins_id_mandatary,
                                  sph_cvl_id_sysprecisionref,
                                  sph_cvl_id_sysprecision,
                                  sph_ptv_id,
                                  sph_cvl_id_windowibch,
                                  sph_cvl_id_windowmakroindex,
                                  sph_cvl_id_windowspear,
                                  sph_project,
                                  sph_determinateddate,
                                  sph_cvl_id_midatstat,
                                  sph_absolutenumberflag,
                                  sph_observationdate,
                                  sph_observationday,
                                  sph_observationmonth,
                                  sph_observationyear,
                                  sph_period,
                                  sph_indexvalueibch,
                                  sph_indexvalueibch_orig,
                                  sph_makroindexvalue,
                                  sph_spearindexvalue,
                                  sph_makroindexvalue_orig,
                                  sph_spearindexvalue_orig,
                                  sph_visibilitystatus,
                                  sph_prj_id,
                                  sph_ivr_id_spear,
                                  sph_ivr_id_ibch,
                                  sph_ivr_id_makroindex,
                                  sph_usr_id_create,
                                  sph_usr_create_date,
                                  sph_ibch_sum_taxon,
                                  sph_ibch_sum_ephemeroptera,
                                  sph_ibch_sum_plecoptera,
                                  sph_ibch_sum_tricoptera,
                                  sph_ibch_indicator_group,
                                  sph_sommeneoz,
                                  sph_autreneoz_1,
                                  sph_autreneoz_2,
                                  sph_sommeept,
                                  sph_sommeabon,
                                  sph_sommetxobs,
                                  sph_sommetxcor,
                                  sph_valeurvt,
                                  sph_valeurgi,
                                  sph_valeurgimax,
                                  sph_ibchq,
                                  sph_vc)
             VALUES (p_id,
                     p_sst_id,
                     p_iph_id,
                     p_imh_id,
                     p_smf_id,
                     p_ins_id_principal,
                     p_ins_id_mandatary,
                     p_cvl_id_sysprecisionref,
                     p_cvl_id_sysprecision,
                     p_ptv_id,
                     p_cvl_id_windowibch,
                     p_cvl_id_windowmakroindex,
                     p_cvl_id_windowspear,
                     p_project,
                     p_determinateddate,
                     p_cvl_id_midatstat,
                     l_absolutenumberflag,
                     p_observationdate,
                     l_observationday,
                     l_observationmonth,
                     l_observationyear,
                     p_period,
                     p_indexvalueibch,
                     p_indexvalueibch_orig,
                     p_makroindexvalue,
                     p_spearindexvalue,
                     p_makroindexvalue_orig,
                     p_spearindexvalue_orig,
                     p_visibilitystatus,
                     p_prj_id,
                     p_ivr_id_spear,
                     p_ivr_id_ibch,
                     p_ivr_id_makroindex,
                     p_usr_id,
                     SYSDATE,
                     p_ibch_sum_taxon,
                     p_ibch_sum_ephemeroptera,
                     p_ibch_sum_plecoptera,
                     p_ibch_sum_tricoptera,
                     p_ibch_indicator_group,
                     p_sommeneoz,
                     p_autreneoz_1,
                     p_autreneoz_2,
                     p_sommeept,
                     p_sommeabon,
                     p_sommetxobs,
                     p_sommetxcor,
                     p_valeurvt,
                     p_valeurgi,
                     p_valeurgimax,
                     p_ibchq,
                     p_vc);

        NULL;
    END;

    /*----------------------------------------------------------------------------------*/
    PROCEDURE p_writefull (
        p_sst_id                      IN     sampleheader.sph_sst_id%TYPE,
        p_iph_id                      IN     sampleheader.sph_iph_id%TYPE,
        p_imh_id                      IN     sampleheader.sph_imh_id%TYPE,
        p_smf_id                      IN     sampleheader.sph_smf_id%TYPE,
        p_ins_id_principal            IN     sampleheader.sph_ins_id_principal%TYPE,
        p_ins_id_mandatary            IN     sampleheader.sph_ins_id_mandatary%TYPE,
        p_cvl_id_sysprecisionref      IN     sampleheader.sph_cvl_id_sysprecisionref%TYPE,
        p_cvl_id_sysprecision         IN     sampleheader.sph_cvl_id_sysprecision%TYPE,
        p_ptv_id                      IN     sampleheader.sph_ptv_id%TYPE,
        p_cvl_id_windowibch           IN     sampleheader.sph_cvl_id_windowibch%TYPE,
        p_cvl_id_windowmakroindex     IN     sampleheader.sph_cvl_id_windowmakroindex%TYPE,
        p_cvl_id_windowspear          IN     sampleheader.sph_cvl_id_windowspear%TYPE,
        p_project                     IN     sampleheader.sph_project%TYPE,
        p_determinateddate            IN     sampleheader.sph_determinateddate%TYPE,
        p_cvl_id_midatstat            IN     sampleheader.sph_cvl_id_midatstat%TYPE, -- IMH_INDICETYPE doit être traduit en cvl_id_midatstat (pour l'instant on le défini dans le détail)
        p_absolutenumberflag          IN     sampleheader.sph_absolutenumberflag%TYPE,
        p_observationdate             IN     sampleheader.sph_observationdate%TYPE,
        p_observationday              IN     sampleheader.sph_observationday%TYPE,
        p_observationmonth            IN     sampleheader.sph_observationmonth%TYPE,
        p_observationyear             IN     sampleheader.sph_observationyear%TYPE,
        p_period                      IN     sampleheader.sph_period%TYPE,
        p_indexvalueibch              IN     sampleheader.sph_indexvalueibch%TYPE,
        p_indexvalueibch_orig         IN     sampleheader.sph_indexvalueibch_orig%TYPE,
        p_makroindexvalue             IN     sampleheader.sph_makroindexvalue%TYPE,
        p_makroindexvalue_orig        IN     sampleheader.sph_makroindexvalue_orig%TYPE,
        p_spearindexvalue             IN     sampleheader.sph_spearindexvalue%TYPE,
        p_spearindexvalue_orig        IN     sampleheader.sph_spearindexvalue_orig%TYPE,
        p_usr_id                      IN     sampleheader.sph_usr_id_create%TYPE,
        p_visibilitystatus            IN     sampleheader.sph_visibilitystatus%TYPE,
        p_prj_id                      IN     sampleheader.sph_prj_id%TYPE,
        p_ivr_id_spear                IN     sampleheader.sph_ivr_id_spear%TYPE,
        p_ivr_id_ibch                 IN     sampleheader.sph_ivr_id_ibch%TYPE,
        p_ivr_id_makroindex           IN     sampleheader.sph_ivr_id_makroindex%TYPE,
        p_sommeneoz                   IN     sampleheader.sph_sommeneoz%TYPE,
        p_autreneoz_1                 IN     sampleheader.sph_autreneoz_1%TYPE,
        p_autreneoz_2                 IN     sampleheader.sph_autreneoz_2%TYPE,
        p_sommeept                    IN     sampleheader.sph_sommeept%TYPE,
        p_sommeabon                   IN     sampleheader.sph_sommeabon%TYPE,
        p_sommetxobs                  IN     sampleheader.sph_sommetxobs%TYPE,
        p_sommetxcor                  IN     sampleheader.sph_sommetxcor%TYPE,
        p_valeurvt                    IN     sampleheader.sph_valeurvt%TYPE,
        p_valeurgi                    IN     sampleheader.sph_valeurgi%TYPE,
        p_valeurgimax                 IN     sampleheader.sph_valeurgimax%TYPE,
        p_ibchq                       IN     sampleheader.sph_ibchq%TYPE,
        p_vc                          IN     sampleheader.sph_vc%TYPE,
        p_taxonindicateur             IN     sampleheader.sph_taxonindicateur%TYPE,
        p_ibchrobust                  IN     sampleheader.sph_ibchrobust%TYPE,
        p_classevariete               IN     sampleheader.sph_classevariete%TYPE,
        p_classevariete_corr          IN     sampleheader.sph_classevariete_corr%TYPE,
        p_classevarieterobust         IN     sampleheader.sph_classevarieterobust%TYPE,
        p_classevarieterobust_corr    IN     sampleheader.sph_classevarieterobust_corr%TYPE,
        p_classevariete_final         IN     sampleheader.sph_classevariete_final%TYPE,
        p_classevarieterobust_final   IN     sampleheader.sph_classevarieterobust_final%TYPE,
        p_taxonfrequencesum           IN     sampleheader.sph_taxonfrequencesum%TYPE,
        p_gimax                       IN     sampleheader.sph_gimax%TYPE,
        p_gimaxrobust                 IN     sampleheader.sph_gimaxrobust%TYPE,
        p_gi_final                    IN     sampleheader.sph_gi_final%TYPE,
        p_girobust_final              IN     sampleheader.sph_girobust_final%TYPE,
        p_sumfamily                   IN     sampleheader.sph_sumfamily%TYPE,
        p_sumfamilycorrected          IN     sampleheader.sph_sumfamilycorrected%TYPE,
        p_sumfamilyrobust             IN     sampleheader.sph_sumfamilyrobust%TYPE,
        p_sumfamilyrobustcorrected    IN     sampleheader.sph_sumfamilyrobustcorrected%TYPE,
        p_ephemeropteracounter        IN     sampleheader.sph_ephemeropteracounter%TYPE,
        p_plecopteracounter           IN     sampleheader.sph_plecopteracounter%TYPE,
        p_tricopteracounter           IN     sampleheader.sph_tricopteracounter%TYPE,
        p_id                             OUT sampleheader.sph_id%TYPE)
    /*---------------------------------------------------------------------------------*/
    IS
        l_observationday       sampleheader.sph_observationday%TYPE;
        l_observationmonth     sampleheader.sph_observationmonth%TYPE;
        l_observationyear      sampleheader.sph_observationyear%TYPE;
        l_absolutenumberflag   sampleheader.sph_absolutenumberflag%TYPE;
    BEGIN
        p_id := seq_sampleheader.NEXTVAL;
        pkg_debug.p_write ('PKG_SAMPLEHEADER.p_write',
                           'Absolute number flag=' || p_absolutenumberflag);
        l_absolutenumberflag := pkg_constante.cst_no;

        IF p_absolutenumberflag IS NULL
        THEN
            l_absolutenumberflag := pkg_constante.cst_no;
        ELSIF UPPER (p_absolutenumberflag) =
              UPPER (pkg_constante.cst_casesetted)
        THEN
            l_absolutenumberflag := pkg_constante.cst_yes;
        END IF;

        IF NOT p_observationdate IS NULL
        THEN
            l_observationday := TO_NUMBER (TO_CHAR (p_observationdate, 'DD'));
            l_observationmonth :=
                TO_NUMBER (TO_CHAR (p_observationdate, 'MM'));
            l_observationyear :=
                TO_NUMBER (TO_CHAR (p_observationdate, 'YYYY'));
        ELSE
            l_observationday := p_observationday;
            l_observationmonth := p_observationmonth;
            l_observationyear := p_observationyear;
        END IF;

        DBMS_OUTPUT.put_line (
               'Sampleheader: '
            || p_observationdate
            || ' day='
            || l_observationday
            || ' month='
            || l_observationmonth
            || ' year='
            || l_observationyear);

        INSERT INTO sampleheader (sph_id,
                                  sph_sst_id,
                                  sph_iph_id,
                                  sph_imh_id,
                                  sph_smf_id,
                                  sph_ins_id_principal,
                                  sph_ins_id_mandatary,
                                  sph_cvl_id_sysprecisionref,
                                  sph_cvl_id_sysprecision,
                                  sph_ptv_id,
                                  sph_cvl_id_windowibch,
                                  sph_cvl_id_windowmakroindex,
                                  sph_cvl_id_windowspear,
                                  sph_project,
                                  sph_determinateddate,
                                  sph_cvl_id_midatstat,
                                  sph_absolutenumberflag,
                                  sph_observationdate,
                                  sph_observationday,
                                  sph_observationmonth,
                                  sph_observationyear,
                                  sph_period,
                                  sph_indexvalueibch,
                                  sph_indexvalueibch_orig,
                                  sph_makroindexvalue,
                                  sph_spearindexvalue,
                                  sph_makroindexvalue_orig,
                                  sph_spearindexvalue_orig,
                                  sph_visibilitystatus,
                                  sph_prj_id,
                                  sph_ivr_id_spear,
                                  sph_ivr_id_ibch,
                                  sph_ivr_id_makroindex,
                                  sph_usr_id_create,
                                  sph_usr_create_date,
                                  sph_sommeneoz,
                                  sph_autreneoz_1,
                                  sph_autreneoz_2,
                                  sph_sommeept,
                                  sph_sommeabon,
                                  sph_sommetxobs,
                                  sph_sommetxcor,
                                  sph_valeurvt,
                                  sph_valeurgi,
                                  sph_valeurgimax,
                                  sph_ibchq,
                                  sph_vc,
                                  sph_taxonindicateur,
                                  sph_ibchrobust,
                                  sph_classevariete,
                                  sph_classevariete_corr,
                                  sph_classevarieterobust,
                                  sph_classevarieterobust_corr,
                                  sph_classevariete_final,
                                  sph_classevarieterobust_final,
                                  sph_taxonfrequencesum,
                                  sph_gimax,
                                  sph_gimaxrobust,
                                  sph_gi_final,
                                  sph_girobust_final,
                                  sph_sumfamily,
                                  sph_sumfamilycorrected,
                                  sph_sumfamilyrobust,
                                  sph_sumfamilyrobustcorrected,
                                  sph_ephemeropteracounter,
                                  sph_tricopteracounter,
                                  sph_plecopteracounter)
             VALUES (p_id,
                     p_sst_id,
                     p_iph_id,
                     p_imh_id,
                     p_smf_id,
                     p_ins_id_principal,
                     p_ins_id_mandatary,
                     p_cvl_id_sysprecisionref,
                     p_cvl_id_sysprecision,
                     p_ptv_id,
                     p_cvl_id_windowibch,
                     p_cvl_id_windowmakroindex,
                     p_cvl_id_windowspear,
                     p_project,
                     p_determinateddate,
                     p_cvl_id_midatstat,
                     l_absolutenumberflag,
                     p_observationdate,
                     l_observationday,
                     l_observationmonth,
                     l_observationyear,
                     p_period,
                     p_indexvalueibch,
                     p_indexvalueibch_orig,
                     p_makroindexvalue,
                     p_spearindexvalue,
                     p_makroindexvalue_orig,
                     p_spearindexvalue_orig,
                     p_visibilitystatus,
                     p_prj_id,
                     p_ivr_id_spear,
                     p_ivr_id_ibch,
                     p_ivr_id_makroindex,
                     p_usr_id,
                     SYSDATE,
                     p_sommeneoz,
                     p_autreneoz_1,
                     p_autreneoz_2,
                     p_sommeept,
                     p_sommeabon,
                     p_sommetxobs,
                     p_sommetxcor,
                     p_valeurvt,
                     p_valeurgi,
                     p_valeurgimax,
                     p_ibchq,
                     p_vc,
                     p_taxonindicateur,
                     p_ibchrobust,
                     p_classevariete,
                     p_classevariete_corr,
                     p_classevarieterobust,
                     p_classevarieterobust_corr,
                     p_classevariete_final,
                     p_classevarieterobust_final,
                     p_taxonfrequencesum,
                     p_gimax,
                     p_gimaxrobust,
                     p_gi_final,
                     p_girobust_final,
                     p_sumfamily,
                     p_sumfamilycorrected,
                     p_sumfamilyrobust,
                     p_sumfamilyrobustcorrected,
                     p_ephemeropteracounter,
                     p_tricopteracounter,
                     p_plecopteracounter);

        NULL;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_setiffilledivr_id (
        p_spearindexvalue         IN     sampleheader.sph_spearindexvalue%TYPE,
        p_indexvalueibch          IN     sampleheader.sph_indexvalueibch%TYPE,
        p_makroindexvalue         IN     sampleheader.sph_makroindexvalue%TYPE,
        p_ivr_cvl_id_spear           OUT sampleheader.sph_ivr_id_spear%TYPE,
        p_ivr_cvl_id_ibch            OUT sampleheader.sph_ivr_id_ibch%TYPE,
        p_ivr_cvl_id_makroindex      OUT sampleheader.sph_ivr_id_makroindex%TYPE)
    /*--------------------------------------------------------------*/
    IS
        l_recindiceversionspear        indiceversion%ROWTYPE;
        l_recindiceversionibch         indiceversion%ROWTYPE;
        l_recindiceversionmakroindex   indiceversion%ROWTYPE;
    BEGIN
        p_ivr_cvl_id_spear := NULL;
        p_ivr_cvl_id_ibch := NULL;
        p_ivr_cvl_id_makroindex := NULL;
        l_recindiceversionspear :=
            pkg_indiceversion.f_getcurrentversion (
                pkg_codevalue.cst_midatindice_spear);
        l_recindiceversionibch :=
            pkg_indiceversion.f_getcurrentversion (
                pkg_codevalue.cst_midatindice_ibch);
        l_recindiceversionmakroindex :=
            pkg_indiceversion.f_getcurrentversion (
                pkg_codevalue.cst_midatindice_makroindex);

        IF NOT p_spearindexvalue IS NULL
        THEN
            p_ivr_cvl_id_spear := l_recindiceversionspear.ivr_id;
        END IF;

        IF NOT p_indexvalueibch IS NULL
        THEN
            p_ivr_cvl_id_ibch := l_recindiceversionibch.ivr_id;
        END IF;

        IF NOT p_makroindexvalue IS NULL
        THEN
            p_ivr_cvl_id_makroindex := l_recindiceversionmakroindex.ivr_id;
        END IF;
    END;

    /*----------------------------------------------------------------------------------*/
    PROCEDURE p_write (
        p_sst_id                       IN     sampleheader.sph_sst_id%TYPE,
        p_iph_id                       IN     sampleheader.sph_iph_id%TYPE,
        p_imh_id                       IN     sampleheader.sph_imh_id%TYPE,
        p_smf_id                       IN     sampleheader.sph_smf_id%TYPE,
        p_ins_id_principal             IN     sampleheader.sph_ins_id_principal%TYPE,
        p_ins_id_mandatary             IN     sampleheader.sph_ins_id_mandatary%TYPE,
        p_cvl_id_sysprecisionref       IN     sampleheader.sph_cvl_id_sysprecisionref%TYPE,
        p_cvl_id_sysprecision          IN     sampleheader.sph_cvl_id_sysprecision%TYPE,
        p_ptv_id                       IN     sampleheader.sph_ptv_id%TYPE,
        p_cvl_id_windowibch            IN     sampleheader.sph_cvl_id_windowibch%TYPE,
        p_cvl_id_windowmakroindex      IN     sampleheader.sph_cvl_id_windowmakroindex%TYPE,
        p_cvl_id_windowspear           IN     sampleheader.sph_cvl_id_windowspear%TYPE,
        p_project                      IN     sampleheader.sph_project%TYPE,
        p_determinateddate             IN     sampleheader.sph_determinateddate%TYPE,
        p_cvl_id_midatstat             IN     sampleheader.sph_cvl_id_midatstat%TYPE, -- IMH_INDICETYPE doit être traduit en cvl_id_midatstat (pour l'instant on le défini dans le détail)
        p_absolutenumberflag           IN     sampleheader.sph_absolutenumberflag%TYPE,
        p_observationdate              IN     sampleheader.sph_observationdate%TYPE,
        p_observationday               IN     sampleheader.sph_observationday%TYPE,
        p_observationmonth             IN     sampleheader.sph_observationmonth%TYPE,
        p_observationyear              IN     sampleheader.sph_observationyear%TYPE,
        p_period                       IN     sampleheader.sph_period%TYPE,
        p_indexvalueibch               IN     sampleheader.sph_indexvalueibch%TYPE,
        p_indexvalueibch_orig          IN     sampleheader.sph_indexvalueibch_orig%TYPE,
        p_makroindexvalue              IN     sampleheader.sph_makroindexvalue%TYPE,
        p_makroindexvalue_orig         IN     sampleheader.sph_makroindexvalue_orig%TYPE,
        p_spearindexvalue              IN     sampleheader.sph_spearindexvalue%TYPE,
        p_spearindexvalue_orig         IN     sampleheader.sph_spearindexvalue_orig%TYPE,
        p_cvl_id_mkicase               IN     sampleheader.sph_cvl_id_mkicase%TYPE,
        p_mkirangecount                IN     sampleheader.sph_mkirangecount%TYPE,
        p_mkiinsectacount              IN     sampleheader.sph_mkiinsectacount%TYPE,
        p_mkinonisectacount            IN     sampleheader.sph_mkinonisectacount%TYPE,
        p_mkiplecopteracount           IN     sampleheader.sph_mkiplecopteracount%TYPE,
        p_mkitricopteracount           IN     sampleheader.sph_mkitricopteracount%TYPE,
        p_mkiephemeropteracount        IN     sampleheader.sph_mkiephemeropteracount%TYPE,
        p_mkibaetidaecount             IN     sampleheader.sph_mkibaetidaecount%TYPE,
        p_mkigammaruscount             IN     sampleheader.sph_mkigammaruscount%TYPE,
        p_mkihydropsychecount          IN     sampleheader.sph_mkihydropsychecount%TYPE,
        p_mkiaselluscount              IN     sampleheader.sph_mkiaselluscount%TYPE,
        p_mkihirudinaecount            IN     sampleheader.sph_mkihirudinaecount%TYPE,
        p_mkitubificidaecount          IN     sampleheader.sph_mkitubificidaecount%TYPE,
        p_mkierrornumber               IN     sampleheader.sph_mkierrornumber%TYPE,
        p_identifiedtaxoncount         IN     sampleheader.sph_identifiedtaxoncount%TYPE,
        p_identifiedtaxoncountlowlev   IN     sampleheader.sph_identifiedtaxoncountlowlev%TYPE,
        p_identifiedtaxoncountuplev    IN     sampleheader.sph_identifiedtaxoncountuplev%TYPE,
        p_ibchidentifiedtaxoncount     IN     sampleheader.sph_ibchidentifiedtaxoncount%TYPE,
        p_spearidentifiedtaxoncount    IN     sampleheader.sph_spearidentifiedtaxoncount%TYPE,
        p_ibchgivalue                  IN     sampleheader.sph_ibchgivalue%TYPE,
        p_ibchvtvalue                  IN     sampleheader.sph_ibchvtvalue%TYPE,
        p_usr_id                       IN     sampleheader.sph_usr_id_create%TYPE,
        p_visibilitystatus             IN     sampleheader.sph_visibilitystatus%TYPE,
        p_prj_id                       IN     sampleheader.sph_prj_id%TYPE,
        p_ivr_id_spear                 IN     sampleheader.sph_ivr_id_spear%TYPE,
        p_ivr_id_ibch                  IN     sampleheader.sph_ivr_id_ibch%TYPE,
        p_ivr_id_makroindex            IN     sampleheader.sph_ivr_id_makroindex%TYPE,
        p_id                              OUT sampleheader.sph_id%TYPE)
    /*---------------------------------------------------------------------------------*/
    -- Utilisé par p_savealldata
    IS
        l_observationday       sampleheader.sph_observationday%TYPE;
        l_observationmonth     sampleheader.sph_observationmonth%TYPE;
        l_observationyear      sampleheader.sph_observationyear%TYPE;
        l_absolutenumberflag   sampleheader.sph_absolutenumberflag%TYPE;
    BEGIN
        p_id := seq_sampleheader.NEXTVAL;

        IF p_absolutenumberflag IS NULL
        THEN
            l_absolutenumberflag := pkg_constante.cst_yes;
        ELSIF UPPER (p_absolutenumberflag) =
              UPPER (pkg_constante.cst_casesetted)
        THEN
            l_absolutenumberflag := pkg_constante.cst_no;
        ELSE
            l_absolutenumberflag := p_absolutenumberflag;
        END IF;

        IF NOT p_observationdate IS NULL
        THEN
            l_observationday := TO_NUMBER (TO_CHAR (p_observationdate, 'DD'));
            l_observationmonth :=
                TO_NUMBER (TO_CHAR (p_observationdate, 'MM'));
            l_observationyear :=
                TO_NUMBER (TO_CHAR (p_observationdate, 'YYYY'));
        ELSE
            l_observationday := p_observationday;
            l_observationmonth := p_observationmonth;
            l_observationyear := p_observationyear;
        END IF;



        INSERT INTO sampleheader (sph_id,
                                  sph_sst_id,
                                  sph_iph_id,
                                  sph_imh_id,
                                  sph_smf_id,
                                  sph_ins_id_principal,
                                  sph_ins_id_mandatary,
                                  sph_cvl_id_sysprecisionref,
                                  sph_cvl_id_sysprecision,
                                  sph_ptv_id,
                                  sph_cvl_id_windowibch,
                                  sph_cvl_id_windowmakroindex,
                                  sph_cvl_id_windowspear,
                                  sph_project,
                                  sph_determinateddate,
                                  sph_cvl_id_midatstat,
                                  sph_absolutenumberflag,
                                  sph_observationdate,
                                  sph_observationday,
                                  sph_observationmonth,
                                  sph_observationyear,
                                  sph_period,
                                  sph_indexvalueibch,
                                  sph_indexvalueibch_orig,
                                  sph_makroindexvalue,
                                  sph_spearindexvalue,
                                  sph_makroindexvalue_orig,
                                  sph_spearindexvalue_orig,
                                  sph_cvl_id_mkicase,
                                  sph_mkirangecount,
                                  sph_mkiinsectacount,
                                  sph_mkinonisectacount,
                                  sph_mkiplecopteracount,
                                  sph_mkitricopteracount,
                                  sph_mkiephemeropteracount,
                                  sph_mkibaetidaecount,
                                  sph_mkigammaruscount,
                                  sph_mkihydropsychecount,
                                  sph_mkiaselluscount,
                                  sph_mkihirudinaecount,
                                  sph_mkitubificidaecount,
                                  sph_mkierrornumber,
                                  sph_identifiedtaxoncount,
                                  sph_identifiedtaxoncountlowlev,
                                  sph_identifiedtaxoncountuplev,
                                  sph_ibchidentifiedtaxoncount,
                                  sph_spearidentifiedtaxoncount,
                                  sph_ibchgivalue,
                                  sph_ibchvtvalue,
                                  sph_visibilitystatus,
                                  sph_prj_id,
                                  sph_ivr_id_spear,
                                  sph_ivr_id_ibch,
                                  sph_ivr_id_makroindex,
                                  sph_usr_id_create,
                                  sph_usr_create_date)
             VALUES (p_id,
                     p_sst_id,
                     p_iph_id,
                     p_imh_id,
                     p_smf_id,
                     p_ins_id_principal,
                     p_ins_id_mandatary,
                     p_cvl_id_sysprecisionref,
                     p_cvl_id_sysprecision,
                     p_ptv_id,
                     p_cvl_id_windowibch,
                     p_cvl_id_windowmakroindex,
                     p_cvl_id_windowspear,
                     p_project,
                     p_determinateddate,
                     p_cvl_id_midatstat,
                     l_absolutenumberflag,
                     p_observationdate,
                     l_observationday,
                     l_observationmonth,
                     l_observationyear,
                     p_period,
                     p_indexvalueibch,
                     p_indexvalueibch_orig,
                     p_makroindexvalue,
                     p_spearindexvalue,
                     p_makroindexvalue_orig,
                     p_spearindexvalue_orig,
                     p_cvl_id_mkicase,
                     p_mkirangecount,
                     p_mkiinsectacount,
                     p_mkinonisectacount,
                     p_mkiplecopteracount,
                     p_mkitricopteracount,
                     p_mkiephemeropteracount,
                     p_mkibaetidaecount,
                     p_mkigammaruscount,
                     p_mkihydropsychecount,
                     p_mkiaselluscount,
                     p_mkihirudinaecount,
                     p_mkitubificidaecount,
                     p_mkierrornumber,
                     p_identifiedtaxoncount,
                     p_identifiedtaxoncountlowlev,
                     p_identifiedtaxoncountuplev,
                     p_ibchidentifiedtaxoncount,
                     p_spearidentifiedtaxoncount,
                     p_ibchgivalue,
                     p_ibchvtvalue,
                     p_visibilitystatus,
                     p_prj_id,
                     p_ivr_id_spear,
                     p_ivr_id_ibch,
                     p_ivr_id_makroindex,
                     p_usr_id,
                     SYSDATE);

        NULL;
    END;



    /*-----------------------------------------------------------------------------------*/
    PROCEDURE p_savealldata (
        p_iph_lan_id                   IN     importprotocolheader.iph_lan_id%TYPE,
        p_usr_id                       IN     sampleheader.sph_usr_id_create%TYPE,
        p_smf_id                       IN     sampleheader.sph_smf_id%TYPE,
        p_sst_id                       IN     sampleheader.sph_sst_id%TYPE,
        p_iph_id                       IN     sampleheader.sph_iph_id%TYPE,
        p_imh_id                       IN     sampleheader.sph_imh_id%TYPE,
        p_ins_id_principal             IN     sampleheader.sph_ins_id_principal%TYPE,
        p_ins_id_mandatary             IN     sampleheader.sph_ins_id_mandatary%TYPE,
        p_cvl_id_sysprecisionref       IN     sampleheader.sph_cvl_id_sysprecisionref%TYPE,
        p_cvl_id_sysprecision          IN     sampleheader.sph_cvl_id_sysprecision%TYPE,
        p_ptv_id                       IN     sampleheader.sph_ptv_id%TYPE,
        p_cvl_id_windowibch            IN     sampleheader.sph_cvl_id_windowibch%TYPE,
        p_cvl_id_windowmakroindex      IN     sampleheader.sph_cvl_id_windowmakroindex%TYPE,
        p_cvl_id_windowspear           IN     sampleheader.sph_cvl_id_windowspear%TYPE,
        p_project                      IN     sampleheader.sph_project%TYPE,
        p_determinateddate             IN     sampleheader.sph_determinateddate%TYPE,
        p_cvl_id_midatstat             IN     sampleheader.sph_cvl_id_midatstat%TYPE, -- IMH_INDICETYPE doit être traduit en cvl_id_midatstat (pour l'instant on le défini dans le détail)
        p_absolutenumberflag           IN     sampleheader.sph_absolutenumberflag%TYPE,
        p_observationdate              IN     sampleheader.sph_observationdate%TYPE,
        p_observationday               IN     sampleheader.sph_observationday%TYPE,
        p_observationmonth             IN     sampleheader.sph_observationmonth%TYPE,
        p_observationyear              IN     sampleheader.sph_observationyear%TYPE,
        p_period                       IN     sampleheader.sph_period%TYPE,
        p_locality                     IN     sampleheaderitem.shm_item%TYPE,
        p_watercourse                  IN     sampleheaderitem.shm_item%TYPE,
        p_calledplace                  IN     sampleheaderitem.shm_item%TYPE,
        p_title                        IN     sampledocument.spt_title%TYPE,
        p_filename                     IN     sampledocument.spt_filename%TYPE,
        p_indexvalueibch_orig          IN     sampleheader.sph_indexvalueibch_orig%TYPE,
        p_indexvalueibch               IN     sampleheader.sph_indexvalueibch%TYPE,
        p_makroindexvalue_orig         IN     sampleheader.sph_makroindexvalue_orig%TYPE,
        p_makroindexvalue              IN     sampleheader.sph_makroindexvalue%TYPE,
        p_spearindexvalue_orig         IN     sampleheader.sph_spearindexvalue_orig%TYPE,
        p_spearindexvalue              IN     sampleheader.sph_spearindexvalue%TYPE,
        p_cvl_id_mkicase               IN     sampleheader.sph_cvl_id_mkicase%TYPE,
        p_mkirangecount                IN     sampleheader.sph_mkirangecount%TYPE,
        p_mkiinsectacount              IN     sampleheader.sph_mkiinsectacount%TYPE,
        p_mkinonisectacount            IN     sampleheader.sph_mkinonisectacount%TYPE,
        p_mkiplecopteracount           IN     sampleheader.sph_mkiplecopteracount%TYPE,
        p_mkitricopteracount           IN     sampleheader.sph_mkitricopteracount%TYPE,
        p_mkiephemeropteracount        IN     sampleheader.sph_mkiephemeropteracount%TYPE,
        p_mkibaetidaecount             IN     sampleheader.sph_mkibaetidaecount%TYPE,
        p_mkigammaruscount             IN     sampleheader.sph_mkigammaruscount%TYPE,
        p_mkihydropsychecount          IN     sampleheader.sph_mkihydropsychecount%TYPE,
        p_mkiaselluscount              IN     sampleheader.sph_mkiaselluscount%TYPE,
        p_mkihirudinaecount            IN     sampleheader.sph_mkihirudinaecount%TYPE,
        p_mkitubificidaecount          IN     sampleheader.sph_mkitubificidaecount%TYPE,
        p_mkierrornumber               IN     sampleheader.sph_mkierrornumber%TYPE,
        p_identifiedtaxoncount         IN     sampleheader.sph_identifiedtaxoncount%TYPE,
        p_identifiedtaxoncountlowlev   IN     sampleheader.sph_identifiedtaxoncountlowlev%TYPE,
        p_identifiedtaxoncountuplev    IN     sampleheader.sph_identifiedtaxoncountuplev%TYPE,
        p_ibchidentifiedtaxoncount     IN     sampleheader.sph_ibchidentifiedtaxoncount%TYPE,
        p_spearidentifiedtaxoncount    IN     sampleheader.sph_spearidentifiedtaxoncount%TYPE,
        p_ibchgivalue                  IN     sampleheader.sph_ibchgivalue%TYPE,
        p_ibchvtvalue                  IN     sampleheader.sph_ibchvtvalue%TYPE,
        p_visibilitystatus             IN     sampleheader.sph_visibilitystatus%TYPE,
        p_observer                     IN     sampleheaderitem.shm_item%TYPE,
        p_prj_id                       IN     sampleheader.sph_prj_id%TYPE,
        p_ivr_id_spear                 IN     sampleheader.sph_ivr_id_spear%TYPE,
        p_ivr_id_ibch                  IN     sampleheader.sph_ivr_id_ibch%TYPE,
        p_ivr_id_makroindex            IN     sampleheader.sph_ivr_id_makroindex%TYPE,
        p_sph_id                          OUT sampleheader.sph_id%TYPE)
    IS
        l_sph_id                   sampleheader.sph_id%TYPE;
        l_recordvaluewatercourse   codevalue%ROWTYPE;
        l_recordvaluelocality      codevalue%ROWTYPE;
        l_recordvalueobserver      codevalue%ROWTYPE;
        l_recordvaluecalledplace   codevalue%ROWTYPE;
        l_shm_id                   sampleheaderitem.shm_id%TYPE;
        l_spt_id                   sampledocument.spt_id%TYPE;
    BEGIN
        DBMS_OUTPUT.put_line (
               'Sampleheader: '
            || p_observationdate
            || ' day='
            || p_observationday
            || ' month='
            || p_observationmonth
            || ' year='
            || p_observationyear);
        l_recordvaluelocality :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_locality,
                pkg_codereference.cst_crf_midathditmty);

        IF l_recordvaluelocality.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_locality
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        l_recordvaluewatercourse :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_watercourse,
                pkg_codereference.cst_crf_midathditmty);

        IF l_recordvaluewatercourse.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_watercourse
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        l_recordvaluecalledplace :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_calledplace,
                pkg_codereference.cst_crf_midathditmty);

        IF l_recordvaluewatercourse.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_calledplace
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;

        l_recordvalueobserver :=
            pkg_codevalue.f_getfromcode (
                pkg_codevalue.cst_midathditem_operator,
                pkg_codereference.cst_crf_midathditmty);

        IF l_recordvaluelocality.cvl_id IS NULL
        THEN
            pkg_message.p_setparameter (
                   'pkg_codevalue. f_getfromcode ('
                || pkg_codevalue.cst_midathditem_operator
                || ','
                || pkg_codereference.cst_crf_midathditmty
                || ')',
                1);
            RAISE pkg_exception.exc_unexpectederror;
        END IF;


        p_write (p_sst_id,
                 p_iph_id,
                 p_imh_id,
                 p_smf_id,
                 p_ins_id_principal,
                 p_ins_id_mandatary,
                 p_cvl_id_sysprecisionref,
                 p_cvl_id_sysprecision,
                 p_ptv_id,
                 p_cvl_id_windowibch,
                 p_cvl_id_windowmakroindex,
                 p_cvl_id_windowspear,
                 p_project,
                 p_determinateddate,
                 p_cvl_id_midatstat,
                 p_absolutenumberflag,
                 p_observationdate,
                 p_observationday,
                 p_observationmonth,
                 p_observationyear,
                 p_period,
                 p_indexvalueibch,                      --.sph_indexvalueibch,
                 p_indexvalueibch_orig,            -- sph_indexvalueibch_orig,
                 p_makroindexvalue,                     --sph_makroindexvalue,
                 p_makroindexvalue_orig,           --sph_makroindexvalue_orig,
                 p_spearindexvalue,                     --sph_spearindexvalue,
                 p_spearindexvalue_orig,           -- sph_spearindexvalue_orig
                 p_cvl_id_mkicase,
                 p_mkirangecount,
                 p_mkiinsectacount,
                 p_mkinonisectacount,
                 p_mkiplecopteracount,
                 p_mkitricopteracount,
                 p_mkiephemeropteracount,
                 p_mkibaetidaecount,
                 p_mkigammaruscount,
                 p_mkihydropsychecount,
                 p_mkiaselluscount,
                 p_mkihirudinaecount,
                 p_mkitubificidaecount,
                 p_mkierrornumber,
                 p_identifiedtaxoncount,
                 p_identifiedtaxoncountlowlev,
                 p_identifiedtaxoncountuplev,
                 p_ibchidentifiedtaxoncount,
                 p_spearidentifiedtaxoncount,
                 p_ibchgivalue,
                 p_ibchvtvalue,
                 p_usr_id,
                 p_visibilitystatus,
                 p_prj_id,
                 p_ivr_id_spear,
                 p_ivr_id_ibch,
                 p_ivr_id_makroindex,
                 l_sph_id);
        p_sph_id := l_sph_id;

        IF NOT p_observer IS NULL
        THEN
            pkg_sampleheaderitem.p_write (
                l_sph_id,
                p_iph_lan_id,
                l_recordvalueobserver.cvl_id,
                p_ptv_id,
                pkg_sampleheaderitem.cst_typecodefromexcelform,
                p_observer,
                NULL,
                p_usr_id,
                l_shm_id);
        END IF;

        IF NOT p_locality IS NULL
        THEN
            pkg_sampleheaderitem.p_write (
                l_sph_id,
                p_iph_lan_id,
                l_recordvaluelocality.cvl_id,
                p_ptv_id,
                pkg_sampleheaderitem.cst_typecodefromexcelform,
                p_locality,
                NULL,
                p_usr_id,
                l_shm_id);
        END IF;

        IF NOT p_watercourse IS NULL
        THEN
            pkg_sampleheaderitem.p_write (
                l_sph_id,
                p_iph_lan_id,
                l_recordvaluewatercourse.cvl_id,
                p_ptv_id,
                pkg_sampleheaderitem.cst_typecodefromexcelform,
                p_watercourse,
                NULL,
                p_usr_id,
                l_shm_id);
        END IF;

        IF NOT p_calledplace IS NULL
        THEN
            pkg_sampleheaderitem.p_write (
                l_sph_id,
                p_iph_lan_id,
                l_recordvaluecalledplace.cvl_id,
                p_ptv_id,
                pkg_sampleheaderitem.cst_typecodefromexcelform,
                p_calledplace,
                NULL,
                p_usr_id,
                l_shm_id);
        END IF;

        IF NOT p_filename IS NULL
        THEN
            pkg_sampledocument.p_write (l_sph_id,
                                        p_ptv_id,
                                        p_filename,
                                        p_title,
                                        p_usr_id,
                                        l_spt_id);
        END IF;

        NULL;
    END;

    /*----------------------------------------------------------------------------------*/
    PROCEDURE p_clearsph_iph_id (p_iph_id IN sampleheader.sph_iph_id%TYPE)
    /*-----------------------------------------------------------------------------------*/
    IS
    BEGIN
        UPDATE sampleheader
           SET sph_iph_id = NULL
         WHERE sph_iph_id = p_iph_id;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_getcountbysmfid (p_smf_id IN sampleheader.sph_smf_id%TYPE)
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM sampleheader
         WHERE sph_smf_id = p_smf_id;

        RETURN l_count;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_countother_sph_id_and_sst_id (
        p_sph_id   IN sampleheader.sph_id%TYPE,
        p_sst_id   IN sampleheader.sph_sst_id%TYPE)
        RETURN NUMBER
    /*-----------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM sampleheader
         WHERE sph_sst_id = p_sst_id AND sph_id != p_sph_id;

        RETURN l_count;
    END;

    /*----------------------------------------------------------------*/
    FUNCTION f_countother_iph_id_and_imh_id (
        p_iph_id   IN sampleheader.sph_iph_id%TYPE,
        p_imh_id   IN sampleheader.sph_imh_id%TYPE)
        RETURN NUMBER
    /*-----------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM sampleheader
         WHERE sph_imh_id != p_imh_id AND sph_iph_id = p_iph_id;

        RETURN l_count;
    END;

    /*-----------------------------------------------------------------*/
    FUNCTION f_getcountbysstid (p_sst_id IN sampleheader.sph_sst_id%TYPE)
        RETURN NUMBER
    /*------------------------------------------------------------------*/
    IS
        l_count   NUMBER;
    BEGIN
        SELECT COUNT (*)
          INTO l_count
          FROM sampleheader
         WHERE sph_sst_id = p_sst_id;

        RETURN l_count;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_testdelete
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        p_deleteprotocolentry (118);
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_deleteheadergrid (p_sph_id   IN sampleheader.sph_id%TYPE,
                                  p_ptv_id   IN sampleheader.sph_ptv_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        pkg_sampleheaderitem.p_deleteby_ptv_id (p_sph_id, p_ptv_id);
        pkg_sampleheaderfile.p_deleteby_ptv_id (p_sph_id, p_ptv_id);
        pkg_sampledocument.p_deleteby_ptv_id (p_sph_id, p_ptv_id);
        pkg_sampleprotocolgrid.p_deleteby_sph_id (p_sph_id);
        NULL;
    END;

    PROCEDURE p_deleteheadergrnd (p_sph_id   IN sampleheader.sph_id%TYPE,
                                  p_ptv_id   IN sampleheader.sph_ptv_id%TYPE)
    /*----------------------------------------------------------------*/
    IS
    BEGIN
        pkg_sampleheaderitem.p_deleteby_ptv_id (p_sph_id, p_ptv_id);
        pkg_sampleheaderfile.p_deleteby_ptv_id (p_sph_id, p_ptv_id);
        pkg_sampledocument.p_deleteby_ptv_id (p_sph_id, p_ptv_id);
        pkg_sampleprotocolgrnd.p_deleteby_sph_id (p_sph_id);
        NULL;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_deleteheader (p_sph_id IN sampleheader.sph_id%TYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        pkg_indicehistory.p_deleteby_ihy_sph_id (p_sph_id);
        pkg_sampleloadcomment.p_deleteby_sph_id (p_sph_id);
        pkg_sampleheaderitem.p_deleteby_sph_id (p_sph_id);
        pkg_sampleheaderfile.p_deleteby_sph_id (p_sph_id);
        pkg_sampledocument.p_deleteby_sph_id (p_sph_id);
        pkg_sampleprotocollabo.p_deleteby_sph_id (p_sph_id);
        pkg_sampleprotocolgrid.p_deleteby_sph_id (p_sph_id);
        pkg_sampleprotocolgrnd.p_deleteby_sph_id (p_sph_id);
        -- Avant de supprimer l'enregistrement de sampleheader, il faut initialiser la colonne IPH_SPH_ID_PARENT
        pkg_importprotocolheader.p_clear_iph_sph_id_parent (p_sph_id);
        pkg_sampleheaderadmingroup.p_deleteby_sph_id (p_sph_id);
        pkg_sampleprotocolmass.p_deleteby_sph_id (p_sph_id);

        DELETE FROM sampleheader
              WHERE sph_id = p_sph_id;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_deleteprotocolentry (
        p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE)
    /*---------------------------------------------------------------*/
    IS
        l_recsampleheader   sampleheader%ROWTYPE;
    BEGIN
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);
        pkg_delete_protocol.p_deleteprotocolentry (
            p_sph_id,
            l_recsampleheader.sph_ptv_id);
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_deletealladdprotofrommass (
        p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE,
        p_ptv_id   IN sampleheader.sph_ptv_id%TYPE)
    /*---------------------------------------------------------------*/
    IS
        l_recprotocolversion             protocolversion%ROWTYPE;
        l_recprotocolversionadditional   protocolversion%ROWTYPE;
        l_reccodevalue                   codevalue%ROWTYPE;
        l_reccodevalueadditional         codevalue%ROWTYPE;
        l_recsampleheader                sampleheader%ROWTYPE;
        l_recimportmassdataheader        importmassdataheader%ROWTYPE;
        l_recsampleheaderfile            sampleheaderfile%ROWTYPE;
        l_recimportprotocolheader        importprotocolheader%ROWTYPE;

        CURSOR l_listadditionalfile (
            p_sph_id1   sampleheaderfile.shf_sph_id%TYPE)
        IS
            SELECT *
              FROM sampleheaderfile
             WHERE shf_sph_id = p_sph_id1;

        l_recistadditionalfile           l_listadditionalfile%ROWTYPE;
    BEGIN
        l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);
        l_reccodevalue :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);

        IF l_reccodevalue.cvl_code != pkg_codevalue.cst_protocoltype_mass
        THEN
            RETURN;
        END IF;

        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);

        OPEN l_listadditionalfile (p_sph_id);

        LOOP
            FETCH l_listadditionalfile INTO l_recistadditionalfile;


            EXIT WHEN l_listadditionalfile%NOTFOUND;
            l_recprotocolversionadditional :=
                pkg_protocolversion.f_getrecord (
                    l_recistadditionalfile.shf_ptv_id);
            l_reccodevalueadditional :=
                pkg_codevalue.f_getrecord (
                    l_recprotocolversionadditional.ptv_cvl_id_protocoltype);

            IF l_reccodevalueadditional.cvl_code =
               pkg_codevalue.cst_protocoltype_ground
            THEN
                p_deleteheadergrnd (p_sph_id,
                                    l_recistadditionalfile.shf_ptv_id);
            ELSIF l_reccodevalueadditional.cvl_code =
                  pkg_codevalue.cst_protocoltype_grdeval
            THEN
                p_deleteheadergrid (p_sph_id,
                                    l_recistadditionalfile.shf_ptv_id);
            END IF;
        END LOOP;

        CLOSE l_listadditionalfile;
    END;

    /*----------------------------------------------------------------*/
    PROCEDURE p_deleteprotocolentry (
        p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE,
        p_ptv_id   IN sampleheader.sph_ptv_id%TYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        pkg_delete_protocol.p_deleteprotocolentry (p_sph_id, p_ptv_id);
    END;


    /*----------------------------------------------------------------*/
    PROCEDURE p_deleteprotocolentryold (
        p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE,
        p_ptv_id   IN sampleheader.sph_ptv_id%TYPE)
    /*---------------------------------------------------------------*/
    IS
        l_recprotocolversion        protocolversion%ROWTYPE;
        l_reccodevalue              codevalue%ROWTYPE;
        l_recsampleheader           sampleheader%ROWTYPE;
        l_recimportmassdataheader   importmassdataheader%ROWTYPE;
    BEGIN
        l_recprotocolversion := pkg_protocolversion.f_getrecord (p_ptv_id);
        l_reccodevalue :=
            pkg_codevalue.f_getrecord (
                l_recprotocolversion.ptv_cvl_id_protocoltype);
        l_recsampleheader := pkg_sampleheader.f_getrecord (p_sph_id);

        IF l_reccodevalue.cvl_code =
           pkg_codevalue.cst_protocoltype_laboratory
        THEN
            -- Type de protocol laboratoire
            p_deleteheader (p_sph_id);
            pkg_importprotocolheader.p_deletelabo (
                l_recsampleheader.sph_iph_id);
            -- Si il n'y a plus d'observation lié à la station on la détruit
            pkg_samplestation.p_deleteconditional (
                l_recsampleheader.sph_sst_id);
        ELSIF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_ground
        THEN
            p_deleteheadergrnd (p_sph_id, p_ptv_id);
            pkg_importprotocolheader.p_deletegrnd (
                l_recsampleheader.sph_iph_id);
        ELSIF l_reccodevalue.cvl_code =
              pkg_codevalue.cst_protocoltype_grdeval
        THEN
            p_deleteheadergrid (p_sph_id, p_ptv_id);
            pkg_importprotocolheader.p_deletegrid (
                l_recsampleheader.sph_iph_id);
        ELSIF l_reccodevalue.cvl_code = pkg_codevalue.cst_protocoltype_mass
        THEN
            p_deletealladdprotofrommass (p_sph_id, p_ptv_id);
            l_recimportmassdataheader :=
                pkg_importmassdataheader.f_getrecord (
                    l_recsampleheader.sph_imh_id);
            p_deleteheader (p_sph_id);
            pkg_importmassdataheader.p_delete (l_recsampleheader.sph_imh_id); -- Détruit aussi les détails et le log
            pkg_importmassstation.p_deleteconditionnal (
                l_recimportmassdataheader.imh_ims_id);
            /*
                 pkg_importprotocolheader.p_deleteconditionnal (
                    l_recsampleheader.sph_iph_id);
            */
            pkg_importmassstation.p_deletebyimh_id (
                l_recsampleheader.sph_imh_id);
            pkg_importmassmappingheader.p_deletebyiph_idconditionnal (
                l_recsampleheader.sph_iph_id);
            pkg_sampleheadermassfile.p_deleteconditional (
                l_recsampleheader.sph_smf_id); -- Détruit le fichier uniquement si aucune entrée dans le fichier HEADER n'est défine
            -- Si il n'y a plus d'observation lié à la station on la détruit
            pkg_samplestation.p_deleteconditional (
                l_recsampleheader.sph_sst_id);
            pkg_importprotocolheader.p_deleteallchildren (
                l_recsampleheader.sph_iph_id);
            pkg_importprotocollog.p_clearconditionnaly (
                l_recsampleheader.sph_iph_id); -- Supprime le log si plus aucun élelement n'est référencé
            pkg_importprotocolheader.p_deleteconditionnal (
                l_recsampleheader.sph_iph_id);
        END IF;
    END;



    /*---------------------------------------------------------------*/
    FUNCTION f_returnlastrecordbysstid (
        p_sst_id   IN samplestation.sst_id%TYPE)
        RETURN sampleheader%ROWTYPE
    /*----------------------------------------------------------------*/
    IS
        l_recsampleheader   sampleheader%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_recsampleheader
          FROM sampleheader
         WHERE     sph_sst_id = p_sst_id
               AND sph_credate = (SELECT MAX (sph_credate)
                                    FROM sampleheader
                                   WHERE sph_sst_id = p_sst_id);

        RETURN l_recsampleheader;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_test1
    /*--------------------------------------------------------------*/
    IS
        l_importmassdataheader   importmassdataheader%ROWTYPE;
        l_sampleheader           sampleheader%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_importmassdataheader
          FROM importmassdataheader
         WHERE imh_id = 114854;

        l_sampleheader :=
            f_findheaderbyimportmassheader (l_importmassdataheader);
        DBMS_OUTPUT.put_line ('SPH_ID=' || TO_CHAR (l_sampleheader.sph_id));
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_findheaderbyimportmassheader (
        p_importmassdataheader   IN importmassdataheader%ROWTYPE)
        RETURN sampleheader%ROWTYPE
    /*---------------------------------------------------------------*/
    IS
        /* Recherche l'existence de l'entête par les données d'importation.
            Une entête existe déjà si la coordonnées X,Y, (Z) et la date d'observation existe.
            Les autres données (nom de la rivière, localité, lieu-dit ne sont pas pris en compte
            */

        l_sampleheader   sampleheader%ROWTYPE;
        l_sdogeometry    MDSYS.sdo_geometry;
    BEGIN
        IF NOT p_importmassdataheader.imh_elevation IS NULL
        THEN
            l_sdogeometry :=
                pkg_sdoutil.f_buildsdo_geometry (
                    pkg_datatype.f_validatedouble (
                        p_importmassdataheader.imh_startpoint_x),
                    pkg_datatype.f_validatedouble (
                        p_importmassdataheader.imh_startpoint_y),
                    pkg_datatype.f_validatedouble (
                        p_importmassdataheader.imh_elevation));
        ELSE
            l_sdogeometry :=
                pkg_sdoutil.f_buildsdo_geometry (
                    pkg_datatype.f_validatedouble (
                        p_importmassdataheader.imh_startpoint_x),
                    pkg_datatype.f_validatedouble (
                        p_importmassdataheader.imh_startpoint_y));
        END IF;

        SELECT sampleheader.*
          INTO l_sampleheader
          FROM sampleheader INNER JOIN samplestation ON sph_sst_id = sst_id
         WHERE     pkg_sdoutil.f_computedistance2d (l_sdogeometry,
                                                    sst_coordinates) <=
                   pkg_codevalue.f_get_midatparam_startptinfo
               AND NVL (sph_observationday, -1) =
                   NVL (p_importmassdataheader.imh_day, -1)
               AND NVL (sph_observationmonth, -1) =
                   NVL (p_importmassdataheader.imh_month, -1)
               AND sph_observationyear = p_importmassdataheader.imh_year
               AND pkg_sdoutil.f_computedistance2d (l_sdogeometry,
                                                    sst_coordinates) =
                   (SELECT MIN (
                               pkg_sdoutil.f_computedistance2d (
                                   l_sdogeometry,
                                   sst_coordinates))
                      FROM sampleheader
                           INNER JOIN samplestation ON sph_sst_id = sst_id
                     WHERE     pkg_sdoutil.f_computedistance2d (
                                   l_sdogeometry,
                                   sst_coordinates) <=
                               pkg_codevalue.f_get_midatparam_startptinfo
                           AND NVL (sph_observationday, -1) =
                               NVL (p_importmassdataheader.imh_day, -1)
                           AND NVL (sph_observationmonth, -1) =
                               NVL (p_importmassdataheader.imh_month, -1)
                           AND sph_observationyear =
                               p_importmassdataheader.imh_year)
               AND ROWNUM < 2;

        RETURN l_sampleheader;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_findheaderbyimportdata (
        p_importprotocolheader   IN importprotocolheader%ROWTYPE)
        RETURN sampleheader%ROWTYPE
    /*---------------------------------------------------------------*/
    IS
        /* Recherche l'existence de l'entête par les données d'importation.
            Une entête existe déjà si la coordonnées X,Y,Z et la date d'observation existe.
            Les autres données (nom de la rivière, localité, lieu-dit ne sont pas pris en compte
            */

        l_sampleheader   sampleheader%ROWTYPE;
        l_sdogeometry    MDSYS.sdo_geometry;
    BEGIN
        l_sdogeometry :=
            pkg_sdoutil.f_buildsdo_geometry (
                pkg_datatype.f_validatedouble (
                    p_importprotocolheader.iph_startpoint_x),
                pkg_datatype.f_validatedouble (
                    p_importprotocolheader.iph_startpoint_y),
                pkg_datatype.f_validatedouble (
                    p_importprotocolheader.iph_elevation));

        SELECT sampleheader.*
          INTO l_sampleheader
          FROM sampleheader INNER JOIN samplestation ON sph_sst_id = sst_id
         WHERE     pkg_sdoutil.f_computedistance2d (l_sdogeometry,
                                                    sst_coordinates) <=
                   pkg_codevalue.f_get_midatparam_startptinfo
               AND TRUNC (sph_observationdate) =
                   TRUNC (
                       TO_DATE (p_importprotocolheader.iph_observationdate,
                                'DD/MM/YYYY'))
               AND pkg_sdoutil.f_computedistance2d (l_sdogeometry,
                                                    sst_coordinates) =
                   (SELECT MIN (
                               pkg_sdoutil.f_computedistance2d (
                                   l_sdogeometry,
                                   sst_coordinates))
                      FROM sampleheader
                           INNER JOIN samplestation ON sph_sst_id = sst_id
                     WHERE     pkg_sdoutil.f_computedistance2d (
                                   l_sdogeometry,
                                   sst_coordinates) <=
                               pkg_codevalue.f_get_midatparam_startptinfo
                           AND TRUNC (sph_observationdate) =
                               TRUNC (
                                   TO_DATE (
                                       p_importprotocolheader.iph_observationdate,
                                       'DD/MM/YYYY')))
               AND ROWNUM < 2;

        RETURN l_sampleheader;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*---------------------------------------------------------------*/
    FUNCTION f_getrecordbyoidanddate (
        p_oid                IN samplestation.sst_oid%TYPE,
        p_ins_id_principal   IN sampleheader.sph_ins_id_principal%TYPE,
        p_date               IN sampleheader.sph_observationdate%TYPE,
        p_protocoltype       IN sampleheader.sph_ptv_id%TYPE)
        RETURN sampleheader%ROWTYPE
    /*----------------------------------------------------------------*/
    IS
        l_recsampleheader   sampleheader%ROWTYPE;
    BEGIN
        SELECT sampleheader.*
          INTO l_recsampleheader
          FROM sampleheader INNER JOIN samplestation ON sph_sst_id = sst_id
         WHERE     TRUNC (sph_observationdate) = TRUNC (p_date)
               AND sst_oid = p_oid
               AND sph_ptv_id = p_protocoltype
               AND sph_ins_id_principal = p_ins_id_principal;

        RETURN l_recsampleheader;
    EXCEPTION
        WHEN OTHERS
        THEN
            RETURN NULL;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_test (p_iph_id IN importprotocolheader.iph_id%TYPE)
    /*--------------------------------------------------------------*/
    IS
        l_importprotocolheader   importprotocolheader%ROWTYPE;
        l_sampleheader           sampleheader%ROWTYPE;
    BEGIN
        l_importprotocolheader :=
            pkg_importprotocolheader.f_getrecord (p_iph_id);
        l_sampleheader := f_findheaderbyimportdata (l_importprotocolheader);

        IF l_sampleheader.sph_id IS NULL
        THEN
            DBMS_OUTPUT.put_line ('NOT FOUND');
        ELSE
            DBMS_OUTPUT.put_line (
                'l_sampleheader.sph_id=' || l_sampleheader.sph_id);
        END IF;
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_getrecord (p_sph_id IN sampleheader.sph_id%TYPE)
        RETURN sampleheader%ROWTYPE
    /*--------------------------------------------------------------*/
    IS
        l_record   sampleheader%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_record
          FROM sampleheader
         WHERE sph_id = p_sph_id;

        RETURN l_record;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*--------------------------------------------------------------*/
    FUNCTION f_getrecordbyiphid (p_iph_id IN sampleheader.sph_iph_id%TYPE)
        RETURN sampleheader%ROWTYPE
    /*--------------------------------------------------------------*/
    IS
        l_record   sampleheader%ROWTYPE;
    BEGIN
        SELECT *
          INTO l_record
          FROM sampleheader
         WHERE sph_iph_id = p_iph_id;

        RETURN l_record;
    EXCEPTION
        WHEN NO_DATA_FOUND
        THEN
            RETURN NULL;
    END;

    /*---------------------------------------------------------------*/
    PROCEDURE p_check (p_command   IN     VARCHAR2,
                       p_oldrec    IN     sampleheader%ROWTYPE,
                       p_newrec    IN OUT sampleheader%ROWTYPE)
    /*---------------------------------------------------------------*/
    IS
    BEGIN
        NULL;
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_tr_bif_sampleheader (p_newrec IN OUT sampleheader%ROWTYPE)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        p_newrec.sph_credate := SYSDATE;
        p_newrec.sph_creuser := USER;

        IF p_newrec.sph_id IS NULL
        THEN
            p_newrec.sph_id := seq_sampleheader.NEXTVAL;
        END IF;

        p_check (pkg_constante.cst_dml_command_insert, NULL, p_newrec);
    END;

    /*--------------------------------------------------------------*/
    PROCEDURE p_tr_buf_sampleheader (p_oldrec   IN     sampleheader%ROWTYPE,
                                     p_newrec   IN OUT sampleheader%ROWTYPE)
    /*--------------------------------------------------------------*/
    IS
    BEGIN
        p_newrec.sph_moddate := SYSDATE;
        p_newrec.sph_moduser := USER;
        p_check (pkg_constante.cst_dml_command_update, p_oldrec, p_newrec);
    END;
END pkg_sampleheader;
/

