create PACKAGE BODY       pkg_sampleheaderw
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEHEADERW
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0       25.07.2013  F.Burri           1. Created this package body.
   ******************************************************************************/

   cst_packageversion   VARCHAR2 (30) := 'Version 1.0, juillet 2013';

   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*----------------------------------------------------------------*/
   PROCEDURE p_deleteprotocolentry (
      p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE,
      p_ptv_id   IN sampleheader.sph_ptv_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      pkg_sampleheader.p_deleteprotocolentry (p_sph_id, p_ptv_id);
   END;
   /*----------------------------------------------------------------*/
   PROCEDURE p_deleteprotocolentry (
      p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE)
   /*---------------------------------------------------------------*/
   IS
   BEGIN
      pkg_sampleheader.p_deleteprotocolentry( p_sph_id);
   END;
END pkg_sampleheaderw;
/

