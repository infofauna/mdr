create trigger TR_BIF_IMPORTPROTOCOLLABO
    before insert
    on IMPORTPROTOCOLLABO
    for each row
DECLARE
BEGIN
   IF :new.IPL_id IS NULL
   THEN
      :new.IPL_id := seq_IMPORTPROTOCOLLABO.NEXTVAL;
   END IF; 

   :new.IPL_credate := SYSDATE;
   :new.IPL_creuser := USER;
END tr_bif_IMPORTPROTOCOLLABO;

/

