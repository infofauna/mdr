create PACKAGE       pkg_validate_old
AS
   /******************************************************************************
      NAME:       PKG_VALIDATE
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
      1.1        20.07.2017      burrif       2. Ajout des projets
      1.2        21.01.2019      burrif       3. Changement des droits
      1.3        20.01.2020      burrif       4. Mise à jour des champs statistique IBCH
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_test1;

   PROCEDURE p_test2;

   PROCEDURE p_test3;

   PROCEDURE p_validateconfirm (
      p_iph_id   IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id   IN     language.lan_id%TYPE,
      p_usr_id   IN     sampleheader.sph_usr_id_create%TYPE,
      p_sph_id      OUT sampleheader.sph_id%TYPE);

   PROCEDURE p_validateconfirm (
      p_iph_id             IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id             IN     language.lan_id%TYPE,
      p_usr_id             IN     sampleheader.sph_usr_id_create%TYPE,
      p_visibilitystatus   IN     sampleheader.sph_visibilitystatus%TYPE,
      p_publicstatus       IN     VARCHAR2,
      p_sph_id                OUT sampleheader.sph_id%TYPE);

   PROCEDURE p_validateprocess (
      p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id        IN     language.lan_id%TYPE,
      p_usr_id        IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_external_id   IN     importprotocolheader.iph_external_id%TYPE,
      p_cursorerror      OUT pkg_importprotocollog.t_cursor,
      p_errorlevel       OUT VARCHAR2);

   PROCEDURE p_validateprocess_v2 (
      p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id        IN     language.lan_id%TYPE,
      p_usr_id        IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_pid_id        IN     importprotocolheader.iph_pid_id%TYPE,
      p_cursorerror      OUT pkg_importprotocollog.t_cursor,
      p_errorlevel       OUT VARCHAR2);

   PROCEDURE p_validateprocess (
      p_iph_id        IN     importprotocollog.ipo_iph_id%TYPE,
      p_lan_id        IN     language.lan_id%TYPE,
      p_usr_id        IN     importprotocolheader.iph_usr_id_modify%TYPE,
      p_cursorerror      OUT pkg_importprotocollog.t_cursor,
      p_errorlevel       OUT VARCHAR2);

   PROCEDURE p_initprocessingstatus (
      p_external_id   IN importprotocolheader.iph_external_id%TYPE);

   PROCEDURE p_initprocessingstatus (
      p_external_id   IN     importprotocolheader.iph_external_id%TYPE,
      p_pid_id           OUT processingstatus.pid_id%TYPE);

   PROCEDURE p_initprocessingstatus_v2 (
      p_pid_id   OUT processingstatus.pid_id%TYPE);
END pkg_validate_old;
/

