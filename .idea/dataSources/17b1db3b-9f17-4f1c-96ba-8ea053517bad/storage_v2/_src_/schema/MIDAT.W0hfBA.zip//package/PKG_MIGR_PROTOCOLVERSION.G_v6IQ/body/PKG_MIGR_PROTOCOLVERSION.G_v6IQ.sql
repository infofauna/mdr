create PACKAGE BODY       pkg_migr_protocolversion
AS
   /******************************************************************************
      NAME:       PKG_MIGR_PROTOCOLVERSION
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        25.09.2013      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30)
                                    := 'Version 1.0, septembre  2013' ;


   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;

   /*------------------------------------------------------------------*/
   PROCEDURE p_deleteall
   /*------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM protocolversion;
   END;

   /*---------------------------------------------------------------*/
   PROCEDURE p_insertdatatest
   /*---------------------------------------------------------------*/
   IS
      l_reccodevalue   codevalue%ROWTYPE;
   BEGIN
   /*
      p_deleteall;
      l_reccodevalue :=
         pkg_codevalue.f_getfromcode (
            pkg_codevalue.cst_protocoltype_laboratory,
            pkg_codereference.cst_crf_midatproto);

      INSERT INTO protocolversion (ptv_id,
                                   ptv_cvl_id_protocoltype,
                                   ptv_defaultflag,
                                   ptv_text,
                                   ptv_startdate)
           VALUES (1,
                   l_reccodevalue.cvl_id,
                   pkg_constante.cst_yes,
                   'Version 2.0, 25 septembre 2013',
                   SYSDATE);

      l_reccodevalue :=
         pkg_codevalue.f_getfromcode (pkg_codevalue.cst_protocoltype_grdeval,
                                      pkg_codereference.cst_crf_midatproto);

      INSERT INTO protocolversion (ptv_id,
                                   ptv_cvl_id_protocoltype,
                                   ptv_defaultflag,
                                   ptv_text,
                                   ptv_startdate)
           VALUES (2,
                   l_reccodevalue.cvl_id,
                   pkg_constante.cst_yes,
                   'Version 1.0, 25 septembre 2013',
                   SYSDATE);

      l_reccodevalue :=
         pkg_codevalue.f_getfromcode (pkg_codevalue.cst_protocoltype_ground,
                                      pkg_codereference.cst_crf_midatproto);

      INSERT INTO protocolversion (ptv_id,
                                   ptv_cvl_id_protocoltype,
                                   ptv_defaultflag,
                                   ptv_text,
                                   ptv_startdate)
           VALUES (3,
                   l_reccodevalue.cvl_id,
                   pkg_constante.cst_yes,
                   'Version 1.0, 25 septembre 2013',
                   SYSDATE);
        
     l_reccodevalue :=
         pkg_codevalue.f_getfromcode (pkg_codevalue.cst_protocoltype_mass,
                                      pkg_codereference.cst_crf_midatproto);

      INSERT INTO protocolversion (ptv_id,
                                   ptv_cvl_id_protocoltype,
                                   ptv_defaultflag,
                                   ptv_text,
                                   ptv_startdate)
           VALUES (4,
                   l_reccodevalue.cvl_id,
                   pkg_constante.cst_yes,
                   'Version 1.0, 25 septembre 2013',
                   SYSDATE);              
                              */ 
                                 
                              l_reccodevalue :=
         pkg_codevalue.f_getfromcode (     pkg_codevalue.cst_protocoltype_laboratory,
                                      pkg_codereference.cst_crf_midatproto);

      INSERT INTO protocolversion (ptv_id,
                                   ptv_cvl_id_protocoltype,
                                   ptv_defaultflag,
                                   ptv_text,
                                   ptv_startdate)
           VALUES (4,
                   l_reccodevalue.cvl_id,
                   pkg_constante.cst_yes,
                   'Version 1.0, ',
                   SYSDATE);     
                   
   END;
END pkg_migr_protocolversion;
/

