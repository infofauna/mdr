create PACKAGE BODY       pkg_wk_logchangemaster
AS
   /******************************************************************************
      NAME:       PKG_WK_LOGCHANGEMASTER
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        21.03.2016      burrif       1. Created this package.
   ******************************************************************************/
   cst_packageversion   CONSTANT VARCHAR2 (30) := 'Version 1.0, mars 2016';



   /*--------------------------------------------------------------*/
   FUNCTION f_getversion
      /*--------------------------------------------------------------*/
      RETURN VARCHAR2
   IS
   BEGIN
      RETURN cst_packageversion;
   END;


   PROCEDURE p_write (
      p_sph_id              IN     wk_logchangemaster.wkm_sph_id%TYPE,
      p_locality            IN     wk_logchangemaster.wkm_locality%TYPE,
      p_watercourse         IN     wk_logchangemaster.wkm_watercourse%TYPE,
      p_currentmkivalue     IN     wk_logchangemaster.wkm_currentmkivalue%TYPE,
      p_currentibchvalue    IN     wk_logchangemaster.wkm_currentibchvalue%TYPE,
      p_currentspearvalue   IN     wk_logchangemaster.wkm_currentspearvalue%TYPE,
      p_newmkivalue         IN     wk_logchangemaster.wkm_newmkivalue%TYPE,
      p_newibchvalue        IN     wk_logchangemaster.wkm_newibchvalue%TYPE,
      p_newspearvalue       IN     wk_logchangemaster.wkm_newspearvalue%TYPE,
      p_currentmkiclass     IN     wk_logchangemaster.wkm_currentmkiclass%TYPE,
      p_currentibchclass    IN     wk_logchangemaster.wkm_currentibchclass%TYPE,
      p_currentspearclass   IN     wk_logchangemaster.wkm_currentspearclass%TYPE,
      p_newmkiclass         IN     wk_logchangemaster.wkm_newmkiclass%TYPE,
      p_newibchclass        IN     wk_logchangemaster.wkm_newibchclass%TYPE,
      p_newspearclass       IN     wk_logchangemaster.wkm_newspearclass%TYPE,
      p_wkm_id                 OUT wk_logchangemaster.wkm_id%TYPE)
   IS
   BEGIN
      p_wkm_id := seq_wk_logchangemaster.NEXTVAL;

      INSERT INTO wk_logchangemaster (wkm_id,
                                      wkm_sph_id,
                                      wkm_locality,
                                      wkm_watercourse,
                                      wkm_currentmkivalue,
                                      wkm_currentibchvalue,
                                      wkm_currentspearvalue,
                                      wkm_newmkivalue,
                                      wkm_newibchvalue,
                                      wkm_newspearvalue,
                                      wkm_currentmkiclass,
                                      wkm_currentibchclass,
                                      wkm_currentspearclass,
                                      wkm_newmkiclass,
                                      wkm_newibchclass,
                                      wkm_newspearclass)
           VALUES (p_wkm_id,
                   p_sph_id,
                   p_locality,
                   p_watercourse,
                   p_currentmkivalue,
                   p_currentibchvalue,
                   p_currentspearvalue,
                   p_newmkivalue,
                   p_newibchvalue,
                   p_newspearvalue,
                   p_currentmkiclass,
                   p_currentibchclass,
                   p_currentspearclass,
                   p_newmkiclass,
                   p_newibchclass,
                   p_newspearclass);
   END;

   /*------------------------------------------------------------------------------------------*/
   PROCEDURE p_deleteall
   /*------------------------------------------------------------------------------------------*/
   IS
   BEGIN
      DELETE FROM wk_logchangedetail;

      DELETE FROM wk_logchangemaster;
   END;

   /*-------------------------------------------------------------------------------------------*/
   PROCEDURE p_updateindexes (
      p_wkm_id          IN wk_logchangemaster.wkm_id%TYPE,
      p_newmkivalue     IN wk_logchangemaster.wkm_newmkivalue%TYPE,
      p_newibchvalue    IN wk_logchangemaster.wkm_newibchvalue%TYPE,
      p_newspearvalue   IN wk_logchangemaster.wkm_newspearvalue%TYPE)
   /*-------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE wk_logchangemaster
         SET wkm_newmkivalue = p_newmkivalue,
             wkm_newibchvalue = p_newibchvalue,
             wkm_newspearvalue = p_newspearvalue
       WHERE wkm_id = p_wkm_id;
   END;

   /*-------------------------------------------------------------------------------------------*/
   PROCEDURE p_updatecurrentclass (
      p_wkm_id              IN wk_logchangemaster.wkm_id%TYPE,
      p_currentmkiclass     IN wk_logchangemaster.wkm_currentmkiclass%TYPE,
      p_currentibchclass    IN wk_logchangemaster.wkm_currentibchclass%TYPE,
      p_currentspearclass   IN wk_logchangemaster.wkm_currentspearclass%TYPE)
   /*-------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE wk_logchangemaster
         SET wkm_currentmkiclass = p_currentmkiclass,
             wkm_currentibchclass = p_currentibchclass,
             wkm_currentspearclass = p_currentspearclass
       WHERE wkm_id = p_wkm_id;
   END;
   
   /*-------------------------------------------------------------------------------------------*/
   PROCEDURE p_updatenewclass (
      p_wkm_id              IN wk_logchangemaster.wkm_id%TYPE,
      p_newmkiclass     IN wk_logchangemaster.wkm_newmkiclass%TYPE,
      p_newibchclass    IN wk_logchangemaster.wkm_newibchclass%TYPE,
      p_newspearclass   IN wk_logchangemaster.wkm_newspearclass%TYPE)
   /*-------------------------------------------------------------------------------*/
   IS
   BEGIN
      UPDATE wk_logchangemaster
         SET wkm_newmkiclass = p_newmkiclass,
             wkm_newibchclass = p_newibchclass,
             wkm_newspearclass = p_newspearclass
       WHERE wkm_id = p_wkm_id;
   END;
END pkg_wk_logchangemaster;
/

