create PACKAGE BODY       pkg_migr_ibch2019_ihy
AS
    /******************************************************************************
       NAME:       pkg_migr_ibch2019_ihy
       PURPOSE:

       REVISIONS:
       Ver        Date        Author           Description
       ---------  ----------  ---------------  ------------------------------------
       1.0       1.07.2020  F.Burri           1. Created this package body.
    ******************************************************************************/


    /*--------------------------------------------------------------*/
    FUNCTION f_getversion
        /*--------------------------------------------------------------*/
        RETURN VARCHAR2
    IS
    BEGIN
        RETURN cst_packageversion;
    END;



    /*----------------------------------------------------------*/
    PROCEDURE p_create_table
    /*----------------------------------------------------------*/
    IS
        l_sql   VARCHAR2 (4096);
    BEGIN
        IF pkg_migr_ibch2019_util.f_checktableexist ('INDICEHISTORY') > 0
        THEN
            l_sql := 'DROP TABLE  MIDAT.INDICEHISTORY';

            EXECUTE IMMEDIATE l_sql;
        END IF;

        l_sql :=
            '  create table indicehistory (IHY_ID                         NUMBER,
  IHY_STATUS                     CHAR(1 BYTE)   DEFAULT ''A'',
  IHY_SPH_ID                     NUMBER,
  IHY_IVR_ID_IBCH                NUMBER,
  IHY_IVR_ID_SPEAR               NUMBER,
  IHY_SEQUENCE                   NUMBER,
  IHY_TAXONINDICATEUR            VARCHAR2(1024 CHAR),
  IHY_IBCHROBUST                 NUMBER,
  IHY_INDEXVALUEIBCH             NUMBER,
  IHY_CLASSEVARIETE              NUMBER,
  IHY_CLASSEVARIETE_CORR         NUMBER,
  IHY_CLASSEVARIETEROBUST        NUMBER,
  IHY_CLASSEVARIETEROBUST_CORR   NUMBER,
  IHY_CLASSEVARIETE_FINAL        NUMBER,
  IHY_CLASSEVARIETEROBUST_FINAL  NUMBER,
  IHY_GIMAX                      NUMBER,
  IHY_GIMAXROBUST                NUMBER,
  IHY_GI_FINAL                   NUMBER,
  IHY_GIROBUST_FINAL             NUMBER,
  IHY_SUMFAMILY                  NUMBER,
  IHY_SUMFAMILYCORRECTED         NUMBER,
  IHY_SUMFAMILYROBUST            NUMBER,
  IHY_SUMFAMROBUSTCORRECTED      NUMBER,
  IHY_EPHEMEROPTERACOUNTER       NUMBER,
  IHY_PLECOPTERACOUNTER          NUMBER,
  IHY_TRICOPTERACOUNTER          NUMBER,
  IHY_SPEARVALUE                 NUMBER,
   IHY_IVR_ID_MAKROINDEX          NUMBER,
  IHY_MAKROINDEX                 NUMBER,
  IHY_AUTREOZ_1                  VARCHAR2(120 BYTE),
  IHY_AUTREOZ_2                  VARCHAR2(120 BYTE),
  IHY_SOMMEEPT                   NUMBER,
  IHY_SOMMENEOZ                  NUMBER,
  IHY_SOMMEABON                  NUMBER,
  IHY_VALEURVT                   NUMBER,
  ihy_valeurgi                   NUMBER,
  IHY_VALEURGIMAX                NUMBER,
  IHY_IBCHQ                      NUMBER,
  IHY_VC                         NUMBER,
  IHY_SOMMETXOBS                 NUMBER,
  IHY_SOMMETXCOR                 NUMBER,
  IHY_CREDATE                    DATE,
  IHY_CREUSER                    VARCHAR2(30 BYTE),
  IHY_MODDATE                    DATE,
  IHY_MODUSER                    VARCHAR2(30 BYTE),
  IHY_USR_CREDATE                DATE,
  IHY_USR_ID_CREATE              NUMBER,
  IHY_USR_MODDATE                DATE,
  IHY_USR_ID_MODIFY              NUMBER
 
)
TABLESPACE MIDAT_DATA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING';
        pkg_debug.p_write ('PKG_MIGR_IBCH2019_IHY.P_CREATE_TABLE',
                           'L_SQL:' || l_sql);

        EXECUTE IMMEDIATE l_sql;

        l_sql := '
CREATE INDEX MIDAT.pk_indicehistory ON MIDAT.INDICEHISTORY
(IHY_ID)
LOGGING
TABLESPACE MIDAT_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL';

        EXECUTE IMMEDIATE l_sql;

        l_sql := '
CREATE INDEX MIDAT.IDX_IHY_IVR_ID_IBCH ON MIDAT.INDICEHISTORY
(IHY_IVR_ID_IBCH)
LOGGING
TABLESPACE MIDAT_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL';

        EXECUTE IMMEDIATE l_sql;

        l_sql :=
            ' CREATE INDEX MIDAT.IDX_IHY_IVR_ID_SPEAR ON MIDAT.INDICEHISTORY
(IHY_IVR_ID_SPEAR)
LOGGING
TABLESPACE MIDAT_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL';

        EXECUTE IMMEDIATE l_sql;

        l_sql := 'CREATE INDEX MIDAT.IDX_IHY_SPH_ID ON MIDAT.INDICEHISTORY
(IHY_SPH_ID)
LOGGING
TABLESPACE MIDAT_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL';

        EXECUTE IMMEDIATE l_sql;

        l_sql := '
CREATE INDEX MIDAT.IDX_IHY_USR_ID_CREATE ON MIDAT.INDICEHISTORY
(IHY_USR_ID_CREATE)
LOGGING
TABLESPACE MIDAT_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL';

        EXECUTE IMMEDIATE l_sql;

        l_sql := '
CREATE INDEX MIDAT.IDX_IHY_USR_ID_MODIFY ON MIDAT.INDICEHISTORY
(IHY_USR_ID_MODIFY)
LOGGING
TABLESPACE MIDAT_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL';

        EXECUTE IMMEDIATE l_sql;



        l_sql := '
ALTER TABLE MIDAT.INDICEHISTORY ADD (
  CONSTRAINT PK_INDICEHYSTORY
  PRIMARY KEY
  (IHY_ID)
  USING INDEX MIDAT.PK_INDICEHiSTORY
  ENABLE VALIDATE
)';

        EXECUTE IMMEDIATE l_sql;

        l_sql := '
CREATE OR REPLACE TRIGGER MIDAT.TR_BIF_INDICEHISTORY

BEFORE INSERT
ON MIDAT.INDICEHISTORY
REFERENCING NEW AS New OLD AS Old
FOR EACH ROW
DECLARE
BEGIN
   IF :new.IHY_id IS NULL
   THEN
      :new.IHY_id := seq_INDICEHISTORY.NEXTVAL;
   END IF;

   :new.IHY_credate := SYSDATE;
   :new.IHY_creuser := USER;
END tr_bif_INDICEHISTORY;
';

        EXECUTE IMMEDIATE l_sql;


        l_sql := 'CREATE OR REPLACE TRIGGER MIDAT.TR_BUF_INDICEHISTORY

BEFORE UPDATE
ON MIDAT.INDICEHISTORY
REFERENCING NEW AS New OLD AS Old
FOR EACH ROW
DECLARE
BEGIN
 
   :new.IHY_moddate := SYSDATE;
   :new.IHY_moduser := USER;
END tr_buf_INDICEHISTORY;
';

        EXECUTE IMMEDIATE l_sql;



        l_sql := '
ALTER TABLE MIDAT.INDICEHISTORY ADD (
  CONSTRAINT FK_IHY_IVR_ID_SPEAR 
  FOREIGN KEY (IHY_IVR_ID_SPEAR) 
  REFERENCES MIDAT.INDICEVERSION (IVR_ID)
  ENABLE VALIDATE
,  CONSTRAINT FK_IHY_SPH_ID 
  FOREIGN KEY (IHY_SPH_ID) 
  REFERENCES MIDAT.SAMPLEHEADER (SPH_ID)
  ENABLE VALIDATE
,  CONSTRAINT FK_IHY_USR_ID_CREATE 
  FOREIGN KEY (IHY_USR_ID_CREATE) 
  REFERENCES APPMANAGER.ADMIN_USER (USR_ID)
  ENABLE VALIDATE
,  CONSTRAINT FK_IVR_ID_IBCH 
  FOREIGN KEY (IHY_IVR_ID_IBCH) 
  REFERENCES MIDAT.INDICEVERSION (IVR_ID)
  ENABLE VALIDATE
,  CONSTRAINT IHY_USR_ID_MODIFY 
  FOREIGN KEY (IHY_USR_ID_MODIFY) 
  REFERENCES APPMANAGER.ADMIN_USER (USR_ID)
  ENABLE VALIDATE)';

        EXECUTE IMMEDIATE l_sql;

        l_sql := 'ALTER TABLE MIDAT.INDICEHISTORY ADD (
  CONSTRAINT FK_IHY_IVR_ID_MAKROINDEX 
  FOREIGN KEY (IHY_IVR_ID_MAKROINDEX) 
  REFERENCES MIDAT.INDICEVERSION (IVR_ID)
  ENABLE VALIDATE)';

        EXECUTE IMMEDIATE l_sql;
    END;
END;
/

