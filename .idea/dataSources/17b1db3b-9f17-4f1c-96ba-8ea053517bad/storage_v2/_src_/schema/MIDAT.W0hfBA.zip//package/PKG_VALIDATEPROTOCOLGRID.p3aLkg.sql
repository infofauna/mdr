create PACKAGE       pkg_validateprotocolgrid
AS
   /******************************************************************************
      NAME:       PKG_VALIDATEPROTOCOLGRID
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        11.10.2013      burrif       1. Created this package.
   ******************************************************************************/


   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_validatedetail (
      p_importprotocolheader   IN importprotocolheader%ROWTYPE,
      p_usr_id                 IN importprotocolheader.iph_usr_id_modify%TYPE,
      p_returnstatus OUT NUMBER);
END pkg_validateprotocolgrid;
/

