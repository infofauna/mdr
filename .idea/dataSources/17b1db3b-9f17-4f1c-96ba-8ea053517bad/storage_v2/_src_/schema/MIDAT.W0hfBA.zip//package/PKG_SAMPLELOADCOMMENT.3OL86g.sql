create PACKAGE       pkg_sampleloadcomment
AS
   /******************************************************************************
      NAME:       PKG_SAMPLELOADCOMMENT
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.07.2017      burrif       1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_deleteby_sph_id (p_sph_id IN sampleloadcomment.slc_sph_id%TYPE);
END pkg_sampleloadcomment;
/

