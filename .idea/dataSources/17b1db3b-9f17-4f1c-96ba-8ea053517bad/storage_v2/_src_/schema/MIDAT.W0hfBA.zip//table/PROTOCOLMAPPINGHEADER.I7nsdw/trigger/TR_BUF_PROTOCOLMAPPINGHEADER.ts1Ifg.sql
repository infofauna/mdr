create trigger TR_BUF_PROTOCOLMAPPINGHEADER
    before update
    on PROTOCOLMAPPINGHEADER
    for each row
DECLARE
BEGIN
 
   :new.PMH_moddate := SYSDATE;
   :new.PMH_moduser := USER;
END tr_buf_PROTOCOLMAPPINGHEADER;

/

