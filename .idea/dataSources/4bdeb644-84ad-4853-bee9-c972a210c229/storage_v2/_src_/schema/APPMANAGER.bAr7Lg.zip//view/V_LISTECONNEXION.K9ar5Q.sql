create view V_LISTECONNEXION as
SELECT rownum id, t1."APPLICATION",t1."LOGIN",t1."LDAP",t1."LASTNAME",t1."FIRSTNAME",t1."ADDRESS",t1."LOCALITY",t1."CREATION_DATE",t1."FIRSTCONNECTION",t1."LASTCONNECTION",t1."CONNECTIONCOUNT" FROM (
      SELECT 
             apl_code
                 Application,
             usr_user_login
                 Login,
             usr_is_ldap_login
                 LDAP,
             per_lastname
                 Lastname,
             per_firstname
                 Firstname,
             per_addressline1
                 Address,
             per_zipcode || '-' || per_locality
                 LOCALITY,
             TO_CHAR (usr_credate, 'DD/MM/YYYY HH24:MI:SS')
                 CREATION_DATE,
             TO_CHAR (MIN (lgx_connectiondate), 'DD/MM/YYYY HH24:MI:SS')
                 firstconnection,
             TO_CHAR (MAX (lgx_connectiondate), 'DD/MM/YYYY HH24:MI:SS')
                 lastconnection,
             COUNT (*)
                 connectioncount
        FROM admin_user
             INNER JOIN admin_logconnection ON usr_id = lgx_usr_id
             INNER JOIN admin_application ON apl_id = lgx_apl_id
             LEFT OUTER JOIN infofauna.person ON per_id = usr_per_id
       WHERE usr_status = 'A'
    GROUP BY usr_user_login,
             usr_is_ldap_login,
             per_lastname,
             per_firstname,
             per_addressline1,
             per_zipcode || '-' || per_locality,
             usr_credate,
             apl_code) t1
    ORDER BY Login, Application
/

