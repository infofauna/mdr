create view V_MIDATFULLEXPORT_V2 as
SELECT sph1.sph_id
               "ID",
           cvl1.cvl_code
               "PROTOCOLTYPE",
           TO_CHAR (sph1.sph_observationdate, 'DD/MM/YYYY')
               "OBSERVATIONDATE",
           sst1.sst_oid
               "OID",
           sst2.sst_oid
               "OID_LINKED",
           (SELECT LISTAGG (sst3.sst_oid, ', ')
                       WITHIN GROUP (ORDER BY sst3.sst_oid)
              FROM samplestation sst3
             WHERE sst3.sst_sst_id = sst1.sst_id)
               "OID_PRINCIPAL",
           shm1.shm_item
               "WATERCOURSE",
           shm2.shm_item
               "LOCALITY",
           cvl4.cvl_code
               "CANTON",
           sst1.sst_coordinates.sdo_point.x
               "X",
           sst1.sst_coordinates.sdo_point.y
               "Y",
           sst1.sst_z
               "Z",
           sst1.sst_gewissnr
               "GEWISSNR",
           sph1.sph_indexvalueibch
               "IBCH_COMPUTED",
           sph1.sph_indexvalueibch_orig
               "IBCH_PROVIDED",
           lan1.lan_id,
           (SELECT cdn1.cdn_designation
              FROM codedesignation cdn1
                   INNER JOIN biologicalstate bls1
                       ON bls1.bls_cvl_id_biolstatetxt = cdn1.cdn_cvl_id
                   INNER JOIN codevalue cvl5
                       ON cvl5.cvl_id = bls1.bls_cvl_id_midatindice
                   INNER JOIN language lan2 ON lan2.lan_id = cdn1.cdn_lan_id
             WHERE     cvl5.cvl_code = pkg_codevalue.f_get_midatindice_ibch
                   AND lan2.lan_code = lan1.lan_code
                   AND sph1.sph_indexvalueibch BETWEEN bls1.bls_fromvalue
                                                   AND bls1.bls_tovalue
                   AND ROWNUM < 2)
               "IBCH_RANGE",
           NVL (
               (SELECT cdn1.cdn_designation
                  FROM codedesignation cdn1
                       INNER JOIN avaliabilitycalendar iac
                           ON cdn1.cdn_cvl_id = iac.iac_cvl_id_midatwindow
                       INNER JOIN codevalue cvl5
                           ON cvl5.cvl_id = iac.iac_cvl_id_midatindice
                       INNER JOIN language lan2
                           ON lan2.lan_id = cdn1.cdn_lan_id
                 WHERE     cvl5.cvl_code =
                           pkg_codevalue.f_get_midatindice_ibch
                       AND lan2.lan_code = lan1.lan_code
                       AND sph1.sph_observationdate BETWEEN TO_DATE (
                                                                   iac.iac_startday
                                                                || '/'
                                                                || iac.iac_startmonth
                                                                || '/'
                                                                || EXTRACT (
                                                                       YEAR FROM sph1.sph_observationdate),
                                                                'DD/MM/YYYY')
                                                        AND TO_DATE (
                                                                   iac.iac_endday
                                                                || '/'
                                                                || iac.iac_endmonth
                                                                || '/'
                                                                || EXTRACT (
                                                                       YEAR FROM sph1.sph_observationdate),
                                                                'DD/MM/YYYY')
                       AND ROWNUM < 2),
               (SELECT cdn1.cdn_designation
                  FROM codedesignation cdn1
                       INNER JOIN avaliabilitycalendar iac
                           ON cdn1.cdn_cvl_id = iac.iac_cvl_id_midatwindow
                       INNER JOIN codevalue cvl5
                           ON cvl5.cvl_id = iac.iac_cvl_id_midatindice
                       INNER JOIN language lan2
                           ON lan2.lan_id = cdn1.cdn_lan_id
                 WHERE     cvl5.cvl_code =
                           pkg_codevalue.f_get_midatindice_ibch
                       AND lan2.lan_id =
                           (SELECT crf_lan_id_default
                              FROM codereference
                             WHERE crf_code =
                                   pkg_codereference.f_get_crf_midatwindow)
                       AND sph1.sph_observationdate BETWEEN TO_DATE (
                                                                   iac.iac_startday
                                                                || '/'
                                                                || iac.iac_startmonth
                                                                || '/'
                                                                || EXTRACT (
                                                                       YEAR FROM sph1.sph_observationdate),
                                                                'DD/MM/YYYY')
                                                        AND TO_DATE (
                                                                   iac.iac_endday
                                                                || '/'
                                                                || iac.iac_endmonth
                                                                || '/'
                                                                || EXTRACT (
                                                                       YEAR FROM sph1.sph_observationdate),
                                                                'DD/MM/YYYY')
                       AND ROWNUM < 2))
               "WINDOWIBCH",
           sph1.sph_spearindexvalue
               "SPEAR",
           (SELECT cdn1.cdn_designation
              FROM codedesignation cdn1
                   INNER JOIN biologicalstate bls1
                       ON bls1.bls_cvl_id_biolstatetxt = cdn1.cdn_cvl_id
                   INNER JOIN codevalue cvl5
                       ON cvl5.cvl_id = bls1.bls_cvl_id_midatindice
                   INNER JOIN language lan2 ON lan2.lan_id = cdn1.cdn_lan_id
             WHERE     cvl5.cvl_code = pkg_codevalue.f_get_midatindice_spear
                   AND lan2.lan_code = lan1.lan_code
                   AND sph1.sph_spearindexvalue BETWEEN bls1.bls_fromvalue
                                                    AND bls1.bls_tovalue
                   AND ROWNUM < 2)
               "SPEAR_RANGE",
           NVL (
               (SELECT cdn1.cdn_designation
                  FROM codedesignation cdn1
                       INNER JOIN avaliabilitycalendar iac
                           ON cdn1.cdn_cvl_id = iac.iac_cvl_id_midatwindow
                       INNER JOIN codevalue cvl5
                           ON cvl5.cvl_id = iac.iac_cvl_id_midatindice
                       INNER JOIN language lan2
                           ON lan2.lan_id = cdn1.cdn_lan_id
                 WHERE     cvl5.cvl_code =
                           pkg_codevalue.f_get_midatindice_spear
                       AND lan2.lan_code = lan1.lan_code
                       AND sph1.sph_observationdate BETWEEN TO_DATE (
                                                                   iac.iac_startday
                                                                || '/'
                                                                || iac.iac_startmonth
                                                                || '/'
                                                                || EXTRACT (
                                                                       YEAR FROM sph1.sph_observationdate),
                                                                'DD/MM/YYYY')
                                                        AND TO_DATE (
                                                                   iac.iac_endday
                                                                || '/'
                                                                || iac.iac_endmonth
                                                                || '/'
                                                                || EXTRACT (
                                                                       YEAR FROM sph1.sph_observationdate),
                                                                'DD/MM/YYYY')
                       AND ROWNUM < 2),
               (SELECT cdn1.cdn_designation
                  FROM codedesignation cdn1
                       INNER JOIN avaliabilitycalendar iac
                           ON cdn1.cdn_cvl_id = iac.iac_cvl_id_midatwindow
                       INNER JOIN codevalue cvl5
                           ON cvl5.cvl_id = iac.iac_cvl_id_midatindice
                       INNER JOIN language lan2
                           ON lan2.lan_id = cdn1.cdn_lan_id
                 WHERE     cvl5.cvl_code =
                           pkg_codevalue.f_get_midatindice_spear
                       AND lan2.lan_id =
                           (SELECT crf_lan_id_default
                              FROM codereference
                             WHERE crf_code =
                                   pkg_codereference.f_get_crf_midatwindow)
                       AND sph1.sph_observationdate BETWEEN TO_DATE (
                                                                   iac.iac_startday
                                                                || '/'
                                                                || iac.iac_startmonth
                                                                || '/'
                                                                || EXTRACT (
                                                                       YEAR FROM sph1.sph_observationdate),
                                                                'DD/MM/YYYY')
                                                        AND TO_DATE (
                                                                   iac.iac_endday
                                                                || '/'
                                                                || iac.iac_endmonth
                                                                || '/'
                                                                || EXTRACT (
                                                                       YEAR FROM sph1.sph_observationdate),
                                                                'DD/MM/YYYY')
                       AND ROWNUM < 2))
               "WINDOWSPEAR",
           sph1.sph_makroindexvalue
               "MAKROINDEX",
           (SELECT cdn1.cdn_designation
              FROM codedesignation cdn1
                   INNER JOIN biologicalstate bls1
                       ON bls1.bls_cvl_id_biolstatetxt = cdn1.cdn_cvl_id
                   INNER JOIN codevalue cvl5
                       ON cvl5.cvl_id = bls1.bls_cvl_id_midatindice
                   INNER JOIN language lan2 ON lan2.lan_id = cdn1.cdn_lan_id
             WHERE     cvl5.cvl_code =
                       pkg_codevalue.f_get_midatindice_makroindex
                   AND lan2.lan_code = lan1.lan_code
                   AND sph1.sph_makroindexvalue BETWEEN bls1.bls_fromvalue
                                                    AND bls1.bls_tovalue
                   AND ROWNUM < 2)
               "MAKROINDEX_RANGE",
           sph1.sph_ibchgivalue
               "GI_VALUE",
           sph1.sph_ibchvtvalue
               "VT_VALUE",
           sph1.sph_ibch_indicator_group
               "GI_TAXON",
           sph1.sph_ibch_sum_taxon
               "TAXON_SUM",
           sph1.sph_ibch_sum_plecoptera
               "SUM_PRECOPTERA",
           sph1.sph_ibch_sum_ephemeroptera
               "SUM_EFEMEROPTERA",
           sph1.sph_ibch_sum_tricoptera
               "SUM_TRICOPTERA",
           prj1.prj_designation
               "PROJECT",
           ins1.ins_name
               "INSTITUTION_MANDANTE",
           ins2.ins_name
               "INSTITUTION_MANDATAIRE",
           (SELECT cdn1.cdn_designation
              FROM codevalue cvl1
                   INNER JOIN codedesignation cdn1
                       ON cdn1.cdn_cvl_id = cvl1.cvl_id
                   INNER JOIN language lan3 ON lan3.lan_id = cdn1.cdn_lan_id
                   INNER JOIN codereference crf1
                       ON crf1.crf_id = cvl1.cvl_crf_id
             WHERE     cvl1.cvl_code =
                       CASE sph1.sph_visibilitystatus
                           WHEN 'Y' THEN 'YES'
                           ELSE 'NO'
                       END
                   AND lan3.lan_code = lan1.lan_code
                   AND crf1.crf_code = pkg_codereference.f_get_crf_yesnofull)
               "PUBLIE",
           (SELECT cdn1.cdn_designation
              FROM codevalue cvl1
                   INNER JOIN codedesignation cdn1
                       ON cdn1.cdn_cvl_id = cvl1.cvl_id
                   INNER JOIN language lan3 ON lan3.lan_id = cdn1.cdn_lan_id
                   INNER JOIN codereference crf1
                       ON crf1.crf_id = cvl1.cvl_crf_id
             WHERE     cvl1.cvl_code =
                       NVL ((SELECT 'YES'
                               FROM DUAL
                              WHERE EXISTS
                                        (SELECT 'x'
                                           FROM sampleprotocolgrid
                                          WHERE spg_sph_id = sph1.sph_id)),
                            'NO')
                   AND lan3.lan_code = lan1.lan_code
                   AND crf1.crf_code = pkg_codereference.f_get_crf_yesnofull)
               "GRID_EXIST",
           (SELECT cdn1.cdn_designation
              FROM codevalue cvl1
                   INNER JOIN codedesignation cdn1
                       ON cdn1.cdn_cvl_id = cvl1.cvl_id
                   INNER JOIN language lan3 ON lan3.lan_id = cdn1.cdn_lan_id
                   INNER JOIN codereference crf1
                       ON crf1.crf_id = cvl1.cvl_crf_id
             WHERE     cvl1.cvl_code =
                       NVL ((SELECT 'YES'
                               FROM DUAL
                              WHERE EXISTS
                                        (SELECT 'x'
                                           FROM sampleprotocolgrnd
                                          WHERE spd_sph_id = sph1.sph_id)),
                            'NO')
                   AND lan3.lan_code = lan1.lan_code
                   AND crf1.crf_code = pkg_codereference.f_get_crf_yesnofull)
               "GROUND_EXIST",
           shm1.shm_id
               "WATERCOURSE_SHM_ID",
           shm2.shm_id
               "LOCALITY_SHM_ID",
           cvl4.cvl_id
               "CANTON_CVL_ID",
           prj1.prj_id
               "PROJET_ID",
           ins1.ins_id
               "INSTITUTION_MANDANTE_ID",
           ins2.ins_id
               "INSTITUTION_MANDATAIRE_ID",
           sph_visibilitystatus
               "PUBLISH_CODE",
           NVL ((SELECT 'Y'
                   FROM DUAL
                  WHERE EXISTS
                            (SELECT 'x'
                               FROM sampleprotocolgrid
                              WHERE spg_sph_id = sph1.sph_id)),
                'N')
               "GRID_EXIST_CODE",
           NVL ((SELECT 'Y'
                   FROM DUAL
                  WHERE EXISTS
                            (SELECT 'x'
                               FROM sampleprotocolgrnd
                              WHERE spd_sph_id = sph1.sph_id)),
                'N')
               "GROUND_EXIST_CODE",
           lan1.lan_code,
           (    SELECT LISTAGG (
                           syd_designation || ' (' || crf_designation || ')', '/')
                           WITHIN GROUP (ORDER BY syv_id)
                  FROM systvalue
                       INNER JOIN systdesignation ON syd_syv_id = syv_id
                       INNER JOIN language ON lan_id = syd_lan_id
                       INNER JOIN codereference ON crf_id = syv_crf_id
                 WHERE lan_code = 'la'
            CONNECT BY syv_id = PRIOR syv_syv_id
            START WITH syv_id = spl1.spl_syv_id)
               "IDENTIFIEDTAXON",
           (    SELECT syd_designation
                  FROM systvalue
                       INNER JOIN systdesignation ON syd_syv_id = syv_id
                       INNER JOIN language ON lan_id = syd_lan_id
                       INNER JOIN codereference ON crf_id = syv_crf_id
                 WHERE     lan_code = 'la'
                       AND crf_code = pkg_codereference.f_get_crf_phylum
                       AND ROWNUM < 2
            CONNECT BY syv_id = PRIOR syv_syv_id
            START WITH syv_id = spl1.spl_syv_id)
               "PHYLUM",
           (    SELECT syd_designation
                  FROM systvalue
                       INNER JOIN systdesignation ON syd_syv_id = syv_id
                       INNER JOIN language ON lan_id = syd_lan_id
                       INNER JOIN codereference ON crf_id = syv_crf_id
                 WHERE     lan_code = 'la'
                       AND crf_code = pkg_codereference.f_get_crf_class
                       AND ROWNUM < 2
            CONNECT BY syv_id = PRIOR syv_syv_id
            START WITH syv_id = spl1.spl_syv_id)
               "CLASS",
           (    SELECT syd_designation
                  FROM systvalue
                       INNER JOIN systdesignation ON syd_syv_id = syv_id
                       INNER JOIN language ON lan_id = syd_lan_id
                       INNER JOIN codereference ON crf_id = syv_crf_id
                 WHERE     lan_code = 'la'
                       AND crf_code = pkg_codereference.f_get_crf_order
                       AND ROWNUM < 2
            CONNECT BY syv_id = PRIOR syv_syv_id
            START WITH syv_id = spl1.spl_syv_id)
               "ORDER",
           (    SELECT syd_designation
                  FROM systvalue
                       INNER JOIN systdesignation ON syd_syv_id = syv_id
                       INNER JOIN language ON lan_id = syd_lan_id
                       INNER JOIN codereference ON crf_id = syv_crf_id
                 WHERE     lan_code = 'la'
                       AND crf_code = pkg_codereference.f_get_crf_family
                       AND ROWNUM < 2
            CONNECT BY syv_id = PRIOR syv_syv_id
            START WITH syv_id = spl1.spl_syv_id)
               "FAMILY",
           (    SELECT syd_designation
                  FROM systvalue
                       INNER JOIN systdesignation ON syd_syv_id = syv_id
                       INNER JOIN language ON lan_id = syd_lan_id
                       INNER JOIN codereference ON crf_id = syv_crf_id
                 WHERE     lan_code = 'la'
                       AND crf_code = pkg_codereference.f_get_crf_genus
                       AND ROWNUM < 2
            CONNECT BY syv_id = PRIOR syv_syv_id
            START WITH syv_id = spl1.spl_syv_id)
               "GENUS",
           (    SELECT syd_designation
                  FROM systvalue
                       INNER JOIN systdesignation ON syd_syv_id = syv_id
                       INNER JOIN language ON lan_id = syd_lan_id
                       INNER JOIN codereference ON crf_id = syv_crf_id
                 WHERE     lan_code = 'la'
                       AND crf_code = pkg_codereference.f_get_crf_species
                       AND ROWNUM < 2
            CONNECT BY syv_id = PRIOR syv_syv_id
            START WITH syv_id = spl1.spl_syv_id)
               "SPECIES",
           spl_stadium
               "STATIUM",
           spl_comment
               "COMMENT",
           spl_sampleno
               "SAMPLENUMBER",
           usr1.usr_id
      FROM language lan1,
           admin_user usr1,
           sampleprotocollabo spl1
           INNER JOIN sampleheader sph1 ON sph1.sph_id = spl1.spl_sph_id
           INNER JOIN protocolversion ptv1 ON ptv1.ptv_id = sph1.sph_ptv_id
           INNER JOIN codevalue cvl1
               ON cvl1.cvl_id = ptv1.ptv_cvl_id_protocoltype
           INNER JOIN samplestation sst1 ON sst1.sst_id = sph1.sph_sst_id
           LEFT OUTER JOIN samplestation sst2
               ON sst2.sst_id = sst1.sst_sst_id
           LEFT OUTER JOIN sampleheaderitem shm1
               ON shm1.shm_sph_id = sph1.sph_id
           INNER JOIN codevalue cvl2
               ON cvl2.cvl_id = shm1.shm_cvl_id_midathditmty
           LEFT OUTER JOIN sampleheaderitem shm2
               ON shm2.shm_sph_id = sph1.sph_id
           INNER JOIN codevalue cvl3
               ON cvl3.cvl_id = shm2.shm_cvl_id_midathditmty
           LEFT OUTER JOIN codevalue cvl4
               ON cvl4.cvl_id = sst1.sst_cvl_id_canton
           LEFT OUTER JOIN project prj1 ON prj1.prj_id = sph1.sph_prj_id
           LEFT OUTER JOIN institution ins1
               ON ins1.ins_id = prj1.prj_ins_id_mandant
           LEFT OUTER JOIN institution ins2
               ON ins2.ins_id = prj1.prj_ins_id_mandataire
     WHERE     cvl2.cvl_code = pkg_codevalue.f_get_midathditmty_watercourse
           AND cvl3.cvl_code = pkg_codevalue.f_get_midathditmty_locality
           AND shm1.shm_cvl_id_midatproto = ptv1.ptv_cvl_id_protocoltype
           AND shm2.shm_cvl_id_midatproto = ptv1.ptv_cvl_id_protocoltype
           -- doit disposer du role user de l'application MIDAT
           AND (    EXISTS
                        (SELECT *
                           FROM admin_user
                                INNER JOIN admin_user_role_group
                                    ON arg_usr_id = usr_id
                                INNER JOIN admin_role ON arg_apr_id = apr_id
                                INNER JOIN admin_application
                                    ON apl_id = apr_apl_id
                          WHERE     apl_code =
                                    pkg_admin_application.f_getapplmidat
                                AND apr_name = pkg_admin_role.f_getroleuser
                                AND usr_id = usr1.usr_id)
                -- Peut voir tous ceux qu'il a créer
                AND (   sph_id IN (SELECT sph_id
                                     FROM sampleheader
                                    WHERE sph_usr_id_create = usr1.usr_id)
                     -- Ou tout ceux qui sont publics et visibles
                     OR sph_id IN
                            (SELECT sph_id
                               FROM sampleheader
                                    INNER JOIN sampleheaderadmingroup
                                        ON sph_id = shg_sph_id
                                    INNER JOIN admin_group
                                        ON shg_agr_id = agr_id
                              WHERE     sph_visibilitystatus = 'Y'
                                    AND agr_name =
                                        pkg_admin_group.f_get_group_public)
                     -- Ou tous ceux qui sont visibles et dans la liste des groupes de l'utilisateur;
                     OR sph_id IN
                            (SELECT sph_id
                               FROM sampleheader
                                    INNER JOIN sampleheaderadmingroup
                                        ON sph_id = shg_sph_id
                              WHERE     sph_visibilitystatus = 'Y'
                                    AND shg_agr_id IN
                                            (SELECT NVL (arg_agr_id, -1)
                                               FROM admin_user_role_group
                                                    INNER JOIN admin_role
                                                        ON arg_apr_id =
                                                           apr_id
                                                    INNER JOIN
                                                    admin_application
                                                        ON apl_id =
                                                           apr_apl_id
                                              WHERE     apl_code =
                                                        pkg_admin_application.f_getapplmidat
                                                    AND arg_usr_id =
                                                        usr1.usr_id))))
/

