create view V_NOMBREECHANTILLONCANTONUTILI as
SELECT COUNT (*) "Nombre",
             cvl1.cvl_code "Type de protocole",
             cdn_designation "Désignation",
             usr_user_login "Utilisateur",
             cvl2.cvl_code "Canton"
        FROM codedesignation
             INNER JOIN codevalue cvl1 ON cdn_cvl_id = cvl1.cvl_id
             INNER JOIN protocolversion ON cvl_id = ptv_cvl_id_protocoltype
             INNER JOIN sampleheader ON sph_ptv_id = ptv_id
             INNER JOIN language ON lan_id = cdn_lan_id
             INNER JOIN admin_user ON sph_usr_id_create = usr_id
             INNER JOIN samplestation ON sst_id = sph_sst_id
              INNER JOIN codevalue cvl2 ON sst_cvl_id_canton = cvl2.cvl_id
       WHERE lan_code = 'fr'
    GROUP BY cvl1.cvl_code,
             cdn_designation,
             sph_usr_id_create,
             usr_user_login,
             cvl2.cvl_code 
    ORDER BY cvl2.cvl_code, cvl1.cvl_code
/

