create PACKAGE       pkg_importprotocolheaderw
AS
   /******************************************************************************
      NAME:       PKG_IMPORTPROTOCOLHEADERW
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        04.10.2013      burrif       1. Created this package.
   ******************************************************************************/

   FUNCTION f_getversion
      RETURN VARCHAR2;



   PROCEDURE p_insertlabodata (
      p_ins_id_principal      IN     importprotocolheader.iph_ins_id_principal%TYPE, -- Mandant
      p_ins_id_mandatary      IN     importprotocolheader.iph_ins_id_mandatary%TYPE, -- Mandataire
      p_ptv_id                IN     importprotocolheader.iph_ptv_id%TYPE, -- Version du protocole
      p_per_id_determinator   IN     importprotocolheader.iph_per_id_determinator%TYPE, -- Personne qui a déterminer les espèces contenues dans l'échantillon
      p_determinateddate      IN     importprotocolheader.iph_determinateddate%TYPE, -- Date de détermination
      p_per_id_operator       IN     importprotocolheader.iph_per_id_operator%TYPE, -- Personne qui a réalisé l'échantillonage
      p_operateddate          IN     importprotocolheader.iph_observationdate%TYPE, -- Date de l'échantillonage
      p_cvl_id_midatstat      IN     importprotocolheader.iph_cvl_id_midatstat%TYPE, -- Type d'indice (en principe toujours IBCH)
      p_reporturl             IN     importprotocolheader.iph_reporturl%TYPE, -- Document URL
      p_lan_id                IN     importprotocolheader.iph_lan_id%TYPE, -- Langue du formulaire
      p_cvl_id_systlref       IN     importprotocolheader.iph_cvl_id_systlref%TYPE, -- Système de référence
      p_cvl_id_systlprec      IN     importprotocolheader.iph_cvl_id_systlprec%TYPE, -- Niveau de précision
      p_inputfilename         IN     importprotocolheader.iph_inputfilename%TYPE, -- Nom du fichier contenant la feuille Excel
      p_file                  IN     importprotocolheader.iph_file%TYPE, -- Fichier contenant la feuille Excel
      p_sheetname             IN     importprotocolheader.iph_sheetname%TYPE, -- Nom de la feuille
      p_usr_id_create         IN     importprotocolheader.iph_usr_id_create%TYPE, -- Identifiant de l'utilisateur qui réalise l'insertion
      p_sph_id_parent         IN     importprotocolheader.iph_sph_id_parent%TYPE, -- Identifiant du protocol laboratoire
      p_iph_prj_id            IN     importprotocolheader.iph_prj_id%TYPE,
      p_id                       OUT importprotocolheader.iph_id%TYPE); -- Identifiant de l'entrée;
END pkg_importprotocolheaderw;
/

