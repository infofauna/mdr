create view V_SAMPLETAXONINDICATEUR as
SELECT ROWNUM row_id,
          sph_id,
          spl_syv_id,
          syd_designation,
          ptl_ibchfaunagroup_gi,
           spl_frequency, ptl_ibchindividumin
     FROM sampleheader sph1
          INNER JOIN sampleprotocollabo ON spl_sph_id = sph_id
          LEFT JOIN sampleheaderfile ON shf_sph_id = sph_id
          LEFT JOIN sampleheadermassfile ON sph_smf_id = smf_id
          LEFT JOIN protocolversion
             ON    ptv_id = smf_ptv_id
                OR ptv_id = NVL (shf_ptv_id, ptv_ptv_id_labofrommass)
          INNER JOIN codevalue ON cvl_id = ptv_cvl_id_protocoltype
          INNER JOIN protocolmappinglabo
             ON     spl_syv_id = ptl_syv_id
                AND ptl_ptv_id = NVL (shf_ptv_id, ptv_ptv_id_labofrommass)
          INNER JOIN systdesignation ON spl_syv_id = syd_syv_id
          INNER JOIN language ON lan_id = syd_lan_id
    WHERE     cvl_code IN ('LABORATORY', 'MASS')
             --  AND sph_id = 233
          AND lan_code = 'la'
          AND spl_frequency>=ptl_ibchindividumin
          AND ptl_ibchfaunagroup_gi IN
                 (SELECT MAX (ptl_ibchfaunagroup_gi)
                    FROM sampleheader sph2
                         INNER JOIN sampleprotocollabo ON spl_sph_id = sph_id
                         LEFT JOIN sampleheaderfile ON shf_sph_id = sph_id
                         LEFT JOIN sampleheadermassfile
                            ON sph_smf_id = smf_id
                         LEFT JOIN protocolversion
                            ON    ptv_id = smf_ptv_id
                               OR ptv_id =
                                     NVL (shf_ptv_id,
                                          ptv_ptv_id_labofrommass)
                         INNER JOIN codevalue
                            ON cvl_id = ptv_cvl_id_protocoltype
                         INNER JOIN protocolmappinglabo
                            ON     spl_syv_id = ptl_syv_id
                               AND ptl_ptv_id =
                                      NVL (shf_ptv_id,
                                           ptv_ptv_id_labofrommass)
                   WHERE     cvl_code IN ('LABORATORY', 'MASS')
                         AND sph1.sph_id = sph2.sph_id                    
                         AND spl_frequency>=ptl_ibchindividumin)
/

