create view V_DISPLAYLOG as
SELECT pkg_message.f_returnmessageseverity (ipo_exceptionnumber)
                 severity,
             pkg_importprotocollog.f_buildmessage (ipo_id,
                                                   ipo_exceptionnumber,
                                                   lan_id)
                 MESSAGE,
             ipo_fieldname,
             ipo_exceptionnumber,
             lan_id,
             sph_id,
             ipo_iph_id,
             ipo_id
        FROM importprotocollog
             INNER JOIN sampleheader ON sph_iph_id = ipo_iph_id,
             language
    ORDER BY ipo_id
/

