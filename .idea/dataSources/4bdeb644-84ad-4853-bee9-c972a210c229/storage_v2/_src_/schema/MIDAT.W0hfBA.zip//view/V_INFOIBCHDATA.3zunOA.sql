create view V_INFOIBCHDATA as
SELECT sph_id,
       CASE cvl0.cvl_code
          WHEN pkg_codevalue.f_get_protocoltype_mass THEN 'PDM'
          WHEN pkg_codevalue.f_get_protocoltype_laboratory THEN 'PDL'
       END
          "TYPE",
       CASE cvl0.cvl_code
          WHEN pkg_codevalue.f_get_protocoltype_mass
          THEN
             CASE pkg_ibchstat.f_hascolumntaxonibchexist (sph_id)
                WHEN 'Y' THEN 'EXIST'
                ELSE 'NOT_EXIST'
             END
          WHEN pkg_codevalue.f_get_protocoltype_laboratory
          THEN
             'N/A'
       END
          "COLUMN_TAXONIBCH",
       sst_oid "STATION",
       TO_CHAR (sph_observationdate, 'DD/MM/YYYY') "Date",
       sst.sst_coordinates.sdo_point.x "CX",
       sst.sst_coordinates.sdo_point.y "CY",
       shm_item "Lieu",
       pkg_ibchstat.f_getibchsomme_vt (sph_id) "SUM_TAXON",
       pkg_ibchstat.f_gettaxonindicateur (sph_id) "TAXON_INDICATEUR",
       pkg_ibchstat.f_getibchgi (sph_id) "GI",
       pkg_ibchstat.f_getibchvt (sph_id) "VT",
       pkg_ibchstat.f_getibch (sph_id) "IBCH",
       pkg_ibchstat.f_getsumbytaxonibch (sph_id, 'EPHEMEROPTERA')
          "COUNT_EPHEMEROPTERA",
       pkg_ibchstat.f_getsumbytaxonibch (sph_id, 'PLECOPTERA')
          "COUNT_PLECOPTERA",
       pkg_ibchstat.f_getsumbytaxonibch (sph_id, 'TRICHOPTERA')
          "COUNT_TRICOPTERA"
  FROM sampleheader sph
       INNER JOIN samplestation sst ON sph.sph_sst_id = sst.sst_id
       INNER JOIN protocolversion ON ptv_id = sph.sph_ptv_id
       INNER JOIN codevalue cvl0 ON cvl0.cvl_id = ptv_cvl_id_protocoltype
       INNER JOIN sampleheaderitem shm ON sph.sph_id = shm.shm_sph_id
       INNER JOIN codevalue cvl1 ON cvl1.cvl_id = shm.shm_cvl_id_midathditmty
 WHERE cvl1.cvl_code = pkg_codevalue.f_get_midatstitmty_watercourse
/

