create view V_STATIONSAMPLE as
SELECT sph_sst_id,
           sst.sst_oid,
           sst.sst_coordinates.sdo_point.x swisscoordinate_x,
           sst.sst_coordinates.sdo_point.y swisscoordinate_y,
           sph_id,
           sph_indexvalueibch,
           sph_makroindexvalue,
           sph_spearindexvalue,
           sph_observationdate
      FROM sampleheader shp
           INNER JOIN samplestation sst ON sph_sst_id = sst_id
/

