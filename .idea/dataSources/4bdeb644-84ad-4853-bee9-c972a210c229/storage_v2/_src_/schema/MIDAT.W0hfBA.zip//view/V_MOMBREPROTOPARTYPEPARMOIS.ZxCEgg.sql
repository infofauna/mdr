create view V_MOMBREPROTOPARTYPEPARMOIS as
SELECT DISTINCT
            rownum id,
           annee,
     
           mois,
       (SELECT COUNT (*)
          FROM sampleheader
               INNER JOIN protocolversion ON ptv_id = sph_ptv_id
               INNER JOIN codevalue ON cvl_id = ptv_cvl_id_protocoltype
         WHERE cvl_code = pkg_codevalue.f_get_protocoltype_laboratory
         AND  EXTRACT (YEAR FROM sph_credate)=ANNEE
         AND EXTRACT (MONTH FROM SPH_CREDATE)=MOIS) NombreLaboratory,
            (SELECT COUNT (*)
          FROM sampleheader
               INNER JOIN protocolversion ON ptv_id = sph_ptv_id
               INNER JOIN codevalue ON cvl_id = ptv_cvl_id_protocoltype
         WHERE cvl_code = pkg_codevalue.f_get_protocoltype_mass
         AND  EXTRACT (YEAR FROM sph_credate)=ANNEE
         AND EXTRACT (MONTH FROM SPH_CREDATE)=MOIS) NombreMASS
  FROM (  SELECT DISTINCT
                 EXTRACT (YEAR FROM "DATEJOUR") annee,
                 EXTRACT (MONTH FROM "DATEJOUR") mois
            FROM (SELECT ROWNUM,
                         (SELECT MIN (sph_credate) FROM sampleheader),
                         (SELECT MAX (sph_credate) FROM sampleheader),
                           (SELECT MIN (sph_credate) FROM sampleheader)
                         + ROWNUM
                         - 1
                             "DATEJOUR"
                    FROM all_objects
                   WHERE (SELECT MIN (sph_credate) FROM sampleheader) + ROWNUM BETWEEN (SELECT MIN (
                                                                                                   sph_credate)
                                                                                          FROM sampleheader)
                                                                                   AND (SELECT MAX (
                                                                                                   sph_credate)
                                                                                          FROM sampleheader)))
        ORDER BY annee, mois
/

