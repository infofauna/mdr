create view V_PROTOCOLEINDICE as
SELECT ROWNUM id,
             DECODE (cvl_code, 'OUTOFBORDER', '{CH-OUT}', cvl_code) canton,
             countibch,
             minibch,
             maxibch,
             avgibch,
             countspear,
             minspear,
             maxspear,
             avgspear,
             countmakroindex,
             minmakroindex,
             maxmakroindex,
             avgmakroindex
        FROM (  SELECT cvl_code,
                       (SELECT COUNT (sph_indexvalueibch)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           countibch,
                       (SELECT MIN (sph_indexvalueibch)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           minibch,
                       (SELECT MAX (sph_indexvalueibch)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           maxibch,
                       (SELECT AVG (sph_indexvalueibch)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           avgibch,
                       (SELECT COUNT (sph_spearindexvalue)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           countspear,
                       (SELECT MIN (sph_spearindexvalue)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           minspear,
                       (SELECT MAX (sph_spearindexvalue)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           maxspear,
                       (SELECT AVG (sph_spearindexvalue)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           avgspear,
                       (SELECT COUNT (sph_makroindexvalue)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           countmakroindex,
                       (SELECT MIN (sph_makroindexvalue)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           minmakroindex,
                       (SELECT MAX (sph_makroindexvalue)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           maxmakroindex,
                       (SELECT AVG (sph_makroindexvalue)
                          FROM sampleheader sph
                               INNER JOIN samplestation ON sst_id = sph_sst_id
                         WHERE sst_cvl_id_canton = cvl1.cvl_id)
                           avgmakroindex
                  FROM codevalue cvl1
                       INNER JOIN codereference ON crf_id = cvl_crf_id
                       LEFT OUTER JOIN samplestation
                           ON cvl1.cvl_id = sst_cvl_id_canton
                       INNER JOIN sampleheader sph1 ON sst_id = sph1.sph_sst_id
                 WHERE crf_code = pkg_codereference.f_get_crf_canton
              GROUP BY cvl1.cvl_id, cvl1.cvl_code)
    ORDER BY NLSSORT (canton, 'NLS_SORT=ASCII7')
/

