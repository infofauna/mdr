create view V_NOMBREECHANTILLONPARMOIS as
SELECT COUNT (*) "Nombre",
             cvl1.cvl_code "type de protocole",
             cdn_designation "Désignation",
             cvl2.cvl_code "Canton",
             EXTRACT (YEAR FROM sph_credate) annee,
             EXTRACT (MONTH FROM sph_credate) mois
        FROM codedesignation
             INNER JOIN codevalue cvl1 ON cdn_cvl_id = cvl1.cvl_id
             INNER JOIN protocolversion ON cvl_id = ptv_cvl_id_protocoltype
             INNER JOIN sampleheader ON sph_ptv_id = ptv_id
             INNER JOIN language ON lan_id = cdn_lan_id
             INNER JOIN admin_user ON sph_usr_id_create = usr_id
             INNER JOIN samplestation ON sst_id = sph_sst_id
             INNER JOIN codevalue cvl2 ON sst_cvl_id_canton = cvl2.cvl_id
       WHERE lan_code = 'fr'
    GROUP BY cvl1.cvl_code,
             cdn_designation,
             EXTRACT (YEAR FROM sph_credate),
             EXTRACT (MONTH FROM sph_credate),
             cvl2.cvl_code
    ORDER BY EXTRACT (YEAR FROM sph_credate),
             EXTRACT (MONTH FROM sph_credate),
             cvl2.cvl_code,
             cvl1.cvl_code
/

