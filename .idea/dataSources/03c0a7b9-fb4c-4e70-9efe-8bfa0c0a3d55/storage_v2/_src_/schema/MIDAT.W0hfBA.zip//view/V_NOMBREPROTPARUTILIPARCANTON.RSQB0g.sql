create view V_NOMBREPROTPARUTILIPARCANTON as
SELECT ROWNUM id,
       usr_user_login login,
       cvl_code canton,
       nombremass,
       nombrelaboratory
  FROM (  SELECT usr_user_login,
                 cvl_code,
                 (SELECT COUNT (*)
                    FROM sampleheader sph
                         INNER JOIN samplestation ON sst_id = sph_sst_id
                         INNER JOIN protocolversion ON ptv_id = sph_ptv_id
                         INNER JOIN codevalue
                             ON cvl_id = ptv_cvl_id_protocoltype
                   WHERE     cvl_code = pkg_codevalue.f_get_protocoltype_mass
                         AND sst_cvl_id_canton = cvl1.cvl_id
                         AND sph_usr_id_create = sph1.sph_usr_id_create)
                     nombremass,
                 (SELECT COUNT (*)
                    FROM sampleheader
                         INNER JOIN samplestation ON sst_id = sph_sst_id
                         INNER JOIN protocolversion ON ptv_id = sph_ptv_id
                         INNER JOIN codevalue
                             ON cvl_id = ptv_cvl_id_protocoltype
                   WHERE     cvl_code =
                             pkg_codevalue.f_get_protocoltype_laboratory
                         AND sst_cvl_id_canton = cvl1.cvl_id
                         AND sph_usr_id_create = sph1.sph_usr_id_create)
                     nombrelaboratory
            FROM codevalue cvl1
                 INNER JOIN codereference ON crf_id = cvl_crf_id
                 LEFT OUTER JOIN samplestation
                     ON cvl1.cvl_id = sst_cvl_id_canton
                 INNER JOIN sampleheader sph1 ON sst_id = sph1.sph_sst_id
                 INNER JOIN admin_user ON usr_id = sph1.sph_usr_id_create
           WHERE crf_code = pkg_codereference.f_get_crf_canton
        GROUP BY sph1.sph_usr_id_create,
                 usr_user_login,
                 cvl1.cvl_id,
                 cvl1.cvl_code
        ORDER BY cvl_code)
/

