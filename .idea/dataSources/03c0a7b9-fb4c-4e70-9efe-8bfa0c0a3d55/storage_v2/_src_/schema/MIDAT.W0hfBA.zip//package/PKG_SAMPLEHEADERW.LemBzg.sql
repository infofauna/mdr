create PACKAGE       pkg_sampleheaderw
AS
   /******************************************************************************
      NAME:       PKG_SAMPLEHEADERW
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        10.10.2013   F.Burri          1. Created this package.
   ******************************************************************************/



   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_deleteprotocolentry (
      p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE);

   PROCEDURE p_deleteprotocolentry (
      p_sph_id   IN sampleheaderitem.shm_sph_id%TYPE,
      p_ptv_id   IN sampleheader.sph_ptv_id%TYPE);

END pkg_sampleheaderw;
/

