create view V_LISTECONNEXION as
SELECT apl_code
                 " Application",
             usr_user_login
                 "Login",
             usr_is_ldap_login
                 "Accès LDAP",
             per_lastname
                 "Nom",
             per_firstname
                 "Prénom",
             per_addressline1
                 "Adresse",
             per_zipcode || '-' || per_locality
                 "NPA-Localité",
             TO_CHAR (usr_credate, 'DD/MM/YYYY HH24:MI:SS')
                 "Date de création",
             TO_CHAR (MIN (lgx_connectiondate), 'DD/MM/YYYY HH24:MI:SS')
                 "première connexion",
             TO_CHAR (MAX (lgx_connectiondate), 'DD/MM/YYYY HH24:MI:SS')
                 "dernière connexion",
             COUNT (*)
                 "Nombre de connexion"
        FROM admin_user
             INNER JOIN admin_logconnection ON usr_id = lgx_usr_id
             INNER JOIN admin_application ON apl_id = lgx_apl_id
             LEFT OUTER JOIN infofauna.person ON per_id = usr_per_id
       WHERE usr_status = 'A'
    GROUP BY usr_user_login,
             usr_is_ldap_login,
             per_lastname,
             per_firstname,
             per_addressline1,
             per_zipcode || '-' || per_locality,
             usr_credate,
             apl_code
    ORDER BY usr_user_login, apl_code
/

