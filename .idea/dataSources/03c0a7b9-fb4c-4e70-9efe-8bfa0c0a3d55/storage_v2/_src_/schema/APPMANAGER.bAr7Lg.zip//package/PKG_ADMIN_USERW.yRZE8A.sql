create PACKAGE            pkg_admin_userw
AS
   /******************************************************************************
      NAME:       PKG_ADMIN_USER
      PURPOSE:

      REVISIONS:
      Ver        Date        Author           Description
      ---------  ----------  ---------------  ------------------------------------
      1.0        19.07.2013      burrif       1. Created this package.
   ******************************************************************************/
   FUNCTION f_getversion
      RETURN VARCHAR2;

   PROCEDURE p_delete (p_usr_id IN admin_user.usr_id%TYPE);


   PROCEDURE p_login (p_username       IN     admin_user.usr_user_login%TYPE,
                      p_password       IN     VARCHAR2, -- Password en clair pour validation via LDAP
                      p_passwordhash   IN     VARCHAR2, -- Password crypté pour validation des comptes locaux
                      p_lan_code       IN     language.lan_code%TYPE, -- Code langue
                      p_ipaddress      IN     VARCHAR2,          -- Adresse IP
                      p_apl_id         IN     NUMBER, -- Identifiant de l'application (colonne APL_ID de la table ADMIN_APPLICATION)
                      p_token          IN     VARCHAR2, -- Token généré par la session WEB
                      p_user_id           OUT admin_user.usr_id%TYPE, -- Identifiant de l'utilisateur
                      p_returnstatus      OUT NUMBER); -- Status (0 = ok, différent de 0 = erreur)
END pkg_admin_userw;
/

